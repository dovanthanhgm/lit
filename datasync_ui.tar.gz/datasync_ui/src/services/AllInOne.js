import axios from "src/utils/axios";

export const getCalculatedMoney = async ({ body }) => {
  const res = await axios.post(`/api/buy-service/aio/calculated`, body);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const updateAllInOne = async ({ body }) => {
  const res = await axios.post(`api/buy-service/aio`, body);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const couponAllInOne = async ({ body }) => {
  const res = await axios.post(`/api/buy-service/aio/apply-coupon`, body);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};
