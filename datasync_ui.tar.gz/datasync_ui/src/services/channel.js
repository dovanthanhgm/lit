import axios from "src/utils/axios";
import { ProductTableSortAPI } from "../constants/TableSortAPI";
import { DRAFT_VALUE, ERROR_VALUE } from "../constants/Listing";

// export const getAllChannelsAPI = async data => {
//   const respose = await axios.get("/api/channels");
//   if (respose.status < 400) {
//     return respose.data;
//   }
// };

export const channelSetupAPI = async data => {
  const respose = await axios.post("/api/channel/setup", data);
  if (respose?.status < 400) {
    return respose.data;
  }
};

export const csvFeedCreateNew = async ({ channel_id, body }) => {
  const response = await axios.post(`api/channels/${channel_id}/feeds`, body);
  if (response?.status < 400) {
    return response.data;
  }
};

export const csvFeedEdit = async ({ channel_id, feed_id }) => {
  const response = await axios.get(
    `api/channels/${channel_id}/feeds/${feed_id}`
  );
  if (response?.status < 400) {
    return response.data;
  }
};

export const csvFeedEditUpdate = async ({ channel_id, feed_id, body }) => {
  const response = await axios.put(
    `api/channels/${channel_id}/feeds/${feed_id}`,
    body
  );
  if (response?.status < 400) {
    return response;
  }
};

export const testConnectCSV = async data => {
  const respose = await axios.post("/api/products/csv/test-connection", data);
  if (respose?.status < 400) {
    return respose.data;
  }
};

export const channelDetailAPI = async ({ channelID }) => {
  const respose = await axios
    .get(`/api/channels/${channelID}`)
    .catch(e => console.log("error", e));
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const getStatusCode = async channelID => {
  const res = await axios
    .get(`/api/channels/${channelID}/process`)
    .catch(e => console.log("error", e));
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const channelSettingsDetailAPI = async ({ channelID }) => {
  const respose = await axios
    .get(`/api/channels/${channelID}/state`)
    .catch(e => console.log("error", e));
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const channelProductsCountAPI = async (channelID, filter, search) => {
  let api = `/api/channel/${channelID}/products/count`;
  let symbol = "?";
  if (Object.keys(filter).length > 0) {
    Object.keys(filter).forEach(key => {
      if (filter[key] || filter[key] === "false") {
        api += `${symbol}${key}=${
          ["title", "sku"].includes(key) ? filter[key]?.trim() : filter[key]
        }`;
        symbol = "&";
      }
    });
  }

  if (search) {
    api += search;
  }
  const respose = await axios.get(api).catch(e => {
    console.log("error", e);
    return e.response;
  });

  if (respose?.status < 400 && respose.data) {
    return respose.data;
  } else {
    return respose;
  }
};

export const listingDetailCount = async ({ channelID, filter, search }) => {
  let api = `/api/channel/${channelID}/products/count`;

  if (search) {
    api += search;
  }
  const request = await axios.get(api);
  return request.data;
};

export const channelPublishAPI = async ({
  channelID,
  product_ids,
  currentTab,
  publish_draft
}) => {
  const data = { product_ids, publish_draft };
  if (!publish_draft) {
    delete data.publish_draft;
  }
  const respose = [ERROR_VALUE, DRAFT_VALUE].includes(currentTab)
    ? await axios.post(`/api/channel/${channelID}/products/listing/publish`, {
        ...data
      })
    : await axios.put(`/api/channel/${channelID}/products/listing/publish`, {
        product_ids
      });
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const listingDetailProducts = async ({
  limit = 25,
  channelID,
  type,
  search = "",
  page = "",
  sort = ""
}) => {
  let newSearch = search ? search + "&" : "?";

  let api =
    type === "active"
      ? `/api/channel/${channelID}/products${newSearch}limit=${limit}&page=${page ||
          1}`
      : `/api/channel/${channelID}/products/${type}${newSearch}limit=${limit}&page=${page ||
          1}`;

  const filterApi = () => {
    if (sort) {
      api += `&${sort}`;
    }
    return api;
  };

  const request = await axios.get(filterApi());
  return request.data.data;
};

const handleSearch = (search, page) => {
  if (search) {
    if (!search.includes("page")) {
      search += `&page=${page}`;
    }
    return search;
  }
  return page ? `?page=${page}` : "?page=1";
};

export const multiEditProductsAPI = async ({
  limit = 25,
  channelID,
  type,
  search,
  sortValueString = "",
  page
}) => {
  let newSearch = handleSearch(search, page);
  if (!!sortValueString) {
    newSearch += sortValueString;
  }
  const api =
    type === "active"
      ? `/api/channel/${channelID}/products${newSearch}&limit=${limit}`
      : `/api/channel/${channelID}/products/${type}${newSearch}&limit=${limit}`;

  const filterApi = () => {
    return api;
  };

  const request = await axios.get(filterApi());
  return request.data.data;
};

export const channelAllProductsAPI = async ({
  limit = 10,
  channelID,
  type,
  colName,
  search,
  sort
}) => {
  let newSearch = search || "?page=1";
  if (!type) {
    return;
  }
  const api =
    type === "active"
      ? `/api/channel/${channelID}/products${newSearch}&limit=${limit}`
      : `/api/channel/${channelID}/products/${type}${newSearch}&limit=${limit}`;

  const filterApi = () => {
    if (sort) {
      return api + ProductTableSortAPI[colName][sort];
    }
    return api;
  };

  const respose = await axios.get(filterApi()).catch(e => {
    return e.response;
  });

  if (respose?.status < 400 && respose.data) {
    return respose.data;
  } else {
    return respose;
  }
};

export const marketplaceMainStoreAPI = async ({
  limit = 10,
  channelID,
  type,
  search,
  page,
  sort
}) => {
  let newSearch = () => {
    if (search) {
      return search + "&";
    }
    return "?";
  };

  if (!type) {
    return;
  }
  const api =
    type === "active"
      ? `/api/channel/${channelID}/products${newSearch()}&page=${page}&limit=${limit}`
      : `/api/channel/${channelID}/products/${type}${newSearch()}&page=${page}&limit=${limit}`;

  const filterApi = () => {
    if (sort) {
      return api + sort;
    }
    return api;
  };

  const response = await axios.get(filterApi()).catch(e => {
    return e.response;
  });

  if (response?.status < 400 && response.data) {
    return response.data;
  } else {
    return response;
  }
};

export const cartConnectorAPI = async () => {
  const respose = await axios
    .post(`/api/cart/connector`)
    .catch(e => console.log("error", e));
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const merchantChannelIDAPI = async ({ channelID, body }) => {
  const respose = await axios.post(`/merchant/${channelID}`, body);
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const reconnectChannelAPi = async ({ channelID, body }) => {
  const respose = await axios.post(
    `/api/channels/${channelID}/reconnect`,
    body
  );
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const merchantAmazonAPI = async ({ id }) => {
  const respose = await axios.get(`/merchant/amazon?marketplace_id=${id}`);
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const deleteChannelAPI = async channelID => {
  const respose = await axios
    .delete(`/api/channels/${channelID}`)
    .catch(e => console.log("error", e));
  if (respose?.status < 400) {
    return respose;
  }
};
//
export const exportCsvFileAPI = async ({ file, format, delimiter }) => {
  const formData = new FormData();
  formData.append("product", file);
  if (format) {
    formData.append("format", format);
  }
  if (delimiter) {
    formData.append("delimiter", delimiter);
  }
  const res = await axios.post(`/api/products/upload/csv`, formData, {
    headers: {
      "Content-Type": "multipart/form-data"
    }
  });
  if (res?.status < 400) {
    return res.data;
  }
};

export const getTemplateChannelType = async ({ channelType }) => {
  const respose = await axios
    .get(`/api/channels/templates/${channelType}`)
    .catch(e => console.log("error", e));
  if (respose?.status < 400) {
    return respose;
  }
};

export const postTemplateChannelTypeAPI = async ({
  channelType,
  channelId,
  templateType,
  templateId,
  ids
}) => {
  const respose = await axios
    .post(
      `/api/channels/${channelType}/${channelId}/${templateType}/${templateId}`,
      {
        listing_ids: ids
      }
    )
    .catch(e => console.log("error", e));
  if (respose?.status < 400) {
    return respose;
  }
};

export const getProductDetailInChannelAPI = async ({
  channelID,
  productId
  // status,
}) => {
  const api = `/api/channel/${channelID}/products/${productId}`;
  const respose = await axios.get(api);
  if (respose?.status < 400) {
    return respose;
  }
};

export const getProductListingDetailInChannelAPI = async ({
  channelID,
  productId
}) => {
  const api = `/api/channel/${channelID}/products/${productId}`;
  const request = await axios.get(api);
  if (request?.status < 400) {
    return request;
  }
};

export const deleteProductDetailInChannelAPI = async ({
  channelID,
  productId
  // status,
}) => {
  const api = `/api/channel/${channelID}/products/${productId}`;
  const respose = await axios.delete(api).catch(e => console.log("error", e));
  if (respose?.status) {
    return respose;
  }
};

export const editProductDetailInChannelAPI = async ({
  channelID,
  productId,
  product,
  templateData,
  saveAndPublish,
  status
}) => {
  const request = await axios.put(
    `/api/channel/${channelID}/products/${productId}`,
    {
      product_info: product,
      template_data: templateData
    }
  );

  if (saveAndPublish && request.status < 400) {
    status === "active"
      ? await axios.put(
          `/api/channel/${channelID}/products/${productId}/push`,
          {
            product_info: product,
            template_data: templateData
          }
        )
      : await axios.post(`/api/channel/${channelID}/products/listing/publish`, {
          product_ids: [productId]
        });
  }
};

export const deleteAllProductsChannelAPI = async ({ channelId }) => {
  await axios.delete(`/api/channel/${channelId}/products`);
};

export const deleteSomeProductsChannelAPI = async ({ channelId, ids }) => {
  await axios.post(`/api/channel/${channelId}/products/bulk_delete`, {
    product_ids: ids
  });
};

export const activeProducts = async ({ body }) => {
  const data = await axios.put(`/api/products/bulk_active`, body);
  if (data) {
    return data?.data;
  }
};

export const getWarehousesLocations = async () => {
  const data = await axios.get(`api/warehouses`);
  if (data?.data) {
    return data?.data;
  }
};

export const getChannelDetail = async ({ channelId }) => {
  const data = await axios.get(`/api/channels/${channelId}/state`);
  if (data?.data) {
    return data?.data;
  }
};

export const postChannel = async ({ channelId, body }) => {
  const data = await axios.post(`/api/channels/${channelId}/setting`, body);
  if (data) {
    return data;
  }
};

export const verifyConnection = async ({ channelId }) => {
  const data = await axios.get(`api/channel/verify_connection/${channelId}`);
  if (data?.data) {
    return data?.data;
  }
};

export const postMerchantBigcommerceAPI = async ({ body, cartType }) => {
  const res = await axios.post(`/merchant/${cartType}/load`, body);
  return res;
};

export const postMerchantAPICallback = async ({ body, cartType }) => {
  const res = await axios.post(`/merchant/${cartType}/callback`, body);
  return res;
};

export const getMerchantBonanzaCallback = async ({ body, cartType }) => {
  const res = await axios.get(`/merchant/${cartType}/callback`, body);
  return res;
};

export const postMerchantWooCommerceAPI = async ({ body, cartType }) => {
  const res = await axios.post(`/merchant/${cartType}/install`, body);
  return res;
};

export const getFeedCsvAPI = async ({ channel_id }) => {
  const response = await axios.get(`api/channels/${channel_id}/feeds`);
  return response;
};

export const syncFromWooCommerce = async ({ channelID, publish_id }) => {
  const res = await axios.put(
    `/api/channel/${channelID}/products/${publish_id}/refresh`
  );
  if (res.status < 400) {
    return res;
  }
};

export const findProduct = async ({ product, channelId, publish_id, page }) => {
  const res = await axios.get(
    `/api/channel/${channelId}/products/${publish_id}/link/search?query=${encodeURIComponent(
      product
    )}&pages=${page}`
  );
  if (res.status < 400) {
    return res.data;
  }
};

export const findProductWithOption = async ({
  product,
  channelId,
  publish_id,
  page,
  body
}) => {
  const res = await axios.post(
    `/api/channel/${channelId}/products/${publish_id}/link/search?pages=${page}`,
    body
  );
  if (res.status < 400) {
    return res.data;
  }
};

export const unLinkProducts = async ({ channel_id, body }) => {
  const request = await axios.delete(
    `/api/channel/${channel_id}/products/unlink_product`,
    { data: body }
  );
  if (request.status < 400) {
    return request;
  }
};

export const createProduct = async ({ channel_id, product_id }) => {
  const request = await axios.post(
    `/api/channel/${channel_id}/products/link_product`,
    { listing_id: product_id, product_id: product_id }
  );
  if (request.status < 400) {
    return request;
  }
};

export const renewListing = async ({ channel_id, product_ids, action }) => {
  const request = await axios.put(`api/channels/${channel_id}/mass-action`, {
    product_ids: product_ids,
    action: action
  });
  if (request.status < 400) {
    return request;
  }
};

export const selectProductAfterFined = async ({ channelID, body }) => {
  const res = await axios.post(
    `/api/channel/${channelID}/products/link_product`,
    body
  );
  if (res?.status < 400) {
    return res;
  }
};

export const findEbayEPid = async ({ channel_id, item, product_id }) => {
  const res = await axios.post(
    `merchant/ebay/${channel_id}/epid/search/${product_id}`,
    {
      query: item
    }
  );
  if (res?.status < 400) {
    return res;
  }
};

export const applyItemEPId = async ({ channel_id, epid, product_id }) => {
  const res = await axios.post(`merchant/ebay/${channel_id}/epid/assign`, {
    epid: epid,
    product_id: product_id
  });
  if (res?.status < 400) {
    return res;
  }
};

//search category id for ebay, fb, gg
export const getCategoryId = async ({ isGGFace, category_name }) => {
  const res = await axios.get(
    isGGFace
      ? `/merchant/facebook/google_product_category?category_id=&name=${encodeURIComponent(
          category_name
        )}`
      : `/merchant/ebay/category/search?category_id=&name=${category_name}`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const autoUpdateSourceCart = async ({ isUpdate, channel_id }) => {
  const request = await axios.post(
    `api/channels/${channel_id}/${
      isUpdate ? "enable-refresh" : "disable-refresh"
    }`
  );
  if (request?.status < 400) {
    return request;
  }
};

export const autoImportToLitC = async ({ isUpdate, channel_id }) => {
  const request = await axios.post(
    `api/channels/${channel_id}/${
      isUpdate ? "enable-autoimport" : "disable-autoimport"
    }`
  );
  if (request?.status < 400) {
    return request;
  }
};

export const syncFromChannel = async ({ productList = [], channelId }) => {
  const body = {
    product_ids: productList
  };
  const request = await axios.post(
    `api/channel/${channelId}/products/refresh`,
    body
  );
  if (request) {
    return request;
  }
};

export const getFacebookCatalog = async ({ channel_id }) => {
  const res = await axios.get(
    `merchant/facebook/${channel_id}/product-catalog`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const postExportVariant = async ({ channel_id, publish_id }) => {
  const res = await axios.post(
    `api/channel/${channel_id}/products/${publish_id}/export-variant`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const findOnBuyProduct = async ({ channel_id, query }) => {
  const data = {
    query: query
  };
  const res = await axios.post(
    `/merchant/onbuy/${channel_id}/find-product`,
    data
  );
  if (res?.status < 400) {
    return res;
  }
};

export const applyItemOnBuy = async ({ channel_id, product_id, opc }) => {
  const data = {
    opc: opc,
    product_id: product_id
  };
  const res = await axios.post(
    `/merchant/onbuy/${channel_id}/assign-product`,
    data
  );
  if (res?.status < 400) {
    return res;
  }
};

export const getFeatureCategory = async ({ channel_id, category_id }) => {
  const res = await axios.get(
    `/merchant/onbuy/${channel_id}/feature-category?category_id=${category_id}`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const reverbCheckListing = async ({ channel_id, listing_id }) => {
  const res = await axios.get(
    `/merchant/reverb/${channel_id}/check-listing?listing_id=${listing_id}`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const matchDraftProductCa = async ({ channel_id, body }) => {
  const res = await axios.post(
    `/api/channel/${channel_id}/products/sync_from_mainstore`,
    body
  );
  if (res?.status < 400) {
    return res;
  }
};

export const getShopifyLocation = async ({ channelID }) => {
  const res = await axios.get(`merchant/shopify/${channelID}/locations`);

  if (res?.status < 400) {
    return res;
  }
};

export const getEtsyFileUpload = async ({ channelID }) => {
  const res = await axios.get(`/merchant/etsy/${channelID}/get-files-upload`);

  if (res?.status < 400) {
    return res;
  }
};

export const getEtsyFileUploadListing = async ({ channelID, listing_id }) => {
  const res = await axios.get(
    `/merchant/etsy/${channelID}/get-files-upload/${listing_id}`
  );

  if (res?.status < 400) {
    return res?.data;
  }
};

export const uploadEtsyDigitalFile = async ({ file }) => {
  const formData = new FormData();
  formData.append("product", file);

  const res = await axios.post(`api/products/upload/file`, formData, {
    headers: {
      "Content-Type": "multipart/form-data"
    }
  });

  if (res?.status < 400) {
    return res?.data;
  }
};

export const deleteEtsyDigitalFile = async ({
  channelID,
  productId,
  fileId
}) => {
  const res = await axios.get(
    `merchant/etsy/${channelID}/delete-file-upload/${productId}/${fileId}`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const loadFromMainApi = async ({ body }) => {
  const res = await axios.post(`api/products/reload`, body);

  if (res?.status < 400) {
    return res;
  }
};

export const editAttributeNameAPI = async ({
  body,
  channel_id,
  product_id
}) => {
  const request = await axios.put(
    `api/channel/${channel_id}/products/${product_id}/variant-attribute-name`,
    body
  );

  if (request?.status < 400) {
    return request;
  }
};

export const checkReverbOldConnection = async ({ channelID }) => {
  const res = await axios.get(`merchant/reverb/${channelID}/check-connect`);
  if (res?.status < 400) {
    return res;
  }
};

export const getWalmartTimerApi = async ({ channelId }) => {
  const res = await axios.get(
    `/merchant/walmart/${channelId}/timestamp-publish`
  );
  if (res?.status < 400) {
    return res;
  }
};

export const channelTiktokSetUp = async ({ channelType, data }) => {
  const response = await axios.post(
    `merchant/${channelType}/tiktok-connect`,
    data
  );
  if (response?.status < 400) {
    return response.data;
  }
};

export const channelTiktokRecommend = async ({ channelID, data }) => {
  if (!data) {
    return;
  }
  const body = { product_name: data };
  const response = await axios.post(
    `/merchant/tiktok/${channelID}/category-recommend`,
    body
  );
  if (response?.status < 400) {
    return response.data;
  }
};

export const channelListingDelete = async ({ channelID, tab }) => {
  if (!tab || ![DRAFT_VALUE, ERROR_VALUE].includes(tab)) {
    return;
  }
  const response = await axios.delete(
    `api/channel/${channelID}/products/${tab}`
  );
  if (response?.status < 400) {
    return response.data;
  }
};

export const channelRefreshImage = payload =>
  axios.post(`api/channel/${payload.channel_id}/products/refresh-images`, {
    product_ids: payload.product_ids
  });
