import axios from 'src/utils/axios';

export const changeLogService = {
   get: {
      getChangelog: payload =>
         axios.get(`api/activities/notification/product-changed`, {
            params: { ...payload }
         })
   }
};
