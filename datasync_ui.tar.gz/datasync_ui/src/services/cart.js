import axios from "src/utils/axios";

export const getCartDetailAPI = async ({ cartId }) => {
  const respose = await axios
    .get(`/api/carts/${cartId}`)
		.catch((e) => console.log("error", e));
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }

  return;
};
