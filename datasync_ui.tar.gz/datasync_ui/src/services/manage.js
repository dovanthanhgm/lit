import axios from "src/utils/axios";

export const getAllActivitiesAPI = async () => {
  const res = await axios
    .get("/api/activities")
    .catch(e => console.log("error", e));
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

export const getListWarehouseAPi = async () => {
  const res = await axios
    .get("/api/warehouses")
    .catch(e => console.log("error", e));
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

export const addWarehouseAPI = async ({ warehouse }) => {
  const res = await axios.post("/api/warehouses", warehouse).catch(error => {
    // throw e;
    console.log("error", error.message);
  });
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

export const editWarehouseAPI = async ({ warehouse }) => {
  const res = await axios
    .put(`/api/warehouses/${warehouse.id}`, warehouse)
    .catch(error => {
      // throw e;
      console.log("error", error.message);
    });
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

export const deleteWarehouseAPI = async ({ warehouseId }) => {
  await axios.delete(`/api/warehouses/${warehouseId}`);
};

export const getListInventoriesAPI = async ({
  limit,
  page,
  query,
  condition,
  location,
  min_available,
  max_available,
  min_reserved,
  max_reserved,
  min_on_hand,
  max_on_hand
}) => {
  let api = `/api/inventories?limit=${limit}&page=${page + 1}`;
  const newProps = {
    query,
    condition,
    location,
    min_available,
    max_available,
    min_reserved,
    max_reserved,
    min_on_hand,
    max_on_hand
  };
  Object.keys(newProps).forEach(key => {
    if (newProps[key]) {
      api += `&${key}=${newProps[key]}`;
    }
  });

  const res = await axios.get(api).catch(e => console.log("error", e));
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

//import - export data
export const importProduct = async ({ file, name }) => {
  const formData = new FormData();
  formData.append([name], file);
  try {
    const res = await axios.post("api/products/import/csv", formData, {
      headers: {
        "Content-Type": "multipart/form-data"
      }
    });
    if (res?.status < 400) {
      return res;
    }
  } catch (error) {
    return error.response;
  }
};

//import Inventory
export const importInventory = async ({
  file,
  name,
  location_id,
  import_type
}) => {
  const inventory = new FormData();
  inventory.append([name], file);
  inventory.append("location_id", location_id);
  inventory.append("import_type", import_type);
  try {
    const res = await axios.post("/api/inventories/import/csv", inventory, {
      headers: {
        "Content-Type": "multipart/form-data"
      }
    });
    if (res?.status < 400) {
      return res;
    }
  } catch (error) {
    return error.response;
  }
};

export const importChannel = async ({ channel_id, body }) => {
  return await axios.post(`api/channel/pull/${channel_id}`, body);
};

export const exportProduct = async ({ body }) => {
  const res = await axios
    .post(`api/products/export/csv`, body)
    .catch(error => console.log("error", error));
  if (res?.status < 400) {
    return res.status;
  }

  return;
};

export const exportOrders = async ({ body }) => {
  const res = await axios
    .post(`/api/orders/downloads`, body)
    .catch(error => console.log("error", error));
  if (res?.status < 400) {
    return res.status;
  }

  return;
};

export const exportInventory = async ({ body }) => {
  const res = await axios
    .post(`/api/inventories/export/csv`, body)
    .catch(error => console.log("error", error));
  if (res?.status < 400) {
    return res.status;
  }
};

export const getSubscriptionAPI = async () => {
  const res = await axios.get(`api/subscription`);
  if (res.status < 400) {
    return res;
  }
};

export const getSubscriptionPaymentAPI = async ({
  plan_id,
  body,
  isPaymentInStep3
}) => {
  let api = `api/subscription/me/select/${plan_id}`;
  if (isPaymentInStep3) {
    api += "?first-setup=1";
  }
  const data = await axios.post(api, body);
  if (data?.data) return data?.data;
};

export const merchantSubscriptionPaymentAPI = async ({
  body,
  isPaymentInStep3
}) => {
  let api = `api/payments/pickup-plan`;
  if (isPaymentInStep3) {
    api += "?first-setup=1";
  }
  const data = await axios.post(api, body);
  if (data?.data) return data?.data;
};

export const getPaymentHistory = async ({ page, limit }) => {
  const res = await axios.get(
    `api/payments/history?page=${page}&limit=${limit}`
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getPaymentHistoryId = async ({ payment_id }) => {
  const res = await axios.get(`api/payments/history/${payment_id}`);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getOrderList = async ({ limit, page }) => {
  const res = await axios.get(
    `api/litcommerce-order?page=${page}&limit=${limit}`
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const discountApply = async ({ body }) => {
  const res = await axios.post(`/api/coupons/apply`, body);
  if (res.status < 400) {
    return res.data;
  }
};

export const getMagentoStore = async ({ channel_default_id }) => {
  const request = await axios.get(
    `merchant/magento/${channel_default_id}/stores`
  );
  if (request.status < 400) {
    return request;
  }
};

export const handleUpdatePlanForAutoRenew = async ({ plan_id }) => {
  const request = await axios.post(
    `api/payments/paypal/subscription/upgrade/${plan_id}`
  );
  if (request.status < 400) {
    return request;
  }
};

export const bigImportSearchCategories = async ({ category, channelID }) => {
  const request = await axios.get(
    `/merchant/bigcommerce/${channelID}/categories/${category}`
  );
  if (request.status < 400) {
    return request.data;
  }
};

export const bigImportSearchBrand = async ({ brand, channelID }) => {
  const request = await axios.get(
    `/merchant/bigcommerce/${channelID}/brands/${brand}`
  );
  if (request.status < 400) {
    return request.data;
  }
};

export const wooImportSearchTags = async ({ channelID }) => {
  const request = await axios.get(`/merchant/woocommerce/${channelID}/tags`);
  if (request.status < 400) {
    return request.data;
  }
};
