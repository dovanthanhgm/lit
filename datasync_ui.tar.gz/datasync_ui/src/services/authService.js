import jwtDecode from "jwt-decode";
import axios from "src/utils/axios";
import Cookies from "universal-cookie";
import { handleResetChatSession } from "src/utils/ScrispChat";
import { deleteAllCookies } from "../constants";
import moment from "moment";
import { Crisp } from "crisp-sdk-web";

const cookies = new Cookies();
const currentHostname =
  window.location.hostname === "localhost" ? "localhost" : ".litcommerce.com";

const whiteList = {
  "/merchant/shopify": {
    method: "post",
    errorField: "errors"
  }
};

class AuthService {
  setAxiosInterceptors = ({ onLogout, enqueueSnackbar, history }) => {
    axios.interceptors.response.use(
      response => response,
      error => {
        if (error.response?.status === 401) {
          const accessToken = cookies.get("accessToken");
          const newAccessToken = `JWT ${accessToken}`;
          const oldAccessToken = axios.defaults.headers.common.Authorization;

          if (accessToken && newAccessToken !== oldAccessToken) {
            window.location.reload();
          } else {
            if (this.isAuthenticated()) {
              localStorage.removeItem("loginPostMerchant");
              localStorage.removeItem("loginWix");
              this.setSession(null);

              if (onLogout) {
                onLogout();
              }

              return;
            }
          }
        }

        const method = error.response?.config?.method;
        const url = error.response?.config?.url;
        const objectFail = whiteList[url];

        if (objectFail?.method === method) {
          const message =
            error.response?.data?.[objectFail.errorField || "message"] ||
            error.message ||
            "Something went wrong";
          enqueueSnackbar(message, {
            variant: "error"
          });
        }

        return Promise.reject(error);
      }
    );
  };

  handleAuthentication() {
    const accessToken = this.getAccessToken();
    if (!accessToken) {
      return;
    }

    if (this.isValidToken(accessToken)) {
      try {
        const permissionToken = this.getPermissionToken();
        const selfToken = this.getSelfToken();
        if (selfToken) {
          this.setSession(accessToken, null, null, permissionToken, selfToken);
        } else {
          this.setSession(accessToken);
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      localStorage.removeItem("loginPostMerchant");
      localStorage.removeItem("loginWix");
      this.setSession(null);
    }
  }

  loginWithEmailAndPassword = (email, password) =>
    new Promise((resolve, reject) => {
      axios
        .post(`/api/login/`, {
          email,
          password
        })
        .then(response => {
          if (response?.data?.user) {
            if (response?.data?.selfToken) {
              if (response.data.permissions) {
                this.setSession(
                  response.data.access,
                  null,
                  response.data.refresh,
                  response.data.permissions,
                  response.data.selfToken
                );
              } else {
                this.setSession(
                  response.data.access,
                  null,
                  response.data.refresh,
                  null,
                  response.data.selfToken
                );
              }
            } else {
              this.setSession(
                response.data.access,
                null,
                response.data.refresh
              );
            }
            resolve(response.data.user);
          } else {
            reject(response?.data?.error);
          }
        })
        .catch(error => {
          reject(error.response);
        });
    });

  loginInWithToken = () =>
    new Promise((resolve, reject) => {
      axios
        .get(`/api/accounts/me`, { params: { time: moment().unix() } })
        .then(response => {
          if (response?.data) {
            resolve({
              userId: response.data.id,
              ...response.data
            });
          } else {
            reject(response?.data?.error);
          }
        })
        .catch(error => {
          reject(error);
        });
    });

  logout = async notSendAPI => {
    if (!notSendAPI) {
      const refresh_token = this.getRefreshToken();
      await axios.post("/api/accounts/logout", {
        refresh_token
      });
    }
    localStorage.clear();
    this.setSession(null);
    Crisp.session.reset();
    deleteAllCookies();
    handleResetChatSession();
  };

  clearCookieKeepLocalStorage = () => {
    cookies.remove("accessToken", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("refreshToken", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("loginByToken", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("hideCrisp", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("permissionsToken", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("loginByAdmin", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("selfToken", {
      domain: currentHostname,
      path: "/"
    });
    delete axios.defaults.headers.common["SelfToken"];
    delete axios.defaults.headers.common["Permission"];
    delete axios.defaults.headers.common.Authorization;
  };

  setSession = (
    accessToken,
    loginByToken,
    refreshToken,
    permissionsToken,
    selfToken,
    loginByAdmin,
    hideCrisp
  ) => {
    const date = new Date();
    date.setDate(date.getDate() + 30);
    if (accessToken) {
      cookies.set("accessToken", accessToken, {
        domain: currentHostname,
        expires: date,
        path: "/"
      });
      refreshToken &&
        cookies.set("refreshToken", refreshToken, {
          domain: currentHostname,
          expires: date,
          path: "/"
        });
      if (loginByToken) {
        cookies.set("loginByToken", loginByToken, {
          domain: currentHostname,
          expires: date,
          path: "/"
        });
      }
      if (loginByAdmin) {
        cookies.set("loginByAdmin", loginByAdmin, {
          domain: currentHostname,
          expires: date,
          path: "/"
        });
      }
      if (hideCrisp) {
        cookies.set("hideCrisp", hideCrisp, {
          domain: currentHostname,
          expires: date,
          path: "/"
        });
      }
      if (selfToken) {
        cookies.set("selfToken", selfToken, {
          domain: currentHostname,
          expires: date,
          path: "/"
        });
        axios.defaults.headers.common["SelfToken"] = selfToken;
      }
      if (permissionsToken) {
        cookies.set("permissionsToken", permissionsToken, {
          domain: currentHostname,
          expires: date,
          path: "/"
        });
        axios.defaults.headers.common["Permission"] = permissionsToken;
      }
      axios.defaults.headers.common.Authorization = `JWT ${accessToken}`;
    } else {
      this.clearCookieKeepLocalStorage();
    }
  };

  getAccessToken = () => cookies.get("accessToken");

  getPermissionToken = () => {
    try {
      return cookies.get("permissionsToken");
    } catch (e) {
      console.log(e);
    }
  };

  getSelfToken = () => {
    try {
      return cookies.get("selfToken");
    } catch (e) {
      console.log(e);
    }
  };

  getLoginByToken = () => cookies.get("loginByToken");
  getLoginByAdmin = () => cookies.get("loginByAdmin");
  getHideCrisp = () => cookies.get("hideCrisp");

  getRefreshToken = () => cookies.get("refreshToken");

  isValidToken = accessToken => {
    if (!accessToken) {
      return false;
    }

    const decoded = jwtDecode(accessToken);
    const currentTime = Date.now() / 1000;

    return decoded.exp > currentTime;
  };

  isAuthenticated = () => !!this.getAccessToken();

  register = values =>
    new Promise((resolve, reject) => {
      axios
        .post(`/api/accounts/signup`, values)
        .then(response => {
          if (response.data) {
            resolve(response.data);
          } else {
            reject(response.data.error);
          }
        })
        .catch(error => {
          reject(error.response.data);
        });
    });

  updateProfile = values =>
    new Promise((resolve, reject) => {
      axios
        .put("/api/accounts/change-info", values)
        .then(response => {
          if (response.data) {
            resolve(response.data);
          } else {
            reject(response.data.error);
          }
        })
        .catch(error => {
          reject(error.response.data);
        });
    });

  changePassword = values =>
    new Promise((resolve, reject) => {
      const newValues = {
        old_password: values.oldPassword,
        new_password: values.newPassword
      };
      axios
        .put(`/api/accounts/password`, newValues)
        .then(response => {
          resolve(true);
          if (response.data) {
            resolve(true);
          } else {
            reject("error");
          }
        })
        .catch(error => {
          reject(error);
        });
    });

  forgotPassword = ({ email }) =>
    new Promise((resolve, reject) => {
      axios
        .post(`/api/accounts/forgot-password`, { email })
        .then(response => {
          if (response.data) {
            resolve(response.data);
          } else {
            reject(response.data.error);
          }
        })
        .catch(error => {
          reject(error.response.data);
        });
    });

  resetPassword = ({ body }) =>
    new Promise((resolve, reject) => {
      axios
        .post(`/api/accounts/reset-password`, body)
        .then(response => {
          if (response.data) {
            resolve(response.data);
          } else {
            reject(response.data.error);
          }
        })
        .catch(error => {
          reject(error.response.data);
        });
    });

  resendEmail = ({ body }) =>
    new Promise((resolve, reject) => {
      axios
        .post(`api/accounts/resend-register`, body)
        .then(response => {
          if (response.data) {
            resolve(response.data);
          } else {
            reject("error");
          }
        })
        .catch(error => {
          reject(error.response);
        });
    });

  registerEmail = ({ body }) =>
    new Promise((resolve, reject) => {
      axios
        .post(`api/accounts/register`, body)
        .then(response => {
          if (response.data) {
            resolve(response.data);
          } else {
            reject(response.data.error);
          }
        })
        .catch(error => {
          reject(error.response);
        });
    });
}

const authService = new AuthService();

export default authService;
