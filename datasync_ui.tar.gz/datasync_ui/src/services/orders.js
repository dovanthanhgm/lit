import axios from "src/utils/axios";

const apiQuery = props => {
  let query = "";
  if (!props) return;
  Object.keys(props).forEach(item => {
    if (!!props[item] && item !== "status") {
      query += `&${item}=${props[item]}`;
    }
  });
  return encodeURI(query);
};

// const apiQueryFilter = props => {
//   let query = "";
//   if (!props) return;
//   Object.keys(props).forEach(item => {
//     if (![null, undefined].includes(props[item])) {
//       query += `&${item}=${props[item]}`;
//     }
//   });
//   return encodeURI(query);
// };

// const apiQueryNoStatus = props => {
//   let query = "";
//   if (!props) return;
//   let indexCount = 0;
//   Object.keys(props).forEach(item => {
//     if (!!props[item] && item !== "status") {
//       query += `${indexCount ? "&" : "?"}${item}=${props[item]}`;
//       indexCount += 1;
//     }
//   });
//   return encodeURI(query);
// };

export const getOrders = async ({ params }) => {
  const { status } = params;
  let api =
    status === "unlink"
      ? `api/orders?link_status=${status}`
      : `api/orders?status=${status}`;
  api += apiQuery(params);
  const data = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const getOrdersTable = async ({ params, extraParams }) => {
  let api = `api/orders`;
  const limit = extraParams?.limit || 25;
  const page = extraParams?.page || 1;
  const defaultApi = `limit=${limit}&page=${page}`;
  if (params) {
    api += params + "&" + defaultApi;
  } else {
    api = api + "?" + defaultApi;
  }

  const data = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const getOrdersRefundWalmart = async ({ params, extraParams }) => {
  const dataExtra = extraParams?.walmartData;
  const querys = "?" + dataExtra?.paramsWalmart;
  let api = `/merchant/walmart/${dataExtra?.channelID}/order-refund`;
  api += querys;
  const data = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const updateShipsFrom = async ({ order_id, body }) => {
  const res = await axios.put(`api/orders/${order_id}/inventories`, body);
  if (res?.status < 400) {
    return res;
  }
};

export const getOrderDetail = async ({ order_id }) => {
  const data = await axios.get(`api/orders/${order_id}`);
  if (data?.data) {
    return data.data;
  }
};

export const putNotes = async ({ params }) => {
  const { order_id, history_id, comment } = params;
  const data = await axios.put(`api/orders/${order_id}/history/${history_id}`, {
    comment
  });
  if (data?.data) {
    return data.data;
  }
};

export const deleteNotes = async ({ params }) => {
  const { order_id, history_id } = params;
  const data = await axios.delete(
    `api/orders/${order_id}/history/${history_id}`
  );

  if (data) {
    return data.status;
  }
};

export const createNotes = async ({ params }) => {
  const { order_id, comment } = params;
  const data = await axios.post(`api/orders/${order_id}/history`, {
    comment
  });
  if (data?.data) {
    return data.data;
  }
};

export const sendToFBA = async ({ order_id, body }) => {
  const res = await axios.post(`api/orders/${order_id}/shipments/fba`, body);
  if (res?.data && res.status < 400) {
    return res;
  }
};

export const getOrderCount = async ({ params }) => {
  let api = "/api/orders/count";
  if (params) {
    api += params;
  }
  const res = await axios.get(api);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getOrderTableCount = async ({ params }) => {
  let api = "/api/orders/count";
  if (params) {
    api += params;
  }
  const res = await axios.get(api);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const importOrderToSource = async ({ order_ids }) => {
  const res = await axios.put(`/api/orders`, {
    order_ids
  });
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const deleteAllOrders = async () => {
  const res = await axios.delete(`/api/orders`);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const updateOrderUnlinkTab = async ({ order_ids }) => {
  const res = await axios.put(`/api/orders`, {
    order_ids
  });
  if (res?.status < 400) {
    return res;
  }
};

export const syncOrderDetail = async ({ order_ids }) => {
  const res = await axios.put(`/api/orders/${order_ids}/sync-status`);
  if (res.status < 400) {
    return res;
  }
};

export const placeOrder = async ({ amount, note }) => {
  const res = await axios.post(`/api/buy-service/custom`, {
    amount: amount,
    note: note
  });
  if (res.status < 400) {
    return res;
  }
};

export const processedOrder = async ({ order_ids = [] }) => {
  const res = await axios.post(`api/orders/processed-in-channel`, {
    order_ids
  });
  if (res.status < 400) {
    return res;
  }
};

export const getOrderProductDetail = async ({ product_ids = [] }) => {
  const res = await axios.post(`api/products/list`, {
    product_ids
  });
  if (res.status < 400) {
    return res.data;
  }
};

export const orderProductRefund = async ({
  channel_id,
  order_number,
  order_id
}) => {
  const body = {
    order_number,
    order_id
  };
  const res = await axios.post(
    `merchant/walmart/${channel_id}/order-refund`,
    body
  );
  if (res.status < 400) {
    return res.data;
  }
};

export const cancelOrderProduct = async ({ channel_id, body }) => {
  if (!body) {
    return;
  }
  const request = await axios.post(
    `merchant/walmart/${channel_id}/order-cancel`,
    body
  );
  if (request?.status < 400) {
    return request;
  }
};

export const confirmOrderAPI = async ({
  channel_id,
  order_number,
  order_id,
  is_all = false
}) => {
  const body = {
    order_number: order_number,
    order_id_walmart: order_id,
    is_all
  };
  const request = await axios.post(
    `merchant/walmart/${channel_id}/order-acknowledge`,
    body
  );
  if (request?.status < 400) {
    return request;
  }
};

export const updateOrderAPI = async ({
  channel_id,
  order_number,
  order_id,
  order_line,
  is_all = false
}) => {
  const body = {
    order_number: order_number,
    order_id_walmart: order_id,
    order_line: order_line,
    is_all
  };
  const request = await axios.post(
    `merchant/walmart/${channel_id}/order-ship`,
    body
  );
  if (request?.status < 400) {
    return request;
  }
};
