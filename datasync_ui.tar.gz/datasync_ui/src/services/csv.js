import axios from "src/utils/axios";

export const deleteFeed = async ({ channel_id, feed_id }) => {
  const res = await axios.delete(`api/channels/${channel_id}/feeds/${feed_id}`);
  if (res.status < 400) {
    return res;
  }
};

export const startProgressFeed = async ({ body, channel_id, feed_id }) => {
  const res = await axios.post(
    `api/channels/${channel_id}/feeds/${feed_id}/start-process`,
    body
  );
  if (res.status < 400) {
    return res;
  }
};

export const scheduleStatus = async ({ channel_id, feed_id, status, body }) => {
  const scheduleStatus = () => {
    if (status) {
      return "enable-scheduler";
    }
    return "disable-scheduler";
  };

  const res = await axios.post(
    `api/channels/${channel_id}/feeds/${feed_id}/${scheduleStatus()}`,
    body
  );
  if (res.status < 400) {
    return res;
  }
};
