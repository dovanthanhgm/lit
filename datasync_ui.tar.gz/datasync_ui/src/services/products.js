import axios from "src/utils/axios";
import { ProductTableSortAPI } from "../constants/TableSortAPI";

export const getAllProductsService = async ({
  limit,
  search,
  sort,
  prdTab,
  colName
}) => {
  let newSearch = search || "?page=1";
  const api = `/api/products${newSearch}&limit=${limit}&tab=${prdTab}`;
  //need clean
  const filterApi = () => {
    if (sort) {
      return api + ProductTableSortAPI[colName][sort];
    }
    return api;
  };

  const { data } = await axios.get(filterApi());

  if (data?.data) {
    return data;
  }
};

export const getAllProductsData = async ({
  limit,
  search,
  sort,
  prdTab,
  page = 1
}) => {
  let newSearch = () => {
    if (search) {
      return search + "&";
    }
    return "?";
  };
  const api = `/api/products${newSearch()}limit=${limit}&page=${page}&tab=${prdTab}`;
  //need clean
  const filterApi = () => {
    if (sort) {
      return api + sort;
    }
    return api;
  };
  const { data } = await axios.get(filterApi());

  if (data?.data) {
    return data;
  }
};

export const searchProductByName = async ({
  name,
  sku,
  minPrice,
  maxPrice,
  minQty,
  maxQty
}) => {
  let api = `/api/products?limit=${50}&page=${1}`;
  const newProps = {
    title: name,
    sku,
    min_price: minPrice,
    max_price: maxPrice,
    min_qty: minQty,
    max_qty: maxQty
  };
  Object.keys(newProps).forEach(key => {
    if (newProps[key]) {
      api += `&${key}=${newProps[key]}`;
    }
  });
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const getCountAllProductsService = async ({ search }) => {
  let api = "/api/products/count";
  if (!!search) {
    api = `/api/products/count${search}`;
  }

  const { data } = await axios.get(api);
  if (data) {
    return data;
  }
};

export const sendProductsToChannel = async ({
  channelID,
  selectedProducts
}) => {
  const res = await axios.post(`/api/channel/${channelID}/products/listing`, {
    product_ids: selectedProducts,
    src_channel_id: channelID
  });
  if (res) {
    return res;
  }
};

export const createProductsMarketChannel = async ({
  channelID,
  selectedProducts,
  defaultId
}) => {
  const res = await axios.post(`/api/channel/${defaultId}/products/listing`, {
    product_ids: selectedProducts,
    src_channel_id: channelID
  });
  if (res) {
    return res;
  }
};

export const createProductOnChannel = async ({
  channelID,
  defaultChannelId,
  squareStoreId,
  selectedProducts
}) => {
  const data = {
    product_ids: selectedProducts,
    src_channel_id: channelID
  };

  if (squareStoreId) {
    data.store_page_id = squareStoreId;
  }

  const res = await axios
    .post(`/api/channel/${defaultChannelId}/products/listing`, data)
    .catch(e => {
      console.log("error", e);
    });
  if (res) {
    return res.data;
  }
};

export const getProductDetailsAPI = async ({ productId, variantId }) => {
  const api = variantId
    ? `/api/products/${productId}/variants/${variantId}`
    : `/api/products/${productId}`;
  const res = await axios.get(api);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getProductDetailVariantsAPI = async ({
  productId,
  page = 1,
  rowsPerPage = 25
}) => {
  const res = await axios.get(
    `/api/products/${productId}/variants?page=${page}&limit=${rowsPerPage}`
  );
  // if (res?.status < 400 && res.data) {
  return res.data;
  // }
};

export const postProductDetailVariantsAPI = async ({ productId, body }) => {
  const res = await axios.post(`/api/products/${productId}/variants`, body);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const deleteProductDetailVariantsAPI = async ({
  productId,
  variantId
}) => {
  await axios.delete(`/api/products/${productId}/variants/${variantId}`);
};

export const editProductDetailsAPI = async ({
  productId,
  product,
  variantId
}) => {
  let api = `/api/products/${productId}`;
  api += variantId ? `/variants/${variantId}` : "";
  const res = await axios.put(api, product);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const editProductDetailVariantsAPI = async ({
  productId,
  variants,
  channel_id
}) => {
  const res = await axios.put(
    `/api/channel/${channel_id}/products/${productId}/variants`,
    {
      variants
    }
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const uploadImageProductAPI = async ({ file, productId, variantId }) => {
  const formData = new FormData();
  formData.append("image", file);
  let api = `/api/products/`;
  api += variantId
    ? `${variantId}/images/upload`
    : `${productId}/images/upload`;
  const res = await axios.post(api, formData, {
    headers: {
      "Content-Type": "multipart/form-data"
    }
  });
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const importCsvFileAPI = async ({ file }) => {
  const formData = new FormData();
  formData.append("product", file);
  const res = await axios
    .post(`/api/products/import/csv`, formData, {
      headers: {
        "Content-Type": "multipart/form-data"
      }
    })
    .catch(e => {
      console.log("error", e);
    });
  if (res?.status < 400) {
    return res.data;
  }
};

export const uploadBulkApi = async ({ file }) => {
  const formData = new FormData();
  formData.append("product", file);
  const res = await axios.post(`/api/products/import/csv`, formData, {
    headers: {
      "Content-Type": "multipart/form-data"
    }
  });

  if (res?.status < 400) {
    return res.data;
  }
};

export const getBulkUpdateProcess = async ({ processId }) => {
  const res = await axios.get(`/api/processes/${processId}`);
  if (res?.status < 400) {
    return res.data;
  }
};

export const editProductDetailImagesAPI = async ({
  productId,
  variantId,
  images
}) => {
  let api = `/api/products/`;
  api += variantId ? `${variantId}/images` : `${productId}/images`;
  const res = await axios.put(api, { images });
  if (res?.status < 400) {
    return res;
  }
};

export const deleteAllProductsAPI = async () => {
  await axios.delete(`/api/products`);
};

export const deleteSomeProductsAPI = async ({ ids }) => {
  await axios.post(`/api/products/bulk_delete`, {
    product_ids: ids
  });
};

export const getAttributes = async () => {
  const res = await axios.get("/api/attributes");
  if (res?.status < 400 && res.data) {
    return res.data?.data;
  }
};

export const postAttribute = async ({ product_id, variantId, body }) => {
  let api = `/api/products/`;
  api += variantId ? `${variantId}/attributes` : `${product_id}/attributes`;
  const res = await axios.post(api, body);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const editProductDetailAttributesAPI = async ({
  productId,
  variantId,
  attributes
}) => {
  let api = `/api/products/`;
  api += variantId ? `${variantId}/attributes` : `${productId}/attributes`;
  const data = await axios.put(api, attributes);
  if (data) {
    return data?.data;
  }
};

export const postNewProduct = async body => {
  const res = await axios.post(`/api/products`, body);
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const updateInventories = async ({ product_id, variantId, body }) => {
  let api = `/api/products/`;
  api += variantId ? `${variantId}/inventories` : `${product_id}/inventories`;
  const data = await axios.put(api, body);
  if (data) {
    return data?.data;
  }
};

export const getInventories = async ({ product_id, variantId }) => {
  let api = `/api/products/`;
  api += variantId ? `${variantId}/inventories` : `${product_id}/inventories`;
  const data = await axios.get(api);
  if (data) {
    return data?.data;
  }
};

export const getCategoriesAmazon = async ({ channel_id }) => {
  const data = await axios.get(`merchant/amazon/${channel_id}/settings`);
  if (data) {
    return data?.data;
  }
};

export const searchASIN = async ({ channel_id, body }) => {
  const data = await axios.post(
    `merchant/amazon/${channel_id}/asin/search`,
    body
  );
  if (data) {
    return data?.data;
  }
};

export const chooseProductAmazon = async ({ channel_id, product_id, body }) => {
  const data = await axios.put(
    `api/channel/${channel_id}/products/${product_id}`,
    body
  );
  if (data) {
    return data?.data;
  }
};

export const handleChooseAmazonAsin = async ({ channel_id, body }) => {
  const data = await axios.post(
    `merchant/amazon/${channel_id}/asin/assign`,
    body
  );
  if (data) {
    return data;
  }
};

export const getASIN = async ({ channel_id, asin }) => {
  const data = await axios.get(`merchant/amazon/${channel_id}/asin/${asin}`);
  if (data) {
    return data?.data;
  }
};

export const filterProductInfoCategory = async ({ page, search }) => {
  const data = await axios.get(`api/categories?pages=${page}&search=${search}`);
  if (data) {
    return data?.data;
  }
};

export const getProductVariantListing = async ({ productId, channel_id }) => {
  const res = await axios.get(
    `/api/channel/${channel_id}/products/${productId}/variants?page=1&limit=25`
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getProductVariantListingPagination = async ({
  productId,
  channel_id,
  page,
  limit
}) => {
  const res = await axios.get(
    `/api/channel/${channel_id}/products/${productId}/variants?page=${page +
      1}&limit=${limit}`
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getCategoryNameOrId = async ({ isName, value }) => {
  const res = await axios.get(
    `/merchant/facebook/google_product_category?${
      isName ? "name" : "category_id"
    }=${value}`
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getOrderProducts = async ({
  publish_id,
  page = 1,
  limit = 20
}) => {
  const res = await axios.get(
    `api/products/${publish_id}/orders?page=${page}&limit=${limit}`
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const createProductsVariant = async ({
  channel_id,
  product_id,
  body,
  variant_id
}) => {
  const request = await axios.post(
    `/api/channel/${channel_id}/products/${product_id}/variants/${variant_id}`,
    body
  );

  if (request?.status < 400) {
    return request;
  }
};

export const productTypeFilter = async () => {
  const request = await axios.get(`/api/products/product-types`);

  if (request?.status < 400) {
    return request?.data;
  }
};

export const productBrandsFilter = async () => {
  const request = await axios.get(`/api/products/brands`);

  if (request?.status < 400) {
    return request?.data;
  }
};

export const productTagsFilter = async () => {
  const request = await axios.get(`/api/products/product-tags`);

  if (request?.status < 400) {
    return request?.data;
  }
};

export const selectAddChannel = async ({ body }) => {
  const request = await axios.post(`api/products/listings`, body);

  if (request?.status < 400) {
    return request?.data;
  }
};

export const selectRemoveChannel = async ({ body }) => {
  const request = await axios.post(`api/products/listings/remove`, body);

  if (request?.status < 400) {
    return request?.data;
  }
};
