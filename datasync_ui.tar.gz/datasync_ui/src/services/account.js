import axios from "src/utils/axios";

export const loginByToken = async ({ token }) => {
  const respose = await axios.post(`/api/accounts/login-by-token/${token}`);
  return respose;
};

export const completeAllStep = async () => {
  const res = await axios.post(`/api/accounts/success-firstsetup`);
  if (res.status < 400) {
    return res;
  }
};

export const getUserInfo = async () => {
  const res = await axios.get(`/api/accounts/me`);
  if (res.status < 400) {
    return res.data;
  }
};

export const refreshAccountApi = async () => {
  await axios.post(`api/accounts/refresh`);
};

export const hideGuideStater = async () => {
  return await axios.post("api/accounts/hide-guide");
};

export const closeSpecialModalAPI = async () => {
  return await axios.post("api/accounts/close-contact-popup");
};

export const deleteAccount = async ({ email }) => {
  const request = await axios.post("/api/accounts/close", {
    email
  });
  if (request.status < 400) {
    return request;
  }
};

export const closeAccountPath = async ({ token }) => {
  const request = await axios.get(`api/accounts/close/${token}`);
  if (request.status < 400) {
    return request;
  }
};

export const submitNewFeature = async ({ body }) => {
  const request = await axios.post(`api/feature-request`, body);
  if (request.status < 400) {
    return request;
  }
};

export const accountSkipStep2 = async () => {
  const request = await axios.post(`api/accounts/skip-setup-channel`, {});
  if (request.status < 400) {
    return request;
  }
};

export const accountSwitchChannel = async () => {
  const request = await axios.post(`api/accounts/switch-channel`, {});
  if (request.status < 400) {
    return request;
  }
};

export const accountCancelSubscription = async () => {
  const request = await axios.post(`api/accounts/cancel-subscription`, {});
  if (request.status < 400) {
    return request;
  }
};

export const sendContactIssue = async ({ body }) => {
  const request = await axios.post(`/api/accounts/contact-issue`, body);
  if (request.status < 400) {
    return request;
  }
};

export const addSubUser = async ({ body }) => {
  const request = await axios.post(`/api/accounts/sub-user-list`, body);
  if (request.status < 400) {
    return request;
  }
};

export const closeFeedback = async () => {
  const request = await axios.post(`/api/accounts/feedback-close`, {});
  if (request?.status < 400) {
    return request;
  }
};

export const getSubUserList = async () => {
  const request = await axios.get(`/api/accounts/sub-user-list`);
  if (request.status < 400) {
    return request;
  }
};

export const getSubUser = async ({ pk }) => {
  const request = await axios.get(`/api/accounts/sub-user/${pk}`);
  if (request.status < 400) {
    return request;
  }
};

export const updateSubUser = async ({ pk }, { body }) => {
  const request = await axios.patch(`/api/accounts/sub-user/${pk}`, body);
  if (request.status < 400) {
    return request;
  }
};

export const deleteSubUser = async ({ pk }) => {
  const request = await axios.delete(`/api/accounts/sub-user/${pk}`);
  return request;
};

export const AcceptInvitation = async ({ body }) => {
  const request = await axios.post(`/api/accounts/invitation`, body);
  if (request.status < 400) {
    return request;
  }
};

export const resendInvitation = async ({ body }) => {
  const request = await axios.post(`/api/accounts/resend-invitation`, body);
  if (request.status < 400) {
    return request;
  }
};

export const rateFeedback = async ({ body }) => {
  const request = await axios.post(`/api/feedbacks`, body);
  if (request?.status < 400) {
    return request;
  }
};

export const apiOneMonthFree = async () => {
  const request = await axios.post(`api/accounts/offer-free-1-month`, {});
  if (request?.status < 400) {
    return request;
  }
};
