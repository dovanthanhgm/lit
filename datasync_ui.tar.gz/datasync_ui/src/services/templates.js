import axios from "src/utils/axios";
import { isNull } from "lodash";

//google
const createQuery = props => {
  if (!props) {
    return;
  }
  let param = "";
  Object.keys(props).forEach(item => {
    const val = props[item];
    const isExistData = !["undefined", "null", null, undefined].includes(val);
    if (!isNull(val) && isExistData) {
      if (param) {
        param += `&${item}=${val}`;
      } else {
        param += `${item}=${val}`;
      }
    }
  });
  return param;
};

export const searchCategoryGoogle = async props => {
  let api = `merchant/facebook/google_product_category`;
  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const browseCategoryGoogle = async ({ parentId = 0, ...props }) => {
  let api = `merchant/facebook/google_product_category`;
  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }

  if (![null, undefined].includes(parentId)) {
    api += `?parent_id=${parentId}`;
  }
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const searchCategoryWalmartCa = async props => {
  let api = `/merchant/walmartca/category/search`;
  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const queryAllCategoryShopeeID = async ({ channel_id, category_id }) => {
  let api = `merchant/shopee/${channel_id}/category/${category_id}/browser`;
  const { data } = await axios.get(api);
  if (data) {
    return data;
  }
};

export const searchCategoryShopee = async props => {
  let api = `/merchant/shopee/${props.channelID}/category/search`;
  if (props.name) {
    api += `?name=${props.name}`;
  }
  if (props.category_id) {
    api += `?name=${props.category_id}`;
  }

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const searchTaxWalmartCa = async props => {
  let api = `merchant/walmartca/taxcodes/search`;
  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};
//ebay
export const searchCategoryEbay = async ({
  query,
  channel_id,
  page = 1,
  support_variant = false
}) => {
  let api = `merchant/ebay/${channel_id}/categories/search?name=${encodeURIComponent(
    query
  )}`;
  if (support_variant) {
    api += `&support_variant=1`;
  }
  const param = createQuery({ page });
  if (param) {
    api += `&${param}`;
  }
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const searchCategoryEbayBrowse = async ({
  channel_id,
  // page,
  parentId = 0,
  support_variant = false
}) => {
  let api = `merchant/ebay/${channel_id}/categories/search?parent_id=${parentId}`;

  if (support_variant) {
    api += `&support_variant=1`;
  }
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const searchCategoryEbayID = async ({
  channel_id,
  // page,
  category_id = 0,
  support_variant = false
}) => {
  let api = `merchant/ebay/${channel_id}/categories/search?category_id=${category_id}`;
  if (support_variant) {
    api += `&support_variant=1`;
  }
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const queryAllCategoryEbayID = async ({
  channel_id,
  category_id,
  variantOnly = false
}) => {
  let api = `merchant/ebay/${channel_id}/categories/${category_id}/browser`;
  if (variantOnly) {
    api += `?support_variant=1`;
  }
  const { data } = await axios.get(api);
  if (data) {
    return data;
  }
};

//etsy
export const searchCategory = async ({ typeChannel, channel_id, ...props }) => {
  let api = `/merchant/${typeChannel}/category/search`;
  if (typeChannel === "etsy") {
    api = `/merchant/${typeChannel}/${channel_id}/category/search`;
  }
  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const queryAllCategoryEtsyID = async ({ channel_id, category_id }) => {
  let api = `merchant/etsy/${channel_id}/category/${category_id}/browser`;
  const { data } = await axios.get(api);
  if (data) {
    return data;
  }
};

export const searchBrowseEtsyCategory = async ({ parentId, channel_id }) => {
  let api = `/merchant/etsy/${channel_id}/category/search?parent_id=${parentId}`;

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};
export const searchBrowseShopeeCategory = async ({ parentId, channel_id }) => {
  let api = `/merchant/shopee/${channel_id}/category/search?parent_id=${parentId}`;

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const searchBrowseAmazonCategory = async ({ parentId, channel_id }) => {
  let api = `/merchant/amazon/${channel_id}/categories/search?parent_id=${parentId}`;

  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const searchBrowseBonanzaCategory = async ({ parentId, channel_id }) => {
  let api = `/merchant/bonanza/${channel_id}/categories/category/${parentId}`;
  const { data } = await axios.get(api);
  if (data) {
    return data;
  }
};

export const searchCategoryBonanza = async ({
  typeChannel,
  channel_id,
  ...props
}) => {
  let api = `/merchant/${typeChannel}/${channel_id}/categories/search`;

  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const postCreateTemplates = async ({ typeChannel, body, channelID }) => {
  // console.log(body);
  const res = await axios.post(
    `/merchant/${typeChannel}/${channelID}/templates`,
    body
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const getChannelTemplates = async () => {
  const data = await axios.get(`api/channels/templates`);
  if (data?.data) {
    return data.data;
  }
};

export const getListTemplates = async ({ type, id }) => {
  const { data } = await axios.get(`merchant/${type}/${id}/templates`);
  if (data?.data) {
    return data.data;
  }
};

export const getTemplateDetail = async ({
  typeChannel,
  channelID,
  templateID
}) => {
  const data = await axios.get(
    `merchant/${typeChannel}/${channelID}/templates/${templateID}`
  );
  if (data?.data) {
    return data.data;
  }
};

export const deleteTemplates = async ({
  typeChannel,
  channelID,
  templatesID
}) => {
  const res = await axios
    .delete(`/merchant/${typeChannel}/${channelID}/templates/${templatesID}`)
    .catch(e => console.log("error", e));
  if (res?.status < 400) {
    return res;
  }
};

export const getShippingProfiles = async ({ typeChannel, channelID }) => {
  const data = await axios.get(
    `merchant/${typeChannel}/${channelID}/shipping-profiles`
  );
  if (data?.data) {
    return data.data;
  }
};

export const getEtsySettings = async ({ channelID }) => {
  const data = await axios.get(`merchant/etsy/${channelID}/settings`);
  if (data?.data) {
    return data.data;
  }
};

export const getSquarespaceStore = async ({ channelId }) => {
  const data = await axios.get(`merchant/squarespace/${channelId}/stores`);
  if (data?.data) {
    return data?.data;
  }
};

export const putTemplates = async ({
  typeChannel,
  body,
  channelID,
  templateID
}) => {
  // console.log(body);
  const res = await axios.put(
    `merchant/${typeChannel}/${channelID}/templates/${templateID}`,
    body
  );
  if (res?.status < 400 && res.data) {
    return res.data;
  }
};

export const templatesApplyChangeCreateAPI = async ({
  templateId,
  productIds,
  channelID
}) => {
  const res = await axios.post(
    `/api/templates/${channelID}/${templateId}/apply-change`,
    {
      product_ids: productIds
    }
  );

  return res;
};

export const assignRecipesTemplates = async ({ channel_id, body }) => {
  const res = await axios.post(`/api/templates/${channel_id}/assign`, body);
  if (res && res.status < 400) {
    return res;
  }
};

export const getSectionEtsyTemplates = async ({ channel_id }) => {
  const data = await axios.get(`merchant/etsy/${channel_id}/section`);
  if (data) {
    return data.data;
  }
};

export const searchSpecificsEbay = async ({ category_id, channel_id }) => {
  const data = await axios.get(
    `/merchant/ebay/${channel_id}/categories/${category_id}/settings`
  );
  if (data.status < 400) {
    return data.data;
  }
};

export const searchSpecificsEbayListing = async ({
  category_id,
  channel_id
}) => {
  const data = await axios.get(
    `/merchant/ebay/${channel_id}/categories/${category_id}/settings?get_values=1`
  );
  if (data.status < 400) {
    return data.data;
  }
};

export const searchEbayCondition = async ({ channel_id, category_id }) => {
  const data = await axios.get(
    `/merchant/ebay/${channel_id}/categories/${category_id}/settings`
  );
  if (data.status < 400) {
    return data?.data;
  }
};

export const getEbayShippingService = async ({ channel_id }) => {
  const data = await axios.get(
    `merchant/ebay/${channel_id}/details/shipping-details`
  );
  if (data.status < 400) {
    return data?.data;
  }
};
// ebay setting
export const getEbayStoreCategory = async ({ channel_id }) => {
  const data = await axios.get(`merchant/ebay/${channel_id}/custom-categories`);
  if (data.status < 400) {
    return data?.data;
  }
};

export const getEbayRateTable = async ({ channel_id }) => {
  const data = await axios.get(`merchant/ebay/${channel_id}/rate-tables`);
  if (data.status < 400) {
    return data;
  }
};

export const changeVisibleVariantItem = async ({
  channel_id,
  publish_id,
  status
}) => {
  const request = await axios.put(
    `api/channel/${channel_id}/products/${publish_id}/${status}`
  );
  if (request.status < 400) {
    return request;
  }
};

export const ebayShippingCategory = async ({ channel_id }) => {
  const request = await axios.get(`merchant/ebay/${channel_id}/settings`);
  if (request.status < 400) {
    return request.data;
  }
};

export const getEtsyAttributes = async ({ channel_id, category_id }) => {
  const request = await axios.get(
    `/merchant/etsy/${channel_id}/category/${category_id}/attributes`
  );
  if (request.status < 400) {
    return request.data;
  }
};

export const getWishSearchBrand = async ({ name }) => {
  const request = await axios.get(`merchant/wish/brands?name=${name}`);
  if (request.status < 400) {
    return request.data;
  }
};

export const getWishWarehouse = async ({ channel_id }) => {
  const request = await axios.get(`merchant/wish/${channel_id}/warehouses`);
  if (request.status < 400) {
    return request.data;
  }
};

export const searchCategoryBigShop = async ({
  channel_id,
  search,
  page,
  channel
}) => {
  let api = `merchant/${channel}/${channel_id}/categories/search?name=${search}&page=${page}&limit=20`;

  const { data } = await axios.get(api);
  if (data?.data) {
    return data;
  }
};

export const bigRefreshCategory = async ({ channel_id, channel }) => {
  const request = await axios.post(
    `merchant/${channel}/${channel_id}/categories/fetch`
  );
  if (request.status < 400) {
    return request;
  }
};

export const getPartnerEtsy = async ({ channel_id }) => {
  const request = await axios.get(
    `merchant/etsy/${channel_id}/production-partners`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const getAttribute = async ({ name }) => {
  const request = await axios.get(`api/attributes?name=${name}`);
  if (request.status < 400) {
    return request?.data;
  }
};

export const getAttributeWalmart = async ({ category_id }) => {
  const request = await axios.get(
    `merchant/walmart/category/${category_id}/attributes`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const getReverbBrandAndModel = async channelID => {
  const request = await axios.get(`merchant/reverb/${channelID}/autocomplete`);
  if (request.status < 400) {
    return request?.data;
  }
};

export const getReverbCategoryList = async () => {
  const request = await axios.get("merchant/reverb/category");
  if (request.status < 400) {
    return request?.data;
  }
};

export const getOnBuyCategoryTree = async ({ parent_id }) => {
  const data = {
    parent_id: parent_id
  };
  const request = await axios.get("merchant/onbuy/category", { params: data });
  if (request.status < 400) {
    return request?.data;
  }
};

export const tiktokShippingService = async ({ channel_id }) => {
  const request = await axios.get(
    `merchant/tiktok/${channel_id}/shipping-provider`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const bonanzaTrait = async ({ channel_id, category_id }) => {
  let api = `/merchant/bonanza/${channel_id}/categories/category/${category_id}/traits`;
  const request = await axios.get(api);

  if (request.status < 400) {
    return request?.data;
  }
};

export const tiktokSearchCategory = async ({ channel_id, ...props }) => {
  let api = `/merchant/tiktok/${channel_id}/category/search`;

  const param = createQuery(props);
  if (param) {
    api += `?${param}`;
  }
  const request = await axios.get(api);
  if (request.status < 400) {
    return request?.data?.data;
  }
};

export const tiktokBrowseCategory = async ({ channel_id, parentId = "" }) => {
  const request = await axios.get(
    `/merchant/tiktok/${channel_id}/category/search?parent_id=${parentId}`
  );
  if (request.status < 400) {
    return request?.data?.data;
  }
};

export const tiktokSearchBrand = async ({ channel_id, category_id = "" }) => {
  const request = await axios.get(
    `merchant/tiktok/${channel_id}/category/${category_id}/brands`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const tiktokBrandSearch = async ({
  channel_id,
  category_id = "",
  name,
  page
}) => {
  let api = `merchant/tiktok/${channel_id}/category/${category_id}/brands?page=1&brand=${name}`;
  if (page) {
    api += `&page=${page}`;
  }
  const request = await axios.get(api);

  if (request.status < 400) {
    return request?.data?.brand_list;
  }
};

export const tiktokSearchAttribute = async ({
  channel_id,
  category_id = ""
}) => {
  const request = await axios.get(
    `merchant/tiktok/${channel_id}/category/${category_id}/attributes`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const tiktokCreateImageUrl = async ({ channel_id, imageFile }) => {
  const form = new FormData();
  if (imageFile) {
    form.append("image", imageFile);
    form.append("type", "5");
  }
  const request = await axios.post(
    `merchant/tiktok/${channel_id}/upload-img`,
    form
  );
  if (request.status < 400) {
    return request;
  }
};

export const tiktokProductCertificationImageUrl = async ({
  channel_id,
  imageFile
}) => {
  const form = new FormData();
  if (imageFile) {
    form.append("image", imageFile);
  }
  form.append("type", "4");
  const request = await axios.post(
    `merchant/tiktok/${channel_id}/upload-img`,
    form
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const tiktokProductCertificationFileUrl = async ({
  channel_id,
  imageFile,
  fileName = ""
}) => {
  const form = new FormData();
  if (imageFile) {
    form.append("file", imageFile);
    form.append("file_name", fileName);
    form.append("type", "4");
  }
  const request = await axios.post(
    `merchant/tiktok/${channel_id}/upload-file`,
    form
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const tiktokValidateRule = async ({ channel_id, category_id }) => {
  const request = await axios.get(
    `merchant/tiktok/${channel_id}/category/${category_id}/rules`
  );
  if (request.status < 400) {
    return request;
  }
};

export const walmartCaAttribute = async ({ category_id, language = "en" }) => {
  const request = await axios.get(
    `merchant/walmartca/category/${category_id}/attributes?language=${language}`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const amazonProductTypeAPI = async ({ channel_id, name }) => {
  const request = await axios.get(
    `/merchant/amazon/${channel_id}/product_type/search?name=${name}`
  );

  if (request.status < 400) {
    return request?.data?.data;
  }
};

export const amazonBrowseProductTypeAPI = async ({ channel_id, parentId }) => {
  const request = await axios.get(
    `/merchant/amazon/${channel_id}/product_type/search?parent_id=${parentId}`
  );

  if (request.status < 400) {
    return request?.data;
  }
};

export const amazonVariantThemeAPI = async ({ channel_id, category_id }) => {
  const request = await axios.get(
    `merchant/amazon/${channel_id}/categories/${category_id}/categoryspecific`
  );

  if (request.status < 400) {
    return request?.data;
  }
};

export const amazonCategoryAPI = async ({ channel_id, name }) => {
  const request = await axios.get(
    `/merchant/amazon/${channel_id}/categories/search?name=${name}`
  );

  if (request.status < 400) {
    return request?.data?.data;
  }
};

export const searchAmazonCategoryID = async ({
  channel_id,
  // page,
  category_id = 0
}) => {
  let api = `/merchant/amazon/${channel_id}/categories/search?category_id=${category_id}`;
  const { data } = await axios.get(api);
  if (data?.data) {
    return data.data;
  }
};

export const tiktokShippingWarehouse = async ({ channel_id }) => {
  const request = await axios.get(
    `merchant/tiktok/${channel_id}/warehouse-list`
  );

  if (request.status < 400) {
    return request?.data;
  }
};

export const getShopeeShippingType = async channelId => {
  const request = await axios.get(`merchant/shopee/${channelId}/shipping_info`);

  if (request.status < 400) return request?.data;
};

export const getShopeeCategoryBrands = async payload => {
  const request = await axios.get(
    `merchant/shopee/${payload.channelID}/category/${payload.category_id}/brands/${payload.offset}`
  );

  if (request.status < 400) return request?.data;
};

export const getShopeeCategoryAttributes = async payload => {
  const request = await axios.get(
    `merchant/shopee/${payload.channelID}/category/${payload.category_id}/attributes`
  );

  if (request.status < 400) return request?.data;
};

export const getShopeeShipDayLimit = async payload => {
  const request = await axios.get(
    `merchant/shopee/${payload.channelID}/category/${payload.category_id}/dts`
  );

  if (request.status < 400) return request?.data;
};

export const getShopeeSizeChart = async payload => {
  const request = await axios.get(
    `merchant/shopee/${payload.channelID}/category/${payload.category_id}/size_chart`
  );

  if (request.status < 400) return request?.data;
};

export const getShopeeSizeChartList = async payload => {
  const request = await axios.get(
    `merchant/shopee/${payload.channelID}/category/${payload.category_id}/list_size_chart`
  );

  if (request.status < 400) return request?.data;
};

export const shopeeCreateImageUrl = async ({ channel_id, imageFile }) => {
  const form = new FormData();
  if (imageFile) {
    form.append("image", imageFile);
  }
  const request = await axios.post(
    `/merchant/shopee/${channel_id}/upload_image`,
    form
  );
  if (request.status < 400) {
    return request;
  }
};

export const ebayBusinessPolicy = async ({ channel_id }) => {
  const request = await axios.get(`/merchant/ebay/${channel_id}/policies`);
  if (request.status < 400) {
    return request?.data;
  }
};

export const amazonDescriptionTemplate = async ({ channel_id }) => {
  const request = await axios.get(
    `merchant/amazon/${channel_id}/description-fields`
  );
  if (request.status < 400) {
    return request?.data;
  }
};

export const bonanzaCustomCategory = async ({ channel_id }) => {
  let api = `/merchant/bonanza/${channel_id}/custom_category`;
  const request = await axios.get(api);

  if (request.status < 400) {
    return request?.data;
  }
};

export const getSkipTemplate = channel_id => axios.get(`/api/channels/${channel_id}/skip-templates`);

export const skipTemplate = payload =>
   axios.post(`/api/channels/${payload.channelID}/skip-templates`, { ...payload.body });

export const queryAllCategoryTikTokID = async ({ channel_id, category_id }) => {
  let api = `merchant/tiktok/${channel_id}/category/${category_id}/browser`;
  const { data } = await axios.get(api);
  if (data) {
    return data;
  }
};
