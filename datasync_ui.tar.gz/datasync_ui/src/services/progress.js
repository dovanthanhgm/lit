import axios from "src/utils/axios";

export const progressService = {
  get: {
    getProgress: () => axios.get(`api/accounts/processes`)
  }
};
