import axios from "src/utils/axios";

export const getShipments = async ({ params }) => {
  let api = `api/shipments?`;
  Object.keys(params).forEach((key) => {
    if (params[key]) {
      api += `&${key}=${params[key]}`;
    }
  });
  const data = await axios.get(api);
  if (data?.data) {
    return data.data;
  }

  return;
};
