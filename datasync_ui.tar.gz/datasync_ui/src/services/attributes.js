import axios from "src/utils/axios";

export const postCustomAttribute = async ({ name }) => {
  const res = await axios.post(`/api/attributes`, { name });
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

export const getListCustomAttributes = async () => {
  const res = await axios.get(`/api/attributes`);
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};

export const putListAttributes = async ({ listAttributes }) => {
  const res = await axios.put(`/api/attributes`, listAttributes);
  if (res.status < 400) {
    return res.status;
  }
};

export const deleteCustomAttribute = async ({ id }) => {
  const res = await axios.delete(`/api/attributes/${id}`);
  if (res?.status < 400 && res.data) {
    return res.data;
  }

  return;
};
