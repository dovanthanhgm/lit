import axios from "src/utils/axios";

export const getTotalListing = async () => {
  const data = await axios.get("api/dashboard/stats");
  if (data && data?.data) {
    return data.data;
  }

  return;
};

export const getTotalOrder = async ({ params }) => {
  const { date, type } = params;
  const data = await axios.get(
    `api/dashboard/total-order?date=${date}&type=${type}`
  );
  if (data && data?.data) {
    return data.data;
  }

  return;
};

export const getActivitiesRecent = async () => {
  const data = await axios.get(`api/activities/recent`);
  if (data && data?.data) {
    return data.data;
  }

  return;
};

export const tutorial = async ({ body }) => {
  const res = await axios.put(`/api/accounts/tutorials`, body);
  if (res.status < 400) {
    return res;
  }

  return;
};

export const countUnListing = async ({ channel }) => {
  const res = await axios.get(
    `/api/channel/${channel}/products/count?linked=false`
  );
  if (res.data && res.status < 400) {
    return res.data;
  }
};

export const getOrderStatus = async () => {
  const res = await axios.get(`/api/orders/count?is_assigned=false`);
  if (res.data && res.status < 400) {
    return res.data;
  }
};

export const getAnnouncements = async () => {
  const res = await axios.get(`/api/announcements`);
  if (res.data && res.status < 400) {
    return res.data;
  }
};

export const getStatusStart = async ({ params }) => {
  const { date, type } = params;

  const res = await axios.get(`api/dashboard/stats?date=${date}&type=${type}`);
  if (res?.status < 400) {
    return res?.data;
  }
};
// export const getSaleData = async () => {
//   const res = await axios.get("api/settings/free-offer");
//   if (res.data && res.status < 400){
//     return res.data
//   }
// }
