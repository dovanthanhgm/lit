import axios from "src/utils/axios";

export const getActivitiesNotiAPI = async ({ page }) => {
  const respose = await axios.get(`/api/activities/notification?page=${page}`);
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const getActivitiesNotiAPICount = async () => {
  const respose = await axios.get(`/api/activities/notification/count`);
  if (respose?.status < 400 && respose.data) {
    return respose.data;
  }
};

export const getMainSyncApi = async () => {
  const request = await axios.get(`api/activities/main_sync`);
  if (request?.status < 400 && request.data) {
    return request.data;
  }
};

export const getChannelSyncApi = async () => {
  const request = await axios.get(`api/activities/channel_sync`);
  if (request?.status < 400 && request.data) {
    return request.data;
  }
};

export const getOrderSyncApi = async () => {
  const request = await axios.get(`api/activities/order_sync`);
  if (request?.status < 400 && request.data) {
    return request.data;
  }
};
