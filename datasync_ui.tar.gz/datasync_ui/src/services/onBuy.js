import axios from "src/utils/axios";

export const getListDeliveryTemplateOnBuy = async ({ channelID }) => {
  try {
    const res = await axios.get(
      `merchant/onbuy/${channelID}/delivery_template`
    );

    return res;
  } catch (e) {
    console.error("getListDeliveryTemplateOnBuy error");
  }
};
