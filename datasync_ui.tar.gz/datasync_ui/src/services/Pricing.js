import axios from "src/utils/axios";

export const sendPayment = async ({ type, orderData }) => {
  // {
  //   "order_type": "add_fund|aio|custom|plan",
  //   "order_data": {
  //   "price": "",
  //     "xxx": "yyy"
  // },
  // }
  const orderType = {
    order_type: type,
    order_data: orderData
  };
  const res = await axios.post(`api/payments/paypal/order/create`, orderType);
  if (res.status < 400) {
    return res.data;
  }
};

export const capturePayment = async ({ type, order_id, orderData }) => {
  const orderType = {
    order_type: type,
    order_data: orderData
  };
  const res = await axios.post(
    `api/payments/paypal/order/capture/${order_id}`,
    orderType
  );
  if (res.status < 400) {
    return res;
  }
};

export const createSubscriptionPlan = async ({
  order_id,
  orderData,
  isUpgraded
}) => {
  let body = { ...orderData };
  if (isUpgraded) {
    body = { ...body, is_upgraded: true };
  }
  const res = await axios.post(
    `/api/payments/paypal/subscription/select/${order_id}`,
    body
  );
  if (res.status < 400) {
    return res;
  }
};

export const approvePayment = async ({ type, order_id, orderData }) => {
  const orderType = {
    order_type: type,
    order_data: orderData
  };
  const res = await axios.post(
    `api/payments/paypal/order/approve/${order_id}`,
    orderType
  );
  if (res.status < 400) {
    return res;
  }
};

export const approvePlanPayment = async ({
  type,
  order_id,
  orderData,
  token
}) => {
  const orderType = {
    order_type: type,
    token,
    order_data: orderData
  };
  const res = await axios.post(
    `api/payments/paypal/subscription/approve/${order_id}`,
    orderType
  );
  if (res.status < 400) {
    return res;
  }
};

export const cancelSubscriptionFeedback = async ({
  survey,
  moreDetail,
  more_details2
}) => {
  const body = {
    survey,
    more_details: moreDetail,
    survey_type: "Cancel Sub",
    more_details2
  };

  const res = await axios.post(`/api/survey/`, body);
  if (res.status < 400) {
    return res;
  }
};

export const createSubscriptionPaypal = async ({ body }) => {
  const res = await axios.post(
    `/api/payments/paypal/subscription/create`,
    body
  );
  if (res.status < 400) {
    return res;
  }
};

export const customListingAndChannelPaypalAPI = async ({ body }) => {
  const res = await axios.post(`api/payments/paypal/subscription/pickup`, body);
  if (res.status < 400) {
    return res;
  }
};
