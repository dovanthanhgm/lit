import axios from 'src/utils/axios';

export const orderReportService = {
   get: {
      getReport: payload =>
         axios.get(`api/orders/report`, {
            params: { ...payload }
         }),
      getDetail: payload =>
         axios.get(`api/orders/detail`, {
            params: { ...payload }
         })
   }
};
