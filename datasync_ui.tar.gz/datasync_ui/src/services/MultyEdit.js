import axios from "src/utils/axios";

export const handleSaveMultiEdit = async ({
  channel_id,
  body,
  channelType
}) => {
  const response = await axios.put(
    `/merchant/${channelType}/${channel_id}/bulk_edit`,
    body
  );
  if (response?.status < 400) {
    return response;
  }
};
