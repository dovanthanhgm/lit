import React from "react";
import { Box, Link, Typography } from "@material-ui/core";
import ArrowForwardIcon from "@material-ui/icons/ArrowForward";
import { useHistory, useLocation } from "react-router";

const listShowBanner = ["product", "listing", "templates", "first-setup"];

export default function AIOBar() {
  const history = useHistory();
  const location = useLocation();
  const redirectAIO = () => {
    history.push("/buy-all-in-one");
  };

  const isShowBanner = () => {
    return listShowBanner.some(url => location.pathname.includes(url));
  };

  if (isShowBanner()) {
    return (
      <Box
        height={50}
        borderRadius={1}
        style={{
          marginTop: "24px",
          backgroundColor: "#1e87f0",
          bottom: 0
          // backgroundImage: "linear-gradient(#2824D1, #1976D2)"
        }}
      >
        <Box
          display="flex"
          alignItems="center"
          justifyContent="center"
          width="100%"
          height="100%"
        >
          <img src="/static/aio.png" alt="" width={24} />
          &nbsp;&nbsp;
          <Typography style={{ color: "white" }} variant="h5">
            NO TIME TO LIST PRODUCTS BY YOUR OWN?&nbsp;&nbsp; Hire our experts
            to perform full listing. &nbsp;&nbsp;
          </Typography>
          <Box display="flex" alignItems="center" onClick={redirectAIO}>
            <Link
              style={{
                color: "#ff9800",
                fontSize: 15,
                cursor: "pointer",
                textDecoration: "none"
              }}
              variant="h5"
            >
              Get My Package
            </Link>
            <ArrowForwardIcon
              cursor={"pointer"}
              fontSize="small"
              style={{ color: "white" }}
              height={20}
            />
          </Box>
        </Box>
      </Box>
    );
  }
}
