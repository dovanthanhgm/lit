import React, { useContext, useState } from "react";
import { useSnackbar } from "notistack";
import ButtonCustom from "src/components/MUI/Button";
import { merchantSubscriptionPaymentAPI } from "src/services/manage";
import { useDispatch, useSelector } from "react-redux";
import { accountCancelSubscription, getUserInfo } from "src/services/account";
import { setUserData } from "src/actions/accountActions";
import { messageError } from "src/utils/ErrorResponse";
import { PaypalContext } from "src/views/management/Pricing/Context/PaypalContext";
import { FREE_CHANNEL_LIMIT, FREE_LISTING_LIMIT } from "src/constants/index";
import { Box, Typography } from "@material-ui/core";
import BillingCaption from "src/views/management/Pricing/Component/BillingCaption";
import { handleCancelledStatus } from "src/helper/PricingHelper";

const PaymentMerchantButton = ({ type, onPaySuccess, setSubscriptionMe }) => {
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();

  const { chanelLimit, listingLimit, isPlanChange } = useContext(PaypalContext);
  const { subscription } = useSelector(state => state.account.user);
  const user = useSelector(state => state?.account?.user);
  const userEndTrial = user?.subscription?.user_plan?.cancelled_at;

  const totalProducts =
    subscription?.products_limit !== 0 ? subscription?.products_limit : 0;

  const userNotFree =
    user?.subscription?.channels_limit > FREE_LISTING_LIMIT ||
    totalProducts > FREE_LISTING_LIMIT;

  const [loading, setLoading] = useState(false);

  const isFreeBill =
    chanelLimit === FREE_CHANNEL_LIMIT && listingLimit === FREE_LISTING_LIMIT;

  const isRenew = subscription?.auto_renew;

  const typeChangeDetect = () => {
    const isMonth = subscription.yearly_paid === 1;
    return isMonth ? "yr" : "mo";
  };
  //có mây chỗ cần fix: nếu chọn plan hiện tại mà có auto renew 21/6/2023/slack 09:46 am
  const isHideWhenRenew =
    isRenew && typeChangeDetect() === type && !isPlanChange;

  const renderButtonText = isSmaller => {
    if (handleCancelledStatus(userEndTrial)) {
      return "upgrade plan & confirm payment";
    }
    if (!isPlanChange) {
      return "extend plan & confirm payment";
    }
    return "Update plan & confirm payment";
  };

  const handleClickPlanId = async () => {
    setLoading(true);
    let body = {
      yearly_billing: type === "yr",
      channel_limit: chanelLimit,
      listings_limit: listingLimit
    };
    try {
      const data = await merchantSubscriptionPaymentAPI({
        body,
        isPaymentInStep3: !!onPaySuccess
      });
      if (data.code === 200 || data.code === "payment") {
        onPaySuccess && onPaySuccess({ isNotPayment: isFreeBill });
      } else {
        setLoading(false);
        enqueueSnackbar("Ooops!", {
          variant: "error"
        });
      }
      data.code === "payment" && window.open(data.data, "_self");
      if (data.code === 200) {
        if (onPaySuccess) {
          return;
        }
        setSubscriptionMe && setSubscriptionMe(data.data);
        enqueueSnackbar("Success", {
          variant: "success"
        });
      }
      !data.data && setLoading(false);
    } catch (e) {
      setLoading(false);
      const message =
        e?.response?.data?.message ||
        e?.response?.data?.errors ||
        "Payment fail";
      enqueueSnackbar(message, { variant: "error" });
    }
  };

  //cancel for merchant only
  const handleCancelSubscription = async () => {
    try {
      setLoading(true);
      await accountCancelSubscription();
      const data = await getUserInfo();
      if (data) {
        dispatch(setUserData({ ...data }));
      }
    } catch (e) {
      enqueueSnackbar(messageError(e, "Change subscription error"), {
        variant: "error"
      });
    }
    setLoading(false);
  };

  if (isHideWhenRenew) {
    return (
      <Box mt={1}>
        <Typography variant="body2">
          Your subscription will automatically renew when it expires.
        </Typography>
      </Box>
    );
  }

  if (isFreeBill) {
    return (
      <Box display={"flex"} justifyContent={"center"} flexDirection={"column"}>
        <ButtonCustom
          text={renderButtonText(userNotFree)}
          color="primary"
          size="large"
          onClick={handleCancelSubscription}
          disabled={loading}
          notShowCircle={!loading}
        />
        <BillingCaption />
      </Box>
    );
  }

  return (
    <Box display={"flex"} justifyContent={"center"} flexDirection={"column"}>
      <ButtonCustom
        text={renderButtonText()}
        color="primary"
        size="large"
        onClick={handleClickPlanId}
        disabled={loading}
        notShowCircle={!loading}
      />
      <BillingCaption />
    </Box>
  );
};

export default PaymentMerchantButton;
