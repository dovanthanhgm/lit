import { Box, Paper, Typography } from "@material-ui/core";
import React from "react";
import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import useMerchantPayment from "src/hooks/Subscription/useMerchantPayment";
import BillingTime from "src/views/management/Pricing/Component/BillingTime";
import CustomMerchantPaymentForm from "src/views/management/Pricing/CustomPlan/FormPayment/MerchantPaymentForm";
import PaymentPaypalButton from "src/views/management/Pricing/CustomPlan/FormPayment/Paypal/PaymentPaypalButton";
import PaypalBillingForm from "src/views/management/Pricing/CustomPlan/FormPayment/Paypal/BillingForm";
import { useSelector } from "react-redux";

export const MERCHANT_PAY = "MERCHANT_PAY";
export const PAYPAL_PAY = "PAYPAL_PAY";

function CustomFormPrice({
  setType,
  type,
  setSubscriptionMe,
  onPaySuccess,
  isDisableMonth,
  defaultType
}) {
  const { isLoginMerchant } = useMerchantPayment({ defaultType });
  const { subscription } = useSelector(state => state?.account?.user);
  const { user } = useSelector(state => state?.account);

  const initialOptions = {
    "client-id": process.env.REACT_APP_CLIENT_PAYPAL,
    vault: true
  };

  const handleSelectBillingType = i => () => {
    setType(i);
  };

  const checkPaymentMethod = () => {
    return subscription?.user_plan?.payment_method;
  };

  const checkUserFrom = () => {
    return ["shopify", "wix"].includes(user?.user_from);
  };

  /* 
  check field payment method
    Nếu payment method k có:
    Check user_from trong api/me, nếu from shopify/wix thì dùng payment method tương ứng là shopify/wix
    nếu user_from litc, woo, square ... (tóm lại k phải shopify/wix) thì check tiếp:
    Nếu login từ shopify/wix thì dùng luôn shopify/wix
    Tất cả điều kiện trên sai thì dùng paypal
  */

  const handleRenderPayButton = () => {
    if (checkPaymentMethod()) {
      return ["shopify", "wix"].includes(checkPaymentMethod())
        ? MERCHANT_PAY
        : PAYPAL_PAY;
    } else if (checkUserFrom()) {
      return MERCHANT_PAY;
    } else if (isLoginMerchant) {
      return MERCHANT_PAY;
    } else {
      return PAYPAL_PAY;
    }
  };

  return (
    <Paper component={Box} p={2} style={{ height: "100%" }}>
      <PayPalScriptProvider options={initialOptions}>
        <Typography variant="h5" color="textPrimary">
          Your Price
        </Typography>
        <BillingTime
          type={type}
          handleSelectBillingType={handleSelectBillingType}
          isDisableMonth={isDisableMonth}
        />
        <PaypalBillingForm type={type} />
        {handleRenderPayButton() === MERCHANT_PAY && (
          <CustomMerchantPaymentForm
            type={type}
            setSubscriptionMe={setSubscriptionMe}
            onPaySuccess={onPaySuccess}
          />
        )}

        {handleRenderPayButton() === PAYPAL_PAY && (
          <PaymentPaypalButton type={type} defaultType={defaultType} />
        )}
      </PayPalScriptProvider>
    </Paper>
  );
}

export default CustomFormPrice;
