import React, { useEffect, useMemo, useState } from "react";
import { Box } from "@material-ui/core";
import { useGetListSubscription } from "src/hooks/index";
import { useSelector } from "react-redux";
import CustomFormPrice from "src/views/management/Pricing/CustomPlan/FormPayment/CustomFormPrice";

const CheckOutForm = () => {
  const [type, setType] = useState("");
  const { lists, listsHigher } = useGetListSubscription();
  const { defaultListing } = useSelector(state => state?.listing);
  const { subscription } = useSelector(state => state.account.user);

  const currentPlan = useMemo(() => {
    if (!lists || !listsHigher) {
      return;
    }

    return (listsHigher || []).concat(lists).find(item => item.id === 3);
  }, [lists, listsHigher]);

  const isYearlyPaid = subscription.yearly_paid === 1;

  useEffect(() => {
    if (isYearlyPaid) {
      setType("yr");
    } else {
      setType("mo");
    }
  }, [isYearlyPaid]);

  return (
    <Box maxWidth={750} pr={2}>
      <CustomFormPrice
        setType={setType}
        type={type}
        plan={currentPlan}
        isDisableMonth={isYearlyPaid}
        defaultType={defaultListing?.type}
      />
    </Box>
  );
};

export default CheckOutForm;
