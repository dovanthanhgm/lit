import React from "react";
import { Box, Divider } from "@material-ui/core";
import PaymentMerchantButton from "src/views/management/Pricing/CustomPlan/FormPayment/Merchant/PaymentMerchantButton";

const CustomMerchantPaymentForm = ({
  type,
  setSubscriptionMe,
  onPaySuccess
}) => {
  return (
    <Box>
      <Divider />
      <Box display="flex" justifyContent="center" width="100%" mt={2}>
        <PaymentMerchantButton
          type={type}
          onPaySuccess={onPaySuccess}
          setSubscriptionMe={setSubscriptionMe}
        />
      </Box>
    </Box>
  );
};

export default CustomMerchantPaymentForm;
