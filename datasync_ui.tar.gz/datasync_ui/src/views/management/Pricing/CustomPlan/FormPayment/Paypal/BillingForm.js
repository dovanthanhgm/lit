import React, { useContext } from "react";
import { Box, Divider, Typography } from "@material-ui/core";
import { PaypalContext } from "src/views/management/Pricing/Context/PaypalContext";
import { calculateDiscountMoney } from "src/constants/Pricing/index";

const PaypalBillingForm = ({ type }) => {
  const { planPrice } = useContext(PaypalContext);

  const handlePrice = () => {
    if (type === "yr") {
      return planPrice * 12;
    }
    return planPrice;
  };

  const handleRenderTotalText = () => {
    return type === "yr" ? "Yearly Fee" : "Monthly Fee";
  };

  const handleDiscount = () => {
    if (type === "yr") {
      return calculateDiscountMoney(planPrice * 12).toFixed(2);
    }
    return 0.0;
  };

  return (
    <div>
      <Box
        pt={2}
        pb={2}
        display="flex"
        justifyContent="space-between"
        alignItems={"center"}
      >
        <Box>
          <Typography variant="body1" component={"span"}>
            ${handlePrice().toFixed(2)}
          </Typography>
          /
          <Typography variant="body2" component={"span"}>
            {type === "yr" ? "year" : "month"}
          </Typography>
        </Box>
        <Box></Box>
      </Box>
      <Divider />
      <Box
        pt={2}
        pb={2}
        display="flex"
        justifyContent="space-between"
        alignItems={"center"}
      >
        <Typography variant="body2">Annual billing discount</Typography>
        <Typography variant="body2">-${handleDiscount()}</Typography>
      </Box>
      <Divider />
      <Box
        pt={2}
        pb={2}
        display="flex"
        justifyContent="space-between"
        alignItems={"center"}
      >
        <Typography variant="body2">{handleRenderTotalText()}</Typography>
        <Typography variant="h4">
          ${(handlePrice() - handleDiscount()).toFixed(2)}
        </Typography>
      </Box>
    </div>
  );
};

export default PaypalBillingForm;
