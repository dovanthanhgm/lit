import React, { useContext, useEffect, useLayoutEffect, useState } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Slider from "@material-ui/core/Slider";
import Typography from "@material-ui/core/Typography";
import Tooltip from "@material-ui/core/Tooltip";
import { Box, ClickAwayListener, Divider, Paper } from "@material-ui/core";
import { useSelector } from "react-redux";
import { debounce } from "lodash";
import { PaypalContext } from "src/views/management/Pricing/Context/PaypalContext";

function ValueLabelComponent(props) {
  const { children, open, value } = props;

  return (
    <Tooltip open={open} enterTouchDelay={0} placement="top" title={value}>
      {children}
    </Tooltip>
  );
}

ValueLabelComponent.propTypes = {
  children: PropTypes.element.isRequired,
  open: PropTypes.bool.isRequired,
  value: PropTypes.number.isRequired
};

const PrettoSlider = withStyles({
  root: {
    // color: colors.blue.A400,
    height: 8
  },
  thumb: {
    height: 27,
    width: 27,
    backgroundColor: "#fff",
    border: "1px solid currentColor",
    marginTop: -10,
    marginLeft: -13,
    boxShadow: "#ebebeb 0 2px 2px",
    "&:focus, &:hover, &$active": {
      boxShadow: "#ccc 0 2px 3px 1px"
    },
    "& .bar": {
      // display: inline-block !important;
      height: 9,
      width: 1,
      backgroundColor: "currentColor",
      marginLeft: 1,
      marginRight: 1
    }
  },
  mark: {
    height: 6,
    width: 3,
    marginTop: 0,
    marginRight: 2
  },
  markActive: {
    opacity: 1,
    height: 0,
    color: "white",
    backgroundColor: "currentColor"
  },
  track: {
    height: 10,
    borderRadius: "4px 0 0 4px",
    marginBottom: 8
  },
  rail: {
    height: 6,
    borderRadius: "4px 0 0 4px",
    marginBottom: 8
  }
})(Slider);

const LabelLayout = ({ children }) => {
  return (
    <Box
      height={24}
      pt={1}
      display={"flex"}
      flexDirection={"column"}
      alignItems={"center"}
    >
      <Divider orientation={"vertical"} />
      {children}
    </Box>
  );
};

function AirbnbThumbComponent(props) {
  return (
    <span {...props}>
      <span className="bar" />
      <span className="bar" />
      <span className="bar" />
    </span>
  );
}

const marks = [
  // {
  //   value: 0,
  //   label: <LabelLayout>20</LabelLayout>,
  //   price: 0,
  //   products: 20
  // },
  {
    value: 10,
    label: <LabelLayout>1k</LabelLayout>,
    price: 14,
    products: 1000
  },
  {
    value: 20,
    label: <LabelLayout>2k</LabelLayout>,
    price: 29,
    products: 2000
  },
  {
    value: 30,
    label: <LabelLayout>5k</LabelLayout>,
    price: 44,
    products: 5000
  },
  {
    value: 40,
    label: <LabelLayout>10k</LabelLayout>,
    price: 69,
    products: 10000
  },
  {
    value: 50,
    label: <LabelLayout>15k</LabelLayout>,
    price: 84,
    products: 15000
  },
  {
    value: 60,
    label: <LabelLayout>20k</LabelLayout>,
    price: 99,
    products: 20000
  },
  {
    value: 70,
    label: <LabelLayout>25k</LabelLayout>,
    price: 114,
    products: 25000
  },
  {
    value: 80,
    label: <LabelLayout>50k</LabelLayout>,
    price: 204,
    products: 50000
  },
  {
    value: 100,
    label: <LabelLayout>75k</LabelLayout>,
    price: 249,
    products: 75000
  },
  {
    value: 120,
    label: <LabelLayout>100k</LabelLayout>,
    price: 294,
    products: 100000
  }
];

const marksChannel = [...Array(15).keys()]
  .map(channel => ({
    value: channel + 1,
    label: <LabelLayout>{channel + 1}</LabelLayout>
  }))
  .filter(channels => channels.value >= 3);

export const handleSetBodyPaypal = debounce(
  async ({ data, setListOption, checkFunction = function() {} }) => {
    try {
      setListOption(data);
      checkFunction();
    } catch (e) {}
  },
  400
);

export default function FormPaymentCustom() {
  const { subscription, plan_history } = useSelector(
    state => state?.account?.user
  );
  const user = useSelector(state => state?.account?.user);
  const isUserTrial = user.is_trial;

  const {
    setChannelLimit,
    setListingLimit,
    chanelLimit,
    listingLimit,
    setPlanPrice,
    setOldPlanPrice
  } = useContext(PaypalContext);

  const userChannel = user?.channels?.length - 1 || 0;
  const userPlanHistory = plan_history?.total_products;

  const totalProducts =
    subscription?.products_limit !== 0 ? subscription?.products_limit : 0;

  const findProduct =
    marks.find(product => product.products === totalProducts)?.value || 0;

  const [channel, setChannel] = useState(
    user?.subscription?.channels_limit || 2
  );

  const [listing, setListing] = useState(findProduct);
  const [tooltipDisable, setTooltipDisable] = useState("");

  function valuetext(value) {
    return `${value}`;
  }

  const isUserFree = channel === 2 && listing === 0;

  const priceCalculate = (channel, listing) => {
    if (isUserFree) return 0;
    const priceListing = marks.find(
      channelPrice => channelPrice.value === listing
    )?.price;
    const priceChannel = channel * 5;
    return priceChannel + priceListing;
  };

  const renderFinalPrice = (channel, listing) => {
    if (channel === 2 && listing === 0) return "Free";
    return "$" + priceCalculate(channel, listing);
  };

  const handleChangeChannel = (event, newValue) => {
    if (newValue < userChannel) {
      setTooltipDisable("channel");
      return null;
    }
    setChannel(newValue);
    setTooltipDisable("");
    const checkFunction = () => {
      if (newValue < 3) {
        setListingLimit(0);
        setListing(0);
      }
      if (listing < 10 && newValue >= 3) {
        setListingLimit(1000);
        setListing(10);
      }
    };
    handleSetBodyPaypal({
      data: newValue,
      setListOption: setChannelLimit,
      checkFunction
    });
  };

  const handleChangeListing = (event, newValue) => {
    const priceListing = marks.find(
      channelPrice => channelPrice.value === newValue
    )?.products;

    if (priceListing < userPlanHistory) {
      setTooltipDisable("listing");
      return null;
    }
    setListing(newValue);
    setTooltipDisable("");
    const checkFunction = () => {
      if (newValue < 10) {
        setChannelLimit(2);
        setChannel(2);
      }
      if (channel < 3 && newValue >= 10) {
        setChannel(3);
        setChannelLimit(3);
      }
    };

    if (priceListing) {
      handleSetBodyPaypal({
        data: priceListing,
        setListOption: setListingLimit,
        checkFunction
      });
    }
  };

  const initUserChannelLimit = user?.subscription?.channels_limit;

  useLayoutEffect(() => {
    if (isUserFree) {
      setListingLimit(1000);
      setListing(10);
      setChannel(3);
      setChannelLimit(3);
    }
    // eslint-disable-next-line
  }, [isUserFree]);

  useEffect(() => {
    setOldPlanPrice(priceCalculate(initUserChannelLimit, findProduct));
    // eslint-disable-next-line
  }, [initUserChannelLimit, findProduct]);

  useEffect(() => {
    const priceListing = marks.find(
      channelPrice => channelPrice.products === listingLimit
    )?.value;
    setPlanPrice(priceCalculate(chanelLimit, priceListing));
    // eslint-disable-next-line
  }, [chanelLimit, listingLimit]);

  return (
    <Paper
      component={Box}
      p={2.5}
      style={{
        height: "fit-content"
      }}
    >
      <Box
        display={"flex"}
        flexDirection={"column"}
        style={{
          height: "100%"
        }}
        justifyContent={"space-between"}
      >
        <Box width={"100%"}>
          <Typography variant="h5" color="textPrimary">
            Set the sliders to choose your Plan and see how much you'll pay
          </Typography>
          {isUserTrial && (
            <Typography variant={"body2"}>
              Upgrading your Plan will stop your{" "}
              <span style={{ fontWeight: "bold" }}>Free Trial</span> and replace
              it by your new Plan
            </Typography>
          )}
          <ClickAwayListener
            onClickAway={() => {
              setTooltipDisable("");
            }}
          >
            <Box mt={4} pr={1}>
              <Typography
                variant={"h6"}
                style={{
                  fontSize: 14
                }}
              >
                Number of Channels (Total):
              </Typography>
              <Box my={1.5} />
              <Tooltip
                open={tooltipDisable === "channel"}
                title={
                  tooltipDisable === "channel"
                    ? "You can not choose plans lower than your current usage."
                    : ""
                }
              >
                <PrettoSlider
                  ThumbComponent={AirbnbThumbComponent}
                  value={channel}
                  step={1}
                  min={3}
                  getAriaValueText={valuetext}
                  max={15}
                  marks={marksChannel}
                  onChange={handleChangeChannel}
                  valueLabelDisplay="auto"
                />
              </Tooltip>

              <Box mt={4} />
              <Typography
                variant={"h6"}
                style={{
                  fontSize: 14
                }}
              >
                Number of Listings (Total):
              </Typography>
              <Box my={1.5} />
              <Tooltip
                open={tooltipDisable === "listing"}
                title={
                  tooltipDisable === "listing"
                    ? "You can not choose plans lower than your current usage."
                    : ""
                }
              >
                <PrettoSlider
                  ThumbComponent={AirbnbThumbComponent}
                  value={listing}
                  step={null}
                  min={10}
                  getAriaValueText={valuetext}
                  max={120}
                  onChange={handleChangeListing}
                  marks={marks}
                  valueLabelDisplay="auto"
                />
              </Tooltip>
            </Box>
          </ClickAwayListener>
          <Box
            mt={4}
            pt={2}
            pb={2}
            display="flex"
            justifyContent="space-between"
          >
            <Box />
            <Box display={"flex"} alignItems={"flex-end"}>
              <Typography
                variant={"body1"}
                style={{
                  opacity: 0.5
                }}
              >
                Monthly Subscription Fee:
              </Typography>
              &nbsp;
              <Typography
                variant="h2"
                align={"right"}
                style={{
                  minWidth: 70
                }}
              >
                {renderFinalPrice(channel, listing)}
              </Typography>
            </Box>
          </Box>
        </Box>

        <Box textAlign={"center"} mt={3}>
          <Typography variant={"body2"}>
            Have more Requirements or need a Custom Plan? Please contact us.
          </Typography>
        </Box>
      </Box>
    </Paper>
  );
}
