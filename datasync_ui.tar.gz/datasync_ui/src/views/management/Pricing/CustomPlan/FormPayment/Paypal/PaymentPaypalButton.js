import React, { useCallback, useContext, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  Divider,
  makeStyles,
  Paper,
  Typography
} from "@material-ui/core";
import { useSnackbar } from "notistack";
import { PayPalButtons } from "@paypal/react-paypal-js";
import {
  approvePlanPayment,
  customListingAndChannelPaypalAPI
} from "src/services/Pricing";
import wait from "src/utils/wait";
import { messageError } from "src/utils/ErrorResponse";

import Cookies from "universal-cookie";
import { PaypalContext } from "src/views/management/Pricing/Context/PaypalContext";
import { useSelector } from "react-redux";
import DialogTitle from "src/components/Modal/DialogTitle";
import moment from "moment";
import BillingCaption from "src/views/management/Pricing/Component/BillingCaption";
import { calculateYearlyMoney } from "src/constants/Pricing/index";

const cookies = new Cookies();

let CurrentToken = "";

const currency = "USD";
const style = { layout: "vertical", minHeight: 130, minWidth: "100%" };

const useStyles = makeStyles(() => ({
  customPaypalButton: {
    width: "100%"
  }
}));

const UpgradeInfo = ({ type }) => {
  const { planPrice, oldPlanPrice } = useContext(PaypalContext);
  const { subscription } = useSelector(state => state?.account?.user);

  const handleRenderTotalText = () => {
    return "To be billed now";
  };

  const dateExp = subscription.expired_at;
  const userDay = moment();
  const expDay = moment(dateExp);
  const diffDay = expDay.diff(userDay, "days"); // =1
  const nextDayCycle = expDay.add(1, "days").format("ll");

  const renderFinalPrice = () => {
    if (diffDay <= 0) {
      return null;
    }
    if (type === "mo") {
      return ((planPrice - oldPlanPrice) / 30) * diffDay;
    }

    return (
      ((calculateYearlyMoney(planPrice) - calculateYearlyMoney(oldPlanPrice)) /
        365) *
      diffDay
    );
  };

  const renderPriceTotal = useCallback(() => {
    if (!planPrice) {
      return "--";
    }
    if (type === "mo") {
      return `$${planPrice}.00`;
    }

    return `$${calculateYearlyMoney(planPrice).toFixed(2)}`;
  }, [type, planPrice]);

  return (
    <Paper style={{ minWidth: 400 }}>
      <Box p={1}>
        <Typography variant="h6" color="textPrimary">
          Subscription Details:
        </Typography>
      </Box>
      <Box p={1}>
        <Typography variant="body2" color="textPrimary">
          {renderPriceTotal()} for each {type === "yr" ? "year" : "month"}{" "}
          (Renews until you cancel)
        </Typography>
      </Box>
      <Box p={1}>
        <Typography variant="body2" color="textPrimary">
          Starts on: {nextDayCycle}
        </Typography>
      </Box>
      {!!diffDay && diffDay > 0 && (
        <>
          <Divider />
          <Box py={1} p={1} display="flex" justifyContent="space-between">
            <Typography variant="body2">Current plan remaining days</Typography>
            <Typography variant="body2">{diffDay}</Typography>
          </Box>
        </>
      )}
      {![null, undefined, NaN].includes(renderFinalPrice()) && (
        <>
          <Divider />
          <Box py={1} p={1} display="flex" justifyContent="space-between">
            <Box>
              <Typography variant="h6">{handleRenderTotalText()}</Typography>
            </Box>
            <Typography variant="h5">
              {renderFinalPrice()
                ? `$${Math.abs(renderFinalPrice()).toFixed(2)}`
                : "Free"}
            </Typography>
          </Box>
        </>
      )}
    </Paper>
  );
};

const FormPayWithPaypal = ({ type, isRenew = false }) => {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const litCommerceBaseAPI = process.env?.REACT_APP_API_URL;
  const { listingLimit, chanelLimit } = useContext(PaypalContext);

  return (
    <PayPalButtons
      disabled={false}
      // Button render if 1 of item change
      forceReRender={[
        currency,
        style,
        type,
        litCommerceBaseAPI,
        listingLimit,
        chanelLimit
      ]}
      fundingSource={undefined}
      style={style}
      className={classes.customPaypalButton}
      createSubscription={async (data, actions) => {
        try {
          const body = {
            products_limit: listingLimit,
            channels_limit: chanelLimit,
            yearly_billing: type === "yr"
          };
          if (isRenew) {
            body.isUpgraded = true;
          }
          const request = await customListingAndChannelPaypalAPI({
            body
          });
          if (request?.status < 400) {
            CurrentToken = request?.data?.token;
            await wait(1000);
            const createBody = request?.data?.paypal_body || {};
            const accessToken = cookies.get("accessToken");
            const newAccessToken = `JWT ${accessToken}`;

            if (!litCommerceBaseAPI || typeof litCommerceBaseAPI !== "string")
              return;
            // this function only work with fetch
            return fetch(
              litCommerceBaseAPI + "/api/payments/paypal/subscription/create",
              {
                method: "post",
                body: JSON.stringify({
                  ...createBody
                }),
                headers: {
                  "content-type": "application/json",
                  Authorization: newAccessToken
                }
              }
            )
              .then(function(res) {
                return res.json();
              })
              .then(function(serverData) {
                return serverData.id;
              });
            // return actions.subscription.create({
            //   ...createBody // Creates the subscription
            // });
          }
        } catch (e) {
          enqueueSnackbar(messageError(e, "Error Create subscription"), {
            variant: "error"
          });
        }
      }}
      onApprove={(data, actions) => {
        const handleCapture = async () => {
          try {
            await approvePlanPayment({
              order_id: data.subscriptionID,
              type: "plan",
              token: CurrentToken,
              orderData: {
                products_limit: listingLimit,
                channels_limit: chanelLimit,
                yearly_paid: type === "yr"
              }
            });
            enqueueSnackbar("Success", {
              variant: "success"
            });
            await wait(1000);
            window.open("/subscription/change-success", "_self");
          } catch (e) {
            CurrentToken = "";
            enqueueSnackbar(messageError(e, "Error"), {
              variant: "error"
            });
          }
          CurrentToken = "";
        };
        return handleCapture();
      }}
    />
  );
};

const ModalUpdatePaypal = ({
  type,
  handleClose = function() {},
  open,
  updateMonthly = false
}) => {
  const [isApprove, setIsApprove] = useState(false);

  const handleOnApprove = () => {
    setIsApprove(true);
  };

  return (
    <Box mt={1}>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle onClose={handleClose}>Update Plan</DialogTitle>
        <DialogContent
          style={{
            padding: "8px 16px"
          }}
        >
          {isApprove && (
            <UpgradeInfo type={type} updateMonthly={updateMonthly} />
          )}
          {!isApprove && (
            <>
              <Typography variant="body2">
                To upgrade your plan, your current plan will be cancelled and
                you will subscribe to a new plan. If you choose a higher plan,
                we will charge the difference for the remaining days of the
                current cycle (On paypal this is called: One Time Setup), and
                you will start paying for the new subscription at the beginning
                of the next billing cycle.
              </Typography>
            </>
          )}
        </DialogContent>
        <DialogActions
          style={{ justifyContent: isApprove ? "center" : "flex-end" }}
        >
          {isApprove && <FormPayWithPaypal type={type} isRenew />}
          {!isApprove && (
            <>
              <Button onClick={handleClose} variant="contained" size="small">
                Back
              </Button>
              <Button
                onClick={handleOnApprove}
                variant="contained"
                color="primary"
                size="small"
                autoFocus
              >
                Approve
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </Box>
  );
};

const PaypalYearly = ({ type }) => {
  const [open, setOpen] = useState(false);
  const { isDownGradePlan } = useContext(PaypalContext);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Button
        variant="contained"
        style={{ backgroundColor: "#ffc439" }}
        onClick={handleOpen}
      >
        {isDownGradePlan ? "Downgrade" : "Update"} Plan & confirm payment
      </Button>
      {open && (
        <ModalUpdatePaypal type={type} handleClose={handleClose} open={open} />
      )}
    </>
  );
};

const PriceRenewPaypal = ({ type }) => {
  const [open, setOpen] = useState(false);
  const { isPlanChange, isDownGradePlan } = useContext(PaypalContext);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  if (!isPlanChange) {
    return (
      <Box mt={1}>
        <Typography variant="body2">
          Your subscription will automatically renew when it expires.
        </Typography>
      </Box>
    );
  }

  return (
    <>
      <Button
        variant="contained"
        style={{ backgroundColor: "#ffc439" }}
        onClick={handleOpen}
      >
        {isDownGradePlan ? "Downgrade" : "Update"} Plan & confirm payment
      </Button>
      {open && (
        <ModalUpdatePaypal type={type} handleClose={handleClose} open={open} />
      )}
    </>
  );
};

const PaymentPaypalButton = ({ type }) => {
  const { subscription } = useSelector(state => state?.account?.user);
  const { isPlanChange, planPrice } = useContext(PaypalContext);

  const paypalSubscription = !!subscription?.user_plan?.paypal_subscription_id;
  const isRenewPlan = subscription?.user_plan?.auto_renew;
  const renderUpgradeTotal = isPlanChange;
  const isRenewPaypal = isRenewPlan && paypalSubscription;
  const showNormalPaymentWithPaypal = !isRenewPaypal && !isRenewPlan;

  const isChangeToYearly =
    subscription.yearly_paid === 0 &&
    type === "yr" &&
    !renderUpgradeTotal &&
    isRenewPlan;

  if (!planPrice) return null;

  return (
    <>
      <Divider />
      <Box display="flex" justifyContent="center" width="100%" mt={2}>
        {/*yearly renew*/}
        {isChangeToYearly && <PaypalYearly type={"yr"} />}
        {!isChangeToYearly && (
          <>
            {showNormalPaymentWithPaypal && <FormPayWithPaypal type={type} />}
            {/*monthly renew*/}
            {isRenewPaypal && <PriceRenewPaypal type={type} />}
          </>
        )}
      </Box>
      {(isPlanChange || isChangeToYearly) && <BillingCaption />}
    </>
  );
};

export default PaymentPaypalButton;
