import React from "react";
import { Box, Container, Divider, Grid, Paper } from "@material-ui/core";
import CurrentPlanSubscription from "src/views/management/Pricing/CurrentPlan/index";
import FormPaymentCustom from "src/views/management/Pricing/CustomPlan/FormPayment/index";
import { useSelector } from "react-redux";
import Header from "src/components/Header";
import CheckOutForm from "src/views/management/Pricing/CustomPlan/FormPayment/CheckOutForm";
import AppPaypalProvider from "src/views/management/Pricing/Context/PaypalContext";
import { makeStyles } from "@material-ui/styles";
import PlanUsageSubscription from "src/views/management/Pricing/PlanUsage/index";

const useStyle = makeStyles(theme => ({
  formLayout: {
    display: "grid",
    gridGap: theme.spacing(2),
    [theme.breakpoints.up(920)]: {
      gridTemplateColumns: "65% 35%"
    },
    [theme.breakpoints.down(920)]: {
      gridTemplateColumns: "100%"
    }
  }
}));

const CustomPlanLayout = ({ children }) => {
  const classes = useStyle();
  return <Box className={classes.formLayout}>{children}</Box>;
};

const CustomPlanPage = () => {
  const { defaultListing } = useSelector(state => state?.listing);

  return (
    <Container maxWidth={false}>
      <Header headerName={"Your Subscription Plan"} />

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper component={Box} p={2} style={{ position: "relative" }}>
            <CurrentPlanSubscription />
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper component={Box} p={2} style={{ height: "100%" }}>
            <PlanUsageSubscription />
          </Paper>
        </Grid>
      </Grid>

      <Box mt={2} mb={2}>
        <Divider />
      </Box>
      <AppPaypalProvider>
        <CustomPlanLayout>
          <FormPaymentCustom defaultType={defaultListing?.type} />
          <CheckOutForm />
        </CustomPlanLayout>
      </AppPaypalProvider>
    </Container>
  );
};

export default CustomPlanPage;
