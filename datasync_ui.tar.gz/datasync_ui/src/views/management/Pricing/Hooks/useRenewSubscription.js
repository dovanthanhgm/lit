import { useSelector } from "react-redux";

const useRenewSubscription = () => {
  const { subscription } = useSelector(state => state?.account?.user);
  const { defaultListing } = useSelector(state => state?.listing);

  const isRenew =
    ((["shopify"].includes(subscription?.user_plan?.payment_method) &&
      ["shopify"].includes(defaultListing?.type)) ||
      !!subscription?.user_plan?.paypal_subscription_id) &&
    subscription?.auto_renew;

  const isRenewWix =
    ["wix"].includes(subscription?.user_plan?.payment_method) &&
    ["wix"].includes(defaultListing?.type) &&
    subscription?.auto_renew;

  const isWixPayment =
    ["wix"].includes(subscription?.user_plan?.payment_method) &&
    ["wix"].includes(defaultListing?.type);

  return { isRenew, isRenewWix, isWixPayment };
};

export default useRenewSubscription;
