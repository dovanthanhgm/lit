import React, { useMemo } from "react";
import {
  Box,
  Grid,
  makeStyles,
  Typography,
  withStyles
} from "@material-ui/core";
import LinearProgress from "@material-ui/core/LinearProgress";
import { useSelector } from "react-redux";

const useStyles = makeStyles(theme => ({
  mrSmall: {
    marginRight: theme.spacing(1)
  }
}));

const BorderLinearProgress = withStyles(theme => ({
  root: {
    height: 10,
    borderRadius: 5
  },
  colorPrimary: {
    backgroundColor:
      theme.palette.grey[theme.palette.type === "light" ? 200 : 700]
  },
  bar: {
    borderRadius: 5,
    backgroundColor: "#1a90ff"
  }
}))(LinearProgress);

const BorderLinearProgressLimited = withStyles(theme => ({
  root: {
    height: 10,
    borderRadius: 5
  },
  colorPrimary: {
    backgroundColor:
      theme.palette.grey[theme.palette.type === "light" ? 200 : 700]
  },
  bar: {
    borderRadius: 5,
    backgroundColor: theme.palette.error.main
  }
}))(LinearProgress);

const GridPlanLabel = ({ children }) => {
  return (
    <Grid item md={5} lg={4} xl={3}>
      {children}
    </Grid>
  );
};

const GridPlanInfo = ({ children }) => {
  return (
    <Grid item md={7} lg={8} xl={9}>
      {children}
    </Grid>
  );
};

const PlanUsageSubscription = () => {
  const classes = useStyles();
  const { subscription, plan_history, nolimit_order } = useSelector(
    state => state?.account?.user
  );
  const user = useSelector(state => state?.account?.user);

  const productValueLimit = useMemo(() => {
    let productLimit =
      plan_history?.total_products >= 0 || subscription?.products_limit >= 0
        ? (`${plan_history?.total_products}` /
            `${subscription?.products_limit}`) *
          100
        : 0;
    return productLimit > 100;
  }, [plan_history, subscription]);

  const channelLimit = () => {
    return (user?.channels?.length - 1) / user?.subscription?.channels_limit;
  };

  return (
    <>
      <Box display="flex" pb={2}>
        <Box width="50%" justifyItems="flex-start" alignItems="center">
          <Typography align="left" variant="h5">
            Your Plan Usage
          </Typography>
        </Box>
      </Box>
      {!nolimit_order && (
        <Grid container spacing={3} alignItems="center">
          {subscription?.orders_limit !== 0 ? (
            <>
              <GridPlanLabel>
                <Box display="flex">
                  <Typography variant="h6" className={classes.mrSmall}>
                    Orders:
                  </Typography>
                  {plan_history?.total_orders >= 0 ||
                  subscription?.orders_limit >= 0 ? (
                    <Typography variant={"body2"}>
                      {plan_history?.total_orders}/{subscription?.orders_limit}
                    </Typography>
                  ) : (
                    ""
                  )}
                </Box>
              </GridPlanLabel>

              <GridPlanInfo>
                <BorderLinearProgress
                  variant="determinate"
                  value={
                    plan_history?.total_orders >= 0 ||
                    subscription?.orders_limit >= 0
                      ? (`${plan_history?.total_orders}` /
                          `${subscription?.orders_limit}`) *
                        100
                      : 0
                  }
                />
              </GridPlanInfo>
            </>
          ) : (
            <>
              <GridPlanLabel>
                <Box display="flex">
                  <Typography variant="h6" className={classes.mrSmall}>
                    Orders:{" "}
                    <Typography
                      variant="h6"
                      className={classes.mrSmall}
                      component={"span"}
                    >
                      Unlimited
                    </Typography>
                  </Typography>
                </Box>
              </GridPlanLabel>

              <GridPlanInfo />
            </>
          )}
        </Grid>
      )}

      <Grid container spacing={2} alignItems="center">
        {subscription?.products_limit !== 0 ? (
          <>
            <GridPlanLabel>
              <Box display="flex">
                <Typography variant="h6" className={classes.mrSmall}>
                  Total Listings:
                </Typography>
                {plan_history?.total_products >= 0 ||
                subscription?.products_limit >= 0 ? (
                  <Typography variant="body2">
                    {plan_history?.total_products}/
                    {subscription?.products_limit}
                  </Typography>
                ) : (
                  ""
                )}
              </Box>
            </GridPlanLabel>

            <GridPlanInfo>
              {!productValueLimit && (
                <BorderLinearProgress
                  variant="determinate"
                  value={
                    plan_history?.total_products >= 0 ||
                    subscription?.products_limit >= 0
                      ? (`${plan_history?.total_products}` /
                          `${subscription?.products_limit}`) *
                        100
                      : 0
                  }
                />
              )}
              {productValueLimit && (
                <BorderLinearProgressLimited
                  variant="determinate"
                  value={100}
                />
              )}
            </GridPlanInfo>
          </>
        ) : (
          <>
            <GridPlanLabel>
              <Box display="flex">
                <Typography variant="h6" className={classes.mrSmall}>
                  Total Listings:{" "}
                  <Typography
                    variant="h6"
                    className={classes.mrSmall}
                    component={"span"}
                  >
                    Unlimited
                  </Typography>
                </Typography>
              </Box>
            </GridPlanLabel>

            <GridPlanInfo />
          </>
        )}
        <GridPlanLabel>
          <Box display="flex">
            <Typography variant="h6" className={classes.mrSmall}>
              Total Channels:
            </Typography>
            <Typography variant="body2">
              {user?.channels?.length - 1}/{user?.subscription?.channels_limit}
            </Typography>
          </Box>
        </GridPlanLabel>
        <GridPlanInfo>
          {channelLimit() < 1 && (
            <BorderLinearProgress
              variant="determinate"
              value={channelLimit() * 100}
            />
          )}
          {channelLimit() >= 1 && (
            <BorderLinearProgressLimited variant="determinate" value={100} />
          )}
        </GridPlanInfo>
      </Grid>
    </>
  );
};

export default PlanUsageSubscription;
