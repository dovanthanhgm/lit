import { Box, makeStyles, Paper, Typography } from "@material-ui/core";
import clsx from "clsx";
import React from "react";
// import useMediaQuery from "@material-ui/core/useMediaQuery";

const useStyles = makeStyles(theme => ({
  product: {
    position: "relative",
    cursor: "pointer",
    transition: theme.transitions.create("transform", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    height: "100%",
    "&:hover": {
      transform: "scale(1.05)"
    }
  },
  recommendedProduct: {
    color: theme.palette.common.white,
    border: `1px solid ${theme.palette.secondary.main}`,
    height: "100%",
    backgroundColor: " rgba(0, 0, 255, 0.2)"
  },
  chooseButton: {
    backgroundColor: theme.palette.common.white
  },
  cardActions: {
    display: "flex",
    flexDirection: "row-reverse"
  },
  mrSmall: {
    marginRight: theme.spacing(1)
  },
  titleSubscription: {
    // eslint-disable-next-line
    ["@media (max-width:1370px)"]: { fontSize: 19 },
    height: 55
  },
  smaller: {
    cursor: "default",
    "&:hover": {
      transform: "scale(1)"
    }
  }
}));

function OnePlan({
  type,
  item,
  selected,
  handleClickOnePlane,
  noLimitOrder,
  isShopify = false,
  subscriptionMe
}) {
  const classes = useStyles();

  const isSmaller =
    item?.monthly_fee < subscriptionMe?.monthly_fee && !isShopify;
  const disabledSelect = isSmaller && !subscriptionMe.expired;

  // const renderUpto = useCallback(
  //   type => {
  //     const total = type === "orders" ? item.orders_limit : item.products_limit;
  //     if (total === 0) {
  //       return (
  //         <Typography variant="body1" color="textPrimary" align="center">
  //           Unlimited {type}
  //         </Typography>
  //       );
  //     }
  //
  //     if (noLimitOrder && type === "orders") {
  //       if (item.id === 1 || item.name === "Free Forever") {
  //         return (
  //           <Typography variant="body1" color="textPrimary" align="center">
  //             No Orders Sync
  //           </Typography>
  //         );
  //       }
  //       return (
  //         <Typography variant="body1" color="textPrimary" align="center">
  //           Unlimited {type}
  //         </Typography>
  //       );
  //     }
  //     return (
  //       <Typography variant="body1" color="textPrimary" align="center">
  //         Up to <strong>{total}</strong> {type}{" "}
  //         {type === "orders" ? "per month" : ""}
  //       </Typography>
  //     );
  //   },
  //   [item.orders_limit, item.products_limit, noLimitOrder, item.id, item.name]
  // );

  return (
    <Paper
      component={Box}
      p={2}
      pl={1}
      pr={1}
      className={clsx(
        classes.product,
        selected?.id === item.id ? classes.recommendedProduct : {},
        disabledSelect && classes.smaller
      )}
      style={{ opacity: disabledSelect ? 0.5 : 1 }}
      onClick={(!disabledSelect && handleClickOnePlane(item)) || function() {}}
      variant="outlined"
    >
      <Typography
        variant="h3"
        color="textPrimary"
        align="center"
        className={classes.titleSubscription}
      >
        {item.name.toUpperCase()}
      </Typography>
      <Box
        pt={2}
        pb={4}
        display="flex"
        alignItems="baseline"
        justifyContent="center"
      >
        <Typography variant="h3" color="textPrimary" align="center">
          ${type === "mo" ? item.monthly_fee : item.yearly_fee}
        </Typography>
        <Typography variant="h5" color="textPrimary" align="center">
          /{type}
        </Typography>
      </Box>

      {/*<Box mb={3}>{renderUpto("orders")}</Box>*/}

      {/*<Box mb={3}>*/}
      {/*  <Box mb={3}>{renderUpto("products")}</Box>*/}
      {/*</Box>*/}

      {item.features.map(item2 => {
        return (
          <Box
            mb={3}
            display="flex"
            alignItems="center"
            justifyContent="center"
            textAlign="center"
            key={item2}
          >
            <Typography variant="body2" color="textPrimary">
              {item2}
            </Typography>
          </Box>
        );
      })}
    </Paper>
  );
}

export default React.memo(OnePlan);
