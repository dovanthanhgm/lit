import React from "react";
import { Box, Container, Divider, Grid, Paper } from "@material-ui/core";
import CurrentPlanSubscription from "src/views/management/Pricing/CurrentPlan/index";
import PlanUsageSubscription from "src/views/management/Pricing/PlanUsage/index";
import ChoosePlan from "src/components/ChoosePlans";
import { useSelector } from "react-redux";
import useRenewSubscription from "src/views/management/Pricing/Hooks/useRenewSubscription";
import { useGetListSubscription } from "src/hooks/index";
import Header from "src/components/Header";

//wix only
const OldPlanLayout = () => {
  const { defaultListing } = useSelector(state => state?.listing);
  const { subscription } = useSelector(state => state?.account?.user);
  const { isRenew } = useRenewSubscription();

  const { lists, listsHigher } = useGetListSubscription();

  return (
    <Container maxWidth={false}>
      <Header headerName={"Your Subscription Plan"} />

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper component={Box} p={2} style={{ position: "relative" }}>
            <CurrentPlanSubscription />
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper component={Box} p={2} style={{ height: "100%" }}>
            <PlanUsageSubscription />
          </Paper>
        </Grid>
      </Grid>

      <Box mt={2} mb={2}>
        <Divider />
      </Box>

      <ChoosePlan
        lists={lists}
        isRenew={isRenew}
        subscriptionMe={subscription}
        listsHigher={listsHigher}
        defaultType={defaultListing?.type}
      />
    </Container>
  );
};

export default OldPlanLayout;
