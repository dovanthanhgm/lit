import React, { useCallback } from "react";
import { Box, Divider, Typography } from "@material-ui/core";
import ChangeYearly from "src/views/management/Pricing/ChangeYearly";
import FormPayWithPaypal from "src/views/management/Pricing/FormPayWithPaypal";
import FormPriceWithRenew from "src/views/management/Pricing/FormPriceWithRenew";
import PriceRenewPaypal from "src/views/management/Pricing/PriceRenewPaypal";
import { useSelector } from "react-redux";

const PaypalPricingForm = ({ plan, type, defaultType }) => {
  const {
    subscription
    // balance
  } = useSelector(state => state.account.user);
  const remainDayPlan = plan?.remaining_days;

  const grandTotalPlan = plan?.grand_total;

  const paypalSubscription = !!subscription?.user_plan?.paypal_subscription_id;
  const isRenewPlan = subscription?.user_plan?.auto_renew;
  const renderUpgradeTotal = subscription?.id !== plan?.id;
  const isRenewPaypal = isRenewPlan && paypalSubscription;

  const isChangeToYearly =
    subscription.yearly_paid === 0 &&
    type === "yr" &&
    !renderUpgradeTotal &&
    isRenewPlan;

  const isRenewSubscription = isRenewPlan && !isRenewPaypal;
  // const normalPay =
  //   !accountBalanceGreaterThanPlan() && !isRenewPlan && !isRenewPaypal;
  const showNormalPaymentWithPaypal = !isRenewPaypal && !isRenewPlan;

  const handleRenderTotalText = () => {
    if (renderUpgradeTotal) {
      return "Upgrade fee (instant payment)";
    } else {
      return ![undefined, null, 0, "0"].includes(grandTotalPlan)
        ? // if default not include shopify wix
          !["shopify", "wix"].includes(defaultType)
          ? "Setup Fee"
          : "Grand total"
        : "Total:";
    }
  };

  const renderFinalPrice = useCallback(() => {
    if (!plan) {
      return "--";
    }
    return `$${type === "mo" ? plan.monthly_fee : plan.yearly_fee}.00`;
  }, [plan, type]);

  return (
    <>
      <Divider />
      <Box pt={2} pb={2} display="flex" justifyContent="space-between">
        <Box>
          <Typography variant="body2">{handleRenderTotalText()}</Typography>
        </Box>
        <Typography variant="h4">
          {grandTotalPlan > 0 ? `$${grandTotalPlan}` : renderFinalPrice()}
        </Typography>
      </Box>

      {renderUpgradeTotal && (
        <>
          <Divider />
          <Box pt={2} pb={2} display="flex" justifyContent="space-between">
            <Typography variant="body2">
              Subscription Fee (pay on next cycle):
            </Typography>
            <Typography variant="body1">
              ${type === "yr" ? plan?.yearly_fee : plan?.monthly_fee}
            </Typography>
          </Box>
        </>
      )}
      <Box display="flex" justifyContent="center" width="100%" mt={2}>
        <Divider />
        {!!remainDayPlan && (
          <Typography variant="body2">
            (Current plan remaining days: {remainDayPlan})
          </Typography>
        )}
        {isChangeToYearly && <ChangeYearly plan={plan} type={"yr"} />}
        {!isChangeToYearly && (
          <>
            {showNormalPaymentWithPaypal && (
              <FormPayWithPaypal plan={plan} type={type} />
            )}

            {isRenewSubscription && (
              <FormPriceWithRenew plan={plan} isRenew={isRenewSubscription} />
            )}
            {isRenewPaypal && <PriceRenewPaypal plan={plan} type={type} />}
            {/*{normalPay && (*/}
            {/*  <FormClassicPayment*/}
            {/*    onPaySuccess={onPaySuccess}*/}

            {/*    setSubscriptionMe={setSubscriptionMe}*/}
            {/*    type={type}*/}
            {/*    plan={plan}*/}
            {/*  />*/}
            {/*)}*/}
          </>
        )}
      </Box>
    </>
  );
};

export default PaypalPricingForm;
