import React, { useState } from "react";
import {
  Box,
  Button,
  Grid,
  makeStyles,
  TextField,
  Typography
} from "@material-ui/core";
import { discountApply } from "../../../services/manage";
import { useSnackbar } from "notistack";

const useStyle = makeStyles(() => ({
  inputCode: {
    marginTop: 4
  }
}));

function Coupon({ plan, type, setPriceCoupon }) {
  const classes = useStyle();
  const [coupon, setCoupon] = useState("");
  const { enqueueSnackbar } = useSnackbar();

  const [submitCoupon, setSubmitCoupon] = useState(false);
  const [couponValid, setCouponValid] = useState(false);

  const handleApplyCoupon = async () => {
    try {
      const pricePlan = () => {
        if (type === "yr") {
          return plan?.yearly_fee;
        }
        return plan?.monthly_fee;
      };

      const body = {
        code: coupon,
        amount: pricePlan(),
        order_type: "plan"
      };
      const request = await discountApply({ body });
      if (request) {
        let result = request;
        result.finalPrice = request.total;
        result.coupon = coupon;
        setPriceCoupon(result);

        enqueueSnackbar(" Your discount code has been applied successfully", {
          variant: "success"
        });
      }
    } catch (e) {
      console.log(e.response);
      setPriceCoupon({});
      const message =
        e?.response?.data?.errors?.toString() ||
        e?.response?.data?.message?.toString() ||
        "error";
      enqueueSnackbar(message, {
        variant: "error"
      });
    }
  };

  const handleSubmit = () => {
    setSubmitCoupon(true);
    if (coupon.trim() === "") {
      setCouponValid(true);
    } else {
      handleApplyCoupon();
    }
  };

  const handleChangeCoupon = e => {
    const { value } = e.target;
    setCoupon(value);
    setCouponValid(false);
    setSubmitCoupon(false);
  };
  const helperText = (
    <Typography color="error">&#8593; coupon is empty</Typography>
  );

  return (
    <Box width={"100%"} mb={2}>
      <Grid container alignItems="center">
        <Grid item xs={3}>
          <Typography>Discount Code</Typography>
        </Grid>
        <Grid item xs={6}>
          <TextField
            className={classes.inputCode}
            autoFocus
            variant={"outlined"}
            value={coupon}
            margin="dense"
            error={submitCoupon && couponValid}
            onChange={handleChangeCoupon}
            type="email"
            fullWidth
          />
        </Grid>
        <Grid item xs={3} style={{ height: "100%" }}>
          <Box
            height="100%"
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            <Button
              onClick={handleSubmit}
              variant={"contained"}
              disabled={!plan}
              color="primary"
              // size="small"
            >
              Apply
            </Button>
          </Box>
        </Grid>
      </Grid>
      {couponValid && submitCoupon && (
        <Grid container alignItems="center">
          <Grid item xs={3} />
          <Grid item xs={6}>
            <Typography variant={"body2"} color="error">
              {helperText}
            </Typography>
          </Grid>
          <Grid item xs={3} />
        </Grid>
      )}
    </Box>
  );
}

export default Coupon;
