import React from "react";
import { useSnackbar } from "notistack";
import { PayPalButtons } from "@paypal/react-paypal-js";
import {
  approvePlanPayment,
  createSubscriptionPlan
} from "src/services/Pricing";
import wait from "src/utils/wait";
import { messageError } from "src/utils/ErrorResponse";
import { makeStyles } from "@material-ui/core";
import Cookies from "universal-cookie";

const cookies = new Cookies();

let CurrentToken = "";

const amount = "2";
const currency = "USD";
const style = { layout: "vertical", minHeight: 130, minWidth: "100%" };

const useStyles = makeStyles(() => ({
  customPaypalButton: {
    width: "100%"
  }
}));

const FormPayWithPaypal = ({ plan, type }) => {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const litCommerceBaseAPI = process.env?.REACT_APP_API_URL;
  const planPaypalId =
    type === "yr" ? plan?.paypal_yearly_plan_id : plan?.paypal_monthly_plan_id;

  return (
    <PayPalButtons
      disabled={false}
      // Button render if 1 of item change
      forceReRender={[amount, currency, style, plan, type, litCommerceBaseAPI]}
      fundingSource={undefined}
      style={style}
      className={classes.customPaypalButton}
      createSubscription={async (data, actions) => {
        try {
          const request = await createSubscriptionPlan({
            order_id: plan.id,
            orderData: { yearly_billing: type === "yr" }
          });
          if (request?.status < 400) {
            CurrentToken = request?.data?.token;
            await wait(1000);
            const createBody = request?.data?.paypal_body || {};
            const accessToken = cookies.get("accessToken");
            const newAccessToken = `JWT ${accessToken}`;

            if (!litCommerceBaseAPI || typeof litCommerceBaseAPI !== "string")
              return;
            // this function only work with fetch
            return fetch(
              litCommerceBaseAPI + "/api/payments/paypal/subscription/create",
              {
                method: "post",
                body: JSON.stringify({
                  ...createBody
                }),
                headers: {
                  "content-type": "application/json",
                  Authorization: newAccessToken
                }
              }
            )
              .then(function(res) {
                return res.json();
              })
              .then(function(serverData) {
                console.log(serverData);
                return serverData.id;
              });
            // return actions.subscription.create({
            //   ...createBody // Creates the subscription
            // });
          }
        } catch (e) {
          console.log(e);
          enqueueSnackbar(messageError(e, "Error Create subscription"), {
            variant: "error"
          });
        }
      }}
      // createOrder={data => {
      //   const payFunction = async () => {
      //     try {
      //       await sendPayment({
      //         type: "plan",
      //         orderData: {
      //           plan_id: planPaypalId || plan.id,
      //           yearly_paid: type === "yr"
      //         }
      //       });
      //       console.log(data);
      //     } catch (e) {
      //       console.log(e);
      //       console.log(e.response);
      //       enqueueSnackbar(messageError(e, "Error"), {
      //         variant: "error"
      //       });
      //     }
      //   };
      //   // console.log(data);
      //   return payFunction();
      // }}
      onApprove={(data, actions) => {
        const handleCapture = async () => {
          try {
            await approvePlanPayment({
              order_id: data.subscriptionID,
              type: "plan",
              token: CurrentToken,
              orderData: {
                plan_id: planPaypalId || plan?.id,
                yearly_paid: type === "yr"
              }
            });
            enqueueSnackbar("Success", {
              variant: "success"
            });
            await wait(1000);
            window.open("/subscription/change-success", "_self");
          } catch (e) {
            CurrentToken = "";
            console.log(e);
            enqueueSnackbar(messageError(e, "Error"), {
              variant: "error"
            });
          }
          CurrentToken = "";
        };
        return handleCapture();
      }}
    />
  );
};

export default FormPayWithPaypal;
