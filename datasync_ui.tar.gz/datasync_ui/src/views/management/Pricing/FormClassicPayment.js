import React, { useState } from "react";
import { useSnackbar } from "notistack";
import ButtonCustom from "src/components/MUI/Button";
import { isEmpty } from "lodash";
import { getSubscriptionPaymentAPI } from "src/services/manage";
import { useDispatch, useSelector } from "react-redux";
import { accountCancelSubscription, getUserInfo } from "src/services/account";
import { setUserData } from "src/actions/accountActions";
import { messageError } from "src/utils/ErrorResponse";

const FormClassicPayment = ({
  plan,
  type,
  onPaySuccess = function() {},
  setSubscriptionMe
}) => {
  const dispatch = useDispatch();
  const { subscription } = useSelector(state => state.account.user);
  const [loading, setLoading] = useState(false);
  const { enqueueSnackbar } = useSnackbar();

  const isRenew = subscription?.auto_renew;

  const typeChangeDetect = () => {
    const isMonth = subscription.yearly_paid === 1;
    return isMonth ? "yr" : "mo";
  };
  //có mây chỗ cần fix: nếu chọn plan hiện tại mà có auto renew 21/6/2023/slack 09:46 am
  const isHideWhenRenew =
    plan.id &&
    subscription?.id &&
    plan?.id === subscription?.id &&
    isRenew &&
    typeChangeDetect() === type;

  const renderButtonText = (plan, newPlan) => {
    const isSmaller = newPlan?.monthly_fee < plan?.monthly_fee;

    if (isSmaller) {
      return "downgrade plan & confirm payment";
    }
    if (plan.id && newPlan?.id && plan?.id === newPlan?.id) {
      return "extend plan & confirm payment";
    }
    return "upgrade plan & confirm payment";
  };

  const handleClickPlanId = async () => {
    setLoading(true);
    let body = {
      yearly_billing: type === "yr"
    };
    try {
      const data = await getSubscriptionPaymentAPI({
        plan_id: plan.id,
        body,
        isPaymentInStep3: !!onPaySuccess
      });
      if (data.code === 200 || data.code === "payment") {
        onPaySuccess && onPaySuccess({ isNotPayment: plan.id === 1 });
      } else {
        enqueueSnackbar("Ooops!", {
          variant: "error"
        });
      }
      data.code === "payment" && window.open(data.data, "_self");
      if (data.code === 200) {
        if (onPaySuccess) {
          return;
        }
        setSubscriptionMe && setSubscriptionMe(data.data);
        enqueueSnackbar("Success", {
          variant: "success"
        });
      }
    } catch (e) {
      console.log(e);
      const message =
        e?.response?.data?.message ||
        e?.response?.data?.errors ||
        "Payment fail";
      enqueueSnackbar(message, { variant: "error" });
    }
    setLoading(false);
  };

  //cancel for merchant only
  const handleCancelSubscription = async () => {
    try {
      setLoading(true);
      await accountCancelSubscription();
      const data = await getUserInfo();
      if (data) {
        dispatch(setUserData({ ...data }));
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Change subscription error"), {
        variant: "error"
      });
    }
    setLoading(false);
  };

  if (isHideWhenRenew) {
    return null;
  }

  if (plan.id === 1) {
    return (
      <ButtonCustom
        text={renderButtonText(subscription, plan)}
        color="primary"
        size="large"
        onClick={handleCancelSubscription}
        disabled={loading || isEmpty(plan)}
        notShowCircle={isEmpty(plan)}
      />
    );
  }

  return (
    <ButtonCustom
      text={renderButtonText(subscription, plan)}
      color="primary"
      size="large"
      onClick={handleClickPlanId}
      disabled={loading || isEmpty(plan)}
      notShowCircle={isEmpty(plan)}
    />
  );
};

export default FormClassicPayment;
