import React, { useState } from "react";
import { FREE_CHANNEL_LIMIT, FREE_LISTING_LIMIT } from "src/constants/index";
import { useSelector } from "react-redux";

export const PaypalContext = React.createContext({
  body: {},
  setListingLimit: function() {},
  setChannelLimit: function() {},
  listingLimit: FREE_LISTING_LIMIT,
  chanelLimit: FREE_CHANNEL_LIMIT,
  isPlanChange: false,
  planPrice: 0,
  setPlanPrice: function() {},
  oldPlanPrice: 0,
  setOldPlanPrice: function() {},
  isDownGradePlan: false
});

const AppPaypalProvider = ({ children }) => {
  const user = useSelector(state => state?.account?.user);
  const { subscription } = useSelector(state => state?.account?.user);

  const totalProducts =
    subscription?.products_limit !== 0 ? subscription?.products_limit : 0;

  const initListing = totalProducts || FREE_LISTING_LIMIT;
  const initChannel = user?.subscription?.channels_limit || FREE_CHANNEL_LIMIT;

  const [listingLimit, setListingLimit] = useState(initListing);
  const [chanelLimit, setChannelLimit] = useState(initChannel);
  // price only show inside upgrade plan
  const [planPrice, setPlanPrice] = useState(0);
  const [oldPlanPrice, setOldPlanPrice] = useState(0);

  const isPlanChange =
    listingLimit !== initListing || chanelLimit !== initChannel;

  const isDownGradePlan =
    listingLimit < initListing || chanelLimit < initChannel;

  return (
    <PaypalContext.Provider
      value={{
        body: {
          listingLimit,
          chanelLimit
        },
        setListingLimit,
        setChannelLimit,
        listingLimit,
        chanelLimit,
        isPlanChange,
        planPrice,
        setPlanPrice,
        oldPlanPrice,
        setOldPlanPrice,
        isDownGradePlan
      }}
    >
      {children}
    </PaypalContext.Provider>
  );
};

export default AppPaypalProvider;
