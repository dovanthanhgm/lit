import React from "react";
import ButtonCustom from "src/components/MUI/Button";
import { Box, useTheme } from "@material-ui/core";
import CancelSubscriptionModal from "src/views/management/Pricing/CancelSubscription/CancelSubscriptionModal";
import { useSelector } from "react-redux";

const CancelSubscription = ({ isRenew = false }) => {
  const theme = useTheme();
  const { user } = useSelector(state => state?.account);
  const isUserTrial = user.is_trial;

  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  if (isUserTrial) {
    return null;
  }

  return (
    <>
      {isRenew && (
        <Box position="absolute" bottom={12} right={12}>
          <ButtonCustom
            text="Cancel Subscription"
            style={{
              backgroundColor: theme.palette.error.main,
              color: "white"
            }}
            // className={classes.deleteButton}
            onClick={handleClickOpen}
            notShowCircle={true}
          />
        </Box>
      )}
      <CancelSubscriptionModal open={open} setOpen={setOpen} />
    </>
  );
};

export default CancelSubscription;
