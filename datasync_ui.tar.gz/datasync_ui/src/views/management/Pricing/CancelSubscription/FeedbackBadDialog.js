import React, { useState } from "react";
import {
  Box,
  Checkbox,
  DialogContent,
  FormControl,
  FormControlLabel,
  FormGroup,
  TextField,
  Typography
} from "@material-ui/core";
import { SadIcon } from "src/views/reports/Feedback/BadChoice";
import DialogActions from "@material-ui/core/DialogActions";
import { cancelSubscriptionFeedback } from "src/services/Pricing";
import { accountCancelSubscription, getUserInfo } from "src/services/account";
import { setUserData } from "src/actions/accountActions";
import { useDispatch } from "react-redux";
import { useSnackbar } from "notistack";
import ButtonCustom from "src/components/MUI/Button";

const FEATURE = "Not enough features/functionality";
const TECHNICAL = "Too many technical issues";
const SUPPORT = "Poor customer support";
const EXPENSIVE = "Too expensive";
const BETTER_APP = "Found a better app";
const OTHER = "Other";

const BAD_CHOICES = [FEATURE, TECHNICAL, SUPPORT, EXPENSIVE, BETTER_APP, OTHER];

const EXTRA_BAD_CHOICES = {
  [FEATURE]: "What features are you looking for?",
  [TECHNICAL]: "What issues are you facing?",
  [SUPPORT]: "How can we make it better?",
  [EXPENSIVE]: "What should be the better cost?",
  [BETTER_APP]: "How are they doing better?",
  [OTHER]: "Please specify:"
};

const FeedbackBadDialog = ({ handleClose = function() {} }) => {
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();

  const [voteItem, setVoteItem] = useState("");
  const [comment, setComment] = useState(null);
  const [comment1, setComment1] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmitFeedBack = async () => {
    try {
      setLoading(true);
      await accountCancelSubscription();
      const data = await getUserInfo();
      if (data) {
        dispatch(setUserData({ ...data }));
      }
      enqueueSnackbar("Cancel success", {
        variant: "success"
      });
      handleClose();
      await cancelSubscriptionFeedback({
        moreDetail: comment || "",
        more_details2: comment1 || "",
        survey: voteItem || ""
      });
    } catch (e) {}
    setLoading(false);
  };

  const handleChangeComment = e => {
    setComment(e.target.value);
  };

  const handleChangeComment1 = e => {
    setComment1(e.target.value);
  };

  const handleCheck = e => {
    setVoteItem(e.target.value);
  };

  return (
    <>
      <DialogContent>
        <Box textAlign="center" mb={2}>
          <SadIcon style={{ fontSize: 64 }} />
        </Box>
        <Typography variant="body2">
          If you have a moment, could you kindly share with us any feedback or
          concerns that led to your decision to cancel? We greatly appreciate
          any insights you can provide and we will use this feedback to
          continually improve our services.
        </Typography>
        <Box mt={1} />
        <FormControl>
          <Typography variant={"h6"}>
            1. What is your primary reason for uninstalling LitCommerce
            <span style={{ color: "red" }}>*</span>
          </Typography>
          <FormGroup aria-label="position">
            <Box
              pl={2}
              display="flex"
              flexDirection="column"
              alignItems="flex-start"
            >
              {BAD_CHOICES.map((badItem, index) => {
                return (
                  <FormControlLabel
                    onChange={handleCheck}
                    control={
                      <Checkbox
                        checked={badItem === voteItem}
                        size="small"
                        inputProps={{ "aria-label": "primary checkbox" }}
                      />
                    }
                    value={badItem}
                    label={badItem}
                  />
                );
              })}
            </Box>
          </FormGroup>
        </FormControl>
        <Typography variant="h6">
          {EXTRA_BAD_CHOICES?.[voteItem] || "More details about this reason?"}
        </Typography>
        <Box mt={0.5} />
        <TextField
          name="review"
          value={comment}
          onChange={handleChangeComment}
          variant="outlined"
          size={"small"}
          fullWidth
          multiline
          rows={4}
        />
        <Box mt={0.5} />
        <Typography variant={"h6"}>
          2. How else can we improve LitCommerce?
        </Typography>
        <TextField
          name="review"
          value={comment1}
          onChange={handleChangeComment1}
          variant="outlined"
          size={"small"}
          fullWidth
          multiline
          rows={4}
        />
        <Box mt={0.5} />
        {!!voteItem && (
          <Typography variant="h6">
            Thank you for your time, and we hope to have the opportunity to
            better serve you in the future.
          </Typography>
        )}
      </DialogContent>
      <DialogActions>
        <ButtonCustom
          onClick={handleSubmitFeedBack}
          color="primary"
          fullWidth
          style={{ marginRight: 16, marginLeft: 16 }}
          variant="contained"
          size="small"
          text={"Submit & Cancel Subscription"}
          notShowCircle={!(voteItem && comment && loading)}
          disabled={!voteItem || loading || !comment}
        />
      </DialogActions>
    </>
  );
};

export default FeedbackBadDialog;
