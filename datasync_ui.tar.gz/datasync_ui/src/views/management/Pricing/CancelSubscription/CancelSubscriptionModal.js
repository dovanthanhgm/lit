import React, { useState } from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import Button from "@material-ui/core/Button";
import { Typography } from "@material-ui/core";
import FeedbackBadDialog from "src/views/management/Pricing/CancelSubscription/FeedbackBadDialog";
import DialogTitle from "src/components/Modal/DialogTitle";

const CancelSubscriptionModal = ({ open, setOpen }) => {
  const [changeToFeedback, setChangeToFeedBack] = useState(false);

  const handleClose = () => {
    setOpen(false);
  };

  const handleCancelSubscription = async () => {
    setChangeToFeedBack(true);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullWidth
      maxWidth={changeToFeedback ? "sm" : "xs"}
    >
      <DialogTitle style={{ padding: "10px 16px" }}>
        <Typography
          variant="h5"
          style={{ textAlign: changeToFeedback ? "center" : "left" }}
        >
          {changeToFeedback
            ? "We are sorry to see you leave"
            : "Do you want to cancel subscription?"}
        </Typography>
      </DialogTitle>
      {changeToFeedback && <FeedbackBadDialog handleClose={handleClose} />}
      {!changeToFeedback && (
        <DialogActions>
          <Button
            onClick={handleCancelSubscription}
            color="primary"
            variant={"text"}
            size={"small"}
          >
            Accept
          </Button>

          <Button onClick={handleClose} variant={"text"} size={"small"}>
            Disagree
          </Button>
        </DialogActions>
      )}
    </Dialog>
  );
};

export default CancelSubscriptionModal;
