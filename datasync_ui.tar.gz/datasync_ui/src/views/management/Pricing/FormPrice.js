import { Box, Paper, Typography } from "@material-ui/core";
import React, { useCallback } from "react";
import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import MerchantPricingForm from "src/views/management/Pricing/MerchantPricingForm";
import PaypalPricingForm from "src/views/management/Pricing/PaypalPricingForm";
import useMerchantPayment from "src/hooks/Subscription/useMerchantPayment";
import BillingTime from "src/views/management/Pricing/Component/BillingTime";

// function addZeroes(num) {
//   const dec = num.toString().split(".")[1];
//   const len = dec && dec.length > 2 ? dec.length : 2;
//   return Number(num).toFixed(len);
// }

function PricingView({
  setType,
  type,
  plan,
  setSubscriptionMe,
  onPaySuccess,
  isDisableMonth,
  defaultType
}) {
  const { isLoginMerchant } = useMerchantPayment({ defaultType });
  const initialOptions = {
    "client-id": process.env.REACT_APP_CLIENT_PAYPAL,
    vault: true
  };

  const handleSelectBillingType = i => () => {
    setType(i);
  };

  const renderPriceTotal = useCallback(() => {
    if (!plan) {
      return "--";
    }
    if (type === "mo") {
      return `$${plan.monthly_fee}.00/ month`;
    }

    return `$${plan.monthly_fee * 12}.00/ year`;
  }, [plan, type]);

  return (
    <Paper component={Box} p={2} style={{ height: "100%" }}>
      <PayPalScriptProvider options={initialOptions}>
        <Typography variant="h5" color="textPrimary">
          Your Price
        </Typography>
        <BillingTime
          type={type}
          handleSelectBillingType={handleSelectBillingType}
          isDisableMonth={isDisableMonth}
        />

        <Box py={2}>
          <Typography variant="body2" color="textPrimary">
            {renderPriceTotal()}
          </Typography>
        </Box>

        {plan && isLoginMerchant && (
          <MerchantPricingForm
            type={type}
            plan={plan}
            setSubscriptionMe={setSubscriptionMe}
            onPaySuccess={onPaySuccess}
          />
        )}
        {plan?.id !== 1 && plan && (
          <>
            {!isLoginMerchant && (
              <PaypalPricingForm
                type={type}
                plan={plan}
                defaultType={defaultType}
              />
            )}
          </>
        )}
      </PayPalScriptProvider>
    </Paper>
  );
}

export default PricingView;
