import React from "react";
import FormClassicPayment from "src/views/management/Pricing/FormClassicPayment";

const FormWithLoginMerchant = ({
  plan,
  type,
  onPaySuccess,
  setSubscriptionMe
}) => {
  return (
    <FormClassicPayment
      plan={plan}
      type={type}
      onPaySuccess={onPaySuccess}
      setSubscriptionMe={setSubscriptionMe}
    />
  );
};

export default FormWithLoginMerchant;
