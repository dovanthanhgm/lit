import React, { useState } from "react";
import { useSelector } from "react-redux";
import { isEmpty } from "lodash";
import ButtonCustom from "src/components/MUI/Button";
import { handleUpdatePlanForAutoRenew } from "src/services/manage";
import { messageError } from "src/utils/ErrorResponse";
import { useSnackbar } from "notistack";
import { Button } from "@material-ui/core";
import { ModalUpdatePaypal } from "src/views/management/Pricing/PriceRenewPaypal";

const HandleChangeYearly = ({ plan }) => {
  const { enqueueSnackbar } = useSnackbar();

  const handleUpGradePlanRenew = async ({ plan }) => {
    try {
      const request = await handleUpdatePlanForAutoRenew({
        plan_id: plan.id
      });
      if (request.data) {
        window.open(request.data.url, "_self");
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Error payment"), { variant: "error" });
    }
  };

  return (
    <ButtonCustom
      text={"Upgrade Subscription"}
      color="primary"
      size="large"
      onClick={() => handleUpGradePlanRenew({ plan })}
      disabled={isEmpty(plan)}
      notShowCircle={isEmpty(plan)}
    />
  );
};

const PaypalYearly = ({ plan, type }) => {
  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Button variant="contained" color="primary" onClick={handleOpen}>
        upgrade plan & confirm payment
      </Button>
      {open && (
        <ModalUpdatePaypal
          plan={plan}
          type={type}
          handleClose={handleClose}
          open={open}
          updateMonthly
        />
      )}
    </>
  );
};

const ChangeYearly = ({ plan }) => {
  const type = "yr";
  const { subscription } = useSelector(state => state.account.user);
  const isRenewPlan = subscription?.user_plan?.auto_renew;
  const paypalSubscription = true;
  const isRenewPaypal = isRenewPlan && paypalSubscription;
  const isRenewSubscription = isRenewPlan && !isRenewPaypal;

  if (isRenewSubscription) {
    return <HandleChangeYearly plan={plan} />;
  }
  if (isRenewPaypal) {
    return <PaypalYearly type={type} plan={plan} />;
  }
  return <></>;
};

export default ChangeYearly;
