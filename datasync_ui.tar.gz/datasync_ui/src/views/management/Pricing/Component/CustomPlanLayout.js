import React from "react";
import { Box } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";

const useStyle = makeStyles(theme => ({
  formLayout: {
    display: "grid",
    gridGap: theme.spacing(2),
    [theme.breakpoints.up(920)]: {
      gridTemplateColumns: "70% 30%"
    },
    [theme.breakpoints.down(920)]: {
      gridTemplateColumns: "100%"
    }
  }
}));

const CustomPlanLayout = ({ children }) => {
  const classes = useStyle();
  return <Box className={classes.formLayout}>{children}</Box>;
};

export default CustomPlanLayout;
