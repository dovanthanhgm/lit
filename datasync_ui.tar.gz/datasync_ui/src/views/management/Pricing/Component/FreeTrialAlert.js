import React from "react";
import SingleAlert from "src/components/Notify/SingleAlert";
import { useSelector } from "react-redux";

const FreeTrialAlert = () => {
  const { user } = useSelector(state => state?.account);
  const isUserTrial = user?.is_trial;
  //chir show ở dashboard
  if (isUserTrial && window.location.pathname === "/") {
    return (
      <SingleAlert
        content={
          "Your 14-day Free Trial has started with access to all functionalities."
        }
        type={"success"}
      />
    );
  }
  return null;
};

export default FreeTrialAlert;
