import React from "react";
import { Box, Typography } from "@material-ui/core";

const BillingCaption = () => {
  return (
    <Box textAlign={"center"} mt={1.5}>
      <Typography variant={"body2"}>
        By clicking, you are confirming your enrollment in our auto-renewal
        service. On this page, you have the option to cancel your subscription,
        choose a different subscription level, or adjust your billing frequency.
        Please note that automatic renewals will be charged to your selected
        payment method until you choose to cancel.
      </Typography>
    </Box>
  );
};

export default BillingCaption;
