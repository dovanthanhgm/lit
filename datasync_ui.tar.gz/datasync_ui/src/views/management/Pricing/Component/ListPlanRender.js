import React from "react";
import { makeStyles } from "@material-ui/styles";
import { Box } from "@material-ui/core";

const useStyle = makeStyles(theme => ({
  gridContainer: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr",
    gridGap: theme.spacing(2)
  },
  gridContainerHigh: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr",
    gridGap: theme.spacing(2)
  }
}));

const ListPlanRender = ({ showHigh = false, children }) => {
  const classes = useStyle();
  return (
    <Box
      className={showHigh ? classes.gridContainerHigh : classes.gridContainer}
    >
      {children}
    </Box>
  );
};

export default ListPlanRender;
