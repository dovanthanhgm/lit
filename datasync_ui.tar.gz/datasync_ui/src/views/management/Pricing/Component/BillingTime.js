import React from "react";
import { Box, Chip, makeStyles, Typography } from "@material-ui/core";
import clsx from "clsx";
import { showEndYearSale } from "src/constants/index";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(3),
    paddingBottom: 100
  },
  product: {
    position: "relative",
    cursor: "pointer",
    transition: theme.transitions.create("transform", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    height: "100%",
    "&:hover": {
      transform: "scale(1.05)"
    }
  },
  recommendedProduct: {
    color: theme.palette.common.white,
    border: `1px solid ${theme.palette.secondary.main}`,
    height: "100%"
  },
  chooseButton: {
    backgroundColor: theme.palette.common.white
  },
  cardActions: {
    display: "flex",
    flexDirection: "row-reverse"
  },
  mrSmall: {
    marginRight: theme.spacing(1)
  },
  titleSubscription: {
    height: 60
  },
  button: {
    cursor: "pointer",
    borderRadius: 4
  },
  buttonSelected: {
    border: `1px solid ${theme.palette.secondary.main}`
  },
  buttonProgress: {
    position: "absolute",
    margin: "auto"
  },
  disableButtonPlanType: {
    cursor: "default",
    opacity: 0.5
  },
  customPaypalButton: {
    width: "100%"
  }
}));

const BillingTime = ({ type, isDisableMonth, handleSelectBillingType }) => {
  const classes = useStyles();

  return (
    <>
      <Box p={2} display="flex" justifyContent="space-around">
        <Box
          bgcolor="background.dark"
          p={2}
          className={clsx(
            classes.button,
            classes.mrSmall,
            type === "mo"
              ? classes.buttonSelected
              : isDisableMonth
              ? classes.disableButtonPlanType
              : {}
          )}
          onClick={
            isDisableMonth ? function() {} : handleSelectBillingType("mo")
          }
        >
          <Typography variant="h4" color="textPrimary" align="center">
            Monthly Billing
          </Typography>
        </Box>

        <Box
          bgcolor="background.dark"
          p={2}
          className={clsx(
            classes.button,
            type === "yr" ? classes.buttonSelected : {}
          )}
          onClick={handleSelectBillingType("yr")}
        >
          <Typography variant="h4" color="textPrimary" align="center">
            Yearly Billing{" "}
            <Chip
              label="30% off"
              color={"secondary"}
              style={{
                backgroundColor: "#f44336",
                color: "white"
              }}
            />
            {/*<Typography*/}
            {/*  component="span"*/}
            {/*  variant="h5"*/}
            {/*  style={{ color: SALE_PLAN_COLOR }}*/}
            {/*>*/}
            {/*  (30% off)*/}
            {/*</Typography>*/}
          </Typography>
        </Box>
      </Box>

      {!showEndYearSale && (
        <Typography component="span" variant="body2" color="textPrimary">
          <Typography display="inline" variant="h6">
            Get 2 months free&nbsp;
          </Typography>
          Get 2 months free when you choose annual billing, which requires a one
          year commitment
        </Typography>
      )}
      {showEndYearSale && (
        <Box textAlign={"center"}>
          <Typography
            component="span"
            variant="body2"
            color="textPrimary"
            align={"center"}
          >
            <Typography variant="h6" component="span">
              Get 30% off
            </Typography>
            &nbsp;when you choose annual billing, which requires a one year
            commitment.
          </Typography>
        </Box>
      )}
    </>
  );
};

export default BillingTime;
