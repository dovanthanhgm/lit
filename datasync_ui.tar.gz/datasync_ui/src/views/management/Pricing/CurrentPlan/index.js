import React from "react";
import { Box, Link, makeStyles, Typography } from "@material-ui/core";
import CancelSubscription from "src/views/management/Pricing/CancelSubscription/CancelSubscription";
import moment from "moment";
import useRenewSubscription from "src/views/management/Pricing/Hooks/useRenewSubscription";
import { useSelector } from "react-redux";
import PlanStatusChip, {
  FREE_TRIAL_CANCEL_STATUS,
  FREE_TRIAL_EXPIRED_STATUS,
  FREE_TRIAL_STATUS
} from "src/views/management/Pricing/CurrentPlan/PlanStatusChip";
import { handleCancelledStatus } from "src/helper/PricingHelper";
import useUserExp from "src/hooks/useUserExp";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(3),
    paddingBottom: 100
  },
  product: {
    position: "relative",
    cursor: "pointer",
    transition: theme.transitions.create("transform", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    height: "100%",
    "&:hover": {
      transform: "scale(1.05)"
    }
  },
  recommendedProduct: {
    color: theme.palette.common.white,
    border: `1px solid ${theme.palette.secondary.main}`,
    height: "100%"
  },
  chooseButton: {
    backgroundColor: theme.palette.common.white
  },
  mrSmall: {
    marginRight: theme.spacing(1)
  }
}));

const CurrentPlanSubscription = () => {
  const classes = useStyles();
  const { isRenew, isRenewWix } = useRenewSubscription();
  const { isUserFree } = useUserExp();
  const { subscription } = useSelector(state => state?.account?.user);
  const { user } = useSelector(state => state?.account);
  const isUserTrial = user.is_trial;
  const userExpired = user?.is_expired;
  const userEndTrial = user?.subscription?.user_plan?.cancelled_at;

  const handlePlanData = () => {
    const channelLimit = subscription?.channels_limit;
    const productLimit = subscription?.products_limit;

    const stringProductLimit =
      productLimit && typeof productLimit === "number"
        ? productLimit / 1000 < 1
          ? "20 Listings"
          : productLimit / 1000 + "k Listings"
        : 0;

    if (!channelLimit && !stringProductLimit) {
      return "";
    }
    if (!channelLimit) {
      return stringProductLimit;
    }
    if (!stringProductLimit) {
      return `${channelLimit} Channels`;
    }
    return `${channelLimit} Channels, ${stringProductLimit}`;
  };

  const handlePlanPrice = () => {
    if (isUserTrial) return "";
    const fee = subscription.user_plan?.subscription_fee;
    const monthlyFee = subscription?.monthly_fee;
    const yearlyFee = subscription?.yearly_fee;
    if (!fee && (!!monthlyFee || !!yearlyFee)) {
      return subscription?.yearly_paid === 1 && !!yearlyFee
        ? `$${yearlyFee}/y`
        : `$${monthlyFee}/m`;
    }
    return subscription.user_plan?.subscription_fee;
  };

  const handleBilling = () => {
    if (isUserTrial) return "";
    if (isUserFree) return "";
    return subscription?.yearly_paid === 1 ? "Yearly" : "Monthly";
  };

  const handlePlanExpired = () => {
    // Free Trial thiếu expired date:
    return moment(subscription?.expired_at).format("LL");
  };

  const handleChipStatus = () => {
    if (userExpired && isUserTrial) {
      return FREE_TRIAL_EXPIRED_STATUS;
    }
    if (handleCancelledStatus(userEndTrial)) {
      return FREE_TRIAL_CANCEL_STATUS;
    }
    if (isUserTrial) {
      return FREE_TRIAL_STATUS;
    }
    return "";
  };

  return (
    <>
      <CancelSubscription isRenew={isRenew && !isRenewWix} />

      {isRenewWix && (
        <Box position="absolute" bottom={12} right={12}>
          <Link
            href={
              "https://support.wix.com/en/article/canceling-an-app-subscription"
            }
          >
            <Typography variant="body2">How to cancel my plan</Typography>
          </Link>
        </Box>
      )}
      <Box pb={1}>
        <Typography variant="h5">Your Current Plan</Typography>
      </Box>

      <Box display="flex" pt={1} alignItems={"center"}>
        <Typography className={classes.mrSmall} variant={"body2"}>
          Plan:
        </Typography>
        <Typography variant="h6">{handlePlanData()}</Typography>
        <Box mx={0.5} />
        <PlanStatusChip status={handleChipStatus()} />
      </Box>
      <Box display="flex" pt={user.is_trial ? 0.75 : 1}>
        <Typography className={classes.mrSmall} variant={"body2"}>
          Plan Price:
        </Typography>
        <Typography variant="h6">
          {handlePlanPrice()}
          {/*{subscription?.yearly_paid === 1*/}
          {/*  ? subscription?.yearly_fee >= 0*/}
          {/*    ? `$${subscription?.yearly_fee}/y`*/}
          {/*    : "0"*/}
          {/*  : !subscription?.monthly_fee >= 0*/}
          {/*  ? `$${subscription?.monthly_fee}/m`*/}
          {/*  : "0"}*/}
        </Typography>
      </Box>
      <Box display="flex" pt={1}>
        <Typography className={classes.mrSmall} variant={"body2"}>
          {isRenew ? "Billing on:" : "Billing Frequency:"}&nbsp;
        </Typography>
        <Typography variant="h6">
          &nbsp;
          {handleBilling()}
        </Typography>
      </Box>
      {subscription?.expired_at && (
        <Box display="flex" pt={1}>
          <Typography className={classes.mrSmall} variant={"body2"}>
            {isRenew ? "Next billing time" : "Expired at"}:&nbsp;
          </Typography>
          <Typography variant="h6">{handlePlanExpired()}</Typography>
        </Box>
      )}
    </>
  );
};

export default CurrentPlanSubscription;
