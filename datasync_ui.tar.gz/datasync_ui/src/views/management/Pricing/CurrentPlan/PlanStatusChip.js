import React from "react";
import { Chip } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import { green, orange, red } from "@material-ui/core/colors";

export const FREE_TRIAL_STATUS = "freeTrial";
export const FREE_TRIAL_EXPIRED_STATUS = "freeTrialExpired";
export const FREE_TRIAL_CANCEL_STATUS = "freeTrialCancel";

const useStyles = makeStyles(() => ({
  freeTrialStyle: {
    color: "white",
    backgroundColor: green[500]
  },
  expiredTrialStyle: {
    color: "white",
    backgroundColor: orange[500]
  },
  cancelTrialStyle: {
    color: "white",
    backgroundColor: red[500]
  }
}));

const PlanStatusChip = ({ status }) => {
  const classes = useStyles();
  const statusChip = {
    [FREE_TRIAL_STATUS]: (
      <Chip
        size={"small"}
        label="Free Trial"
        className={classes.freeTrialStyle}
      />
    ),
    [FREE_TRIAL_EXPIRED_STATUS]: (
      <Chip
        size={"small"}
        label="Free Trial Expired"
        className={classes.expiredTrialStyle}
      />
    ),
    [FREE_TRIAL_CANCEL_STATUS]: (
      <Chip
        size={"small"}
        label="Cancelled"
        className={classes.cancelTrialStyle}
      />
    )
  };

  if (!statusChip?.[status]) {
    return null;
  }
  return statusChip?.[status];
};

export default PlanStatusChip;
