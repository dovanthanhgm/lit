import { Box, makeStyles } from "@material-ui/core";
import React from "react";
import LoadingScreen from "src/components/Loading/LoadingScreen";
import Page from "src/components/Page";
import { useLocation, useParams } from "react-router";
import { useSelector } from "react-redux";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";
import { Alert } from "@material-ui/lab";
import OldPlanLayout from "src/views/management/Pricing/PlanLayout/index";
import CustomPlanPage from "src/views/management/Pricing/CustomPlan/index";
import useRenewSubscription from "src/views/management/Pricing/Hooks/useRenewSubscription";

const RENEW_WIX = "RENEW_WIX";
const CUSTOM_PLAN = "CUSTOM_PLAN";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "50%",
    paddingTop: theme.spacing(3),
    paddingBottom: theme.spacing(1)
  }
}));

function PricingView() {
  const classes = useStyles();
  const { plan_history, subscription } = useSelector(
    state => state?.account?.user
  );
  const { isWixPayment } = useRenewSubscription();

  const location = useLocation();
  const { option } = useParams();

  const handleRenderPlan = () => {
    if (isWixPayment) {
      return RENEW_WIX;
    }
    return CUSTOM_PLAN;
  };

  if (!plan_history || !subscription) {
    return <LoadingScreen />;
  }

  const choiceOption = {
    "change-error": {
      content: `Payment cancelled`,
      type: "error"
    },
    "change-success": {
      content: `Your Plan was successfully updated`,
      type: "success"
    }
  };

  return (
    <Page className={classes.root} title="Your Subscription" noPadding>
      <ErrorBoundaryComponent>
        {location.pathname === `/subscription/${option}` && (
          <Box my={0.5} px={3}>
            <Alert severity={choiceOption[option]?.type}>
              {choiceOption[option]?.content}
            </Alert>
          </Box>
        )}

        {handleRenderPlan() === RENEW_WIX && <OldPlanLayout />}
        {handleRenderPlan() === CUSTOM_PLAN && <CustomPlanPage />}
      </ErrorBoundaryComponent>
    </Page>
  );
}

export default PricingView;
