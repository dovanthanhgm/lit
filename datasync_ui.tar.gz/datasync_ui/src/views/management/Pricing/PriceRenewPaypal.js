import React, { useCallback, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  Divider,
  makeStyles,
  Paper,
  Typography
} from "@material-ui/core";
import DialogTitle from "src/components/Modal/DialogTitle";
import {
  approvePlanPayment,
  createSubscriptionPlan
} from "src/services/Pricing";
import wait from "src/utils/wait";
import { messageError } from "src/utils/ErrorResponse";
import { PayPalButtons } from "@paypal/react-paypal-js";
import { useSnackbar } from "notistack";
// import { accountCancelSubscription } from "src/services/account";
import { useSelector } from "react-redux";
import Cookies from "universal-cookie";

const cookies = new Cookies();

let CurrentToken = "";

const amount = "2";
const currency = "USD";
const style = { layout: "vertical", minHeight: 130, minWidth: "100%" };

const useStyles = makeStyles(() => ({
  customPaypalButton: {
    width: "100%"
  }
}));

const UpgradeInfo = ({ plan, type, updateMonthly = false }) => {
  const remainDayPlan = plan?.remaining_days;
  const grandTotalPlan = plan?.grand_total;

  const renderPriceTotal = useCallback(() => {
    if (!plan) {
      return "--";
    }
    if (type === "mo") {
      return `$${plan?.monthly_fee}.00/ month`;
    }

    return `$${plan?.monthly_fee * 12}.00/ year`;
  }, [plan, type]);

  const handleRenderTotalText = () => {
    return "Upgrade fee (instant payment)";
  };

  // const renderDiscount = useCallback(() => {
  //   if (!plan) {
  //     return "--";
  //   }
  //   return `-$${type === "mo" ? "0" : plan.monthly_fee * 2}.00`;
  // }, [plan, type]);

  const renderFinalPrice = useCallback(() => {
    if (!plan) {
      return "--";
    }
    return `$${type === "mo" ? plan.monthly_fee : plan.yearly_fee}.00`;
  }, [plan, type]);

  return (
    <Paper style={{ padding: 8, minWidth: 400 }}>
      <Box py={2}>
        <Typography variant="body1" color="textPrimary">
          {renderPriceTotal()}
        </Typography>
      </Box>
      {/*<Divider />*/}
      {/*<Box pt={2} pb={2} display="flex" justifyContent="space-between">*/}
      {/*  <Typography variant="body1">Annual billing discount</Typography>*/}
      {/*  <Typography variant="body1">{renderDiscount()}</Typography>*/}
      {/*</Box>*/}
      {/*<Box pt={2} pb={2} display="flex" justifyContent="space-between">*/}
      {/*  <Typography variant="body1">Coupon Discount:</Typography>*/}
      {/*  <Typography variant="body1">*/}
      {/*    -{renderTotal(priceApplyCoupon?.discount)}*/}
      {/*  </Typography>*/}
      {/*</Box>*/}
      {!!remainDayPlan && !updateMonthly && (
        <>
          <Divider />
          <Box pt={2} pb={2} display="flex" justifyContent="space-between">
            <Typography variant="body2">Remaining days:</Typography>
            <Typography variant="body2">{remainDayPlan}</Typography>
          </Box>
          <Divider />
        </>
      )}
      {!updateMonthly && (
        <Box pt={2} pb={2} display="flex" justifyContent="space-between">
          <Box>
            <Typography variant="body2">{handleRenderTotalText()}</Typography>
          </Box>
          <Typography variant="h4">
            {grandTotalPlan > 0 ? grandTotalPlan : renderFinalPrice()}
          </Typography>
        </Box>
      )}
      <Divider />
      <Box pt={2} pb={2} display="flex" justifyContent="space-between">
        <Typography variant="body2">
          Subscription Fee (pay on next cycle):
        </Typography>
        <Typography variant="body1">
          {type === "yr" ? plan?.yearly_fee : plan?.monthly_fee}
        </Typography>
      </Box>
    </Paper>
  );
};

export const ModalUpdatePaypal = ({
  plan,
  type,
  handleClose = function() {},
  open,
  updateMonthly = false
}) => {
  const [isApprove, setIsApprove] = useState(false);
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const litCommerceBaseAPI = process.env?.REACT_APP_API_URL;

  const planPaypalId =
    type === "yr" ? plan?.paypal_yearly_plan_id : plan?.paypal_monthly_plan_id;

  const handleOnApprove = () => {
    setIsApprove(true);
  };

  return (
    <Box mt={1}>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle onClose={handleClose}>{"Upgrade Plan"}</DialogTitle>
        <DialogContent>
          {isApprove && (
            <UpgradeInfo
              plan={plan}
              type={type}
              updateMonthly={updateMonthly}
            />
          )}
          {!isApprove && (
            <>
              {!updateMonthly && (
                <Typography variant="body2">
                  To upgrade your plan, your current plan will be cancelled and
                  you will subscribe to a new plan. If you choose a higher plan,
                  we will charge the difference for the remaining days of the
                  current cycle (On paypal this is called: One Time Setup), and
                  you will start paying for the new subscription at the
                  beginning of the next billing cycle.
                </Typography>
              )}
              {updateMonthly && (
                <Typography variant="body2">
                  To upgrade your plan, your current plan will be cancelled and
                  you will subscribe to a new plan. You will start paying for
                  the new subscription at the beginning of the next billing
                  cycle.
                </Typography>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions
          style={{ justifyContent: isApprove ? "center" : "flex-end" }}
        >
          {isApprove && (
            <PayPalButtons
              disabled={false}
              // Button render if 1 of item change
              forceReRender={[amount, currency, style, plan, type]}
              fundingSource={undefined}
              style={style}
              className={classes.customPaypalButton}
              createSubscription={async (data, actions) => {
                try {
                  // api nay da co is upgraded nen khong can cancel truoc
                  // await accountCancelSubscription();
                  // await wait(1500);
                  const request = await createSubscriptionPlan({
                    order_id: plan.id,
                    orderData: { yearly_billing: type === "yr" },
                    isUpgraded: true
                  });
                  if (request?.status < 400) {
                    CurrentToken = request?.data?.token;
                    await wait(1000);
                    const createBody = request?.data?.paypal_body || {};
                    const accessToken = cookies.get("accessToken");
                    const newAccessToken = `JWT ${accessToken}`;

                    if (
                      !litCommerceBaseAPI ||
                      typeof litCommerceBaseAPI !== "string"
                    )
                      return;
                    // this function only work with fetch
                    return fetch(
                      litCommerceBaseAPI +
                        "/api/payments/paypal/subscription/create",
                      {
                        method: "post",
                        body: JSON.stringify({
                          ...createBody
                        }),
                        headers: {
                          "content-type": "application/json",
                          Authorization: newAccessToken
                        }
                      }
                    )
                      .then(function(res) {
                        return res.json();
                      })
                      .then(function(serverData) {
                        console.log(serverData);
                        return serverData.id;
                      });
                    // return actions.subscription.create({
                    //   ...createBody // Creates the subscription
                    // });
                  }
                } catch (e) {
                  console.log(e);
                  enqueueSnackbar(
                    messageError(e, "Error Create subscription"),
                    {
                      variant: "error"
                    }
                  );
                }
              }}
              onApprove={(data, actions) => {
                const handleCapture = async () => {
                  try {
                    await approvePlanPayment({
                      order_id: data.subscriptionID,
                      type: "plan",
                      token: CurrentToken,
                      orderData: {
                        plan_id: planPaypalId || plan?.id,
                        yearly_paid: type === "yr"
                      }
                    });
                    enqueueSnackbar("Success", {
                      variant: "success"
                    });
                    await wait(1000);
                    window.location.reload();
                  } catch (e) {
                    handleClose();
                    CurrentToken = "";
                    console.log(e);
                    enqueueSnackbar(messageError(e, "Error"), {
                      variant: "error"
                    });
                  }
                  handleClose();
                  CurrentToken = "";
                };
                return handleCapture();
              }}
            />
          )}
          {!isApprove && (
            <>
              <Button onClick={handleClose} variant="contained" size="small">
                Back
              </Button>
              <Button
                onClick={handleOnApprove}
                variant="contained"
                color="primary"
                size="small"
                autoFocus
              >
                Approve
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </Box>
  );
};

const PriceRenewPaypal = ({ plan, type }) => {
  const [open, setOpen] = useState(false);
  const { subscription } = useSelector(state => state.account.user);

  const handleShowAutoRenew = () => {
    return subscription?.id === plan?.id;
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  if (handleShowAutoRenew()) {
    return (
      <Box mt={1}>
        <Typography variant="body2">
          Your subscription will automatically renew when it expires.
        </Typography>
      </Box>
    );
  }

  return (
    <>
      <Button
        variant="contained"
        style={{ backgroundColor: "#ffc439" }}
        onClick={handleOpen}
      >
        upgrade plan & confirm payment
      </Button>
      {open && (
        <ModalUpdatePaypal
          plan={plan}
          type={type}
          handleClose={handleClose}
          open={open}
        />
      )}
    </>
  );
};

export default PriceRenewPaypal;
