import React from "react";
import { Box, Typography } from "@material-ui/core";
import ButtonCustom from "src/components/MUI/Button";
import { isEmpty } from "lodash";
import { messageError } from "src/utils/ErrorResponse";
import { handleUpdatePlanForAutoRenew } from "src/services/manage";
import { useSnackbar } from "notistack";
import { useSelector } from "react-redux";

const FormPriceWithRenew = ({ plan, isRenew = false }) => {
  const { enqueueSnackbar } = useSnackbar();
  const { subscription } = useSelector(state => state.account.user);

  const handleShowAutoRenew = () => {
    if (!isRenew) return false;
    return subscription?.id === plan?.id;
  };

  const handleUpGradePlanRenew = async ({ plan }) => {
    try {
      const request = await handleUpdatePlanForAutoRenew({
        plan_id: plan.id
      });
      if (request.data) {
        window.open(request.data.url, "_self");
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Error payment"), { variant: "error" });
    }
  };

  return (
    <>
      {handleShowAutoRenew() && (
        <Box mt={1}>
          <Typography variant="body1">
            Your subscription will automatically renew when it expires.
          </Typography>
        </Box>
      )}
      {!handleShowAutoRenew() && (
        <ButtonCustom
          text={"Upgrade Subscription"}
          color="primary"
          size="large"
          onClick={() => handleUpGradePlanRenew({ plan })}
          disabled={isEmpty(plan)}
          notShowCircle={isEmpty(plan)}
        />
      )}
    </>
  );
};

export default FormPriceWithRenew;
