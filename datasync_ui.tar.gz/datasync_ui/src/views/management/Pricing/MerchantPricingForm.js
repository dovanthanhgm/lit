import React, { useCallback } from "react";
import { Box, Divider, Typography } from "@material-ui/core";
import FormWithLoginMerchant from "src/views/management/Pricing/FormWithLoginMerchant";
import { useSelector } from "react-redux";

const MerchantPricingForm = ({
  plan,
  type,
  setSubscriptionMe,
  onPaySuccess
}) => {
  const { subscription } = useSelector(state => state.account.user);
  const isNewPlan = subscription.id !== plan.id;
  const isRenew = subscription?.auto_renew;

  // const renderDiscount = useCallback(() => {
  //   if (!plan) {
  //     return "--";
  //   }
  //   return `-$${type === "mo" ? "0" : plan.monthly_fee * 2}.00`;
  // }, [plan, type]);
  const remainDayPlan = plan?.remaining_days;

  const isRemainDay = !!remainDayPlan;

  const renderFinalPrice = useCallback(() => {
    if (!plan) {
      return "--";
    }
    //nếu chọn plan cao hơn, mà có remaining days thì chỗ grand total dùng field grand total để hiển thị 21/6/2023 9:46 am slack
    if (isNewPlan && isRemainDay && isRenew && plan?.grand_total > 0) {
      return `$${plan.grand_total}`;
    }
    return `$${type === "mo" ? plan.monthly_fee : plan.yearly_fee}.00`;
  }, [plan, type, isRenew, isNewPlan, isRemainDay]);

  return (
    <Box>
      <Divider />
      {/*<Box*/}
      {/*  pt={2}*/}
      {/*  pb={2}*/}
      {/*  display="flex"*/}
      {/*  justifyContent="space-between"*/}
      {/*>*/}
      {/*  <Typography>Annual billing discount</Typography>*/}
      {/*  <Typography>{renderDiscount()}</Typography>*/}
      {/*</Box>*/}
      {/*<Divider />*/}
      <Box pt={2} pb={2} display="flex" justifyContent="space-between">
        <Typography variant="body2">Grand total</Typography>
        <Typography variant="h4">{renderFinalPrice()}</Typography>
      </Box>
      <Divider />
      {!!remainDayPlan && (
        <Box textAlign={"center"}>
          <Typography variant="body2">
            (Current plan remaining days: {remainDayPlan})
          </Typography>
        </Box>
      )}
      <Box display="flex" justifyContent="center" width="100%" mt={2}>
        <FormWithLoginMerchant
          plan={plan}
          type={type}
          onPaySuccess={onPaySuccess}
          setSubscriptionMe={setSubscriptionMe}
        />
      </Box>
    </Box>
  );
};

export default MerchantPricingForm;
