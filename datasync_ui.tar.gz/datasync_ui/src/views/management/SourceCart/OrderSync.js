import React, { useEffect, useState } from "react";
import {
  Box,
  FormControlLabel,
  Grid,
  Switch,
  Tooltip,
  Typography
} from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import { autoImportToLitC, autoUpdateSourceCart } from "src/services/channel";
import WarningSyncDialog from "src/components/Listings/WarningSyncDialog";
import Loading from "src/components/Loading/Loading";
import { useSnackbar } from "notistack";
import { convertIdToName } from "src/utils/helper";
import useUserExp from "src/hooks/useUserExp";
import SvgIconsCustom from "src/components/Icons/svgIcons";
import wait from "src/utils/wait";
import { actionSetListings } from "src/actions/listingActions";
import { messageError } from "src/utils/ErrorResponse";
import { getUserInfo } from "src/services/account";

export default function OrderSync() {
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const [enableUpdate, setUpdate] = useState(false);
  const [enableAuto, setAuto] = useState(false);
  const { defaultListing } = useSelector(state => state.listing);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const initUpdate = defaultListing?.auto_update;
  const initAuto = defaultListing?.auto_import;
  const { isUserFree } = useUserExp();
  // const [openAutoImport, setOpenAutoImport] = useState(
  //   [1, "1", true].includes(initAuto)
  // );

  const sendUpdateRequest = async ({ isUpdate }) => {
    try {
      await autoUpdateSourceCart({
        channel_id: defaultListing.id,
        isUpdate: isUpdate
      });
    } catch (e) {
      console.log(e);
    }
  };

  const sendAutoImportRequest = async ({ isUpdate }) => {
    try {
      await autoImportToLitC({
        channel_id: defaultListing.id,
        isUpdate: isUpdate
      });
    } catch (e) {
      console.log(e);
    }
  };

  const handleCloseWarningDialog = () => {
    setOpen(false);
    setLoading(false);
  };

  const handleConfirmWarningDialog = () => {
    setUpdate(false);
    setLoading(true);
    try {
      const sendRequest = async status => {
        await sendUpdateRequest({ isUpdate: status });
        await wait(700);
        const data = await getUserInfo();
        dispatch(actionSetListings({ listings: data.channels }));
        setUpdate(false);
        setLoading(false);
        enqueueSnackbar("success", { variant: "success" });
      };
      sendRequest(false);
    } catch (e) {
      setLoading(false);
      enqueueSnackbar("error", { variant: "error" });
    }
    setOpen(false);
  };

  const handleChangeUpdate = event => {
    setLoading(true);
    try {
      const sendRequest = async status => {
        await sendUpdateRequest({ isUpdate: status });
        await wait(700);
        const data = await getUserInfo();
        dispatch(actionSetListings({ listings: data.channels }));
        setAuto(true);
        setLoading(false);
        enqueueSnackbar("success", { variant: "success" });
      };

      sendRequest(event.target.checked).catch(e => {
        console.log(e);
        enqueueSnackbar(messageError(e, "Error enable update"), {
          variant: "error"
        });
      });
    } catch (e) {
      setLoading(false);
      enqueueSnackbar("error", { variant: "error" });
    }
  };

  const handleChangeAutoImport = checkStatus => {
    try {
      const sendRequest = async status => {
        setLoading(true);
        await sendAutoImportRequest({ isUpdate: status });
        await wait(700);
        const data = await getUserInfo();
        dispatch(actionSetListings({ listings: data.channels }));
        setUpdate(true);
        setLoading(false);
        enqueueSnackbar("success", { variant: "success" });
      };
      sendRequest(checkStatus).catch(e => {
        console.log(e);
        setLoading(false);
        enqueueSnackbar(
          messageError(
            e,
            `Error ${checkStatus ? "Disable" : "Enabled"} update`
          ),
          {
            variant: "error"
          }
        );
      });
    } catch (e) {
      enqueueSnackbar("error", { variant: "error" });
    }
  };

  useEffect(() => {
    setUpdate([1, "1", true].includes(initUpdate));
  }, [initUpdate]);

  useEffect(() => {
    setAuto([1, "1", true].includes(initAuto));
  }, [initAuto]);

  // useEffect(() => {
  //   setOpenAutoImport(enableAuto);
  // }, [enableAuto]);

  const {
    user_id,
    support_amazon_order,
    meta_data,
    number_products_linked,
    identifier,
    last_imported,
    updated_at,
    created_at,
    ...rest
  } = defaultListing;

  useEffect(() => {
    console.log(
      "please send us this code if update button is not working properly"
    );
    console.log("code", {
      initUpdate,
      enableUpdateValue: enableUpdate,
      ...rest
    });
    // eslint-disable-next-line
  }, [defaultListing]);

  return (
    <>
      <WarningSyncDialog
        channelType={defaultListing.type}
        handleClose={handleCloseWarningDialog}
        handleConfirm={handleConfirmWarningDialog}
        open={open}
        syncType={"source"}
      />
      {loading && <Loading />}
      <Grid container spacing={1}>
        <Grid item xs={6} lg={3} style={{ position: "relative" }}>
          <Typography variant="h6" color="textPrimary">
            Automatic Update
          </Typography>
          {isUserFree && (
            <Tooltip title="This feature is available in Paid Plans">
              <Box position="absolute" height="40" right={4} top="25%">
                <SvgIconsCustom color={"crown"} />
              </Box>
            </Tooltip>
          )}
        </Grid>

        <Grid item xs={6} lg={9}>
          <FormControlLabel
            disabled={isUserFree}
            control={
              <Switch checked={enableUpdate} onChange={handleChangeUpdate} />
            }
            label={`Automatically update changes from ${convertIdToName(
              defaultListing.type
            )} to LitCommerce`}
          />
        </Grid>
        <Grid item xs={6} lg={3} style={{ position: "relative" }} />

        <Grid item xs={6} lg={9}>
          <FormControlLabel
            disabled={isUserFree}
            control={
              <Switch
                checked={enableAuto}
                onChange={() => {
                  setAuto(!enableAuto);
                  handleChangeAutoImport(!enableAuto);
                }}
              />
            }
            label={`Auto import new product from ${convertIdToName(
              defaultListing.type
            )} to LitCommerce`}
          />
        </Grid>
      </Grid>
    </>
  );
}
