import {
  Box,
  Container,
  Link,
  makeStyles,
  Typography
} from "@material-ui/core";
import React, { useState, useEffect } from "react";
import Page from "src/components/Page";
import useEbaySetting from "src/hooks/EbaySetting";
import Connection from "src/views/management/Listing/ChannelSettings/Connection";
import { useDispatch, useSelector } from "react-redux";
import { verifyConnection } from "src/services/channel";
import SingleAlert from "src/components/Notify/SingleAlert";
import {
  connectionButtonStatusAction,
  openReconnectDialog,
  setFieldListing
} from "src/actions/listingActions";
import { useSnackbar } from "notistack";
import Header from "src/components/Header";
import { useHistory } from "react-router";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(1),
    paddingBottom: 100
  },
  largeIcon: {
    width: 160,
    height: 160
  },
  paddingMainShop: {
    paddingTop: theme.spacing(2)
  }
}));

function SourceCart() {
  const classes = useStyles();
  const history = useHistory();
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const [alert, setAlert] = useState();

  const { defaultListing, ebay_setting } = useSelector(state => state?.listing);
  const [hideButton, setHideButton] = useState(false);
  const [reconnectDialog, setOpenDialog] = useState(false);
  const defaultListingId = defaultListing?.id;
  const defaultListingType = defaultListing?.type;
  const [sourceCartSetting, setSourceCartSetting] = useState(null);

  useEbaySetting(defaultListingId);

  useEffect(() => {
    dispatch(connectionButtonStatusAction(false));
    const checkStatus = async () => {
      try {
        if (defaultListing?.id) {
          const data = await verifyConnection({
            channelId: defaultListing?.id
          });
          if (data?.result === "error") {
            setAlert(data.msg);
          }
        }
      } catch (e) {
        console.log("error", e);
        const message =
          e.response?.data?.msg ?? e.response?.data?.message ?? "";
        enqueueSnackbar(message, { variant: `error` });
      }
    };

    checkStatus();

    // eslint-disable-next-line
  }, [defaultListing?.id]);

  const handleTestConnect = async () => {
    const channelID = defaultListing?.id;
    dispatch(connectionButtonStatusAction(true));

    if (defaultListing.status === "disconnected") {
      if (["shopify", "magento"].includes(defaultListing?.type)) {
        setOpenDialog(true);
        dispatch(openReconnectDialog(true));
        return;
      }
      // else if (["google", "etsy", "facebook", "wix", "bigcommerce", "amazon"].includes(defaultListing.type)){
      //   let data;
      //   if (defaultListing.type === "amazon"){
      //     data = await merchantAmazonAPI({
      //       id: marketId,
      //     });
      //   } else {
      //     data = await merchantChannelIDAPI({channelID: defaultListing.type, body: {}});
      //   }
      //   //hàm nghe dùng chung ở src/views/management/Listing/ChannelConnect/Template.js -> const messageEvent
      //   if (data) {
      //     window.open(
      //       data,
      //       "_blank",
      //       `location=yes,height=${window.outerHeight},width=800,scrollbars=yes,status=yes`
      //     );
      //   }
      //   return;
      // }
      if (defaultListing.type === "woocommerce") {
        return window.open(
          defaultListing.url +
            "/wp-admin/admin.php?page=litcommerce&reconnect=1",
          "_blank"
        );
      }

      return history.push(
        `/listing/reconnect/${defaultListing.type}/${defaultListing.id}`
      );
    }

    try {
      const data = await verifyConnection({ channelId: channelID });

      if (data?.result === "error") {
        setAlert(data.msg);
        dispatch(
          setFieldListing({
            defaultListing: {
              ...defaultListing,
              status: "disconnected"
            }
          })
        );
      }
      if (data?.result === "success") {
        dispatch(
          setFieldListing({
            defaultListing: {
              ...defaultListing,
              status: "connected"
            }
          })
        );
      }
      setHideButton(false);
    } catch (error) {
      console.log("error", error);
      const message =
        error?.response?.data?.msg ||
        `API error: api response status ${error?.response?.status}`;
      setHideButton(false);
      enqueueSnackbar(message, { variant: `error` });
    }
  };

  useEffect(() => {
    if (defaultListingType === "ebay") {
      setSourceCartSetting({
        username: ebay_setting?.[defaultListingId]?.username,
        marketplace_id: ebay_setting?.[defaultListingId]?.marketplace_id
      });
    }
  }, [defaultListingId, defaultListingType, ebay_setting]);

  return (
    <Page className={classes.root} title="Main Store">
      <ErrorBoundaryComponent>
        <Container maxWidth={false} className={classes.paddingMainShop}>
          <Header headerName="Main Store" typeLogo={defaultListing?.type} />
          {alert && <SingleAlert content={alert} type="error" />}
          <Box pb={2}>
            <Connection
              channelDetail={defaultListing}
              handleTestConnect={handleTestConnect}
              hideButton={hideButton}
              typeCart={"source"}
              setHideButton={setHideButton}
              marketId={sourceCartSetting?.marketplace_id}
              reconnectDialog={reconnectDialog}
              sourceCartSetting={sourceCartSetting}
              setOpenReconnectDialog={setOpenDialog}
            />
            <Box mt={1}>
              <Typography variant="body2">
                If you want to change your Mainstore, you will need to&nbsp;
                <Link
                  target="_blank"
                  underline="none"
                  href="https://help.litcommerce.com/en/article/close-your-account-9f931w/"
                >
                  Close your account
                </Link>
                &nbsp;and restart setup steps. Details&nbsp;
                <Link
                  target="_blank"
                  underline="none"
                  href="https://help.litcommerce.com/en/article/step-1-connect-your-main-store-8grqgu/"
                >
                  here
                </Link>
              </Typography>
            </Box>
          </Box>
        </Container>
      </ErrorBoundaryComponent>
    </Page>
  );
}

const SourCartWithErrorBoundary = () => {
  return (
    <ErrorBoundaryComponent>
      <SourceCart />
    </ErrorBoundaryComponent>
  );
};

export default SourCartWithErrorBoundary;
