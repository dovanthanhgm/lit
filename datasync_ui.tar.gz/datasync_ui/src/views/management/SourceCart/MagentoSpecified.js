import React, { useEffect, useState } from "react";
import { Box, Grid, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import { getMagentoStore } from "src/services/manage";
import { useSelector } from "react-redux";
import { useFormikContext } from "formik";

const useStyles = makeStyles(theme => ({
  formControl: {
    minWidth: 120
  }
}));

const MagentoSpecified = () => {
  const classes = useStyles();
  const { defaultListing } = useSelector(state => state.listing);
  const { values, handleChange } = useFormikContext();
  const [store, setStore] = useState([]);
  const [specifiedStore, setSpecifiedStore] = useState(values.store_id);
  const defaultId = defaultListing.id;

  useEffect(() => {
    const handleGetStore = async () => {
      const data = await getMagentoStore({
        channel_default_id: defaultId
      });
      if (data) {
        setStore(data.data);
      }
    };
    handleGetStore();
  }, [defaultId]);

  const handleChangeStore = async e => {
    setSpecifiedStore(e.target.value);
    const findStore = store.find(bodyStore => bodyStore.id === e.target.value);

    handleChange({
      target: {
        name: "store_name",
        value: findStore.name
      }
    });
    handleChange({
      target: {
        name: "store_id",
        value: findStore.id
      }
    });
  };

  return (
    <>
      <Grid item xs={4} lg={2} style={{ position: "relative" }}>
        <Typography variant="subtitle2" color="textPrimary">
          Select store
        </Typography>
      </Grid>
      <Grid item xs={8} lg={10}>
        <Box display="flex" alignItems="center">
          <FormControl
            edge="start"
            variant="outlined"
            className={classes.formControl}
            size="small"
          >
            <Select
              value={specifiedStore}
              onChange={handleChangeStore}
              displayEmpty
              MenuProps={{
                anchorOrigin: {
                  vertical: "bottom",
                  horizontal: "left"
                },
                transformOrigin: {
                  vertical: "top",
                  horizontal: "left"
                },
                getContentAnchorEl: null
              }}
            >
              <MenuItem value={""}>select store</MenuItem>
              {store.map(magentoStore => {
                return (
                  <MenuItem value={magentoStore.id}>
                    {magentoStore.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
          &nbsp;
          <Typography variant="body2" component="span">
            The order will be imported into the store you specified, if the
            store is not selected, the order will be imported into the default
            store
          </Typography>
        </Box>
      </Grid>
    </>
  );
};

export default MagentoSpecified;
