import React, { useState } from "react";
import { FormControlLabel, Grid, Switch, Typography } from "@material-ui/core";
import { useFormikContext } from "formik";

const WoocommerceEmail = () => {
  const { values, handleChange } = useFormikContext();
  const [emailEnable, setEmailEnable] = useState(
    values.send_email === "enable"
  );

  const handleSetEmail = async () => {
    setEmailEnable(!emailEnable);
    handleChange({
      target: {
        name: "send_email",
        value: !emailEnable ? "enable" : "disable"
      }
    });
  };

  return (
    <>
      <Grid item xs={4} lg={2}>
        <Typography variant="h6" color="textPrimary">
          Customers Notification
        </Typography>
      </Grid>

      <Grid item xs={8} lg={10}>
        <FormControlLabel
          control={
            <Switch
              edge="start"
              checked={emailEnable}
              onChange={handleSetEmail}
            />
          }
          label={`Customers will receive notification email when you change Order Status.`}
        />
      </Grid>
    </>
  );
};

export default WoocommerceEmail;
