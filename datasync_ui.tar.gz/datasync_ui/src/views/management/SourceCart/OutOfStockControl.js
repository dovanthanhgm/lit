import React, { useState } from "react";
import {
  Box,
  Button,
  FormControlLabel,
  Grid,
  Switch,
  Typography
} from "@material-ui/core";
import SimpleTooltips from "src/components/Tooltip/SimpleTooltips";
import InfoIcon from "@material-ui/icons/Info";
import useUserExp from "src/hooks/useUserExp";
import { postChannel } from "src/services/channel";
import { useSnackbar } from "notistack";
import { getUserInfo } from "src/services/account";
import { SILENT_LOGIN } from "src/actions/accountActions";
import { useDispatch, useSelector } from "react-redux";

const OutOfStockControl = () => {
  const { isUserFree } = useUserExp();
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const { defaultListing } = useSelector(state => state.listing);
  const channelSetting = defaultListing?.settings ?? {};
  const initValue = {
    name: defaultListing?.name,

    statusPrice: channelSetting?.price?.status || "disable",
    direction: channelSetting?.price?.direction || "increase",
    modifier: channelSetting?.price?.modifier || "fixed",
    value: channelSetting?.price?.value,
    rounding: channelSetting?.price?.rounding,
    statusQty: channelSetting?.qty?.status || "disable",
    statusOrder: channelSetting?.order?.status || "disable",
    adjust: channelSetting?.qty?.adjust || 100,
    max_qty: channelSetting?.qty?.max_qty || 0,
    min_qty: channelSetting?.qty?.min_qty || 0,
    without_tax: channelSetting?.order?.without_tax || "disable",
    keep_order_number: channelSetting?.order?.keep_order_number || "disable",
    out_of_stock_control:
      channelSetting?.qty?.out_of_stock_control === "enable",
    statusMax_qty: channelSetting?.qty?.max_qty > 0,
    statusMin_qty: channelSetting?.qty?.min_qty > 0,
    order_number_prefix: channelSetting?.order?.order_number_prefix || "",
    activeList: channelSetting?.inventory?.active || [],
    disableList: channelSetting?.inventory?.disable || []
  };
  const [value, setValue] = useState(initValue?.out_of_stock_control ?? false);
  const [loading, setLoading] = useState(false);
  const [isShow, setIsShow] = useState(false);

  const saveUserData = async () => {
    const userData = await getUserInfo();
    if (userData) {
      dispatch({
        type: SILENT_LOGIN,
        payload: {
          user: userData
        }
      });
    }
  };

  const handleSaveOutOfStock = async () => {
    try {
      setLoading(true);
      let settings = {
        setting: {
          price: {
            status: initValue?.statusPrice,
            direction: initValue?.direction,
            modifier: initValue?.modifier,
            value: initValue?.value,
            rounding: initValue?.rounding
          },
          qty: {
            status: initValue?.statusQty,
            adjust: initValue?.adjust,
            max_qty: initValue.statusMax_qty ? initValue.max_qty : 0,
            min_qty: initValue.statusMin_qty ? initValue.min_qty : 0,
            out_of_stock_control: value ? "enable" : "disable"
          },
          order: {
            status: initValue.statusOrder,
            without_tax: initValue?.without_tax,
            order_number_prefix: initValue?.order_number_prefix ?? "",
            keep_order_number: initValue?.keep_order_number
          },
          inventory: {
            active: initValue.activeList.map(item => item?.id),
            disable: initValue.disableList.map(item => item?.id)
          }
        },
        name: initValue?.name
      };
      const res = await postChannel({
        channelId: defaultListing.id,
        body: settings
      });
      if (res.status < 400) {
        await saveUserData();
        enqueueSnackbar("Settings out of stock saved.", {
          variant: "success"
        });
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar("Save error", {
        variant: "error"
      });
    }
    setLoading(false);
  };

  const handleChangeStock = e => {
    const changeValue = e.target.checked;
    setValue(!value);
    if (changeValue === initValue?.out_of_stock_control) {
      setIsShow(false);
    } else {
      setIsShow(true);
    }
  };

  return (
    <>
      <Grid container spacing={3}>
        <Grid item xs={6} lg={3} style={{ position: "relative" }}>
          <Typography variant="h6">Ebay Out Of Stock Control</Typography>
        </Grid>
        <Grid item xs={6} lg={9}>
          <FormControlLabel
            disabled={isUserFree}
            control={<Switch checked={value} onChange={handleChangeStock} />}
            label={
              <Box display="flex" alignItems="center">
                <Typography component={"span"} variant="body2">
                  Keep listings alive when quantity reaches 0 (zero), rather
                  than ending the listings.
                </Typography>
                <SimpleTooltips
                  title={
                    <span style={{ fontSize: 12 }}>
                      When enabled, your listings will be hidden from eBay
                      search when the quantity goes to 0 (zero), but kept alive
                      and sales history is retained. That means the Good 'Til
                      Cancelled automatic renewal will continue every 30 days
                      AND the listing fees will be charged. This is best suited
                      for long running items where inventory can be replace in a
                      reasonable time.
                    </span>
                  }
                  icon={<InfoIcon color="primary" />}
                />
              </Box>
            }
          />
        </Grid>
      </Grid>
      {isShow && (
        <Box textAlign="right">
          <Button
            variant="contained"
            color="primary"
            size={"small"}
            onClick={handleSaveOutOfStock}
            disabled={loading}
          >
            Save
          </Button>
        </Box>
      )}
    </>
  );
};

export default OutOfStockControl;
