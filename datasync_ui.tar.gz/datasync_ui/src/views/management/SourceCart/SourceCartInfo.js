import React from "react";
import { Box, Card, Divider, makeStyles } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  button: {
    marginRight: theme.spacing(2),
    marginTop: theme.spacing(2)
  },
  divider: {
    marginTop: theme.spacing(2)
  }
}));

function SourceCartInfo({ content, icon, button, header }) {
  const classes = useStyles();

  return (
    <Box mt={2}>
      <Card>
        <Box m={7}>
          {header}
          <Box display={"flex"} alignItems={"flex-start"}>
            <Box m={2} ml={0}>
              {content}
              <Divider className={classes.divider} />
              <Box display={"flex"}>{button}</Box>
            </Box>
            {icon}
          </Box>
        </Box>
      </Card>
    </Box>
  );
}

export default SourceCartInfo;
