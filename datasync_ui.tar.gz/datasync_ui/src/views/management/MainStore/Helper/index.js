import {
  marketplaceAllProductTab,
  productTabs
} from "src/constants/Product/index";

export const getTotalCount = data => {
  if (data) {
    return Object.values(data).reduce((total, tab) => (total += tab), 0);
  }
  return 0;
};

export const returnTab = data => {
  let newVal = null;
  for (let tab of productTabs) {
    if (data[tab.value] > 0) {
      newVal = tab.value;
      break;
    }
  }
  return newVal;
};

export const returnMarketplaceTab = data => {
  let newVal = null;
  for (let tab of marketplaceAllProductTab) {
    if (data[tab.value] > 0) {
      newVal = tab.value;
      break;
    }
  }
  return newVal;
};
