import React, { useContext, useMemo, useState } from "react";
import { allProductLoading } from "src/actions/product";
import { useQuery } from "react-query";
import {
  GET_ALL_PRODUCT_COUNT,
  GET_ALL_PRODUCT_DATA
} from "src/constants/Product/index";
import { useDispatch, useSelector } from "react-redux";
import { useQueryV2 } from "src/hooks/useQuery";
import { AllProductProcessContext } from "src/views/management/MainStore/Context/AllProductProcessContext";
import {
  getTotalCount,
  returnMarketplaceTab
} from "src/views/management/MainStore/Helper/index";
import {
  channelProductsCountAPI,
  marketplaceMainStoreAPI
} from "src/services/channel";
import {
  tabCallEnded,
  tabCallEtsyDraft,
  tabCallExpired,
  tabCallInactive,
  tabCallSoldOut,
  tabCallDeleted,
  tabCallUnlist,
  tabCallBanned,
  tabCallInactiveUpperCase
} from "src/views/management/ListingDetail/utils";
import AllProductCountProvider from "src/views/management/MainStore/Context/AllProductCountContext";
import AllProductProvider from "src/views/management/MainStore/Context/AllProductContext";

const MarketplaceTableLayout = ({ children }) => {
  const dispatch = useDispatch();
  const { search, state } = useQueryV2();
  const sort = state?.sort;

  const limit = useSelector(state => state.product.limit);
  const { defaultListing } = useSelector(state => state.listing);

  const { process } = useContext(AllProductProcessContext);

  const [page, setPage] = useState(1);
  const [count, setCount] = useState({});
  const [total, setTotal] = useState([]);
  const [product, setProduct] = useState([]);
  const [countSuccess, setCountSuccess] = useState(false);
  const [tab, setTab] = useState("draft");

  const statusChannel = process?.[0]?.status;

  const isActiveProcess = ["pulling", "pushing"].includes(statusChannel);

  const handleSearchListing = () => {
    const channelType = defaultListing?.type;
    let tabCall = "";
    switch (tab) {
      case "inactive":
        tabCall = tabCallInactive;
        break;
      case "Inactive":
        tabCall = tabCallInactiveUpperCase;
        break;
      case "sdeleted":
        tabCall = tabCallDeleted;
        break;
      case "unlist":
        tabCall = tabCallUnlist;
        break;
      case "banned":
        tabCall = tabCallBanned;
        break;
      case "etsy_draft":
        tabCall = tabCallEtsyDraft;
        break;
      case "sold_out":
        tabCall = tabCallSoldOut;
        break;
      case "expired":
        tabCall = tabCallExpired;
        break;
      case "ended":
        tabCall = tabCallEnded;
        break;
      default:
    }

    if (!tabCall) {
      return { search };
    }

    const extraSearch = () =>
      tabCall?.[channelType]?.[
        ![undefined, null, ""]?.includes(search) ? "search" : "search_product"
      ] ?? "";

    return {
      ...tabCall[channelType],
      search: search + extraSearch()
    };
  };

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const handleCallCount = useMemo(() => {
    // return !(!search && localCountData);
    return ![null, undefined].includes(search);
  }, [search]);

  const allProductCount = useQuery(
    [GET_ALL_PRODUCT_COUNT, search],
    async () => await channelProductsCountAPI(defaultListing?.id, {}, search),
    {
      retryDelay: 30000,
      onSuccess: data => {
        setTotal(getTotalCount(data));
        if (!getTotalCount(data)) {
          setLoading(false);
          setProduct([]);
        }
        setCount(data);
        if (getTotalCount(data) && (!countSuccess || !data?.[tab])) {
          setTab(returnMarketplaceTab(data));
        }
      },
      refetchInterval: isActiveProcess ? 60000 : 0,
      enabled:
        !!isActiveProcess ||
        (!countSuccess && handleCallCount) ||
        handleCallCount,
      onSettled: () => {
        setCountSuccess(true);
      }
    }
  );
  const countLoading = allProductCount?.isFetching || false;

  const allProductRequest = useQuery(
    [GET_ALL_PRODUCT_DATA, search, sort, tab, limit, page],
    async () =>
      marketplaceMainStoreAPI({
        search: handleSearchListing()?.search || "",
        channelID: defaultListing?.id,
        type: handleSearchListing()?.type || tab,
        sort,
        page,
        limit
      }),
    {
      retryDelay: 30000,
      onSuccess: data => {
        setProduct(data?.data);
        setLoading(false);
      },
      refetchInterval: isActiveProcess ? 60000 : 0,
      enabled:
        ((!!search && !!allProductCount.isSuccess) ||
          !!sort ||
          (!!isActiveProcess && !!allProductCount.isSuccess) ||
          !!countSuccess) &&
        !countLoading &&
        !!count?.[tab]
    }
  );

  return (
    <AllProductCountProvider
      setCount={setCount}
      count={count}
      total={total}
      tab={tab}
      setTab={setTab}
      page={page}
      setPage={setPage}
      recallCount={allProductCount.refetch}
    >
      <AllProductProvider
        products={product}
        setProducts={setProduct}
        getProduct={allProductRequest.refetch}
      >
        {children}
      </AllProductProvider>
    </AllProductCountProvider>
  );
};

export default MarketplaceTableLayout;
