import React, { useState } from "react";
import { makeStyles } from "@material-ui/core";
import Page from "src/components/Page";
import Tour from "reactour";
import { steps } from "src/constants/Product/index";
import Tutorial from "src/views/management/ProductListView/Tutorial";
import { showAio } from "src/constants/index";
import AIOBar from "src/views/AIOBar";
import { QueryClient, QueryClientProvider } from "react-query";
import { ReactQueryDevtools } from "react-query/devtools";
import LoadingScreen from "src/components/Loading/LoadingScreen";
import { useSelector } from "react-redux";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: 500,
    // marginTop: theme.spacing(3)
    // paddingBottom: 100
    padding: "12px 0"
  }
}));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false
    }
  }
});

const MainStoreLayout = ({ children }) => {
  const classes = useStyles();
  const [isOpenTutorial, setIsOpenTutorial] = useState(
    localStorage.getItem("tutorialInProduct") === "true"
  );
  const { defaultListing } = useSelector(state => state.listing);

  const closeTour = () => {
    setIsOpenTutorial(false);
    localStorage.setItem("tutorialInProduct", "false");
  };

  if (!defaultListing) {
    return <LoadingScreen />;
  }

  return (
    <Page className={classes.root} title="Product List" noPadding>
      <Tour
        steps={steps}
        isOpen={isOpenTutorial}
        onRequestClose={closeTour}
        disableInteraction
        rounded={4}
        closeWithMask={false}
      />
      <Tutorial />
      <QueryClientProvider client={queryClient}>
        {children}
        <ReactQueryDevtools initialIsOpen={false} />
      </QueryClientProvider>
      {showAio && <AIOBar />}
    </Page>
  );
};

export default MainStoreLayout;
