import React, { useContext, useMemo, useState } from "react";
import { useQuery } from "react-query";
import {
  GET_ALL_PRODUCT_COUNT,
  GET_ALL_PRODUCT_DATA
} from "src/constants/Product/index";
import {
  getAllProductsData,
  getCountAllProductsService
} from "src/services/products";
import { AllProductProcessContext } from "src/views/management/MainStore/Context/AllProductProcessContext";
import AllProductCountProvider from "src/views/management/MainStore/Context/AllProductCountContext";
import AllProductProvider from "src/views/management/MainStore/Context/AllProductContext";
import { useDispatch, useSelector } from "react-redux";
import { allProductLoading } from "src/actions/product";
import {
  getTotalCount,
  returnTab
} from "src/views/management/MainStore/Helper/index";
import useLimitIntervalTimes from "src/hooks/useLimitIntervalTimes";

const INTERVAL_TIME = 120000;
const TIME_INTERVAL = 5;

const TableProductLayout = ({ children }) => {
  const dispatch = useDispatch();
  const productFilterParams = useSelector(
    state => state.product.productFilterParams
  );
  const { search, state } = productFilterParams;
  const sort = state?.sort;
  const countFilter = state?.countFilter || 0;

  const limit = useSelector(state => state.product.limit);

  const { process } = useContext(AllProductProcessContext);

  const [tab, setTab] = useState("instock");
  const [count, setCount] = useState({});
  const [product, setProduct] = useState([]);
  const [total, setTotal] = useState([]);
  const [countSuccess, setCountSuccess] = useState(false);
  const [page, setPage] = useState(1);

  const conditionIntervalProduct = useMemo(() => {
    return `${search}${page}${limit}${sort}`;
  }, [search, page, limit, sort]);

  const { isCallInterval } = useLimitIntervalTimes(
    5,
    INTERVAL_TIME,
    conditionIntervalProduct
  );

  const conditionIntervalCountProduct = useMemo(() => {
    return `${search}`;
  }, [search]);

  const { isCallInterval: isCallIntervalCount } = useLimitIntervalTimes(
    5,
    INTERVAL_TIME,
    conditionIntervalCountProduct
  );

  const statusChannel = process?.[0]?.status;
  const isCallCountInterval = isCallIntervalCount < TIME_INTERVAL;
  const isCallProductInterval = isCallInterval < TIME_INTERVAL;

  const isActiveProcess = ["pulling", "pushing"].includes(statusChannel);

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const handleCallCount = useMemo(() => {
    // return !(!search && localCountData);
    return ![null, undefined].includes(search);
  }, [search]);

  const allProductCount = useQuery(
    [GET_ALL_PRODUCT_COUNT, search, countFilter],
    async () =>
      await getCountAllProductsService({
        search
      }),
    {
      retryDelay: 30000,
      onSuccess: data => {
        setTotal(getTotalCount(data));
        if (!getTotalCount(data)) {
          setLoading(false);
          setProduct([]);
        }
        // if (!search) {
        //   handleSetLocalValue({ pathValue: localCountPath, value: data });
        // }
        setCount(data);
        if (!!getTotalCount(data) && (!countSuccess || !data?.[tab])) {
          setTab(returnTab(data));
        }
      },
      refetchInterval: isActiveProcess && isCallCountInterval ? 60000 : 0,
      enabled:
        !!isActiveProcess ||
        (!countSuccess && handleCallCount) ||
        handleCallCount,
      onSettled: () => {
        setCountSuccess(true);
      }
    }
  );
  const countLoading = allProductCount?.isFetching || false;

  const allProductRequest = useQuery(
    [GET_ALL_PRODUCT_DATA, search, sort, tab, limit, page, countFilter],
    async () =>
      getAllProductsData({
        search,
        sort,
        prdTab: tab,
        limit,
        page
      }),
    {
      retryDelay: 30000,
      onSuccess: data => {
        setProduct(data.data);
        setLoading(false);
        //update count by product call
      },
      refetchInterval: isActiveProcess && isCallProductInterval ? 60000 : 0,
      enabled:
        ((!!search && !!allProductCount.isSuccess) ||
          !!sort ||
          (!!isActiveProcess && !!allProductCount.isSuccess) ||
          !!countSuccess) &&
        !countLoading &&
        !!count?.[tab]
    }
  );
  //
  // useEffect(() => {
  //   if (!handleCallCount) {
  //     setCount(localCountData);
  //     setCountSuccess(true);
  //     setTotal(getTotalCount(localCountData));
  //   }
  //   // eslint-disable-next-line
  // }, [handleCallCount]);

  return (
    <AllProductCountProvider
      setCount={setCount}
      count={count}
      total={total}
      tab={tab}
      setTab={setTab}
      setPage={setPage}
      page={page}
    >
      <AllProductProvider
        products={product}
        setProducts={setProduct}
        getProduct={allProductRequest.refetch}
      >
        {children}
      </AllProductProvider>
    </AllProductCountProvider>
  );
};

export default TableProductLayout;
