import React, { useContext, useMemo } from "react";
import { useHistory, useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import {
  Badge,
  Box,
  FormControl,
  makeStyles,
  MenuItem,
  Select,
  Tooltip
} from "@material-ui/core";
import { useQueryV2 } from "src/hooks/useQuery";
import { Formik } from "formik";
import DefaultFilter from "src/components/Filter/Listing/DefaultFilter";
import { Link as LinkIcon } from "react-feather";
import ButtonCustom from "src/components/MUI/Button";
import MoreFilterListing from "src/components/Filter/Listing/MoreFilter";
import FilterChip from "src/components/Filter/Products/FilterChip";
import { productLink } from "src/constants/index";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";
import { allProductLoading } from "src/actions/product";
import { isEqual } from "lodash";
import AllProductSort from "src/views/management/MainStore/Component/AllProductSort";

const useStyles = makeStyles(theme => ({
  formControl: {
    marginRight: 8
  }
}));

const FilterMarketplaceProducts = () => {
  const classes = useStyles();
  const history = useHistory();
  const dispatch = useDispatch();
  const { productId } = useParams();
  const { state } = useQueryV2();

  const { defaultListing } = useSelector(state => state.listing);
  const isAmazon = defaultListing?.type === "amazon";
  const { tab } = useContext(AllProductCountContext);

  const {
    title,
    linked,
    sku,
    fulfilled_by,
    ebay_status,
    etsy_status,
    asin,
    min_qty = "",
    max_qty = "",
    min_price = "",
    max_price = "",
    amazon_status,
    search,
    variant_unlink,
    sync_error,
    in_channel = "",
    nin_channel = "",
    section_id = "",
    shopee_status ="",
    ...value
  } = useQueryV2();

  const listKey = useMemo(() => {
    const filterKey = Object?.keys(value).reduce((prev, curr) => {
      if (curr.includes("template")) {
        prev = [...prev, { [curr]: value[curr] }];
      }
      return prev;
    }, []);
    return filterKey[0];
    // eslint-disable-next-line
  }, [search]);

  const initialValues = {
    title: title?.trim() ?? "",
    linked: linked ?? "",
    sku: sku?.trim() ?? "",
    min_qty: min_qty ?? "",
    max_qty: max_qty ?? "",
    fulfilled_by: fulfilled_by ?? "",
    asin: asin ?? "",
    min_price: min_price ?? "",
    max_price: max_price ?? "",
    amazon_status: amazon_status ?? "",
    ebay_status: ebay_status ?? "",
    etsy_status: etsy_status ?? "",
    shopee_status: shopee_status ?? "",
    sync_error,
    variant_unlink,
    in_channel: in_channel ?? "",
    nin_channel: nin_channel ?? "",
    section_id,
    ...listKey
  };

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  return (
    <Formik
      initialValues={initialValues}
      enableReinitialize
      onSubmit={async values => {
        let search = ``;
        let symbol = "?";
        Object.keys(values).forEach(key => {
          if (![null, undefined, "", "NaN", NaN].includes(values[key])) {
            search += `${symbol}${key}=${
              ["title", "sku", "asin"].includes(key)
                ? values[key].trim()
                : values[key]
            }`;
            symbol = "&";
          }
        });
        if (!isEqual(values, initialValues)) {
          setLoading(true);
        }

        if (productId) {
          const count = state?.countFilter || 0;

          history.push("/products" + encodeURI(search), {
            countFilter: count + 1
          });
        } else {
          const count = state?.countFilter || 0;

          history.push(
            {
              search: encodeURI(search)
            },
            { countFilter: count + 1 }
          );
        }
      }}
    >
      {({ values, handleChange, handleSubmit, resetForm }) => {
        const condition = Object.values(values).some(
          item => ![NaN, "", null, undefined].includes(item)
        );
        const handleResetForm = () => {
          history.push({ search: "" });
          resetForm();
          // handleSubmit();
        };

        const handleChangeUnlinkVariant = e => {
          if (e.target.value === 1) {
            handleChange({
              target: {
                name: "linked",
                value: null
              }
            });
            return handleChange({
              target: {
                name: "variant_unlink",
                value: "1"
              }
            });
          } else {
            handleChange({
              target: {
                name: "variant_unlink",
                value: null
              }
            });
            return handleChange(e);
          }
        };

        return (
          <form onSubmit={handleSubmit}>
            <Box p={1} py={1} display="flex" alignItems="center">
              <DefaultFilter isAmazon={isAmazon} />
              <Box display="flex" alignItems="center" ml={1}>
                <FormControl
                  variant="outlined"
                  size="small"
                  className={classes.formControl}
                >
                  <Select
                    name="linked"
                    displayEmpty
                    value={values?.variant_unlink ?? values.linked}
                    onChange={handleChangeUnlinkVariant}
                  >
                    {productLink.map((items, key) => (
                      <MenuItem key={key} value={items.value}>
                        <Tooltip
                          title={
                            !!values?.variant_unlink
                              ? "Find parent products which are linked but contain unlinked variations."
                              : ""
                          }
                        >
                          <Box display="flex" spacing={3}>
                            {items.icon && (
                              <Box mr={1}>
                                <Badge color={items?.color} variant="dot">
                                  <LinkIcon size="14" />
                                </Badge>
                              </Box>
                            )}
                            <Box>{items.name}</Box>
                          </Box>
                        </Tooltip>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                <ButtonCustom
                  type="submit"
                  color="secondary"
                  text="Search"
                  disabled={!condition}
                  notShowCircle
                />
              </Box>
              <Box mx={1}>
                <ButtonCustom
                  disabled={!search}
                  notShowCircle
                  color="secondary"
                  onClick={handleResetForm}
                  text="Clear"
                />
              </Box>
              <AllProductSort />
              <Box ml={1} />
              <MoreFilterListing
                isAmazon={isAmazon}
                isProduct
                currentTab={tab}
                channelType={defaultListing.type}
                channelID={defaultListing.id}
              />
            </Box>
            <FilterChip channelID={defaultListing.id} />
          </form>
        );
      }}
    </Formik>
  );
};

export default FilterMarketplaceProducts;
