import React from "react";
import { Box, Card } from "@material-ui/core";
import FilterMarketplaceProducts from "src/views/management/MainStore/MarketplaceMainStore/Body/Filter/FilterMarketplaceProducts";
import MarketplaceAllProductTabs from "src/views/management/MainStore/MarketplaceMainStore/Body/Tabs/MarketplaceAllProductTabs";
import MarketplaceTable from "src/views/management/MainStore/MarketplaceMainStore/Body/Table/index";

const MarketplaceProductContent = () => {
  return (
    <Box mt={3}>
      <Card>
        <FilterMarketplaceProducts />
        <MarketplaceAllProductTabs />
        <MarketplaceTable />
      </Card>
    </Box>
  );
};

export default MarketplaceProductContent;
