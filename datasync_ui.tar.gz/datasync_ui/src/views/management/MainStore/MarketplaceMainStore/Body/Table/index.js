import React from "react";
import AllProductMarketPlaceTable from "src/views/management/MainStore/MarketplaceMainStore/Body/Table/AllProductMarketPlaceTable";
import ProductProvider from "src/context/ProductContext";
import ProductDetailView from "src/views/pages/Product/ProductDetailView";

const MarketplaceTable = () => {
  return (
    <ProductProvider>
      <ProductDetailView />
      <AllProductMarketPlaceTable />
    </ProductProvider>
  );
};

export default MarketplaceTable;
