import React from "react";
import { extraColumn, tableColumns } from "src/constants/Product/TableProduct";
import { Box } from "@material-ui/core";
import ProductLoading from "src/views/management/ProductEditView/ProductLoading";
import {
  Grid,
  TableHeaderRow,
  TableSelection
} from "@devexpress/dx-react-grid-material-ui";
import SelectionTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/Selection";
import { IntegratedSelection } from "@devexpress/dx-react-grid";
import CustomTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/CustomTable";
import AllProductTablePagination from "src/views/management/MainStore/Component/AllProductTablePagination";
import { useSelector } from "react-redux";
import TableVisibleColumns from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/TableVisibleColumns";

const MarketResultTable = ({ products = [], total }) => {
  const { defaultListing } = useSelector(state => state.listing);
  const isAmazon = defaultListing?.type === "amazon";

  const handleTableColumn = () => {
    if (isAmazon) {
      let newTable = [...tableColumns];
      newTable.splice(3, 0, { name: "asin", title: "ASIN" });
      return newTable;
    }
    return tableColumns;
  };

  const productTableColumn = [...handleTableColumn(), ...extraColumn];
  return (
    <Box position="relative">
      <ProductLoading productLength={total} />
      <Grid
        rows={products}
        columns={productTableColumn}
        getRowId={row => {
          return row.publish_id;
        }}
      >
        <SelectionTable />
        <IntegratedSelection />
        <CustomTable />
        <TableVisibleColumns />
        {/*<ColumnResizing />*/}
        <TableHeaderRow />
        <TableSelection showSelectAll />
      </Grid>

      <AllProductTablePagination />
    </Box>
  );
};

export default React.memo(MarketResultTable);
