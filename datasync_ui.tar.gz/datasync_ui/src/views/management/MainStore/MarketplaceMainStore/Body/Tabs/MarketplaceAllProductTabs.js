import React, { useContext } from "react";
import { Box, Chip, makeStyles, Tab, Tabs } from "@material-ui/core";
import { totalTab } from "src/constants/Product/index";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";
import { allProductLoading } from "src/actions/product";
import { useDispatch } from "react-redux";
import TabLabelCustom from "src/components/Layout/TabLabelCustom";

const useStyles = makeStyles(theme => ({
  tabRoot: {
    width: "auto",
    // minWidth: 100,
    height: 40
  },
  labelSmall: {
    paddingLeft: theme.spacing(0.5),
    paddingRight: theme.spacing(0.5)
  },
  chip: {
    marginLeft: theme.spacing(1)
  }
}));

const MarketplaceAllProductTabs = () => {
  const classes = useStyles();
  const dispatch = useDispatch();

  const { tab, setTab, countProduct } = useContext(AllProductCountContext);

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const handleChangeProductTab = (_, value) => {
    if (tab !== value) {
      setTab(value);
      setLoading(true);
    }
  };

  const handleTab = counts =>
    Object.keys(counts)
      .map(count => {
        if (counts[count] > 0) {
          return totalTab[count];
        }
        return null;
      })
      .filter(item => item);

  return (
    <Tabs onChange={handleChangeProductTab} value={tab}>
      {handleTab(countProduct)?.map((tab, index) => {
        return (
          <Tab
            size="small"
            classes={{
              root: classes.tabRoot
            }}
            disabled={countProduct?.[tab.value] === 0}
            key={tab?.value || index}
            value={tab?.value || ""}
            label={
              <Box display="flex" alignItems={"center"} justifyContent="center">
                <TabLabelCustom>{tab?.name}</TabLabelCustom>
                <Chip
                  size="small"
                  label={countProduct?.[tab.value]}
                  color="primary"
                  classes={{ labelSmall: classes.labelSmall }}
                  className={classes.chip}
                />
              </Box>
            }
          />
        );
      })}
    </Tabs>
  );
};

export default MarketplaceAllProductTabs;
