import React from "react";
import { Box, makeStyles } from "@material-ui/core";
import AllProductTableActionButton from "src/views/management/MainStore/Component/ActionButton/index";
import SelectedProductProvider from "src/views/management/MainStore/Context/SelectedProductContext";
import MarketAllProductTableData from "src/views/management/MainStore/MarketplaceMainStore/Body/Table/MarketAllProductTableData";
import AllProductColumnProvider from "src/views/management/MainStore/Context/AllProductColumnContext";

const useStyles = makeStyles(theme => ({
  root: {
    position: "relative"
  }
}));

const AllProductMarketPlaceTable = () => {
  const classes = useStyles();

  return (
    <Box className={classes.root}>
      <SelectedProductProvider>
        <AllProductColumnProvider>
          <React.Fragment>
            <AllProductTableActionButton isMarket />
            <MarketAllProductTableData />
          </React.Fragment>
        </AllProductColumnProvider>
      </SelectedProductProvider>
    </Box>
  );
};

export default React.memo(AllProductMarketPlaceTable);
