import React, { useContext } from "react";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import MarketResultTable from "src/views/management/MainStore/MarketplaceMainStore/Body/Table/MarketResultTable";

const MarketAllProductTableData = () => {
  const { listProduct } = useContext(AllProductContext);

  return <MarketResultTable products={listProduct} />;
};

export default React.memo(MarketAllProductTableData);
