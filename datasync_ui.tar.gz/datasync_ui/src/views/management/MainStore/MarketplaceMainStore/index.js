import React from "react";
import MainStoreLayout from "src/views/management/MainStore/Layout/index";
import { Container } from "@material-ui/core";
import AllProductProcessProvider from "src/views/management/MainStore/Context/AllProductProcessContext";
import MarketplaceTableLayout from "src/views/management/MainStore/Layout/MarketplaceTableLayout";
import AllProductAlertProvider from "src/views/management/MainStore/Context/AllProductAlertContext";
import DefaultAllProductsHeader from "src/views/management/MainStore/Component/Header/index";
import MarketplaceProductContent from "src/views/management/MainStore/MarketplaceMainStore/Body/index";
import ProductDetailView from "src/views/pages/Product/ProductDetailView";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

const MarketplaceMainStore = () => {
  return (
    <MainStoreLayout>
      <ErrorBoundaryComponent>
        <Container style={{ padding: "0 12px" }} maxWidth={false}>
          <AllProductProcessProvider>
            <MarketplaceTableLayout>
              <AllProductAlertProvider>
                <React.Fragment>
                  <ProductDetailView />
                  <DefaultAllProductsHeader />
                  <MarketplaceProductContent />
                </React.Fragment>
              </AllProductAlertProvider>
            </MarketplaceTableLayout>
          </AllProductProcessProvider>
        </Container>
      </ErrorBoundaryComponent>
    </MainStoreLayout>
  );
};

export default MarketplaceMainStore;
