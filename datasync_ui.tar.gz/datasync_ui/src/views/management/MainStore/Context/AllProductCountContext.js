import React from "react";

export const AllProductCountContext = React.createContext({
  countProduct: {},
  setCountProduct: function() {},
  total: 0,
  tab: "",
  setTab: function() {},
  tabTotal: 0,
  page: 1,
  setPage: function() {},
  recallCount: function() {}
});

const AllProductCountProvider = ({
  count = {},
  setCount = function() {},
  total = 0,
  tab,
  setTab = function() {},
  recallCount = function() {},
  page,
  setPage,
  children
}) => {
  return (
    <AllProductCountContext.Provider
      value={{
        countProduct: count,
        setCountProduct: setCount,
        total,
        tab,
        setTab,
        tabTotal: count?.[tab] || 0,
        recallCount,
        page,
        setPage
      }}
    >
      {children}
    </AllProductCountContext.Provider>
  );
};

export default AllProductCountProvider;
