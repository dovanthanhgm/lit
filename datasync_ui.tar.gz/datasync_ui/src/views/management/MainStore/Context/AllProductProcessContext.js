import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getStatusCode } from "src/services/channel";
import { showImportAlert } from "src/actions/listingActions";
import useLimitIntervalTimes from "src/hooks/useLimitIntervalTimes";

export const AllProductProcessContext = React.createContext({
  process: "",
  setProcess: function() {},
  setTimeCall: function() {},
  setLimit: function() {}
});
const INTERVAL_TIME = 125000;

const AllProductProcessProvider = ({ children }) => {
  const dispatch = useDispatch();
  const { defaultListing } = useSelector(state => state.listing);
  const [process, setProcess] = useState();
  const [timeCall, setTimeCall] = useState(INTERVAL_TIME);
  const [limit, setLimit] = useState(5);
  const { isCallInterval } = useLimitIntervalTimes(limit, timeCall);

  const defaultId = defaultListing.id;
  const callInterValTimes = isCallInterval || 0;

  useEffect(() => {
    const getStatus = async () => {
      const res = await getStatusCode(defaultId);
      if (res) {
        setProcess(res);
      }
    };

    getStatus();
    const interval = setInterval(() => {
      getStatus().catch(e => {
        console.log(e);
      });
    }, 60000);

    if (!callInterValTimes) {
      dispatch(showImportAlert(false));
      clearInterval(interval);
    }

    return () => {
      dispatch(showImportAlert(false));
      clearInterval(interval);
    };
  }, [defaultId, dispatch, callInterValTimes]);

  return (
    <AllProductProcessContext.Provider
      value={{
        process,
        setProcess,
        setTimeCall,
        setLimit
      }}
    >
      {children}
    </AllProductProcessContext.Provider>
  );
};

export default AllProductProcessProvider;
