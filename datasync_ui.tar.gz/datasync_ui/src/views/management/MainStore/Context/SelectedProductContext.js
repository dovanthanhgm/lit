import React, { useContext, useState } from 'react';
import { useEffect } from 'react';
import { AllProductContext } from './AllProductContext';
import { cloneDeep } from 'lodash';

export const SelectedProductContext = React.createContext({
  selectedProduct: [],
  setSelectedProduct: function() {},
  disableButton: false,
  setDisableButton: function() {},
  selectOneItem: function() {},
  selectedAllItems: function() {},
  selectWithShiftHeld: () => {},
  setLastSelectedRow: () => {}
});

const SelectedProductProvider = ({ children }) => {
  const [selectedProduct, setSelectedProduct] = useState([]);
  const [disableButton, setDisableButton] = useState(false);
  const [shiftHeld, setShiftHeld] = useState(false);
  const [lastSelectedRow, setLastSelectedRow] = useState(-1)

  const { listProduct } = useContext(AllProductContext);

  useEffect(() => {
    function downHandler({ key }) {
       if (key === 'Shift') {
          setShiftHeld(true);
       }
    }
    function upHandler({ key }) {
       if (key === 'Shift') {
          setShiftHeld(false);
       }
    }
    
    document.addEventListener('keydown', downHandler);
    document.addEventListener('keyup', upHandler);
    return () => {
       document.removeEventListener('keydown', downHandler);
       document.removeEventListener('keyup', upHandler);
    };
 }, []);

  const selectOneItem = (item, rowNumber) => {
    setLastSelectedRow(rowNumber)
    if (!selectedProduct.includes(item)) setSelectedProduct(current => [...current, item]);
    else setSelectedProduct(current => current.filter(cur => cur !== item));
  };

  const selectedAllItems = (event, products) => {
    if (event.target.checked) setSelectedProduct(products.map(product => product.id));
    else {
      setLastSelectedRow(-1)
      setSelectedProduct([]);
    }
  };

  const selectWithShiftHeld = (rowNumber, checked) => {
    if (
       !shiftHeld ||
       rowNumber === lastSelectedRow ||
       selectedProduct === listProduct.length ||
       lastSelectedRow === -1
    )
       return;

    let _selected = cloneDeep(selectedProduct);

    const shiftSelected =
       rowNumber > lastSelectedRow
          ? listProduct.slice(lastSelectedRow, rowNumber + 1)
          : listProduct.slice(rowNumber, lastSelectedRow + 1); //Because slice doesnt take the second index element into the new Array
    
    const shiftSelectedIds = shiftSelected.map(selected => selected.id);

    const isUnchecked = shiftSelectedIds.some(id => !_selected.includes(id)); // checking whether the new Ids havent been checked by seeing if the selected ones don't includes all the new ones

    let _newSelected = [];

    if (!isUnchecked) {
       _newSelected = _selected.filter(selected => !shiftSelectedIds.includes(selected));

       let _lastSelected = rowNumber;

       if (_newSelected.length !== 0)
          _lastSelected = rowNumber > lastSelectedRow ? rowNumber + 1 : rowNumber - 1;
       // When the new length is 0, the last select index is equal to the rowNumber
       /* When it's not, we consider the new index and the last index, if the new one is bigger, it means that we have to check those ones
       that are under, we need to add 1 to last selectedRow, so that when we get the new shiftSelected items, it would only get the items that 
       are not already previously selected. Same goes to the above items.
       But still, I highly recommend you read the logic and log it out step to step to fully understand it */

       setLastSelectedRow(() => _lastSelected);
    } else {
       if (checked) _newSelected = [...new Set([..._selected, ...shiftSelectedIds])];
       else _newSelected = _selected.filter(selected => !shiftSelectedIds.includes(selected));
       setLastSelectedRow(() => rowNumber);
    }

    setSelectedProduct(() => _newSelected);
 };

  return (
    <SelectedProductContext.Provider
      value={{
        selectedProduct,
        setSelectedProduct,
        disableButton,
        setDisableButton,
        selectOneItem,
        selectedAllItems, 
        selectWithShiftHeld,
        setLastSelectedRow
      }}
    >
      {children}
    </SelectedProductContext.Provider>
  );
};

export default SelectedProductProvider;
