import React, { useState } from "react";

export const AllProductAlertContext = React.createContext({
  alert: {},
  setAlert: function() {}
});

const AllProductAlertProvider = ({ children }) => {
  const [alert, setAlert] = useState({});

  return (
    <AllProductAlertContext.Provider
      value={{
        alert,
        setAlert
      }}
    >
      {children}
    </AllProductAlertContext.Provider>
  );
};

export default AllProductAlertProvider;
