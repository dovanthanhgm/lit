import React, { useState } from "react";

export const AllProductActionContext = React.createContext({
  loading: false,
  setLoading: function() {},
  actionRun: "",
  setActionRun: function() {},
  listAction: "",
  setListAction: function() {}
});

const AllProductActionProvider = ({ action, setAction, children }) => {
  const [loading, setLoading] = useState(false);
  const [actionRun, setActionRun] = useState("");

  return (
    <AllProductActionContext.Provider
      value={{
        loading,
        setLoading,
        actionRun,
        setActionRun,
        listAction: action,
        setListAction: setAction
      }}
    >
      {children}
    </AllProductActionContext.Provider>
  );
};

export default AllProductActionProvider;