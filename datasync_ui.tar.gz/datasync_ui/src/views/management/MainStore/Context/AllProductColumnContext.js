import React, { useState } from "react";
import { useSelector } from "react-redux";

export const AllProductColumnContext = React.createContext({
  columns: {},
  setColumns: function() {},
  hideColumns: []
});

const AllProductColumnProvider = ({ children }) => {
  const { productColumns } = useSelector(state => state.product);
  const { defaultListing } = useSelector(state => state.listing);

  const [columnList, setColumnList] = useState(
    productColumns
      ? productColumns
      : {
          image: { isShow: true, label: "Images" },
          name: { isShow: true, label: "Name" },
          sku: { isShow: true, label: "Sku" },
          origin: { isShow: true, label: "Origin" },
          manage_stock: { isShow: true, label: "Manage Stock" },
          is_in_stock: { isShow: true, label: "In Stock" },
          qty: { isShow: true, label: "Total Available" },
          variant_count: { isShow: true, label: "Variants" },
          price: { isShow: true, label: "Price" },
          sale_price: { isShow: true, label: "Sale Price" },
          upc: { isShow: false, label: "UPC" },
          ean: { isShow: false, label: "EAN" },
          mpn: { isShow: false, label: "MPN" },
          gtin: { isShow: false, label: "GTIN" },
          invisible: { isShow: true, label: "Status" },
          updated_time: { isShow: true, label: "Last Modified" },
          active_listings: { isShow: true, label: "Active listings" }
        }
  );

  const handleColumns = () => {
    const channel = {
      amazon: () => {
        return { ...columnList, asin: { isShow: true, label: "ASIN" } };
      },
      shopify: () => {
        return {
          ...columnList,
          product_type: { isShow: true, label: "Product Type" }
        };
      }
    };

    if (channel?.[defaultListing.type]) {
      return channel[defaultListing.type]();
    }
    return columnList;
  };

  return (
    <AllProductColumnContext.Provider
      value={{
        columns: handleColumns(),
        setColumns: setColumnList,
        hideColumns: Object.keys(columnList).filter(
          item => !columnList[item].isShow
        )
      }}
    >
      {children}
    </AllProductColumnContext.Provider>
  );
};

export default AllProductColumnProvider;
