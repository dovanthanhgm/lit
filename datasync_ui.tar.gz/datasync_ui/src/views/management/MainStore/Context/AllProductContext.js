import React from "react";

export const AllProductContext = React.createContext({
  listProduct: [],
  setListProduct: function() {},
  getProduct: function() {}
});

const AllProductProvider = ({
  products = [],
  setProducts = function() {},
  getProduct = function() {},
  children
}) => {
  return (
    <AllProductContext.Provider
      value={{
        listProduct: products,
        setListProduct: setProducts,
        getProduct
      }}
    >
      {children}
    </AllProductContext.Provider>
  );
};

export default AllProductProvider;
