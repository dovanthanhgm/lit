import React, { useContext } from "react";
import { Typography } from "@material-ui/core";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";

const TableSelectedProduct = () => {
  const { selectedProduct } = useContext(SelectedProductContext);

  return (
    <Typography color="textPrimary" variant="body2">
      {selectedProduct.length} products selected
    </Typography>
  );
};

export default TableSelectedProduct;
