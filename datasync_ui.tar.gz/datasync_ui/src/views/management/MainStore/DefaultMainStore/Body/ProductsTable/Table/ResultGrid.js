import { Box, Grid, makeStyles } from '@material-ui/core';
import React from 'react';
import { useSelector } from 'react-redux';
import PageScrollbarCustom from 'src/components/PageScrollbarCustom';
import AllProductGridCheckbox from './GridComps/AllProductGridSelectionAll';
import AllProductGridBox from './GridComps/AllProductGridBox';

const useStyles = makeStyles(() => ({
   root: {
      '& .MuiTableHead-root': {
         position: 'sticky',
         top: 0,
         backgroundColor: 'white',
         zIndex: 2
      }
   },
   checkbox: {
      height: '16px',
      width: '16px',
      position: 'absolute',
      top: '8px',
      left: '8px',
      background: 'white',
      '&:hover': {
         backgroundColor: '#EFEFEF'
      }
   },
   name: {
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      paddingLeft: '4px'
   },
   channelImage: {
      marginLeft: '4px',
      cursor: 'pointer',
      borderRadius: '4px'
   }
}));

function ResultGrid(props) {
   const { products } = props;
   const { listingStyle } = useSelector(state => state.listing);
   const classes = useStyles();

   return (
      <PageScrollbarCustom
         position='relative'
         style={{ maxHeight: listingStyle === 'grid' ? '100%' : 0 }}
         extendClass={classes.root}
      >
         <React.Fragment>
            <Box padding='0 20px'>
               <AllProductGridCheckbox products={products} />

               <Grid container>
                  {products.map((product, index) => (
                     <AllProductGridBox
                        key={product.id}
                        classes={classes}
                        product={product}
                        index={index}
                     />
                  ))}
               </Grid>
            </Box>
         </React.Fragment>
      </PageScrollbarCustom>
   );
}

export default ResultGrid;
