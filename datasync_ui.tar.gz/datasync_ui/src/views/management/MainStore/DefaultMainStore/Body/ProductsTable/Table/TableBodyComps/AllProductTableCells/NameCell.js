import { Link, TableCell, Tooltip, Typography } from "@material-ui/core";
import React, { useContext } from "react";
import { ProductContext } from "src/context/ProductContext";
import useProductListingHook from "src/hooks/Listing/useProductListingHook";

function NameCell(props) {
  const { product, name, classes } = props;
  const { setDialogProduct, setOpenDialog } = useContext(ProductContext);
  const { isMainMarket } = useProductListingHook();
  const { variant_attributes } = product;
  const variantAttributesLength = variant_attributes?.length;

  return (
    <TableCell style={{ width: "200px", padding: 6 }}>
      <Link
        color="primary"
        onClick={() => {
          window.history.replaceState(
            null,
            null,
            `/products/${isMainMarket ? product.publish_id : product.id}`
          );
          setOpenDialog(true);
          setDialogProduct(product);
        }}
      >
        <Tooltip title={product[name]}>
          <Typography className={classes.title} variant="subtitle2">
            {product[name]}
          </Typography>
        </Tooltip>
      </Link>
      {variantAttributesLength > 0 && (
        <Typography variant="inherit" color="textSecondary">
          Varies on:{" "}
          {variant_attributes.map((item, index) => {
            if (index === variantAttributesLength - 1) {
              return item;
            } else {
              return `${item}, `;
            }
          })}
        </Typography>
      )}
    </TableCell>
  );
}

export default NameCell;
