import React, { useState } from "react";
import { TableColumnResizing } from "@devexpress/dx-react-grid-material-ui";
import { columnExtensions } from "src/constants/Product/TableProduct";

export const widthColumn = {
  image: 80,
  sku: "12%",
  origin: 90,
  manage_stock: 110,
  is_in_stock: 90,
  asin: 110,
  qty: 110,
  price: "6%",
  product_type: 100,
  fulfilled: "8%",
  variant_count: "6%",
  updated_time: 120,
  invisible: 80,
  active_listings: 150,
  name: "19%"
  // ((100 - 11 - 8 - 6 - 8 - 6) / 100) * widthScreen -
  // (80 + 110 + 90 + 110 + 130 + 160)
};

export const ColumnResizing = () => {
  const [columnWidths, setColumnWidths] = useState([
    { columnName: "image", width: widthColumn.image },
    {
      columnName: "name",
      width: widthColumn.name
    },
    { columnName: "sku", width: widthColumn.sku },
    { columnName: "asin", width: widthColumn.asin },
    { columnName: "origin", width: widthColumn.origin },
    {
      columnName: "manage_stock",
      width: widthColumn.manage_stock
    },
    { columnName: "is_in_stock", width: widthColumn.is_in_stock },
    { columnName: "qty", width: widthColumn.qty },
    {
      columnName: "price",
      width: widthColumn.price
    }, // { columnName: "bpn", width: "10%" },
    { columnName: "product_type", width: widthColumn.product_type },
    { columnName: "fulfilled", width: widthColumn.fulfilled },
    { columnName: "variant_count", width: widthColumn.variant_count },
    {
      columnName: "invisible",
      width: widthColumn.updated_time
    },
    {
      columnName: "updated_time",
      width: widthColumn.updated_time
    },
    { columnName: "active_listings", width: widthColumn.active_listings }
  ]);

  return (
    <TableColumnResizing
      columnWidths={columnWidths}
      onColumnWidthsChange={setColumnWidths}
      resizingMode="nextColumn"
      columnExtensions={columnExtensions}
    />
  );
};

export default ColumnResizing;
