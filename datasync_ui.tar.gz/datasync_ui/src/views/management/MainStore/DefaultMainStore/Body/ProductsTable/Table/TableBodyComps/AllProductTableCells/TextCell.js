import { TableCell, Typography } from '@material-ui/core';
import React from 'react';

function TextCell(props) {
   const { text = ''} = props;
   return (
      <TableCell style={{padding: 6}}>
         <Typography variant='body2'>{text}</Typography>
      </TableCell>
   );
}

export default TextCell;
