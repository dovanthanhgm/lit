import React from "react";
import ProductProvider from "src/context/ProductContext";
import ProductDetailView from "src/views/pages/Product/ProductDetailView";
import AllProductTableData from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/TableData";

const AllProductTable = () => {
  return (
    <ProductProvider>
      <React.Fragment>
        <ProductDetailView />
        <AllProductTableData />
      </React.Fragment>
    </ProductProvider>
  );
};

export default AllProductTable;
