import React, {useContext} from 'react';
import {SelectionState} from "@devexpress/dx-react-grid";
import {SelectedProductContext} from "src/views/management/MainStore/Context/SelectedProductContext";

const SelectionTable = () => {
  const { selectedProduct, setSelectedProduct } = useContext(
    SelectedProductContext
  );

  const handleSelectionChange = e => {
    setSelectedProduct(e);
  };

  return (
    <SelectionState
      selection={selectedProduct}
      onSelectionChange={handleSelectionChange}
    />
  );
};

export default SelectionTable;