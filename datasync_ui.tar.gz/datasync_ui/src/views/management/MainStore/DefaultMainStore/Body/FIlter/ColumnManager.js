import React, { useContext, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Typography
} from "@material-ui/core";
import DialogTitle from "src/components/Modal/DialogTitle";
import { AllProductColumnContext } from "src/views/management/MainStore/Context/AllProductColumnContext";
import { makeStyles } from "@material-ui/styles";
import { useDispatch, useSelector } from "react-redux";
import { saveProductColumns } from "src/actions/product";
import {
  handleSetLocalValue,
  productFilterStore
} from "src/helper/handleLocalstorageValue";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.grey["100"],
    padding: theme.spacing(1)
  },
  headerDialog: {
    paddingTop: theme.spacing(1.5),
    paddingBottom: theme.spacing(1.5)
  },
  buttonColumnStyle: {
    textTransform: "none"
  },
  cardContent: {
    padding: theme.spacing(1),
    // "& .MuiCardContent-root": {
    "&:last-child": {
      paddingBottom: theme.spacing(2)
    }
    // }
  },
  cardHeader: {
    paddingBottom: theme.spacing(0.5),
    paddingTop: theme.spacing(1.5)
  }
}));
//
// const mainField = ["image", "name", "sku", "price", "qty"];
//
// const mainStore = channelType => {
//   const channel = {
//     shopify: ["product_type"]
//   };
//
//   return channel?.[channelType] ? channel[channelType] : [];
// };
const FilterButton = ({ item, handleSetShowColumns = function() {} }) => {
  const classes = useStyles();

  return (
    <Box m={0.5}>
      {!item.isShow && (
        <Button
          onClick={() => handleSetShowColumns(item?.name)}
          variant={"outlined"}
          size={"small"}
          className={classes.buttonColumnStyle}
        >
          {item.label}
        </Button>
      )}
      {item.isShow && (
        <Button
          onClick={() => handleSetShowColumns(item.name)}
          variant={"contained"}
          size={"small"}
          className={classes.buttonColumnStyle}
          color={"primary"}
        >
          {item.label}
        </Button>
      )}
    </Box>
  );
};

export const FilterSection = ({
  fields = [],
  handleSetShowColumns = function() {},
  header = ""
}) => {
  const classes = useStyles();

  return (
    <Card>
      <CardHeader
        className={classes.cardHeader}
        title={<Typography variant={"h5"}>{header}</Typography>}
      />
      <CardContent className={classes.cardContent}>
        <Box display={"flex"} flexWrap={"wrap"}>
          {Object.keys(fields).map(item => {
            return (
              <FilterButton
                key={fields[item]?.name}
                item={{ ...fields[item], name: fields[item]?.name || item }}
                handleSetShowColumns={handleSetShowColumns}
              />
            );
          })}
        </Box>
      </CardContent>
    </Card>
  );
};

const ColumnManager = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const { defaultListing } = useSelector(state => state.listing);
  const { listingStyle } = useSelector(state => state.listing);

  const [open, setOpen] = useState(false);
  const { columns, setColumns } = useContext(AllProductColumnContext);
  const [fields, setFields] = useState(columns);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSetShowColumns = column => {
    const newColumns = JSON.parse(JSON.stringify(fields));
    newColumns[column].isShow = !newColumns[column].isShow;
    setFields(newColumns);
    dispatch(saveProductColumns(newColumns));
    handleSetLocalValue({
      pathValue: productFilterStore(defaultListing.id),
      value: newColumns
    });
  };

  const handleSubmit = () => {
    setColumns(fields);
    handleClose();
  };

  // const mainStoreColumn = Object.keys(fields).reduce(
  //   (prevColumns, currColumns) => {
  //     if (mainField.includes(currColumns)) {
  //       prevColumns.mainColumns = [
  //         ...prevColumns.mainColumns,
  //         { ...fields[currColumns], name: currColumns }
  //       ];
  //     } else if (mainStore(defaultListing.type).includes(currColumns)) {
  //       prevColumns.mainStoreColumns = [
  //         ...prevColumns.mainStoreColumns,
  //         { ...fields[currColumns], name: currColumns }
  //       ];
  //     } else {
  //       prevColumns.otherColumns = [
  //         ...prevColumns.otherColumns,
  //         { ...fields[currColumns], name: currColumns }
  //       ];
  //     }
  //     return prevColumns;
  //   },
  //   { mainColumns: [], otherColumns: [], mainStoreColumns: [] }
  // );

  return (
    <Box ml={1}>
      <Button
        variant="contained"
        color="primary"
        size={"small"}
        onClick={handleClickOpen}
        disabled={listingStyle === 'grid'}
      >
        Columns
      </Button>
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth={"md"}>
        <DialogTitle onClose={handleClose} className={classes.headerDialog}>
          Hide/Show Columns
        </DialogTitle>
        <DialogContent className={classes.root}>
          <FilterSection
            handleSetShowColumns={handleSetShowColumns}
            fields={fields}
            header={"Product Fields"}
          />
          {/*{mainStoreColumn.mainStoreColumns.length > 0 && <Box my={0.5} />}*/}
          {/*{mainStoreColumn.mainStoreColumns.length > 0 && (*/}
          {/*  <Card>*/}
          {/*    <CardHeader*/}
          {/*      className={classes.cardHeader}*/}
          {/*      title={<Typography variant={"h5"}>Main Store Field</Typography>}*/}
          {/*    />*/}
          {/*    <CardContent className={classes.cardContent}>*/}
          {/*      <Box display={"flex"} flexWrap={"wrap"}>*/}
          {/*        {mainStoreColumn.mainStoreColumns.map(item => {*/}
          {/*          return (*/}
          {/*            <FilterButton*/}
          {/*              key={item.name}*/}
          {/*              item={item}*/}
          {/*              handleSetShowColumns={handleSetShowColumns}*/}
          {/*            />*/}
          {/*          );*/}
          {/*        })}*/}
          {/*      </Box>*/}
          {/*    </CardContent>*/}
          {/*  </Card>*/}
          {/*)}*/}
          {/*<Box my={0.5} />*/}
          {/*<Card>*/}
          {/*  <CardHeader*/}
          {/*    className={classes.cardHeader}*/}
          {/*    title={<Typography variant={"h5"}>Other Field</Typography>}*/}
          {/*  />*/}
          {/*  <CardContent className={classes.cardContent}>*/}
          {/*    <Box display={"flex"} flexWrap={"wrap"}>*/}
          {/*      {mainStoreColumn.otherColumns.map(item => {*/}
          {/*        return (*/}
          {/*          <FilterButton*/}
          {/*            item={item}*/}
          {/*            key={item.name}*/}
          {/*            handleSetShowColumns={handleSetShowColumns}*/}
          {/*          />*/}
          {/*        );*/}
          {/*      })}*/}
          {/*    </Box>*/}
          {/*  </CardContent>*/}
          {/*</Card>*/}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} color="primary">
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ColumnManager;
