import React from "react";
import ProductTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/ProductTable";

const AllProductTableResult = ({ productList = [] }) => {
  return <ProductTable products={productList} />;
};

export default React.memo(AllProductTableResult);
