import {
   Checkbox,
   TableCell,
   TableHead,
   TableRow,
   Typography,
   makeStyles
} from '@material-ui/core';
import React, { useContext } from 'react';
import { SelectedProductContext } from 'src/views/management/MainStore/Context/SelectedProductContext';

const useStyles = makeStyles(theme => ({
   titleTemplate: {
      overflow: 'hidden',
      textOverflow: 'ellipsis'
   },
   tablePaddingCustom: {
      paddingLeft: '0px !important'
   },
   styleHeader: {
      position: 'sticky',
      top: 0,
      boxShadow: 'none',
      backgroundColor: 'white',
      zIndex: 2
   }
}));

function AllProductTableHeader(props) {
   const { showColumns, products } = props;

   const classes = useStyles();

   const { selectedProduct, selectedAllItems } = useContext(SelectedProductContext);

   const selectedSome = selectedProduct.length > 0 && selectedProduct.length < products.length;
   const selectedAll = selectedProduct.length === products.length;

   return (
      <TableHead>
         <TableRow>
            <TableCell width='auto' padding='checkbox' className={classes.tablePaddingCustom}>
               <Checkbox
                  checked={selectedAll}
                  indeterminate={selectedSome}
                  onChange={(e) => selectedAllItems(e, products)}
               />
            </TableCell>
            {showColumns.map(col => (
               <TableCell key={col.name} style={{padding: 6}}>
                  <Typography variant='h6' color='textPrimary' className={classes.titleTemplate}>
                     {col?.title}
                  </Typography>
               </TableCell>
            ))}
         </TableRow>
      </TableHead>
   );
}

export default AllProductTableHeader;
