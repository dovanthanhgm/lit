import { TableCell } from '@material-ui/core';
import React from 'react';
import Label from 'src/components/Label';

function StatusCell(props) {
   const { status = false } = props;
   return (
      <TableCell style={{padding: 6}}>
         <Label color={status ? 'warning' : 'success'}>
            {status ? 'Inactive' : 'Active'}
         </Label>
      </TableCell>
   );
}

export default StatusCell;
