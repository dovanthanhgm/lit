import { Typography } from '@material-ui/core';
import React from 'react';

const subtitle = [
   { code: 'sku', name: 'SKU' },
   { code: 'qty', name: 'Quantity' },
   { name: 'Price', code: 'price' }
];

function BoxSubTitles(props) {
   const { product, classes } = props;

   return subtitle.map((sub, index) => (
      <Typography variant='subtitle2' className={classes.name} key={index}>
         {sub.name}: {product[sub.code]}
      </Typography>
   ));
}

export default BoxSubTitles;
