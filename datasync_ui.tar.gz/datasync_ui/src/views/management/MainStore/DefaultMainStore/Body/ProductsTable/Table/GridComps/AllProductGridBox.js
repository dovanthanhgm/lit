import { Box, Grid, useMediaQuery, useTheme } from '@material-ui/core';
import React from 'react';
import BoxSubTitles from './BoxComps/BoxSubTitles';
import ItemImage from 'src/views/management/ListingDetail/ListingDetail/GridListing/ItemImage';
import BoxSelection from './BoxComps/BoxSelection';
import BoxName from './BoxComps/BoxName';
import BoxListings from './BoxComps/BoxListings';

function AllProductGridBox(props) {
   const { product, classes, index } = props;

   const theme = useTheme();

   const mdUp = useMediaQuery(theme.breakpoints.up('md'));
   const lgUp = useMediaQuery(theme.breakpoints.up('lg'));

   const renderBoxHeight = () => {
      return lgUp ? '370px' : mdUp ? '280px' : '310px';
   };

   return (
      <Grid item xs={3} md={2} key={product.id} style={{ padding: '5px' }}>
         <Box
            height={renderBoxHeight()}
            style={{ outline: '1px solid #ccc' }}
            position='relative'
            borderRadius='4px'
         >
            <BoxSelection classes={classes} product={product} index={index} />
            <ItemImage src={product.thumb_image?.url} />
            <BoxName product={product} classes={classes} />
            <BoxSubTitles classes={classes} product={product} />
            <BoxListings product={product} classes={classes} />
         </Box>
      </Grid>
   );
}

export default AllProductGridBox;
