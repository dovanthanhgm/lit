import { Checkbox, FormControlLabel } from '@material-ui/core';
import React, { useContext } from 'react';
import { SelectedProductContext } from 'src/views/management/MainStore/Context/SelectedProductContext';

function AllProductGridCheckbox(props) {
   const { products } = props;
   const { selectedProduct, selectedAllItems } = useContext(SelectedProductContext);

   const selectedSome = selectedProduct.length > 0 && selectedProduct.length < products.length;
   const selectedAll = selectedProduct.length === products.length;

   return (
      <FormControlLabel
         control={
            <Checkbox
               checked={selectedAll}
               indeterminate={selectedSome}
               name='Select All'
               onChange={e => selectedAllItems(e, products)}
            />
         }
         label='Select All'
      />
   );
}

export default AllProductGridCheckbox;
