import { Checkbox, TableCell, TableRow, makeStyles } from '@material-ui/core';
import React, { useContext } from 'react';
import useGetProductsOrigin from 'src/utils/products';
import ImageCell from './AllProductTableCells/ImageCell';
import NameCell from './AllProductTableCells/NameCell';
import OriginCell from './AllProductTableCells/OriginCell';
import TextCell from './AllProductTableCells/TextCell';
import { capitalizeFirstLetter } from 'src/utils/CapitalizeFirstLetter';
import StatusCell from './AllProductTableCells/StatusCell';
import LastModifiedCell from './AllProductTableCells/LastModifiedCell';
import ActiveListingsCell from './AllProductTableCells/ActiveListingsCell';
import { SelectedProductContext } from 'src/views/management/MainStore/Context/SelectedProductContext';

const useStyles = makeStyles(theme => ({
   tablePaddingCustom: {
      paddingLeft: '0px !important'
   },
   name: {
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      overflow: 'hidden'
   },
   title: {
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      cursor: 'pointer',
      width: 300
   },
   cartImage: {
      height: 24,
      width: 24,
      marginRight: theme.spacing(0.25),
      cursor: 'pointer'
   }
}));

function AllProductTableRow(props) {
   const { showColumns, product, rowNumber } = props;
   const { channelOrigin } = useGetProductsOrigin(product);

   const classes = useStyles();

   const { selectedProduct, selectOneItem, selectWithShiftHeld } = useContext(
      SelectedProductContext
   );

   const renderCell = name => {
      switch (name) {
         case 'image':
            return <ImageCell src={product?.thumb_image?.url} />;
         case 'name':
            return <NameCell classes={classes} product={product} name={name} />;
         case 'origin':
            return (
               <OriginCell
                  classes={classes}
                  type={channelOrigin()?.type}
                  name={channelOrigin()?.name}
                  id={product?.id}
               />
            );
         case 'sale_price':
            return <TextCell text={product?.special_price?.price} />;
         case 'product_type':
            return <TextCell text={capitalizeFirstLetter(product?.[name])} />;
         case 'invisible':
            return <StatusCell status={product?.[name]} />;
         case 'updated_time':
            return <LastModifiedCell date={product?.updated_at} />;
         case 'active_listings':
            return <ActiveListingsCell product={product} classes={classes} />;

         default:
            return <TextCell text={product?.[name]} />;
      }
   };

   return (
      <TableRow>
         <TableCell padding='checkbox' className={classes.tablePaddingCustom}>
            <Checkbox
               onChange={e => {
                  selectOneItem(product.id, rowNumber);
                  selectWithShiftHeld(rowNumber, e.target.checked);
               }}
               checked={selectedProduct.includes(product.id)}
            />
         </TableCell>
         {showColumns.map(col => (
            <React.Fragment key={col.name}>{renderCell(col.name)}</React.Fragment>
         ))}
      </TableRow>
   );
}

export default AllProductTableRow;
