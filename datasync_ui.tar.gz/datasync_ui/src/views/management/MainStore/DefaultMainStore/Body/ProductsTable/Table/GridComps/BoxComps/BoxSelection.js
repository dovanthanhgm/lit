import { Checkbox } from '@material-ui/core';
import React, { useContext } from 'react';
import { SelectedProductContext } from 'src/views/management/MainStore/Context/SelectedProductContext';

function BoxSelection(props) {
   const { classes, product, index } = props;
   const { selectedProduct, selectOneItem, selectWithShiftHeld } = useContext(
      SelectedProductContext
   );

   return (
      <Checkbox
         className={classes.checkbox}
         onChange={e => {
            selectOneItem(product.id, index);
            selectWithShiftHeld(index);
         }}
         checked={selectedProduct.includes(product.id)}
      />
   );
}

export default BoxSelection;
