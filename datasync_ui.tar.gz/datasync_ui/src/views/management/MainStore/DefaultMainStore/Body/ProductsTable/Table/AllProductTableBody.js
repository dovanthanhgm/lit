import { TableBody } from '@material-ui/core';
import React from 'react';
import AllProductTableRow from './TableBodyComps/AllProductTableRow';

function AllProductTableBody(props) {
   const { products, showColumns } = props;

   if (products.length === 0) return null;

   return (
      <TableBody>
         {products.map((product, index) => (
            <AllProductTableRow
               key={product.id}
               showColumns={showColumns}
               product={product}
               rowNumber={index}
            />
         ))}
      </TableBody>
   );
}

export default AllProductTableBody;
