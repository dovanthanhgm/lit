import { TableCell, Tooltip } from '@material-ui/core';
import React from 'react';
import { getSrcImageCartFromType } from 'src/utils/helper';

function OriginCell(props) {
   const { classes, type, name } = props;

   return (
      <TableCell style={{ padding: 6 }}>
         <Tooltip title={name}>
            <img
               src={getSrcImageCartFromType(type)}
               alt=''
               width='24px'
               height='24px'
               className={classes.cartImage}
            />
         </Tooltip>
      </TableCell>
   );
}

export default OriginCell;
