import React, { useContext } from "react";
import useUserExp from "src/hooks/useUserExp";
import { useQueryV2 } from "src/hooks/useQuery";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";
import AddModalChannel from "src/views/management/MainStore/Component/ActionButton/ManageChannel/AddModalChannel";
import { useSelector } from "react-redux";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import { AllProductActionContext } from "src/views/management/MainStore/Context/AllProductActionContext";

const SelectAllMainStore = () => {
  const { isUserFree, expired } = useUserExp();
  const { tab } = useContext(AllProductCountContext);
  const { listings } = useSelector(state => state.listing);
  const { setSelectedProduct } = useContext(SelectedProductContext);
  const { actionRun, setActionRun, setListAction } = useContext(
    AllProductActionContext
  );

  const {
    title = "",
    min_price = "",
    sku = "",
    max_price = "",
    min_qty = "",
    max_qty = "",
    in_channel = "",
    nin_channel = "",
    bpn = "",
    category = "",
    status = "",
    product_type = "",
    product_format = "",
    brands = "",
    tags = ""
  } = useQueryV2();

  const initValue = {
    title,
    sku,
    min_price,
    max_price,
    min_qty,
    max_qty,
    in_channel,
    nin_channel,
    category,
    bpn,
    status,
    product_type,
    product_format,
    brands,
    tags
  };

  const existValue = Object.keys(initValue).reduce((prev, curr) => {
    if (![null, undefined, "", "NaN", NaN].includes(initValue[curr])) {
      prev[curr] = initValue[curr];
    }
    return prev;
  }, {});

  const body = {
    conditions: { ...existValue, tab },
    select_all: true
  };

  if (isUserFree || expired) {
    return null;
  }

  return (
    <AddModalChannel
      open={actionRun === "list_all"}
      listAllProduct
      selectedProducts={[]}
      setSelectedProduct={setSelectedProduct}
      listings={listings}
      setAction={setActionRun}
      bodySelectAll={body}
      setListAction={setListAction}
    />
  );
};

export default SelectAllMainStore;
