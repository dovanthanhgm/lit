import { Box, Tooltip, Typography } from "@material-ui/core";
import React from "react";
import { useSelector } from "react-redux";
import { getSrcImageCartFromType } from "src/utils/helper";

function BoxListings(props) {
  const { product, classes } = props;

  const listing = useSelector(state => state?.listing?.listings);

  const getChannel = name => listing.find(list => list.name === name).id;

  const activeListings = product?.active_listings;

  const renderActiveListings = () => {
    if (activeListings?.length > 1)
      //Because it also includes Main Store as an active listing
      return activeListings
        .filter(active => active.name !== "Main Store")
        .map((active, index) => (
          <Tooltip title={active.name} key={index}>
            <img
              src={getSrcImageCartFromType(active.type)}
              alt=""
              width="30px"
              height="30px"
              className={classes.channelImage}
              onClick={() => {
                window.open(
                  `/listing/${getChannel(active.name)}/${product.id}`
                );
              }}
            />
          </Tooltip>
        ));

    return (
      <Typography variant="subtitle2" className={classes.name}>
        No active listings
      </Typography>
    );
  };

  return (
    <Box
      display="flex"
      flexDirection="row"
      overflow="hidden"
      position="relative"
      bottom={"2px"}
    >
      {renderActiveListings()}
    </Box>
  );
}

export default BoxListings;
