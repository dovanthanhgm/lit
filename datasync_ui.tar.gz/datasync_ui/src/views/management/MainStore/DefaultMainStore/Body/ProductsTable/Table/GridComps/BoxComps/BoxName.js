import { Link, Tooltip, Typography } from '@material-ui/core';
import React from 'react';
import { useContext } from 'react';
import { ProductContext } from 'src/context/ProductContext';
import useProductListingHook from 'src/hooks/Listing/useProductListingHook';

function BoxName(props) {
   const { product, classes } = props;

   const { isMainMarket } = useProductListingHook();
   const { setDialogProduct, setOpenDialog } = useContext(ProductContext);

   return (
      <Link
         color='primary'
         onClick={() => {
            window.history.replaceState(
               null,
               null,
               `/products/${isMainMarket ? product.publish_id : product.id}`
            );
            setOpenDialog(true);
            setDialogProduct(product);
         }}
         style={{ overflow: 'hidden' }}
      >
         <Tooltip title={product.name}>
            <Typography variant='subtitle2' style={{ cursor: 'pointer' }} className={classes.name}>
               {product.name}
            </Typography>
         </Tooltip>
      </Link>
   );
}

export default BoxName;
