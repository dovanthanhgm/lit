import { TableCell, Typography } from '@material-ui/core';
import moment from 'moment';
import React from 'react';

const getDate = date => {
   if (moment(date).isValid()) {
      return moment(date).format('MMM DD, YYYY');
   }
   return '';
};

function LastModifiedCell(props) {
   const { date } = props;
   
   return (
      <TableCell style={{padding: 6}}>
         <Typography variant='body2'>{getDate(date)}</Typography>
      </TableCell>
   );
}

export default LastModifiedCell;
