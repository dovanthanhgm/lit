import React from "react";
import { Table } from "@devexpress/dx-react-grid-material-ui";
import NoDataTable from "src/views/management/ProductListView/NoDataTable";
import AllProductTableCell from "src/views/management/MainStore/Component/AllProductTableCell";
import { tableColumnExtensions } from "src/constants/Product/TableProduct";
import { Box } from "@material-ui/core";
import { withStyles } from "@material-ui/styles";

const StyledTableRow = withStyles(theme => ({
  root: {
    overflow: "visible"
  }
}))(Box);

const CustomTable = () => {
  return (
    <Table
      noDataRowComponent={() => <NoDataTable />}
      columnExtensions={tableColumnExtensions}
      cellComponent={AllProductTableCell}
      containerComponent={StyledTableRow}
    />
  );
};

export default CustomTable;
