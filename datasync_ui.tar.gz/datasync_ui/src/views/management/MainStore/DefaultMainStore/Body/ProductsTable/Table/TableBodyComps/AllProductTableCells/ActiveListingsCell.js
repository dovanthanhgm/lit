import { Box, TableCell, Tooltip, Typography } from "@material-ui/core";
import React from "react";
import { useSelector } from "react-redux";
import { getSrcImageCartFromType } from "src/utils/helper";

function ActiveListingsCell(props) {
  const { product, classes } = props;
  const listing = useSelector(state => state.listing.listings);

  const getChannel = name => listing.find(list => list.name === name).id;

  const renderActiveListings = () => {
    if (product?.active_listings?.length) {
      return product.active_listings
        .filter(active => active.name !== "Main Store")
        .map((active, index) => (
          <Tooltip title={active.name} key={index}>
            <img
              src={getSrcImageCartFromType(active.type)}
              alt=""
              width="24px"
              height="24px"
              className={classes.cartImage}
              onClick={() => {
                window.open(
                  `/listing/${getChannel(active.name)}/${product.id}`
                );
              }}
            />
          </Tooltip>
        ));
    }

    return (
      <Typography variant="subtitle2" className={classes.name}>
        No active listings
      </Typography>
    );
  };

  return (
    <TableCell style={{ padding: 6 }}>
      <Box display="flex" flexDirection="row" bottom={4}>
        {renderActiveListings()}
      </Box>
    </TableCell>
  );
}

export default ActiveListingsCell;
