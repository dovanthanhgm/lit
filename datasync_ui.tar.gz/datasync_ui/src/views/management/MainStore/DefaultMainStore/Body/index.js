import React from "react";
import { Card } from "@material-ui/core";
import FilterAllProduct from "src/views/management/MainStore/DefaultMainStore/Body/FIlter/FilterAllProduct";
import AllProductTab from "src/views/management/MainStore/DefaultMainStore/Body/Tabs/AllProductTab";
import AllProductTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/AllProductTable";

const AllProductContent = () => {
  return (
    <Card style={{ flex: 1, flexDirection: "column", display: "flex" }}>
      <FilterAllProduct />
      <AllProductTab />
      <AllProductTable />
    </Card>
  );
};

export default AllProductContent;
