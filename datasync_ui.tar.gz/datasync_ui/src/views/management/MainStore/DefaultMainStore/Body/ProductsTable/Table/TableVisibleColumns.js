import React, { useContext } from "react";
import { TableColumnVisibility } from "@devexpress/dx-react-grid";
import { AllProductColumnContext } from "src/views/management/MainStore/Context/AllProductColumnContext";
import { Box, Typography } from "@material-ui/core";

const TableVisibleColumns = () => {
  const { hideColumns } = useContext(AllProductColumnContext);

  return (
    <TableColumnVisibility
      hiddenColumnNames={hideColumns}
      emptyMessageComponent={() => (
        <Box minHeight={"100"} textAlign={"center"}>
          <Typography variant={"h5"}>Select at least one column</Typography>
        </Box>
      )}
    />
  );
};

export default TableVisibleColumns;
