import { TableCell } from '@material-ui/core';
import React from 'react';
import { channelColumnConfig } from 'src/constants/Listing/ListingDetail/ListingDetailChannel';
import TableListingImage from 'src/views/management/ListingDetail/ListingDetail/TableListingImage';

function ImageCell(props) {
   const {src} = props
   const styleGlobal = channelColumnConfig.globalConfig;

   return (
      <TableCell
         width={styleGlobal.image.width}
         style={{ maxWidth: styleGlobal.image.maxWidth, padding: 6 }}
         align={styleGlobal.image.align}
      >
         <TableListingImage src={src} paddingImageFail={3} />
      </TableCell>
   );
}

export default ImageCell;
