import React, { useContext } from "react";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import ProductTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/ProductTable";

const AllProductTableData = () => {
  const { listProduct } = useContext(AllProductContext);

  return <ProductTable products={listProduct} />;
};

export default AllProductTableData;
