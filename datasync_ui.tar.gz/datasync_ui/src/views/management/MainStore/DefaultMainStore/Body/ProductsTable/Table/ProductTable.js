import React from "react";
import { Box, Divider, makeStyles } from "@material-ui/core";
import SelectedProductProvider from "src/views/management/MainStore/Context/SelectedProductContext";
import AllProductTableActionButton from "src/views/management/MainStore/Component/ActionButton/index";
import ResultTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/ResultTable";
import AllProductTablePagination from "src/views/management/MainStore/Component/AllProductTablePagination";
import { useSelector } from "react-redux";
import AllProductColumnProvider from "src/views/management/MainStore/Context/AllProductColumnContext";
import ResultGrid from "./ResultGrid";
import useShopifyLocation from "src/views/management/Listing/ChannelSettings/ShopifyLocation/useShopifyLocation";

const useStyles = makeStyles(theme => ({
  root: {
    position: "relative",
    flex: 1,
    flexDirection: "column",
    display: "flex",
    overflow: "hidden"
  }
}));

const ProductTable = ({ products = [] }) => {
  const classes = useStyles();
  const { defaultListing } = useSelector(state => state.listing);
  useShopifyLocation();
  const defaultType = defaultListing.type;

  return (
    <Box className={classes.root}>
      <SelectedProductProvider>
        <AllProductColumnProvider>
          <React.Fragment>
            <AllProductTableActionButton />
            <ResultTable products={products} defaultType={defaultType} />
            <ResultGrid products={products} defaultType={defaultType} />
            <Divider />
            <AllProductTablePagination />
          </React.Fragment>
        </AllProductColumnProvider>
      </SelectedProductProvider>
    </Box>
  );
};

export default ProductTable;
