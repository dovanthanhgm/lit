import React, { useContext } from "react";
import ProductLoading from "src/views/management/ProductEditView/ProductLoading";
// import {
//   Grid,
//   TableHeaderRow,
//   TableSelection
// } from "@devexpress/dx-react-grid-material-ui";
// import { IntegratedSelection } from "@devexpress/dx-react-grid";
// import SelectionTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/Selection";
// import CustomTable from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/CustomTable";
import { extraColumn, tableColumns } from "src/constants/Product/TableProduct";
import { makeStyles } from "@material-ui/styles";
import PageScrollbarCustom from "src/components/PageScrollbarCustom";
// import TableVisibleColumns from 'src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/TableVisibleColumns';
import { useSelector } from "react-redux";
import { AllProductColumnContext } from "src/views/management/MainStore/Context/AllProductColumnContext";
import { Table } from "@material-ui/core";
import AllProductTableHeader from "./AllProductTableHeader";
import AllProductTableBody from "./AllProductTableBody";

const useStyles = makeStyles(() => ({
  root: {
    "& .MuiTableHead-root": {
      position: "sticky",
      top: 0,
      backgroundColor: "white",
      zIndex: 2
    }
  },
  customTable: {
    borderCollapse: "separate",
    "& .MuiTableCell-sizeSmall": {
      padding: "6px" // <-- arbitrary value
    },
    "& .MuiTableCell-head": { whiteSpace: "nowrap" }
  }
}));

const handleProductTable = channelType => {
  const columns = [...tableColumns, ...extraColumn];
  if (channelType !== "shopify") {
    return columns.filter(col => col.name !== "product_type");
  }
  return columns;
};

const ResultTable = ({ products = [], defaultType = "" }) => {
  const classes = useStyles();
  const productTableColumn = handleProductTable(defaultType);
  const { hideColumns } = useContext(AllProductColumnContext);
  const { listingStyle } = useSelector(state => state.listing);

  const showColumns = productTableColumn
    .map(col => col.name)
    .filter(col => !hideColumns.includes(col))
    .map(col => productTableColumn.find(column => column.name === col));

  return (
    <PageScrollbarCustom
      position="relative"
      style={{ maxHeight: listingStyle === "table" ? "100%" : 0 }}
      extendClass={classes.root}
    >
      <React.Fragment>
        <ProductLoading productLength={products.length} />
        <Table style={{ width: "100%" }} className={classes.customTable}>
          <AllProductTableHeader
            products={products}
            showColumns={showColumns}
          />
          <AllProductTableBody products={products} showColumns={showColumns} />
        </Table>
        {/* <Grid
          rows={products}
          columns={productTableColumn}
          getRowId={row => {
            return row.id;
          }}
          >
          <SelectionTable />
          <IntegratedSelection />
          <CustomTable />
          <TableVisibleColumns />
          <TableHeaderRow />
          <TableSelection showSelectAll />
        </Grid> */}
      </React.Fragment>
    </PageScrollbarCustom>
  );
};

export default React.memo(ResultTable);
