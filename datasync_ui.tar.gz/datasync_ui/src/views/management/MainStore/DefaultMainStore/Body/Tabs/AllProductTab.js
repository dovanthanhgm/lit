import React, { useContext } from "react";
import {
  Box,
  Chip,
  makeStyles,
  Tab,
  Tabs,
  Typography
} from "@material-ui/core";
import { productTabs } from "src/constants/Product/index";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";
import { allProductLoading } from "src/actions/product";
import { useDispatch } from "react-redux";
import TabLabelCustom from "src/components/Layout/TabLabelCustom";

const useStyles = makeStyles(theme => ({
  tabRoot: {
    width: "auto",
    // minWidth: 100,
    opacity: 1,
    height: 40
  },
  labelSmall: {
    paddingLeft: theme.spacing(0.5),
    paddingRight: theme.spacing(0.5)
  },
  chip: {
    marginLeft: theme.spacing(1)
  },
  chipNotSelected: {
    marginLeft: theme.spacing(1),
    color: "#546e7a",
    backgroundColor: "#e4e4e4"
  }
}));

const AllProductTab = () => {
  const classes = useStyles();
  const dispatch = useDispatch();

  const { tab, setTab, countProduct, setPage } = useContext(
    AllProductCountContext
  );

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const handleChangeProductTab = (_, value) => {
    if (tab !== value) {
      setTab(value);
      setLoading(true);
      setPage(1);
    }
  };

  const isSelected = tabItem => tabItem === tab;

  return (
    <Tabs onChange={handleChangeProductTab} value={tab}>
      {productTabs?.map((tab, index) => {
        return (
          <Tab
            size="small"
            classes={{
              root: classes.tabRoot
            }}
            disabled={countProduct?.[tab.value] === 0}
            key={tab?.value || index}
            value={tab?.value || ""}
            label={
              <Box display="flex" alignItems={"center"} justifyContent="center">
                <TabLabelCustom>
                  <Typography variant="body2" component={"span"}>
                    {tab?.name}
                  </Typography>
                </TabLabelCustom>
                <Chip
                  size="small"
                  label={countProduct?.[tab.value]}
                  color="primary"
                  // classes={{ labelSmall: classes.labelSmall }}
                  className={
                    !isSelected(tab.value)
                      ? classes.chipNotSelected
                      : classes.chip
                  }
                />
              </Box>
            }
          />
        );
      })}
    </Tabs>
  );
};

export default AllProductTab;
