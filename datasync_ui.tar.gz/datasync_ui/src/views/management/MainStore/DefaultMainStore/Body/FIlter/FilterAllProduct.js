import { Box, Button, Grid, useMediaQuery } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import { Form, Formik } from "formik";
import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router";
import ButtonCustom from "src/components/MUI/Button";
import TextFieldCustom from "src/components/MUI/Formik/Text";
import { useQueryV2 } from "src/hooks/useQuery";
import { useDispatch, useSelector } from "react-redux";
import CustomFilter from "src/components/Filter/index";
import ProductFilter from "src/components/Filter/Products/ProductFilter";
import CategoryFilter from "src/components/Filter/Products/CategoryFilter";
import FilterChip from "src/components/Filter/Products/FilterChip";
import AllProductSort from "src/views/management/MainStore/Component/AllProductSort";
import {
  allProductLoading,
  saveProductFilterParams
} from "src/actions/product";
import { isEqual } from "lodash";
import AllProductStatusFilter from "src/components/Filter/Products/AllProductStatusFilter";

const useStyles = makeStyles(theme => ({
  root: {},
  formControl: {
    minWidth: 200
  }
}));

const getParams = (search = "") => {
  const params = new URLSearchParams(search);
  const paramsValue = {};
  for (const [key, value] of params.entries()) {
    paramsValue[key] = value;
  }
  return paramsValue;
};

export default function FilterAllProduct() {
  const dispatch = useDispatch();
  const classes = useStyles();
  const { productId } = useParams();
  const { search, state } = useQueryV2();
  const { defaultListing } = useSelector(state => state.listing);
  const productFilterParams = useSelector(
    state => state.product.productFilterParams
  );
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const history = useHistory();
  const matchesMedium = useMediaQuery(`(min-width: 1040px)`);
  const matchesButton = useMediaQuery(`(min-width: 1220px)`);
  const matchStatus = useMediaQuery(`(min-width: 1220px)`);
  const isBigcommerce = defaultListing.type === "bigcommerce";
  const isShopify = defaultListing.type === "shopify";
  const showMoreBpn = isBigcommerce && !matchesButton;

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const {
    title = "",
    min_price = "",
    sku = "",
    max_price = "",
    min_qty = "",
    max_qty = "",
    in_channel = "",
    nin_channel = "",
    bpn = "",
    category = "",
    status = "",
    product_type = "",
    product_format = "",
    brands = "",
    tags = ""
  } = useQueryV2();

  const initValue = {
    title,
    sku,
    min_price,
    max_price,
    min_qty,
    max_qty,
    in_channel,
    nin_channel,
    category,
    bpn,
    status,
    product_type,
    product_format,
    brands,
    tags
  };

  // const actionQuery = (getValue = function() {}) => {
  //   return initKey.reduce((prev, curr) => {
  //illegal invocation ?? getValue = params.get
  //     prev[curr] = getValue("title") || "";
  //     return prev;
  //   }, {});
  // };

  const productFilterParamsSearch = productFilterParams.search;

  const handleInit = () => {
    if (!!productFilterParamsSearch) {
      return getParams(productFilterParamsSearch);
    }
    return initValue;
  };

  const gridProduct = () => {
    if (!matchesButton && matchesMedium) {
      return 6;
    } else if (!matchesMedium) {
      return 12;
    }
    return 4;
  };

  const gridSku = () => {
    if (!matchesButton) {
      return 6;
    }
    return 3;
  };

  useEffect(() => {
    if (!!state || !!search) {
      dispatch(saveProductFilterParams({ state, search }));
    }
    // eslint-disable-next-line
  }, [state, search]);

  return (
    <Formik
      initialValues={handleInit()}
      enableReinitialize
      onSubmit={async values => {
        try {
          let isCount = 0;
          let search = ``;
          Object.keys(values).forEach((key, index) => {
            const conditionFilter = field => {
              if (Array.isArray(field)) {
                return field.length !== 0;
              }
              return ![null, undefined, "", "NaN", NaN].includes(field);
            };
            if (conditionFilter(values[key])) {
              if (index !== 0 && isCount === 1) {
                search += "&";
              } else {
                search += "?";
                isCount = 1;
              }
              search += `${key}=${encodeURIComponent(
                ["title", "sku"].includes(key)
                  ? values[key].trim()
                  : values[key]
              )}`;
            }
          });
          if (!isEqual(values, initValue)) {
            setLoading(true);
          }
          if (productId) {
            const count = state?.countFilter || 0;
            history.push("/products" + search, {
              countFilter: count + 1
            });
            dispatch(
              saveProductFilterParams({
                state: { countFilter: count + 1 },
                search
              })
            );
          } else {
            const count = state?.countFilter || 0;
            dispatch(
              saveProductFilterParams({
                state: { countFilter: count + 1 },
                search
              })
            );
            history.push(
              {
                search: search
              },
              { countFilter: count + 1 }
            );
          }
        } catch (error) {
          console.log("error", error);
        }
      }}
    >
      {({ handleSubmit, isSubmitting, setValues, values, resetForm }) => {
        const extraField = () => {
          let field = {};
          if (showMoreBpn) {
            field = { ...field, bpn: "" };
          }
          if (!matchesMedium) {
            field = { ...field, sku: "" };
          }
          return field;
        };

        const handleReset = async () => {
          await setValues({
            ...values,
            min_price: "",
            max_price: "",
            min_qty: "",
            max_qty: "",
            in_channel: "",
            nin_channel: "",
            product_type: "",
            brands: "",
            tags: "",
            category: "",
            product_format: "",
            ...extraField()
          });
          dispatch(saveProductFilterParams({ state: {}, search: "" }));
          if (!!search) {
            setLoading(true);
          }
          handleSubmit();
        };

        const handleResetForm = () => {
          history.push({ search: "" });
          if (!!search) {
            setLoading(true);
          }
          dispatch(saveProductFilterParams({ state: {}, search: "" }));
          resetForm();
          // handleSubmit();
        };

        return (
          <Form className={classes.root} onSubmit={handleSubmit}>
            <CustomFilter
              open={open}
              setOpen={setOpen}
              handleReset={handleReset}
            >
              <ProductFilter
                showSku={!matchesMedium}
                categoryList={options}
                setCategoryList={setOptions}
                showCategory={!isBigcommerce && matchesButton}
                showBpn={showMoreBpn}
                isBigcommerce={isBigcommerce}
                showStatus={!matchStatus}
                isShopify={isShopify}
              />
            </CustomFilter>
            <Box
              p={1}
              pb={0}
              pt={1}
              style={{ minWidth: 768 }}
              display="flex"
              alignItems="center"
              justifyContent="space-between"
            >
              <Grid container alignItems="center" spacing={1}>
                <Grid item xs={gridProduct()}>
                  <TextFieldCustom
                    placeholder="Search products"
                    name="title"
                    fullWidth
                    useDefaultStartAdornment
                  />
                </Grid>
                {matchesMedium && (
                  <Grid item xs={gridSku()}>
                    <TextFieldCustom
                      placeholder="Search SKUs"
                      name="sku"
                      fullWidth
                      // useDefaultStartAdornment
                    />
                  </Grid>
                )}
                {isBigcommerce && matchesButton && (
                  <Grid item xs={4}>
                    <TextFieldCustom
                      placeholder="Search BPN"
                      name="bpn"
                      fullWidth
                      useDefaultStartAdornment
                    />
                  </Grid>
                )}
                <Grid
                  item
                  xs={3}
                  style={{
                    display: !isBigcommerce && matchesButton ? "block" : "none",
                    width: !isBigcommerce && matchesButton ? "auto" : 0
                  }}
                >
                  <CategoryFilter
                    isShow
                    categoryList={options}
                    setCategoryList={setOptions}
                  />
                </Grid>
                {!isBigcommerce && matchStatus && (
                  <Grid item xs={2}>
                    <AllProductStatusFilter isShow />
                  </Grid>
                )}
              </Grid>
              <Box display="flex" alignItems="center" ml={1}>
                <Box mr={1} ml={1}>
                  <ButtonCustom
                    text="Search"
                    color="primary"
                    onClick={handleSubmit}
                    type="submit"
                    disabled={isSubmitting}
                  />
                </Box>
                <ButtonCustom
                  disabled={isSubmitting}
                  notShowCircle={isSubmitting}
                  color="secondary"
                  onClick={handleResetForm}
                  text="Clear"
                />
                <Box ml={1} />
                <AllProductSort />
                <Box ml={1} />
                <Button
                  variant="contained"
                  color="primary"
                  size="small"
                  style={{
                    whiteSpace: "nowrap"
                  }}
                  onClick={() => setOpen(true)}
                >
                  More filters
                </Button>
              </Box>
            </Box>
            <FilterChip isProduct />
            {/*<Box p={2} pt={0} display="flex" alignItems="center">*/}
            {/*  <FilterChip handleDelete={handleDelete} />*/}
            {/*</Box>*/}
          </Form>
        );
      }}
    </Formik>
  );
}
