import React from "react";
import MainStoreLayout from "src/views/management/MainStore/Layout/index";
import { Container } from "@material-ui/core";
import AllProductProcessProvider from "src/views/management/MainStore/Context/AllProductProcessContext";
import TableProductLayout from "src/views/management/MainStore/Layout/TableProductLayout";
import DefaultAllProductsHeader from "src/views/management/MainStore/Component/Header/index";
import AllProductContent from "src/views/management/MainStore/DefaultMainStore/Body/index";
import AllProductAlertProvider from "src/views/management/MainStore/Context/AllProductAlertContext";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

const DefaultMainStore = () => {
  return (
    <MainStoreLayout>
      <ErrorBoundaryComponent>
        <Container
          maxWidth={false}
          style={{
            maxHeight: "100%",
            display: "flex",
            flexDirection: "column",
            padding: "0 12px"
          }}
        >
          <AllProductProcessProvider>
            <TableProductLayout>
              <AllProductAlertProvider>
                <React.Fragment>
                  <DefaultAllProductsHeader />
                  <AllProductContent />
                </React.Fragment>
              </AllProductAlertProvider>
            </TableProductLayout>
          </AllProductProcessProvider>
        </Container>
      </ErrorBoundaryComponent>
    </MainStoreLayout>
  );
};

export default DefaultMainStore;
