import { useSelector } from "react-redux";
import useGetProductsOrigin from "src/utils/products";
import moment from "moment";
import { Table } from "@devexpress/dx-react-grid-material-ui";
import ImageProduct from "src/components/ListImageProduct/ImageProduct";
import { Box, makeStyles, Tooltip, Typography } from "@material-ui/core";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import TableProductItemName from "src/components/Products/EditProduct/TableProductItemName";
import React from "react";
import { withStyles } from "@material-ui/core/styles";
import Label from "src/components/Label";
import ProductTableQty from "src/components/Products/ListProdutcs/ProductTableQTY";

const useStyles = makeStyles(theme => ({
  root: {
    position: "relative"
  },
  queryField: {
    width: 500
  },
  image: {
    height: 48,
    width: 48
  },
  cartImage: {
    height: 24,
    width: 24,
    marginRight: theme.spacing(0.25)
  },
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const tableCellPadding = 6;

const CustomTooltip = withStyles(theme => ({
  tooltip: {
    fontSize: 12,
    maxWidth: 350
  }
}))(Tooltip);

const fulfilledItem = item => {
  switch (item) {
    case "fba":
      return <Typography>Amazon</Typography>;
    default:
      return <Typography>Merchant</Typography>;
  }
};

const AllProductTableCell = props => {
  const classes = useStyles();
  const { column, row } = props;

  const { listings } = useSelector(state => state.listing);

  const { channelOrigin, isMainMarket } = useGetProductsOrigin(row);

  const updateTime = () => {
    if (moment(row?.updated_at).isValid()) {
      return moment(row?.updated_at).format("MMM DD, YYYY");
    }
    return <span>&nbsp;</span>;
  };

  if (column.name === "image") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <ImageProduct
          src={row.thumb_image.url}
          className={classes.image}
          paddingImageFail={2}
        />
      </Table.Cell>
    );
  }

  if (column.name === "manage_stock") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography
          variant="body2"
          // color="textPrimary"
          // className={classes.name}
        >
          {row.manage_stock ? "Yes" : "No"}
        </Typography>
      </Table.Cell>
    );
  }

  if (column.name === "price") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography
          variant="body2"
          // color="textPrimary"
          // className={classes.name}
        >
          {row.price}
        </Typography>
      </Table.Cell>
    );
  }

  if (column.name === "sale_price") {
    const rowSpecialPrice = row?.special_price?.price;

    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography
          variant="body2"
          // color="textPrimary"
          // className={classes.name}
        >
          {rowSpecialPrice}
        </Typography>
      </Table.Cell>
    );
  }

  if (column.name === "is_in_stock") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography
          variant="body2"
          // color="textPrimary"
          // className={classes.name}
        >
          {row.is_in_stock ? "Yes" : "No"}
        </Typography>
      </Table.Cell>
    );
  }

  if (column.name === "updated_time") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography variant="body2">{updateTime()}</Typography>
      </Table.Cell>
    );
  }

  if (column.name === "sku") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <CustomTooltip title={row.sku} placement="bottom-start">
          <Typography
            variant="body2"
            color="textPrimary"
            className={classes.name}
          >
            {row.sku}
          </Typography>
        </CustomTooltip>
      </Table.Cell>
    );
  }

  if (column.name === "qty") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <ProductTableQty row={row} classes={classes} />
      </Table.Cell>
    );
  }

  if (column.name === "fulfilled") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography
          variant="body2"
          color="textPrimary"
          className={classes.name}
        >
          {fulfilledItem(row?.template_data?.offer?.fulfillment)}
        </Typography>
      </Table.Cell>
    );
  }

  if (column.name === "invisible") {
    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Typography
          variant="body2"
          color="textPrimary"
          className={classes.name}
        >
          <Label color={!!row?.invisible ? "warning" : "success"}>
            {!!row?.invisible ? "Inactive" : "active"}
          </Label>
        </Typography>
      </Table.Cell>
    );
  }

  if (column.name === "origin") {
    const Origin = () => {
      return (
        <Box>
          <CartLogo
            className={classes.cartImage}
            id={channelOrigin()?.type}
            isHover
            hoverDetail={channelOrigin()?.name}
          />
        </Box>
      );
    };

    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        {channelOrigin() ? <Origin /> : ""}
      </Table.Cell>
    );
  }

  if (column.name === "active_listings") {
    const handleClickChannel = channel => {
      const mapChannel = listings.find(
        channels => channels.name === channel.name
      );
      if (mapChannel) {
        return `/listing/${mapChannel.id}/${
          isMainMarket ? row.publish_id : row.id
        }`;
      }
    };

    return (
      <Table.Cell {...props} style={{ padding: tableCellPadding }}>
        <Box display="flex" flexWrap={"wrap"} justifyContent={"flex-end"}>
          {row.active_listings?.length > 0 &&
            row.active_listings.map(item => {
              if (item.name === "Main Store") {
                return null;
              }

              return (
                <CartLogo
                  key={`${item.name}${item.type}`}
                  className={classes.cartImage}
                  id={item.type}
                  isHover
                  url={handleClickChannel(item)}
                  hoverDetail={item.name}
                />
              );
            })}
        </Box>
      </Table.Cell>
    );
  }

  if (column.name === "name") {
    return <TableProductItemName row={row} {...props} />;
  }

  return (
    <Table.Cell {...props} style={{ padding: tableCellPadding }}>
      <Typography variant="body2">{row?.[column.name]}</Typography>
    </Table.Cell>
  );
};

export default AllProductTableCell;
