import React, { useContext } from "react";
import { AllProductAlertContext } from "src/views/management/MainStore/Context/AllProductAlertContext";
import { Box } from "@material-ui/core";
import SingleAlert from "src/components/Notify/SingleAlert";

const ListOnChannelAlert = () => {
  const { alert } = useContext(AllProductAlertContext);
  const listChannelAlert = alert?.listOnChannel || null;

  if (!listChannelAlert) {
    return null;
  }

  return (
    <Box mb={0.25}>
      <SingleAlert content={listChannelAlert} type={"warning"} />
    </Box>
  );
};

export default ListOnChannelAlert;
