import React, { useContext } from "react";
import { Box } from "@material-ui/core";
import SingleAlert from "src/components/Notify/SingleAlert";
import { Link } from "react-router-dom";
import { AllProductProcessContext } from "src/views/management/MainStore/Context/AllProductProcessContext";
import { makeStyles } from "@material-ui/styles";

const useStyles = makeStyles(theme => ({
  link: {
    textDecoration: "none"
  }
}));

const ImportProductAlert = () => {
  const classes = useStyles();
  const { process } = useContext(AllProductProcessContext);

  if (process?.[0]?.status === "pulling") {
    return (
      <Box mb={0.25}>
        <SingleAlert
          type="info"
          content={
            <>
              <Box>
                We'll import your Main Store as quickly as possible, but it may
                be take some time.
              </Box>
              <Box>
                You can navigate away from this page - importing won't be
                affected. We'll notify you when it's done.{" "}
                <Link to={"/activities"} className={classes.link}>
                  more detail
                </Link>
              </Box>
            </>
          }
        />
      </Box>
    );
  }
  return null;
};

export default ImportProductAlert;
