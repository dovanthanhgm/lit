import React from "react";
import ImportProductAlert from "src/views/management/MainStore/Component/ALlProductAlert/ImportAlert";
import ListOnChannelAlert from "src/views/management/MainStore/Component/ALlProductAlert/ListOnChannelAlert";
import { Box } from "@material-ui/core";

const ALlProductAlert = () => {
  return (
    <Box>
      <ImportProductAlert />
      <ListOnChannelAlert />
    </Box>
  );
};

export default ALlProductAlert;
