import React, { useContext, useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { FormControl, MenuItem, Select, Typography } from "@material-ui/core";
import { useQueryV2 } from "src/hooks/useQuery";
import { useHistory } from "react-router-dom";
import { ProductTableSortAPI } from "src/constants/TableSortAPI";
import { makeStyles } from "@material-ui/styles";
import { allProductLoading } from "src/actions/product";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";

const useStyles = makeStyles(theme => ({
  formControl: {
    minWidth: 100,
    width: "auto",
    "& .MuiSelect-root": { paddingTop: 8.5, paddingBottom: 8.5 }
  }
}));

const listSort = {
  "-name": { colName: "name", sort: "asc" },
  name: { colName: "name", sort: "name" },
  "-sku": { colName: "sku", sort: "asc" },
  sku: { colName: "sku", sort: "name" },
  price: { colName: "price", sort: "asc" },
  "-price": { colName: "price", sort: "name" },
  "-qty": { colName: "total available", sort: "asc" },
  qty: { colName: "total available", sort: "name" },
  "-updated_at": { colName: "last modified", sort: "asc" },
  updated_at: { colName: "last modified", sort: "name" },
  "-created_at": { colName: "created at", sort: "asc" },
  created_at: { colName: "created at", sort: "name" }
};

const AllProductSort = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const { total } = useContext(AllProductCountContext);
  const productFilterParams = useSelector(
    state => state.product.productFilterParams
  );
  const { defaultListing } = useSelector(state => state.listing);

  const { search, state } = useQueryV2();

  const initSort = !!productFilterParams?.state?.sort
    ? productFilterParams.state.sort
    : state?.sort || "";

  const initSearch = !!productFilterParams?.search
    ? productFilterParams.search
    : search;

  const getSortState = () => {
    return initSort?.split("=")?.[1] || "";
  };

  const channelID = defaultListing.id;
  const channelType = defaultListing?.type;

  const localstorageSort = useMemo(() => {
    if (initSort) {
      return initSort;
    }
    return "";
  }, [initSort]);

  const [select, setSelect] = useState("");

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const handleChangeSelectSort = event => {
    const params = new URLSearchParams(initSearch);
    setLoading(!!total);
    if (!event?.target?.value) {
      localStorage.removeItem("productSort");
      setSelect("");
      history.push({ search: params.toString() });
    }
    if (Object.keys(listSort).includes(event?.target?.value)) {
      localStorage.setItem(
        "productSort",
        JSON.stringify({ [channelID]: event.target.value })
      );
      const sortData =
        ProductTableSortAPI[listSort[event.target.value].colName][
          listSort[event.target.value].sort
        ];
      setSelect(event.target.value);
      history.push({ search: params.toString() }, { sort: sortData });
    }
    if (event.target.value === "") {
      localStorage.removeItem("productSort");
      setSelect("");
      history.push({ search: params.toString() });
    }
  };

  useEffect(() => {
    setSelect(getSortState(localstorageSort));
    // eslint-disable-next-line
  }, [localstorageSort]);

  return (
    <FormControl
      variant="outlined"
      className={classes.formControl}
      size="small"
    >
      <Select value={select} onChange={handleChangeSelectSort} displayEmpty>
        <MenuItem value="">
          <Typography variant="body2">Sort by</Typography>
        </MenuItem>
        <MenuItem value={"name"}>
          <Typography variant="body2">Title A-Z</Typography>
        </MenuItem>
        <MenuItem value={"-name"}>
          <Typography variant="body2">Title Z-A</Typography>
        </MenuItem>
        <MenuItem value={"sku"}>
          <Typography variant="body2">SKU A-Z</Typography>
        </MenuItem>
        <MenuItem value={"-sku"}>
          <Typography variant="body2">SKU Z-A</Typography>
        </MenuItem>
        <MenuItem value={"price"}>
          <Typography variant="body2">Price: High - Low</Typography>
        </MenuItem>
        <MenuItem value={"-price"}>
          <Typography variant="body2">Price: Low - High</Typography>
        </MenuItem>
        <MenuItem value={"qty"}>
          <Typography variant="body2">Low inventory</Typography>
        </MenuItem>
        <MenuItem value={"-qty"}>
          <Typography variant="body2">High inventory</Typography>
        </MenuItem>
        {channelType !== "ebay" && (
          <MenuItem value={"updated_at"}>
            <Typography variant="body2">Modified (oldest first)</Typography>
          </MenuItem>
        )}
        {channelType !== "ebay" && (
          <MenuItem value={"-updated_at"}>
            <Typography variant="body2">Modified (newest first)</Typography>
          </MenuItem>
        )}
        <MenuItem value={"created_at"}>
          <Typography variant="body2">Created date (oldest first)</Typography>
        </MenuItem>
        <MenuItem value={"-created_at"}>
          <Typography variant="body2">Created date (newest first)</Typography>
        </MenuItem>
      </Select>
    </FormControl>
  );
};

export default AllProductSort;
