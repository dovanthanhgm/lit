import React from "react";
import ALlProductAlert from "src/views/management/MainStore/Component/ALlProductAlert/index";
import AllProductHeader from "src/views/management/MainStore/Component/AllProductHeader/index";

const DefaultAllProductsHeader = () => {
  return (
    <React.Fragment>
      <ALlProductAlert />
      <AllProductHeader />
    </React.Fragment>
  );
};

export default DefaultAllProductsHeader;
