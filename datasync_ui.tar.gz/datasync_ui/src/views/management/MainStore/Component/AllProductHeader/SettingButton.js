import React from "react";
import { Box, Button } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import SettingsIcon from "@material-ui/icons/Settings";
import { DEFAULT_ICON_APP_NAV_SIDE } from "src/constants/index";

const SettingButton = () => {
  const history = useHistory();

  return (
    <Box ml={1}>
      <Button
        color="primary"
        variant="contained"
        size="small"
        onClick={() => history.push("/source-cart")}
        className="first-step"
      >
        <SettingsIcon
          style={{ fontSize: DEFAULT_ICON_APP_NAV_SIDE, marginRight: 2 }}
        />
        Settings
      </Button>
    </Box>
  );
};

export default SettingButton;
