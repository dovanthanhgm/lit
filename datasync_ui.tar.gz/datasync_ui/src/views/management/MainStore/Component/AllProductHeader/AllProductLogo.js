import React from "react";
import { Box, makeStyles } from "@material-ui/core";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import { useSelector } from "react-redux";
import HeaderPageTitle from "src/components/Layout/HeaderPageTitle";

const useStyles = makeStyles(theme => ({
  root: {},
  cartImage: {
    width: 32,
    height: 32
  },
  wixImage: {
    width: 62,
    height: 25
  },
  wishImage: {
    width: 60,
    height: 20
  }
}));

const AllProductLogo = () => {
  const classes = useStyles();
  const { defaultListing } = useSelector(state => state.listing);

  const channelImage = {
    wix: classes.wixImage,
    wish: classes.wishImage
  };

  return (
    <Box flexGrow={1} display="flex" alignItems="center">
      <CartLogo
        id={defaultListing?.type}
        isDefault
        className={channelImage?.[defaultListing?.type] || classes.cartImage}
      />
      <HeaderPageTitle
        color="textPrimary"
        component="span"
        style={{ marginLeft: 8 }}
      >
        All Products
      </HeaderPageTitle>
    </Box>
  );
};

export default AllProductLogo;
