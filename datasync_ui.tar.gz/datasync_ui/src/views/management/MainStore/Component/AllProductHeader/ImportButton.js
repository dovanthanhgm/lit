import React from "react";
import { Box, Button, Tooltip } from "@material-ui/core";
import { convertIdToName } from "src/utils/helper";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import useUserExp from "src/hooks/useUserExp";
import {DEFAULT_ICON_APP_NAV_SIDE} from "src/constants/index";
import GetAppIcon from "@material-ui/icons/GetApp";

const ImportProductsButton = () => {
  const history = useHistory();
  const { expired } = useUserExp();
  const { defaultListing } = useSelector(state => state.listing);
  const isShowButton = defaultListing?.type !== "file";

  const importFromChannel = async () => {
    history.push(`/import-data/listings/${defaultListing?.id}`);
  };

  if (!isShowButton) {
    return null;
  }

  return (
    <Box ml={1}>
      <Tooltip title={"Import new products from Main Store."}>
        <span>
          <Button
            color="primary"
            variant="contained"
            size="small"
            onClick={importFromChannel}
            className="first-step"
            disabled={expired}
          >
            <GetAppIcon style={{ fontSize: DEFAULT_ICON_APP_NAV_SIDE, marginRight: 2 }} />{`Import From ${convertIdToName(defaultListing.type)}`}
          </Button>
        </span>
      </Tooltip>
    </Box>
  );
};

export default ImportProductsButton;
