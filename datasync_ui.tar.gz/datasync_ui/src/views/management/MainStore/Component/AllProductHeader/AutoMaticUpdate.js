import React, { useMemo } from "react";
import { Box, Typography, useTheme } from "@material-ui/core";
import { useSelector } from "react-redux";

const AutoMaticUpdate = () => {
  const theme = useTheme();
  const { defaultListing, marketplaces } = useSelector(state => state.listing);
  const initUpdate = [1, "1"].includes(defaultListing?.auto_update);

  const isMainMarket = useMemo(() => {
    return marketplaces?.map(item => item.id)?.includes(defaultListing?.type);
  }, [marketplaces, defaultListing]);

  if (isMainMarket || defaultListing?.type === "file") {
    return null;
  }

  return (
    <Box display="flex" alignItems="center">
      <Typography variant="h6" component="span">
        Auto Update:&nbsp;
      </Typography>
      <Box
        color={
          initUpdate ? theme.palette.primary.main : theme.palette.error.main
        }
      >
        {initUpdate && <Typography variant="h6">On</Typography>}
        {!initUpdate && <Typography variant="h6">Off</Typography>}
      </Box>
    </Box>
  );
};

export default AutoMaticUpdate;
