import React from "react";
import { Box } from "@material-ui/core";
import AllProductLogo from "src/views/management/MainStore/Component/AllProductHeader/AllProductLogo";
import LastImport from "src/views/management/MainStore/Component/AllProductHeader/LastImport";
import AutoMaticUpdate from "src/views/management/MainStore/Component/AllProductHeader/AutoMaticUpdate";
import ButtonBulkExport from "src/views/management/MainStore/Component/AllProductHeader/ButtonBulkExport";
import ImportProductsButton from "src/views/management/MainStore/Component/AllProductHeader/ImportButton";
import SettingButton from "src/views/management/MainStore/Component/AllProductHeader/SettingButton";
import { DEFAULT_MARGIN_BOTTOM_HEADER } from "src/constants/index";
import AutoMaticImport from "src/views/management/MainStore/Component/AllProductHeader/AutoMaticImport";

const AllProductHeader = () => {
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      mb={DEFAULT_MARGIN_BOTTOM_HEADER}
    >
      <AllProductLogo />
      <Box display={"flex"} alignItems={"center"}>
        <LastImport />
        <Box mx={0.5} />
        <AutoMaticImport />
        <Box mx={0.5} />
        <AutoMaticUpdate />
      </Box>

      <ButtonBulkExport />
      <ImportProductsButton />
      <SettingButton />
    </Box>
  );
};

export default React.memo(AllProductHeader);
