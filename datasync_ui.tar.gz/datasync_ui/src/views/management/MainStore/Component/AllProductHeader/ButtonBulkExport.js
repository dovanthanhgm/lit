import React, { useContext, useEffect, useState } from "react";
import ExportProduct from "src/views/management/ProductListView/ExportProduct/index";
import { Box } from "@material-ui/core";
// import BulkUpdate from "src/views/management/ProductListView/BulkUpdate/index";
import useUserExp from "src/hooks/useUserExp";
import { useSelector } from "react-redux";
import { useQueryV2 } from "src/hooks/useQuery";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";

const ButtonBulkExport = () => {
  const { expired } = useUserExp();
  const { user } = useSelector(state => state.account);
  const { total } = useContext(AllProductCountContext);
  const { defaultListing } = useSelector(state => state.listing);

  const conditionShow =
    (user?.enable_bulk_edit || defaultListing?.type === "file") && !expired;
  const [paramFilter, setParamFilter] = useState();

  const {
    title = "",
    min_price = "",
    sku = "",
    max_price = "",
    min_qty = "",
    max_qty = "",
    in_channel = "",
    nin_channel = "",
    bpn = "",
    category = ""
  } = useQueryV2();

  useEffect(() => {
    setParamFilter({
      title,
      min_price,
      sku,
      max_price,
      min_qty,
      max_qty,
      in_channel,
      category,
      nin_channel,
      bpn
    });
  }, [
    title,
    min_price,
    sku,
    max_price,
    min_qty,
    category,
    max_qty,
    in_channel,
    nin_channel,
    bpn
  ]);

  if (!conditionShow) {
    return null;
  }

  return (
    <>
      <Box ml={1}>
        <ExportProduct paramFilter={paramFilter} productMatch={total} />
      </Box>
      {/*<Box ml={1.5}>*/}
      {/*  <BulkUpdate />*/}
      {/*</Box>*/}
    </>
  );
};

export default ButtonBulkExport;
