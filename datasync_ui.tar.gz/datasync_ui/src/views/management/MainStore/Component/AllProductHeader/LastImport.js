import React from "react";
import {Box, Tooltip, Typography} from "@material-ui/core";
import {importTimeAgo} from "src/constants/Product/index";
import HelpIcon from "@material-ui/icons/Help";
import {useSelector} from "react-redux";
import {capitalizeFirstLetter} from "src/utils/CapitalizeFirstLetter";
//
const LastImport = () => {
  const {defaultListing} = useSelector(state => state.listing);
  const lastImport = defaultListing?.last_imported;

  if (!lastImport) {
    return null;
  }
  return (
    <Box display="flex" alignItems="center">
      <Typography variant="body2">
        Last sync {importTimeAgo(lastImport)}
      </Typography>
      <Box mr={0.25}/>
      <Tooltip
        title={
          defaultListing?.type === "file"
            ? "The last time file was imported into LitCommerce"
            : `The last time Auto update or Auto import new products from ${capitalizeFirstLetter(
              defaultListing.type
            )} to LitCommerce were triggered.`
        }
      >
        <span style={{
          writingMode: 'vertical-lr'
        }}>
          <HelpIcon fontSize="small" color="primary"/>
        </span>
      </Tooltip>
    </Box>
  );
};

export default LastImport;
