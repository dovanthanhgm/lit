import React, { useContext, useEffect, useState } from "react";
import CustomPagination from "src/components/MUI/CustomTable/CustomPagination";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";
import { useDispatch, useSelector } from "react-redux";
import { useQueryV2 } from "src/hooks/useQuery";
import { actionSetLimit, allProductLoading } from "src/actions/product";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import { useHistory } from "react-router";
import { useParams } from "react-router";
import { defaultALlProductLimit } from "src/constants/Product/TableProduct";
import wait from "src/utils/wait";

const AllProductTablePagination = () => {
  const dispatch = useDispatch();
  const history = useHistory();

  const { tabTotal, tab, setPage } = useContext(AllProductCountContext);
  const { setSelectedProduct, setLastSelectedRow } = useContext(SelectedProductContext);

  const { productId } = useParams();
  const { search, state: urlState } = useQueryV2();
  const state = urlState || {};
  const page = state?.page || 1;

  const currentState = state || {};
  const limit = useSelector(state => state.product.limit);

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const [tablePage, setTablePage] = useState(1);
  const [tableLimit, setTableLimit] = useState(limit);

  useEffect(() => {
    setTablePage(page);
    setPage(page);
    setLastSelectedRow(-1)
    // eslint-disable-next-line
  }, [page]);

  useEffect(() => {
    setTablePage(1);
    setLastSelectedRow(-1);
    history.replace({
      pathname: window.location.pathname,
      search,
      state: { ...state, page: 1 }
    }); // eslint-disable-next-line
  }, [tab]);

  useEffect(() => {
    setTableLimit(limit);
  }, [limit]);

  const handlePageChange = (_, newPage) => {
    const pageChange = async newPage => {
      let newTablePage = page;
      const params = new URLSearchParams(search);
      if (newPage > 0) {
        newTablePage = newPage + 1;
      } else {
        newTablePage = 1;
      }
      setTablePage(newTablePage);
      setLoading(true);
      await wait(100);
      setSelectedProduct([]);
      setPage(newTablePage);
      if (productId) {
        history.push("/products?" + params.toString(), {
          ...currentState,
          page: newTablePage
        });
      } else {
        history.push(
          { search: params.toString() },
          { ...currentState, page: newTablePage }
        );
      }
    };
    pageChange(newPage);
  };

  const handleLimitChange = event => {
    localStorage.setItem("rowPerPage", event?.target?.value);
    const handleLimit = async limit => {
      handlePageChange(0, 0);
      setTableLimit(limit);
      setLoading(true);
      await wait(70);
      dispatch(actionSetLimit({ limit: limit }));
      setSelectedProduct([]);
    };
    handleLimit(event?.target?.value);
  };

  const handleCustomPage = e => {
    handlePageChange(0, e.target.value);
  };

  return (
    <CustomPagination
      total={tabTotal}
      page={tablePage - 1}
      limit={tableLimit || defaultALlProductLimit}
      onPageChange={handlePageChange}
      onRowPerPageChange={handleLimitChange}
      onHandleCustomPageChange={handleCustomPage}
    />
  );
};

export default AllProductTablePagination;
