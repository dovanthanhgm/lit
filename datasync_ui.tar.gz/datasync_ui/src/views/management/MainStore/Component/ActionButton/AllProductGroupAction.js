import React, { useContext, useEffect, useState } from "react";
import {
  Box,
  Divider,
  MenuItem,
  MenuList,
  Tooltip,
  Typography
} from "@material-ui/core";
import ListProductOnChannel from "src/views/management/MainStore/Component/ActionButton/ListProductOnChannel";
import { makeStyles } from "@material-ui/styles";
import { AllProductActionContext } from "src/views/management/MainStore/Context/AllProductActionContext";
import SelectAllMainStore from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/SelectAll";
import ListTotalProduct from "src/views/management/MainStore/Component/ActionButton/ListTotalProduct";
import useUserExp from "src/hooks/useUserExp";
import ButtonMenuCustom from "src/components/MUI/ButtonMenu";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import PublishIcon from "@material-ui/icons/Publish";
import LinkOffIcon from "@material-ui/icons/LinkOff";
import RemoveFromMainStore from "src/views/management/MainStore/Component/ActionButton/ManageChannel/RemoveFromMainStore";

const useStyles = makeStyles(theme => ({
  menuItem: {
    ...theme.typography.body2,
    fontSize: 14,
    lineHeight: 1.5,
    fontWeight: 500
  }
}));

const optionObject = {
  list: "List Products on Channel",
  remove: "Remove Products on Channel",
  remove_main: "Remove from All Products",
  list_all: <ListTotalProduct />
};

const AllProductGroupAction = () => {
  const classes = useStyles();
  const { isUserFree, expired } = useUserExp();
  const { selectedProduct } = useContext(SelectedProductContext);
  const [action, setAction] = useState("");
  const [open, setOpen] = useState(false);

  const { setActionRun, actionRun } = useContext(AllProductActionContext);

  const handleChange = e => {
    setActionRun(e);
    setOpen(false);
  };

  useEffect(() => {
    setAction(actionRun);
  }, [actionRun]);

  const freeUser = isUserFree || expired;

  return (
    <Box display={"flex"} alignItems={"center"}>
      <ButtonMenuCustom
        open={open}
        setOpen={setOpen}
        title={
          <Typography style={{ fontSize: "0.8125rem", fontWeight: 500 }}>
            {!action ? "Select action" : optionObject[action]}
          </Typography>
        }
        color={"primary"}
        variant={"contained"}
        style={{
          fontSize: 14,
          padding: "3.375px 5px 3.375px 10px"
        }}
      >
        <MenuList>
          <MenuItem
            value="list"
            className={classes.menuItem}
            disabled={!selectedProduct.length}
            onClick={() => handleChange("list")}
          >
            <PublishIcon fontSize={"small"} />
            &nbsp;List Products to Channels
          </MenuItem>
          {!freeUser && (
            <Tooltip
              title={
                selectedProduct.length > 0
                  ? "Only available when none product is selected."
                  : ""
              }
            >
              <div>
                <MenuItem
                  value="list_all"
                  disabled={selectedProduct.length > 0}
                  className={classes.menuItem}
                  onClick={() => handleChange("list_all")}
                >
                  <PublishIcon fontSize={"small"} />
                  &nbsp;
                  <ListTotalProduct />
                </MenuItem>
              </div>
            </Tooltip>
          )}
          <Divider />
          <MenuItem
            value="remove"
            className={classes.menuItem}
            onClick={() => handleChange("remove")}
            disabled={!selectedProduct.length}
          >
            <LinkOffIcon fontSize={"small"} />
            &nbsp;Remove Products from Channels
          </MenuItem>
          <MenuItem
            value="remove_main"
            className={classes.menuItem}
            onClick={() => handleChange("remove_main")}
            disabled={!selectedProduct.length}
          >
            <LinkOffIcon fontSize={"small"} />
            &nbsp;Remove from All Products
          </MenuItem>
        </MenuList>
      </ButtonMenuCustom>
      <ListProductOnChannel />
      <ListProductOnChannel isRemove />
      <SelectAllMainStore />
      <RemoveFromMainStore />
      <Box mx={0.5} />
    </Box>
  );
};

export default AllProductGroupAction;
