import { Button, Dialog, DialogActions, DialogContent, Typography } from '@material-ui/core';
import React, { useImperativeHandle, useState } from 'react';
import { forwardRef } from 'react';
import DialogTitle from 'src/components/Modal/DialogTitle';

const CloseConfirmDialog = forwardRef(function CloseConfirmDialog(props, ref) {
   const { cancel: cancelStep } = props;
   const [open, setOpen] = useState(false);

   useImperativeHandle(ref, () => ({
      open: () => {
         setOpen(current => !current);
      }
   }));

   const cancel = () => setOpen(current => !current);

   return (
      <Dialog open={open} onClose={() => cancel()}>
         <DialogTitle onClose={() => cancel()}>Close Confirm</DialogTitle>
         <DialogContent dividers>
            <Typography variant='subtitle2'>
               Are you sure want to close? Current process might not be fully completed!
            </Typography>
         </DialogContent>
         <DialogActions>
            <Button
               variant='contained'
               size='small'
               color='primary'
               onClick={() => {
                  cancelStep();
                  cancel();
               }}
            >
               Confirm
            </Button>
            <Button variant='contained' size='small' onClick={() => cancel()}>
               Cancel
            </Button>
         </DialogActions>
      </Dialog>
   );
});

export default CloseConfirmDialog;
