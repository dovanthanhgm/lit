import React, { useContext } from "react";
import { Box, Typography } from "@material-ui/core";
import ButtonDelete from "src/components/Button/ButtonDelete";
import { deleteSomeProductsAPI } from "src/services/products";
import { messageError } from "src/utils/ErrorResponse";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import { useSnackbar } from "notistack";
import { useDispatch } from "react-redux";
import { allProductLoading } from "src/actions/product";

const ProductTableDeleteButton = () => {
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const {
    selectedProduct,
    setDisableButton,
    disableButton,
    setSelectedProduct
  } = useContext(SelectedProductContext);
  const { getProduct } = useContext(AllProductContext);

  const handleConfirmDeleteSome = async () => {
    try {
      setLoading(true);
      await deleteSomeProductsAPI({ ids: selectedProduct });
      enqueueSnackbar("Delete success", {
        variant: "success"
      });
      getProduct();
      setLoading(false);
      setSelectedProduct([]);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  return (
    <Box display="flex" mr={1}>
      <ButtonDelete
        buttonText="Delete"
        handleConfirm={handleConfirmDeleteSome}
        headerDialog="Are you sure?"
        contentDialog={
          <Typography color="textPrimary" variant="body1">
            Are you sure you want to remove selected products?
          </Typography>
        }
        buttonTextSubmit="Yes, Remove"
        setDisableButton={setDisableButton}
        disabled={selectedProduct.length === 0 || disableButton}
      />
    </Box>
  );
};

export default ProductTableDeleteButton;
