import {
   Button,
   CircularProgress,
   Dialog,
   DialogActions,
   DialogContent,
   Grid,
   makeStyles
} from '@material-ui/core';
import React, { useEffect } from 'react';
import DialogTitle from 'src/components/Modal/DialogTitle';
import { useState } from 'react';
import { forwardRef } from 'react';
import { useImperativeHandle } from 'react';
import AddDefaultStepper from './AddDefaultTempComponents/AddDefaultStepper';
import DefaultTemplate from './AddDefaultTempComponents/DefaultTemplate';
import { Form, Formik } from 'formik';
import { templateValidate } from 'src/utils/Validates';
import { convertFakeToReal } from 'src/utils/convertData';
import { defaultChannelSubmitData } from './AddDefaultTempComponents/utils';
import { postCreateTemplates } from 'src/services/templates';
import { useSnackbar } from 'notistack';
import { alertError } from 'src/helper/showErrorMessage';
import { messageError } from 'src/utils/ErrorResponse';
import AddDefaultTempAlert from './AddDefaultTempComponents/AddDefaultTempAlert';
import AddDefaultLoading from './AddDefaultTempComponents/AddDefaultLoading';
import CloseConfirmDialog from './AddDefaultTempComponents/CloseConfirmDialog';
import { useRef } from 'react';
import AddDefaultHeader from './AddDefaultTempComponents/AddDefaultHeader';

const useStyles = makeStyles(theme => ({
   buttonProgress: {
      position: 'absolute',
      margin: 'auto'
   }
}));

const AddDefaultTemplate = forwardRef(function AddDefaultTemplate(props, ref) {
   const { handleSubmit = () => {} } = props;

   const classes = useStyles();

   const [open, setOpen] = useState(false);
   const [templates, setTemplates] = useState([]);
   const [channelType, setChannelType] = useState(null);
   const [activeStep, setActiveStep] = useState(1);
   const [channelID, setChannelID] = useState(null);
   const [loading, setLoading] = useState(false);
   const [skipping, setSkipping] = useState(false);
   const [doneSubmitting, setSubmitting] = useState(false);

   const templateType = templates[activeStep - 1];
   const validateType = templateValidate[channelType]?.[templateType];
   const isLastStep = activeStep - 1 === templates.length && templates.length !== 0;
   //Because the stepper step always plus 1 to the templates length

   const refConfirm = useRef(null);

   const { enqueueSnackbar } = useSnackbar();

   const initialValues = {
      name: `Default Template`,
      default: true
   };

   useImperativeHandle(ref, () => ({
      openAddDefault: (temps, type, listChannel) => {
         setOpen(() => true);
         setChannelID(listChannel[0]);
         setTemplates(() => temps);
         setChannelType(() => type);
      }
   }));

   useEffect(() => {
      const addDraft = async () => {
         await handleSubmit();
         setSubmitting(() => true);
      };
      if (isLastStep) addDraft();
      // eslint-disable-next-line
   }, [activeStep]);

   useEffect(() => {
      if (doneSubmitting && open) {
         window.location.href = `/listing/detail/${channelID}`;
      }
      // eslint-disable-next-line
   }, [doneSubmitting, open]);

   const cancel = () => {
      setOpen(() => false);
      setActiveStep(() => 1);
      setTemplates(() => []);
      setChannelType(() => null);
      setChannelID(() => null);
   };

   const submit = async values => {
      setLoading(current => !current);

      try {
         let body = convertFakeToReal({
            channelType,
            templateType,
            values
         });
         body = defaultChannelSubmitData({
            channelType,
            body,
            type: templateType
         });
         const res = await postCreateTemplates({
            typeChannel: channelType,
            body: { ...body, type: templateType },
            channelID
         });

         if (res && !res.message) {
            // if (isFirstSetup) {
            //    return handleAddTemplateSuccess();
            // }
            enqueueSnackbar('Success', {
               variant: 'success'
            });

            setActiveStep(current => current + 1);
         } else {
            throw new Error('Error');
         }
      } catch (e) {
         console.log('error', e);
         enqueueSnackbar(alertError(messageError(e, 'Save template fail')), {
            variant: 'error'
         });
      }

      setLoading(current => !current);
   };

   const renderContent = () => {
      if (!isLastStep)
         return (
            <DefaultTemplate channelID={channelID} type={channelType} templateType={templateType} />
         );
      return <AddDefaultLoading />;
   };

   return (
      <React.Fragment>
         <Dialog
            open={open}
            fullWidth
            PaperProps={{
               style: {
                  maxWidth: '90%',
                  height: '90%'
               }
            }}
         >
            <DialogTitle onClose={() => refConfirm.current.open()}>
               Add Default Templates
            </DialogTitle>

            <Formik
               initialValues={initialValues}
               onSubmit={values => submit(values)}
               validationSchema={validateType}
               validateOnChange={false}
            >
               {formik => (
                  <Form style={{ height: '94%' }}>
                     {/* Content */}
                     <DialogContent dividers style={{ height: '94%' }}>
                        <Grid container>
                           {/* Stepper */}
                           <Grid item xs={2}>
                              <AddDefaultStepper activeStep={activeStep} templates={templates} />
                           </Grid>
                           {/* Template */}
                           <Grid item xs={10}>
                              {!isLastStep && <AddDefaultTempAlert setActiveStep={setActiveStep} />}
                              <AddDefaultHeader
                                 isLastStep={isLastStep}
                                 channelID={channelID}
                                 setActiveStep={setActiveStep}
                                 templateType={templateType}
                                 channelType={channelType}
                                 setSkipping={setSkipping}
                                 skipping={skipping}
                                 loading={loading}
                              />
                              {renderContent()}
                           </Grid>
                        </Grid>
                     </DialogContent>

                     {/* Button */}
                     {!isLastStep && (
                        <DialogActions style={{ maxHeight: 48 }}>
                           <Button
                              variant='contained'
                              size='small'
                              color='primary'
                              type='submit'
                              disabled={loading || skipping}
                           >
                              Save & Continue
                              {loading && (
                                 <CircularProgress size={20} className={classes.buttonProgress} />
                              )}
                           </Button>
                        </DialogActions>
                     )}
                  </Form>
               )}
            </Formik>
         </Dialog>

         <CloseConfirmDialog ref={refConfirm} cancel={cancel} />
      </React.Fragment>
   );
});

export default AddDefaultTemplate;
