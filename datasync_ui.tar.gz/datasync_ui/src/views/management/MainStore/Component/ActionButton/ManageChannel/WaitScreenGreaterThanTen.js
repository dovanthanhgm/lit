import React from "react";
import { Box, Checkbox, FormControlLabel, Typography } from "@material-ui/core";
import { localSHowGuidePath } from "src/constants/Product/ActionProduct";

const WaitScreenGreaterThanTen = () => {
  const handleCheck = () => {
    localStorage.setItem(localSHowGuidePath, "hide");
  };

  return (
    <Box>
      <Typography variant={"body2"}>
        LitCommerce are now adding products to Draft section in each of your
        selected Channels. This will take sometime, you can click here to view
        the detailed
      </Typography>
      <img
        src={"/static/images/products/process.png"}
        alt={""}
        style={{ display: "block", margin: "auto" }}
      />
      <Typography variant={"body2"}>
        Once the progress is completed, please go to each of your selected
        channels, enter necessary data and publish your listing
      </Typography>
      <img src={"/static/images/products/product_guide_2.png"} alt={""} style={{objectFit:'contain', width:'100%'}}/>
      <FormControlLabel
        control={<Checkbox />}
        onChange={handleCheck}
        label={"I understood, please don't show this guide in this session"}
      />
    </Box>
  );
};

export default WaitScreenGreaterThanTen;
