import React, { useContext, useState } from "react";
import DialogTitle from "src/components/Modal/DialogTitle";
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  Grid,
  Typography
} from "@material-ui/core";
import DialogContent from "@material-ui/core/DialogContent";
import { getSrcImageCartFromType } from "src/utils/helper";
import { makeStyles } from "@material-ui/styles";
import DialogActions from "@material-ui/core/DialogActions";
import { selectRemoveChannel } from "src/services/products";
import ButtonCustom from "src/components/MUI/Button";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import wait from "src/utils/wait";
import { useSelector } from "react-redux";
import { useSnackbar } from "notistack";
import { messageError } from "src/utils/ErrorResponse";
import { Alert, AlertTitle } from "@material-ui/lab";

const useStyles = makeStyles(theme => ({
  icon: {
    width: 36,
    height: 36,
    marginRight: theme.spacing(1),
    borderRadius: 4
  },
  modalStyle: {
    "& .MuiPaper-root": {
      maxWidth: 620
    }
  }
}));

const RemoveChannelModal = ({
  open,
  setOpen = function() {},
  listings = [],
  selectedProducts = [],
  setSelectedProduct = function() {},
  setAction = function() {},
  setListAction = function() {}
}) => {
  const { enqueueSnackbar } = useSnackbar();
  const classes = useStyles();
  const { getProduct } = useContext(AllProductContext);
  const { defaultListing } = useSelector(state => state?.listing);

  const [listChannel, setListChannel] = useState([]);
  const [loading, setLoading] = useState(false);
  //+1 => default main store
  const isChecked = listings.length + 1 === listChannel.length;
  const isIndicator =
    listChannel.length && listings.length + 1 > listChannel.length;

  const handleClose = () => {
    setOpen(false);
    setAction("");
  };

  const handleChange = () => {
    setListChannel(() =>
      isChecked ? [] : [...listings.map(item => item.id), defaultListing.id]
    );
  };

  const handleIsCheck = name => {
    return listChannel.includes(name);
  };

  const handleCheck = name => {
    if (listChannel.includes(name)) {
      setListChannel(listChannel.filter(channel => channel !== name));
    } else {
      setListChannel([...listChannel, name]);
    }
  };

  const handleSubmit = async () => {
    try {
      const body = {
        channel_ids: listChannel,
        product_ids: selectedProducts
      };
      setLoading(true);
      const request = await selectRemoveChannel({ body });
      if (request) {
        setOpen(false);
        setSelectedProduct([]);
        setLoading(false);
        setListAction("");
        setAction("");
        await wait(1500);
        await getProduct();
      }
    } catch (e) {
      setLoading(false);
      enqueueSnackbar(messageError(e, "Remove fail"), { variant: "error" });
      console.log(e);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullWidth
      maxWidth={"sm"}
      className={classes.modalStyle}
    >
      <DialogTitle onClose={handleClose}>Select Channel To Remove</DialogTitle>
      <DialogContent dividers>
        <Typography variant={"h6"}>
          This will remove products from selected Channels but will keep them in
          Main product list
        </Typography>
        <Grid container alignItems={"center"}>
          <Grid item xs={1}>
            <Checkbox
              checked={isChecked}
              onChange={handleChange}
              indeterminate={isIndicator}
            />
          </Grid>
          <Grid item xs={1}>
            <Typography variant={"h6"} style={{ whiteSpace: "nowrap" }}>
              Select All
            </Typography>
          </Grid>
          <Grid item xs={10} />
          {listings.map((channel, index) => {
            return (
              <React.Fragment key={index}>
                <Grid item xs={1}>
                  <Checkbox
                    checked={handleIsCheck(channel.id)}
                    onChange={() => handleCheck(channel?.id)}
                  />
                </Grid>
                <Grid item xs={1}>
                  <img
                    src={getSrcImageCartFromType(channel.type)}
                    className={classes.icon}
                    alt=""
                  />
                </Grid>
                <Grid item xs={10}>
                  <Typography variant={"h6"} style={{ marginLeft: 8 }}>
                    {channel?.default ? "Main Store" : channel.name}
                  </Typography>
                </Grid>
              </React.Fragment>
            );
          })}
        </Grid>
        {/*<Typography variant={"h6"} style={{ marginBottom: 8 }}>*/}
        {/*  Remove from Main Store*/}
        {/*</Typography>*/}
        {/*<Grid container alignItems={"center"}>*/}
        {/*  <Grid item xs={1}>*/}
        {/*    <Checkbox*/}
        {/*      checked={handleIsCheck(defaultListing.id)}*/}
        {/*      onChange={() => handleCheck(defaultListing?.id)}*/}
        {/*    />*/}
        {/*  </Grid>*/}
        {/*  <Grid item xs={1}>*/}
        {/*    <img*/}
        {/*      src={getSrcImageCartFromType(defaultListing.type)}*/}
        {/*      className={classes.icon}*/}
        {/*      alt=""*/}
        {/*    />*/}
        {/*  </Grid>*/}
        {/*  <Grid item xs={10}>*/}
        {/*    <Typography variant={"h6"} style={{ marginLeft: 8 }}>*/}
        {/*      Main Store*/}
        {/*    </Typography>*/}
        {/*  </Grid>*/}
        {/*</Grid>*/}

        <Alert severity="info" style={{ padding: 8, marginTop: 16 }}>
          <AlertTitle>
            <Typography variant="h6">Notes</Typography>
          </AlertTitle>
          <Typography variant={"caption"}>
            If a product removed from Main Store yet still exists in one
            channel, it remains as Unlinked.
          </Typography>
          <Box my={0.5} />
          <Typography variant={"caption"}>
            Delete this listing will remove it from this channel on LitCommerce,
            but will NOT delete on Channel or Main Store. Are you sure want to
            delete this listing? This action cannot be undone.
          </Typography>
        </Alert>
      </DialogContent>
      <DialogActions>
        <Button variant={"contained"} size={"small"} onClick={handleClose}>
          Cancel
        </Button>
        <ButtonCustom
          onClick={() => {
            handleSubmit();
          }}
          color="primary"
          notShowCircle={!loading}
          disabled={loading}
          text={"Remove from selected channel"}
        />
      </DialogActions>
    </Dialog>
  );
};

export default RemoveChannelModal;
