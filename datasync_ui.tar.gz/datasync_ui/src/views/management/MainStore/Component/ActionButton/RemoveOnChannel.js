import React, { useContext } from "react";
import RemoveChannelModal from "src/views/management/MainStore/Component/ActionButton/ManageChannel/RemoveChannelModal";
import { AllProductActionContext } from "src/views/management/MainStore/Context/AllProductActionContext";

const RemoveOnChannel = ({
  listings,
  setSelectedProduct = function() {},
  selectedProducts = []
}) => {
  const { actionRun, setActionRun, setListAction } = useContext(AllProductActionContext);

  return (
    <>
      {actionRun === "remove" && (
        <RemoveChannelModal
          open={actionRun === "remove"}
          setAction={setActionRun}
          selectedProducts={selectedProducts}
          setSelectedProduct={setSelectedProduct}
          listings={listings}
          setListAction={setListAction}
        />
      )}
    </>
  );
};

export default RemoveOnChannel;