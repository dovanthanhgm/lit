import React from "react";
import { Box, Checkbox, FormControlLabel, Typography } from "@material-ui/core";
import { localSHowGuidePath } from "src/constants/Product/ActionProduct";

const WaitScreenTen = () => {
  const handleCheck = () => {
    localStorage.setItem(localSHowGuidePath, "hide");
  };

  return (
    <Box>
      <Typography variant={"body2"}>
        Products has been added to Draft section in each of your selected
        Channels.
      </Typography>
      <Typography variant={"body2"}>
        Please enter go there, enter necessary data and publish your listing
      </Typography>
      <img src={"/static/images/products/product_guide_2.png"} alt={""} style={{objectFit:'contain', width:'100%'}}/>
      <FormControlLabel
        control={<Checkbox />}
        onChange={handleCheck}
        label={"I understood, please don't show this guide in this session"}
      />
    </Box>
  );
};

export default WaitScreenTen;
