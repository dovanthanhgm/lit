import React, { useContext } from "react";
import RemoveAllProductModal from "src/views/management/MainStore/Component/ActionButton/ManageChannel/RemoveAllProductModal";
import { AllProductActionContext } from "src/views/management/MainStore/Context/AllProductActionContext";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";

const RemoveFromMainStore = () => {
  const { actionRun, setActionRun, setListAction } = useContext(
    AllProductActionContext
  );
  const { selectedProduct, setSelectedProduct } = useContext(
    SelectedProductContext
  );

  return (
    <>
      {actionRun === "remove_main" && (
        <RemoveAllProductModal
          selectedProducts={selectedProduct}
          setListAction={setListAction}
          open={actionRun === "remove_main"}
          setSelectedProduct={setSelectedProduct}
          setAction={setActionRun}
        />
      )}
    </>
  );
};

export default RemoveFromMainStore;
