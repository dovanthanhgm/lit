import React, { useContext } from "react";
import UpdateProduct from "src/components/Products/ListProdutcs/UpdateProduct";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import { useSelector } from "react-redux";

const ProductTableUpdateButton = () => {
  const { defaultListing } = useSelector(state => state.listing);

  const {
    selectedProduct,
    setDisableButton,
    disableButton,
    setSelectedProduct
  } = useContext(SelectedProductContext);

  if (defaultListing?.type === "file") {
    return null;
  }

  return (
    <UpdateProduct
      text={`Update From ${defaultListing?.type}`}
      selectedItems={selectedProduct}
      setSelectedItems={setSelectedProduct}
      disabled={disableButton}
      setDisableButton={setDisableButton}
    />
  );
};

export default ProductTableUpdateButton;
