import { Step, StepLabel, Stepper, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/styles';
import { cloneDeep } from 'lodash';

const useStyles = makeStyles(theme => ({
   stepper: {
      '& .MuiStepConnector-vertical': {
         paddingTop: theme.spacing(1)
      },
      '& .MuiStepConnector-lineVertical': {
         height: 24
      },
      '& .MuiStepIcon-completed': {
         color: '#4caf50'
      }
   }
}));

const defaultStep = ['Select Products', 'Review & Publish'];

function AddDefaultStepper(props) {
   const { templates, activeStep } = props;

   const classes = useStyles();

   const [steps, setSteps] = useState([]);

   useEffect(() => {
      const keys = templates.map(key => key.charAt(0).toUpperCase() + key.slice(1));

      let _steps = cloneDeep(defaultStep);

      keys.forEach((key, index) => _steps.splice(index + 1, 0, `Add Default ${key} Template`));

      setSteps(() => _steps);
   }, [templates]);

   return (
      <React.Fragment>
         <Stepper
            activeStep={activeStep}
            orientation='vertical'
            className={classes?.stepper || ''}
            style={{ padding: 0, height: 'auto' }}
         >
            {steps.map((label, index) => {
               const labelProps = {};
               if (index !== 0 && index !== steps.length - 1)
                  labelProps.optional = <Typography variant='caption'>(one-time setup)</Typography>;

               if (index === steps.length - 1)
                  labelProps.optional = (
                     <Typography variant='caption'>(redirect to Channel Listings page)</Typography>
                  );

               return (
                  <Step key={label}>
                     <StepLabel {...labelProps}>
                        <Typography variant='subtitle2'>{label}</Typography>
                     </StepLabel>
                  </Step>
               );
            })}
         </Stepper>
      </React.Fragment>
   );
}

export default AddDefaultStepper;
