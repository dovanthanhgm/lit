import { CONDITION_RSC_ID, EBAY_CONDITION_POLICIES_KEY } from 'src/views/channel/Ebay/constants';

export const defaultChannelSubmitData = ({ channelType, body, type }) => {
   const newBody = Object.assign({}, body);
   const channel = {
      ebay: function() {
         if (type === 'category') {
            EBAY_CONDITION_POLICIES_KEY.forEach(item => {
               delete newBody[item];
            });
            delete newBody[CONDITION_RSC_ID];
         }
         if (type === 'shipping') {
            if (!newBody?.weight_major) {
               newBody.weight_major = 0;
            }
            if (!newBody?.weight_minor) {
               newBody.weight_minor = 0;
            }
         }
      },
      etsy: function() {
         if (type === 'category') {
            if (newBody?.advance?.attributes?.length === 0) {
               delete newBody?.advance?.attributes;
            } else {
               newBody.advance.attributes = newBody?.advance?.attributes?.filter(
                  item => item.attribute_id
               );
            }
         }
      },
      tiktok: function() {
         if (type === 'category') {
            if (!newBody?.category_rules?.isSizeChartSupport) {
               delete newBody?.size_chart_id;
               delete newBody?.size_chart_url;
            }
            if (!newBody?.category_rules?.isSupportExemption) {
               newBody.exemption_of_identifier_code = '';
            }

            newBody.is_cod_open = newBody?.category_rules?.supportCod ? newBody?.is_cod_open : false;
         }
      }
   };
   if (channel?.[channelType]) {
      channel[channelType]();
   }
   return newBody;
};
