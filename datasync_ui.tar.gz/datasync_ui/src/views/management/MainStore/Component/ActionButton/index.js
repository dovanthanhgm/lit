import React, { useState } from "react";
import { Box } from "@material-ui/core";
import TableSelectedProduct from "src/views/management/MainStore/DefaultMainStore/Body/ProductsTable/Table/TableSelectedProduct";
import ProductTableDeleteAll from "src/views/management/MainStore/Component/ActionButton/ProductTableDeleteAll";
import GroupButtonActionProductsMainMarket from "../../../ProductListView/GroupButtonAction";
import ColumnManager from "src/views/management/MainStore/DefaultMainStore/Body/FIlter/ColumnManager";
import ListingStyleButton from "src/views/management/ListingDetail/GroupBulkButton/ListingStyleButton";
import AdminButtons from "src/views/management/ListingDetail/GroupBulkButton/Admin";
import AllProductGroupAction from "src/views/management/MainStore/Component/ActionButton/AllProductGroupAction";
import AllProductActionProvider from "../../Context/AllProductActionContext";

const AllProductTableActionButton = ({ isMarket = false }) => {
  const [action, setAction] = useState("");

  return (
    <Box px={1} mx={1}>
      <Box display={"flex"} alignItems={"center"}>
        <Box
          my={1}
          display="flex"
          alignItems="center"
          flexGrow={1}
          mx={1}
          ml={0}
        >
          <AllProductActionProvider action={action} setAction={setAction}>
            <AllProductGroupAction />
          </AllProductActionProvider>
          {/*<ListProductOnChannel />*/}
          {isMarket && <Box ml={1}>
            <GroupButtonActionProductsMainMarket />
          </Box>}
          {/*1/6/2023 09:29 Thurs slack litcommerce_ui Mr Kevin: đồng thời e bỏ luôn button remove đi, vì đã có trong cái kia rồi*/}
          {/*https://mylitgroup.slack.com/archives/C04Q8HC2ZGV/p1685586593789099*/}
          {/*<ProductTableDeleteButton />*/}
          {/*<Box mx={1}>*/}
          {/*  <ProductTableUpdateButton />*/}
          {/*</Box>*/}
        </Box>
        <ProductTableDeleteAll />
        <AdminButtons />
        <ListingStyleButton />
        <ColumnManager />
      </Box>

      <TableSelectedProduct />
    </Box>
  );
};

export default AllProductTableActionButton;
