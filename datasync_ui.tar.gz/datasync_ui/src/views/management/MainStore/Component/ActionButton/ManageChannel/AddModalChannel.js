import React, { useContext, useEffect, useRef, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import { Checkbox, Grid, Typography } from "@material-ui/core";
import { getSrcImageCartFromType } from "src/utils/helper";
import { makeStyles } from "@material-ui/styles";
import DialogTitle from "src/components/Modal/DialogTitle";
import WaitScreenTen from "src/views/management/MainStore/Component/ActionButton/ManageChannel/WaitScreenTen";
import WaitScreenGreaterThanTen from "src/views/management/MainStore/Component/ActionButton/ManageChannel/WaitScreenGreaterThanTen";
import { localSHowGuidePath } from "src/constants/Product/ActionProduct";
import { selectAddChannel } from "src/services/products";
import ButtonCustom from "src/components/MUI/Button";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import wait from "src/utils/wait";
import { useSnackbar } from "notistack";
import { useDispatch } from "react-redux";
import { setToolTipRunningProcess } from "src/actions/accountActions";
import { messageError } from "src/utils/ErrorResponse";
import NoteAddChannel from "src/views/management/MainStore/Component/ActionButton/ManageChannel/NoteAddChannel";
import { getListTemplates, getSkipTemplate } from "src/services/templates";
import AddDefaultTemplate from "./AddDefaultTemplate";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";

const requiredTemps = {
  etsy: ["shipping", "category"],
  tiktok: ["shipping", "category"],
  ebay: ["shipping", "category", "payment"]
};

const useStyles = makeStyles(theme => ({
  icon: {
    width: 36,
    height: 36,
    marginRight: theme.spacing(1),
    borderRadius: 4
  },
  listStyle: {
    listStyleType: "'-'",
    listStylePosition: "inside"
  },
  modalStyle: {
    "& .MuiPaper-root": {
      maxWidth: 700
    }
  }
}));

const AddModalChannel = ({
  open,
  setOpen = function() {},
  listings = [],
  selectedProducts = [],
  setSelectedProduct = function() {},
  bodySelectAll = {},
  listAllProduct = false,
  setAction = function() {},
  setListAction = function() {}
}) => {
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const classes = useStyles();
  const { getProduct } = useContext(AllProductContext);
  const { tabTotal } = useContext(AllProductCountContext);

  const [listChannel, setListChannel] = useState([]);
  const [runsSuccess, setRunSuccess] = useState(false);
  const [openTooltip, setOpenTooltip] = useState(false);
  const [loading, setLoading] = useState(false);
  const selectedLength = selectedProducts.length || 0;
  const isChecked = listings.length === listChannel.length;
  const isIndicator =
    listChannel.length && listings.length > listChannel.length;

  const localShowGuide = localStorage.getItem(localSHowGuidePath);

  const refAddDefault = useRef(null);

  const handleClose = () => {
    if (openTooltip) {
      dispatch(
        setToolTipRunningProcess("Click here to see current running processes")
      );
    }
    setOpen(false);
    setAction("");
  };

  const handleChange = () => {
    setListChannel(() => (isChecked ? [] : listings.map(item => item.id)));
  };

  const handleIsCheck = name => {
    return listChannel.includes(name);
  };

  const handleCheck = name => {
    if (listChannel.includes(name)) {
      setListChannel(listChannel.filter(channel => channel !== name));
    } else {
      setListChannel([...listChannel, name]);
    }
  };

  const addProduct = async () => {
    if (listChannel.length === 1)
      await checkProductsOfChannel(listChannel[0], handleSubmit);
    else handleSubmit();
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const body = {
        channel_ids: listChannel,
        product_ids: selectedProducts,
        select_all: false,
        ...bodySelectAll
      };
      await selectAddChannel({ body });

      if (localShowGuide) {
        setOpen(false);
      } else {
        setRunSuccess(true);
      }
      setSelectedProduct([]);
      if (selectedLength > 10) {
        setOpenTooltip(true);
      }
      setListAction("");
      await wait(1500);
      await getProduct();
    } catch (e) {
      enqueueSnackbar(
        <div
          dangerouslySetInnerHTML={{ __html: messageError(e, "Add Fail") }}
        />,
        { variant: "error" }
      );
    }
    setLoading(false);
  };

  const checkProductsOfChannel = async (id, submit) => {
    const type = listings.find(channel => channel.id === id)?.type;

    if (!["etsy", "ebay", "tiktok"].includes(type)) await submit();

    setLoading(current => !current);

    try {
      let _hasTemplate = {};
      let skipTemps = [];
      const templates = await getListTemplates({ type, id });
      const skipTemplates = await getSkipTemplate(id);

      if (skipTemplates.status === 200)
        skipTemps = skipTemplates.data.skip_templates;

      if (Array.isArray(requiredTemps[type]))
        requiredTemps[type].forEach(temp => {
          _hasTemplate[temp] = templates[temp]?.length !== 0;
        }); //Check if there is default template already

      let _templates = Object.keys(_hasTemplate)
        .filter(temp => !_hasTemplate[temp])
        .filter(temp => !skipTemps.includes(temp)); //filter the temps that are not skipped

      if (_templates.length > 0)
        refAddDefault.current.openAddDefault(_templates, type, listChannel);
      else await submit();
    } catch (err) {
      enqueueSnackbar(messageError(err, "Add Fail"), { variant: "error" });
      console.log(err);
    }

    setLoading(current => !current);
  };

  const onlyOneChannelID = listings.length === 1 ? listings[0]?.id : "";

  useEffect(() => {
    if (onlyOneChannelID) {
      setListChannel([onlyOneChannelID]);
    }
  }, [onlyOneChannelID]);

  return (
    <React.Fragment>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        className={classes.modalStyle}
      >
        <DialogTitle onClose={handleClose}>
          {listAllProduct
            ? `List ${tabTotal} Products to Channels`
            : `List ${selectedLength} Products to Channels`}
        </DialogTitle>
        {!runsSuccess && (
          <DialogContent dividers>
            <Grid container alignItems={"center"}>
              <Grid item xs={1}>
                <Checkbox
                  checked={isChecked}
                  onChange={handleChange}
                  indeterminate={isIndicator}
                />
              </Grid>
              <Grid item xs={1}>
                <Typography variant={"h6"} style={{ whiteSpace: "nowrap" }}>
                  Select All
                </Typography>
              </Grid>
              <Grid item xs={10} />
              {listings.map(channel => {
                return (
                  <React.Fragment key={channel.id}>
                    <Grid item xs={1}>
                      <Checkbox
                        checked={handleIsCheck(channel.id)}
                        onChange={() => handleCheck(channel?.id)}
                      />
                    </Grid>
                    <Grid item xs={1}>
                      <img
                        src={getSrcImageCartFromType(channel.type)}
                        className={classes.icon}
                        alt=""
                      />
                    </Grid>
                    <Grid item xs={10}>
                      <Typography variant={"h6"} style={{ marginLeft: 8 }}>
                        {channel.name}
                      </Typography>
                    </Grid>
                  </React.Fragment>
                );
              })}
            </Grid>
            <NoteAddChannel />
          </DialogContent>
        )}
        {!runsSuccess && (
          <DialogActions>
            <Button onClick={handleClose} variant={"contained"} size={"small"}>
              Cancel
            </Button>
            <ButtonCustom
              text={"Add as Draft Now"}
              onClick={() => {
                addProduct();
              }}
              color={"primary"}
              notShowCircle={!loading}
              disabled={loading || listChannel.length === 0}
            />
          </DialogActions>
        )}
        {runsSuccess && !openTooltip && (
          <DialogContent dividers>
            <WaitScreenTen />
          </DialogContent>
        )}
        {runsSuccess && openTooltip && (
          <DialogContent dividers>
            <WaitScreenGreaterThanTen />
          </DialogContent>
        )}
        {runsSuccess && (
          <DialogActions>
            <Button onClick={handleClose} variant={"contained"} size={"small"}>
              Close
            </Button>
          </DialogActions>
        )}
      </Dialog>

      <AddDefaultTemplate handleSubmit={handleSubmit} ref={refAddDefault} />
    </React.Fragment>
  );
};

export default AddModalChannel;
