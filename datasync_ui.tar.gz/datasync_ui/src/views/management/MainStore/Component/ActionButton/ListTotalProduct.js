import React, { useContext } from "react";
import { AllProductCountContext } from "src/views/management/MainStore/Context/AllProductCountContext";

const ListTotalProduct = () => {
  const { tabTotal } = useContext(AllProductCountContext);

  return (
    <React.Fragment>List All {tabTotal} Products to Channels</React.Fragment>
  );
};

export default ListTotalProduct;
