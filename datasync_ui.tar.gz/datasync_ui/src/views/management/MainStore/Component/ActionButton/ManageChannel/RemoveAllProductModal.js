import React, { useContext, useState } from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "src/components/Modal/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import DialogActions from "@material-ui/core/DialogActions";
import Button from "@material-ui/core/Button";
import ButtonCustom from "src/components/MUI/Button";
import { makeStyles } from "@material-ui/styles";
import { Typography } from "@material-ui/core";
import { selectRemoveChannel } from "src/services/products";
import wait from "src/utils/wait";
import { messageError } from "src/utils/ErrorResponse";
import { useSelector } from "react-redux";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import { useSnackbar } from "notistack";

const useStyles = makeStyles(theme => ({
  icon: {
    width: 36,
    height: 36,
    marginRight: theme.spacing(1),
    borderRadius: 4
  },
  modalStyle: {
    "& .MuiPaper-root": {
      maxWidth: 620
    }
  }
}));

const RemoveAllProductModal = ({
  open,
  setOpen = function() {},
  selectedProducts = [],
  setSelectedProduct = function() {},
  setAction = function() {},
  setListAction = function() {}
}) => {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();

  const [loading, setLoading] = useState(false);

  const { defaultListing } = useSelector(state => state?.listing);
  const { getProduct } = useContext(AllProductContext);

  const handleClose = () => {
    setOpen(false);
    setAction("");
  };

  const handleSubmit = async () => {
    try {
      const body = {
        channel_ids: [defaultListing.id],
        product_ids: selectedProducts
      };
      setLoading(true);
      const request = await selectRemoveChannel({ body });
      if (request) {
        setOpen(false);
        setSelectedProduct([]);
        setLoading(false);
        setListAction("");
        setAction("");
        await wait(1500);
        await getProduct();
        enqueueSnackbar("Remove success", {
          variant: "success"
        });
      }
    } catch (e) {
      setLoading(false);
      enqueueSnackbar(messageError(e, "Remove fail"), { variant: "error" });
      console.log(e);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullWidth
      className={classes.modalStyle}
    >
      <DialogTitle onClose={handleClose}>Remove from Main Store</DialogTitle>
      <DialogContent dividers>
        <Typography variant={"body2"}>
          This will delete selected products on "All Products" section of
          LitCommerce and will NOT delete the actual products on Main Store. If
          products are removed from "All Products" yet still exists in one
          Channel, they remain as Unlinked.
        </Typography>
        <Typography variant={"body2"}>
          Are you sure want to proceed? This action cannot be undone.
        </Typography>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} variant={"contained"} size={"small"}>
          Cancel
        </Button>
        <ButtonCustom
          text={"Remove"}
          onClick={() => {
            handleSubmit();
          }}
          color={"primary"}
          notShowCircle={!loading}
          disabled={loading}
        />
      </DialogActions>
    </Dialog>
  );
};

export default RemoveAllProductModal;
