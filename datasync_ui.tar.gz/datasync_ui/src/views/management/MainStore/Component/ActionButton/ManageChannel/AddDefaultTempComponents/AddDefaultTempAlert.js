import { Box, Typography } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import React from 'react';

function AddDefaultTempAlert(props) {
   return (
      <Alert severity='info' style={{ maxWidth: '100%', height: 'auto', marginBottom: 8 }}>
         <Box>
            <Typography variant='body2'>
               This process shows during your first time adding products to your channel. You can
               add a default Template to automatically applied to current and future listings. If
               you don't need that for now, please click on <strong>"Skip this step"</strong>.
            </Typography>
         </Box>
      </Alert>
   );
}

export default AddDefaultTempAlert;
