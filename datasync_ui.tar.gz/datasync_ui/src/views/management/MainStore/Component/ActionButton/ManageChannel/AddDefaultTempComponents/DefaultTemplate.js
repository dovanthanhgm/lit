import { useFormikContext } from 'formik';
import React, { useEffect } from 'react';
import { defaultTemplateValue } from 'src/constants/defaultValue';
import { convertRealToFake } from 'src/utils/convertData';
import Channel from 'src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel';

function DefaultTemplate(props) {
   const { type, channelID, templateType } = props;

   const defaultTemp = templateType?.charAt(0)?.toUpperCase() + templateType?.slice(1);
   const defaultName = `Default ${defaultTemp} Template`;

   const { setValues } = useFormikContext();

   useEffect(() => {
      const getInit = () => {
         let init = defaultTemplateValue?.[type]?.[templateType];

         if (!init) {
            return {};
         }
         return convertRealToFake({
            channelType: type,
            templateType,
            values: JSON.parse(JSON.stringify(init))
         });
      };

      const newValues = { ...getInit(), default: true, name: defaultName };

      setValues(newValues);
      // eslint-disable-next-line
   }, [templateType, type]);

   return (
      <Channel
         type={type}
         channelType={type}
         templateType={templateType}
         channelID={channelID}
         isAddingDefaultTemplate
      />
   );
}

export default DefaultTemplate;
