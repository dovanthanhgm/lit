import { Box, Button, CircularProgress } from '@material-ui/core';
import React from 'react';
import Header from 'src/components/Header';
import DoubleArrowIcon from '@material-ui/icons/DoubleArrow';
import { capitalizeFirstLetter } from 'src/utils/CapitalizeFirstLetter';
import { convertTemplateTypeToName } from 'src/utils/helper';
import { skipTemplate } from 'src/services/templates';
import { useSnackbar } from 'notistack';
import { messageError } from "src/utils/ErrorResponse";

function AddDefaultHeader(props) {
   const {
      channelType,
      isLastStep,
      templateType,
      setActiveStep,
      channelID,
      setSkipping,
      skipping,
      loading
   } = props;

  const { enqueueSnackbar } = useSnackbar();

   const header = !isLastStep //Because the stepper step always plus 1 to the templates length
      ? `Default ${capitalizeFirstLetter(convertTemplateTypeToName(templateType))} Template`
      : 'Add Default Templates Completed';

   const skipStep = async () => {
      let _payload = {
         channelID: channelID,
         body: {
            skip_templates: templateType
         }
      };
      setSkipping(current => !current);
      try {
         await skipTemplate(_payload).then(res => {
            if (res.status < 400) {
               setActiveStep(current => current + 1);
            }
         });
      } catch (error) {
      enqueueSnackbar(messageError(error, "Skipping Step Fail"), { variant: "error" });
      console.log(error);
      }
      setSkipping(current => !current);
   };

   return (
      <Box display='flex' justifyContent='space-between' width='auto' alignItems='center'>
         <Header headerName={header} typeLogo={channelType} />
         {!isLastStep && (
            <Button
               variant='contained'
               size='small'
               color='primary'
               disabled={skipping || loading}
               onClick={() => skipStep()}
            >
               Skip This Step <DoubleArrowIcon style={{ height: 20, width: 20 }} />
               {skipping && (
                  <CircularProgress
                     size={20}
                     style={{
                        position: 'absolute',
                        margin: 'auto'
                     }}
                  />
               )}
            </Button>
         )}
      </Box>
   );
}

export default AddDefaultHeader;
