import React, { useCallback, useContext } from "react";
import ListProductsonChannel from "src/components/Listings/ListProductsonChannel";
import useUserExp from "src/hooks/useUserExp";
import { useDispatch, useSelector } from "react-redux";
import { useSnackbar } from "notistack";
import { useHistory } from "react-router-dom";
import { AllProductAlertContext } from "src/views/management/MainStore/Context/AllProductAlertContext";
import { alertError } from "src/helper/showErrorMessage";
import { sendProductsToChannel } from "src/services/products";
import { actionChangeTab } from "src/actions/listingActions";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import { allProductLoading } from "src/actions/product";
import RemoveOnChannel from "src/views/management/MainStore/Component/ActionButton/RemoveOnChannel";

const ListProductOnChannel = ({ isRemove = false }) => {
  const dispatch = useDispatch();
  const { expired } = useUserExp();
  const { listings } = useSelector(state => state.listing);

  const { setAlert } = useContext(AllProductAlertContext);
  const { selectedProduct, setSelectedProduct } = useContext(
    SelectedProductContext
  );

  const { enqueueSnackbar } = useSnackbar();
  const history = useHistory();

  const setLoading = status => {
    dispatch(allProductLoading(status));
  };

  const changeChannel = useCallback(async (channelID, selectedProducts) => {
    try {
      setLoading(true);
      const res = await sendProductsToChannel({
        channelID,
        selectedProducts
      });
      if (res?.data) {
        dispatch(actionChangeTab(true));
        history.push(`/listing/detail/${channelID}`);
      }
    } catch (e) {
      const getError =
        e?.response?.data?.message ||
        e?.response?.data?.errors ||
        e?.response?.data?.msg ||
        e?.response?.data?.error ||
        e?.response?.data?.message;
      if (getError) {
        setAlert(prev => ({
          ...prev,
          listOnChannel: alertError(getError, false, true)
        }));
      }
      console.log(e);
      enqueueSnackbar(
        alertError(getError, false, true) || "Something went wrong",
        {
          variant: "error"
        }
      );
    }
    setLoading(false);
    // eslint-disable-next-line
  }, []);

  if (expired) {
    return null;
  }

  return (
    <>
      {!isRemove && (
        <ListProductsonChannel
          listings={listings}
          handleChangeChannel={changeChannel}
          selectedProducts={selectedProduct}
          setSelectedProduct={setSelectedProduct}
        />
      )}
      {isRemove && (
        <RemoveOnChannel
          listings={listings}
          handleChangeChannel={changeChannel}
          selectedProducts={selectedProduct}
          setSelectedProduct={setSelectedProduct}
        />
      )}
    </>
  );
};

export default ListProductOnChannel;
