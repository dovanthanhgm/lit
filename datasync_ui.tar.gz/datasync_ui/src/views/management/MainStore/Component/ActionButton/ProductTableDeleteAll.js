import React, { useContext } from "react";
import ButtonDelete from "src/components/Button/ButtonDelete";
import { Box, Typography } from "@material-ui/core";
import { deleteAllProductsAPI } from "src/services/products";
import { messageError } from "src/utils/ErrorResponse";
import { useSnackbar } from "notistack";
import { AllProductContext } from "src/views/management/MainStore/Context/AllProductContext";
import { SelectedProductContext } from "src/views/management/MainStore/Context/SelectedProductContext";
import authService from "src/services/authService";

const ProductTableDeleteAll = () => {
  const loginByToken = authService.getLoginByToken();
  const { enqueueSnackbar } = useSnackbar();
  const { getProduct } = useContext(AllProductContext);
  const { setSelectedProduct } = useContext(SelectedProductContext);

  const handleConfirmDeleteAll = async () => {
    try {
      await deleteAllProductsAPI();
      enqueueSnackbar("Delete success", {
        variant: "success"
      });
      getProduct();
      setSelectedProduct([]);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  if (!loginByToken) {
    return null;
  }

  return (
    <Box mr={1}>
      <ButtonDelete
        buttonText="Delete All"
        handleConfirm={handleConfirmDeleteAll}
        headerDialog="Are you sure?"
        contentDialog={
          <Typography color="textPrimary" variant="body1">
            Are you sure you want to remove all products?
          </Typography>
        }
        buttonTextSubmit="Yes, Remove"
      />
    </Box>
  );
};

export default ProductTableDeleteAll;
