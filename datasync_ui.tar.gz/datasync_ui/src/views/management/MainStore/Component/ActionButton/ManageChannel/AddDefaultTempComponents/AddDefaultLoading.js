import { Box, CircularProgress, Typography } from '@material-ui/core';
import React from 'react';

function AddDefaultLoading() {
   return (
      <Box
         style={{ height: 'calc(90vh - 180px)' }}
         display='flex'
         justifyContent='center'
         alignItems='center'
         flexDirection='column'
      >
         <CircularProgress />
         <Typography variant='subtitle2' style={{paddingTop: 8}}>
            Adding Products as Drafts and redirect to Channel Listings Page...
         </Typography>
      </Box>
   );
}

export default AddDefaultLoading;
