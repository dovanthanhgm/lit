import React from "react";
import { Alert, AlertTitle } from "@material-ui/lab";
import { Box, Link, Typography } from "@material-ui/core";

const NoteAddChannel = () => {
  return (
    <Alert severity="info" style={{ padding: 8, marginTop: 16 }}>
      <AlertTitle>
        <Typography variant="h6">Notes</Typography>
      </AlertTitle>
      <Box mb={0.5}>
        <Typography variant={"caption"}>
          All products data will be copied into draft listings, and from that
          point, listings data will be maintained separately from original main
          store products.
        </Typography>
      </Box>

      <Box mb={0.5}>
        <Typography variant={"caption"}>
          <Link
            style={{ cursor: "pointer" }}
            href={
              "https://help.litcommerce.com/en/article/step-6-set-up-price-sync-pricing-rules-18ifkuf/#3-pricing-rules"
            }
            target={"_blank"}
          >
            Price
          </Link>
          ,&nbsp;
          <Link
            target={"_blank"}
            style={{ cursor: "pointer" }}
            href={
              "https://help.litcommerce.com/en/article/step-5-set-up-inventory-sync-inventory-rules-1crzyuh/#3-how-to-set-inventory-rules"
            }
          >
            Inventory
          </Link>
          &nbsp;modification can be automatically applied to listings if
          configured in Channels settings.
        </Typography>
      </Box>

      <Box>
        <Typography variant={"caption"}>
          Other fields modification can be automatically applied to listings
          using&nbsp;
          <Link
            target={"_blank"}
            href={
              "https://help.litcommerce.com/en/article/templates-and-recipes-1ging68/#3-default-templates"
            }
          >
            Default Templates
          </Link>
        </Typography>
      </Box>
      <Box
        style={{
          lineHeight: 1.8
        }}
      >
        <Typography variant={"caption"}>
          If a selected product already exists in a Channel's list, it will be
          ignored.
        </Typography>
      </Box>
    </Alert>
  );
};

export default NoteAddChannel;
