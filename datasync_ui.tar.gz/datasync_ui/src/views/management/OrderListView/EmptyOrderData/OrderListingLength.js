import { Box, Typography } from "@material-ui/core";
import React from "react";

export default function OrderListingLength() {
  return (
    <Box
      minHeight={250}
      display="flex"
      alignItems="center"
      justifyContent={"center"}
    >
      <Typography variant="h5" color="textPrimary">
        You have no orders yet.&nbsp;
      </Typography>
      <Typography variant="body1" color={"textPrimary"}>
        Your orders will be imported automatically when you connect a channel.
      </Typography>
    </Box>
  );
}
