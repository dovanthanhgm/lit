import { Box, Popper } from "@material-ui/core";
import DateRangePick from "./DateRangePick";
import DatePickOrder from "src/components/InputField/OrderDatePick";
import React, { useState } from "react";

export default function OrderDateRangeFilter() {
  const [openDatePick, setOpenDatePick] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClickDatePick = event => {
    setAnchorEl(event.currentTarget);
    setOpenDatePick(!openDatePick);
  };

  return (
    <Box>
      <Popper
        anchorEl={anchorEl}
        style={{ zIndex: 2 }}
        open={openDatePick}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center"
        }}
      >
        <DateRangePick setOpen={setOpenDatePick} />
      </Popper>
      <Box width={250} px={1}>
        <DatePickOrder handleClickDatePick={handleClickDatePick} />
      </Box>
    </Box>
  );
}
