import React, { useState } from "react";
import { addDays } from "date-fns";
import { DateRangePicker } from "react-date-range";
import "react-date-range/dist/styles.css"; // main css file
import "react-date-range/dist/theme/default.css";
import { Box, ClickAwayListener, makeStyles } from "@material-ui/core";
import { useFormikContext } from "formik";

const useStyles = makeStyles(theme => {
  return {
    root: {
      ...theme.typography.body2
    }
  };
});

export default function DateRangePick({ setOpen }) {
  const classes = useStyles();

  const { setFieldValue } = useFormikContext();
  const [state, setState] = useState([
    {
      startDate: new Date(),
      endDate: addDays(new Date(), 0),
      key: "selection"
    }
  ]);

  const handleDateRangePick = item => {
    let _formatStartDate = `${item.selection.startDate.getFullYear()}-${formatMonth(
      item.selection.startDate.getMonth()
    )}-${formatDate(item.selection.startDate.getDate())}`;
    let _formatEndDate = `${item.selection.endDate.getFullYear()}-${formatMonth(
      item.selection.endDate.getMonth()
    )}-${formatDate(item.selection.endDate.getDate())}`;
    setState([item.selection]);
    setFieldValue("min_date", _formatStartDate);
    setFieldValue("max_date", _formatEndDate);
  };

  const formatDate = date => {
    if (date < 10) return `0${date}`;
    return date;
  };
  const formatMonth = month => {
    if (month < 9) return `0${month + 1}`;
    return month + 1;
    /*This is because the getMonth method returns a zero-based number between 0 and 11. 
    For example, January is 0, February is 1, March is 2, etc. */
  };

  return (
    <ClickAwayListener onClickAway={() => setOpen(false)}>
      <Box boxShadow={4} borderRadius={4} className={classes.root}>
        <DateRangePicker
          onChange={item => handleDateRangePick(item)}
          showSelectionPreview={true}
          moveRangeOnFirstSelection={false}
          months={2}
          ranges={state}
          direction='horizontal'
          preventSnapRefocus={true}
          calendarFocus='backwards'
        />
      </Box>
    </ClickAwayListener>
  );
}
