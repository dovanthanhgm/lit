import { Box, TextField } from "@material-ui/core";
import React from "react";
import { useFormikContext } from "formik";
import { useSelector } from "react-redux";

export default function OrderChannelFilter() {
  const { handleChange, values } = useFormikContext();
  const { listings } = useSelector(state => state?.listing);

  return (
    <Box width={250} px={1}>
      <TextField
        onChange={handleChange}
        name="channel_id"
        size="small"
        fullWidth
        variant="outlined"
        select
        SelectProps={{
          native: true
        }}
        value={values.channel_id}
      >
        <option value="">All Channels</option>
        {listings.map(items => (
          <option key={items.id} value={items.id}>
            {items.name}
          </option>
        ))}
      </TextField>
    </Box>
  );
}
