import { Box } from "@material-ui/core";
import ButtonCustom from "src/components/MUI/Button";
import React, { useContext } from "react";
import OrderNameFilter from "./OrderName";
import OrderChannelFilter from "./OrderChannel";
import OrderDateRangeFilter from "./DateRangePick/OrderDateRange";
import { useDispatch, useSelector } from "react-redux";
import { useFormikContext } from "formik";
import { currentTab } from "src/actions/orderActions";
import { useHistory } from "react-router-dom";
import { OrderProductsContext } from "../Context/OrderProductsContext";

export default function FilterOrder({ setCurrentFilter }) {
  const dispatch = useDispatch();
  const history = useHistory();
  const { isLoading } = useSelector(state => state?.order);
  const { setTab } = useContext(OrderProductsContext);

  const { values, resetForm } = useFormikContext();

  const handleClearFilter = async () => {
    dispatch(currentTab(0));
    resetForm();
    setTab("count");
    history.push({ search: "" });
    setCurrentFilter("");
  };

  const setDisable = values => {
    return (
      values.query === "" && values.minDate === "" && values.maxDate === ""
    );
  };

  return (
    <Box display="flex" width="100%" alignItems={"center"} p={1} px={0}>
      <OrderNameFilter />
      <OrderChannelFilter />
      <OrderDateRangeFilter />
      <Box justifyItems="center" alignItems="center" display="flex">
        <Box display="flex" pl={1}>
          <ButtonCustom
            size="small"
            type="submit"
            variant="contained"
            color="primary"
            text="Apply filter"
            disabled={isLoading}
            notShowCircle
          />
          <Box mx={0.5} />
          <ButtonCustom
            disabled={setDisable(values) || isLoading}
            notShowCircle
            color="primary"
            onClick={handleClearFilter}
            text="Clear Filter"
            size="small"
          />
        </Box>
      </Box>
    </Box>
  );
}
