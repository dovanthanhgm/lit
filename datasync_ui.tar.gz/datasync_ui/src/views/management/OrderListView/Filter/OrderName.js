import { Box, InputAdornment, TextField } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import React from "react";
import { useFormikContext } from "formik";

export default function OrderNameFilter() {
  const { handleChange, values } = useFormikContext();

  return (
    <Box width="32%" px={1}>
      <TextField
        name="query"
        onChange={handleChange}
        fullWidth
        variant="outlined"
        size="small"
        placeholder="Order ID, Product Name, SKU, Customer Name ..."
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon />
            </InputAdornment>
          )
        }}
        value={values.query}
      />
    </Box>
  );
}
