import { Grid, makeStyles, SvgIcon } from "@material-ui/core";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import React from "react";
import OrderSetting from "src/components/Orders/Setting";
import HeaderPageTitle from "src/components/Layout/HeaderPageTitle";

const useStyles = makeStyles(theme => ({
  root: {
    marginBottom: theme.spacing(1)
  },
  action: {
    marginBottom: theme.spacing(1),
    "& + &": {
      marginLeft: theme.spacing(1)
    }
  },
  actionIcon: {
    marginRight: theme.spacing(1)
  }
}));

// const content =
//   "Please wait until your active export is completed before starting another export.";

function OrderListViewHeader({
  selectedOrder,
  // paramsFilter,
  // ordersCount,
  ...rest
}) {
  const classes = useStyles();
  // const history = useHistory();
  // const { enqueueSnackbar } = useSnackbar();

  // const [showAlert, setShowAlert] = useState(false);

  // const [disableImportButton, setDisableImportButton] = useState(false);
  //
  // const handleClickExport = () => {
  //   return history.push("/export-data");
  // };

  // const handleImportToSource = async () => {
  //   setDisableImportButton(true)
  //   try {
  //     const res = await importOrderToSource({order_ids: selectedOrder});
  //     if (res){
  //       enqueueSnackbar("import success", {
  //         variant: "success"
  //       })
  //     }
  //   } catch (error) {
  //     const message = error.response?.data?.errors ?
  //       alertError(error.response?.data?.errors) : error.response?.data?.message ||
  //       error.message ||
  //       "Import Error";
  //     enqueueSnackbar(message, {
  //       variant: "error"
  //     })
  //   } finally {
  //     setDisableImportButton(false);
  //   }
  // }

  return (
    <Grid
      container
      // spacing={3}
      justify="space-between"
      className={classes.root}
      {...rest}
    >
      {/*{showAlert && (*/}
      {/*  <Box width={"100%"}>*/}
      {/*    <SingleAlert content={content} type="warning" />*/}
      {/*  </Box>*/}
      {/*)}*/}
      <Grid item>
        <HeaderPageTitle color="textPrimary">
          <SvgIcon fontSize="small" className={classes.actionIcon}>
            <ShoppingCartIcon />
          </SvgIcon>
          Orders
        </HeaderPageTitle>
      </Grid>
      <Grid item>
        <OrderSetting />
      </Grid>
    </Grid>
  );
}
//
// Header.propTypes = {
//   className: PropTypes.string
// };

export default OrderListViewHeader;
