import React, { useContext } from "react";
import {
  Badge,
  Box,
  makeStyles,
  TableCell,
  Tooltip,
  useTheme
} from "@material-ui/core";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";
import useLinkStatus from "src/hooks/Orders/useLinkStatus";
import { Link as LinkIcon } from "react-feather";
import { withStyles } from "@material-ui/core/styles";

const useStyles = makeStyles(theme => ({
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    paddingLeft: 10,
    paddingRight: 10,
    maxWidth: 250
  }
}));

const styles = () => ({
  customBadge: {
    backgroundColor: props => {
      return props.corlor;
    }
  }
});

function SimpleBadge(props) {
  const { classes } = props;
  return (
    <Badge
      classes={{ badge: classes.customBadge }}
      className={classes.margin}
      variant="dot"
    >
      <LinkIcon size="20" />
    </Badge>
  );
}

const StyledBadge = withStyles(styles)(SimpleBadge);

const OrderRowLinkStatusIcon = ({ order }) => {
  const classes = useStyles();
  const theme = useTheme();
  const { tab } = useContext(OrderProductsContext);
  const { orderLinked, orderUnlinked, orderNoProduct } = useLinkStatus({
    order
  });

  if (tab !== "count") {
    return null;
  }
  return (
    <TableCell className={classes.tableCell}>
      <Box m={1}>
        {orderLinked && (
          <Tooltip
            title={"All products inside this order are properly linked. "}
          >
            <span>
              <StyledBadge corlor={theme.palette.primary.main} />
            </span>
          </Tooltip>
        )}
        {orderUnlinked && (
          <Tooltip
            title={
              "There are unlinked product(s) in this order, please check and correct/link them to get the order properly synced."
            }
          >
            <span>
              <StyledBadge corlor={theme.palette.error.main} />
            </span>
          </Tooltip>
        )}
        {orderNoProduct && <StyledBadge corlor="grey" />}
      </Box>
    </TableCell>
  );
};

export default OrderRowLinkStatusIcon;
