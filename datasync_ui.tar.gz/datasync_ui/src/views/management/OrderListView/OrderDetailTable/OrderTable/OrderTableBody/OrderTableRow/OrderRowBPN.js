import React, { useMemo } from "react";
import { makeStyles, TableCell, Typography } from "@material-ui/core";
import { useSelector } from "react-redux";

const useStyles = makeStyles(theme => ({
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    paddingLeft: 10,
    paddingRight: 10,
    maxWidth: 250
  }
}));

const OrderRowBpn = ({ order }) => {
  const classes = useStyles();
  const { defaultListing } = useSelector(state => state.listing);

  const BigCommerceCol = useMemo(() => {
    return defaultListing?.type === "bigcommerce";
  }, [defaultListing]);

  if (!BigCommerceCol) {
    return null;
  }

  return (
    <TableCell className={classes.tableCell}>
      {order?.products?.length > 1 && (
        <Typography>{"(multiple items)"}</Typography>
      )}
      {order?.products?.length === 1 && (
        <Typography
          variant="subtitle2"
          // color="primary"
          className={classes.name}
        >
          {order?.products?.[0]?.product_bpn}
        </Typography>
      )}
    </TableCell>
  );
};

export default OrderRowBpn;
