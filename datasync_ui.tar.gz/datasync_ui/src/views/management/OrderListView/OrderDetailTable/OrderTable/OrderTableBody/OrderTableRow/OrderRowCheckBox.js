import React, { useContext } from "react";
import { Checkbox, TableCell } from "@material-ui/core";
import { SelectOrderContext } from "src/views/management/OrderListView/Context/SelectOrderContext";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";

const OrderRowCheckBox = ({ order }) => {
  const { handleSelectOneOrder, selectedOrder } = useContext(
    SelectOrderContext
  );
  const { tab } = useContext(OrderProductsContext);
  const isOrderSelected = selectedOrder.includes(order.id);

  if (!["unlink", "error"].includes(tab)) {
    return null;
  }
  return (
    <TableCell padding="checkbox">
      <Checkbox
        checked={isOrderSelected}
        onChange={event => handleSelectOneOrder(event, order.id)}
        value={isOrderSelected}
      />
    </TableCell>
  );
};

export default OrderRowCheckBox;
