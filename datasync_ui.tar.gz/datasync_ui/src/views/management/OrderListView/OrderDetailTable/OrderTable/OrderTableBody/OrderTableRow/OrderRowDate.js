import React, { useContext } from "react";
import { Typography } from "@material-ui/core";
import moment from "moment";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";

const OrderRowDate = ({ orderDate, orderReturnDate }) => {
  const { tab } = useContext(OrderProductsContext);

  const date = tab === "refund_walmart" ? orderReturnDate : orderDate;

  return (
    <Typography variant="body2" color="textSecondary">
      {moment(date).format("MMM DD YYYY")}
    </Typography>
  );
};

export default React.memo(OrderRowDate);
