import React from "react";
import { Box, Link as MuiLink, Typography } from "@material-ui/core";
import SvgIconsCustom from "src/components/Icons/svgIcons";
import { useQueryV2 } from "src/hooks/useQuery";
import { useSelector } from "react-redux";
import useUserExp from "src/hooks/useUserExp";
import { useHistory } from "react-router-dom";

const OrderSyncStatus = () => {
  const history = useHistory();
  const { search } = useQueryV2();
  const { orders, isLoading } = useSelector(state => state?.order);
  const { isUserFree } = useUserExp();

  const handlePaidPlan = () => {
    history.push("/subscription");
  };

  if (!search && orders?.length === 0 && isUserFree && !isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" p={1}>
        <Box maxWidth={1000} p={3} textAlign={"center"}>
          <Box display="flex" alignItems="center">
            <SvgIconsCustom color={"crown"} />
            <Box mr={1} />
            <Typography variant="h5" color="textPrimary">
              Order Sync is available for&nbsp;
              <MuiLink style={{ cursor: "pointer" }} onClick={handlePaidPlan}>
                Paid Plans
              </MuiLink>
              .
            </Typography>
          </Box>
        </Box>
      </Box>
    );
  }

  return null;
};

export default OrderSyncStatus;
