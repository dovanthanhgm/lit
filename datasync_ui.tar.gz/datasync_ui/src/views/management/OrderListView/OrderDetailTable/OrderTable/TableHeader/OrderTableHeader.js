import React, { useContext, useMemo } from "react";
import { Checkbox, TableCell, TableHead, TableRow } from "@material-ui/core";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";
import { useSelector } from "react-redux";
import { SelectOrderContext } from "src/views/management/OrderListView/Context/SelectOrderContext";

const tableHeadName = [
  "Order #",
  "Order Date",
  "Products Link",
  "Status",
  // "Paid",
  // "Shipped",
  "Channel",
  "Channel Order #",
  "Item SKU",
  "Item Name",
  "Bin Picking Number",
  "Buyer",
  // "Ship Method",
  "Total",
  "Last Updated"
];

const OrderTableHeader = () => {
  const { tab } = useContext(OrderProductsContext);
  const {
    handleSelectAllOrders,
    selectedSomeOrders,
    selectedAllOrders
  } = useContext(SelectOrderContext);
  const { isLoading } = useSelector(state => state?.order);
  const { defaultListing } = useSelector(state => state.listing);

  const BigCommerceCol = useMemo(() => {
    return defaultListing?.type === "bigcommerce";
  }, [defaultListing]);

  const orderArray = () => {
    let initArray = [...tableHeadName];
    if (isLoading) {
      return tableHeadName.filter(
        item => !["Link status", "Bin Picking Number"].includes(item)
      );
    }
    if (!BigCommerceCol) {
      initArray = tableHeadName.filter(item => item !== "Bin Picking Number");
    }
    // if (["unlink"].includes(tab)) {
    //   initArray = tableHeadName.filter(item => item !== "Link Status");
    // }
    return ["count"].includes(tab)
      ? initArray
      : initArray.filter((item, index) => index !== 2); // remove link status
  };

  return (
    <TableHead
      style={{
        top: 0,
        zIndex: 2,
        position: "sticky",
        boxShadow: "none",
        backgroundColor: "white"
      }}
    >
      <TableRow>
        {["unlink", "error"].includes(tab) && (
          <TableCell align="left" padding="checkbox">
            <Checkbox
              checked={selectedAllOrders}
              indeterminate={selectedSomeOrders}
              onChange={handleSelectAllOrders}
            />
          </TableCell>
        )}
        {tab !== "unlink" && !isLoading && (
          <TableCell style={{ paddingLeft: 4, paddingRight: 4 }} />
        )}
        {orderArray().map((item, key) => (
          <TableCell key={key} align="left">
            {item}
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
};

export default OrderTableHeader;
