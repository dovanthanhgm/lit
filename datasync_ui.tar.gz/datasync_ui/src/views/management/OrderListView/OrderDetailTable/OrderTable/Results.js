import {
  Box,
  Divider,
  makeStyles,
  Table,
  TableContainer
} from "@material-ui/core";
import React from "react";
import OrderModalDetail from "src/views/management/OrderDetailsView/Modal/index";
import OrderTablePagination from "src/views/management/OrderListView/OrderDetailTable/OrderTable/TablePagination";
import FilterOrderTable from "src/views/management/OrderListView/OrderDetailTable/OrderTable/FilterOrderTable";
import SelectedOrdersText from "src/views/management/OrderListView/OrderDetailTable/OrderTable/SelectedOrdersText";
import OrderTableHeader from "src/views/management/OrderListView/OrderDetailTable/OrderTable/TableHeader/OrderTableHeader";
import OrderSyncStatus from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderSyncStatus";
import OrderLoadingTable from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/LoadingTable";
import OpenOrderDetailDialogProvider from "src/views/management/OrderListView/Context/OpenOrderDetailDialog";
import OrderTableRow from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow";
import SelectOrderProvider from "../../Context/SelectOrderContext";
import PageScrollbarCustom from "src/components/PageScrollbarCustom";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexDirection: "column",
    overflow: "hidden"
  },
  table: {
    width: "100%",
    "& a": {
      textDecoration: "none"
    },
    flex: 1,
    overflow: "hidden"
  }
}));

function OrderTableResult() {
  const classes = useStyles();

  return (
    <OpenOrderDetailDialogProvider>
      <SelectOrderProvider>
        <Box className={classes.root}>
          <OrderModalDetail />

          <Box
            style={{
              overflow: "hidden",
              display: "flex",
              flexDirection: "column"
            }}
          >
            <SelectedOrdersText />
            <Divider />
            <Box className={classes.table} display="flex">
              <TableContainer>
                <PageScrollbarCustom
                  position="relative"
                  style={{ height: "100%" }}
                >
                  <Table size="small">
                    <OrderTableHeader />
                    <OrderTableRow />
                    <OrderLoadingTable />
                  </Table>
                </PageScrollbarCustom>
              </TableContainer>
            </Box>

            <OrderSyncStatus />
            <FilterOrderTable />
            <OrderTablePagination />
          </Box>
        </Box>
      </SelectOrderProvider>
    </OpenOrderDetailDialogProvider>
  );
}

export default OrderTableResult;
