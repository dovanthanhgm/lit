import React, { useContext } from "react";
import { TableCell, Tooltip } from "@material-ui/core";
import ErrorIcon from "@material-ui/icons/Error";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";
import { useSelector } from "react-redux";

const OrderRowStatusIcon = ({ order }) => {
  const { tab } = useContext(OrderProductsContext);
  const { defaultListing } = useSelector(state => state.listing);

  const handleErrorStatus = (orderDetail = {}) => {
    if (Object.keys(orderDetail).length > 0) {
      const defaultId = defaultListing?.id;

      let listOrder = [];
      listOrder = Object.values(orderDetail?.channel).reduce((prev, curr) => {
        prev[curr.channel_id] = curr;
        return prev;
      }, {});
      return listOrder[defaultId]?.status;
    }
  };

  if (tab === "unlink") {
    return null;
  }

  return (
    <TableCell
      style={{ paddingLeft: tab === "error" ? 4 : 8, paddingRight: 0 }}
      align="center"
    >
      {handleErrorStatus(order) === "error" && (
        <Tooltip title={order?.error_message || ""}>
          <ErrorIcon fontSize="small" color="error" />
        </Tooltip>
      )}
    </TableCell>
  );
};

export default OrderRowStatusIcon;
