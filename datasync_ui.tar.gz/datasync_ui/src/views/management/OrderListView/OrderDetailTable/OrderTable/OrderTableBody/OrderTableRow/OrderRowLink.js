import React, { useContext } from "react";
import { Link, makeStyles, TableCell } from "@material-ui/core";
import { getOrderDetailSuccess } from "src/actions/orderActions";
import { useDispatch } from "react-redux";
import { OpenOrderDetailDialogContext } from "src/views/management/OrderListView/Context/OpenOrderDetailDialog";

const useStyles = makeStyles(theme => ({
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    paddingLeft: 10,
    paddingRight: 10,
    maxWidth: 250
  }
}));

const OrderRowLink = ({ order }) => {
  const classes = useStyles();
  const { setOpen, setOrderID } = useContext(OpenOrderDetailDialogContext);
  const dispatch = useDispatch();

  return (
    <TableCell className={classes.tableCell}>
      <Link
        color="primary"
        style={{ cursor: "pointer" }}
        onClick={() => {
          console.log(order?.id);
          window.history.replaceState(null, null, `/orders/${order?.id}`);
          setOpen(order);
          setOrderID(order?.id);
          dispatch(getOrderDetailSuccess(order));
        }}
      >
        {order.order_number}
      </Link>
    </TableCell>
  );
};

export default OrderRowLink;
