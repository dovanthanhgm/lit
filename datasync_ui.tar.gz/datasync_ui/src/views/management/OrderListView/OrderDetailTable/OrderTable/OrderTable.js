import React from "react";
import { useSelector } from "react-redux";
import OrderListingLength from "src/views/management/OrderListView/EmptyOrderData/OrderListingLength";
import OrderTutorial from "src/views/management/OrderListView/OrderTutorial/index";
import OrderTableResult from "src/views/management/OrderListView/OrderDetailTable/OrderTable/Results";

const OrderTable = () => {
  const { listings } = useSelector(state => state?.listing);

  if (listings?.length === 0) {
    return <OrderListingLength />;
  }

  return (
    <React.Fragment>
      <OrderTutorial />
      <OrderTableResult />
    </React.Fragment>
  );
};

export default OrderTable;
