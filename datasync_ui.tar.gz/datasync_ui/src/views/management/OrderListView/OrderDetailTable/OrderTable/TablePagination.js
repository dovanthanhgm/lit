import React, { useContext, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { OrderCountContext } from "src/views/management/OrderListView/Context/OrderCountContext";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";
import { useQueryV2 } from "src/hooks/useQuery";
import wait from "src/utils/wait";
import { getOrderFilterLoading } from "src/actions/orderActions";
import { useHistory } from "react-router-dom";
import CustomPagination from "src/components/MUI/CustomTable/CustomPagination";
import { localRowPerPageOrder } from "src/constants/Order/index";

const OrderTablePagination = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { search, limit: initLimit, state } = useQueryV2();
  const initPage = state?.page || 1;

  const { count } = useContext(OrderCountContext);
  const { tab } = useContext(OrderProductsContext);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(localRowPerPageOrder() || initLimit);

  const setLoading = () => {
    dispatch(getOrderFilterLoading(true));
  };

  const handlePageChange = (_, newPage) => {
    const setTablePage = async newPage => {
      const params = new URLSearchParams(search);
      setLoading(true);
      setPage(newPage + 1);
      await wait(150);
      history.push(
        {
          search: params.toString()
        },
        { ...state, page: newPage + 1 }
      );
    };

    setTablePage(newPage);
  };

  const handleLimitChange = event => {
    const setLimitOrder = async limitValue => {
      setLoading(true);
      const params = new URLSearchParams(search);
      setLimit(limitValue);
      setPage(1);
      localStorage.setItem("orderRowPerPage", event.target.value);
      await wait(150);
      history.push(
        {
          search: params.toString(),
          limit: limitValue
        },
        { ...state, page: 1, limit: limitValue }
      );
    };

    setLimitOrder(event?.target?.value);
  };

  const handleCustomPage = e => {
    handlePageChange(0, e.target.value);
  };

  useEffect(() => {
    setPage(initPage);
  }, [initPage]);

  return (
    <CustomPagination
      total={count?.[tab] ?? 0}
      page={page - 1}
      limit={limit}
      onPageChange={handlePageChange}
      onRowPerPageChange={handleLimitChange}
      onHandleCustomPageChange={handleCustomPage}
    />
  );
};

export default OrderTablePagination;
