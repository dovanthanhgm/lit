import React from "react";
import {
  Box,
  makeStyles,
  TableBody,
  TableCell,
  TableRow
} from "@material-ui/core";
import { useSelector } from "react-redux";
import Loading from "src/components/Loading/Loading";

const useStyles = makeStyles(theme => ({
  circle: {
    borderBottom: "none"
  }
}));

const OrderLoadingTable = () => {
  const classes = useStyles();
  const { isLoading } = useSelector(state => state.order);

  if (!isLoading) {
    return null;
  }

  return (
    <TableBody>
      <TableRow>
        <TableCell className={classes.circle}>
          <Box p={2}>
            <Loading />
          </Box>
        </TableCell>
      </TableRow>
    </TableBody>
  );
};

export default OrderLoadingTable;
