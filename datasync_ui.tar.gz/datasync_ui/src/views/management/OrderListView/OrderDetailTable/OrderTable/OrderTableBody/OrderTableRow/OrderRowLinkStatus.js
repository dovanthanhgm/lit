import React, { useContext } from "react";
import { CircularProgress, makeStyles, TableCell } from "@material-ui/core";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";

const useStyles = makeStyles(theme => ({
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    paddingLeft: 10,
    paddingRight: 10,
    maxWidth: 250
  }
}));

const renderStatus = isShowIcon => {
  if (isShowIcon) {
    return <CircularProgress disableShrink size={20} />;
  }

  return null;
};

const OrderRowLinkStatus = () => {
  const classes = useStyles();
  const { tab } = useContext(OrderProductsContext);

  if (tab !== "unlink") {
    return null;
  }

  return <TableCell className={classes.tableCell}>{renderStatus()}</TableCell>;
};

export default OrderRowLinkStatus;
