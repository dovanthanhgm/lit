import React from "react";
import { Box, Typography } from "@material-ui/core";
import { useSelector } from "react-redux";
import { useQueryV2 } from "src/hooks/useQuery";
import useUserExp from "src/hooks/useUserExp";

const FilterOrderTable = () => {
  const { expired, isUserFree } = useUserExp();
  const { search } = useQueryV2();

  const { isLoading, orders } = useSelector(state => state.order);
  const channelListings = useSelector(state => state.listing.listings);

  const isAllChannelNotSync = () =>
    channelListings.every(channel => {
      return ["disabled", false, null, undefined, "disable"].includes(
        channel?.settings?.order?.status
      );
    });
  const isShowAlert = !isUserFree && !expired && isAllChannelNotSync();

  const handleMessage = () => {
    if (!!search) {
      return "Not found";
    }
    if (isShowAlert) {
      return "Please enable Inventory Sync/Order Sync on your Channel(s) to start importing orders.";
    }
    return "No data";
  };

  if (orders?.length === 0 && !isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" p={1}>
        <Box maxWidth={1000} p={3} textAlign={"center"}>
          <Typography variant="body1" color="textPrimary">
            {handleMessage()}
          </Typography>
        </Box>
      </Box>
    );
  }
  return null;
};

export default FilterOrderTable;
