import React, { useContext, useEffect } from "react";
import { Box, makeStyles, Typography } from "@material-ui/core";
import UpdateOrder from "src/components/Orders/UpdateOrder";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";
import { SelectOrderContext } from "src/views/management/OrderListView/Context/SelectOrderContext";

const useStyles = makeStyles(theme => ({
  button: {
    margin: "0 10px 0 10px"
  }
}));

const SelectedOrdersText = () => {
  const classes = useStyles();
  const { tab } = useContext(OrderProductsContext);
  const { selectedOrder, setSelectedOrder } = useContext(SelectOrderContext);

  useEffect(() => {
    setSelectedOrder([]);
    // eslint-disable-next-line
  }, [tab]);

  if (!["unlink", "error"].includes(tab)) {
    return null;
  }

  return (
    <Box display="flex" m={2} alignItems="center">
      <Typography className={classes.button} variant="body2">
        {selectedOrder.length} order
        {selectedOrder.length > 1 ? "s" : ""} selected
      </Typography>
      <UpdateOrder
        selectedOrder={selectedOrder}
        setSelectedOrders={setSelectedOrder}
      />
    </Box>
  );
};

export default SelectedOrdersText;
