import React from "react";
import { TableBody } from "@material-ui/core";
import { useSelector } from "react-redux";
import OrderRow from "src/views/management/OrderListView/OrderRow";

const OrderTableRow = () => {
  const { isLoading, orders } = useSelector(state => state.order);

  if (isLoading) {
    return null;
  }
  return (
    <TableBody>
      {orders?.map(order => {
        return <OrderRow key={order.id} order={order} />;
      })}
    </TableBody>
  );
};

export default OrderTableRow;
