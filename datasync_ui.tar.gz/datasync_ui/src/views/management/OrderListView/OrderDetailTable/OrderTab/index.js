import React, { useContext } from "react";
import { Box, Tab, Tabs } from "@material-ui/core";
import { tabs } from "src/constants/Order/index";
import OrderTabLabel from "src/views/management/OrderListView/OrderDetailTable/OrderTab/OrderTabLabel";
import { useDispatch } from "react-redux";
import { currentTab, getOrderFilterLoading } from "src/actions/orderActions";
import { useQueryV2 } from "src/hooks/useQuery";
import { useHistory } from "react-router-dom";
import { OrderCountContext } from "src/views/management/OrderListView/Context/OrderCountContext";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";
import useWalmartRefund from "../../hook/useWalmartRefund";

const OrderDetailTab = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { count, total } = useContext(OrderCountContext);
  const { tab, setTab, openDialogWarning } = useContext(OrderProductsContext);
  const isWalmart = useWalmartRefund();
  const { search, state } = useQueryV2();
  const page = state?.page || 1;

  const handleChangeTabs = (_, newValue) => {
    if (openDialogWarning) return;
    if (newValue !== tab) {
      dispatch(getOrderFilterLoading(true));
      setTab(newValue);
      dispatch(currentTab(newValue));

      if (page) {
        const params = new URLSearchParams(search);
        if (newValue === "unlink") {
          params.set("link_status", newValue);
          params.delete("status");
        } else {
          params.set("status", newValue);
          params.delete("link_status");
        }
        if (newValue === "count") {
          params.set("status", "");
        }

        history.push(
          {
            search: params.toString()
          },
          { ...state, page: 1 }
        );
      }
    }
  };

  const handleOrderTab = () => {
    if (isWalmart) {
      return [...tabs, { name: "Refund", value: "refund_walmart" }];
    }
    return tabs;
  };

  const handleChipRefund = tab => {
    return !(isWalmart && tab === "refund_walmart");
  };

  const isSelected = tabItem => tabItem === tab;

  if (!total && !isWalmart) {
    return null;
  }

  return (
    <Box>
      <Tabs
        scrollButtons="auto"
        textColor="secondary"
        value={tab}
        variant="scrollable"
        onChange={handleChangeTabs}
      >
        {handleOrderTab().map((item, key) => (
          <Tab
            size="small"
            key={key}
            value={item.value}
            style={
              isWalmart && item.value === "refund_walmart"
                ? {}
                : !count[item.value]
                ? { display: "none" }
                : { whiteSpace: "nowrap", maxWidth: "none" }
            }
            label={
              <OrderTabLabel
                index={key}
                count={count}
                item={item}
                isSelected={isSelected}
                hideChip={handleChipRefund(item.value)}
              />
            }
          />
        ))}
      </Tabs>
    </Box>
  );
};

export default OrderDetailTab;
