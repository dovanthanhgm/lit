import { Box, Chip, makeStyles } from "@material-ui/core";
import { LightTooltip } from "src/constants/index";
import { questionMark } from "src/constants/Order/index";
import { Help as HelpIcon } from "@material-ui/icons";
import React, { useContext } from "react";
import ErrorIcon from "@material-ui/icons/Error";
import TabLabelCustom from "src/components/Layout/TabLabelCustom";
import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    marginTop: theme.spacing(3)
    // paddingBottom: theme.spacing(3)
  },
  markColor: {
    color: theme.palette.warning.main
  },
  toolTipSpace: {
    marginBottom: 8
  },
  chip: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1)
  },
  chipNotSelected: {
    marginLeft: theme.spacing(1),
    color: "#546e7a",
    backgroundColor: "#e4e4e4"
  }
}));

export default function OrderTabLabel({
  item,
  index,
  count,
  hideChip = true,
  isSelected = function() {}
}) {
  const classes = useStyles();

  const { setOpenDialogWarning } = useContext(OrderProductsContext);

  return (
    <Box display="flex" alignItems="center">
      {item.value === "unlink" && (
        <Box
          onMouseEnter={() => setOpenDialogWarning(true)}
          display="flex"
          alignItems="center"
          pb={0.5}
          onMouseLeave={() => setOpenDialogWarning(false)}
        >
          <LightTooltip
            arrow
            title={questionMark(classes)}
            placement="top"
            disableTouchListener
            interactive
          >
            {/*<IconButton size="small">*/}
            <HelpIcon className={classes.markColor} fontSize="small" />
            {/*</IconButton>*/}
          </LightTooltip>
        </Box>
      )}
      {item.value === "error" && (
        <Box
          onMouseEnter={() => setOpenDialogWarning(true)}
          onMouseLeave={() => setOpenDialogWarning(false)}
          display="flex"
          alignItems="center"
          pb={0.5}
        >
          {/*<IconButton size="small">*/}
          <ErrorIcon color="error" fontSize="small" />
          {/*</IconButton>*/}
        </Box>
      )}
      <TabLabelCustom>{item.name}</TabLabelCustom>
      {hideChip && (
        <Chip
          size="small"
          label={count[item?.value]}
          color="primary"
          className={
            !isSelected(item.value) ? classes.chipNotSelected : classes.chip
          }
        />
      )}
    </Box>
  );
}
