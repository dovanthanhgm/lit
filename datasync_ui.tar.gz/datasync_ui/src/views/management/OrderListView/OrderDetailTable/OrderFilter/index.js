import React, { useContext, useState } from "react";
import { orderArray } from "src/constants/Order/index";
import { Form, Formik } from "formik";
import { useQueryV2 } from "src/hooks/useQuery";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import FilterOrder from "src/views/management/OrderListView/Filter/index";
import { Box } from "@material-ui/core";
import { getOrderFilterLoading } from "../../../../../actions/orderActions";
import { OrderCountContext } from "../../Context/OrderCountContext";
import authService from "../../../../../services/authService";

const OrderListViewFilter = () => {
  const loginByAdmin = authService.getLoginByAdmin(); //undefined if not found

  const dispatch = useDispatch();
  const history = useHistory();
  const {
    search: initSearch,
    query,
    channel_id,
    min_date,
    max_date,
    status,
    state
  } = useQueryV2();
  const { setCountFetching } = useContext(OrderCountContext);

  const { orderTab } = useSelector(state => state?.order);
  const [currentFilter, setCurrentFilter] = useState("");

  const initValue = {
    query: query || "",
    channel_id: channel_id || "",
    min_date: min_date || "",
    max_date: max_date || "",
    status: status || orderArray[orderTab] || "",
    state: state || ""
  };

  return (
    <Box>
      <Formik
        initialValues={initValue}
        enableReinitialize
        onSubmit={async values => {
          try {
            let search = ``;
            let symbol = "?";

            let params = {
              status: orderArray[orderTab] || "",
              query: values.query,
              channel_id: values.channel_id,
              min_date: values.min_date,
              max_date: values.max_date
            };

            Object.keys(params).forEach(key => {
              if (![null, undefined, "", "NaN", NaN].includes(params[key])) {
                search += `${symbol}${key}=${
                  ["query"].includes(key) ? values[key].trim() : values[key]
                }`;
                symbol = "&";
              }
            });

            const param1 = new URLSearchParams(initSearch);

            param1.delete("link_status");
            param1.delete("status");
            let searchParam = param1.toString();

            if (loginByAdmin) {
              console.log("log admin mode", searchParam);
              console.log("log admin mode", search);
              console.log("log admin mode", currentFilter);
            }

            if (currentFilter !== search) {
              dispatch(getOrderFilterLoading(true));
              setCountFetching(true);

              history.push(
                {
                  search: encodeURI(search)
                },
                { page: 1 }
              );
              setCurrentFilter(search);
            }
          } catch (error) {
            console.log("error", error);
          }
        }}
      >
        {({ handleSubmit }) => {
          return (
            <Form onSubmit={handleSubmit}>
              <FilterOrder setCurrentFilter={setCurrentFilter} />
            </Form>
          );
        }}
      </Formik>
    </Box>
  );
};

export default OrderListViewFilter;
