import { Box } from "@material-ui/core";
import TutorialDialogs from "src/components/Modal/TutorialDialog";
import React, { useState } from "react";
import { goTutorial } from "src/actions/accountActions";
import { useDispatch, useSelector } from "react-redux";

export default function OrderTutorial() {
  const [open, setOpen] = useState(true);
  const dispatch = useDispatch();
  const { go_tutorial } = useSelector(state => state?.account);

  const handleClose = () => {
    setOpen(false);
    dispatch(goTutorial(false));
  };

  if (!go_tutorial) {
    return null;
  }
  return (
    <Box>
      <TutorialDialogs handleClose={handleClose} open={open} tab={"order"} />
    </Box>
  );
}
