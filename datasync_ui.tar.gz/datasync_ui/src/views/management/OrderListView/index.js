import { Card, Container, makeStyles } from "@material-ui/core";
import React from "react";

import Page from "src/components/Page";
import authService from "src/services/authService";

import FreeAccountOrder from "./OrderLoginToken/FreeAccountOrder";

import useUserExp from "src/hooks/useUserExp";
import { withAccessOrders } from "src/hooks/hocs";
import OrderCountProvider from "src/views/management/OrderListView/Context/OrderCountContext";
import OrderListViewHeader from "./Header";
import OrderProductProvider from "src/views/management/OrderListView/Context/OrderProductsContext";
import OrderListViewFilter from "src/views/management/OrderListView/OrderDetailTable/OrderFilter/index";
import OrderDetailTab from "src/views/management/OrderListView/OrderDetailTable/OrderTab/index";
import OrderTable from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTable";
import { QueryClient, QueryClientProvider } from "react-query";
import { ReactQueryDevtools } from "react-query/devtools";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false
    }
  }
});

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    overflow: "hidden",
    padding: "12px 0"
  },
  containerRoot: {
    display: "flex",
    flexDirection: "column",
    padding: "0 12px",
    height: "100%"
  },
  cardRoot: {
    display: "flex",
    flexDirection: "column"
  }
}));

function OrderListView() {
  const classes = useStyles();
  const { isUserFree } = useUserExp();
  const loginByToken = authService.getLoginByToken();

  if (isUserFree && !loginByToken) {
    return (
      <Page className={classes.root} title="Orders List">
        <Container maxWidth={false}>
          <FreeAccountOrder />
        </Container>
      </Page>
    );
  }

  return (
    <Page className={classes.root} title="Orders List" noPadding>
      <ErrorBoundaryComponent>
        <Container className={classes.containerRoot} maxWidth={false}>
          <OrderListViewHeader />
          <QueryClientProvider client={queryClient}>
            <ReactQueryDevtools initialIsOpen={false} />

            <OrderCountProvider>
              <OrderProductProvider>
                <React.Fragment>
                  <Card className={classes.cardRoot}>
                    <OrderListViewFilter />
                    <OrderDetailTab />
                    <OrderTable />
                  </Card>
                </React.Fragment>
              </OrderProductProvider>
            </OrderCountProvider>
          </QueryClientProvider>
        </Container>
      </ErrorBoundaryComponent>
    </Page>
  );
}

export default withAccessOrders(OrderListView);
