import { useSelector } from "react-redux";
import { useMemo } from "react";
import { useQueryV2 } from "../../../../hooks/useQuery";

const useWalmartRefund = () => {
  const { channel_id } = useQueryV2();
  const { listings } = useSelector(state => state.listing);

  const matchingChannel = useMemo(() => {
    // eslint-disable-next-line
    return listings.find(channel => channel.id == channel_id) || { type: "" };
  }, [listings, channel_id]);
  const isWalmart = useMemo(() => {
    return matchingChannel.type === "walmart";
  }, [matchingChannel]);

  return isWalmart;
};

export default useWalmartRefund;
