import React, { useContext, useEffect, useMemo, useState } from "react";
import { OrderCountContext } from "src/views/management/OrderListView/Context/OrderCountContext";
import { useDispatch } from "react-redux";
import {
  getOrderFailed,
  getOrderFilterLoading,
  getOrderSuccess
} from "src/actions/orderActions";
import { useQueryV2 } from "src/hooks/useQuery";
import {
  localRowPerPageOrder,
  TABLE_ORDER_TABLE
} from "src/constants/Order/index";
import { useQuery } from "react-query";
import { getOrdersRefundWalmart, getOrdersTable } from "src/services/orders";
import useWalmartRefund from "../hook/useWalmartRefund";

export const OrderProductsContext = React.createContext({
  tab: "",
  setTab: function() {},
  openDialogWarning: false,
  setOpenDialogWarning: function() {}
});

const OrderProductProvider = ({ children }) => {
  const dispatch = useDispatch();
  const { search, status, limit: routeLimit, state, channel_id } = useQueryV2();
  const page = state?.page || 1;
  const limit = localRowPerPageOrder() || routeLimit;
  const isWalmart = useWalmartRefund();

  const { initTab, countFetching, count, initCount } = useContext(
    OrderCountContext
  );
  const [tab, setTab] = useState(initTab || "count");
  const [openDialogWarning, setOpenDialogWarning] = useState(false);

  const currentCountTab = useMemo(() => {
    return count?.[tab];
  }, [count, tab]);

  useEffect(() => {
    setTab(initTab);
  }, [initTab]);

  useEffect(() => {
    if (!isWalmart) {
      if (!currentCountTab && initCount) {
        setTab("count");
      }
    }
  }, [currentCountTab, status, isWalmart, initCount]);

  const getOrderData = async ({ params, state }) => {
    return await getOrdersTable({ params, extraParams: state });
  };

  const getOrderWalmartRefundData = async ({ params }) => {
    return await getOrdersRefundWalmart({
      extraParams: {
        walmartData: {
          paramsWalmart: params,
          channelID: channel_id
        }
      }
    });
  };

  const paramsWalmart = useMemo(() => {
    const params = new URLSearchParams(search);

    params.delete("link_status");
    params.delete("status");
    return params.toString();
  }, [search]);

  useQuery(
    [TABLE_ORDER_TABLE, search, limit, page, tab],
    async () => {
      dispatch(getOrderFilterLoading(true));

      return tab === "refund_walmart"
        ? getOrderWalmartRefundData({ params: paramsWalmart })
        : getOrderData({
            params: search,
            state: { ...state, limit }
          });
    },
    {
      retryDelay: 30000,
      onSuccess: data => {
        dispatch(getOrderSuccess(data?.data));
      },
      onError: () => {
        dispatch(getOrderFailed());
        dispatch(getOrderFilterLoading(false));
      },
      enabled: !countFetching && (!!count[tab] || tab === "refund_walmart"),
      // cacheTime: ,
      onSettled: () => {
        dispatch(getOrderFilterLoading(false));
      }
    }
  );

  return (
    <OrderProductsContext.Provider
      value={{
        tab,
        setTab,
        openDialogWarning,
        setOpenDialogWarning
      }}
    >
      {children}
    </OrderProductsContext.Provider>
  );
};

export default OrderProductProvider;
