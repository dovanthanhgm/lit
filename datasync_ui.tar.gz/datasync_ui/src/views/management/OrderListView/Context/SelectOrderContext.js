import React, { useState } from "react";
import { useSelector } from "react-redux";

export const SelectOrderContext = React.createContext({
  selectedOrder: [],
  setSelectedOrder: function() {},
  handleSelectAllOrders: function() {},
  handleSelectOneOrder: function() {},
  selectedSomeOrders: false,
  selectedAllOrders: false
});

const SelectOrderProvider = ({ children }) => {
  const [selectedOrder, setSelectedOrder] = useState([]);
  const { orders } = useSelector(state => state?.order);

  const handleSelectAllOrders = event => {
    setSelectedOrder(event.target.checked ? orders.map(order => order.id) : []);
  };

  const handleSelectOneOrder = (_, orderId) => {
    if (!selectedOrder.includes(orderId)) {
      setSelectedOrder(prevSelected => [...prevSelected, orderId]);
    } else {
      setSelectedOrder(prevSelected =>
        prevSelected.filter(id => id !== orderId)
      );
    }
  };

  const selectedSomeOrders =
    selectedOrder.length > 0 && selectedOrder.length < orders.length;
  const selectedAllOrders = selectedOrder.length === orders.length;

  return (
    <SelectOrderContext.Provider
      value={{
        selectedOrder,
        setSelectedOrder,
        handleSelectAllOrders,
        handleSelectOneOrder,
        selectedSomeOrders,
        selectedAllOrders
      }}
    >
      {children}
    </SelectOrderContext.Provider>
  );
};

export default SelectOrderProvider;
