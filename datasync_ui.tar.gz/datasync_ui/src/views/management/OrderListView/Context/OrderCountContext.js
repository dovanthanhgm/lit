import React, { useEffect, useMemo, useState } from "react";
import {
  currentTab,
  getOrderFilterLoading,
  getOrderSuccess
} from "src/actions/orderActions";
import { getOrderCount } from "src/services/orders";
import { TABLE_ORDER_COUNT, tabs } from "src/constants/Order/index";
import { useDispatch } from "react-redux";
import { useQueryV2 } from "src/hooks/useQuery";
import { useQuery } from "react-query";
import useWalmartRefund from "src/views/management/OrderListView/hook/useWalmartRefund";

const returnOrderTab = data => {
  let newVal = "count";
  for (let tab of tabs) {
    if (data[tab.value] > 0) {
      newVal = tab?.value;
      break;
    }
  }
  return newVal;
};

const getTotalCount = data => {
  if (data) {
    return Object.values(data).reduce((total, tab) => (total += tab), 0);
  }
  return 0;
};

export const OrderCountContext = React.createContext({
  countFetching: false,
  setCountFetching: function() {},
  count: {},
  setCount: {},
  initTab: "count",
  total: 0,
  initCount: false
});

const OrderCountProvider = ({ children }) => {
  const dispatch = useDispatch();
  const { search, status, link_status } = useQueryV2();
  const isWalmart = useWalmartRefund();

  const handleTab = useMemo(() => {
    if (!!link_status) {
      return link_status;
    }
    return status;
  }, [status, link_status]);

  const [count, setCount] = useState({});
  const [countFetching, setCountFetching] = useState(true);
  const [initTab, setInitTab] = useState(handleTab || "count");
  const [initCount, setIsInitCount] = useState(false);

  const initSearch = useMemo(() => {
    if (!search) return "";
    const params = new URLSearchParams(search);

    params.delete("link_status");
    params.delete("status");
    let searchParam = params.toString();

    if (searchParam && typeof searchParam === "string") {
      if (!["?"].includes(searchParam[0])) {
        searchParam = "?" + searchParam;
      }
    } else {
      searchParam = "";
    }
    return searchParam;
  }, [search]);

  useQuery(
    [TABLE_ORDER_COUNT, initSearch],
    async () => getOrderCount({ params: initSearch }),
    {
      retryDelay: 30000,
      onSuccess: data => {
        setCount(data);
        if (!getTotalCount(data)) {
          dispatch(getOrderFilterLoading(false));
          dispatch(getOrderSuccess([]));
        }
        if (isWalmart && !getTotalCount(data)) {
          dispatch(currentTab(returnOrderTab(data)));
          setInitTab("refund_walmart");
          dispatch(getOrderFilterLoading(true));
        }
      },
      enabled: true,
      onSettled: () => {
        setCountFetching(false);
        setIsInitCount(true);
      }
    }
  );

  useEffect(() => {
    dispatch(getOrderFilterLoading(true));
    // eslint-disable-next-line
  }, []);

  return (
    <OrderCountContext.Provider
      value={{
        countFetching,
        setCountFetching,
        count,
        setCount,
        initTab,
        initCount,
        total: getTotalCount(count) || 0
      }}
    >
      {children}
    </OrderCountContext.Provider>
  );
};

export default OrderCountProvider;
