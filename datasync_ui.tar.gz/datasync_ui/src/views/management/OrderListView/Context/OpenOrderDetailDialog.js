import React, { useEffect, useState } from "react";
import { useParams } from "react-router";

export const OpenOrderDetailDialogContext = React.createContext({
  open: false,
  setOpen: function() {},
  handleCloseModal: function() {},
  openOrderId: false,
  setOpenOrderID: function() {},
  orderID: "",
  setOrderID: function() {}
});

const OpenOrderDetailDialogProvider = ({ children }) => {
  const { order_id } = useParams();

  const [open, setOpen] = useState();
  const [openOrderId, setOpenOrderID] = useState(false);
  const [orderID, setOrderID] = useState("");

  const handleCloseModal = () => {
    setOpen(null);
    setOpenOrderID(null);
    window.history.replaceState(null, null, "/orders");
  };

  useEffect(() => {
    setOpenOrderID(!!order_id);
    setOrderID(order_id);
  }, [order_id]);

  return (
    <OpenOrderDetailDialogContext.Provider
      value={{
        open,
        setOpen,
        openOrderId,
        setOpenOrderID,
        handleCloseModal,
        setOrderID,
        orderID
      }}
    >
      {children}
    </OpenOrderDetailDialogContext.Provider>
  );
};

export default OpenOrderDetailDialogProvider;
