import React from "react";
import {
  Box,
  Link,
  makeStyles,
  Paper,
  SvgIcon,
  Typography
} from "@material-ui/core";
import { useHistory } from "react-router";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import SvgIconsCustom from "src/components/Icons/svgIcons";
import HeaderPageTitle from "src/components/Layout/HeaderPageTitle";

const useStyles = makeStyles(theme => ({
  root: {
    minHeight: "25vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  actionIcon: {
    marginRight: theme.spacing(1)
  },
  linkStyle: {
    cursor: "pointer"
  }
}));

function FreeAccountOrder() {
  const classes = useStyles();
  const history = useHistory();

  const handlePaidPlan = () => {
    history.push("/subscription");
  };

  return (
    <Box>
      <Box display="flex" alignItems="center" mb={1.5}>
        <SvgIcon fontSize="small" className={classes.actionIcon}>
          <ShoppingCartIcon />
        </SvgIcon>
        <HeaderPageTitle>Orders</HeaderPageTitle>
      </Box>
      <Paper className={classes.root}>
        <Box display="flex" alignItems="center">
          <SvgIconsCustom color={"crown"} />
          <Box mr={1} />
          <Typography variant="h5" color="textPrimary">
            Order Sync is available for&nbsp;
            <Link className={classes.linkStyle} onClick={handlePaidPlan}>
              Paid Plans
            </Link>
            .
          </Typography>
        </Box>
      </Paper>
    </Box>
  );
}

export default FreeAccountOrder;
