import { Box, Typography } from "@material-ui/core";
import ButtonDelete from "src/components/Button/ButtonDelete";
import React from "react";
import { deleteAllOrders } from "src/services/orders";
import { useSnackbar } from "notistack";
import { messageError } from "src/utils/ErrorResponse";

export default function OrderLoginToken({ setToggleDeleteAll }) {
  const { enqueueSnackbar } = useSnackbar();

  const handleConfirmDeleteAll = async () => {
    try {
      await deleteAllOrders();
      enqueueSnackbar("Delete success", {
        variant: "success"
      });
      setToggleDeleteAll(preVal => !preVal);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  return (
    <Box m={2}>
      <ButtonDelete
        buttonText="Delete All"
        handleConfirm={handleConfirmDeleteAll}
        headerDialog="Are you sure?"
        contentDialog={
          <Typography color="textPrimary" variant="body1">
            Are you sure you want to remove all products?
          </Typography>
        }
        buttonTextSubmit="Yes, Remove"
      />
    </Box>
  );
}
