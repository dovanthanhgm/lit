import React, { useContext } from "react";
import {
  Avatar,
  Box,
  makeStyles,
  TableCell,
  TableRow,
  Tooltip,
  Typography
} from "@material-ui/core";
import moment from "moment";
import Label from "src/components/Label";
import { useSelector } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { channelUsePngImage } from "../../../constants";
import OrderRowCheckBox from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow/OrderRowCheckBox";
import OrderRowStatusIcon from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow/OrderRowStatusIcon";
import { SelectOrderContext } from "src/views/management/OrderListView/Context/SelectOrderContext";
import OrderRowLink from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow/OrderRowLink";
import OrderRowLinkStatusIcon from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow/OrderRowLinkStatusIcon";
import OrderRowBpn from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow/OrderRowBPN";
import OrderRowDate from "src/views/management/OrderListView/OrderDetailTable/OrderTable/OrderTableBody/OrderTableRow/OrderRowDate";

const useStyles = makeStyles(theme => ({
  avatar: {
    marginRight: theme.spacing(1),
    "& .MuiAvatar-img": {
      objectFit: "contain"
    },
    width: 32,
    height: 32
  },
  name: {
    fontSize: 14,
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  },
  table: {
    width: "100%",
    "& a": {
      textDecoration: "none"
    },
    paddingBottom: theme.spacing(3)
  },
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    paddingLeft: 10,
    paddingRight: 10,
    maxWidth: 200,
    width: "auto"
  }
}));

const handleImagePath = channelType => {
  if (!channelType || typeof channelType !== "string") return "";
  if (channelUsePngImage.includes(channelType.toLowerCase())) {
    return `/static/images/markets/${channelType.toLowerCase()}.png`;
  }
  return `/static/images/markets/${channelType.toLowerCase()}.svg`;
};

export function paymentStatusColors(status) {
  const map = {
    open: {
      text: "Open",
      color: "primary"
    },
    canceled: {
      text: "Canceled",
      color: "error"
    },
    shipping: {
      text: "shipping",
      color: "secondary"
    },
    ready_to_ship: {
      text: "ready_to_ship",
      color: "warning"
    },
    awaiting_payment: {
      text: "awaiting_payment",
      color: "warning"
    },
    completed: {
      text: "completed",
      color: "success"
    }
  };

  if (status in map) {
    const { text, color } = map[status];
    return <Label color={color}>{text}</Label>;
  } else {
    return <Label>{status}</Label>;
  }
}

const CustomTooltip = withStyles(theme => ({
  tooltip: {
    fontSize: 12,
    maxWidth: 350
  }
}))(Tooltip);

const OrderRow = ({ order }) => {
  const { listings } = useSelector(state => state.listing);
  const classes = useStyles();
  const { selectedOrder } = useContext(SelectOrderContext);
  const updateTime = time => {
    if (moment(time).isValid()) {
      return moment(time).format("MMM DD YYYY");
    }
    return <span>&nbsp;</span>;
  };

  const handleGetChannelOrder = () =>
    listings.find(item => item.id === order.channel_id);

  return (
    <TableRow key={order.id} selected={selectedOrder.indexOf(order.id) !== -1}>
      <OrderRowCheckBox order={order} />
      <OrderRowStatusIcon order={order} />

      {/* Order # */}
      <OrderRowLink order={order} />

      {/* Order Date */}
      <TableCell className={classes.tableCell}>
        <OrderRowDate
          orderDate={order.created_at}
          orderReturnDate={order?.return_order_date}
        />
      </TableCell>

      {/*link status*/}
      <OrderRowLinkStatusIcon order={order} />

      {/*<OrderRowLinkStatus />*/}

      {/* Status */}
      <TableCell className={classes.tableCell}>
        {paymentStatusColors(order.status)}
      </TableCell>

      {/* Paid */}
      {/*<TableCell className={classes.tableCell}>*/}
      {/*  <Box*/}
      {/*    borderRadius="50%"*/}
      {/*    color={*/}
      {/*      order.payment.status ? "#8BD55D" : "#9e9e9e"*/}
      {/*    }*/}
      {/*    bgcolor={*/}
      {/*      order.payment.status ? "#8BD55D" : "#fafafa"*/}
      {/*    }*/}
      {/*    border={1}*/}
      {/*    width={18}*/}
      {/*    height={18}*/}
      {/*  />*/}
      {/*</TableCell>*/}

      {/* Shipped */}
      {/*<TableCell className={classes.tableCell}>*/}
      {/*  <Box*/}
      {/*    borderRadius="50%"*/}
      {/*    color={*/}
      {/*      order.shipping.status ? "#8BD55D" : "#9e9e9e"*/}
      {/*    }*/}
      {/*    bgcolor={*/}
      {/*      order.shipping.status ? "#8BD55D" : "#fafafa"*/}
      {/*    }*/}
      {/*    border={1}*/}
      {/*    width={18}*/}
      {/*    height={18}*/}
      {/*  />*/}
      {/*</TableCell>*/}

      {/* Channel */}
      <TableCell className={classes.tableCell} align="right">
        <Box alignItems="center" display="flex">
          {handleGetChannelOrder() ? (
            <Box display="flex" justifyItems="center" alignItems="center">
              <Avatar
                className={classes.avatar}
                variant="square"
                src={handleImagePath(handleGetChannelOrder().type)}
              />
              <Typography variant="body2">
                {handleGetChannelOrder().name}
              </Typography>
            </Box>
          ) : (
            <Typography variant="body2">Removed Channel</Typography>
          )}
        </Box>
      </TableCell>

      {/* Channel Order # */}
      <TableCell className={classes.tableCell}>
        <Typography variant="body2">{order.channel_order_number}</Typography>
      </TableCell>

      {/*Item SKU */}
      <TableCell className={classes.tableCell}>
        {order?.products?.length > 1 && (
          <Typography variant="body2">{"(multiple items)"}</Typography>
        )}
        {order?.products?.length === 1 && (
          <Typography
            variant="body2"
            // variant="subtitle2"
            // color="primary"
            className={classes.name}
          >
            {order?.products?.[0]?.product_sku}
          </Typography>
        )}
      </TableCell>

      {/* Item Name */}
      <TableCell className={classes.tableCell}>
        {order?.products?.length > 1 && (
          <Typography variant="body2">{"(multiple items)"}</Typography>
        )}
        {order?.products?.length === 1 && (
          <CustomTooltip
            title={order?.products?.[0]?.product_name}
            placement="bottom-start"
          >
            <Typography
              // variant="subtitle2"
              // color="primary"
              variant="body2"
              className={classes.name}
            >
              {order?.products?.[0]?.product_name}
            </Typography>
          </CustomTooltip>
        )}
      </TableCell>

      {/*bpn*/}
      <OrderRowBpn order={order} />
      {/* Buyer */}
      <TableCell className={classes.tableCell}>
        <Typography variant="body2">
          {order.customer["first_name"] +
            " " +
            order.customer["middle_name"] +
            " " +
            order.customer["last_name"]}
        </Typography>
      </TableCell>

      {/* Ship Method */}
      {/*<TableCell className={classes.tableCell}>*/}
      {/*  {order.shipping?.method}*/}
      {/*</TableCell>*/}

      {/* Total */}
      <TableCell className={classes.tableCell}>
        <Typography variant="body2">
          {order?.total || order?.subtotal}
        </Typography>
      </TableCell>

      {/* Last Updated */}
      <TableCell className={classes.tableCell}>
        <Typography variant="body2" color="textSecondary">
          {updateTime(order?.updated_at)}
        </Typography>
      </TableCell>
    </TableRow>
  );
};

export default OrderRow;
