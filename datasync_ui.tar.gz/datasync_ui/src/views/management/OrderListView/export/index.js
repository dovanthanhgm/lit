import React, { useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  FormControl,
  FormControlLabel,
  makeStyles,
  Radio,
  RadioGroup,
  SvgIcon,
  Typography
} from "@material-ui/core";
import { Download as DownloadIcon } from "react-feather";
import { exportOrders } from "../../../../services/manage";
import DialogTitle from "../../../../components/Modal/DialogTitle";
import ModalExportNotifi from "../../../../components/Modal/ModalImportExport/ModalExportNotifi";
import ButtonCustom from "../../../../components/MUI/Button";

const useStyles = makeStyles(theme => ({
  action: {
    marginBottom: theme.spacing(1),
    "& + &": {
      marginLeft: theme.spacing(1)
    }
  },
  actionIcon: {
    marginRight: theme.spacing(1)
  }
}));

export default function ExportOrder({
  setShowAlert,
  filterParams,
  ordersCount
}) {
  const classes = useStyles();
  const [openModal, setOpenModal] = useState(false);
  const [exportOrder, setExportOrder] = useState("all");
  const [openModalNotify, setOpenModalNotify] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);

  const handleModal = () => {
    setOpenModal(!openModal);
  };

  const handleAlert = value => {
    setShowAlert(value);
  };

  const handleShowNotify = value => {
    setOpenModalNotify(value);
  };

  const handleChangeOrderExport = event => {
    setExportOrder(event.target.value);
  };

  const handleExportButton = async () => {
    try {
      setExportLoading(true);
      const body = () => {
        return Object.keys(filterParams)
          .filter(k => filterParams[k] !== "")
          .reduce((a, k) => ({ ...a, [k]: filterParams[k] }), {});
      };

      handleAlert();
      await exportOrders({ body: body() });
      setOpenModalNotify(true);
    } catch (e) {
      console.log(e);
    }
    handleModal();
    setExportLoading(false);
  };

  return (
    <Box>
      <Button
        size="small"
        color="secondary"
        variant="contained"
        className={classes.action}
        onClick={handleModal}
      >
        <SvgIcon fontSize="small" className={classes.actionIcon}>
          <DownloadIcon />
        </SvgIcon>
        Export
      </Button>
      <Dialog
        fullWidth
        onClose={handleModal}
        aria-labelledby="customized-dialog-title"
        open={openModal}
      >
        <DialogTitle
          id="customized-dialog-title"
          onClose={handleModal}
          children={"Export products"}
        >
          Export products
        </DialogTitle>
        <DialogContent dividers>
          <Box mt={2} />
          <Typography variant="h5">Export</Typography>
          <FormControl component="fieldset">
            <RadioGroup
              aria-label="Export"
              name="export"
              value={exportOrder}
              onChange={handleChangeOrderExport}
            >
              <FormControlLabel
                value="all"
                control={<Radio />}
                label="All orders"
              />
              <FormControlLabel
                value="matching"
                control={<Radio />}
                label={`${ordersCount} orders matching your search`}
              />
            </RadioGroup>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            onClick={handleModal}
            variant="contained"
            size="small"
          >
            Cancel
          </Button>
          <ButtonCustom
            onClick={handleExportButton}
            variant="contained"
            color="primary"
            size="small"
            notShowCircle={!exportLoading}
            disabled={exportLoading}
            text="Export Orders"
          />
        </DialogActions>
      </Dialog>
      <ModalExportNotifi
        open={openModalNotify}
        title={"Export orders"}
        handleClose={() => handleShowNotify(false)}
      />
    </Box>
  );
}
