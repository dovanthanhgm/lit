import {
  Box,
  Card,
  Checkbox,
  Container,
  FormControlLabel,
  InputAdornment,
  makeStyles,
  Paper,
  TextField,
  Typography,
} from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import { Formik } from "formik";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { actionGetWarehouses } from "src/actions/warehouse";
import ButtonCustom from "src/components/MUI/Button";
import Page from "src/components/Page";
import { getShipments } from "src/services/shipments";
import Header from "./Header";
import Results from "./Results";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    marginTop: theme.spacing(3),
    paddingBottom: theme.spacing(3),
  },
  tab: {
    width: "auto",
    minWidth: 0,
    height: 40,
  },
  filter: {
    margin: theme.spacing(3),
  },
}));

function ShipmentListView() {
  const classes = useStyles();
  const dispatch = useDispatch();

  const [shipments, setShipments] = useState([]);
  const [loading, setLoading] = useState(false);

  const { listings } = useSelector((state) => state.listing);
  const { warehouses } = useSelector((state) => state.warehouse);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      let params = {
        // status: "status",
        // query: "query",
      };
      const data = await getShipments({ params });
      if (data) {
        setShipments(data?.data);
      }
      setLoading(false);
    }
    fetchData();
  }, []);

  useEffect(() => {
    dispatch(actionGetWarehouses());
  }, [dispatch]);

  return (
    <Page className={classes.root} title="Shipments">
      <Container maxWidth={false}>
        <Formik
          initialValues={{}}
          enableReinitialize
          onSubmit={(values) => {
            try {
            } catch (error) {
              console.log("error", error);
            }
          }}
        >
          {({ values, handleSubmit, handleChange, resetForm }) => {
            const handleClearFilter = async () => {
              resetForm();
            };
            return (
              <form onSubmit={handleSubmit}>
                <Box>
                  <Header />
                  {listings?.length === 0 && (
                    <Box>
                      <Typography variant="h4" color={"textPrimary"}>
                        You have no shipments yet.
                      </Typography>
                      <Typography variant="subtitle1" color={"textPrimary"}>
                        Your orders will be imported automatically when you
                        connect a channel.
                      </Typography>
                    </Box>
                  )}
                  {listings?.length > 0 && (
                    <Card>
                      <Paper className={classes.filter} variant="outlined">
                        <Box
                          justifyItems="center"
                          alignItems="center"
                          display="flex"
                        >
                          <Box width={350} p={2}>
                            <Box>
                              <Typography variant="subtitle2">
                                FILTER SHIPMENTS
                              </Typography>
                            </Box>
                            <TextField
                              name="query"
                              onChange={handleChange}
                              fullWidth
                              variant="outlined"
                              size="small"
                              placeholder="Search orders"
                              InputProps={{
                                startAdornment: (
                                  <InputAdornment position="start">
                                    <SearchIcon />
                                  </InputAdornment>
                                ),
                              }}
                              value={values.query}
                            />
                          </Box>
                          <Box width={250} p={2}>
                            <Typography variant="subtitle2">
                              Channels
                            </Typography>
                            <TextField
                              onChange={handleChange}
                              name="channelId"
                              size="small"
                              fullWidth
                              variant="outlined"
                              select
                              SelectProps={{
                                native: true,
                              }}
                              value={values.channelId}
                            >
                              <option value="">All Channels</option>
                              {listings.map((items) => (
                                <option key={items.id} value={items.id}>
                                  {items.name}
                                </option>
                              ))}
                            </TextField>
                          </Box>
                          <Box width={250} p={2}>
                            <Typography variant="subtitle2">From</Typography>
                            <TextField
                              onChange={handleChange}
                              name="minDate"
                              variant="outlined"
                              size="small"
                              fullWidth
                              type="date"
                              value={values.minDate}
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </Box>
                          <Box width={250} p={2}>
                            <Typography variant="subtitle2">To</Typography>
                            <TextField
                              onChange={handleChange}
                              name="maxDate"
                              variant="outlined"
                              size="small"
                              fullWidth
                              type="date"
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </Box>
                        </Box>
                        <Box
                          justifyItems="center"
                          alignItems="center"
                          display="flex"
                          pl={2}
                          pb={2}
                        >
                          <Box>
                            <FormControlLabel
                              control={
                                <Checkbox
                                  onChange={handleChange}
                                  name="archived"
                                />
                              }
                              label="Archived orders only"
                            />
                          </Box>
                          <Box display="flex">
                            <Box m={1}>
                              <ButtonCustom
                                size="small"
                                type="submit"
                                variant="contained"
                                color="primary"
                                text="Apply filter"
                              />
                            </Box>
                            <Box m={1}>
                              <ButtonCustom
                                notShowCircle
                                color="primary"
                                onClick={handleClearFilter}
                                text="Clear Filter"
                                size="small"
                              />
                            </Box>
                          </Box>
                        </Box>
                      </Paper>
                      <Box p={3}>
                        <Results
                          shipments={shipments}
                          warehouses={warehouses}
                          listings={listings}
                          loading={loading}
                        />
                      </Box>
                    </Card>
                  )}
                </Box>
              </form>
            );
          }}
        </Formik>
      </Container>
    </Page>
  );
}

export default ShipmentListView;
