import {
  Box,
  Button,
  Card,
  Checkbox,
  Divider,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from "@material-ui/core";
import PrintIcon from "@material-ui/icons/Print";
import clsx from "clsx";
import React, { useState } from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import Loading from "src/components/Loading/Loading";

function applyPagination(shipments, page, limit) {
  return shipments.slice(page * limit, page * limit + limit);
}

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  table: {
    width: "100%",
    "& a": {
      textDecoration: "none",
    },
    paddingBottom: theme.spacing(3),
  },
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  circle: {
    borderBottom: "none",
    padding: "2px",
  },
}));

function Results({
  className,
  shipments,
  warehouses,
  listings,
  value,
  loading,
  ...rest
}) {
  const classes = useStyles();

  const [selectedOrders, setSelectedOrders] = useState([]);
  const [page, setPage] = useState(0);
  const [limit, setLimit] = useState(10);

  const handleSelectAllOrders = (event) => {
    setSelectedOrders(
      event.target.checked ? shipments.map((shipment) => shipment.id) : []
    );
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const paginatedOrders = applyPagination(shipments, page, limit);
  const selectedSomeOrders =
    selectedOrders.length > 0 && selectedOrders.length < shipments.length;
  const selectedAllOrders = selectedOrders.length === shipments.length;

  return (
    <Box className={clsx(classes.root, className)} {...rest}>
      <Box mb={3} display="flex">
        <Box mr={1}>
          <Button variant="contained" size="small" startIcon={<PrintIcon />}>
            Create USPS SCAN Form
          </Button>
        </Box>
        <Box ml={1}>
          <Button variant="contained" size="small">
            SCAN Form History
          </Button>
        </Box>
      </Box>

      <Typography color="textSecondary" gutterBottom variant="body2">
        {shipments.length} Records found. Page{" "}
        {shipments.length <= 0 ? page : page + 1} of{" "}
        {Math.ceil(shipments.length / limit)}
      </Typography>
      <Card>
        <Divider />
        <PerfectScrollbar>
          <Box className={classes.table} display="flex">
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell align="left" size="small" padding="checkbox">
                      <Checkbox
                        checked={selectedAllOrders}
                        indeterminate={selectedSomeOrders}
                        onChange={handleSelectAllOrders}
                      />
                    </TableCell>
                    <TableCell align="left" size="small">
                      Order #
                    </TableCell>
                    <TableCell align="left" size="small">
                      Channel Order #
                    </TableCell>
                    <TableCell align="left" size="small">
                      Channel
                    </TableCell>
                    <TableCell align="left" size="small">
                      Fulfillment Order ID
                    </TableCell>
                    <TableCell align="left" size="small">
                      Shipped From
                    </TableCell>
                    <TableCell align="left" size="small">
                      Shipped To
                    </TableCell>
                    <TableCell size="small" align="left">
                      Shipped Via
                    </TableCell>
                    <TableCell size="small" align="left">
                      Ship Date
                    </TableCell>
                    <TableCell size="small" align="left">
                      Carrier
                    </TableCell>
                    <TableCell size="small" align="left">
                      Tracking Number
                    </TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {paginatedOrders.map((shipment) => {
                    return (
                      <TableRow
                        key={shipment.id}
                        selected={selectedOrders.indexOf(shipment.id) !== -1}
                      >
                        <TableCell size="small"></TableCell>

                        {/* Order # */}
                        <TableCell className={classes.tableCell} size="small">
                          {shipment?.order_id}
                        </TableCell>

                        {/* Channel Order # */}
                        <TableCell className={classes.tableCell} size="small">
                          {shipment?.channel_order_number}
                        </TableCell>

                        {/*  Channel */}
                        <TableCell className={classes.tableCell} size="small">
                          {
                            /* eslint eqeqeq: 0 */
                            listings.filter(
                              (listing) => listing.id == shipment?.channel_id
                            )?.[0]?.name
                          }
                        </TableCell>

                        {/* Fulfillment Order ID */}
                        <TableCell className={classes.tableCell} size="small">
                          {shipment?.fulfillment_id}
                        </TableCell>

                        {/* Shipped From */}
                        <TableCell className={classes.tableCell} size="small">
                          {
                            warehouses.filter(
                              (warehouse) =>
                                warehouse.id == shipment.location_id
                            )?.[0]?.name
                          }
                        </TableCell>

                        {/* Shipped To */}
                        <TableCell
                          className={classes.tableCell}
                          size="small"
                          align="right"
                        ></TableCell>

                        {/* Shipped Via */}
                        <TableCell
                          className={classes.tableCell}
                          size="small"
                        ></TableCell>

                        {/* Ship Date */}
                        <TableCell
                          className={classes.tableCell}
                          size="small"
                        ></TableCell>

                        {/* Carrier */}
                        <TableCell className={classes.tableCell} size="small">
                          {shipment?.carrier}
                        </TableCell>

                        {/* Tracking Number */}
                        <TableCell className={classes.tableCell} size="small">
                          {shipment?.tracking_number}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
                {loading && (
                  <TableBody>
                    <TableRow>
                      <TableCell className={classes.circle}>
                        <Box p={2}>
                          <Loading />
                        </Box>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                )}
              </Table>
            </TableContainer>
          </Box>
        </PerfectScrollbar>
        <TablePagination
          component="div"
          count={shipments.length}
          onChangePage={handlePageChange}
          onChangeRowsPerPage={handleLimitChange}
          page={page}
          rowsPerPage={limit}
          rowsPerPageOptions={[5, 10, 25]}
        />
      </Card>
    </Box>
  );
}

export default Results;
