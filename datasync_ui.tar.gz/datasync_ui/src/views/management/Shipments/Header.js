import {
  Button,
  Grid,
  makeStyles,
  // Link,
  SvgIcon,
  Typography,
} from "@material-ui/core";
import LocalShippingIcon from "@material-ui/icons/LocalShipping";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import clsx from "clsx";
// import { Link as RouterLink } from "react-router-dom";
import PropTypes from "prop-types";
import React from "react";
import { useHistory } from "react-router";
// import NavigateNextIcon from "@material-ui/icons/NavigateNext";

const useStyles = makeStyles((theme) => ({
  root: {
    marginBottom: theme.spacing(1),
  },
  action: {
    marginBottom: theme.spacing(1),
    "& + &": {
      marginLeft: theme.spacing(1),
    },
  },
  actionIcon: {
    marginRight: theme.spacing(1),
  },
}));

function Header({ className, ...rest }) {
  const classes = useStyles();
  const history = useHistory();

  const handleClickOrders = () => {
    return history.push("/orders");
  };

  return (
    <Grid
      container
      spacing={3}
      justify="space-between"
      className={clsx(classes.root, className)}
      {...rest}
    >
      <Grid item>
        <Typography variant="h3" color="textPrimary">
          <SvgIcon fontSize="small" className={classes.actionIcon}>
            <LocalShippingIcon />
          </SvgIcon>
          Shipments
        </Typography>
      </Grid>
      <Grid item>
        <Button
          size="small"
          color="secondary"
          variant="contained"
          className={classes.action}
          onClick={handleClickOrders}
        >
          <SvgIcon fontSize="small" className={classes.actionIcon}>
            <ShoppingCartIcon />
          </SvgIcon>
          Manage Orders
        </Button>
      </Grid>
    </Grid>
  );
}

Header.propTypes = {
  className: PropTypes.string,
};

export default Header;
