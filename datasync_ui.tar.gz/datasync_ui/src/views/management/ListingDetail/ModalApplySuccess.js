import React, { useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  FormControlLabel,
  Typography
} from "@material-ui/core";
import DialogTitle from "src/components/Modal/DialogTitle";

export const LOCAL_PATH_SHOW_MODAL = "show_apply_modal";

const ModalApplySuccess = ({ open, setOpen = function() {} }) => {
  const [check, setCheck] = useState(false);
  const [hide, setHide] = useState(false);

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = () => {
    setCheck(!check);
    localStorage.setItem(LOCAL_PATH_SHOW_MODAL, "true");
    setHide(true);
  };

  return (
    <Dialog open={open && !hide} onClose={handleClose} transitionDuration={300}>
      <DialogTitle>Apply Success</DialogTitle>
      <DialogContent dividers>
        <Typography variant="body2" color="textPrimary">
          Applying a template/recipe will only update information on
          LitCommerce. Please click to 'Update to channel' to update the
          adjustments to listings on your store.
        </Typography>
      </DialogContent>
      <DialogActions>
        <Box display={"flex"} alignItems={"center"} width="100%">
          <Box flexGrow={1}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={check}
                  onChange={handleChange}
                  name="checkedB"
                  color="primary"
                />
              }
              label={
                <Typography variant="caption">Do not show again</Typography>
              }
            />
          </Box>
          <Button size="small" onClick={handleClose}>
            Cancel
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default ModalApplySuccess;
