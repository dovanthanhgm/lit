import React, { useContext } from "react";
import DetailListingFilter from "src/views/management/ListingDetail/FilterListing/DetailListingFilter";
import { useSelector } from "react-redux";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";

const FilterListing = () => {
  const { currentTab } = useSelector(state => state.listing.listingDetail);
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);

  return (
    <DetailListingFilter
      channelID={channelDetail.channelID}
      currentTab={currentTab}
      channelType={channelDetail.channelType}
    />
  );
};

export default FilterListing;
