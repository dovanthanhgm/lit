import React from "react";
import EbayTableRow from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Ebay/index";
import { TableBody } from "@material-ui/core";
import TableSkeleton from "src/components/Skeleton/Table";

const EbayChannelData = ({ newProducts }) => {
  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <EbayTableRow
              item={item}
              key={item?.publish_id || item?.id}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

export default EbayChannelData;
