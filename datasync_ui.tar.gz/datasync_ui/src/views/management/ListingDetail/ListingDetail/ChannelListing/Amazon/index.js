import React, { useContext } from "react";
import {
  Box,
  makeStyles,
  TableCell,
  TableRow,
  Typography
} from "@material-ui/core";
import ListingTableStatus from "src/views/management/ListingDetail/ListingDetail/TableStatus";
import ListingTableProductName from "src/views/management/ListingDetail/ListingDetail/TableProductName";
import TableLinkIcon from "src/views/management/ListingDetail/ListingDetail/TableLink";
import TableListingImage from "src/views/management/ListingDetail/ListingDetail/TableListingImage";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import CheckBoxProduct from "src/views/management/ListingDetail/ListingDetail/TableRowComponents/CheckBoxProduct";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import CellsAmazon from "src/views/management/ListingDetail/ListingDetail/TableRowComponents/CellsAmazon";
import RowTemplate from "src/views/management/ListingDetail/ListingDetail/TableRowComponents/RowTemplate";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";

const useStyles = makeStyles(theme => ({
  tablePaddingCustom: {
    paddingLeft: "13px !important"
  },
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const AmazonTableRow = ({ item, rowNumber }) => {
  const { channelID } = useContext(ListingDetailChannelDetailContext);
  // const { objectTableHeader } = useContext(ListingDetailTableContext);
  const { tableHeader } = useContext(ListingDetailTableContext);

  const styleGlobal = channelColumnConfig.globalConfig;
  const styleChannel = columnName =>
    channelColumnConfig?.amazon?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  const classes = useStyles();

  const isNotVariant = !item?.parentIdEdit;

  if (!Object.keys(tableHeader).length) {
    return null;
  }

  return (
    <TableRow>
      <TableCell padding="checkbox" className={classes.tablePaddingCustom}>
        <CheckBoxProduct isNotVariant={isNotVariant} item={item} rowNumber={rowNumber}/>
      </TableCell>
      <TableCell
        width={styleGlobal.image.width}
        style={{ maxWidth: styleGlobal.image.maxWidth }}
        align={styleGlobal.image.align}
      >
        {isNotVariant && (
          <TableListingImage
            className={classes.productImage}
            src={item.thumb_image?.url}
            paddingImageFail={3}
          />
        )}
        {!isNotVariant && <Box style={{ height: 48 }} />}
      </TableCell>
      <TableCell
        style={{
          maxWidth: styleGlobal.linkIcon.maxWidth,
          width: styleGlobal.linkIcon.width
        }}
        align={styleGlobal.linkIcon.align}
      >
        <TableLinkIcon item={item} isNotVariant={isNotVariant} />
      </TableCell>
      <TableCell style={{ width: styleGlobal.status.width }}>
        <ListingTableStatus channelType={"amazon"} item={item} />
      </TableCell>
      {tableHeader.title.isShow && (
        <TableCell
          width={styleChannel("name").width}
          style={{
            maxWidth: styleChannel("name").maxWidth,
            minWidth: styleChannel("name").minWidth
          }}
          align={styleChannel("name").align}
        >
          <ListingTableProductName item={item} isNotVariant={isNotVariant} />
        </TableCell>
      )}
      {tableHeader.sku.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("sku").minWidth,
            maxWidth: styleChannel("sku").maxWidth
          }}
          align={styleChannel("sku").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            // <CustomTooltip title={item.sku} placement="bottom-start">
            <Box width="100%">
              <Typography className={classes.name} variant="body2">
                {item.sku}
              </Typography>
            </Box>
            // </CustomTooltip>
          )}
        </TableCell>
      )}
      {tableHeader.quantity.isShow && (
        <TableCell
          width={styleChannel("qty").width}
          style={{ maxWidth: styleChannel("qty").maxWidth }}
          align={styleChannel("qty").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.qty}
          </Typography>
        </TableCell>
      )}
      {tableHeader.price.isShow && (
        <TableCell
          width={styleChannel("price")}
          style={{ maxWidth: styleChannel("price").maxWidth }}
          align={styleChannel("price").align}
        >
          <Typography variant="body2">
            {item.lastItem ? (
              ""
            ) : (
              <Typography variant="body2" component="span">
                {item.price}
              </Typography>
            )}
          </Typography>
        </TableCell>
      )}
      <CellsAmazon item={item} styleChannel={styleChannel} />
      <RowTemplate
        item={item}
        channelID={channelID}
        styleChannel={styleChannel}
      />
    </TableRow>
  );
};

export default AmazonTableRow;
