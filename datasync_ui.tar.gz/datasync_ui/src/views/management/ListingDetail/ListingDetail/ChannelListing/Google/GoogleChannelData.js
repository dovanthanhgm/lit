import React from "react";
import TableSkeleton from "src/components/Skeleton/Table";
import { TableBody } from "@material-ui/core";
import GoogleTableRow from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Google/index";

const GoogleChannelData = ({ newProducts }) => {
  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <GoogleTableRow
              item={item}
              key={item?.publish_id || item?.id}
              channelType={"google"}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

export default GoogleChannelData;
