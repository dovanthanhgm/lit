import React, { useContext } from "react";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import { get } from "lodash";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { TableCell, Tooltip, Typography } from "@material-ui/core";

const Walmart3Pl = ({ item, listShipping = [] }) => {
  const { tableHeader } = useContext(ListingDetailTableContext);

  const initValue = get(item, tableHeader.walmart_3pl.value);

  const styleChannel = columnName =>
    channelColumnConfig?.walmart?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  const matchCenter = listShipping.find(item => item?.shipNode === initValue)
    ?.shipNodeName;

  return (
    <TableCell
      style={{
        minWidth: styleChannel("walmart_3pl").minWidth,
        maxWidth: styleChannel("walmart_3pl").maxWidth
      }}
      align={styleChannel("walmart_3pl").align}
    >
      <Tooltip title={matchCenter || ""}>
        <Typography
          variant="body2"
          style={{
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {matchCenter || ""}
        </Typography>
      </Tooltip>
    </TableCell>
  );
};

export default Walmart3Pl;
