import React, { useContext } from "react";
import useEtsySection from "src/views/management/ListingEditProduct/Hooks/Channel/Etsy/useEtsySection";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import TableSkeleton from "src/components/Skeleton/Table";
import { TableBody } from "@material-ui/core";
import EtsyTableRow from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Etsy/index";
import useShippingProfile from "src/views/management/ListingEditProduct/Hooks/Channel/Etsy/useShippingProfile";

const EtsyChannelData = ({ newProducts }) => {
  const { channelID } = useContext(ListingDetailChannelDetailContext);

  const { section } = useEtsySection({
    channelID
  });

  const { dataShipping, dataReturn } = useShippingProfile({
    channelID,
    channelType: "etsy"
  });

  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <EtsyTableRow
              item={item}
              key={item?.publish_id || item?.id}
              channelType={"etsy"}
              section={section}
              shippingData={dataShipping}
              dataReturn={dataReturn}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

export default EtsyChannelData;
