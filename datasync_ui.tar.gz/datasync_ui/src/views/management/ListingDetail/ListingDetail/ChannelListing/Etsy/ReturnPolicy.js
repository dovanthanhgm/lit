import React, { useContext } from "react";
import { TableCell, Tooltip, Typography } from "@material-ui/core";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { get } from "lodash";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";

const EtsyPolicy = ({ item, dataReturn = [] }) => {
  const { tableHeader } = useContext(ListingDetailTableContext);

  const initValue = get(item, tableHeader.return_policy.value);

  const styleChannel = columnName =>
    channelColumnConfig?.etsy?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  const policyTitle = dataReturn.find(item => item?.policy_id === initValue)
    ?.title;

  return (
    <TableCell
      style={{
        minWidth: styleChannel("category").minWidth,
        maxWidth: styleChannel("category").maxWidth
      }}
      align={styleChannel("category").align}
    >
      <Tooltip title={policyTitle || ""}>
        <Typography
          variant="body2"
          style={{
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {policyTitle || ""}
        </Typography>
      </Tooltip>
    </TableCell>
  );
};

export default EtsyPolicy;
