import React, { useContext } from "react";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import { get } from "lodash";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { TableCell, Tooltip, Typography } from "@material-ui/core";

const EtsyShipping = ({ item, shippingData = [] }) => {
  const { tableHeader } = useContext(ListingDetailTableContext);

  const initValue = get(item, tableHeader.shipping_profile.value);

  const styleChannel = columnName =>
    channelColumnConfig?.etsy?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  const shippingTitle = shippingData.find(
    shipping => shipping?.shipping_template_id === initValue
  )?.title;

  return (
    <TableCell
      style={{
        minWidth: styleChannel("shipping").minWidth,
        maxWidth: styleChannel("shipping").maxWidth
      }}
      align={styleChannel("shipping").align}
    >
      <Tooltip title={shippingTitle || ""}>
        <Typography
          variant="body2"
          style={{
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {shippingTitle || ""}
        </Typography>
      </Tooltip>
    </TableCell>
  );
};

export default EtsyShipping;
