import React from "react";
import { TableBody } from "@material-ui/core";
import TableSkeleton from "src/components/Skeleton/Table";
import ReverbTableRow from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Reverb/index";

const ReverbChannelData = ({ newProducts }) => {
  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <ReverbTableRow
              item={item}
              key={item?.publish_id || item?.id}
              channelType={"reverb"}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

export default ReverbChannelData;
