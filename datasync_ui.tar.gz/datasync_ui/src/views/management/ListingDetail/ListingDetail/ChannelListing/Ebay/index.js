import React, { useContext } from "react";
import {
  Box,
  makeStyles,
  TableCell,
  TableRow,
  Typography
} from "@material-ui/core";
import CheckBoxProduct from "src/views/management/ListingDetail/ListingDetail/TableRowComponents/CheckBoxProduct";
import TableListingImage from "src/views/management/ListingDetail/ListingDetail/TableListingImage";
import TableLinkIcon from "src/views/management/ListingDetail/ListingDetail/TableLink";
import ListingTableStatus from "src/views/management/ListingDetail/ListingDetail/TableStatus";
import ListingTableProductName from "src/views/management/ListingDetail/ListingDetail/TableProductName";
import RowTemplate from "src/views/management/ListingDetail/ListingDetail/TableRowComponents/RowTemplate";
import PreviewButtonListingDetail from "src/views/management/ListingDetail/ListingDetail/TableRowComponents/PreviewButton";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { salePriceListingTable } from "src/utils/Listing/salePrice";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import EbayCategory from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Ebay/Category";
import EbayStoreCategory from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Ebay/StoreCategory";
import EbayListingFormat from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Ebay/ListingFormat";

const useStyles = makeStyles(theme => ({
  tablePaddingCustom: {
    paddingLeft: "13px !important"
  },
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const EbayTableRow = ({ item, rowNumber }) => {
  const classes = useStyles();
  const { fetchDataLoading } = useContext(ListingProductDialogContext);
  const { channelID } = useContext(ListingDetailChannelDetailContext);

  const { tableHeader } = useContext(ListingDetailTableContext);
  const styleGlobal = channelColumnConfig.globalConfig;
  const isNotVariant = !item?.parentIdEdit;

  const styleChannel = columnName =>
    channelColumnConfig?.ebay?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  const handleShowSalePrice = () => {
    if (fetchDataLoading) return "";
    return salePriceListingTable(
      item,
      { price: item.parentPrice },
      !item.isVariant
    )
      ? item?.special_price?.price ?? ""
      : "";
  };

  const checkIsBusiness =
    !!item?.template_data?.business?.fulfillment_policy
      ?.fulfillment_policy_id &&
    !!item?.template_data?.business?.payment_policy?.payment_policy_id &&
    !!item?.template_data?.business?.return_policy?.return_policy_id;

  const hideCondition = (templates = {}) => (templateType) => {
    const isBusinessTemplate = templates?.business;
    return (
      !!(
        isBusinessTemplate && ["payment", "shipping"].includes(templateType)
      ) ||
      (checkIsBusiness && ["payment", "shipping"].includes(templateType))
    );
  };

  if (!Object.keys(tableHeader).length) {
    return null;
  }

  return (
    <TableRow>
      <TableCell padding="checkbox" className={classes.tablePaddingCustom}>
        <CheckBoxProduct isNotVariant={isNotVariant} item={item} rowNumber={rowNumber}/>
      </TableCell>
      <TableCell
        width={styleGlobal.image.width}
        style={{ maxWidth: styleGlobal.image.maxWidth }}
        align={styleGlobal.image.align}
      >
        {isNotVariant && (
          <TableListingImage
            className={classes.productImage}
            src={item.thumb_image?.url}
            paddingImageFail={3}
          />
        )}
        {!isNotVariant && <Box style={{ height: 48 }} />}
      </TableCell>
      <TableCell
        style={{
          maxWidth: styleGlobal.linkIcon.maxWidth,
          width: styleGlobal.linkIcon.width
        }}
        align={styleGlobal.linkIcon.align}
      >
        <TableLinkIcon item={item} isNotVariant={isNotVariant} />
      </TableCell>
      <TableCell style={{ width: styleGlobal.status.width }}>
        <ListingTableStatus channelType={"ebay"} item={item} />
      </TableCell>
      {tableHeader.title.isShow && (
        <TableCell
          width={styleChannel("name").width}
          style={{
            maxWidth: styleChannel("name").maxWidth,
            minWidth: styleChannel("name").minWidth
          }}
          align={styleChannel("name").align}
        >
          <ListingTableProductName item={item} isNotVariant={isNotVariant} />
        </TableCell>
      )}
      {tableHeader.sku.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("sku").minWidth,
            maxWidth: styleChannel("sku").maxWidth
          }}
          align={styleChannel("sku").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            // <CustomTooltip title={item.sku} placement="bottom-start">
            <Box width="100%">
              <Typography className={classes.name} variant="body2">
                {item.sku}
              </Typography>
            </Box>
            // </CustomTooltip>
          )}
        </TableCell>
      )}

      {tableHeader.quantity.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("qty").minWidth,
            maxWidth: styleChannel("qty").maxWidth
          }}
          align={styleChannel("qty").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.qty}
          </Typography>
        </TableCell>
      )}
      {tableHeader.price.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("price").minWidth,
            maxWidth: styleChannel("price").maxWidth
          }}
          align={styleChannel("price").align}
        >
          <Typography variant="body2">
            {item.lastItem ? (
              ""
            ) : (
              <Typography variant="body2" component="span">
                {item.price}
              </Typography>
            )}
          </Typography>
        </TableCell>
      )}
      {tableHeader.sale_price.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("salePrice").minWidth,
            maxWidth: styleChannel("salePrice").maxWidth
          }}
          align={styleChannel("salePrice").align}
        >
          <Typography variant="body2">
            {item.lastItem ? (
              ""
            ) : (
              <Typography variant="body2" component={"span"}>
                {handleShowSalePrice()}
              </Typography>
            )}
          </Typography>
        </TableCell>
      )}
      {tableHeader.ePID.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("ePID").minWidth,
            maxWidth: styleChannel("ePID").maxWidth
          }}
          align={styleChannel("ePID").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.epid}
          </Typography>
        </TableCell>
      )}
      {tableHeader.upc.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("upc").minWidth,
            maxWidth: styleChannel("upc").maxWidth
          }}
          align={styleChannel("upc").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.upc}
          </Typography>
        </TableCell>
      )}
      {tableHeader.ean.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("ean").minWidth,
            maxWidth: styleChannel("ean").maxWidth
          }}
          align={styleChannel("ean").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.ean}
          </Typography>
        </TableCell>
      )}
      {tableHeader.mpn.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("mpn").minWidth,
            maxWidth: styleChannel("mpn").maxWidth
          }}
          align={styleChannel("mpn").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.mpn}
          </Typography>
        </TableCell>
      )}

      {tableHeader.ispn.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("ispn").minWidth,
            maxWidth: styleChannel("ispn").maxWidth
          }}
          align={styleChannel("ispn").align}
        >
          <Typography variant="body2">
            {item.lastItem ? "" : item.ispn}
          </Typography>
        </TableCell>
      )}
      {tableHeader.brand.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("brand").minWidth,
            maxWidth: styleChannel("brand").maxWidth
          }}
          align={styleChannel("brand").align}
        >
          <Typography variant="body2" style={{ whiteSpace: "nowrap" }}>
            {item.lastItem ? "" : item.brand}
          </Typography>
        </TableCell>
      )}

      {tableHeader.category.isShow && <EbayCategory item={item} />}
      {tableHeader.store_category_1.isShow && <EbayStoreCategory item={item} />}
      {tableHeader.store_category_2.isShow && (
        <EbayStoreCategory isStore2 item={item} />
      )}
      {tableHeader.listing_format.isShow && <EbayListingFormat item={item} />}
      <RowTemplate
        item={item}
        channelID={channelID}
        styleChannel={styleChannel}
        hideCondition={hideCondition(item.templates)}
      />
      <PreviewButtonListingDetail
        channelType={"ebay"}
        product={item}
        styleGlobal={styleGlobal}
        channelID={channelID}
      />
    </TableRow>
  );
};

export default EbayTableRow;
