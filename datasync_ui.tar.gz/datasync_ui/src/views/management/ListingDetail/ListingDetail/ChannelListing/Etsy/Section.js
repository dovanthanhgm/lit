import React, { useContext } from "react";
import { TableCell, Tooltip, Typography } from "@material-ui/core";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { get } from "lodash";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";

const EtsySection = ({ item, section }) => {
  const { tableHeader } = useContext(ListingDetailTableContext);

  const initValue = get(item, tableHeader.section.value);

  const styleChannel = columnName =>
    channelColumnConfig?.etsy?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };
  // eslint-disable-next-line
  const sectionItem = section.find(sec => sec?.shop_section_id == initValue)
    ?.title;

  return (
    <TableCell
      style={{
        minWidth: styleChannel("section").minWidth,
        maxWidth: styleChannel("section").maxWidth
      }}
      align={styleChannel("section").align}
    >
      <Tooltip title={sectionItem || ""}>
        <Typography
          variant="body2"
          style={{
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {sectionItem || ""}
        </Typography>
      </Tooltip>
    </TableCell>
  );
};

export default EtsySection;
