import React, { useContext } from "react";
import { TableCell, Tooltip, Typography } from "@material-ui/core";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { get } from "lodash";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";

const EbayStoreCategory = ({ item, isStore2 = false }) => {
  const { tableHeader } = useContext(ListingDetailTableContext);

  const initValue = get(
    item,
    tableHeader?.[isStore2 ? "store_category_2" : "store_category_1"].value
  );

  const styleChannel = columnName =>
    channelColumnConfig?.ebay?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  return (
    <TableCell
      style={{
        minWidth: styleChannel("category").minWidth,
        maxWidth: styleChannel("category").maxWidth
      }}
      align={styleChannel("category").align}
    >
      <Tooltip title={initValue}>
        <Typography
          variant="body2"
          style={{
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {initValue}
        </Typography>
      </Tooltip>
    </TableCell>
  );
};

export default EbayStoreCategory;
