import React, { useContext } from "react";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import { get } from "lodash";
import { channelColumnConfig } from "src/constants/Listing/ListingDetail/ListingDetailChannel";
import { TableCell, Tooltip, Typography } from "@material-ui/core";
import { condition } from "src/constants/template";

const AmazonCondition = ({ item }) => {
  const { tableHeader } = useContext(ListingDetailTableContext);

  const initValue = get(item, tableHeader.condition.value);

  const styleChannel = columnName =>
    channelColumnConfig?.amazon?.[columnName] || {
      width: "auto",
      minWidth: 100,
      maxWidth: 100,
      align: "left"
    };

  const matchAmazonCondition = condition.find(item => item.value === initValue)
    ?.name;

  return (
    <TableCell
      style={{
        minWidth: styleChannel("condition").minWidth,
        maxWidth: styleChannel("condition").maxWidth
      }}
      align={styleChannel("condition").align}
    >
      <Tooltip title={initValue}>
        <Typography
          variant="body2"
          style={{
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {matchAmazonCondition || ""}
        </Typography>
      </Tooltip>
    </TableCell>
  );
};

export default AmazonCondition;
