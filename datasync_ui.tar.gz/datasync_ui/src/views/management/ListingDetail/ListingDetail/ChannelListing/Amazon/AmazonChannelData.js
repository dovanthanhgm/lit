import React from "react";
import { TableBody } from "@material-ui/core";
import TableSkeleton from "src/components/Skeleton/Table";
import AmazonTableRow from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Amazon/index";

const AmazonChannelData = ({ newProducts }) => {
  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <AmazonTableRow
              item={item}
              key={item?.publish_id || item?.id}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

export default AmazonChannelData;
