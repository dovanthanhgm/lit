import React, { useContext } from "react";
import useWalmartShippingProfile from "src/views/management/ListingEditProduct/Hooks/Channel/Walmart/useWalmartShippingProfile";
import { TableBody } from "@material-ui/core";
import TableSkeleton from "src/components/Skeleton/Table";
import WalmartTableRow from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Walmart/index";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";

const WalmartChannelData = ({ newProducts }) => {
  const { channelID } = useContext(ListingDetailChannelDetailContext);

  const { listShipping } = useWalmartShippingProfile({ channelID });

  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <WalmartTableRow
              item={item}
              key={item?.publish_id || item?.id}
              listShipping={listShipping}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

export default WalmartChannelData;
