import React, { useContext } from "react";
import IconLink from "src/views/management/ListingDetail/IconLink";
import { getProductVariantListing } from "src/services/products";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";
// import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";

const TableLinkIcon2 = ({ item, isNotVariant, isGrid }) => {
  const { setVariants } = useContext(ListingProductDialogContext);
  const { channelID, channelType } = useContext(
    ListingDetailChannelDetailContext
  );
  const { handleChangeStatus } = useContext(
    ListingDetailTableSelectedProductContext
  );
  // const { recallProduct } = useContext(ListingDetailProductsContext);
  const { recallCount } = useContext(ListingDetailCountContext);

  const handleVariantLink = () => {
    const productId = item.publish_id;
    setVariants(prev => {
      delete prev?.[productId];
      return prev;
    });
  };

  const getVariant = async data => {
    const productId = item?.parent_id ? item.parent_id : item?.publish_id;
    const parentLinked = item.parentLinked;
    const resVariations = await getProductVariantListing({
      channel_id: channelID,
      productId: productId
    });
    if (resVariations) {
      setVariants(items => ({
        ...items,
        [productId]: {
          ...items[productId],
          data: resVariations.data.map(itemSmall => ({
            ...itemSmall,
            parentIdEdit: item.currentTab === "active" ? data.id : productId,
            parentName: data.name || data.parentName,
            parentLinked
          }))
        }
      }));
    }
  };

  return (
    <IconLink
      item={item}
      idName="publish_id"
      currentTab={item?.channel_status}
      isNotVariant={isNotVariant}
      channelID={channelID}
      channelType={channelType}
      handleChangeStatus={handleChangeStatus}
      getDataDetail={() => {
        recallCount();
      }}
      getVariant={isNotVariant ? handleVariantLink : getVariant}
      parentLinkStatus={item?.parentLinked}
      isGrid={isGrid}
    />
  );
};

const TableLinkIcon = props => {
  if (props.item.lastItem) return "";
  return <TableLinkIcon2 {...props} />;
};

export default TableLinkIcon;
