import React from "react";
import { showIcon } from "src/views/management/ListingDetail/ListingFunction";
import { useSelector } from "react-redux";
import {
  handleIconListingDetailStatus,
  handleListingDetailIconMessage
} from "src/helper/ListingDetalIconHandle";

const ListingTableStatus = ({ item, channelType }) => {
  const defaultListing = useSelector(state => state?.listing?.defaultListing);

  const handleShowIcon = () => {
    if (item?.lastItem) {
      return "";
    }

    return showIcon({
      channelType,
      statusCode: handleIconListingDetailStatus(item, channelType),
      tooltipMessage: handleListingDetailIconMessage(item, channelType),
      defaultChannelType: defaultListing.type
    });
  };

  return <>{handleShowIcon()}</>;
};

export default ListingTableStatus;
