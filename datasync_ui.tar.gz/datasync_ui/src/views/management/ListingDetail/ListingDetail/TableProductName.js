import React, { useContext } from "react";
import { Box, makeStyles, Tooltip, Typography } from "@material-ui/core";
import {
  ControlPoint as ControlPointIcon,
  RemoveCircleOutline as RemoveCircleOutlineIcon,
  SubdirectoryArrowRight as SubdirectoryArrowRightIcon
} from "@material-ui/icons";
import Link from "src/components/MUI/Link";
import { changeProductListingTab } from "src/actions/listingActions";
import { getProductVariantListing } from "src/services/products";
import { useDispatch } from "react-redux";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import { withStyles } from "@material-ui/styles";

const useStyles = makeStyles(() => ({
  titleTemplate2: {
    overflow: "hidden",
    width: "100%",
    textOverflow: "ellipsis",
    display: "inline-block"
  },
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const CustomTooltip = withStyles(theme => ({
  tooltip: {
    fontSize: 12,
    maxWidth: 350
  }
}))(Tooltip);

const ListingTableProductName = ({ item, isNotVariant }) => {
  const { variants, setVariants, setDialogProduct, setOpenDialog } = useContext(
    ListingProductDialogContext
  );
  const { channelID } = useContext(ListingDetailChannelDetailContext);
  const classes = useStyles();
  const dispatch = useDispatch();
  const hasAddedVariant = variants?.[item?.publish_id]?.removed === false;

  const hideVariant = () => {
    const id = item?.publish_id;
    setVariants(items => ({
      ...items,
      [id]: { ...items[id], removed: true }
    }));
  };

  const showVariant = async () => {
    const id = item?.publish_id;
    if (variants[id]) {
      setVariants(items => ({
        ...items,
        [id]: { ...items[id], removed: false }
      }));
      return;
    }

    const resVariations = await getProductVariantListing({
      channel_id: channelID,
      productId: id
    });

    const getVariantOption = (variant = { link_variant_options: [] }) => {
      return variant?.link_variant_options?.length > 0 &&
        variant?.link_variant_options
        ? variant?.link_variant_options
        : item?.link_variant_options || [];
    };

    setVariants(items => ({
      ...items,
      [id]: {
        data: resVariations.data.map(itemSmall => ({
          ...itemSmall,
          parentIdEdit:
            item.currentTab === "active" ? item?.id : item?.publish_id,
          parentVariantOption: getVariantOption(itemSmall),
          parentName: item?.name,
          parentLinked: item?.link_status
        })),
        removed: false
      }
    }));
  };

  return (
    <Box display="flex" alignItems="center" width="auto">
      {item?.variant_count > 0 && (
        <Box mr={1}>
          {hasAddedVariant && (
            <RemoveCircleOutlineIcon
              fontSize="small"
              style={{ cursor: "pointer" }}
              onClick={hideVariant}
            />
          )}

          {!hasAddedVariant && (
            <ControlPointIcon
              fontSize="small"
              style={{ cursor: "pointer" }}
              onClick={showVariant}
            />
          )}
        </Box>
      )}

      {!isNotVariant && !item?.lastItem && (
        <Box ml={2}>
          <SubdirectoryArrowRightIcon size="small" />
        </Box>
      )}
      {!item?.lastItem && (
        <Link
          color="primary"
          onClick={() => {
            window.history.replaceState(
              null,
              null,
              `/listing/${channelID}/${item?.publish_id}`
            );
            setOpenDialog(true);
            setDialogProduct(item);
          }}
          className={classes.titleTemplate}
          style={{ overflow: "hidden" }}
        >
          <CustomTooltip
            title={item?.name || item?.parentName}
            placement="bottom-start"
          >
            <Typography variant="body2" className={classes.name}>
              {item?.name || item?.parentName}
            </Typography>
          </CustomTooltip>
        </Link>
      )}
      {item?.lastItem && (
        <>
          <Box ml={5} />
          <Link
            color="primary"
            to={`/listing/${channelID}/${item?.parent_id}`}
            className={classes.titleTemplate}
            style={{ overflow: "hidden" }}
          >
            <Typography
              variant="body2"
              className={classes.name}
              onClick={() => dispatch(changeProductListingTab("price"))}
            >
              more...
            </Typography>
          </Link>
        </>
      )}
    </Box>
  );
};

export default ListingTableProductName;
