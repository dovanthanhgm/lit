import React, { useState } from "react";
import clsx from "clsx";
import { makeStyles, Box, SvgIcon, Tooltip } from "@material-ui/core";
import { Image as ImageIcon } from "react-feather";
import LazyLoad from "react-lazy-load";

const useStyles = makeStyles(theme => ({
  root: {
    height: 48,
    width: 48,
    overflow: "hidden",
    border: "1px solid #b5b2b1",
    borderRadius: 4,
    padding: 2
  },
  img: {
    objectFit: "contain",
    borderRadius: 4,
    backgroundImage: "white",
    maxWidth: "100%",
    maxHeight: "100%"
  }
}));

export default function TableListingImage({
  src,
  className,
  bgcolor = "dark"
}) {
  const [isImgError, setIsImgError] = useState(false);
  const classes = useStyles();
  const onImageError = () => {
    setIsImgError(true);
  };
  const WrapComponent = isImgError ? Tooltip : React.Fragment;
  const propsWrapComponent = isImgError
    ? {
        title:
          "Unable to load image. Please click on the product details to reload the images.",
        placement: "top",
        arrow: true
      }
    : {};

  return (
    <WrapComponent {...propsWrapComponent}>
      <Box
        className={clsx(classes.root, className)}
        display="flex"
        alignItems="center"
        justifyContent="center"
        bgcolor={`background.${bgcolor}`}
        style={isImgError ? { backgroundColor: "#fff" } : {}}
      >
        {src && (
          <LazyLoad height={48} width={48} style={{ display: "flex" }}>
            <img
              src={isImgError ? "/static/images/image_not_found.png" : src}
              className={classes.img}
              alt=" "
              referrerPolicy="no-referrer"
              height={48}
              width={48}
              onError={onImageError}
            />
          </LazyLoad>
        )}

        {!src && (
          <SvgIcon>
            <ImageIcon />
          </SvgIcon>
        )}
      </Box>
    </WrapComponent>
  );
}
