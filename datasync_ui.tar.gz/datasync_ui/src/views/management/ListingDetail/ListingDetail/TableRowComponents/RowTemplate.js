import { Box, makeStyles, TableCell, Typography } from "@material-ui/core";
import React, { useContext } from "react";
import Link from "src/components/MUI/Link";
import { editRoute } from "src/hooks/Template/useTemplateRoute";
import { TableContext } from "../../TableListing/Table";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";

const useStyles = makeStyles(() => ({
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const RowTemplate = ({
  item,
  channelID,
  styleChannel,
  hideCondition = () => false
}) => {
  const classes = useStyles();
  const { arrayKeyTemplatesTitle, listTemplatesObject } = useContext(
    TableContext
  );
  const { tableHeaderTemplate } = useContext(ListingDetailTableContext);

  return (
    <>
      {arrayKeyTemplatesTitle.map(keyTemplate => {
        const itemKeyTemplate = item.templates?.[keyTemplate];
        const arrayTemplate =
          listTemplatesObject[keyTemplate]?.[itemKeyTemplate];

        if (!tableHeaderTemplate?.[keyTemplate]?.isShow) {
          return null;
        }
        return (
          <TableCell
            key={keyTemplate}
            style={{
              minWidth: styleChannel("template").minWidth
            }}
            align={styleChannel("template").align}
          >
            {item.lastItem || !arrayTemplate || hideCondition(keyTemplate) ? (
              ""
            ) : (
              <Box display="flex" alignItems="center" width="100%">
                <Link
                  to={editRoute({
                    templateType: keyTemplate,
                    template_id: arrayTemplate?.id,
                    channelId: channelID
                  })}
                  className={classes.name}
                >
                  <Typography variant="body2" className={classes.name}>
                    {arrayTemplate?.name || ""}
                  </Typography>
                </Link>
              </Box>
            )}
          </TableCell>
        );
      })}
    </>
  );
};

export default RowTemplate;
