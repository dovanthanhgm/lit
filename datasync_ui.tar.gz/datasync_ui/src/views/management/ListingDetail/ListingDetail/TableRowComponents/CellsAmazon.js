import {
  Box,
  Link as MuiLInk,
  makeStyles,
  TableCell,
  Typography
} from "@material-ui/core";
import React, { useContext } from "react";
import { fulfilledItem } from "src/views/management/ListingDetail/ListingFunction";
import AmazonCondition from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Amazon/Condition";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";

const useStyles = makeStyles(theme => ({
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const CellsAmazon = ({ item, styleChannel = function() {} }) => {
  const classes = useStyles();
  const { tableHeader } = useContext(ListingDetailTableContext);

  if (!Object.keys(tableHeader).length) {
    return null;
  }

  return (
    <>
      {tableHeader.asin.isShow && (
        <TableCell
          width={styleChannel("asin").width}
          style={{ maxWidth: styleChannel("asin").maxWidth }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Box width="100%">
              {item.asin !== "" && (
                <MuiLInk
                  onClick={event => {
                    event.preventDefault();
                    window.open(item?.asin_data?.url, "_blank");
                    return false;
                  }}
                  style={{ cursor: "pointer" }}
                  href={item?.asin_data?.url}
                >
                  <Typography variant="body2" className={classes.name}>
                    {item.asin}
                  </Typography>
                </MuiLInk>
              )}
            </Box>
          )}
        </TableCell>
      )}
      {tableHeader.gtin.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.gtin}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.ean.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.ean}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.upc.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.upc}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.isbn.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.isbn}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.mpn.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.mpn}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.msrp.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.msrp}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.map.isShow && (
        <TableCell
          style={{
            minWidth: styleChannel("asin").minWidth,
            maxWidth: styleChannel("asin").maxWidth
          }}
          align={styleChannel("asin").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Typography variant={"body2"}>{item.map}</Typography>
          )}
        </TableCell>
      )}
      {tableHeader.fulfillment.isShow && (
        <TableCell
          width={styleChannel("fulfillment").width}
          style={{ maxWidth: styleChannel("fulfillment").maxWidth }}
          align={styleChannel("fulfillment").align}
        >
          {item.lastItem ? (
            ""
          ) : (
            <Box className={classes.name}>
              {fulfilledItem(item?.template_data?.offer?.fulfillment)}
            </Box>
          )}
        </TableCell>
      )}
      {tableHeader.condition.isShow && <AmazonCondition item={item} />}
    </>
  );
};

export default CellsAmazon;
