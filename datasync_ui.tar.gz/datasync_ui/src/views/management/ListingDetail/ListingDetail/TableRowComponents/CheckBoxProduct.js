import React, { useContext } from "react";
import { Checkbox } from "@material-ui/core";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";

const CheckBoxProduct = ({ item, isNotVariant = false, rowNumber }) => {
  const { selectedItems, handleSelectOneItem, selectWithShiftHeld } = useContext(
    ListingDetailTableSelectedProductContext
  );
  if (!isNotVariant) {
    return null;
  }

  const isSelected = selectedItems.includes(item?.publish_id);

  return (
     <Checkbox
        checked={!!isSelected}
        onChange={(e) => {
           handleSelectOneItem({ item, isSelected, rowNumber });
           selectWithShiftHeld(rowNumber, e.target.checked)
        }}
     />
  );
};

export default CheckBoxProduct;
