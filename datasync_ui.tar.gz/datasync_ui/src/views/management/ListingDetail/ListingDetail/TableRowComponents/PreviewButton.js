import React from "react";
import { colors, IconButton, TableCell, Tooltip } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import OpenInNewIcon from "@material-ui/icons/OpenInNew";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";
import {
  ebayURL,
  handleSeeOnChannelText
} from "src/views/management/ListingEditProduct/Components/Layout/ModalLayout/PreviewButton";
import { ebayDomain } from "src/views/management/Listing/ChannelConnect/Channels/Ebay";
import { useSelector } from "react-redux";
import { IS_PREVIEW_CHANNEL } from "src/constants/Listing/index";

const useStyles = makeStyles(theme => ({
  eyeButtonStyle: {
    color: colors.grey[500],
    "&:hover": {
      color: colors.grey[700]
    }
  }
}));

const PreviewButtonListingDetail = ({
  product,
  channelType,
  styleGlobal,
  channelID
}) => {
  const classes = useStyles();
  const ebaySetting = useSelector(
    state => state?.listing?.ebay_setting?.[channelID]
  );
  const ebaySettingMarketId = ebaySetting?.marketplace_id;
  const isShowPreview = product?.channel_status === "active";
  const isEbayEtsy = IS_PREVIEW_CHANNEL.includes(channelType);

  const isShowPreviewEye = isShowPreview && isEbayEtsy;

  const findDomainEbay = ebayDomain.find(
    item => item.value === ebaySettingMarketId
  );

  const productHref = productId => {
    if (!productId) return;
    const channel = {
      etsy: `https://www.etsy.com/listing/${productId}`,
      ebay: ebayURL(findDomainEbay, productId),
      reverb: `https://reverb.com/item/${productId}`
    };
    if (channel?.[channelType]) {
      return channel[channelType];
    }
    return "";
  };

  const handleTooltipTitle = () => {
    if (channelType === "ebay") {
      return handleSeeOnChannelText.ebay(findDomainEbay);
    }
    return `See on ${capitalizeFirstLetter(channelType)}.com`;
  };

  if (!isShowPreviewEye) {
    return null;
  }

  if (product?.parent_id) {
    return <TableCell width={styleGlobal.preview.width} />;
  }

  return (
    <TableCell width={styleGlobal.preview.width}>
      <Tooltip title={product.id ? handleTooltipTitle() : "Id not found"}>
        <IconButton
          size="small"
          href={productHref(product.id)}
          target="_blank"
          className={classes.eyeButtonStyle}
          // onClick={() => handleClickPreview(product.id)}
        >
          <OpenInNewIcon fontSize="small" />
        </IconButton>
      </Tooltip>
    </TableCell>
  );
};

export default PreviewButtonListingDetail;
