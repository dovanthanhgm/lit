import {
  makeStyles,
  Paper,
  Popover,
  Typography,
  withStyles
} from "@material-ui/core";
import React, { useContext, useState } from "react";
import Link from "src/components/MUI/Link";
import { editRoute } from "src/hooks/Template/useTemplateRoute";
import { GridContext } from "./GridList";

const useStyles = makeStyles(() => ({
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden",
    display: "inline"
  }
}));

const CustomPaper = withStyles(theme => ({
  root: {
    padding: ".75rem"
  }
}))(Paper);

const TemplateLists = (props, ref) => {
  const { channelID, item } = props;

  const itemTemplates = item?.templates || {};
  delete itemTemplates.recipes;
  const templateTitle = Object.keys(itemTemplates).filter(
    title => ![null, ""].includes(itemTemplates[title])
  );

  const classes = useStyles();
  const { arrayKeyTemplatesTitle, listTemplatesObject } = useContext(
    GridContext
  );

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = event => {
    setAnchorEl(anchorEl ? null : event.currentTarget);
  };

  return (
    <React.Fragment>
      {templateTitle.length > 0 ? (
        <Link
          variant="subtitle2"
          className={classes.name}
          onClick={e => handleClick(e)}
        >
          {templateTitle.length} Templates
        </Link>
      ) : (
        <Typography variant="subtitle2" className={classes.name}>
          {templateTitle.length} Templates
        </Typography>
      )}
      <Popover
        open={Boolean(anchorEl)}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center"
        }}
      >
        <CustomPaper>
          {arrayKeyTemplatesTitle.map(keyTemplate => {
            const itemKeyTemplate = item.templates?.[keyTemplate];
            const arrayTemplate =
              listTemplatesObject[keyTemplate]?.[itemKeyTemplate];
            return item.lastItem || !arrayTemplate ? (
              ""
            ) : (
              <Link
                to={editRoute({
                  templateType: keyTemplate,
                  template_id: arrayTemplate?.id,
                  channelId: channelID
                })}
                className={classes.name}
                key={arrayTemplate?.id}
              >
                <Typography
                  variant="body2"
                  className={classes.name}
                  style={{ padding: "0 .75rem" }}
                >
                  {arrayTemplate?.name || ""}
                </Typography>
              </Link>
            );
          })}
        </CustomPaper>
      </Popover>
    </React.Fragment>
  );
};

export default TemplateLists;
