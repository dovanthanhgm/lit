import React, { useContext } from 'react';
import { Checkbox, makeStyles } from '@material-ui/core';
import { ListingDetailTableSelectedProductContext } from 'src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext';

const useStyles = makeStyles({
   root: {
      height: '16px',
      width: '16px',
      position: 'absolute',
      top: '8px',
      left: '8px',
      background: 'white',
      '&:hover': {
         backgroundColor: '#EFEFEF'
      }
   }
});

const CheckBoxGridProduct = ({ item, isNotVariant = false, rowNumber }) => {
   const { selectedItems, handleSelectOneItem, selectWithShiftHeld } = useContext(
      ListingDetailTableSelectedProductContext
   );

   const classes = useStyles();
   if (!isNotVariant) {
      return null;
   }

   const isSelected = selectedItems.includes(item?.publish_id);

   return (
      <Checkbox
         className={classes.root}
         checked={!!isSelected}
         onChange={() => {
            handleSelectOneItem({ item, isSelected, rowNumber });
            selectWithShiftHeld(rowNumber);
         }}
      />
   );
};

export default CheckBoxGridProduct;
