import {
   makeStyles,
   TableCell,
   TableHead,
   TableRow,
   Typography,
   withStyles
} from '@material-ui/core';
import { Info as InfoIcon } from '@material-ui/icons';
import React, { useContext, useMemo } from 'react';
import SimpleTooltips from 'src/components/Tooltip/SimpleTooltips';
import { ListingDetailChannelDetailContext } from 'src/views/management/ListingDetail/Context/ListingDetailChannelDetail';
import { ListingDetailProductsContext } from 'src/views/management/ListingDetail/Context/ListingDetailProductsContext';

const useStyles = makeStyles(theme => ({
   titleTemplate: {
      overflow: 'hidden',
      textOverflow: 'ellipsis'
   },
   tablePaddingCustom: {
      padding: '13px !important'
   },
   styleHeader: {
      position: 'sticky',
      top: 0,
      boxShadow: 'none',
      backgroundColor: 'white',
      zIndex: 2,
      padding: '5px 0px'
   }
}));

const StyledTableCell = withStyles(theme => ({
   head: {
      padding: '0 16px'
   }
}))(TableCell);

const tableHeadName = ['Title', 'SKU', 'Quantity', 'Price'];

function TableHeaderGridPopper() {
   const classes = useStyles();

   const { channelType } = useContext(ListingDetailChannelDetailContext);
   const { tab } = useContext(ListingDetailProductsContext);

   const newTableHeader = useMemo(() => {
      let newTableName = [...tableHeadName];
      if (channelType === 'amazon') {
         newTableName.splice(3, 0, 'ASIN', 'Fulfilled By');
      }
      if (channelType === 'google') {
         newTableName.splice(4, 0, 'Sale price');
      }
      return newTableName;
   }, [channelType]);

   const isEbayEtsy = ['ebay', 'etsy'].includes(channelType);
   const isActiveTab = !['draft', 'error'].includes(tab);

   return (
      <TableHead className={classes.styleHeader}>
         <TableRow>
            <StyledTableCell>
               <SimpleTooltips
                  title={
                     'Indicates whether the listing is linked to a product in the product catalog'
                  }
                  icon={<InfoIcon color='primary' />}
               />
            </StyledTableCell>
            {newTableHeader.map((item, key) => (
               <StyledTableCell key={key}>
                  <Typography variant='h6' color='textPrimary' className={classes.titleTemplate}>
                     {item}
                  </Typography>
               </StyledTableCell>
            ))}
            {isActiveTab && isEbayEtsy && <StyledTableCell style={{ width: 50 }} />}
         </TableRow>
      </TableHead>
   );
}

export default TableHeaderGridPopper;
