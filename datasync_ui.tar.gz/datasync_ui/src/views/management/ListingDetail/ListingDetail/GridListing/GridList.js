import {
  Box,
  FormControlLabel,
  Grid,
  Checkbox,
  Typography,
  useMediaQuery,
  useTheme
} from "@material-ui/core";
import React, { useContext, useMemo, useState } from "react";
import ItemImage from "./ItemImage";
import CheckBoxGridProduct from "./CheckBoxGridProduct";
import TableLinkIcon from "../TableLink";
import ListingTableStatus from "../TableStatus";
import { ListingDetailChannelDetailContext } from "../../Context/ListingDetailChannelDetail";
import ListingGridProductName from "./ListingGridProductName";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import { salePriceListingTable } from "src/utils/Listing/salePrice";
import TemplateLists from "./TemplateLists";
import { useIsChannelInMarketplaces } from "src/hooks";
import { useSelector } from "react-redux";
import { ListingDetailTableSelectedProductContext } from "../../Context/ListingDetailTableSelectedProductContext";
import useTemplate from "src/hooks/useTemplate";

export const GridContext = React.createContext({
  arrayKeyTemplatesTitle: [],
  listTemplatesObject: {}
});

function GridCustom(props, ref) {
  const { products } = props;

  const { selectedItems, handleSelectAllItems } = useContext(
    ListingDetailTableSelectedProductContext
  );

  const { channelType, channelID } = useContext(
    ListingDetailChannelDetailContext
  );
  const { fetchDataLoading } = useContext(ListingProductDialogContext);

  const [isOpenVariant, setIsOpenVariant] = useState(false);

  const templatesTitle = useTemplate({ channelType, channelID })
    .allChannelTemplatesTitle;

  const { isChannelInMarketplaces } = useIsChannelInMarketplaces({
    channelType
  });
  const { listTemplates } = useSelector(state => state.templates);

  const theme = useTheme();

  const mdUp = useMediaQuery(theme.breakpoints.up("md"));
  const lgUp = useMediaQuery(theme.breakpoints.up("lg"));

  const arrayKeyTemplatesTitle = useMemo(() => {
    if (templatesTitle) {
      return isChannelInMarketplaces
        ? Object.keys(templatesTitle).filter(item => item !== "recipes")
        : [];
    }
    return [];
  }, [templatesTitle, isChannelInMarketplaces]);

  const listTemplatesObject = useMemo(() => {
    if (!listTemplates) return {};
    const result = {};
    Object.entries(listTemplates).forEach(([key, value]) => {
      const valueObject = {};
      value.forEach(it => {
        valueObject[it.id] = it;
      });
      result[key] = valueObject;
    });

    return result;
  }, [listTemplates]);

  const handleShowSalePrice = product => {
    if (fetchDataLoading) return "";
    return salePriceListingTable(
      product,
      { price: product.parentPrice },
      !product.isVariant
    )
      ? product?.special_price?.price ?? ""
      : "";
  };

  const selectedAll = selectedItems.length === products?.length;
  const selectedSome =
    selectedItems.length > 0 && selectedItems.length < products?.length;

  const renderBoxHeight = () => {
    if (channelType === "google")
      return lgUp ? "400px" : mdUp ? "310px" : "340px";
    return lgUp ? "380px" : mdUp ? "295px" : "325px";
  };

  return (
    <GridContext.Provider
      value={{
        arrayKeyTemplatesTitle,
        listTemplatesObject
      }}
    >
      <Box padding="0 16px">
        <FormControlLabel
          control={
            <Checkbox
              checked={selectedAll}
              indeterminate={selectedSome}
              name="Select All"
              onChange={handleSelectAllItems}
            />
          }
          label="Select All"
        />
        <Grid container>
          {products.map((product, index) => (
            <Grid
              item
              xs={3}
              md={2}
              key={product?.publish_id || product?.id}
              style={{ padding: "5px" }}
            >
              <Box
                height={renderBoxHeight()}
                style={{ outline: "1px solid #ccc" }}
                position="relative"
                borderRadius="4px"
              >
                <CheckBoxGridProduct
                  item={product}
                  isNotVariant={!product?.parentIdEdit}
                  rowNumber={index}
                />
                <ItemImage src={product.thumb_image?.url}></ItemImage>
                <Box
                  flexDirection="row"
                  display="flex"
                  alignItems="center"
                  paddingBottom="4px"
                >
                  <TableLinkIcon
                    item={product}
                    isOpenVariant={isOpenVariant}
                    isNotVariant={!product?.parentIdEdit}
                  />
                  <ListingTableStatus
                    channelType={channelType}
                    item={product}
                  />
                  <ListingGridProductName
                    setIsOpenVariant={setIsOpenVariant}
                    item={product}
                    isNotVariant={!product?.parentIdEdit}
                  />
                </Box>
                {product.lastItem ? (
                  ""
                ) : (
                  <Box width="100%" style={{ paddingLeft: "8px" }}>
                    <Typography
                      variant="subtitle2"
                      style={{
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        overflow: "hidden"
                      }}
                    >
                      SKU: {product.sku}
                    </Typography>
                    <Typography variant="subtitle2">
                      Quantity: {product.lastItem ? "" : product.qty}
                    </Typography>
                    {channelType === "google" && (
                      <Typography variant="subtitle2">
                        {product.lastItem ? (
                          ""
                        ) : (
                          <Typography variant="subtitle2" component={"span"}>
                            Sale Price: {handleShowSalePrice(product)}
                          </Typography>
                        )}
                      </Typography>
                    )}
                    <Typography variant="subtitle2">
                      {product.lastItem ? (
                        ""
                      ) : (
                        <Typography variant="subtitle2" component="span">
                          Price: {product.price}
                        </Typography>
                      )}
                    </Typography>
                    <TemplateLists item={product} channelID={channelID} />
                  </Box>
                )}
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>
    </GridContext.Provider>
  );
}

export default React.memo(GridCustom);
