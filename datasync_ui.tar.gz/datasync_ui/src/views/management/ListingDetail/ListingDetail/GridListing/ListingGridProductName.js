import React, { useContext, useState } from 'react';
import { Box, makeStyles, Tooltip, Typography } from '@material-ui/core';
import {
   ControlPoint as ControlPointIcon,
   RemoveCircleOutline as RemoveCircleOutlineIcon
} from '@material-ui/icons';
import Link from 'src/components/MUI/Link';
import { getProductVariantListing } from 'src/services/products';
import { ListingDetailChannelDetailContext } from 'src/views/management/ListingDetail/Context/ListingDetailChannelDetail';
import { ListingProductDialogContext } from 'src/views/management/ListingEditProduct/Context/ListingTableVariantContext';
import ItemsPopper from './ItemsPopper';

const useStyles = makeStyles(() => ({
   titleTemplate2: {
      overflow: 'hidden',
      width: '100%',
      textOverflow: 'ellipsis',
      display: 'inline-block'
   },
   name: {
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      overflow: 'hidden'
   }
}));

const ListingGridProductName = ({ item, setIsOpenVariant }) => {
   const { variants, setVariants, setDialogProduct, setOpenDialog } = useContext(
      ListingProductDialogContext
   );
   const { channelID } = useContext(ListingDetailChannelDetailContext);
   const classes = useStyles();
   const hasAddedVariant = variants?.[item?.publish_id]?.removed === false;

   const [anchorEl, setAnchorEl] = useState(null);

   const hideVariant = event => {
      setIsOpenVariant(false);
      setAnchorEl(null);
      const id = item?.publish_id;
      setVariants(items => ({
         ...items,
         [id]: { ...items[id], removed: true }
      }));
   };

   const showVariant = async event => {
      setIsOpenVariant(true);
      setAnchorEl(event.currentTarget);
      const id = item?.publish_id;
      if (variants[id]) {
         setVariants(items => ({
            ...items,
            [id]: { ...items[id], removed: false }
         }));
         return;
      }

      const resVariations = await getProductVariantListing({
         channel_id: channelID,
         productId: id
      });

      const getVariantOption = (variant = { link_variant_options: [] }) => {
         return variant?.link_variant_options?.length > 0 && variant?.link_variant_options
            ? variant?.link_variant_options
            : item?.link_variant_options || [];
      };

      setVariants(items => ({
         ...items,
         [id]: {
            data: resVariations.data.map(itemSmall => ({
               ...itemSmall,
               parentIdEdit: item.currentTab === 'active' ? item?.id : item?.publish_id,
               parentVariantOption: getVariantOption(itemSmall),
               parentName: item?.name,
               parentLinked: item?.link_status
            })),
            removed: false
         }
      }));
   };
   return (
      <Box
         display='flex'
         alignItems='center'
         width='50%'
         flexGrow={1}
         style={{ marginLeft: '4px' }}
      >
         {item?.variant_count > 0 && (
            <Box mr={1}>
               <RemoveCircleOutlineIcon
                  fontSize='small'
                  style={{
                     cursor: 'pointer',
                     visibility: !hasAddedVariant ? 'hidden' : null,
                     width: !hasAddedVariant ? 0 : null
                  }}
                  onClick={e => hideVariant(e)}
               />

               <ControlPointIcon
                  fontSize='small'
                  style={{
                     cursor: 'pointer',
                     visibility: hasAddedVariant ? 'hidden' : null,
                     width: hasAddedVariant ? 0 : null
                  }}
                  onClick={e => showVariant(e)}
               />
               <ItemsPopper
                  anchorEl={anchorEl}
                  hasAddedVariant={hasAddedVariant}
                  item={item}
                  hideVariant={hideVariant}
               />
            </Box>
         )}

         {!item?.lastItem && (
            <Link
               color='primary'
               onClick={() => {
                  window.history.replaceState(
                     null,
                     null,
                     `/listing/${channelID}/${item?.publish_id}`
                  );
                  setOpenDialog(true);
                  setDialogProduct(item);
               }}
               className={classes.titleTemplate}
               style={{ overflow: 'hidden' }}
            >
               <Tooltip title={item?.name || item?.parentName}>
                  <Typography variant='body2' className={classes.name}>
                     {item?.name || item?.parentName}
                  </Typography>
               </Tooltip>
            </Link>
         )}
      </Box>
   );
};

export default ListingGridProductName;
