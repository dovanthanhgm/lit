import {
   Paper,
   Popper,
   Table,
   TableBody,
   TableCell,
   TableContainer,
   TableRow,
   withStyles,
   ClickAwayListener,
   Box,
   Typography
} from '@material-ui/core';
import React, { useContext } from 'react';
import { ListingProductDialogContext } from 'src/views/management/ListingEditProduct/Context/ListingTableVariantContext';
import TableHeaderGridPopper from './TableHeaderGridPopper';
import TableLinkIcon from '../TableLink';
import ListingTableProductName from '../TableProductName';

const CustomTableCell = withStyles(theme => ({
   root: {
      padding: '4px'
   }
}))(TableCell);

const CustomPaper = withStyles(theme => ({
   root: {
      maxHeight: '250px',
   }
}))(Paper);

function ItemsPopper(props) {
   const { variants } = useContext(ListingProductDialogContext);
   const { anchorEl, hasAddedVariant, item, hideVariant } = props;

   const isNotVariant = !item?.parentIdEdit;

   return (
      <React.Fragment>
         {hasAddedVariant && (
            <ClickAwayListener onClickAway={() => hideVariant()}>
               <Popper open={Boolean(anchorEl)} anchorEl={anchorEl}>
                  <TableContainer component={CustomPaper}>
                     <Table>
                        <TableHeaderGridPopper />
                        <TableBody>
                           {variants?.[item?.publish_id]?.data?.map(variant => (
                              <TableRow key={variant.publish_id}>
                                 <CustomTableCell>
                                    <TableLinkIcon
                                       item={item}
                                       isNotVariant={isNotVariant}
                                       isOpenVariant={false}
                                       isGrid
                                    />
                                 </CustomTableCell>
                                 <CustomTableCell align='center'>
                                    <ListingTableProductName
                                       item={variant}
                                       isNotVariant={isNotVariant}
                                    />
                                 </CustomTableCell>
                                 <CustomTableCell align='center'>
                                    <Box width='100%'>
                                       <Typography variant='body2'>{variant.sku}</Typography>
                                    </Box>
                                 </CustomTableCell>
                                 <CustomTableCell align='center'>
                                    <Typography variant='body2'>{variant.qty}</Typography>
                                 </CustomTableCell>
                                 <CustomTableCell align='center'>
                                    <Typography variant='body2' component='span'>
                                       {variant.price}
                                    </Typography>
                                 </CustomTableCell>
                              </TableRow>
                           ))}
                        </TableBody>
                     </Table>
                  </TableContainer>
               </Popper>
            </ClickAwayListener>
         )}
      </React.Fragment>
   );
}

export default ItemsPopper;
