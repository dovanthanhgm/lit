import { Box, SvgIcon, Tooltip, useMediaQuery } from "@material-ui/core";
import React, { useState } from "react";
import LazyLoad from "react-lazy-load";
import { Image as ImageIcon } from "react-feather";
import { useTheme } from "@material-ui/core/styles";

function ItemImage(props, ref) {
  const { src } = props;
  const [isImgError, setIsImgError] = useState(false);
  const onImageError = () => {
    setIsImgError(true);
  };
  const WrapComponent = isImgError ? Tooltip : React.Fragment;
  const propsWrapComponent = isImgError
    ? {
        title:
          "Unable to load image. Please click on the product details to reload the images.",
        placement: "top",
        arrow: true
      }
    : {};
  const theme = useTheme();

  const mdUp = useMediaQuery(theme.breakpoints.up("md"));
  const lgUp = useMediaQuery(theme.breakpoints.up("lg"));

  return (
    <WrapComponent {...propsWrapComponent}>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        minHeight={lgUp ? "250px" : mdUp ? "160px" : "190px"}
        padding="1px"
      >
        {src && (
          <LazyLoad style={{ display: "flex" }}>
            <img
              src={isImgError ? "/static/images/image_not_found.png" : src}
              style={{
                objectFit: "contain",
                maxHeight: lgUp ? "250px" : mdUp ? "160px" : "190px",
                borderRadius: "4px 4px 0 0"
              }}
              width="100%"
              alt=" "
              referrerPolicy="no-referrer"
              onError={onImageError}
            />
          </LazyLoad>
        )}

        {!src && (
          <SvgIcon>
            <ImageIcon />
          </SvgIcon>
        )}
      </Box>
    </WrapComponent>
  );
}

export default ItemImage;
