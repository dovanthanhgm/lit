import React from "react";
import Result from "src/views/management/ListingDetail/TableListing/Result";
import ProductDetailListing from "src/views/management/ListingDetail/TableListing/ProductDetailListing";
import ListingTableProvider from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";

const ListingTableData = () => {
  return (
    <ListingTableProvider>
      <React.Fragment>
        <ProductDetailListing />
        <Result />
      </React.Fragment>
    </ListingTableProvider>
  );
};

export default ListingTableData;
