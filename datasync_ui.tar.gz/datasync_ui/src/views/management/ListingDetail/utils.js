import {
  ACTIVE_VALUE,
  DRAFT_VALUE,
  ENDED_VALUE,
  ERROR_VALUE,
  ETSY_DRAFT,
  EXPIRED_VALUE,
  FAILED_VALUE,
  FREEZE_VALUE,
  INACTIVE_VALUE,
  PENDING_VALUE,
  SOLD_OUT,
  TIKTOK_DRAFT_VALUE,
  UPPERCASE_INACTIVE_VALUE
} from "src/constants/Listing";

export const listingTabs = [
  DRAFT_VALUE,
  ACTIVE_VALUE,
  ERROR_VALUE,
  INACTIVE_VALUE,
  UPPERCASE_INACTIVE_VALUE,
  ENDED_VALUE,
  EXPIRED_VALUE,
  SOLD_OUT,
  ETSY_DRAFT
];

const itemCount = item => {
  if (isNaN(item)) {
    return 0;
  }
  return item;
};

export const checkTotal = checkList => {
  let total = 0;
  listingTabs.forEach(item => {
    total += itemCount(checkList?.[item]);
  });

  return total;
};

export const tabCallInactive = {
  amazon: {
    type: "active",
    search: "&amazon_status=inactive",
    search_product: "?amazon_status=inactive"
  },
  etsy: {
    type: "active",
    search: "&etsy_status=inactive",
    search_product: "?etsy_status=inactive"
  },
  tiktok: {
    type: "active",
    search: "&tiktok_status=inactive",
    search_product: "?tiktok_status=inactive"
  }
};

export const tabCallInactiveUpperCase = {
  amazon: {
    type: "active",
    search: "&amazon_status=Inactive",
    search_product: "?amazon_status=Inactive"
  }
};

export const tabCallExpired = {
  etsy: {
    type: "active",
    search: "&etsy_status=expired",
    search_product: "?etsy_status=expired"
  }
};

export const tabCallSoldOut = {
  etsy: {
    type: "active",
    search: "&etsy_status=sold_out",
    search_product: "?etsy_status=sold_out"
  },
  reverb: {
    type: "active",
    search: "&reverb_status=sold",
    search_product: "?reverb_status=sold"
  }
};

export const tabCallEtsyDraft = {
  etsy: {
    type: "active",
    search: "&etsy_status=etsy_draft",
    search_product: "?etsy_status=etsy_draft"
  },
  reverb: {
    type: "active",
    search: "&reverb_status=reverb_draft",
    search_product: "?reverb_status=reverb_draft"
  }
};

export const tabCallEnded = {
  ebay: {
    type: "active",
    search: "&ebay_status=ended",
    search_product: "?ebay_status=ended"
  },
  bonanza: {
    type: "active",
    search: "&bonanza_status=ended",
    search_product: "?bonanza_status=ended"
  },
  reverb: {
    type: "active",
    search: "&reverb_status=ended",
    search_product: "?reverb_status=ended"
  }
};

export const tabCallRetired = {
  walmart: {
    type: "active",
    search: "&walmart_status=retired",
    search_product: "?walmart_status=retired"
  },
  walmartca: {
    type: "active",
    search: "&walmartca_status=retired",
    search_product: "?walmartca_status=retired"
  }
};

export const tabCallArchive = {
  walmart: {
    type: "active",
    search: "&walmart_status=archived",
    search_product: "?walmart_status=archived"
  },
  walmartca: {
    type: "active",
    search: "&walmartca_status=archived",
    search_product: "?walmartca_status=archived"
  }
};

export const tabCallUnpublished = {
  walmart: {
    type: "active",
    search: "&walmart_status=unpublished",
    search_product: "?walmart_status=unpublished"
  }
};

export const tabCallDeleted = {
  shopee: {
    type: "active",
    search: "&shopee_status=sdeleted",
    search_product: "?shopee_status=sdeleted"
  }
};

export const tabCallUnlist = {
  shopee: {
    type: "active",
    search: "&shopee_status=unlist",
    search_product: "?shopee_status=unlist"
  }
};

export const tabCallBanned = {
  shopee: {
    type: "active",
    search: "&shopee_status=banned",
    search_product: "?shopee_status=banned"
  }
};

export const tabCallFailed = {
  tiktok: {
    type: "active",
    search: `&tiktok_status=${FAILED_VALUE}`,
    search_product: `?tiktok_status=${FAILED_VALUE}`
  }
};

export const tabCallFreeze = {
  tiktok: {
    type: "active",
    search: `&tiktok_status=${FREEZE_VALUE}`,
    search_product: `?tiktok_status=${FREEZE_VALUE}`
  }
};

export const tabCallPending = {
  tiktok: {
    type: "active",
    search: `&tiktok_status=${PENDING_VALUE}`,
    search_product: `?tiktok_status=${PENDING_VALUE}`
  }
};

export const tabCallTiktokDraft = {
  tiktok: {
    type: "active",
    search: `&tiktok_status=${TIKTOK_DRAFT_VALUE}`,
    search_product: `?tiktok_status=${TIKTOK_DRAFT_VALUE}`
  }
};
