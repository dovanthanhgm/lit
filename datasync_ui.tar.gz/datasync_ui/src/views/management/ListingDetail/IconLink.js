import { Badge, Box, Button, makeStyles, Tooltip } from "@material-ui/core";
import AddIcon from "@material-ui/icons/Add";
import LinkOffIcon from "@material-ui/icons/LinkOff";
import SearchIcon from "@material-ui/icons/Search";
import { debounce } from "lodash";
import { useSnackbar } from "notistack";
import React, { useContext, useState } from "react";
import { Box as BoxIcon, Link as LinkIcon } from "react-feather";
import LinkProductDialog from "src/components/Modal/ModalChannel/LinkProductDialog";
import { alertError } from "src/helper/showErrorMessage";
import { unLinkProducts } from "src/services/channel";
import { createProductOnChannel } from "src/services/products";
import { useDispatch, useSelector } from "react-redux";
import { handleSquareSpaceCallCreate } from "../Listing/ListingCallCreate";
import SquareSpaceStoreModal from "src/components/Modal/SquareSpaceStoreModal";
import useMainStoreMagento from "../../../hooks/Listing/useMainStoreMagento";
import { DRAFT_VALUE, ERROR_VALUE } from "src/constants/Listing";
import useUserExp from "src/hooks/useUserExp";
import useUnlinkVariantListingDetail from "src/views/management/ListingDetail/Hook/useUnlinkVariantListingDetail";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import wait from "src/utils/wait";
import { HIDE_CREATE_ON_CHANNEL } from "src/constants/index";

const useStyles = makeStyles(theme => ({
  tooltipStyle: {
    backgroundColor: "unset",
    marginTop: 0
  }
}));

const draftErrorStatus = [DRAFT_VALUE, ERROR_VALUE];

function IconLink({
  item,
  currentTab,
  idName,
  setLoading = function() {},
  handleChangeStatus,
  channelID,
  channelType,
  getVariant = function() {},
  getDataDetail = function() {},
  parentLinkStatus,
  isNotVariant = true,
  isGrid = false
}) {
  const classes = useStyles();
  const dispatch = useDispatch();
  const { defaultListing } = useSelector(state => state?.listing);
  const { enqueueSnackbar } = useSnackbar();
  const { hideCreateOn } = useMainStoreMagento();
  const hideCreateOnMain =
    HIDE_CREATE_ON_CHANNEL.includes(channelType) || hideCreateOn;
  const [openLink, setOpenLink] = useState(false);
  const [openDialogStore, setOpenDialogStore] = useState(false);
  const { expired } = useUserExp();
  const { handleUnlinkVariant } = useUnlinkVariantListingDetail();
  const { handleChangeVariantUnlink } = useContext(ListingProductDialogContext);

  const handleLinkOpen = () => {
    setOpenLink(true);
  };

  const handleLinkClose = () => {
    setOpenLink(false);
  };

  const handleCreateOnDefault = async storeId => {
    handleChangeStatus({
      id: [item?.publish_id],
      status: "creating"
    });
    await createProductOnChannel({
      channelID: channelID,
      selectedProducts: [item?.publish_id],
      defaultChannelId: defaultListing?.id,
      squareStoreId: storeId
    });
  };

  const handleUnlink = async () => {
    handleChangeStatus({
      id: [item?.publish_id],
      status: draftErrorStatus.includes(currentTab) ? "pushing" : "creating"
    });
    const data = await unLinkProducts({
      channel_id: channelID,
      body: { product_ids: [item?.publish_id] }
    });
    if (data) {
      if (isNotVariant) {
        handleUnlinkVariant({ items: item, newId: data?.data?.[0] });
      }
      if (!isNotVariant && !!item.parent_id) {
        handleChangeVariantUnlink(item);
      }
    }
  };

  const handleCreateProduct = () => {
    if (defaultListing.type === "squarespace") {
      return handleSquareSpaceCallCreate({
        channelId: defaultListing.id,
        enqueueSnackbar,
        dispatch,
        channelType: defaultListing.type,
        createProductFunction: handleCreateOnDefault,
        setOpenDialogStore
      });
    }
    return handleCreateOnDefault();
  };

  const fetchAllProductAPI = debounce(async () => {
    try {
      if (item.variant_count > 0) {
        getVariant(item);
      }
      getDataDetail();
    } catch (e) {
      console.log("error", e);
      enqueueSnackbar("Fetch products failed", {
        variant: "error"
      });
    }
  }, 1500);

  const handleClickActiveProduct = value => async () => {
    setLoading(true);
    try {
      value === "unlink" ? await handleCreateProduct() : await handleUnlink();
      getVariant(item);
      if (
        !item.parent_id &&
        value === "unlink" &&
        defaultListing.type !== "squarespace"
      ) {
        await wait(30000);
        fetchAllProductAPI();
      }
    } catch (error) {
      console.log(error);
      const message = error.response?.data?.errors
        ? alertError(error.response?.data?.errors)
        : error.response?.data?.message || "Something went wrong";
      enqueueSnackbar(message, { variant: "error" });
    }
    setLoading(false);
  };

  const warningMessage =
    parentLinkStatus === "unlink"
      ? "You need to link parent product first."
      : "";

  return (
    <Box>
      {openDialogStore && (
        <SquareSpaceStoreModal
          open={openDialogStore}
          handleClose={() => {
            setOpenDialogStore(false);
          }}
          handleConfirm={handleCreateOnDefault}
          channelId={defaultListing?.id}
        />
      )}

      <Tooltip
        classes={{ tooltip: classes.tooltipStyle }}
        title={
          <>
            <Box>
              {(item?.link_status === "linked" ||
                draftErrorStatus.includes(currentTab)) && (
                <>
                  {isNotVariant && (
                    <Box>
                      <Button
                        fullWidth
                        variant="contained"
                        color="default"
                        startIcon={<BoxIcon />}
                        size="small"
                        href={`/products/${item[idName]}`}
                        target="_blank"
                        // disabled={disableAction}
                      >
                        View Linked Product
                      </Button>
                    </Box>
                  )}
                  {!draftErrorStatus.includes(currentTab) && (
                    <Box>
                      <Button
                        fullWidth
                        variant="contained"
                        color="default"
                        startIcon={<LinkOffIcon />}
                        onClick={handleClickActiveProduct(item.link_status)}
                        // disabled={disableAction}
                        size="small"
                      >
                        Unlink from Product
                      </Button>
                    </Box>
                  )}
                </>
              )}
              {item?.link_status === "unlink" &&
                !draftErrorStatus.includes(currentTab) && (
                  <Box display="flex" flexDirection="column">
                    <Button
                      fullWidth
                      variant="contained"
                      color="default"
                      startIcon={<SearchIcon />}
                      onClick={handleLinkOpen}
                      // disabled={disableAction}
                      size="small"
                    >
                      Link to a product
                    </Button>
                    {!hideCreateOnMain && (
                      <Button
                        disabled={expired}
                        fullWidth
                        variant="contained"
                        color="default"
                        startIcon={<AddIcon />}
                        onClick={handleClickActiveProduct(item.link_status)}
                        size="small"
                      >
                        Create On {defaultListing?.type}
                      </Button>
                    )}
                  </Box>
                )}
            </Box>
          </>
        }
        interactive
      >
        <Box display="flex" p={1} justifyContent={isGrid ? 'center' : ''}>
          <Badge
            color={
              item.link_status === "linked" ||
              draftErrorStatus.includes(currentTab)
                ? "primary"
                : "error"
            }
            variant="dot"
          >
            <LinkIcon size="22" />
          </Badge>
        </Box>
      </Tooltip>

      {openLink && (
        <LinkProductDialog
          open={openLink}
          handleClose={handleLinkClose}
          values={{
            name: item?.name,
            sku: item?.sku,
            id: item?.publish_id,
            parentLinkId: item?.parentIdEdit,
            img: item?.thumb_image?.url
          }}
          channelID={channelID}
          setLoading={setLoading}
          isVariations={item.is_variant}
          variantOption={item?.parentVariantOption}
          currentTab={currentTab}
          setOpenLink={setOpenLink}
          getVariant={getVariant}
          getDataListingDetail={getDataDetail}
          extraFunction={() => getVariant(item)}
          warningMessage={warningMessage}
        />
      )}
    </Box>
  );
}

export default IconLink;
