import React, { useState } from "react";
import {
  COUNT_CALL_TIMES_LIMIT,
  DEFAULT_COUNT_API_LISTING_DELAY,
  DEFAULT_PROCESS_API_LISTING_DELAY,
  DEFAULT_PRODUCT_API_LISTING_DELAY,
  PROCESS_CALL_TIMES_LIMIT,
  PRODUCT_CALL_TIMES_LIMIT,
  SUB_TIMES_ACTION
} from "src/views/management/ListingDetail/Constant/index";
import {
  driverItem,
  driverItemTime,
  handleSetDriverValue
} from "src/views/management/ListingDetail/Helper/index";

export const ListingDetailApiDriver = React.createContext({
  tableProduct: {
    call: true,
    delay: DEFAULT_PRODUCT_API_LISTING_DELAY,
    max: PRODUCT_CALL_TIMES_LIMIT
  },
  tableCount: {
    call: true,
    delay: DEFAULT_COUNT_API_LISTING_DELAY,
    max: COUNT_CALL_TIMES_LIMIT
  },
  tableProcess: {
    call: true,
    delay: DEFAULT_PROCESS_API_LISTING_DELAY,
    max: PROCESS_CALL_TIMES_LIMIT
  },
  listingApiDriver: {
    product: {
      start: function() {},
      stop: function() {},
      timesControl: function() {}
    },
    count: {
      start: function() {},
      stop: function() {},
      timesControl: function() {}
    },
    process: {
      start: function() {},
      stop: function() {},
      timesControl: function() {}
    }
  }
});

const ListingDetailApiDriverProvider = ({ children }) => {
  const [tableProductDriver, setTableProductDriver] = useState({
    call: true,
    delay: DEFAULT_PRODUCT_API_LISTING_DELAY,
    max: PRODUCT_CALL_TIMES_LIMIT
  });
  const [tableCountDriver, setTableCountDriver] = useState({
    call: true,
    delay: DEFAULT_COUNT_API_LISTING_DELAY,
    max: COUNT_CALL_TIMES_LIMIT
  });
  const [tableProcessDriver, setTableProcessDriver] = useState({
    call: true,
    delay: DEFAULT_PROCESS_API_LISTING_DELAY,
    max: PROCESS_CALL_TIMES_LIMIT
  });

  const productCallStart = (
    time = DEFAULT_PRODUCT_API_LISTING_DELAY,
    max = 5
  ) =>
    setTableProductDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItem({ time, callStatus: true, max })
      )
    );

  const productCallStop = (time = DEFAULT_PRODUCT_API_LISTING_DELAY) =>
    setTableProductDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItem({ time, callStatus: false, max: 5 })
      )
    );

  const countCallStart = (time = DEFAULT_PRODUCT_API_LISTING_DELAY, max = 5) =>
    setTableCountDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItem({ time, callStatus: true, max })
      )
    );

  const countCallStop = (time = DEFAULT_PRODUCT_API_LISTING_DELAY) =>
    setTableCountDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItem({ time, callStatus: false, max: 5 })
      )
    );

  const processCallStart = (
    time = DEFAULT_PROCESS_API_LISTING_DELAY,
    max = 5
  ) =>
    setTableProcessDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItem({ time, callStatus: true, max })
      )
    );

  const processCallStop = (time = DEFAULT_PROCESS_API_LISTING_DELAY) =>
    setTableProcessDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItem({ time, callStatus: false, max: 5 })
      )
    );

  const productTimeControl = (type = SUB_TIMES_ACTION, number = 1) => {
    setTableProductDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItemTime({
          currentLimit: prevState.max,
          type,
          number
        })
      )
    );
  };

  const countTimeControl = (type = SUB_TIMES_ACTION, number = 1) => {
    setTableCountDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItemTime({
          currentLimit: prevState.max,
          type,
          number
        })
      )
    );
  };

  const processTimeControl = (type = SUB_TIMES_ACTION, number = 1) => {
    setTableProcessDriver(prevState =>
      handleSetDriverValue(
        prevState,
        driverItemTime({
          currentLimit: prevState.max,
          type,
          number
        })
      )
    );
  };

  const listingApiDriver = {
    product: {
      start: productCallStart,
      stop: productCallStop,
      timesControl: productTimeControl
    },
    count: {
      start: countCallStart,
      stop: countCallStop,
      timesControl: countTimeControl
    },
    process: {
      start: processCallStart,
      stop: processCallStop,
      timesControl: processTimeControl
    }
  };

  return (
    <ListingDetailApiDriver.Provider
      value={{
        tableProduct: tableProductDriver,
        tableCount: tableCountDriver,
        tableProcess: tableProcessDriver,
        listingApiDriver
      }}
    >
      {children}
    </ListingDetailApiDriver.Provider>
  );
};

export default ListingDetailApiDriverProvider;
