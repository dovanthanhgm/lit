import React from "react";

export const ListingDetailProductsContext = React.createContext({
  listingData: [],
  setListingData: function() {},
  tab: "draft",
  setTab: function() {},
  recallProduct: function() {},
  setListingDataProductField: function() {},
  loadingTab: false,
  setLoadingTab: function() {},
  setPage: function() {},
  page: 1
});

const ListingDetailProductsProvider = ({
  listingData,
  setListingData = function() {},
  tab,
  setTab,
  recallProduct = function() {},
  loadingTab,
  setPage,
  page,
  setLoadingTab,
  children
}) => {
  const setListingDataProductField = (publish_id, field, value) => {
    const newListingData = listingData.map(product => {
      if (product.publish_id === publish_id) {
        product[field] = value;
      }
      return product;
    });
    setListingData(newListingData);
  };

  return (
    <ListingDetailProductsContext.Provider
      value={{
        listingData,
        setListingData,
        tab,
        setTab,
        recallProduct,
        setListingDataProductField,
        setLoadingTab,
        loadingTab,
        setPage,
        page
      }}
    >
      {children}
    </ListingDetailProductsContext.Provider>
  );
};

export default ListingDetailProductsProvider;
