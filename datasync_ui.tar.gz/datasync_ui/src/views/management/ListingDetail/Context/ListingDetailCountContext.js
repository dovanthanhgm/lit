import React from "react";
import { listingDetailTabs } from "src/constants/Listing/index";

export const ListingDetailCountContext = React.createContext({
  recallCount: function() {},
  count: {},
  setCount: function() {},
  totalCount: 0
});

const getTotalCount = data => {
  if (
    !!data &&
    typeof data === "object" &&
    !Array.isArray(data) &&
    Object.values(data).length > 0
  ) {
    return Object.values(data).reduce((total, tab) => (total += tab), 0);
  }
  return 0;
};

export const returnTab = data => {
  let newVal = null;
  for (let tab of listingDetailTabs) {
    if (data[tab] > 0) {
      newVal = tab;
      break;
    }
  }
  return newVal;
};

const ListingDetailCountProvider = ({
  setCount,
  count,
  recallCount = function() {},
  children
}) => {
  return (
    <ListingDetailCountContext.Provider
      value={{
        recallCount,
        count,
        setCount,
        totalCount: getTotalCount(count)
      }}
    >
      {children}
    </ListingDetailCountContext.Provider>
  );
};

export default ListingDetailCountProvider;
