import React, { useState } from "react";

export const ProcessContext = React.createContext({
  processStatus: "completed",
  setProcess: function() {}
});

const ListingDetailProcessProvider = ({ children }) => {
  const [processStatus, setProcess] = useState("completed");

  return (
    <ProcessContext.Provider value={{ processStatus, setProcess }}>
      {children}
    </ProcessContext.Provider>
  );
};

export default ListingDetailProcessProvider;
