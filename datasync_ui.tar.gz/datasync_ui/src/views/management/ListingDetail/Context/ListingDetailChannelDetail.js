import React, { useState } from "react";
import { useSelector } from "react-redux";

export const ListingDetailChannelDetailContext = React.createContext({
  channelDetail: {
    channelType: "",
    channelID: ""
  },
  channelType: "",
  channelID: "",
  setChannelDetail: function() {},
  channelSetting: {}
});
// Channel for product api.
// This count api can be called many times due to clicking on channels repeatedly.
// Prevent render table of product render many times because channel type.
// Waiting for count call success. after that, set channel detail
const ListingDetailChannelDetailProvider = ({ children }) => {
  const [channelDetail, setChannelDetail] = useState({});
  const channel = useSelector(state => state.listing.listings);
  const channelSetting = channel.find(item => item.id === channelDetail?.id);

  return (
    <ListingDetailChannelDetailContext.Provider
      value={{
        channelDetail,
        setChannelDetail,
        channelType: channelDetail?.type,
        channelID: channelDetail?.id,
        channelSetting
      }}
    >
      {children}
    </ListingDetailChannelDetailContext.Provider>
  );
};

export default ListingDetailChannelDetailProvider;
