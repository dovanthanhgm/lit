import React, { useContext, useEffect, useMemo, useState } from "react";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { useIsChannelInMarketplaces } from "src/hooks/index";
import useTemplate from "src/hooks/useTemplate";
import { useSelector } from "react-redux";

const etsyColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" },
  category: {
    label: "Category",
    value: "template_data.category.category.name",
    isShow: false,
    name: "category"
  },
  section: {
    label: "Section",
    value: "template_data.category.advance.section",
    isShow: true,
    name: "section"
  },
  shipping_profile: {
    label: "Shipping Profile",
    value: "template_data.shipping.shipping_id",
    isShow: false,
    name: "shipping_profile"
  },
  return_policy: {
    label: "Return Policy",
    value: "template_data.shipping.policy_id",
    isShow: false,
    name: "return_policy"
  }
};

const amazonColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" },
  asin: { label: "ASIN", value: "asin", isShow: true, name: "asin" },
  gtin: { label: "GTIN", value: "gtin", isShow: true, name: "gtin" },
  ean: { label: "EAN", value: "ean", isShow: false, name: "ean" },
  upc: { label: "UPC", value: "upc", isShow: false, name: "upc" },
  isbn: { label: "ISBN", value: "isbn", isShow: false, name: "isbn" },
  mpn: { label: "MPN", value: "mpn", isShow: false, name: "mpn" },
  msrp: {
    label: "MSRP",
    value: "template_data.price.msrp.price",
    isShow: true,
    name: "msrp"
  },
  map: {
    label: "MAP",
    value: "template_data.price.map.price",
    isShow: true,
    name: "map"
  },
  fulfillment: {
    label: "Fulfillment",
    value: "fulfillment",
    isShow: true,
    name: "fulfillment"
  },
  condition: {
    label: "Condition",
    value: "template_data.shipping.policy_id",
    isShow: false,
    name: "condition"
  }
};

const walmartColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" },
  gtin: { label: "GTIN", value: "gtin", isShow: true, name: "gtin" },
  upc: { label: "UPC", value: "upc", isShow: false, name: "upc" },
  wpid: { label: "WPID", value: "wpid", isShow: false, name: "wpid" },
  category: {
    label: "Category",
    value: "template_data.category.category.name",
    isShow: true,
    name: "category"
  },
  walmart_center: {
    label: "Walmart Center",
    value: "template_data.shipping.fulfillment_id",
    isShow: true,
    name: "walmart_center"
  },
  walmart_3pl: {
    label: "Walmart 3PL",
    value: "template_data.shipping.shipping_id",
    isShow: true,
    name: "walmart_3pl"
  }
};

const ebayColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" },
  sale_price: {
    label: "Sale Price",
    value: "sale_price",
    isShow: true,
    name: "sale_price"
  },
  ePID: { label: "ePID", value: "epid", isShow: false, name: "ePID" },
  upc: { label: "UPC", value: "upc", isShow: true, name: "upc" },
  ean: { label: "EAN", value: "ean", isShow: false, name: "ean" },
  mpn: { label: "MPN", value: "mpn", isShow: false, name: "mpn" },
  ispn: { label: "ISPN", value: "ispn", isShow: false, name: "ispn" },
  brand: { label: "Brand", value: "brand", isShow: false, name: "brand" },
  category: {
    label: "Category",
    value: "template_data.category.primary_category.category_name",
    isShow: false,
    name: "category"
  },
  store_category_1: {
    label: "Store Category 1",
    value: "template_data.category.store_category_1.category_name",
    isShow: false,
    name: "store_category_1"
  },
  store_category_2: {
    label: "Store Category 2",
    value: "template_data.category.store_category_2.category_name",
    isShow: false,
    name: "store_category_2"
  },
  listing_format: {
    label: "Listing Format",
    value: "template_data.category.listing_type",
    isShow: false,
    name: "listing_format"
  }
  //api call by category id // => call api for 100 item
  // condition: {
  //   label: "Condition",
  //   value: "template_data.shipping.policy_id",
  //   isShow: false,
  //   name: "condition"
  // }
};

const googleColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  sale_price: {
    label: "Sale Price",
    value: "sale_price",
    isShow: true,
    name: "sale_price"
  },
  price: { label: "Price", value: "price", isShow: true, name: "price" }
};

const wixColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" },
  sale_price: {
    label: "Sale Price",
    value: "sale_price",
    isShow: true,
    name: "sale_price"
  },
};

const reverbColumn = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  upc: { label: "UPC", value: "upc", isShow: true, name: "upc" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" },
  brand: { label: "Brand", value: "brand", isShow: true, name: "brand" },
  model: { label: "Model", value: "model", isShow: true, name: "model" }
};

const defaultValue = {
  title: { label: "Title", value: "name", isShow: true, name: "title" },
  sku: { label: "SKU", value: "sku", isShow: true, name: "sku" },
  quantity: { label: "Quantity", value: "qty", isShow: true, name: "quantity" },
  price: { label: "Price", value: "price", isShow: true, name: "price" }
};

const channelHeader = channelType => {
  const channel = {
    etsy: etsyColumn,
    ebay: ebayColumn,
    amazon: amazonColumn,
    walmart: walmartColumn,
    google: googleColumn,
    reverb: reverbColumn,
    wix: wixColumn
  };

  return channel?.[channelType] ? channel[channelType] : defaultValue;
};

export const ListingDetailTableContext = React.createContext({
  tableHeader: defaultValue,
  setTableHeader: function() {},
  tableHeaderTemplate: {},
  setTableHeaderTemplate: function() {},
  templatesTitle: {}
});

const ListingDetailTableProvider = ({ children }) => {
  const { channelType, channelID } = useContext(
    ListingDetailChannelDetailContext
  );

  const { isChannelInMarketplaces } = useIsChannelInMarketplaces({
    channelType
  });

  const templatesTitle = useTemplate({ channelType, channelID })
    .allChannelTemplatesTitle;

  const arrayKeyTemplatesTitle = useMemo(() => {
    if (templatesTitle) {
      return isChannelInMarketplaces
        ? Object.keys(templatesTitle).filter(item => item !== "recipes")
        : [];
    }
    return [];
  }, [templatesTitle, isChannelInMarketplaces]);

  const dataColumn = useSelector(state => state.listing.listingColumn);
  const dataColumnChannelID = dataColumn?.[`channel_${channelID}`];
  const headerRedux = dataColumnChannelID?.header;
  const headerTemplateRedux = dataColumnChannelID?.headerTemplate;

  const [tableHeader, setTableHeader] = useState({});
  const [tableHeaderTemplate, setTableHeaderTemplate] = useState({});

  useEffect(() => {
    setTableHeader(headerRedux || channelHeader(channelType));
    // eslint-disable-next-line
  }, [channelType, channelID]);

  useEffect(() => {
    setTableHeaderTemplate(
      headerTemplateRedux ||
        arrayKeyTemplatesTitle.reduce((prev, curr) => {
          prev[curr] = {
            label: templatesTitle?.[curr],
            isShow: true,
            value: curr
          };

          return prev;
        }, {})
    );
    // eslint-disable-next-line
  }, [channelID]);

  return (
    <ListingDetailTableContext.Provider
      value={{
        tableHeader,
        objectTableHeader: tableHeader,

        setTableHeader,
        tableHeaderTemplate,
        setTableHeaderTemplate,
        templatesTitle
      }}
    >
      {children}
    </ListingDetailTableContext.Provider>
  );
};

export default ListingDetailTableProvider;
