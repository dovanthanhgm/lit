import React, { useCallback, useContext, useEffect, useState } from "react";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import {
  ACTIVE_VALUE,
  DRAFT_VALUE,
  ERROR_VALUE,
  LISTING_EDIT_PRODUCT_ID
} from "src/constants/Listing/index";
import { useSelector } from "react-redux";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { cloneDeep } from "lodash";

export const ListingDetailTableSelectedProductContext = React.createContext({
  selectedItems: [],
  setSelectedItems: function() {},
  onClearData: function() {},
  handleChangeStatus: function() {},
  handleChangeLinkStatus: function() {},
  handleSelectOneItem: function() {},
  handleSelectAllItems: function() {},
  selectWithShiftHeld: () => {},
  setLastSelectedRow: () => {}
});

const ListingDetailTableSelectedProductProvider = ({ children }) => {
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const { listingData, setListingData } = useContext(
    ListingDetailProductsContext
  );
  const channelID = channelDetail.channelID;
  const currentTab = useSelector(
    state => state.listing.listingDetail.currentTab
  );

  const [selectedItems, setSelectedItems] = useState([]);
  const [shiftHeld, setShiftHeld] = useState(false);
  const [lastSelectedRow, setLastSelectedRow] = useState(-1)

  useEffect(() => {
     function downHandler({ key }) {
        if (key === 'Shift') {
           setShiftHeld(true);
        }
     }

     function upHandler({ key }) {
        if (key === 'Shift') {
           setShiftHeld(false);
        }
     }
     document.addEventListener('keydown', downHandler);
     document.addEventListener('keyup', upHandler);
     return () => {
        document.removeEventListener('keydown', downHandler);
        document.removeEventListener('keyup', upHandler);
     };
  }, []);

  const handleChangeStatus = useCallback(selectedItems => {
    setListingData(prevState =>
      prevState.map(elem => {
        // eslint-disable-next-line
        if (selectedItems.id.some(item => item == elem.publish_id)) {
          if ([DRAFT_VALUE, ERROR_VALUE].includes(elem?.channel_status)) {
            return {
              ...elem,
              error_message: "",
              publish_status: selectedItems?.status,
              publish_action: selectedItems?.status
            };
          } else {
            return {
              ...elem,
              publish_action: selectedItems?.status,
              publish_status:
                elem?.channel_status === ACTIVE_VALUE
                  ? selectedItems?.status
                  : ""
            };
          }
        } else {
          return elem;
        }
      })
    );
    // eslint-disable-next-line
  }, []);

  const handleChangeLinkStatus = status => {
    const setLinkStatus = items => {
      const isSelected = selectedItems.includes(items.publish_id);
      if (isSelected) {
        return {
          ...items,
          link_status: status
        };
      } else {
        return items;
      }
    };

    setListingData(products => products.map(setLinkStatus));
  };

  const handleSelectOneItem = useCallback(({ item, isSelected, rowNumber }) => {
    const itemId = item["publish_id"];
    setLastSelectedRow(rowNumber)
    if (!isSelected) {
      setSelectedItems(prevSelected => [...prevSelected, itemId]);
    } else {
      setSelectedItems(prevSelected =>
        prevSelected.filter(id => id !== itemId)
      );
    }
  }, []);

  const handleSelectAllItems = useCallback(
    event => {
      if (event.target.checked) {
        setSelectedItems(
          listingData?.map(item => item[LISTING_EDIT_PRODUCT_ID])
        );
      } else {
        setLastSelectedRow(-1)
        setSelectedItems([]);
      }
    },
    [listingData]
  );

  const onClearData = () => {
    setSelectedItems([]);
  };

  const selectWithShiftHeld = (rowNumber, checked) => {
     if (
        !shiftHeld ||
        rowNumber === lastSelectedRow ||
        selectedItems === listingData.length ||
        lastSelectedRow === -1
     )
        return;

     let _selected = cloneDeep(selectedItems);

     const shiftSelected =
        rowNumber > lastSelectedRow
           ? listingData.slice(lastSelectedRow, rowNumber + 1)
           : listingData.slice(rowNumber, lastSelectedRow + 1); //Because slice doesnt take the second index element into the new Array


     const shiftSelectedIds = shiftSelected.map(selected => selected.publish_id);

     const isUnchecked = shiftSelectedIds.some(id => !_selected.includes(id)); // checking whether the new Ids havent been checked by seeing if the selected ones don't includes all the new ones

     let _newSelected = [];

     if (!isUnchecked) {
        _newSelected = _selected.filter(selected => !shiftSelectedIds.includes(selected));

        let _lastSelected = rowNumber;

        if (_newSelected.length !== 0)
           _lastSelected = rowNumber > lastSelectedRow ? rowNumber + 1 : rowNumber - 1;
        // When the new length is 0, the last select index is equal to the rowNumber
        /* When it's not, we consider the new index and the last index, if the new one is bigger, it means that we have to check those ones
        that are under, we need to add 1 to last selectedRow, so that when we get the new shiftSelected items, it would only get the items that 
        are not already previously selected. Same goes to the above items.
        But still, I highly recommend you read the logic and log it out step to step to fully understand it */

        setLastSelectedRow(() => _lastSelected);
     } else {
        if (checked) _newSelected = [...new Set([..._selected, ...shiftSelectedIds])];
        else _newSelected = _selected.filter(selected => !shiftSelectedIds.includes(selected));
        setLastSelectedRow(() => rowNumber);
     }

     setSelectedItems(() => _newSelected);
  };

  useEffect(() => {
    setSelectedItems([]);
    setLastSelectedRow(-1)
  }, [currentTab, channelID]);

  return (
    <ListingDetailTableSelectedProductContext.Provider
      value={{
        selectedItems,
        setSelectedItems,
        onClearData,
        handleChangeStatus,
        handleChangeLinkStatus,
        handleSelectAllItems,
        handleSelectOneItem,
        selectWithShiftHeld,
        setLastSelectedRow
      }}
    >
      {children}
    </ListingDetailTableSelectedProductContext.Provider>
  );
};

export default ListingDetailTableSelectedProductProvider;
