import {
  PLUS_TIMES_ACTION,
  PULLING_STATUS,
  PUSHING_STATUS
} from "src/views/management/ListingDetail/Constant/index";

export const isStatusProcessActive = status => {
  return [PULLING_STATUS, PUSHING_STATUS].includes(status);
};

export const driverItem = ({ time, max, callStatus }) => ({
  call: callStatus,
  delay: time,
  max
});

export const driverItemTime = ({ currentLimit = 5, type = "", number }) => ({
  call: currentLimit - number > 0,
  max:
    type === PLUS_TIMES_ACTION ? currentLimit + number : currentLimit - number
});

export const handleSetDriverValue = (prevState = {}, driverItem = {}) => ({
  ...prevState,
  ...driverItem
});
