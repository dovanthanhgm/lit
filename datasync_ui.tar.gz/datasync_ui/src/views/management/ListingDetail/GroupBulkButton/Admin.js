import { Box, Typography } from "@material-ui/core";
import { useSnackbar } from "notistack";
import React, { useContext } from "react";
import { useDispatch } from "react-redux";
import { SILENT_LOGIN } from "src/actions/accountActions";
import ButtonDelete from "src/components/Button/ButtonDelete";
import ButtonCustom from "src/components/MUI/Button";
import { getUserInfo } from "src/services/account";
import authService from "src/services/authService";
import { deleteAllProductsChannelAPI } from "src/services/channel";
import { messageError } from "src/utils/ErrorResponse";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";

function AdminButtons() {
  const { enqueueSnackbar } = useSnackbar();
  const loginByToken = authService.getLoginByToken();
  const dispatch = useDispatch();

  const { channelID } = useContext(ListingDetailChannelDetailContext);
  const { recallCount } = useContext(ListingDetailCountContext);

  const getUser = async () => {
    const userData = await getUserInfo();
    if (userData) {
      dispatch({
        type: SILENT_LOGIN,
        payload: {
          user: userData
        }
      });
    }
  };

  const handleConfirmDeleteAll = async () => {
    try {
      await deleteAllProductsChannelAPI({ channelId: channelID });
      enqueueSnackbar("Delete success", {
        variant: "success"
      });
      // add loading payload for dispatch action
      recallCount();

      const timer = setTimeout(() => getUser(), 5000);
      return () => clearTimeout(timer);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  const handleClickViewAdmin = () => {
    window.open(
      `${process.env?.REACT_APP_API_URL ||
        "https://api.litcommerce.com"}/admin/channels/process/?channel__id__exact=${channelID}`,
      "_blank"
    );
  };

  if (!loginByToken) return null;

  return (
    <Box ml={1.5} display={"flex"} alignItems={"center"}>
      <ButtonDelete
        buttonText="Channel Delete All"
        handleConfirm={handleConfirmDeleteAll}
        headerDialog="Are you sure?"
        contentDialog={
          <Typography color="textPrimary" variant="body1">
            Are you sure you want to remove all products?
          </Typography>
        }
        buttonTextSubmit="Yes, Remove"
      />

      <Box mx={1}>
        <ButtonCustom
          text="View in admin"
          color="primary"
          onClick={handleClickViewAdmin}
        />
      </Box>
    </Box>
  );
}

export default AdminButtons;
