import React, { useContext } from "react";
import ListingOption from "src/components/Listings/ListingOption";
import { useSelector } from "react-redux";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";

const ListingGroupOption = ({
  actionSelect,
  disabled = false,
  handleChangeAction = function() {},
  disableByWalmartTime = false,
  selectedItems
}) => {
  const { currentTab } = useSelector(state => state?.listing?.listingDetail);
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);

  return (
    <ListingOption
      handleChangeAction={handleChangeAction}
      disabled={disabled}
      selectedItems={selectedItems}
      disableByWalmartTime={disableByWalmartTime}
      actionSelect={actionSelect}
      channelDetail={channelDetail}
      currentTab={currentTab}
    />
  );
};

export default ListingGroupOption;
