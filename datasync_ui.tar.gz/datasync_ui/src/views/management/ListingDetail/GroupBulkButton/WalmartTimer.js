import React from "react";
import { Box, Link, Tooltip, Typography } from "@material-ui/core";
import HelpIcon from "@material-ui/icons/Help";
import useWalmartTimer from "src/views/channel/Walmart/Hooks/useWalmartTimer";

const WalmartTimer = () => {
  const { countDown, walmart_waiting, isNumber, isPast } = useWalmartTimer();

  if (
    !walmart_waiting ||
    countDown === "Invalid date" ||
    countDown === "1" ||
    !isNumber ||
    isPast
  ) {
    return null;
  }

  return (
    <Box mx={1} display={"flex"} alignItems={"center"}>
      <Typography variant={"body2"}>
        Publishing to Walmart will be re-enabled in {countDown}
      </Typography>
      <Tooltip
        interactive
        title={
          <>
            Publishing to Walmart is temporarily locked due to{" "}
            <Link
              href={
                "https://help.litcommerce.com/en/article/walmart-api-limits-2nlihn/"
              }
              style={{
                color: "deepskyblue"
              }}
              target={"_blank"}
            >
              exceeding Walmart API limit
            </Link>
            . You should wait a few minutes for replenishment and button Run
            re-enabled.
          </>
        }
      >
        <Box display={"flex"} px={0.5}>
          <HelpIcon fontSize={"small"} color={"primary"} />
        </Box>
      </Tooltip>
    </Box>
  );
};

export default WalmartTimer;
