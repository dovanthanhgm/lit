import React, { useContext, useEffect, useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import { Box } from "@material-ui/core";
import DialogTitle from "src/components/Modal/DialogTitle";
import { makeStyles } from "@material-ui/styles";
import { FilterSection } from "src/views/management/MainStore/DefaultMainStore/Body/FIlter/ColumnManager";
import wait from "src/utils/wait";
import { useDispatch, useSelector } from "react-redux";
import { setListingColumn } from "src/actions/listingActions";
import {
  handleSetLocalValue,
  listingFilterStore
} from "src/helper/handleLocalstorageValue";

const defaultTableHeaderGroup = {
  product_field: ["title", "sku", "quantity", "price"]
};

const etsyTableHeaderGroup = {
  product_field: ["title", "sku", "quantity", "price"],
  category_field: ["category", "section"],
  shipping_field: ["shipping_profile", "return_policy"]
};

const ebayTableHeaderGroup = {
  product_field: ["title", "quantity"],
  pricing_field: ["price", "sale_price"],
  category_field: [
    "category",
    "store_category_1",
    "store_category_2",
    "listing_format"
  ],
  identifier_field: ["ePID", "sku", "upc", "ean", "mpn", "ispn", "brand"]
};

const googleTableHeaderGroup = {
  product_field: ["title", "sku", "quantity"],
  pricing_field: ["price", "sale_price"]
};
const wixTableHeaderGroup = {
  product_field: ["title", "sku", "quantity"],
  pricing_field: ["price", "sale_price"]
};

const reverbTableHeaderGroup = {
  product_field: ["title", "sku", "upc", "quantity", "price", "brand", "model"]
};

const amazonTableHeaderGroup = {
  product_field: ["title"],
  identifier_field: ["sku", "asin", "gtin", "ean", "isbn", "upc", "mpn"],
  pricing_field: ["price", "msrp", "map"],
  offer_field: ["quantity", "condition", "fulfillment"]
};

const walmartTableHeaderGroup = {
  product_field: ["title", "quantity", "price"],
  identifier_field: ["sku", "wpid", "gtin", "upc"],
  category_field: ["category"],
  shipping_field: ["walmart_center", "walmart_3pl"]
};

const channelCardHeader = {
  product_field: "Product Fields",
  pricing_field: "Pricing Fields",
  category_field: "Category Fields",
  shipping_field: "Shipping Fields",
  identifier_field: "Identifier Fields",
  offer_field: "Offer Fields"
};

const channelsHeaderField = channelType => {
  const channel = {
    etsy: etsyTableHeaderGroup,
    ebay: ebayTableHeaderGroup,
    amazon: amazonTableHeaderGroup,
    walmart: walmartTableHeaderGroup,
    google: googleTableHeaderGroup,
    reverb: reverbTableHeaderGroup,
    wix: wixTableHeaderGroup
  };

  if (channel?.[channelType]) {
    return channel[channelType];
  }
  return defaultTableHeaderGroup;
};

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.grey["100"],
    padding: theme.spacing(1)
  }
}));

const matchHeaderField = (header = [], data = [], initData = []) => {
  let _headerGroup = initData;
  data.forEach(item => {
    _headerGroup = [..._headerGroup, header[item]];
  });

  return _headerGroup;
};

const ManageTableColumnButton = ({ channelType, channelID }) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const {
    tableHeader,
    setTableHeader,
    tableHeaderTemplate,
    setTableHeaderTemplate
  } = useContext(ListingDetailTableContext);
  const { listingStyle } = useSelector(state => state.listing);


  const [open, setOpen] = React.useState(false);
  const [header, setHeader] = useState({});
  const [headerTemplate, setHeaderTemplate] = useState({});

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = column => {
    const newHeader = JSON.parse(JSON.stringify(header));
    newHeader[column].isShow = !newHeader[column].isShow;
    setHeader(newHeader);
  };

  useEffect(() => {
    setHeader(tableHeader);
  }, [tableHeader]);

  const handleChangeTemplate = column => {
    const newHeader = JSON.parse(JSON.stringify(headerTemplate));
    newHeader[column].isShow = !newHeader[column].isShow;
    setHeaderTemplate(newHeader);
  };

  const handleSubmit = async () => {
    //prevent lagging
    await wait(500);
    setTableHeader(header);
    setTableHeaderTemplate(headerTemplate);
  };

  const handleStoreColumn = () => {
    const localPath = listingFilterStore(channelID);
    dispatch(
      setListingColumn({
        [`channel_${channelID}`]: {
          header,
          headerTemplate
        }
      })
    );
    handleSetLocalValue({
      value: {
        header,
        headerTemplate
      },
      pathValue: localPath
    });
  };

  const headerSection = () => {
    return Object.keys(channelsHeaderField(channelType)).reduce(
      (prev, curr) => {
        prev[curr] = matchHeaderField(
          header,
          channelsHeaderField(channelType)[curr],
          prev?.[curr]
        );
        return prev;
      },
      {}
    );
  };

  useEffect(() => {
    setHeaderTemplate(tableHeaderTemplate);
  }, [tableHeaderTemplate]);

  if (!Object.keys(tableHeader).length) {
    return null;
  }

  return (
    <div>
      <Button
        variant="contained"
        color="primary"
        onClick={handleClickOpen}
        size={"small"}
        disabled={listingStyle === 'grid'}
      >
        Columns
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle onClose={handleClose}>Hide/Show Columns</DialogTitle>
        <DialogContent className={classes.root}>
          {Object.keys(headerSection()).map(group => {
            return (
              <Box my={1} key={group}>
                <FilterSection
                  handleSetShowColumns={handleChange}
                  fields={headerSection()[group]}
                  header={channelCardHeader[group]}
                />
              </Box>
            );
          })}
          <Box my={1}>
            <FilterSection
              handleSetShowColumns={handleChangeTemplate}
              fields={headerTemplate}
              header={"Templates"}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button
            onClick={() => {
              handleClose();
              handleStoreColumn();
              handleSubmit().catch(e => {
                console.log(e);
              });
            }}
            color="primary"
            autoFocus
          >
            Ok
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ManageTableColumnButton;
