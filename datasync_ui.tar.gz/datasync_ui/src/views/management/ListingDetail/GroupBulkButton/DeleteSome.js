import { Box, Typography } from "@material-ui/core";
import { useSnackbar } from "notistack";
import React from "react";
import Dialog from "src/components/MUI/Dialog";
import { useGetChannelDetail } from "src/hooks/Listing/useProductListingHook";
import { deleteSomeProductsChannelAPI } from "src/services/channel";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";
import { messageError } from "src/utils/ErrorResponse";

function DeleteSome({
  selectedItems,
  onDeleteSomeSuccess,
  setOpenDeleteSelected,
  openDeleteSelected,
  setDisableButton,
  setActionSelect,
  channelID: channelIDProps
}) {
  const { enqueueSnackbar } = useSnackbar();
  const { type: channelType, id: channelIDHook } = useGetChannelDetail();
  const channelID = channelIDProps || channelIDHook;

  const handleConfirmDeleteSome = async () => {
    try {
      setActionSelect("");
      setDisableButton(true);
      await deleteSomeProductsChannelAPI({
        channelId: channelID,
        ids: selectedItems
      });
      onDeleteSomeSuccess();
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
    setDisableButton(false);
  };

  return (
    <Box ml={0.5}>
      <Dialog
        open={openDeleteSelected}
        handleClose={() => setOpenDeleteSelected(false)}
        header="Are you sure?"
        content={
          <>
            <Typography color="textPrimary" variant="body1">
              Delete this listing will remove it from this channel on
              LitCommerce, but will NOT delete on{" "}
              {capitalizeFirstLetter(channelType)} or Main Store. Are you sure
              want to delete this listing? This action cannot be undone.
            </Typography>
          </>
        }
        maxWidth={"md"}
        handleConfirm={handleConfirmDeleteSome}
        nameButton="Delete"
      />
    </Box>
  );
}

export default DeleteSome;
