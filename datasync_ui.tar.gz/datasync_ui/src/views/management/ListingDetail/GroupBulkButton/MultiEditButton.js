import React, { useContext } from "react";
import useListingFilterMulti from "src/hooks/Listing/useListingFilterMulti";
import { channelMultiEdit } from "src/constants/Listing/index";
import ButtonCustom from "src/components/MUI/Button";
import { Box } from "@material-ui/core";
import ViewListIcon from "@material-ui/icons/ViewList";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import { redirectUrl } from "src/views/management/MultyEdit/hooks/Filter";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";

const MultiEditButton = () => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { urlSearchParam } = useListingFilterMulti();
  const { channelID, channelType } = useContext(
    ListingDetailChannelDetailContext
    );

  if (!channelMultiEdit.includes(channelType)) {
    return null;
  }

  return (
    <ButtonCustom
      style={{ whiteSpace: "nowrap", minWidth: 156 }}
      text={
        <Box display="flex" alignItems="center">
          <ViewListIcon fontSize="small" />
          <span style={{ marginLeft: 4 }}>Multi Edit Mode</span>
        </Box>
      }
      color="primary"
      onClick={() => {
        dispatch(
          setFieldListingDetailAction({
            loadingProduct: false,
            listProducts: [],
            firstLoading: true,
            loadingCountProduct: true
          })
        );
        history.push(`${channelID}/multi-edit${redirectUrl(urlSearchParam)}`);
      }}
      notShowCircle
    />
  );
};

export default MultiEditButton;
