import { useState, useEffect } from "react";

export function usePublish() {
  const [isPublish, setIsPublish] = useState(false);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (isPublish) {
        setIsPublish(false);
      }
    }, 20000);
    return () => {
      clearTimeout(timeout);
    };
  }, [isPublish]);

  return {
    isPublish,
    setIsPublish
  };
}
