import React, { useCallback, useContext, useMemo, useState } from "react";
import {
  Box,
  ListSubheader,
  makeStyles,
  MenuItem,
  MenuList,
  Tooltip,
  Typography
} from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import ModalApplyConfirm from "src/views/management/ListingDetail/ModalApplyConfirm";
import {
  DRAFT_VALUE,
  ERROR_VALUE,
  groupButtonItemPadding
} from "src/constants/Listing/index";
import { useIsChannelInMarketplaces } from "src/hooks";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";
import { postTemplateChannelTypeAPI } from "src/services/channel";
import { useSnackbar } from "notistack";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { ListingDetailApiDriver } from "src/views/management/ListingDetail/Context/ListingDetailApiDriver";
import {
  DEFAULT_PRODUCT_API_LISTING_DELAY,
  LISTING_DETAIL_APPLY_TEMPLATE_DELAY
} from "src/views/management/ListingDetail/Constant/index";
import useTemplate from "src/hooks/useTemplate";
import ModalApplySuccess, {
  LOCAL_PATH_SHOW_MODAL
} from "src/views/management/ListingDetail/ModalApplySuccess";
import ApplyTemplateModal201 from "src/views/management/ListingDetail/components/ListingModal/ApplyTemplateModal";
import ButtonMenuCustom from "src/components/MUI/ButtonMenu";
import { setToolTipRunningProcess } from "src/actions/accountActions";
import wait from "src/utils/wait";

const useStyles = makeStyles(theme => ({
  select: {
    width: 230,
    "& .MuiSelect-root": { paddingTop: 8.5, paddingBottom: 8.5 },
    "& .MuiMenu-list": {
      paddingRight: 0
    },
    "& .MuiOutlinedInput-input": {
      paddingLeft: 4
    }
  },
  templateName: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  rootScroll: {
    "&::-webkit-scrollbar": {
      width: "0.6em"
    },
    "&::-webkit-scrollbar-track": {
      boxShadow: "inset 0 0 6px rgba(0,0,0,0.00)",
      webkitBoxShadow: "inset 0 0 6px rgba(0,0,0,0.00)"
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: "rgba(0,0,0,.3)",
      borderRadius: 10
    }
  }
}));

const SelectGroup = ({
  title,
  data,
  classes,
  templateList,
  onChange = function() {}
}) => {
  if (data.length === 0) return null;

  return [
    <ListSubheader
      disableGutters={false}
      color="inherit"
      disableSticky
      key={title}
    >
      <Box px={0} py={1}>
        <Typography variant="h6" style={{ color: "#757575" }}>
          {templateList?.[title] || ""}
        </Typography>
      </Box>
    </ListSubheader>,
    data.map(templates => {
      const isShowToolTip = templates?.name && templates?.name?.length > 27;
      return (
        <MenuItem
          value={templates.id}
          key={templates.id}
          onClick={() => onChange(templates)}
        >
          <Tooltip title={isShowToolTip ? templates?.name : "" || ""}>
            <Box key={templates.id} width={260} pl={groupButtonItemPadding}>
              <Typography variant="body2" className={classes.templateName}>
                {templates?.name || ""}
              </Typography>
            </Box>
          </Tooltip>
        </MenuItem>
      );
    })
  ];
};

const ApplyTemplatesComponent = ({ channelDetail }) => {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const { channelType, channelID } = channelDetail;

  const showModalSuccess = !!localStorage.getItem(LOCAL_PATH_SHOW_MODAL);

  const { selectedItems, setSelectedItems: setSelected } = useContext(
    ListingDetailTableSelectedProductContext
  );
  const templateList = useTemplate({ channelID, channelType })
    .channelTemplateName;

  const { recallProduct } = useContext(ListingDetailProductsContext);
  const { listingApiDriver } = useContext(ListingDetailApiDriver);
  //
  const listingDetailGetProduct = () => {
    recallProduct();
    listingApiDriver.count.start();
    listingApiDriver.product.start(DEFAULT_PRODUCT_API_LISTING_DELAY, 6);
  };

  const listingDetailApplyProduct = () => {
    recallProduct();
    listingApiDriver.count.start();
    listingApiDriver.product.start(LISTING_DETAIL_APPLY_TEMPLATE_DELAY, 5);
  };

  const { currentTab } = useSelector(state => state.listing.listingDetail);
  const { listTemplates } = useSelector(state => state.templates);

  const disabled = selectedItems.length === 0;

  const [template, setTemplate] = useState("");
  const [templateInfo, setTemplateInfo] = useState(null);
  const [applySuccess, setApplySuccess] = useState(false);
  const [open, setOpen] = useState(false);
  const [openWaitModal, setOpenWaitModal] = useState(false);

  const { channelSetting } = useContext(ListingDetailChannelDetailContext);
  const isClearSelectedProduct =
    channelSetting?.settings?.other_setting?.clear_selected === "enable";

  const setSelectedItems = () => {
    if (isClearSelectedProduct) {
      setSelected([]);
    }
  };

  const handleCloseModal = () => {
    setTemplate("");
    setTemplateInfo(null);
  };

  const handleConfirmApplyTemplate = useCallback(
    async ({ selectedItems, template, setTemplate }) => {
      setTemplate();
      const res = await postTemplateChannelTypeAPI({
        channelType,
        channelId: channelID,
        templateType: template.type,
        templateId: template.id,
        ids: selectedItems
      });
      if (res) {
        const isCodeWait = res?.code === "wait" || res?.data?.code === "wait";
        setApplySuccess(currentTab);
        setSelectedItems();

        if (isCodeWait) {
          setOpenWaitModal(true);
          listingDetailApplyProduct();
          await wait(2000);
          dispatch(
            setToolTipRunningProcess(
              "Click here to see current running processes"
            )
          );
        } else {
          listingDetailGetProduct();
        }
        enqueueSnackbar("Success", {
          variant: "success"
        });
      } else {
        enqueueSnackbar("Something went wrong", {
          variant: "error"
        });
      }
    },
    // eslint-disable-next-line
    [listingDetailGetProduct, channelDetail]
  );

  const handleConfirmApply = () => {
    // onClearData();
    handleConfirmApplyTemplate({
      template: templateInfo,
      setTemplate: handleCloseModal,
      selectedItems
    });
  };

  const handleChangeTemplate = event => {
    const value = event;
    setOpen(false);

    if (![undefined, null].includes(value?.id)) {
      setTemplate(value.id);
      setTemplateInfo(value);
    }
  };

  const listTemplatesKeys = Object.keys(listTemplates);

  const templateByTitle = useMemo(() => {
    const templates = JSON.parse(JSON.stringify(listTemplates));
    if (currentTab === "active" && channelType === "facebook") {
      delete templates.shipping;
    }
    return templates;
  }, [listTemplates, channelType, currentTab]);

  return (
    <>
      <ApplyTemplateModal201 open={openWaitModal} setOpen={setOpenWaitModal} />
      <ModalApplyConfirm
        template={templateInfo}
        handleClose={handleCloseModal}
        handleConfirm={handleConfirmApply}
      />
      {!showModalSuccess && (
        <ModalApplySuccess
          open={
            !!applySuccess && ![ERROR_VALUE, DRAFT_VALUE].includes(applySuccess)
          }
          setOpen={setApplySuccess}
        />
      )}
      {listTemplatesKeys.length > 0 && (
        <>
          <ButtonMenuCustom
            open={open}
            setOpen={setOpen}
            title={
              <Typography
                component={"span"}
                variant="body2"
                style={{ fontSize: "0.8125rem", fontWeight: 500 }}
              >
                {!template ? "Apply Template(s)" : templateInfo.name}
              </Typography>
            }
            disabled={disabled}
            style={{ padding: "2.375px 5px 2.375px 10px" }}
          >
            <MenuList>
              {Object.keys(templateByTitle).map(title => {
                return SelectGroup({
                  title,
                  channelType,
                  classes,
                  templateList,
                  onChange: handleChangeTemplate,
                  data: templateByTitle[title] || []
                });
              })}
            </MenuList>
          </ButtonMenuCustom>
        </>
      )}
    </>
  );
};

const ApplyTemplates = () => {
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);

  const channelType = channelDetail.channelType;

  const { isChannelInMarketplaces } = useIsChannelInMarketplaces({
    channelType
  });
  if (!isChannelInMarketplaces) return null;
  return <ApplyTemplatesComponent channelDetail={channelDetail} />;
};

export default ApplyTemplates;
