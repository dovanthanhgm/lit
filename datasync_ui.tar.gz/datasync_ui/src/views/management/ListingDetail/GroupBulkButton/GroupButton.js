import { Box, Typography } from "@material-ui/core";
import { useSnackbar } from "notistack";
import React, { useEffect, useMemo, useState } from "react";
import Dialog from "src/components/MUI/Dialog";
import { alertError } from "src/helper/showErrorMessage";
import {
  channelPublishAPI,
  channelRefreshImage,
  deleteSomeProductsChannelAPI,
  renewListing,
  syncFromChannel,
  unLinkProducts
} from "src/services/channel";
import {
  createProductOnChannel,
  createProductsMarketChannel
} from "src/services/products";
import CreateOnSourceCartDialog from "src/components/Modal/CreateOnSourceCartDialog";
import { handleSquareSpaceCallCreate } from "../../Listing/ListingCallCreate";
import { useDispatch, useSelector } from "react-redux";
import SquareSpaceStoreModal from "src/components/Modal/SquareSpaceStoreModal";
import {
  DRAFT_VALUE,
  ERROR_VALUE,
  LISTING_DETAIL_LIST_ACTION,
  LISTING_EDIT_PRODUCT_ID
} from "src/constants/Listing";
import { getUserInfo } from "src/services/account";
import { SILENT_LOGIN } from "src/actions/accountActions";
import { messageError } from "src/utils/ErrorResponse";
import ListingDetailRun from "src/components/Button/ListingDetailRun";
import MultiEditGroupOption from "src/views/management/MultyEdit/Action/GroupOption";
import { handleMissingProduct } from "src/views/management/ListingDetail/ListingFunction";
import CustomizedDialogs from "src/components/Modal/ModalChannel/ListingDialog";
import { isMissingConditionAction } from "src/helper/handleListingAction";

function GroupButton({
  channelID,
  autoSave = function() {},
  channelType,
  selectedItems = [],
  setSelectedItems,
  currentTab,
  handleChangeStatus,
  cloneList = [],
  setListProduct = function() {},
  getData
}) {
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();

  const defaultListing = useSelector(state => state.listing.defaultListing);
  const marketList = useSelector(state => state.listing.marketplaces);

  const [openDialogStore, setOpenDialogStore] = useState(false);
  const [actionSelect, setActionSelect] = useState("");
  const [openCreateDialog, setOpenCreateDialog] = useState(false);
  const [isOpenDialogDeleteAll, setIsOpenDeleteDialog] = useState(false);
  const [disableActionButton, setDisableButton] = useState(true);
  const [dialogMiss, setDialogMiss] = useState([]);

  const isMainMarket = useMemo(() => {
    return marketList.map(item => item.id).includes(defaultListing.type);
  }, [marketList, defaultListing]);

  const handleCheckItemCondition = ({ type }) => {
    return selectedItems.reduce(
      (prev, curr) => {
        const missingList = prev?.missingInfo || [];
        const createList = prev?.listCreateOnChannel || [];
        const missingArray = prev?.missingArray || [];
        const productSelected = cloneList.find(
          product => product?.[LISTING_EDIT_PRODUCT_ID] === curr
        );
        if (!productSelected) {
          prev = {
            ...prev,
            missingInfo: [...missingList, curr]
          };
        } else {
          const conditionMiss = isMissingConditionAction({ type })?.(
            productSelected
          );
          if (
            (productSelected &&
              handleMissingProduct({
                item: productSelected,
                channelType,
                channelID,
                hasVariant: curr?.variant_count > 0
              })) ||
            conditionMiss
          ) {
            prev = {
              ...prev,
              missingInfo: [...missingList, curr],
              missingArray: [...missingArray, productSelected]
            };
          }
          if (productSelected && !conditionMiss) {
            //prevent current tab in redux lagging/// draft item can call put api
            prev = {
              ...prev,
              itemType: productSelected?.channel_status
            };
          }
          if (productSelected?.link_status === "unlink") {
            prev = {
              ...prev,
              listCreateOnChannel: [
                ...createList,
                productSelected?.[LISTING_EDIT_PRODUCT_ID]
              ]
            };
          }
        }
        return prev;
      },
      {
        missingInfo: [],
        listCreateOnChannel: [],
        missingArray: [],
        itemType: ""
      }
    );
  };

  const handlePublish = async ({
    selectedItems,
    listItemsMiss = [],
    missingArray = [],
    isDraft = false,
    itemType = ""
  }) => {
    const isItemType = itemType !== currentTab ? itemType : currentTab;

    if (listItemsMiss && listItemsMiss?.length > 0) {
      setDialogMiss(missingArray);
    }
    if (selectedItems.length > 0) {
      const listMiss = listItemsMiss.map(product => product);
      const filterMissing = selectedItems.filter(id => {
        return !listMiss.includes(id.toString());
      });
      if (filterMissing.length > 0) {
        setDisableButton(true);
        try {
          const res = await channelPublishAPI({
            channelID,
            product_ids: filterMissing,
            currentTab: isItemType,
            publish_draft: isDraft
          });
          if (res?.code === 200) {
            enqueueSnackbar(
              "Publishing process has started, it will complete in a few secs",
              {
                variant: "success"
              }
            );
            handleChangeStatus({
              id: filterMissing,
              status: [DRAFT_VALUE, ERROR_VALUE].includes(currentTab)
                ? "pushing"
                : "updating"
            });
            setSelectedItems([]);
          }
        } catch (e) {
          setDisableButton(false);
          enqueueSnackbar("Something went wrong", {
            variant: "error"
          });
        }
      } else {
        setDisableButton(false);
        enqueueSnackbar("No product can publish", {
          variant: "warning"
        });
      }
    } else {
      enqueueSnackbar("You need to select at least 1 product", {
        variant: "warning"
      });
    }
  };

  const getUser = async () => {
    const userData = await getUserInfo();
    if (userData) {
      dispatch({
        type: SILENT_LOGIN,
        payload: {
          user: userData
        }
      });
    }
  };

  const onDeleteSomeSuccess = () => {
    handleChangeStatus({ id: selectedItems, status: "delete" });
    enqueueSnackbar("Delete success", {
      variant: "success"
    });
    setDisableButton(true);
    setSelectedItems([]);
    getData();
    setTimeout(() => getUser(), 5000);
  };

  const handleConfirmDeleteSome = async () => {
    try {
      if (channelType === "etsy") {
        await renewListing({
          channel_id: channelID,
          product_ids: selectedItems,
          action: "delete"
        });
      } else {
        await deleteSomeProductsChannelAPI({
          channelId: channelID,
          ids: selectedItems
        });
      }
      onDeleteSomeSuccess();
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  const handleChangeAction = event => {
    setActionSelect(event);
    setDisableButton(selectedItems.length <= 0);
  };

  const handleCloseDeleteDialog = () => {
    setIsOpenDeleteDialog(false);
  };

  const openDeleteAllDialog = () => {
    setIsOpenDeleteDialog(true);
  };

  const handleCloseCrateSourceCart = () => {
    setOpenCreateDialog(false);
  };

  const handleSyncFrom = async () => {
    try {
      //syncSelected have to change when syncName change
      await syncFromChannel({
        productList: selectedItems,
        channelId: channelID
      });
      setSelectedItems([]);
      enqueueSnackbar(
        "Request sent successfully. The products you choose will be synced to LitCommerce in a few minutes",
        {
          variant: "success"
        }
      );
    } catch (e) {
      console.log(e);
      enqueueSnackbar("Error", {
        variant: "error"
      });
    }
  };

  const handleRenewListing = async action => {
    try {
      await renewListing({
        channel_id: channelID,
        product_ids: selectedItems,
        action: action
      });
      handleChangeStatus({ id: selectedItems, status: "renew" });
      setSelectedItems([]);
    } catch (e) {
      console.log("error", e);
    }
  };

  const handleUnlink = async () => {
    try {
      const data = await unLinkProducts({
        channel_id: channelID,
        body: { product_ids: selectedItems }
      });
      if (data) {
        enqueueSnackbar("Success", {
          variant: "success"
        });
        setSelectedItems([]);
        // handleChangeStatus({ id: selectedItems, status: "unlink" });
        if (setListProduct) {
          setListProduct(item =>
            item.map((value, _) => {
              if (selectedItems.includes(value.publish_id)) {
                return {
                  ...value,
                  link_status: "unlink"
                };
              } else {
                return value;
              }
            })
          );
        }
      }
    } catch (e) {
      console.log("errors", e);
      enqueueSnackbar("Error", {
        variant: "error"
      });
    }
  };

  const handleCreateOnDefault = (createList = []) => async storeId => {
    if (createList.length > 0) {
      try {
        setDisableButton(true);
        isMainMarket
          ? await createProductsMarketChannel({
              channelID: channelID,
              defaultId: defaultListing.id,
              selectedProducts: createList
            })
          : await createProductOnChannel({
              channelID: channelID,
              selectedProducts: createList,
              defaultChannelId: defaultListing?.id,
              squareStoreId: storeId
            });
        setOpenCreateDialog(true);
        handleChangeStatus({ id: selectedItems, status: "creating" });
        setSelectedItems([]);
      } catch (e) {
        const message =
          e?.response?.data?.message ||
          e?.response?.data?.errors ||
          e?.response?.data?.msg ||
          e?.response?.data?.error ||
          e?.response?.data?.message;
        message &&
          enqueueSnackbar(alertError(message), {
            variant: "error"
          });
      }
      setDisableButton(false);
    } else {
      enqueueSnackbar(
        "All products you choose are already on main and linked. Please choose another product",
        { variant: "warning" }
      );
    }
  };

  const handleCreateProduct = () => {
    const createList =
      handleCheckItemCondition({ type: LISTING_DETAIL_LIST_ACTION.create })
        ?.listCreateOnChannel || [];

    if (defaultListing.type === "squarespace") {
      return handleSquareSpaceCallCreate({
        channelId: defaultListing.id,
        enqueueSnackbar,
        dispatch,
        channelType: defaultListing.type,
        createProductFunction: handleCreateOnDefault(createList),
        setOpenDialogStore
      });
    }
    return handleCreateOnDefault(createList)();
  };

  const refreshImage = async () => {
    const _payload = {
      channel_id: channelID,
      product_ids: selectedItems
    };
    try {
      await channelRefreshImage(_payload).then(res => {
        if (res?.status < 400)
          enqueueSnackbar("Reload Images Success", {
            variant: "success"
          });
      });
      getData();
    } catch (error) {
      console.log(error);
      enqueueSnackbar("Reload Images Fail", {
        variant: "error"
      });
    }
  };

  useEffect(() => {
    setActionSelect("");
  }, [channelID, currentTab]);

  const handleAction = async (runAction = "") => {
    await autoSave();
    const action = {
      [LISTING_DETAIL_LIST_ACTION.publish]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish
          })?.missingArray,
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish
          })?.itemType
        }),
      // 2 action is the same because product channel_status, active | draft | error.
      // active => put: edit product, draft and error => post: create new active listing
      [LISTING_DETAIL_LIST_ACTION.update]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.update
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.update
          })?.missingArray,
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.update
          })?.itemType
        }),
      [LISTING_DETAIL_LIST_ACTION.delete_listing]: () => openDeleteAllDialog(),
      [LISTING_DETAIL_LIST_ACTION.sync]: () => handleSyncFrom(),
      [LISTING_DETAIL_LIST_ACTION.end]: () => handleRenewListing("end"),
      [LISTING_DETAIL_LIST_ACTION.active_listing]: () =>
        handleRenewListing("active"),
      [LISTING_DETAIL_LIST_ACTION.relist]: () => handleRenewListing("relist"),
      [LISTING_DETAIL_LIST_ACTION.renew]: () => handleRenewListing("renew"),
      [LISTING_DETAIL_LIST_ACTION.unlist]: () => handleRenewListing("unlist"),
      [LISTING_DETAIL_LIST_ACTION.unlink]: () => handleUnlink(),
      [LISTING_DETAIL_LIST_ACTION.create]: () => handleCreateProduct(),
      [LISTING_DETAIL_LIST_ACTION.publish_draft]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_draft
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_draft
          })?.missingArray,
          isDraft: "draft",
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_draft
          })?.itemType
        }),
      [LISTING_DETAIL_LIST_ACTION.publish_live]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_live
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_live
          })?.missingArray,
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_live
          })?.itemType
        }),
      [LISTING_DETAIL_LIST_ACTION.refresh_img]: () => refreshImage()
    };

    return Object.keys(action).includes(runAction)
      ? action?.[runAction]?.() && setActionSelect("")
      : null;
  };

  useEffect(() => {
    setActionSelect("");
  }, [channelID, currentTab]);

  return (
    <>
      <SquareSpaceStoreModal
        open={openDialogStore}
        handleClose={() => {
          setOpenDialogStore(false);
        }}
        handleConfirm={handleCreateOnDefault}
        channelId={defaultListing?.id}
      />

      {dialogMiss && (
        <CustomizedDialogs
          handleClose={() => setDialogMiss([])}
          handleConfirm={() => setDialogMiss([])}
          open={dialogMiss && dialogMiss?.length > 0}
          values={dialogMiss}
          channelId={channelID}
        />
      )}

      <CreateOnSourceCartDialog
        channelType={defaultListing?.type}
        handleClose={handleCloseCrateSourceCart}
        open={openCreateDialog}
      />

      <Dialog
        open={isOpenDialogDeleteAll}
        handleClose={handleCloseDeleteDialog}
        header="Are you sure?"
        content={
          <Typography color="textPrimary" variant="body1">
            {channelType === "etsy" ? (
              <>
                <Typography component={"span"}>
                  Deleting this listing will remove it from
                </Typography>
                <Typography component={"span"} style={{ fontWeight: "bold" }}>
                  {" App and Etsy"}
                </Typography>
                <Typography component={"span"}>
                  . Are you sure you want to delete this listing? This action
                  can not be undone.
                </Typography>
              </>
            ) : (
              "Are you sure you want to delete selected listings? All the listing information will be discarded and cannot be retrieved."
            )}
          </Typography>
        }
        handleConfirm={handleConfirmDeleteSome}
        nameButton="Yes, Remove"
      />

      <Box display="flex" alignItems="center" style={{ gap: 8 }}>
        <MultiEditGroupOption
          handleChangeAction={handleChangeAction}
          selectedItems={selectedItems}
          actionSelect={actionSelect}
        />
        <ListingDetailRun
          actionSelect={actionSelect}
          handleAction={handleAction}
          handleDisableActionButton={
            disableActionButton || selectedItems.length <= 0 || !actionSelect
          }
        />
      </Box>
    </>
  );
}

GroupButton.defaultProps = {
  channelID: "",
  autoSave: () => {},
  channelType: "",
  selectedItems: [],
  setSelectedItems: () => {},
  setOpenDialogMiss: () => {},
  currentTab: "",
  handleChangeStatus: () => {},
  cloneList: [],
  setListProduct: () => {},
  getData: () => {}
};

export default GroupButton;
