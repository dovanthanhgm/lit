import React from "react";
import Dialog from "src/components/MUI/Dialog";
import { Typography } from "@material-ui/core";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";

const DeleteAllDialog = ({
  open = false,
  setOpen = function() {},
  channelType,
  handleConfirm = function() {},
  currentTab = ""
}) => {
  return (
    <div>
      <Dialog
        open={open}
        handleClose={() => setOpen(false)}
        header="Are you sure?"
        content={
          <>
            <Typography color="textPrimary" variant="body1">
              Delete all {capitalizeFirstLetter(currentTab)} Listings will
              remove it from this channel on LitCommerce, but will NOT delete on{" "}
              {capitalizeFirstLetter(channelType)} or Main Store. Are you sure
              want to delete all? This action cannot be undone.
            </Typography>
          </>
        }
        maxWidth={"md"}
        handleConfirm={handleConfirm}
        nameButton="Delete"
      />
    </div>
  );
};

export default DeleteAllDialog;
