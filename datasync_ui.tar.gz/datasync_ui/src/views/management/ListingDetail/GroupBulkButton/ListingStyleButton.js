import React from 'react';
import MenuIcon from '@material-ui/icons/Menu';
import { Button, ButtonGroup } from '@material-ui/core';
// import GridIconButton from 'src/components/Icons/GridIcon';
import AppsIcon from '@material-ui/icons/Apps';
import { useDispatch, useSelector } from 'react-redux';
import { setStoreListingStyle } from 'src/actions/listingActions';

function ListingStyleButton(props, ref) {
   const { listingStyle } = useSelector(state => state.listing);
   const dispatch = useDispatch();

   return (
      <React.Fragment>
         <ButtonGroup ariant='outlined' size='small'>
            <Button
               style={{ minWidth: '32px', background: listingStyle === 'grid' ? '#c3c3c3' : null }}
               onClick={() => {
                  dispatch(setStoreListingStyle('grid'));
                  localStorage.setItem('listingStyle', 'grid');
               }}
            >
               <AppsIcon />
            </Button>
            <Button
               style={{ minWidth: '32px', background: listingStyle === 'table' ? '#c3c3c3' : null }}
               onClick={() => {
                  dispatch(setStoreListingStyle('table'));
                  localStorage.setItem('listingStyle','table' )
               }}
            >
               <MenuIcon />
            </Button>
         </ButtonGroup>
      </React.Fragment>
   );
}

export default ListingStyleButton;
