import React, { useContext } from "react";
import useUserExp from "src/hooks/useUserExp";
import { usePublish } from "./hook";
import PublishStatusMessage from "src/components/Listings/PublishStatus";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import ListingDetailGroupButton from "src/views/management/ListingDetail/GroupBulkButton/ListingDetailGroupButton";
import ApplyTemplates from "src/views/management/ListingDetail/GroupBulkButton/ApplyTemplates";
import { Box } from "@material-ui/core";
// import GroupButton from "./GroupButton";

function GroupButtonListing() {
  const { expired } = useUserExp();

  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const channelType = channelDetail?.type;

  const { isPublish, setIsPublish } = usePublish() || {};

  if (expired) return null;

  return (
    <React.Fragment>
      <Box display="flex" alignItems="center" p={1}>
        <ApplyTemplates />
        <Box mx={0.75}/>
        <ListingDetailGroupButton setIsPublish={setIsPublish} />
      </Box>
      {isPublish && <PublishStatusMessage channelType={channelType} />}
    </React.Fragment>
  );
}

export default GroupButtonListing;
