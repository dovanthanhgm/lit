import React, { useContext, useEffect, useMemo, useState } from "react";
import {
  DRAFT_VALUE,
  ERROR_VALUE,
  LISTING_DETAIL_LIST_ACTION,
  LISTING_EDIT_PRODUCT_ID
} from "src/constants/Listing/index";
import {
  channelListingDelete,
  channelPublishAPI,
  channelRefreshImage,
  loadFromMainApi,
  renewListing,
  syncFromChannel,
  unLinkProducts
} from "src/services/channel";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { handleMissingProduct } from "src/views/management/ListingDetail/ListingFunction";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { useSnackbar } from "notistack";
import { useDispatch, useSelector } from "react-redux";
import { handleSquareSpaceCallCreate } from "src/views/management/Listing/ListingCallCreate/index";
import {
  createProductOnChannel,
  createProductsMarketChannel
} from "src/services/products";
import { alertError } from "src/helper/showErrorMessage";
import SquareSpaceStoreModal from "src/components/Modal/SquareSpaceStoreModal";
import CreateOnSourceCartDialog from "src/components/Modal/CreateOnSourceCartDialog";
import DeleteListingModal from "src/views/management/ListingDetail/components/ListingModal/DeleteListing";
import ListingGroupOption from "src/views/management/ListingDetail/GroupBulkButton/ListingGroupOption";
import ListingDetailRun from "src/components/Button/ListingDetailRun";
import DeleteSome from "src/views/management/ListingDetail/GroupBulkButton/DeleteSome";
import { Box } from "@material-ui/core";
import { getUserInfo } from "src/services/account";
import {
  setToolTipRunningProcess,
  SILENT_LOGIN
} from "src/actions/accountActions";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import CustomizedDialogs from "src/components/Modal/ModalChannel/ListingDialog";
import useUnlinkVariantListingDetail from "src/views/management/ListingDetail/Hook/useUnlinkVariantListingDetail";
import AdminButtons from "src/views/management/ListingDetail/GroupBulkButton/Admin";
import MultiEditButton from "src/views/management/ListingDetail/GroupBulkButton/MultiEditButton";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import { isMissingConditionAction } from "src/helper/handleListingAction";
import { ListingDetailApiDriver } from "src/views/management/ListingDetail/Context/ListingDetailApiDriver";
import {
  CREATE_ON_MAIN_DELAY_TIME,
  RELOAD_ON_MAIN_DELAY_TIME
} from "src/views/management/ListingDetail/Constant/index";
import ListingStyleButton from "./ListingStyleButton";
import ManageTableColumnButton from "src/views/management/ListingDetail/GroupBulkButton/ManageTableColumnButton";
import wait from "src/utils/wait";
import WalmartTimer from "src/views/management/ListingDetail/GroupBulkButton/WalmartTimer";
import { getWalmartTimeRun } from "src/actions/listingActions";
import DeleteAllDialog from "src/views/management/ListingDetail/GroupBulkButton/DeleteAllDialog";
import { messageError } from "src/utils/ErrorResponse";
import ListingDetailUpdateFromModal from "src/views/management/ListingDetail/components/ListingModal/UpdateFromModal";
import ListingDetailUpdateToModal from "src/views/management/ListingDetail/components/ListingModal/UpdateToModal";

const ListingDetailGroupButton = ({ setIsPublish }) => {
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();

  const {
    defaultListing,
    marketplaces,
    listingDetail,
    listingDetailModal
  } = useSelector(state => state?.listing);
  const currentTab = listingDetail?.currentTab;

  const isMainMarket = useMemo(() => {
    return marketplaces.map(item => item.id).includes(defaultListing.type);
  }, [marketplaces, defaultListing]);

  const {
    selectedItems,
    handleChangeStatus,
    setSelectedItems: setSelected,
    handleChangeLinkStatus
  } = useContext(ListingDetailTableSelectedProductContext);

  const { variants } = useContext(ListingProductDialogContext);
  const { listingData, recallProduct } = useContext(
    ListingDetailProductsContext
  );
  const { recallCount } = useContext(ListingDetailCountContext);
  const { channelDetail, channelSetting } = useContext(
    ListingDetailChannelDetailContext
  );
  const { listingApiDriver } = useContext(ListingDetailApiDriver);

  const isClearSelectedProduct =
    channelSetting?.settings?.other_setting?.clear_selected === "enable";

  const setSelectedItems = value => {
    if (isClearSelectedProduct) {
      setSelected([]);
    }
  };

  const { handleUnlinkVariant } = useUnlinkVariantListingDetail();

  const channelType = channelDetail.channelType;
  const channelID = channelDetail.channelID;

  const [dialogMiss, setDialogMiss] = useState([]);
  const [disableButton, setDisableButton] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [openDialogStore, setOpenDialogStore] = useState(false);
  const [openCreateDialog, setOpenCreateDialog] = useState(false);
  const [disableByWalmartTime, setDisableByWalmartTime] = useState(false);
  const [openDialogDeleteSelected, setOpenDialogDeleteSelected] = useState(
    false
  );
  const [openDeleteAll, setOpenDeleteAll] = useState(false);
  const [openUpdateFrom, setOpenUpdateFrom] = useState(null);
  const [openUpdateTo, setOpenUpdateTo] = useState(null);
  const [actionSelect, setActionSelect] = useState("");

  const handleClearAction = async () => {
    await wait(1200);
    setActionSelect("");
  };

  const handleCheckItemCondition = ({ type }) => {
    return selectedItems.reduce(
      (prev, curr) => {
        const missingList = prev?.missingInfo || [];
        const createList = prev?.listCreateOnChannel || [];
        const missingArray = prev?.missingArray || [];
        const productSelected = listingData.find(
          product => product?.[LISTING_EDIT_PRODUCT_ID] === curr
        );

        if (!productSelected) {
          prev = {
            ...prev,
            missingInfo: [...missingList, curr]
          };
        } else {
          const conditionMiss = isMissingConditionAction({ type })?.(
            productSelected
          );

          if (
            (productSelected &&
              handleMissingProduct({
                item: productSelected,
                channelType,
                channelID,
                hasVariant: productSelected?.variant_count > 0,
                variants,
                channelSetting
              })) ||
            conditionMiss
          ) {
            prev = {
              ...prev,
              missingInfo: [...missingList, curr],
              missingArray: [...missingArray, productSelected]
            };
          }
          if (productSelected && !conditionMiss) {
            //prevent current tab in redux lagging/// draft item can call put api
            prev = {
              ...prev,
              itemType: productSelected?.channel_status
            };
          }
          if (productSelected?.link_status === "unlink") {
            prev = {
              ...prev,
              listCreateOnChannel: [
                ...createList,
                productSelected?.[LISTING_EDIT_PRODUCT_ID]
              ]
            };
          }
        }

        return prev;
      },
      {
        missingInfo: [],
        listCreateOnChannel: [],
        missingArray: [],
        itemType: ""
      }
    );
  };

  // const handleConditionMatchCa = () => {
  //   return selectedItems.filter(item => {
  //     const productSelected = listingData.find(
  //       product => product?.[LISTING_EDIT_PRODUCT_ID] === item
  //     );
  //
  //     const conditionMiss = isMissingConditionAction({
  //       type: LISTING_DETAIL_LIST_ACTION.match_ca
  //     })?.(productSelected);
  //     return !!productSelected && conditionMiss;
  //   });
  // };

  const handlePublish = async ({
    selectedItems,
    listItemsMiss = [],
    missingArray = [],
    isDraft = false,
    itemType = "",
    isPublish = true
  }) => {
    const isItemType = itemType !== currentTab ? itemType : currentTab;
    if (listItemsMiss && listItemsMiss?.length > 0) {
      setDialogMiss(missingArray);
    }
    if (selectedItems.length > 0) {
      const listMiss = listItemsMiss.map(product => product);
      const filterMissing = selectedItems.filter(id => {
        return !listMiss.includes(id.toString());
      });
      if (filterMissing.length > 0) {
        setIsPublish(channelType === "google");
        setDisableButton(true);
        try {
          const res = await channelPublishAPI({
            channelID,
            product_ids: filterMissing,
            currentTab: isItemType,
            publish_draft: isDraft
          });
          if (res?.code === 200) {
            listingApiDriver.product.start(120000);
            listingApiDriver.count.start(120000);
            enqueueSnackbar(
              "Publishing process has started, it will complete in a few secs",
              {
                variant: "success"
              }
            );
            channelType === "walmart" &&
              isPublish &&
              dispatch(getWalmartTimeRun({ channelId: channelID }));
            handleChangeStatus({
              id: filterMissing,
              status: [DRAFT_VALUE, ERROR_VALUE].includes(currentTab)
                ? "pushing"
                : "updating"
            });
            setSelectedItems([]);
            setDisableButton(false);
            await wait(15000);
            dispatch(
              setToolTipRunningProcess(
                "Click here to see current running processes"
              )
            );
          }
        } catch (e) {
          enqueueSnackbar("Something went wrong", {
            variant: "error"
          });
        }
      } else {
        enqueueSnackbar("No product can publish", {
          variant: "warning"
        });
      }
    } else {
      enqueueSnackbar("You need to select at least 1 product", {
        variant: "warning"
      });
    }
    setDisableButton(false);
  };

  const openDeleteAllDialog = () => {
    setOpenDeleteDialog(true);
  };

  const handleSyncFrom = async () => {
    try {
      // syncSelected have to change when syncName change
      await syncFromChannel({
        productList: selectedItems,
        channelId: channelID
      });
      setActionSelect("");
      setSelectedItems([]);
      enqueueSnackbar(
        "Request sent successfully. The products you choose will be synced to LitCommerce in a few minutes",
        {
          variant: "success"
        }
      );
      await wait(15000);
      dispatch(
        setToolTipRunningProcess("Click here to see current running processes")
      );
    } catch (e) {
      console.log(e);
      enqueueSnackbar("Error", {
        variant: "error"
      });
    }
  };

  const handleRenewListing = async action => {
    try {
      await renewListing({
        channel_id: channelID,
        product_ids: selectedItems,
        action
      });
      handleChangeStatus({ id: selectedItems, status: "renew" });
      setSelectedItems([]);

      listingApiDriver.product.start(120000);
      listingApiDriver.count.start(120000);
    } catch (e) {
      console.log("error", e);
    }
  };

  // const handleMapDraftProductCa = async () => {
  //   try {
  //     const body = {
  //       product_ids: handleConditionMatchCa()
  //     };
  //     await matchDraftProductCa({ channel_id: channelID, body });
  //     setSelectedItems([]);
  //   } catch (e) {
  //     console.log(e);
  //     enqueueSnackbar("Match product fail", {
  //       variant: "error"
  //     });
  //   }
  // };

  const handleUnlink = async () => {
    try {
      const data = await unLinkProducts({
        channel_id: channelID,
        body: { product_ids: selectedItems }
      });
      if (data) {
        handleUnlinkVariant({
          listItems: selectedItems,
          listNewID: data?.data || []
        });
        setSelectedItems([]);
        enqueueSnackbar("Success", {
          variant: "success"
        });
        handleChangeLinkStatus("unlink");
      }
    } catch (e) {
      console.log("errors", e);
      enqueueSnackbar("Error", {
        variant: "error"
      });
    }
  };

  const handleCreateOnDefault = (createList = []) => async storeId => {
    if (createList.length > 0) {
      try {
        setDisableButton(true);
        isMainMarket
          ? await createProductsMarketChannel({
              channelID: channelID,
              defaultId: defaultListing.id,
              selectedProducts: createList
            })
          : await createProductOnChannel({
              channelID: channelID,
              selectedProducts: createList,
              defaultChannelId: defaultListing?.id,
              squareStoreId: storeId
            });
        setOpenCreateDialog(true);
        handleChangeStatus({ id: selectedItems, status: "creating" });
        setSelectedItems([]);
        listingApiDriver.product.start(CREATE_ON_MAIN_DELAY_TIME);
        await handleClearAction();

        await wait(15000);
        dispatch(
          setToolTipRunningProcess(
            "Click here to see current running processes"
          )
        );
      } catch (e) {
        const message =
          e?.response?.data?.message ||
          e?.response?.data?.errors ||
          e?.response?.data?.msg ||
          e?.response?.data?.error ||
          e?.response?.data?.message;
        message &&
          enqueueSnackbar(alertError(message), {
            variant: "error"
          });
      }
      setDisableButton(false);
    } else {
      enqueueSnackbar(
        "All products you choose are already on main and linked. Please choose another product",
        { variant: "warning" }
      );
    }
  };

  const handleCreateProduct = () => {
    const createList =
      handleCheckItemCondition({ type: LISTING_DETAIL_LIST_ACTION.create })
        ?.listCreateOnChannel || [];

    if (defaultListing.type === "squarespace") {
      return handleSquareSpaceCallCreate({
        channelId: defaultListing.id,
        enqueueSnackbar,
        dispatch,
        channelType: defaultListing.type,
        createProductFunction: handleCreateOnDefault(createList),
        setOpenDialogStore
      });
    }
    return handleCreateOnDefault(createList)();
  };

  const handleReloadMain = async selectedItems => {
    try {
      setDisableButton(true);
      const body = {
        channel_id: channelID,
        product_ids: selectedItems
      };
      await loadFromMainApi({ body });
      handleChangeStatus({ id: selectedItems, status: "reloading" });
      setSelectedItems([]);
      listingApiDriver.product.start(RELOAD_ON_MAIN_DELAY_TIME);
      listingApiDriver.product.timesControl(1);
      await handleClearAction();
    } catch (e) {
      console.log(e);
    }
    setDisableButton(false);
  };

  const handleDeleteSelected = () => {
    setOpenDialogDeleteSelected(true);
  };

  const handleDeleteAll = () => {
    setOpenDeleteAll(true);
  };

  const updateFunction = () =>
    handlePublish({
      selectedItems,
      listItemsMiss: handleCheckItemCondition({
        type: LISTING_DETAIL_LIST_ACTION.update
      })?.missingInfo,
      missingArray: handleCheckItemCondition({
        type: LISTING_DETAIL_LIST_ACTION.update
      })?.missingArray,
      itemType: handleCheckItemCondition({
        type: LISTING_DETAIL_LIST_ACTION.update
      })?.itemType
    });

  const refreshImage = async () => {
    const _payload = {
      channel_id: channelID,
      product_ids: selectedItems
    };
    try {
      await channelRefreshImage(_payload).then(res => {
        if (res?.status < 400)
          enqueueSnackbar("Reload Images Success", {
            variant: "success"
          });
      });
      recallProduct();
    } catch (error) {
      console.log(error);
      enqueueSnackbar("Reload Images Fail", {
        variant: "error"
      });
    }
  };

  const handleActionButton = async (runAction = "") => {
    const action = {
      [LISTING_DETAIL_LIST_ACTION.publish]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish
          })?.missingArray,
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish
          })?.itemType,
          isPublish: 1
        }),
      // 2 action is the same because product channel_status, active | draft | error.
      // active => put: edit product, draft and error => post: create new active listing
      [LISTING_DETAIL_LIST_ACTION.update]: () => {
        // const isOpenUpdateFrom = listingDetailModal.hideUpdateFrom;
        const isOpenUpdateTo = listingDetailModal.hideUpdateTo;

        if (!isOpenUpdateTo) {
          setOpenUpdateTo(true);
          return;
        }
        updateFunction();
      },
      [LISTING_DETAIL_LIST_ACTION.delete_listing]: () => openDeleteAllDialog(),
      [LISTING_DETAIL_LIST_ACTION.reloadMain]: () =>
        handleReloadMain(selectedItems),
      [LISTING_DETAIL_LIST_ACTION.sync]: () => {
        const isOpenUpdateFrom = listingDetailModal.hideUpdateFrom;
        if (!isOpenUpdateFrom) {
          setOpenUpdateFrom(true);
          return;
        }
        handleSyncFrom();
      },
      [LISTING_DETAIL_LIST_ACTION.delete_selected]: () =>
        handleDeleteSelected(),
      [LISTING_DETAIL_LIST_ACTION.delete_all]: () => handleDeleteAll(),
      [LISTING_DETAIL_LIST_ACTION.end]: () => handleRenewListing("end"),
      [LISTING_DETAIL_LIST_ACTION.active_listing]: () =>
        handleRenewListing("active"),
      [LISTING_DETAIL_LIST_ACTION.relist]: () => handleRenewListing("relist"),
      [LISTING_DETAIL_LIST_ACTION.renew]: () => handleRenewListing("renew"),
      [LISTING_DETAIL_LIST_ACTION.unlink]: () => handleUnlink(),
      [LISTING_DETAIL_LIST_ACTION.unlist]: () => handleRenewListing("unlist"),
      [LISTING_DETAIL_LIST_ACTION.create]: () => handleCreateProduct(),
      // [LISTING_DETAIL_LIST_ACTION.match_ca]: () => handleMapDraftProductCa(),
      [LISTING_DETAIL_LIST_ACTION.publish_draft]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_draft
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_draft
          })?.missingArray,
          isDraft: "draft",
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_draft
          })?.itemType
        }),
      [LISTING_DETAIL_LIST_ACTION.publish_live]: () =>
        handlePublish({
          selectedItems,
          listItemsMiss: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_live
          })?.missingInfo,
          missingArray: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_live
          })?.missingArray,
          itemType: handleCheckItemCondition({
            type: LISTING_DETAIL_LIST_ACTION.publish_live
          })?.itemType
        }),
      [LISTING_DETAIL_LIST_ACTION.refresh_img]: () => refreshImage()
    };

    return Object.keys(action).includes(runAction)
      ? action?.[runAction]?.() && handleClearAction()
      : null;
  };

  const handleChangeAction = event => {
    setActionSelect(event);
  };

  const getUser = async () => {
    const userData = await getUserInfo();
    if (userData) {
      dispatch({
        type: SILENT_LOGIN,
        payload: {
          user: userData
        }
      });
    }
  };

  const onDeleteSomeSuccess = () => {
    handleChangeStatus({ id: selectedItems, status: "delete" });

    setSelectedItems([]);
    // getData();
    recallCount();
    handleClearAction();
    enqueueSnackbar("Delete success", {
      variant: "success"
    });
    setTimeout(() => getUser(), 2000);
  };

  const onDeleteAllConfirm = async () => {
    try {
      await channelListingDelete({ channelID, tab: currentTab });
      setSelectedItems([]);
      recallCount();
      handleClearAction();
      setTimeout(() => getUser(), 2000);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete fail"), {
        variant: "success"
      });
    }
  };

  const confirmSquareSpace = storeId => {
    const createList =
      handleCheckItemCondition({
        type: LISTING_DETAIL_LIST_ACTION.create
      })?.listCreateOnChannel || [];
    return handleCreateOnDefault(createList)(storeId);
  };

  useEffect(() => {
    setActionSelect("");
  }, [channelID, currentTab]);

  return (
    <React.Fragment>
      <Box display="flex" alignItems="center" width="100%">
        <ListingDetailUpdateFromModal
          open={openUpdateFrom}
          confirmFunction={handleSyncFrom}
          setOpen={value => {
            setActionSelect("");
            setOpenUpdateFrom(value);
          }}
        />
        <ListingDetailUpdateToModal
          open={openUpdateTo}
          confirmFunction={updateFunction}
          setOpen={value => {
            setActionSelect("");
            setOpenUpdateTo(value);
          }}
        />
        {dialogMiss && (
          <CustomizedDialogs
            handleClose={() => setDialogMiss([])}
            handleConfirm={() => setDialogMiss([])}
            open={dialogMiss && dialogMiss?.length > 0}
            values={dialogMiss}
            channelId={channelID}
          />
        )}

        {openDialogStore && (
          <SquareSpaceStoreModal
            open={openDialogStore}
            handleClose={() => {
              setOpenDialogStore(false);
              setDisableButton(false);
            }}
            handleConfirm={confirmSquareSpace}
            channelId={defaultListing?.id}
          />
        )}
        {openCreateDialog && (
          <CreateOnSourceCartDialog
            channelType={defaultListing?.type}
            handleClose={() => setOpenCreateDialog(false)}
            open={openCreateDialog}
          />
        )}
        {openDeleteDialog && (
          <DeleteListingModal
            channelType={channelType}
            isOpenDialogDeleteAll={openDeleteDialog}
            handleCloseDeleteDialog={() => setOpenDeleteDialog(false)}
            onDeleteSomeSuccess={onDeleteSomeSuccess}
            channelID={channelID}
          />
        )}
        {openDeleteAll && (
          <DeleteAllDialog
            channelType={channelType}
            open={openDeleteAll}
            setOpen={setOpenDeleteAll}
            currentTab={currentTab}
            handleConfirm={onDeleteAllConfirm}
          />
        )}
        <Box width="100%" display="flex" style={{ paddingRight: "8px" }}>
          <Box display="flex" alignItems="center" flexGrow={1}>
            <ListingGroupOption
              actionSelect={actionSelect}
              handleChangeAction={handleChangeAction}
              disableByWalmartTime={disableByWalmartTime}
              selectedItems={selectedItems}
              disableButton={disableButton}
              disabled={disableButton || selectedItems.length <= 0}
            />
            <Box mx={0.5} />
            <ListingDetailRun
              actionSelect={actionSelect}
              handleAction={handleActionButton}
              channelID={channelID}
              setActionSelect={setActionSelect}
              setDisableByWalmartTime={setDisableByWalmartTime}
              channelType={channelType}
            />
            <DeleteSome
              setDisableButton={setDisableButton}
              openDeleteSelected={openDialogDeleteSelected}
              setOpenDeleteSelected={setOpenDialogDeleteSelected}
              selectedItems={selectedItems}
              setActionSelect={setActionSelect}
              onDeleteSomeSuccess={onDeleteSomeSuccess}
            />
            <AdminButtons />
            {channelType === "walmart" && <WalmartTimer />}
          </Box>
          <Box display="flex" alignItems="center">
            <ListingStyleButton />
          </Box>
        </Box>

        <ManageTableColumnButton
          channelType={channelType}
          channelID={channelID}
        />
        <Box mx={0.5} />
        <MultiEditButton />
      </Box>
    </React.Fragment>
  );
};

export default ListingDetailGroupButton;
