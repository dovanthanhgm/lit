import React, { useContext } from "react";
import { ChannelDetailContext } from "src/views/management/ListingEditProduct/Context/ChannelDetailContext";
import SingleAlert from "src/components/Notify/SingleAlert";
import { Box } from "@material-ui/core";
import { useField } from "formik";

const OnBuyCategoryAlert = () => {
  const { channelType } = useContext(ChannelDetailContext);
  const [{ value }] = useField("template_data.category");

  if (channelType !== "onbuy" || value?.category?.category_id) {
    return null;
  }

  return (
    <Box my={0.5}>
      <SingleAlert
        content={
          <>
            Your listing is missing category, this maybe due to OnBuy does not support retrieve category from listing 
            so we could not get category when import listing from OnBuy.
          </>
        }
        type={"info"}
      />
    </Box>
  );
};

export default OnBuyCategoryAlert;
