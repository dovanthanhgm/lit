import React, { useContext } from "react";
import { ChannelDetailContext } from "src/views/management/ListingEditProduct/Context/ChannelDetailContext";
import SingleAlert from "src/components/Notify/SingleAlert";
import { Box, Link } from "@material-ui/core";
import { useField } from "formik";

const ReverbAlertVariant = () => {
  const { channelType } = useContext(ChannelDetailContext);
  const [{ value }] = useField("variant_count");

  if (channelType !== "reverb" || !value) {
    return null;
  }

  return (
    <Box my={0.5}>
      <SingleAlert
        content={
          <>
            This product has variants, but please note&nbsp;
            <Link href="https://help.reverb.com/hc/en-us/articles/360015397173-Can-I-sync-variable-products-to-Reverb-from-my-Shopify-">
              Reverb does not have variant product type
            </Link>
            , all variants will be published as simple products in Reverb.
          </>
        }
        type={"info"}
      />
    </Box>
  );
};

export default ReverbAlertVariant;
