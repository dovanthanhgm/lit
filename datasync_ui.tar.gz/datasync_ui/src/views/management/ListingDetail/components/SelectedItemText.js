import { Box, Typography } from "@material-ui/core";
import React, { useContext } from "react";

import useUserExp from "src/hooks/useUserExp";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";

function SelectedItemText() {
  const { expired } = useUserExp();
  const { selectedItems } = useContext(
    ListingDetailTableSelectedProductContext
  );
  const selectedItemsLength = selectedItems.length;

  return (
    <Box pl={2} pt={expired ? 2 : 0} display="flex">
      <Typography color="textPrimary" variant="body2">
        {selectedItemsLength} product{selectedItemsLength > 1 ? "s" : ""}{" "}
        selected
      </Typography>
    </Box>
  );
}

export default SelectedItemText;
