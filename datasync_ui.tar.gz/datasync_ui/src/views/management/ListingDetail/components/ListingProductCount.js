import React from "react";

const ListingProductCount = () => {
  return <div></div>;
};

export default ListingProductCount;
