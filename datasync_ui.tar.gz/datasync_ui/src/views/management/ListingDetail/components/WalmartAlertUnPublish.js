import React, { useContext } from "react";
import SingleAlert from "src/components/Notify/SingleAlert";
import { Box } from "@material-ui/core";
import { useField } from "formik";
import { ChannelDetailContext } from "src/views/management/ListingEditProduct/Context/ChannelDetailContext";
import { UNPUBLISHED } from "src/constants/Listing/index";

const WalmartAlertUnPublish = () => {
  const { channelType } = useContext(ChannelDetailContext);

  const [{ value: walmartStatus }] = useField("walmart_status");
  const [{ value: publishReason }] = useField("unpublished_reason");

  if (
    channelType !== "walmart" ||
    !walmartStatus ||
    !publishReason ||
    walmartStatus !== UNPUBLISHED
  ) {
    return null;
  }

  return (
    <Box my={0.5}>
      <SingleAlert content={<>{publishReason}</>} type={"error"} />
    </Box>
  );
};

export default WalmartAlertUnPublish;
