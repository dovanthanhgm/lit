import React, { useContext } from "react";

import { Alert } from "@material-ui/lab";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";

function AlertComponent() {
  const { tab } = useContext(ListingDetailProductsContext);

  if (tab !== "error") return null;

  return (
    <Alert
      icon={false}
      severity="warning"
      style={{
        padding: "0 4px 0px 16px",
        margin: "4px 16px"
      }}
    >
      Please click on each product to see Error details.
    </Alert>
  );
}

export default AlertComponent;
