import React, { useContext } from "react";
import { ChannelDetailContext } from "src/views/management/ListingEditProduct/Context/ChannelDetailContext";
import SingleAlert from "src/components/Notify/SingleAlert";
import { Box } from "@material-ui/core";
import { useField } from "formik";

const ReverbConditionAlert = () => {
  const { channelType } = useContext(ChannelDetailContext);
  const [{ value }] = useField("template_data.category");

  if (channelType !== "reverb" || !value?.info?.reverb_condition?.tags) {
    return null;
  }

  return (
    <Box my={0.5}>
      <SingleAlert
        content={
          <>
            This product is using Shopify tags reverbsync-condition for mapping. Please note that each 
            tag in your listings tags is seprated by comma and value use for mapping must be one of these: 
            Brand New, B-Stock, Mint (with inventory), Mint, Excellent, Very Good, Good, Fair, Poor, Non Functioning. 
            For example, listing tags could include this tag "reverbsync-condition:Very Good".
          </>
        }
        type={"info"}
      />
    </Box>
  );
};

export default ReverbConditionAlert;
