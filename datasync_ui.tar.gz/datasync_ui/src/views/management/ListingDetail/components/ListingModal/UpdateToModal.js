import React, { useContext, useState } from "react";
import DialogTitle from "src/components/Modal/DialogTitle";
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  FormControlLabel,
  Typography
} from "@material-ui/core";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { convertIdToName } from "src/utils/helper";
import { useDispatch } from "react-redux";
import { setListingDetailModalStatus } from "src/actions/listingActions";

const ListingDetailUpdateToModal = ({
  open,
  setOpen = function() {},
  confirmFunction = function() {}
}) => {
  const dispatch = useDispatch();
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const [status, setStatus] = useState(false);

  const channelType = channelDetail?.type;

  const handleClose = () => {
    setOpen(null);
  };

  const handleSetAction = () => {
    setStatus(!status);
    dispatch(
      setListingDetailModalStatus({
        actionName: "hideUpdateTo",
        actionStatus: !status
      })
    );
  };

  return (
    <div>
      <Dialog open={!!open} onClose={handleClose}>
        <DialogTitle>Update to {convertIdToName(channelType)}</DialogTitle>
        <DialogContent dividers>
          <Typography>
            This will update changes/overwrite the linked listings on your{" "}
            {convertIdToName(channelType)}. Are you sure want to do this?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Box
            display={"flex"}
            alightItems={"center"}
            px={2}
            width={"100%"}
            justifyContent={"space-between"}
          >
            <FormControlLabel
              control={<Checkbox onChange={handleSetAction} name="checkedA" />}
              label="Do not show again in this session."
            />
            <Box display={"flex"} alignItems={"center"}>
              <Button onClick={handleClose}>Cancel</Button>
              <Button
                onClick={() => {
                  handleClose();
                  confirmFunction();
                }}
                color="primary"
              >
                Confirm
              </Button>
            </Box>
          </Box>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ListingDetailUpdateToModal;
