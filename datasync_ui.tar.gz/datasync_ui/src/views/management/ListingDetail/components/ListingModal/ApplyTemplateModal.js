import React from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  Typography
} from "@material-ui/core";
import DialogTitle from "src/components/Modal/DialogTitle";

const ApplyTemplateModal201 = ({ open, setOpen }) => {
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Apply Template Success</DialogTitle>
      <DialogContent>
        <Typography variant={"body2"}>
          Your action takes some time to complete. Please wait.
        </Typography>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default ApplyTemplateModal201;
