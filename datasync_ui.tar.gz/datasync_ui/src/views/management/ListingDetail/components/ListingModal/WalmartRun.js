import React, { useState } from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "src/components/Modal/DialogTitle";
import {
  Box,
  Checkbox,
  FormControlLabel,
  Link,
  Typography
} from "@material-ui/core";
import { LOCAL_WALMART_DIALOG_KEY } from "src/components/Button/ListingDetailRun";

const WalmartRun = ({
  open,
  setOpen = function() {},
  setHideWalmartWarning = function() {},
  walmartRunAction = function() {},
  setActionSelect = function() {}
}) => {
  const [hide, setHide] = useState(false);
  const handleClose = () => {
    setOpen(false);
    setActionSelect("");
  };

  const handleHide = () => {
    if (hide) {
      localStorage.setItem(LOCAL_WALMART_DIALOG_KEY, "Hubert");
      setHideWalmartWarning(true);
    }
  };

  const handleAccept = () => {
    handleHide();
    handleClose();
    walmartRunAction();
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Walmart's Notice</DialogTitle>
      <DialogContent>
        <Typography>
          Due to Walmart API Limits, you can only publish 10 times per hour to
          Walmart.&nbsp;
          <Link
            href={
              "https://help.litcommerce.com/en/article/walmart-api-limits-2nlihn/"
            }
            target={"_blank"}
          >
            Read more
          </Link>
        </Typography>
        <Typography>
          We highly recommend you finish editing all needed listings first and
          then publish listings in bulk rather than one by one to avoid reaching
          the feed limit.
        </Typography>
      </DialogContent>
      <DialogActions
        style={{
          paddingLeft: 24,
          paddingRight: 24
        }}
      >
        <Box display={"flex"} alignItems={"center"} width={"100%"}>
          <Box flexGrow={1}>
            <FormControlLabel
              control={
                <Checkbox
                  value={hide}
                  onChange={() => setHide(!hide)}
                  name="checkedB"
                  color="primary"
                />
              }
              label={
                <Typography variant={"body1"}>
                  I understood, don't show this again.
                </Typography>
              }
            />
          </Box>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleAccept} color="primary">
            Accept & Publish
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default WalmartRun;
