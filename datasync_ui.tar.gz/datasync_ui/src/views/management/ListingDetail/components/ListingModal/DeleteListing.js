import React, { useContext } from "react";
import Dialog from "src/components/MUI/Dialog";
import { Typography } from "@material-ui/core";
import {
  deleteSomeProductsChannelAPI,
  renewListing
} from "src/services/channel";
import { messageError } from "src/utils/ErrorResponse";
import { useSnackbar } from "notistack";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";

const MASS_ACTION_DELETE = ["etsy", "walmart", "reverb", 'google'];
const DeleteListingModal = ({
  channelType,
  channelID,
  isOpenDialogDeleteAll,
  handleCloseDeleteDialog = function() {},
  onDeleteSomeSuccess = function() {}
}) => {
  const { enqueueSnackbar } = useSnackbar();

  const { selectedItems } = useContext(
    ListingDetailTableSelectedProductContext
  );

  const handleConfirmDeleteSome = async () => {
    try {
      if (MASS_ACTION_DELETE.includes(channelType)) {
        await renewListing({
          channel_id: channelID,
          product_ids: selectedItems,
          action: "delete"
        });
      } else {
        await deleteSomeProductsChannelAPI({
          channelId: channelID,
          ids: selectedItems
        });
      }
      onDeleteSomeSuccess();
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  return (
    <Dialog
      open={isOpenDialogDeleteAll}
      handleClose={handleCloseDeleteDialog}
      header="Are you sure?"
      content={
        <Typography color="textPrimary" variant="body1">
          {channelType === "etsy" ? (
            <>
              <Typography component={"span"}>
                Deleting this listing will remove it from
              </Typography>
              <Typography component={"span"} style={{ fontWeight: "bold" }}>
                {" App and Etsy"}
              </Typography>
              <Typography component={"span"}>
                . Are you sure you want to delete this listing? This action can
                not be undone.
              </Typography>
            </>
          ) : (
            "Are you sure you want to delete selected listings? All the listing information will be discarded and cannot be retrieved."
          )}
        </Typography>
      }
      handleConfirm={handleConfirmDeleteSome}
      nameButton="Yes, Remove"
    />
  );
};

export default DeleteListingModal;
