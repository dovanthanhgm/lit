import React, { useContext, useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  FormControlLabel,
  Typography
} from "@material-ui/core";
import DialogTitle from "src/components/Modal/DialogTitle";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { useDispatch } from "react-redux";
import { setListingDetailModalStatus } from "src/actions/listingActions";
import { convertIdToName } from "src/utils/helper";

const ListingDetailUpdateFromModal = ({
  open,
  setOpen = function() {},
  confirmFunction = function() {}
}) => {
  const dispatch = useDispatch();
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const channelType = channelDetail?.type;
  const [status, setStatus] = useState(false);

  const handleClose = () => {
    setOpen(null);
  };

  const handleSetAction = () => {
    setStatus(!status);
    dispatch(
      setListingDetailModalStatus({
        actionName: "hideUpdateFrom",
        actionStatus: !status
      })
    );
  };

  return (
    <div>
      <Dialog open={!!open} onClose={handleClose}>
        <DialogTitle>Update to {convertIdToName(channelType)}</DialogTitle>
        <DialogContent dividers>
          <Typography>
            This will update/overwrite the selected listings on LitCommerce. Are
            you sure want to do this?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Box
            display={"flex"}
            alightItems={"center"}
            px={2}
            width={"100%"}
            justifyContent={"space-between"}
          >
            <FormControlLabel
              control={<Checkbox onChange={handleSetAction} name="checkedA" />}
              label="Do not show again in this session."
            />
            <Box display={"flex"} alignItems={"center"}>
              <Button onClick={handleClose}>Cancel</Button>
              <Button
                onClick={() => {
                  handleClose();
                  confirmFunction();
                }}
                color="primary"
              >
                Confirm
              </Button>
            </Box>
          </Box>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ListingDetailUpdateFromModal;
