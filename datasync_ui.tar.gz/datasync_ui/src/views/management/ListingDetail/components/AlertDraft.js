import React, { useContext } from "react";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { Alert } from "@material-ui/lab";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";
import { DRAFT_VALUE } from "src/constants/Listing/index";

const AlertDraft = () => {
  const { tab } = useContext(ListingDetailProductsContext);
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);

  if (![DRAFT_VALUE ].includes(tab) || !channelDetail?.channelType) {
    return null;
  }

  return (
    <Alert
      icon={false}
      severity="info"
      style={{
        padding: "0 4px 0px 16px",
        margin: "4px 16px"
      }}
    >
      These are Draft listings and not yet published to your {capitalizeFirstLetter(channelDetail.channelType)} store.&nbsp;
      Please fill all required data before Publishing listings to your live{" "}
      {capitalizeFirstLetter(channelDetail.channelType)} store
    </Alert>
  );
};

export default AlertDraft;