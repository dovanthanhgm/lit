import React, { useCallback, useContext, useEffect } from "react";
import { showImportAlert } from "src/actions/listingActions";
import { getStatusCode } from "src/services/channel";
import { useParams } from "react-router";
import { useDispatch } from "react-redux";
import { ProcessContext } from "src/views/management/ListingDetail/Context/ListingDetailProcessContext";
import { ListingDetailApiDriver } from "src/views/management/ListingDetail/Context/ListingDetailApiDriver";
import { PULLING_STATUS } from "src/views/management/ListingDetail/Constant/index";

const ListingDetailProcess = () => {
  const dispatch = useDispatch();
  const { channelID } = useParams();
  const { setProcess } = useContext(ProcessContext);
  const { tableProcess, listingApiDriver } = useContext(ListingDetailApiDriver);

  const processTimes = tableProcess.max;
  const processDelay = tableProcess.delay || 120000;

  const getStatus = useCallback(async () => {
    const res = await getStatusCode(channelID);
    if (res) {
      //Api reponse không có status, đang trả về 1 mảng rỗng 28/6/2023 11h30
      setProcess(res?.[0]?.status || "completed");
      const isImport = res?.[0]?.status === PULLING_STATUS;
      dispatch(showImportAlert(isImport));
    }
    // eslint-disable-next-line
  }, [channelID]);

  useEffect(() => {
    const timeOut = setTimeout(() => {
      getStatus().catch(e => {
        console.log("Process Error");
      });
    }, 3000);

    return () => {
      clearTimeout(timeOut);
    };
  }, [getStatus]);

  useEffect(() => {
    const interval = setInterval(() => {
      getStatus()
        .then(e => {
          listingApiDriver.process.timesControl();
        })
        .catch(() => {
          listingApiDriver.process.timesControl();
          console.log("Process Error");
        });
    }, processDelay);

    if (!processTimes) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
    // eslint-disable-next-line
  }, [processTimes, processDelay, getStatus]);

  return <></>;
};

export default ListingDetailProcess;
