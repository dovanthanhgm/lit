import React, { useContext } from "react";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { Alert } from "@material-ui/lab";
import {
  TIKTOK_MESSAGE_FAIL,
  TIKTOK_MESSAGE_PENDING
} from "src/views/management/ListingDetail/TableListing/Tabs";
import { FAILED_VALUE, PENDING_VALUE } from "src/constants/Listing/index";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";

const TiktokAlertListingDetail = () => {
  const { tab } = useContext(ListingDetailProductsContext);
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const channelType = channelDetail?.type;

  if (![PENDING_VALUE, FAILED_VALUE].includes(tab) || channelType !== "tiktok")
    return null;

  if (tab === PENDING_VALUE) {
    return (
      <Alert
        icon={false}
        severity="info"
        style={{
          padding: "0 4px 0px 16px",
          margin: "4px 16px"
        }}
      >
        {TIKTOK_MESSAGE_PENDING}
      </Alert>
    );
  }
  if (tab === FAILED_VALUE) {
    return (
      <Alert
        icon={false}
        severity="error"
        style={{
          padding: "0 4px 0px 16px",
          margin: "4px 16px"
        }}
      >
        {TIKTOK_MESSAGE_FAIL}
      </Alert>
    );
  }
};

export default TiktokAlertListingDetail;
