import { Container, makeStyles } from "@material-ui/core";
import { isEmpty } from "lodash";
import { QueryClient, QueryClientProvider } from "react-query";
import React from "react";
import { useSelector } from "react-redux";
import { Redirect } from "react-router-dom";
import Page from "src/components/Page";
import { showAio, topAppBarHeight } from "src/constants";
import AIOBar from "src/views/AIOBar";
import HeaderListingDetail from "./HeaderListing";
import { ReactQueryDevtools } from "react-query/devtools";
import { withAccessChannelEdit } from "src/hooks/hocs";
import ListingDetailChannelDetailProvider from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import ListingDetailTableLayout from "src/views/management/ListingDetail/Layout/ListingDetailTableLayout";
import ListingDetailProcessProvider from "src/views/management/ListingDetail/Context/ListingDetailProcessContext";
import ListingProductTableLayout from "src/views/management/ListingDetail/Layout/ListingProductTableLayout";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";
import ListingDetailApiDriverProvider from "src/views/management/ListingDetail/Context/ListingDetailApiDriver";
import ListingDetailProcess from "src/views/management/ListingDetail/components/ListingProcess";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false
    }
  }
});

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    paddingTop: theme.spacing(1.5),
    paddingBottom: theme.spacing(1.5),
    flex: 1,
    overflow: "hidden"
  },
  modalContainer: {
    top: topAppBarHeight,
    position: "absolute",
    right: 0,
    height: `calc(100% - ${topAppBarHeight}px)`,
    width: "80%"
    // zIndex: 9999
  }
}));

function ListingDetail() {
  const classes = useStyles();

  return (
    <Page className={classes.root} title="Listing" noPadding>
      <ErrorBoundaryComponent>
        <Container
          maxWidth={false}
          style={{
            height: "100%",
            padding: "0 12px",
            display: "flex",
            flexDirection: "column"
          }}
        >
          <ListingDetailChannelDetailProvider>
            <ListingDetailApiDriverProvider>
              <ListingDetailProcessProvider>
                <ListingDetailProcess />
                <ListingDetailTableLayout>
                  <React.Fragment>
                    <HeaderListingDetail />
                    <ListingProductTableLayout />
                  </React.Fragment>
                </ListingDetailTableLayout>
              </ListingDetailProcessProvider>
            </ListingDetailApiDriverProvider>
          </ListingDetailChannelDetailProvider>
        </Container>
      </ErrorBoundaryComponent>
      {showAio && <AIOBar />}
    </Page>
  );
}

function Layout() {
  const user = useSelector(state => state?.account.user) || [];

  if (isEmpty(user)) {
    return <Redirect to={"/"} />;
  }

  return <ListingDetail />;
}

const ListingDetailPage = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <Layout />
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
};
export default withAccessChannelEdit(ListingDetailPage);
