import { CircularProgress, Tooltip, Typography } from "@material-ui/core";
import { Error as ErrorIcon } from "@material-ui/icons";
import { convertIdToName } from "src/utils/helper";
import React from "react";
import { get, isEmpty } from "lodash";
import {
  googleShippingCheck,
  requiredByTemplateField,
  requiredFieldMar,
  requiredImagesChannel,
  requiredTemplatesChannel
} from "src/utils/required";
import { checkVariantListing } from "src/views/management/Listing/Product/ListingFunction";
import {
  DRAFT_VALUE,
  ERROR_VALUE,
  UNPUBLISHED
} from "src/constants/Listing/index";
import {
  AMAZON_VALIDATE_FIELD,
  AMAZON_VALIDATE_PRODUCT_TYPE
} from "src/views/management/ListingEditProduct/constants";

export const LISTING_DETAIL_WARNING_MSG = "LISTING_DETAIL_WARNING_MSG";
export const LISTING_DETAIL_ERROR_STATUS = '"error"';

export const showIcon = ({
  statusCode,
  tooltipMessage,
  defaultChannelType,
  channelType
}) => {
  switch (statusCode) {
    case LISTING_DETAIL_ERROR_STATUS:
      return (
        <Tooltip
          title={
            (
              <Typography
                noWrap
                style={{ fontSize: "0.65rem" }}
                dangerouslySetInnerHTML={{
                  __html: tooltipMessage
                }}
              />
            ) || "Listing has errors"
          }
        >
          <ErrorIcon style={{ color: "#eb4934" }} />
        </Tooltip>
      );
    case LISTING_DETAIL_WARNING_MSG:
      return (
        <Tooltip
          title={
            (
              <Typography
                noWrap
                style={{ fontSize: "0.65rem" }}
                dangerouslySetInnerHTML={{
                  __html: tooltipMessage
                }}
              />
            ) || ""
          }
        >
          <ErrorIcon style={{ color: "#ff9800" }} />
        </Tooltip>
      );
    case UNPUBLISHED: {
      return (
        <Tooltip
          title={
            (
              <Typography
                style={{ fontSize: "0.65rem", maxHeight: 400 }}
                dangerouslySetInnerHTML={{
                  __html: tooltipMessage
                }}
              />
            ) || "Listing has errors"
          }
        >
          <ErrorIcon style={{ color: "#eb4934" }} />
        </Tooltip>
      );
    }
    case "pushing":
      return (
        <Tooltip title="pushing...">
          <CircularProgress disableShrink size={20} />
        </Tooltip>
      );
    case "creating":
      return (
        <Tooltip title={`creating on ${convertIdToName(defaultChannelType)}`}>
          <CircularProgress disableShrink size={20} />
        </Tooltip>
      );
    case "reloading":
      return (
        <Tooltip
          title={`Reloading from ${convertIdToName(defaultChannelType)}`}
        >
          <CircularProgress disableShrink size={20} />
        </Tooltip>
      );
    case "updating":
      return (
        <Tooltip title={`updating on ${convertIdToName(channelType)}`}>
          <CircularProgress disableShrink size={20} />
        </Tooltip>
      );
    case "renew":
      return (
        <Tooltip title={`renew on ${convertIdToName(channelType)}`}>
          <CircularProgress size={20} />
        </Tooltip>
      );
    case "completed":
      return (
        <>
          {tooltipMessage && (
            <Tooltip
              title={
                <Typography
                  noWrap
                  style={{ fontSize: "0.65rem" }}
                  dangerouslySetInnerHTML={{
                    __html: tooltipMessage
                  }}
                />
              }
            >
              <ErrorIcon style={{ color: "#eb4934" }} />
            </Tooltip>
          )}
        </>
      );
    default:
      return null;
  }
};

export const fulfilledItem = item => {
  switch (item) {
    case "fba":
      return <Typography variant="body2">Amazon</Typography>;
    default:
      return <Typography variant="body2">Merchant</Typography>;
  }
};

const checkTemplateField = ({ channelType, channelID, data }) => {
  const channel = {
    ebay: (value, field) => {
      let checkIsBusiness = false;
      const dataBusiness = get(value, `template_data.business`);

      checkIsBusiness =
        !!dataBusiness?.fulfillment_policy?.fulfillment_policy_id &&
        !!dataBusiness?.payment_policy?.payment_policy_id &&
        !!dataBusiness?.return_policy?.return_policy_id;

      if (["shipping"].some(item => field.includes(item))) {
        if (checkIsBusiness) return false;
      }

      if (field === "payment.item_location.country") {
        if (data === "US") {
          const dataPostal = get(
            value,
            `template_data.payment.item_location.postal_code`
          );
          if (!dataPostal) {
            return true;
          }
        }
      }
    },
    // Hubert 20/5/2023 SAT 8:30 - rsc: click up https://app.clickup.com/t/865cd0jac
    // Đối với các sản pull từ Walmart về
    // Loại bỏ thông báo required shipping template vì các sản phẩm đã có sẵn template trước đó.
    walmart: (value, field) => {
      if (field === "shipping.shipping_id") {
        const rscData = value.src;
        // eslint-disable-next-line
        const isChannel = rscData?.channel_id == channelID;
        if (isChannel) {
          return false;
        }
        return !data;
      }
    },
    google: (value, field) => {
      if (field === "category.category.id") {
        if (value?.channel_status !== "active") {
          return !get(value, `template_data.${field}`);
        }
      }
      if (googleShippingCheck === field) {
        const shippingValue = get(value, `template_data.shipping`);
        const priceShipping = shippingValue?.price;
        const countryShipping = shippingValue?.country;
        const deliveryShipping = shippingValue?.delivery_area?.value;

        if (priceShipping || deliveryShipping) {
          return !countryShipping;
        }
      }
      return false;
    },
    etsy: (value, field) => {
      const isDigitalStatus = value?.template_data?.digital?.digital_status;
      const dataShipping = get(value, `template_data.${field}`);

      //remove required shipping when digital on
      if (field === "shipping.shipping_id") {
        if (isDigitalStatus) {
          return false;
        }
        return !dataShipping;
      }
      return !data;
    },
    tiktok: (value, field) => {
      return !data;
    },
    amazon: (value, field) => {
      if (field === "offer.condition.value" && value.sku) {
        return false;
      }
      return !data;
    }
  };

  return channel?.[channelType]
    ? channel[channelType]
    : () => [null, undefined, "", 0].includes(data);
};

const handleCheckMissingTemplateField = ({ channelType, item, channelID }) => {
  const templateCheck = requiredByTemplateField?.[channelType];
  if (templateCheck) {
    return templateCheck.some(field => {
      const data = get(item, `template_data.${field}`);

      return checkTemplateField({ channelType, channelID, data })?.(
        item,
        field
      );
    });
  }
  return false;
};

// export const handleMissing = ({
//   checkMissing,
//   setListItemMiss,
//   channelDetail,
//   variants
// }) => {
//   setListItemMiss([]);
//   checkMissing.forEach(item => {
//     //check
//     const channelType = channelDetail?.type;
//     const hasVariant = item?.variant_count > 0;
//     const productVariants = variants?.[item.publish_id];
//
//     const isCheckVariant = () => {
//       if (!hasVariant || !productVariants) {
//         return false;
//       }
//       if (typeof productVariants === "object") {
//         if (productVariants.data.length === 0) {
//           return false;
//         }
//       }
//       if (!Object.keys(checkVariantListing).includes(channelType)) {
//         return false;
//       }
//       return checkVariantListing?.[channelType](
//         variants?.[item.publish_id]?.data,
//         item.publish_id
//       );
//     };
//
//     if (!(channelType === "amazon" && hasVariant)) {
//       const hasTemplates = isEmpty(
//         requiredTemplatesChannel[channelType]?.filter(
//           template => !isEmpty(item?.["template_data"]?.[template])
//         )
//       );
//       const hasFieldRequired =
//         !isEmpty(
//           requiredFieldMar[
//             channelType === "etsy" && hasVariant
//               ? `etsyHasVariant`
//               : channelType === "amazon" &&
//                 (item?.variant_count > 0 || item?.is_variant)
//               ? "amazonVariant"
//               : channelType
//           ]?.filter(field => !item?.[field]) ||
//             (!!requiredImagesChannel[channelType] &&
//               !(item?.thumb_image?.url || !isEmpty(item.images)))
//         ) || isCheckVariant();
//       //end check
//       //add value
//       if (
//         (!!requiredTemplatesChannel[channelType] && hasTemplates) ||
//         hasFieldRequired ||
//         handleCheckMissingTemplateField({ channelType, item })
//       ) {
//         setListItemMiss(prevState => [...prevState, item]);
//       }
//     }
//   });
// };

const amazon = (isVariant, item, channelSetting) => {
  const isMissingId = !["asin", ...AMAZON_VALIDATE_FIELD].some(
    field => item[field]
  );
  let missingFields = requiredFieldMar.amazon;
  if (!isMissingId) {
    missingFields = requiredFieldMar.amazon.filter(
      field => !["gtin", "asin"].includes(field)
    );
  }
  const itemSKU = item?.sku || "";

  const isSupportGTINExemption = [true, "True", "true", 1, "1"].includes(
    channelSetting?.support_amazon_gtin_exemption
  );

  const missingDataField = missingFields.filter(field => !item[field]);

  if (isSupportGTINExemption) {
    //check gtin exemption field data. All variations and simple check
    const templateFieldRequiredGTINExemption = AMAZON_VALIDATE_PRODUCT_TYPE.filter(
      field => !get(item, field)
    );
    if (!!templateFieldRequiredGTINExemption.length && !itemSKU) {
      return templateFieldRequiredGTINExemption;
    }

    if (isVariant)
      return requiredFieldMar.amazonVariant.filter(field => !item[field]);

    return missingDataField.filter(item => !["asin", "gtin"].includes(item));
  }
  if (isVariant)
    return requiredFieldMar.amazonVariant.filter(field => !item[field]);

  return missingDataField.filter(field => !item[field]);
};

const etsy = (isVariant, item) => {
  if (isVariant)
    return requiredFieldMar.etsyHasVariant.filter(field => !item[field]);

  return requiredFieldMar.etsy.filter(field => !item[field]);
};

const tiktok = (isVariant, item) => {
  if (![DRAFT_VALUE, ERROR_VALUE].includes(item?.channel_status)) {
    return requiredFieldMar.tiktok?.filter(field => !item?.[field]) || [];
  }
  return [];
};

const checkMissingField = (channelType, isVariant, item, channelSetting) => {
  const channel = {
    amazon,
    etsy,
    tiktok
  };

  return channel?.[channelType]
    ? channel[channelType](isVariant, item, channelSetting)
    : requiredFieldMar?.[channelType]?.filter(field => !item?.[field]) || [];
};

const etsyTemplateValidate = (value, templateList = []) => {
  const isDigitalStatus = value?.template_data?.digital?.digital_status;

  if (!isDigitalStatus) {
    return templateList.filter(
      templateRequire => templateRequire !== "shipping"
    );
  }
  return templateList;
};

export const handleMissingProduct = ({
  channelType = "",
  channelID = "",
  item = {},
  hasVariant = false,
  variants = [],
  channelSetting
}) => {
  const handleRequiredTemplate = () => {
    const channel = {
      etsy: etsyTemplateValidate
    };
    if (channel?.[channelType]) {
      return channel[channelType]?.(
        item,
        requiredTemplatesChannel[channelType]
      );
    }
    return requiredTemplatesChannel[channelType];
  };

  const hasTemplates =
    !!requiredTemplatesChannel[channelType] &&
    isEmpty(
      handleRequiredTemplate()?.filter(
        template => !isEmpty(item?.["template_data"]?.[template])
      )
    );

  // check miss field of item
  const hasFieldRequired =
    !isEmpty(
      checkMissingField(channelType, hasVariant, item, channelSetting)
    ) ||
    (!!requiredImagesChannel[channelType] &&
      !(item?.thumb_image?.url || !isEmpty(item.images)));

  const productVariants = variants?.[item.publish_id];
  const isCheckVariant = () => {
    if (!hasVariant || !productVariants) {
      return false;
    }
    //check length ??
    if (productVariants && typeof productVariants === "object") {
      if (productVariants.data.length === 0) {
        return false;
      }
    }
    if (!Object.keys(checkVariantListing).includes(channelType)) {
      return false;
    }
    return checkVariantListing?.[channelType](
      variants?.[item.publish_id]?.data,
      item.publish_id
    );
  };

  return (
    hasTemplates ||
    hasFieldRequired ||
    isCheckVariant() ||
    handleCheckMissingTemplateField({ channelType, item, channelID })
  );
};
