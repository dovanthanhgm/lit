import React, { useContext, useLayoutEffect, useMemo } from "react";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { useSelector } from "react-redux";
import ModalListingDetailEditProduct from "src/views/management/ListingDetail/TableListing/ModalListingDetailEditProduct";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";

const ProductDetailListing = () => {
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const { setListingData, listingData, recallProduct } = useContext(
    ListingDetailProductsContext
  );
  const { recallCount } = useContext(ListingDetailCountContext);

  const { setDialogProduct, setOpenDialog, openDialog } = useContext(
    ListingProductDialogContext
  );

  const channelID = channelDetail.channelID;

  const { marketplaces } = useSelector(state => state?.listing);
  const currentTab = useSelector(
    state => state.listing.listingDetail.currentTab
  );

  const isMarketPlace = useMemo(() => {
    return !!marketplaces.map(market => market.id).includes(channelDetail.type);
  }, [marketplaces, channelDetail]);

  const onCloseListingDetail = (publish_id, productValues) => {
    if (productValues) {
      const newListingData = listingData.map(product => {
        if (product.publish_id === publish_id) {
          product = productValues;
        }
        return product;
      });
      setListingData(newListingData);
    }
  };

  useLayoutEffect(() => {
    setOpenDialog(false);
    setDialogProduct({});
    // eslint-disable-next-line
  }, [channelID]);

  return (
    <>
      {openDialog && (
        <ModalListingDetailEditProduct
          currentTab={currentTab}
          getCount={recallCount}
          onCloseListingDetail={onCloseListingDetail}
          getData={recallProduct}
          isMarketPlace={isMarketPlace}
        />
      )}
    </>
  );
};

export default React.memo(ProductDetailListing);
