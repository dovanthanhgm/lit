import {
  Checkbox,
  makeStyles,
  TableCell,
  TableHead,
  TableRow,
  Typography
} from "@material-ui/core";
import { Info as InfoIcon } from "@material-ui/icons";
import React, { useContext } from "react";
import SimpleTooltips from "src/components/Tooltip/SimpleTooltips";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { ListingDetailTableContext } from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import { IS_PREVIEW_CHANNEL } from "src/constants/Listing/index";

const useStyles = makeStyles(theme => ({
  titleTemplate: {
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  tablePaddingCustom: {
    paddingLeft: "13px !important"
  },
  styleHeader: {
    position: "sticky",
    top: 0,
    boxShadow: "none",
    backgroundColor: "white",
    zIndex: 2
  }
}));

// const tableHeadName = ["Status", "Title", "SKU", "Quantity", "Price"];

function TableHeader({
  templatesTitle,
  arrayKeyTemplatesTitle,
  listingProduct
}) {
  const classes = useStyles();

  const { selectedItems, handleSelectAllItems } = useContext(
    ListingDetailTableSelectedProductContext
  );

  const { channelType } = useContext(ListingDetailChannelDetailContext);
  const { tab } = useContext(ListingDetailProductsContext);
  const { tableHeader, tableHeaderTemplate } = useContext(
    ListingDetailTableContext
  );

  const selectedAll = selectedItems.length === listingProduct?.length;
  const selectedSome =
    selectedItems.length > 0 && selectedItems.length < listingProduct?.length;

  const isEbayEtsy = IS_PREVIEW_CHANNEL.includes(channelType);
  const isActiveTab = !["draft", "error"].includes(tab);

  return (
    <TableHead className={classes.styleHeader}>
      <TableRow
      // className={classes.styleHeader}
      // style={{ borderBottom: "1px solid black" }}
      >
        <TableCell
          width="auto"
          padding="checkbox"
          className={classes.tablePaddingCustom}
        >
          <Checkbox
            checked={selectedAll}
            indeterminate={selectedSome}
            onChange={handleSelectAllItems}
          />
        </TableCell>
        <TableCell />
        <TableCell>
          <SimpleTooltips
            title={
              "Indicates whether the listing is linked to a product in the product catalog"
            }
            icon={<InfoIcon color="primary" />}
          />
        </TableCell>
        <TableCell>
          <Typography variant="h6" color="textPrimary">
            Status
          </Typography>
        </TableCell>
        {Object.values(tableHeader).map((item, key) => {
          if (item.isShow) {
            return (
              <TableCell key={key}>
                <Typography
                  variant="h6"
                  color="textPrimary"
                  className={classes.titleTemplate}
                >
                  {item?.label}
                </Typography>
              </TableCell>
            );
          }
          return null;
        })}
        {arrayKeyTemplatesTitle.map(item => {
          if (!tableHeaderTemplate?.[item]?.isShow) {
            return null;
          }
          return (
            <TableCell key={item}>
              <Typography
                className={classes.titleTemplate}
                variant="h6"
                color="textPrimary"
              >
                {templatesTitle[item]}
              </Typography>
            </TableCell>
          );
        })}
        {isActiveTab && isEbayEtsy && <TableCell style={{ width: 50 }} />}
      </TableRow>
    </TableHead>
  );
}

export default TableHeader;
