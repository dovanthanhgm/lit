import { TableBody } from "@material-ui/core";
import React, { useContext, useMemo } from "react";
import TableSkeleton from "src/components/Skeleton/Table";
import { DRAFT_VALUE, ERROR_VALUE } from "src/constants/Listing";
import ListingDetailTableRow from "src/views/management/ListingDetail/ListingDetail/TableRow";
import { useSelector } from "react-redux";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";
import EtsyChannelData from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Etsy/EtsyChannelData";
import EbayChannelData from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Ebay/EbayChannelData";
import AmazonChannelData from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Amazon/AmazonChannelData";
import WalmartChannelData from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Walmart/WalmartChannelData";
import GoogleChannelData from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Google/GoogleChannelData";
import ReverbChannelData from "src/views/management/ListingDetail/ListingDetail/ChannelListing/Reverb/ReverbChannelData";
import WixChannelData from "src/views/channel/Wix/ListingDetail/WixChannelData";

const idName = "publish_id";

const ChannelTableBody = ({ channelType, newProducts }) => {
  const channel = {
    etsy: <EtsyChannelData newProducts={newProducts} />,
    ebay: <EbayChannelData newProducts={newProducts} />,
    amazon: <AmazonChannelData newProducts={newProducts} />,
    walmart: <WalmartChannelData newProducts={newProducts} />,
    google: <GoogleChannelData newProducts={newProducts} />,
    reverb: <ReverbChannelData newProducts={newProducts} />,
    wix: <WixChannelData newProducts={newProducts} />
  };

  if (channel?.[channelType]) {
    return channel[channelType];
  }

  return (
    <TableBody>
      {newProducts?.length > 0 &&
        newProducts.map((item, index) => {
          return (
            <ListingDetailTableRow
              item={item}
              key={item.publish_id || item.id}
              channelType={channelType}
              rowNumber={index}
            />
          );
        })}
      {!newProducts && <TableSkeleton column={9} />}
    </TableBody>
  );
};

const MemoTableBody = React.memo(ChannelTableBody);

function BodyTable({ listingProducts, channelType }) {
  const { variants } = useContext(ListingProductDialogContext);
  const { currentTab } = useSelector(state => state.listing.listingDetail);

  const newProducts = useMemo(() => {
    if (listingProducts?.length > 0 && listingProducts) {
      let newProducts = [];
      listingProducts.forEach(item => {
        newProducts.push(item);
        let variant = variants[item[idName]];
        if (variant?.removed === false) {
          let aList = variant.data.filter((item, index) => index < 11);
          let listVariant =
            aList.length < 11
              ? aList
              : aList.map((item, index) =>
                  index === aList.length - 1
                    ? { ...item, lastItem: "last" }
                    : item
                );
          newProducts = newProducts.concat(listVariant);
        }
        if ([DRAFT_VALUE, ERROR_VALUE].includes(currentTab)) {
          newProducts = newProducts.map(item => {
            return { ...item, link_status: "linked" };
          });
        }
      });
      return newProducts;
    }

    return listingProducts;
    // eslint-disable-next-line
  }, [listingProducts, variants]);

  return <MemoTableBody channelType={channelType} newProducts={newProducts} />;
}

export default React.memo(BodyTable);
