// import { useContext, useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
//
// import { modalVariantChangeListing } from "src/actions/listingActions";
// import { getProductVariantListing } from "src/services/products";
// import { ListingProductDialogContext } from "src/views/management/ListingDetail/ListingDetail/ListingTableBody/ListingTableData";
// import { useSnackbar } from "notistack";
// import {ListingDetailChannelDetailContext} from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
//
// export function useVariant() {
//   const { variants, setVariants, openDialog, dialogProduct } = useContext(
//     ListingProductDialogContext
//   );
//   const {channelDetail} = useContext(ListingDetailChannelDetailContext)
//   const channelID = channelDetail.id;
//   const { modalVariantListing } = useSelector(state => state?.listing);
//   const dispatch = useDispatch();
//   const { enqueueSnackbar } = useSnackbar();
//
//   const getVariant = async (data, dialogProduct) => {
//     const productId = data.parent_id;
//     const resVariations = await getProductVariantListing({
//       channel_id: channelID,
//       productId: productId
//     });
//     if (resVariations) {
//       setVariants(items => ({
//         ...items,
//         [productId]: {
//           ...items[productId],
//           data: resVariations.data.map(itemSmall => ({
//             ...itemSmall,
//             parentIdEdit: productId,
//             parentName: dialogProduct?.name || data?.name,
//             parentPrice: dialogProduct?.price || data?.price,
//             parentLinked: dialogProduct?.link_status,
//             isVariant: true
//           }))
//         }
//       }));
//     }
//   };
//
//   useEffect(() => {
//     let count = false;
//     if (!count) {
//       //call api variant after dialog close, prevent lag
//       if (modalVariantListing !== "" && openDialog === false) {
//         dispatch(modalVariantChangeListing(""));
//         getVariant({ ...modalVariantListing }, dialogProduct).catch(e => {
//           enqueueSnackbar("Get variations fail", {
//             variant: "error"
//           });
//           console.log(e);
//         });
//       }
//     }
//
//     return () => {
//       count = true;
//     };
//     // eslint-disable-next-line
//   }, [modalVariantListing, openDialog]);
//
//   return {
//     variants,
//     setVariants
//   };
// }
