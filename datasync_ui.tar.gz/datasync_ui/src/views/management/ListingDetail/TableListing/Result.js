import React, { useContext } from "react";
import { Box, Divider } from "@material-ui/core";
import GroupButtonListing from "src/views/management/ListingDetail/GroupBulkButton/GroupButtonListing";
import Alert from "../components/Alert";
import SelectedItemText from "../components/SelectedItemText";
import LoadingDetailListing from "src/components/Listings/LoadingDetailListing/index";
import ListingDetailTableSelectedProductProvider from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";
import NotFoundProduct from "src/views/management/ListingDetail/TableListing/NotFoundProduct";
import Pagination from "src/views/management/ListingDetail/TableListing/Pagination";
import TableCustome from "src/views/management/ListingDetail/TableListing/Table";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import PageScrollbarCustom from "src/components/PageScrollbarCustom";
import GridCustom from "../ListingDetail/GridListing/GridList";
import { useSelector } from "react-redux";
import ListingDetailTableProvider from "src/views/management/ListingDetail/Context/ListingDetailtableContext";
import AlertDraft from "src/views/management/ListingDetail/components/AlertDraft";
import TiktokAlertListingDetail from "src/views/management/ListingDetail/components/TiktokAlert";

function Result() {
  const { listingData } = useContext(ListingDetailProductsContext);

  const { listingStyle } = useSelector(state => state.listing);

  return (
    <ListingDetailTableSelectedProductProvider>
      <ListingDetailTableProvider>
        <Box
          style={{
            position: "relative",
            flex: 1,
            flexDirection: "column",
            display: "flex",
            overflow: "hidden"
          }}
        >
          <GroupButtonListing />
          <SelectedItemText />
          <Alert />
          <AlertDraft />
          <LoadingDetailListing />
          <TiktokAlertListingDetail />

          <PageScrollbarCustom
            position={"relative"}
            height={listingStyle === "table" ? "100%" : 0}
          >
            <TableCustome listingProducts={listingData} />
            <NotFoundProduct listingProducts={listingData} />
          </PageScrollbarCustom>
          <PageScrollbarCustom
            position={"relative"}
            height={listingStyle === "grid" ? "100%" : 0}
          >
            <GridCustom products={listingData} />
            <NotFoundProduct listingProducts={listingData} />
          </PageScrollbarCustom>
          <Divider />
          <Pagination />
        </Box>
      </ListingDetailTableProvider>
    </ListingDetailTableSelectedProductProvider>
  );
}

export default React.memo(Result);
