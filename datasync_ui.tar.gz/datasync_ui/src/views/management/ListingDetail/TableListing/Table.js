import { makeStyles, Table } from "@material-ui/core";
import React, { useContext, useMemo } from "react";
import { useSelector } from "react-redux";

import { useIsChannelInMarketplaces } from "src/hooks";
import BodyTable from "./TableBody";
import TableHeader from "./TableHeader";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import useTemplate from "src/hooks/useTemplate";

const useStyles = makeStyles(theme => ({
  customTable: {
    borderCollapse: "separate",
    "& .MuiTableCell-sizeSmall": {
      padding: "6px" // <-- arbitrary value
    },
    "& .MuiTableCell-head": { whiteSpace: "nowrap" }
  }
}));

export const TableContext = React.createContext({
  arrayKeyTemplatesTitle: [],
  listTemplatesObject: {}
});

function TableCustome({ listingProducts }) {
  const { channelType, channelID } = useContext(
    ListingDetailChannelDetailContext
  );
  const classes = useStyles();
  const { isChannelInMarketplaces } = useIsChannelInMarketplaces({
    channelType
  });
  const { listTemplates } = useSelector(state => state.templates);

  const templatesTitle = useTemplate({ channelType, channelID })
    .allChannelTemplatesTitle;

  const arrayKeyTemplatesTitle = useMemo(() => {
    if (templatesTitle) {
      return isChannelInMarketplaces
        ? Object.keys(templatesTitle).filter(item => item !== "recipes")
        : [];
    }
    return [];
  }, [templatesTitle, isChannelInMarketplaces]);

  const listTemplatesObject = useMemo(() => {
    if (!listTemplates) return {};
    const result = {};
    Object.entries(listTemplates).forEach(([key, value]) => {
      const valueObject = {};
      value.forEach(it => {
        valueObject[it.id] = it;
      });
      result[key] = valueObject;
    });

    return result;
  }, [listTemplates]);

  return (
    <TableContext.Provider
      value={{
        arrayKeyTemplatesTitle,
        listTemplatesObject,
        channelType
      }}
    >
      <Table
        size="small"
        style={{ width: "100%" }}
        className={classes.customTable}
      >
        <TableHeader
          listingProduct={listingProducts}
          templatesTitle={templatesTitle}
          arrayKeyTemplatesTitle={arrayKeyTemplatesTitle}
        />
        <BodyTable
          listingProducts={listingProducts}
          channelType={channelType}
        />
      </Table>
    </TableContext.Provider>
  );
}

export default React.memo(TableCustome);
