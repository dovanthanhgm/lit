import React, { useContext, useEffect, useLayoutEffect, useState } from "react";
import { Paper } from "@material-ui/core";
import { useHistory } from "react-router";
import { useQueryV2 } from "src/hooks/useQuery";
import CustomPagination from "src/components/MUI/CustomTable/CustomPagination";
import { ListingDetailTableSelectedProductContext } from "src/views/management/ListingDetail/Context/ListingDetailTableSelectedProductContext";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import { useDispatch, useSelector } from "react-redux";
import wait from "src/utils/wait";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";

function Pagination() {
  const dispatch = useDispatch();
  const history = useHistory();
  const { search, state: urlState } = useQueryV2();
  const page = urlState?.page || 1;
  const state = urlState || {};
  const { currentTab, limit: localLimit } = useSelector(
    state => state.listing.listingDetail
  );

  const setLoading = value => {
    dispatch(
      setFieldListingDetailAction({
        loadingCountProduct: value
      })
    );
  };

  const { onClearData, setLastSelectedRow } = useContext(ListingDetailTableSelectedProductContext);
  const { count, totalCount } = useContext(ListingDetailCountContext);
  const { setPage, tab } = useContext(ListingDetailProductsContext);

  const [tablePage, setTablePage] = useState(1);
  const [tableLimit, setTableLimit] = useState(localLimit);

  useLayoutEffect(() => {
    if (!isNaN(parseInt(page.toString()))) {
      setTablePage(page);
      setPage(page);
    }
    setLastSelectedRow(-1)
    // eslint-disable-next-line
  }, [page]);

  useEffect(() => {
    setTablePage(1);
    history.replace({
      pathname: window.location.pathname,
      search,
      state: { ...state, page: 1 }
    });
    // eslint-disable-next-line
  }, [tab]);

  const handlePageChange = (_, newPage) => {
    const setPages = async newPage => {
      const params = new URLSearchParams(search);
      setLoading(totalCount);
      onClearData();
      setTablePage(newPage + 1);
      await wait(150);
      setPage(newPage + 1);
      history.push(
        {
          search: params.toString()
        },
        { ...state, page: newPage + 1 }
      );
    };

    setPages(newPage).catch(e => {
      setPage(1);
      setTablePage(1);
    });
  };

  const handleLimitChange = event => {
    const setLimitTb = async limitValue => {
      setLoading(totalCount);
      const params = new URLSearchParams(search);
      setTableLimit(limitValue);
      onClearData();
      localStorage.setItem("listingRowPerPage", limitValue);
      await wait(150);
      history.push(
        {
          search: params.toString(),
          limit: limitValue
        },
        { ...state, page: 1, limit: limitValue }
      );
    };

    setLimitTb(event?.target?.value);
  };

  const handleCustomPage = e => {
    handlePageChange(0, e.target.value);
  };

  return (
    <Paper>
      <CustomPagination
        total={count?.[currentTab] ?? 0}
        page={tablePage - 1}
        limit={tableLimit}
        onPageChange={handlePageChange}
        onRowPerPageChange={handleLimitChange}
        onHandleCustomPageChange={handleCustomPage}
      />
    </Paper>
  );
}

export default Pagination;
