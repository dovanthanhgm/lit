import {
  Box,
  Chip,
  makeStyles,
  Tab,
  Tabs,
  Tooltip,
  Typography
} from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import React, { useContext } from "react";
import {
  ARCHIVED,
  DRAFT_VALUE,
  FAILED_VALUE,
  FREEZE_VALUE,
  getTabsFromChannel,
  PENDING_VALUE,
  RETIRED,
  TIKTOK_DRAFT_VALUE,
  UNPUBLISHED
} from "src/constants/Listing";
import {
  tabCallArchive,
  tabCallBanned,
  tabCallDeleted,
  tabCallEnded,
  tabCallEtsyDraft,
  tabCallExpired,
  tabCallFailed,
  tabCallFreeze,
  tabCallInactive,
  tabCallInactiveUpperCase,
  tabCallPending,
  tabCallRetired,
  tabCallSoldOut,
  tabCallTiktokDraft,
  tabCallUnlist,
  tabCallUnpublished
} from "src/views/management/ListingDetail/utils";
import { useQueryV2 } from "src/hooks/useQuery";
import { debounce } from "lodash";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";

export const handleLoading = debounce(
  async ({ setLoadingTab = function() {}, value = false }) => {
    setLoadingTab(value);
  },
  400
);

const useStyles = makeStyles(theme => ({
  labelSmall: {
    paddingLeft: theme.spacing(0.5),
    paddingRight: theme.spacing(0.5)
  },
  chip: {
    marginLeft: theme.spacing(1)
  },
  chipNotSelected: {
    marginLeft: theme.spacing(1),
    color: "#546e7a",
    backgroundColor: "#e4e4e4"
  }
}));

const messageHoverDraft =
  "Drafts are products in editing and not published to channel yet. After published, Draft items will be come Active items";

export const TIKTOK_MESSAGE_PENDING =
  "Products are currently being reviewed by TikTok Shop.";

export const TIKTOK_MESSAGE_FAIL =
  "Products were not approved by TikTok Shop. Please check the Seller Center to find out the reasons.";

export const handleApiCallProductSpecialTab = (
  channel,
  tab,
  searchParams = ""
) => {
  let tabCall;
  switch (tab) {
    case "inactive":
      tabCall = tabCallInactive;
      break;
    case "Inactive":
      tabCall = tabCallInactiveUpperCase;
      break;
    case "sdeleted":
      tabCall = tabCallDeleted;
      break;
    case "unlist":
      tabCall = tabCallUnlist;
      break;
    case "banned":
      tabCall = tabCallBanned;
      break;
    case "etsy_draft":
      tabCall = tabCallEtsyDraft;
      break;
    case "reverb_draft":
      tabCall = tabCallEtsyDraft;
      break;
    case "sold":
      tabCall = tabCallSoldOut;
      break;
    case "sold_out":
      tabCall = tabCallSoldOut;
      break;
    case "expired":
      tabCall = tabCallExpired;
      break;
    case "ended":
      tabCall = tabCallEnded;
      break;
    case RETIRED:
      tabCall = tabCallRetired;
      break;
    case ARCHIVED:
      tabCall = tabCallArchive;
      break;
    case UNPUBLISHED:
      tabCall = tabCallUnpublished;
      break;
    case FAILED_VALUE:
      tabCall = tabCallFailed;
      break;
    case FREEZE_VALUE:
      tabCall = tabCallFreeze;
      break;
    case PENDING_VALUE:
      tabCall = tabCallPending;
      break;
    case TIKTOK_DRAFT_VALUE:
      tabCall = tabCallTiktokDraft;
      break;
    default:
  }

  if (!tabCall) {
    return {};
  }

  const handleSearch = () => {
    const params =
      tabCall?.[channel]?.[searchParams === "" ? "search_product" : "search"] ||
      "";
    if (!!searchParams) return searchParams + params;
    return params;
  };

  return {
    ...tabCall[channel],
    search: handleSearch()
  };
};

const CustomTooltip = withStyles(() => ({
  tooltip: {
    fontSize: 12,
    maxWidth: 350
  }
}))(Tooltip);

const RenderTabLabel = ({ tab, count, isSelected = function() {} }) => {
  // const { channelType } = useContext(ListingDetailChannelDetailContext);

  const classes = useStyles();
  if (tab.value === DRAFT_VALUE) {
    return (
      <CustomTooltip
        title={messageHoverDraft}
        enterDelay={500}
        enterNextDelay={500}
        placement="bottom-start"
      >
        <Box display="flex" alignItems="center">
          <Typography variant="body2">{tab.label}</Typography>
          <Chip
            size="small"
            label={count?.[tab.value]}
            color="primary"
            classes={{ labelSmall: classes.labelSmall }}
            className={
              !isSelected(tab.value) ? classes.chipNotSelected : classes.chip
            }
          />
        </Box>
      </CustomTooltip>
    );
  }

  // if (channelType === "tiktok") {
  //   if (tab.value === PENDING_VALUE) {
  //     return (
  //       <CustomTooltip
  //         title={TIKTOK_MESSAGE_PENDING}
  //         enterDelay={500}
  //         enterNextDelay={500}
  //         placement="bottom-start"
  //       >
  //         <Box display="flex" alignItems="center">
  //           <Typography variant="body2">{tab.label}</Typography>
  //           <Chip
  //             size="small"
  //             label={count?.[tab.value]}
  //             color="primary"
  //             classes={{ labelSmall: classes.labelSmall }}
  //             className={
  //               !isSelected(tab.value) ? classes.chipNotSelected : classes.chip
  //             }
  //           />
  //         </Box>
  //       </CustomTooltip>
  //     );
  //   }
  //   if (tab.value === FAILED_VALUE) {
  //     return (
  //       <CustomTooltip
  //         title={TIKTOK_MESSAGE_FAIL}
  //         enterDelay={500}
  //         enterNextDelay={500}
  //         placement="bottom-start"
  //       >
  //         <Box display="flex" alignItems="center">
  //           <Typography variant="body2">{tab.label}</Typography>
  //           <Chip
  //             size="small"
  //             label={count?.[tab.value]}
  //             color="primary"
  //             classes={{ labelSmall: classes.labelSmall }}
  //             className={
  //               !isSelected(tab.value) ? classes.chipNotSelected : classes.chip
  //             }
  //           />
  //         </Box>
  //       </CustomTooltip>
  //     );
  //   }
  // }

  return (
    <Box display="flex" alignItems="center">
      <Typography variant="body2">{tab.label}</Typography>
      <Chip
        size="small"
        label={count?.[tab.value]}
        color="primary"
        classes={{ labelSmall: classes.labelSmall }}
        className={
          !isSelected(tab.value) ? classes.chipNotSelected : classes.chip
        }
      />
    </Box>
  );
};

function ListingDetailTab() {
  const { search } = useQueryV2();
  const isFilter = !!search;
  const { setListingData, tab, setTab, setLoadingTab, setPage } = useContext(
    ListingDetailProductsContext
  );
  const { totalCount, count } = useContext(ListingDetailCountContext);
  const { channelDetail } = useContext(ListingDetailChannelDetailContext);
  const channelType = channelDetail.channelType;

  const handleTabsChange = (_, value) => {
    if (tab !== value) {
      setTab(value);
      setListingData([]);
      setLoadingTab(true);
      setPage(1);
    }
  };

  const isSelected = tabItem => tabItem === tab;

  if (!!totalCount) {
    return (
      <Tabs
        onChange={handleTabsChange}
        scrollButtons="auto"
        textColor="secondary"
        value={tab}
      >
        {getTabsFromChannel(channelType).map(tab => (
          <Tab
            size="small"
            style={
              (!count?.[tab.value] && !(isFilter && totalCount === 0)) ||
              (isFilter && tab !== tab.value && !count?.[tab.value])
                ? { display: "none" }
                : null
            }
            key={tab.value}
            value={tab.value}
            disabled={isFilter && !count?.[tab.value] && totalCount === 0}
            label={
              <RenderTabLabel tab={tab} count={count} isSelected={isSelected} />
            }
          />
        ))}
      </Tabs>
    );
  }
  return <></>;
}

export default ListingDetailTab;
