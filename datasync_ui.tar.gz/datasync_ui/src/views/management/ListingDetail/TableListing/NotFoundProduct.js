import React, { useContext } from "react";
import { Box, Typography } from "@material-ui/core";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import { useQueryV2 } from "src/hooks/useQuery";

const NotFoundProduct = () => {
  const { search } = useQueryV2();
  const { totalCount } = useContext(ListingDetailCountContext);

  if (totalCount === 0) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" p={1}>
        <Typography variant="body2">
          {search ? "Not found" : "No data"}
        </Typography>
      </Box>
    );
  }
  return null;
};

export default NotFoundProduct;
