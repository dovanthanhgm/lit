import React, { useContext } from "react";
import EditListingModal from "src/views/management/ListingEditProduct/EditListingModal";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ListingProductDialogContext } from "src/views/management/ListingEditProduct/Context/ListingTableVariantContext";

const ModalListingDetailEditProduct = ({
  getCount,
  getData,
  isMarketPlace,
  onCloseListingDetail
}) => {
  const {
    setDialogProduct,
    setOpenDialog,
    openDialog,
    dialogProduct
  } = useContext(ListingProductDialogContext);

  const { channelID, channelType } = useContext(
    ListingDetailChannelDetailContext
  );

  return (
    <EditListingModal
      onCloseListingDetail={onCloseListingDetail}
      status={dialogProduct?.channel_status}
      getCount={getCount}
      getData={getData}
      setOpen={setOpenDialog}
      productStatus={dialogProduct?.channel_status}
      productId={dialogProduct?.publish_id}
      setProductDetail={setDialogProduct}
      productDetail={dialogProduct}
      open={openDialog}
      channelID={channelID}
      channelType={channelType}
      isMarketPlace={isMarketPlace}
    />
  );
};

export default ModalListingDetailEditProduct;
