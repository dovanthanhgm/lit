import React from "react";
import { Card } from "@material-ui/core";
import FilterListing from "../FilterListing";
import ListingTableData from "src/views/management/ListingDetail/ListingDetail/ListingTableBody/ListingTableData";
import ListingDetailTab from "src/views/management/ListingDetail/TableListing/Tabs";

const TableProductListing = () => {
  return (
    <Card style={{ flexDirection: "column", display: "flex" }}>
      <FilterListing />
      <ListingDetailTab />
      <ListingTableData />
    </Card>
  );
};

export default React.memo(TableProductListing);
