import {
  Badge,
  Box,
  FormControl,
  makeStyles,
  MenuItem,
  Select,
  Tooltip
} from "@material-ui/core";
import { Formik } from "formik";
import React, { useEffect, useMemo } from "react";
import { Link as LinkIcon } from "react-feather";
import { useHistory } from "react-router";
import ButtonCustom from "src/components/MUI/Button";
import { useQueryV2 } from "src/hooks/useQuery";
import ListingSortSelect from "src/components/Filter/Listing/ListingSortSelect";
import MoreFilterListing from "src/components/Filter/Listing/MoreFilter";
import DefaultFilter from "src/components/Filter/Listing/DefaultFilter";
import FilterChip from "src/components/Filter/Products/FilterChip";
import SortSelect from "src/components/Filter/Products/SortSelect";
import { useDispatch } from "react-redux";
import { setFieldListingDetailAction } from "src/actions/listingActions";
// import MultiEditSort from "src/components/Filter/Listing/MultiEditSort";

const useStyles = makeStyles(theme => ({
  formControl: {
    marginRight: 8
  }
}));

const productLink = [
  {
    name: "Link Status",
    value: "",
    icon: false
  },
  {
    name: "Linked",
    value: true,
    icon: true,
    color: "primary"
  },
  {
    name: "Unlinked",
    value: false,
    icon: true,
    color: "error"
  },
  {
    name: "Has Unlinked Variations",
    value: 1,
    icon: true,
    color: "error"
  }
];

function Filter({
  setIsClearFilter = function() {},
  isAmazon,
  setParamFilter,
  isMultiEdit = false,
  listChangeLength,
  isProduct = false,
  isListing = false,
  setLoading = function() {},
  extraFilterUrlParam = {},
  setSort = function() {},
  setColumnSort = function() {},
  currentTab,
  setCountSuccess = function() {},
  channelType,
  channelID
}) {
  const classes = useStyles();
  const history = useHistory();
  const dispatch = useDispatch();
  const isMustSave = isMultiEdit && listChangeLength > 0;
  const {
    title,
    linked,
    sku,
    fulfilled_by,
    ebay_status,
    etsy_status,
    asin,
    min_qty = "",
    max_qty = "",
    min_price = "",
    max_price = "",
    amazon_status,
    search,
    variant_unlink,
    sync_error,
    ...value
  } = useQueryV2();

  const listKey = useMemo(() => {
    const filterKey = Object?.keys(value).reduce((prev, curr) => {
      if (curr.includes("template")) {
        prev = [...prev, { [curr]: value[curr] }];
      }
      return prev;
    }, []);
    return filterKey[0];
    // eslint-disable-next-line
  }, [search]);

  const initialValues = {
    title: title?.trim() ?? "",
    linked: linked ?? "",
    sku: sku?.trim() ?? "",
    min_qty: min_qty ?? "",
    max_qty: max_qty ?? "",
    fulfilled_by: fulfilled_by ?? "",
    asin: asin ?? "",
    min_price: min_price ?? "",
    max_price: max_price ?? "",
    amazon_status: amazon_status ?? "",
    ebay_status: ebay_status ?? "",
    etsy_status: etsy_status ?? "",
    sync_error,
    variant_unlink,
    ...listKey,
    ...extraFilterUrlParam
  };

  const handleLoadingMultiEdit = () => {
    if (isMultiEdit) {
      dispatch(
        setFieldListingDetailAction({
          loadingProduct: true
        })
      );
    }
  };

  useEffect(() => {
    if (setParamFilter) {
      setParamFilter({
        title,
        linked,
        sku,
        fulfilled_by,
        ebay_status,
        etsy_status,
        asin,
        min_qty,
        max_qty,
        min_price,
        max_price,
        amazon_status,
        variant_unlink,
        sync_error
      });
    }
  }, [
    setParamFilter,
    title,
    linked,
    sku,
    fulfilled_by,
    ebay_status,
    etsy_status,
    asin,
    min_qty,
    max_qty,
    min_price,
    max_price,
    amazon_status,
    variant_unlink,
    sync_error
  ]);

  return (
    <Formik
      initialValues={initialValues}
      enableReinitialize
      onSubmit={async values => {
        let search = ``;
        let symbol = "?";
        Object.keys(values).forEach(key => {
          if (![null, undefined, "", "NaN", NaN].includes(values[key])) {
            search += `${symbol}${key}=${
              ["title", "sku", "asin"].includes(key)
                ? values[key].trim()
                : values[key]
            }`;
            symbol = "&";
          }
        });

        handleLoadingMultiEdit();
        history.push({
          search: encodeURI(search)
        });
        dispatch(
          setFieldListingDetailAction({
            loadingCountProduct: true
          })
        );
      }}
    >
      {({ values, handleChange, handleSubmit, resetForm }) => {
        const condition = Object.values(values).some(
          item => ![NaN, "", null, undefined].includes(item)
        );

        const handleResetForm = () => {
          setIsClearFilter(false);
          setLoading(true);
          resetForm();
          dispatch(
            setFieldListingDetailAction({
              loadingCountProduct: true
            })
          );
          handleLoadingMultiEdit();
          history.push({ search: "" });
        };

        const handleChangeUnlinkVariant = e => {
          if (e.target.value === 1) {
            handleChange({
              target: {
                name: "linked",
                value: null
              }
            });
            return handleChange({
              target: {
                name: "variant_unlink",
                value: "1"
              }
            });
          } else {
            handleChange({
              target: {
                name: "variant_unlink",
                value: null
              }
            });
            return handleChange(e);
          }
        };

        return (
          <form onSubmit={handleSubmit}>
            <Box p={1} py={1} display="flex" alignItems="center">
              <DefaultFilter isAmazon={isAmazon} />
              <Box display="flex" alignItems="center" ml={1}>
                <FormControl
                  variant="outlined"
                  size="small"
                  className={classes.formControl}
                >
                  <Select
                    name="linked"
                    displayEmpty
                    value={values?.variant_unlink ?? values.linked}
                    onChange={handleChangeUnlinkVariant}
                  >
                    {productLink.map((items, key) => (
                      <MenuItem key={key} value={items.value}>
                        <Tooltip
                          title={
                            !!values?.variant_unlink
                              ? "Find parent products which are linked but contain unlinked variations."
                              : ""
                          }
                        >
                          <Box display="flex" spacing={3}>
                            {items.icon && (
                              <Box mr={1}>
                                <Badge color={items?.color} variant="dot">
                                  <LinkIcon size="14" />
                                </Badge>
                              </Box>
                            )}
                            <Box>{items.name}</Box>
                          </Box>
                        </Tooltip>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                {!isMultiEdit && (
                  <ButtonCustom
                    type="submit"
                    color="secondary"
                    text="Search"
                    disabled={!condition}
                    notShowCircle
                  />
                )}
                {isMultiEdit && (
                  <Tooltip
                    title={isMustSave ? "Please save data before search" : ""}
                  >
                    <span>
                      <ButtonCustom
                        type="submit"
                        color="secondary"
                        text="Search"
                        disabled={!condition || isMustSave}
                        notShowCircle
                      />
                    </span>
                  </Tooltip>
                )}
              </Box>
              <Box mx={1}>
                <ButtonCustom
                  disabled={!search}
                  notShowCircle
                  color="secondary"
                  onClick={() => handleResetForm()}
                  text="Clear"
                />
              </Box>
              <Box>
                {(isListing || isMultiEdit) && <ListingSortSelect />}
                {isProduct && (
                  <SortSelect
                    isProduct
                    setColNameSort={setColumnSort}
                    setCountSuccess={setCountSuccess}
                    setSort={setSort}
                  />
                )}
              </Box>
              <Box ml={1} />
              <MoreFilterListing
                isAmazon={isAmazon}
                isProduct={isProduct}
                currentTab={currentTab}
                channelType={channelType}
                channelID={channelID}
              />
            </Box>
            <FilterChip channelID={channelID} />
          </form>
        );
      }}
    </Formik>
  );
}

export default Filter;
