import { useSelector } from "react-redux";
import { useContext } from "react";
import { ListingDetailCountContext } from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import { isEmpty } from "lodash";
import { useQueryV2 } from "src/hooks/useQuery";

const useHideImportButton = ({ channelID }) => {
  const { search } = useQueryV2();

  const { firstLoading, loadingCountProduct } = useSelector(
    state => state.listing.listingDetail
  );
  const { totalCount } = useContext(ListingDetailCountContext);

  const isFilter = !!search;
  const { listingFilter } = useSelector(state => state.listing);

  const filterRedux = listingFilter?.[`channel_${channelID}`] || {};

  const isFilterRedux = isEmpty(filterRedux);

  const hideImport =
    !firstLoading &&
    totalCount === 0 &&
    !isFilter &&
    !loadingCountProduct &&
    isFilterRedux;

  return { hideImport };
};

export default useHideImportButton;