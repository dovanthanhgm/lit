import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { CHANNEL_NO_ORDER_SETTING } from "src/constants/index";

const useStepGuideChannel = () => {
  const listing = useSelector(state => state.listing.listings) || [];
  const { channelID } = useParams();
  // eslint-disable-next-line
  const channelDetail = listing.find(channel => channel?.id == channelID);
  const channelType = channelDetail?.type;
  const hideStep3 = CHANNEL_NO_ORDER_SETTING.includes(channelType);
  const iStep1Done = channelDetail?.number_products_linked > 0;
  const iStep2Done = !!channelDetail?.sync_price || !!channelDetail?.sync_qty;
  const iStep3Done = !!channelDetail?.sync_order;

  const guideStep = [
    { item: iStep1Done, step: 1 },
    { item: iStep2Done, step: 2 },
    { item: iStep3Done, step: 3 }
  ];
  const completeStep = () => {
    if (hideStep3) {
      return guideStep.filter(step => step.step !== 3);
    }

    return guideStep;
  };

  const initStep = () => {
    let step = 1;
    for (let i = 0; i < completeStep().length; i++) {
      if (!completeStep()[i].item) {
        step = completeStep()[i].step - 1;
        break;
      } else {
        step = completeStep()[i].step;
      }
    }

    return step;
    // return (
    //   [
    //     { item: iStep3Done, step: 3 },
    //     { item: iStep2Done, step: 2 },
    //     { item: iStep1Done, step: 1 }
    //   ].find(items => !!items.item)?.step || 0
    // );
  };

  if (!channelType) {
    return [];
  }

  if (initStep() === 3) {
    return [];
  }

  if (hideStep3 && initStep() === 2) {
    return [];
  }

  return [`${initStep()}/${completeStep().length}`, initStep()];
};

export default useStepGuideChannel;
