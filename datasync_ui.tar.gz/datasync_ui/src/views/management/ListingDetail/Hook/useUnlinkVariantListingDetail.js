import { useContext } from "react";
import { ListingDetailProductsContext } from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";

const getIndexInList = (list = [], itemId) => list.indexOf(itemId);

const useUnlinkVariantListingDetail = () => {
  const { setListingData } = useContext(ListingDetailProductsContext);

  const handleUnlinkVariant = ({
    items = {},
    newId = "",
    listItems = [],
    listNewID = []
  }) => {
    const replaceProductID = (product = {}) => {
      if (product?.publish_id === items?.publish_id) {
        product.publish_id = newId;
        product.link_status = "unlink";
        product.publish_status = "";
        product.publish_action = "";
      }
      return product;
    };

    const replaceAllProductsSelected = (products = {}) => {
      if (listItems.includes(products?.publish_id)) {
        const index = getIndexInList(listItems, products.publish_id);
        if (![null, undefined].includes(index)) {
          products.publish_id = listNewID[index];
          products.link_status = "unlink";
          products.publish_status = "";
          products.publish_action = "";
        }
      }
      return products;
    };

    const handleUnlinkDrive = () => {
      if (
        listItems &&
        listNewID &&
        Array.isArray(listNewID) &&
        listItems.length > 0 &&
        listNewID.length > 0
      ) {
        return replaceAllProductsSelected;
      }
      if (items && Object.keys(items).length > 0 && newId) {
        return replaceProductID;
      }
      return function() {};
    };

    setListingData(products => products.map(handleUnlinkDrive()));
  };

  return { handleUnlinkVariant };
};

export default useUnlinkVariantListingDetail;
