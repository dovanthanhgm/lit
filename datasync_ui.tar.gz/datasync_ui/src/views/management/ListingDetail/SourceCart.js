import { Box, makeStyles, Typography, useTheme } from "@material-ui/core";
import React, { useContext } from "react";
import Paper from "@material-ui/core/Paper";
import StepperGuide from "src/views/pages/Guide/StepperGuide";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { ReactComponent as EmptyBox } from "src/assets/icons/emptyBox.svg";
import { ReactComponent as ConfirmOrderIcon } from "src/assets/icons/confirmOrder.svg";
import useStepGuideChannel from "src/views/management/ListingDetail/Hook/useStepGuideChannel";
import { CHANNEL_NO_ORDER_SETTING } from "src/constants/index";

const EmptyIcon = props => {
  return (
    <EmptyBox component={ConfirmOrderIcon} viewBox="0 0 512 512" {...props} />
  );
};

const useStyles = makeStyles(theme => ({
  largeIcon: {
    width: 160,
    height: 160
  },
  button: {
    marginTop: theme.spacing(1)
  },
  actionsContainer: {
    marginBottom: theme.spacing(1)
  },
  listItemStyle: {
    margin: 0
  },
  resetContainer: {
    padding: theme.spacing(3)
  },
  root: {
    width: "100%",
    maxWidth: 1350,
    backgroundColor: theme.palette.background.paper,
    padding: 0,
    "& .MuiListItem-root": {
      maxWidth: 650,
      padding: theme.spacing(1),
      paddingLeft: 0,
      paddingRight: 0,
      borderTop: "1px solid rgba(0, 0, 0, .125)",
      borderBottom: "1px solid rgba(0, 0, 0, .125)",
      "&:not(:last-child)": {
        borderBottom: 0
      }
    }
  },
  inline: {
    display: "inline"
  },
  listProductStyle: {
    width: 20,
    height: 20,
    color: "white",
    backgroundColor: "#546e7a",
    fontSize: 13
  },
  listItemIcon: {
    minWidth: 0,
    paddingRight: theme.spacing(1),
    marginTop: 0
  },
  listStyle: {
    listStylePosition: "inside",
    listStyleType: "none"
    // "li:before": {
    //   content: "-"
  },
  linkStyle: {
    cursor: "pointer"
  },
  stepperDashboard: {
    "& .MuiStepIcon-completed": {
      color: "#4caf50"
    }
  }
}));

function SourceCart() {
  const classes = useStyles();
  const theme = useTheme();

  const { channelType, channelID } = useContext(
    ListingDetailChannelDetailContext
  );
  const [, initStep] = useStepGuideChannel();
  const isRemoveStepGuideOrder = CHANNEL_NO_ORDER_SETTING.includes(channelType);

  return (
    <div style={{ position: "relative" }}>
      <Paper>
        <Box p={2}>
          <Box display="flex" alignItems="center">
            <Typography variant="h4">You have no listings yet.</Typography>
            <Box mx={0.5} />
            <EmptyIcon
              style={{
                width: 28,
                height: 28,
                fill: theme.palette.primary.main
              }}
              color={"main"}
            />
          </Box>
          <Box py={0.75} />
          <Typography variant="body2">
            To get started, please follow these steps:
          </Typography>
          <Box py={0.75} />
          <StepperGuide
            channelType={channelType}
            classes={classes}
            activeAll
            removeOrderGuide={isRemoveStepGuideOrder}
            initStep={initStep}
            channelID={channelID}
          />
        </Box>
      </Paper>
    </div>
  );
}

export default SourceCart;
