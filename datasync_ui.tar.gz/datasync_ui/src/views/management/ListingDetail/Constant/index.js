export const PUSHING_STATUS = "pushing";
export const PULLING_STATUS = "pulling";
export const DEFAULT_PRODUCT_API_LISTING_DELAY = 180000;
export const DEFAULT_COUNT_API_LISTING_DELAY = 180000;
export const DEFAULT_PROCESS_API_LISTING_DELAY = 190000;
export const PRODUCT_CALL_TIMES_LIMIT = 5;
export const COUNT_CALL_TIMES_LIMIT = 5;
export const PROCESS_CALL_TIMES_LIMIT = 5;

export const SUB_TIMES_ACTION = "sub";
export const PLUS_TIMES_ACTION = "plus";

export const SEARCH_DELAY_TIME = 300000;
export const CREATE_ON_MAIN_DELAY_TIME = 60000;
export const RELOAD_ON_MAIN_DELAY_TIME = 30000;
export const GLOBAL_POPPER_Z_INDEX = 1600;
export const GLOBAL_ROLE_TOOLTIP_Z_INDEX = 1500;

export const LISTING_DETAIL_APPLY_TEMPLATE_DELAY = 30000;
