import React from "react";
import { Box, makeStyles, Typography } from "@material-ui/core";
import { DEFAULT_MARGIN_BOTTOM_HEADER } from "src/constants/index";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import HeaderPageTitle from "src/components/Layout/HeaderPageTitle";
import ButtonCustom from "src/components/MUI/Button";
import clsx from "clsx";
import BigNoti from "src/components/Notify/BigNoti";

const useStyles = makeStyles(theme => ({
  button: {
    marginLeft: theme.spacing(1),
    textAlign: "center"
  },
  cartImage: {
    width: 38,
    height: 38,
    borderRadius: 5,
    objectFit: "contain"
  },
  wixImage: {
    width: 62,
    height: 25
  },
  syncOn: {
    color: theme.palette.primary.main
  },
  syncOff: {
    color: "red"
  },
  rulesOn: {
    color: theme.palette.primary.main
  },
  rulesOff: {
    color: theme.palette.error.main
  },
  header: {
    fontWeight: "bold"
  }
}));

const SYNC_STATUS = ["price", "qty", "order"];

const SyncStatus = {
  price: "Price Sync",
  qty: "Inventory Sync",
  order: "Order Sync"
};

const syncRule = {
  price: "Price Rules",
  qty: "Inventory Rules"
};

const syncOnOff = status => {
  if (status === "enable") {
    return "On";
  }
  return "Off";
};

const HeaderListingDetail = ({
  typeLogo,
  isRulesListing,
  headerName,
  showSetting,
  groupButton = [],
  ...rest
}) => {
  const classes = useStyles();

  const showRule = () => {
    return Object.values(isRulesListing).some(item => item.status);
  };

  const channelImage = {
    wix: classes.wixImage
  };

  const listSync = () => {
    if (["facebook", "google"].includes(typeLogo)) {
      return SYNC_STATUS.filter(item => item !== "order");
    }
    return SYNC_STATUS;
  };

  return (
    <>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="space-between"
        {...rest}
        mb={DEFAULT_MARGIN_BOTTOM_HEADER}
      >
        <Box display="flex" alignItems="center">
          <Box mr={2}>
            <CartLogo
              id={typeLogo}
              className={channelImage?.[typeLogo] || classes.cartImage}
            />
          </Box>
          <div>
            <HeaderPageTitle color="textPrimary">{headerName}</HeaderPageTitle>

            {showSetting && (
              <Box display="flex" alignItems="center" lineHeight={1}>
                <Box display="flex" alignItems="center">
                  {listSync().map((item, index) => (
                    <Box mr={1} key={index}>
                      <Typography variant="h6" component="span">
                        {SyncStatus[item]}
                      </Typography>
                      :{" "}
                      <Typography
                        component="span"
                        variant="h6"
                        className={
                          showSetting[item]?.status === "enable"
                            ? classes.syncOn
                            : classes.syncOff
                        }
                      >
                        {syncOnOff(showSetting[item]?.status)}
                      </Typography>
                    </Box>
                  ))}
                </Box>

                {showRule() && (
                  <Box display="flex" alignItems="center">
                    {Object.keys(syncRule).map((item, index) => {
                      if (
                        isRulesListing[item].status &&
                        isRulesListing[item].value
                      ) {
                        return (
                          <Box mr={1} key={index}>
                            <Typography variant="h6" component="span">
                              {syncRule[item]}
                            </Typography>
                            :{" "}
                            <Typography
                              component="span"
                              className={
                                isRulesListing[item].value
                                  ? classes.rulesOn
                                  : classes.rulesOff
                              }
                              variant="h6"
                            >
                              {isRulesListing[item].value
                                ? "Enabled"
                                : "Disabled"}
                            </Typography>
                          </Box>
                        );
                      }
                      return <React.Fragment key={index}></React.Fragment>;
                    })}
                  </Box>
                )}
              </Box>
            )}
          </div>
        </Box>

        <Box display="flex">
          <Box display="flex" alignItems="center">
            {groupButton?.length > 0 &&
              groupButton.map(
                ({ icon, name, className, ...item }, index) =>
                  !item.isShow && (
                    <ButtonCustom
                      startIcon={icon}
                      key={index}
                      color="primary"
                      className={clsx(classes.button, className)}
                      text={name}
                      {...item}
                    />
                  )
              )}
          </Box>
        </Box>
      </Box>
      <BigNoti />
    </>
  );
};

export default HeaderListingDetail;
