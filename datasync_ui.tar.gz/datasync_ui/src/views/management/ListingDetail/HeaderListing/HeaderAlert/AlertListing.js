import { Box } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import SingleAlert from "src/components/Notify/SingleAlert";
import ListInChannelAlert from "src/views/management/ListingDetail/HeaderListing/HeaderAlert/ListInChannelAlert";
import { useSelector } from "react-redux";

function Alert({ showImport, channelID }) {
  const [startCheckStatus, setStartCheckStatus] = useState(false);
  const [showImportMessage, setShowImportMessage] = useState(false);
  const processRedux = useSelector(state => state.account.runningProcessList);
  // eslint-disable-next-line
  const process = processRedux.find(item => item?.channel_id == channelID);
  const isChannelInPulling =
    !process || ["prepare", "running"].includes(process?.status);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setStartCheckStatus(true);
    }, 20000);
    return () => {
      clearTimeout(timeout);
    };
  }, [process]);

  useEffect(() => {
    if (startCheckStatus) {
      setShowImportMessage(isChannelInPulling);
    }
  }, [startCheckStatus, isChannelInPulling]);

  useEffect(() => {
    setShowImportMessage(showImport);
  }, [showImport]);

  return (
    <>
      <ListInChannelAlert />
      {showImport && showImportMessage && (
        <Box my={0.5}>
          <SingleAlert
            type="info"
            content={
              <>
                <Box>
                  We'll import your listings as quickly as possible, but it may
                  be take some time.
                </Box>
                <Box>
                  You can navigate away from this page - importing won't be
                  affected. We'll notify you when it's done.
                </Box>
              </>
            }
          />
        </Box>
      )}
    </>
  );
}

export default Alert;
