import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { actionChangeTab } from "src/actions/listingActions";
import { Box } from "@material-ui/core";
import SingleAlert from "src/components/Notify/SingleAlert";

const ListInChannelAlert = () => {
  const dispatch = useDispatch();
  const { channelID } = useParams();
  const status = useSelector(state => state?.listing?.isDraft);
  const [channelState] = useState(channelID);

  useEffect(() => {
    if (channelState && channelID !== channelState && status === true) {
      dispatch(actionChangeTab(false));
    }
    // eslint-disable-next-line
  }, [channelID, channelState, status]);

  return (
    <>
      {status && (
        <Box my={0.5}>
          <SingleAlert
            content="Draft listings successfully created. Review and update listings,
          if necessary, then publish when ready."
            type="info"
          />
        </Box>
      )}
    </>
  );
};

export default ListInChannelAlert;
