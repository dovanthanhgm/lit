import React, { useLayoutEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useParams } from "react-router";
import { convertIdToName } from "src/utils/helper";
import HeaderListingDetail from "src/views/management/ListingDetail/HeaderListing/HeaderListingDetail";
import { Box, Chip, Tooltip } from "@material-ui/core";
import useStepGuideChannel from "src/views/management/ListingDetail/Hook/useStepGuideChannel";
import { openListingGuide } from "src/actions/listingActions";
import useHideImportButton from "src/views/management/ListingDetail/Hook/useHideImportButton";
import useUserExp from "src/hooks/useUserExp";
import GetAppIcon from "@material-ui/icons/GetApp";
import SettingsIcon from "@material-ui/icons/Settings";
import { FileText as FileTextIcon } from "react-feather";
import { DEFAULT_ICON_APP_NAV_SIDE } from "src/constants/index";
import { getCurrentTab } from "src/actions/templates";

const rulesSetting = [
  { name: "price", value: ["value"] },
  { name: "qty", value: ["adjust", "max_qty", "min_qty"] }
];

const extraFiled = {
  price: {
    name: "price",
    value: ["rounding"]
  },
  qty: {
    name: "qty",
    value: ["out_of_stock_control"]
  }
};

const renderRuleNumber = (fieldName = "", value = 0) => {
  if (fieldName === "adjust") {
    return value !== 100;
  }
  return value > 0;
};

function HeaderListing({ showImport, channelDetail }) {
  const history = useHistory();
  const dispatch = useDispatch();
  const { expired } = useUserExp();
  const { channelID } = useParams();

  const { hideImport } = useHideImportButton({ channelID });
  const [channelSetting, setChannelSetting] = useState({});
  const { channels } = useSelector(state => state.account.user);
  const { listings } = useSelector(state => state.listing);

  const userChannelSettingById = channels?.reduce((prev, curr) => {
    prev[curr.id] = curr.settings;
    return prev;
  }, {});
  const currentSetting = userChannelSettingById?.[channelID];

  const [textStep] = useStepGuideChannel();

  const gtinExemption = channelDetail.support_amazon_gtin_exemption

  const handleOpenGuide = value => {
    dispatch(openListingGuide(value));
  };

  const handleChannelSettings = e => {
    e.preventDefault();
    history.push(`/listing/${channelID}/settings`, { from: "detail" });
    return false;
  };

  const handleChannelTemplate = e => {
    // eslint-disable-next-line
    let getIndex = listings.findIndex(channel => channel.id == channelID) || 0;

    e.preventDefault();
    history.push(`/settings/templates`);
    dispatch(getCurrentTab({ mainTab: getIndex, subTab: 0 }));
    return false;
  };

  const disabled = showImport || expired;

  const showRulesListing = rulesSetting.reduce((prev, curr) => {
    const extendField = extraFiled[curr?.name];
    prev[curr.name] = {
      value:
        curr.value?.some(value =>
          renderRuleNumber(value, currentSetting?.[curr.name]?.[value])
        ) ||
        extendField?.value.some(value => {
          return ![
            null,
            undefined,
            false,
            "disabled",
            "disable",
            "false",
            "False",
            0,
            "0"
          ].includes(currentSetting?.[curr.name]?.[value]);
        }),
      status: currentSetting?.[curr.name]?.status === "enable"
    };
    return prev;
  }, {});

  useLayoutEffect(() => {
    const settingData = () => {
      if (!currentSetting) {
        return {
          price: {
            status: "disabled"
          },
          order: {
            status: "disabled"
          },
          qty: {
            status: "disabled"
          }
        };
      }
      return {
        price: {
          status: currentSetting?.price?.status || "disabled"
        },
        order: {
          status: currentSetting?.order?.status || "disabled"
        },
        qty: {
          status: currentSetting?.qty?.status || "disabled"
        }
      };
    };
    setChannelSetting(settingData());
  }, [currentSetting]);

  const groupButton = [
    {
      name: (
        <>
          <GetAppIcon style={{ fontSize: DEFAULT_ICON_APP_NAV_SIDE }} />
          <Box mr={0.25} />
          Import From {channelDetail?.type || "type"}{" "}
          {channelDetail?.type === "google" ? "shopping" : ""}
        </>
      ),
      href: `/import-data/listings/${channelDetail.id}`,
      // onClick: importFromChannel,
      disabled: disabled,
      notShowCircle: disabled
    },
    {
      name: (
        <>
          <Box
            width={DEFAULT_ICON_APP_NAV_SIDE}
            display={"flex"}
            alignItems={"center"}
          >
            <FileTextIcon size={DEFAULT_ICON_APP_NAV_SIDE} />
          </Box>
          <Box mr={0.25} />
          Listing Templates/Recipes
        </>
      ),
      onClick: handleChannelTemplate
      // href: `/listing/${channelID}/settings`
    },
    {
      name: (
        <>
          <SettingsIcon style={{ fontSize: DEFAULT_ICON_APP_NAV_SIDE }} />
          <Box mr={0.25} />
          Channel Settings
        </>
      ),
      onClick: handleChannelSettings,
      href: `/listing/${channelID}/settings`
    }
  ];

  // const handleGroupButton = ["walmartca"].includes(channelDetail?.type)
  //   ? groupButton.slice(1)
  //   : groupButton;

  return (
    <HeaderListingDetail
      headerName={
        <span>
          {convertIdToName(channelDetail?.type)} Listings&nbsp;-&nbsp;
          {channelDetail?.name || "name"}&nbsp;
          <span>
            {gtinExemption &&
              <React.Fragment>
                <Chip
                  size='small'
                  component='span'
                  style={{ cursor: 'pointer', backgroundColor:'#f58800', color:'white' }}
                  label='GTIN Exemption'
                />
                &nbsp;
              </React.Fragment>
            }
            {!!textStep && (
              <Tooltip title={`${textStep} progress done. Click for details.`}>
                <Chip
                  size="small"
                  component={"span"}
                  style={{ cursor: "pointer" }}
                  label={`${textStep} done`}
                  color="secondary"
                  onClick={() => {
                    handleOpenGuide(true);
                  }}
                />
              </Tooltip>
            )}
          </span>
        </span>
      }
      showSetting={channelSetting}
      isRulesListing={showRulesListing}
      groupButton={
        !hideImport
          ? groupButton
          : [
              {
                name: (
                  <>
                    <Box
                      width={DEFAULT_ICON_APP_NAV_SIDE}
                      display={"flex"}
                      alignItems={"center"}
                    >
                      <FileTextIcon size={DEFAULT_ICON_APP_NAV_SIDE} />
                    </Box>
                    <Box mr={0.25} />
                    Listing Templates/Recipes
                  </>
                ),
                onClick: handleChannelTemplate
                // href: `/listing/${channelID}/settings`
              },
              {
                name: (
                  <>
                    <SettingsIcon
                      style={{ fontSize: DEFAULT_ICON_APP_NAV_SIDE }}
                    />
                    <Box mr={0.25} />
                    Channel Settings
                  </>
                ),
                onClick: handleChannelSettings,
                href: `/listing/${channelID}/settings`
              }
            ]
      }
      typeLogo={channelDetail.type}
    />
  );
}

export default HeaderListing;
