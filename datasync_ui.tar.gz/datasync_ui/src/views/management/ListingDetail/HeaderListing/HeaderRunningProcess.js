import React, { useRef, useState } from "react";
import { useSelector } from "react-redux";
import { convertIdToName } from "src/utils/helper";
import {
  Box,
  Divider,
  makeStyles,
  Popover,
  Typography
} from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import { RunningProcess } from "src/components/Layout/RunningProcess";

const useStyles = makeStyles(theme => ({
  header: {
    fontWeight: "bold"
  }
}));

export const HeaderRunningProcess = ({ channelID }) => {
  const classes = useStyles();
  const refProgress = useRef(null);
  const [show, setShow] = useState(false);
  const { listings } = useSelector(state => state?.listing);
  const processRedux = useSelector(state => state.account.runningProcessList);
  // eslint-disable-next-line
  const process = processRedux.find(item => item?.channel_id == channelID);

  // const process = {
  //   total: 100,
  //   channel_id: 16405,
  //   imported: 0,
  //   error: 0,
  //   process_type: "listing",
  //   created_at: "2023-05-30 08:00:00"
  // };
  // eslint-disable-next-line
  const channel = listings.find(listing => listing.id == channelID);

  const getChannelName = () => {
    if (!channel) return "";
    return convertIdToName(channel?.type);
  };

  const showProgress = () => {
    setShow(current => !current);
  };

  const cancel = () => {
    setShow(current => !current);
  };

  if (!process || !channelID) {
    return null;
  }

  return (
    <Box ml={1}>
      <CircularProgress
        onMouseEnter={() => showProgress()}
        style={{ cursor: "pointer" }}
        ref={refProgress}
        size={20}
        disableShrink
      />
      <Popover
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right"
        }}
        classes={{ paper: classes.popover }}
        anchorEl={refProgress.current}
        onClose={() => cancel()}
        open={show}
      >
        <Box p={2}>
          <Typography
            variant="h5"
            color="textPrimary"
            className={classes.header}
          >
            Running Processes
          </Typography>
        </Box>
        <Divider />
        <RunningProcess
          name={getChannelName(process.channel_id)}
          channelName={channel?.name}
          progress={process}
        />
      </Popover>
    </Box>
  );
};
