import React, { useContext } from "react";
import HeaderListing from "./Header";
import AlertListing from "src/views/management/ListingDetail/HeaderListing/HeaderAlert/AlertListing";
import { useParams } from "react-router";
import { useSnackbar } from "notistack";
import { Redirect } from "react-router-dom";
import useEbaySetting from "src/hooks/EbaySetting";
import { isEmpty } from "lodash";
import { useGetChannelDetail } from "src/hooks/Listing/useProductListingHook";
import { ProcessContext } from "src/views/management/ListingDetail/Context/ListingDetailProcessContext";
import { useDispatch, useSelector } from "react-redux";
import GuideHelp from "src/views/management/ListingDetail/GuideHelp";
import { getUserInfo } from "src/services/account";
import { setUserData } from "src/actions/accountActions";
import { isStatusProcessActive } from "src/views/management/ListingDetail/Helper/index";

const HeaderListingDetail = () => {
  const { enqueueSnackbar } = useSnackbar();
  const { channelID } = useParams();
  const dispatch = useDispatch();

  useEbaySetting(channelID);

  const channelDetail = useGetChannelDetail();
  const { processStatus } = useContext(ProcessContext);
  const showImport = isStatusProcessActive(processStatus);
  const { isOpenGuide } = useSelector(state => state.listing);

  const getUserData = async () => {
    const data = await getUserInfo();
    if (data) {
      dispatch(setUserData({ ...data }));
    }
  };

  if (isEmpty(channelDetail)) {
    getUserData().catch(e => {
      console.log(e);
      enqueueSnackbar("Channel not found", {
        variant: "error"
      });
    });

    return <Redirect to={"/"} />;
  }

  if (isOpenGuide) {
    return (
      <GuideHelp
        channelType={channelDetail?.type}
        channelID={channelID}
        channelDetail={channelDetail}
      />
    );
  }

  return (
    <>
      <HeaderListing showImport={showImport} channelDetail={channelDetail} />

      <AlertListing showImport={showImport} channelID={channelID} />

      {/*{!isFilter &&*/}
      {/*  !getTotalCount(data) &&*/}
      {/*  !isLoading &&*/}
      {/*  !firstLoading &&*/}
      {/*  !loadingCount && <SourceCart showImport={showImport} />}*/}
    </>
  );
};

export default HeaderListingDetail;
