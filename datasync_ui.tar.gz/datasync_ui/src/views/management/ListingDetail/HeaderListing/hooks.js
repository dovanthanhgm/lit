import { useContext, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router";
import { showImportAlert } from "src/actions/listingActions";
import { getStatusCode } from "src/services/channel";
import { PULLING_STATUS } from "src/views/management/ListingDetail/Constant/index";

export function useHeaderImport() {
  const dispatch = useDispatch();
  const { channelID } = useParams();
  const { processStatus, setProcess } = useContext(ProcessContext);
  const { show_import_alert } = useSelector(state => state?.listing);
  const showImport = show_import_alert || processStatus === PULLING_STATUS;

  useEffect(() => {
    const timeout = setTimeout(() => dispatch(showImportAlert(false)), 6000);
    return () => {
      clearTimeout(timeout);
    };
    // eslint-disable-next-line
  }, [processStatus]);

  useEffect(() => {
    const getStatus = async () => {
      const res = await getStatusCode(channelID);
      if (res) {
        setProcess(res?.[0].status);
        if (res?.[0].status === "completed") {
          dispatch(showImportAlert(false));
        }
      }
    };
    // getStatus();
    //call process one time after 3 second;
    const timeOut = setTimeout(getStatus, 3000);
    const interval = setInterval(() => {
      if (!document.hidden) {
        getStatus();
      }
    }, 63000);

    return () => {
      clearTimeout(timeOut);
      clearInterval(interval);
    };
    // eslint-disable-next-line
  }, [channelID, dispatch]);

  return {
    showImport,
    processStatus
  };
}
