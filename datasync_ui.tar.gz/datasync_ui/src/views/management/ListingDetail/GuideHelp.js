import React, { useEffect } from "react";
import StepperGuide from "src/views/pages/Guide/StepperGuide";
import { Box, Chip, Link, Paper, Typography } from "@material-ui/core";
import { useDispatch } from "react-redux";
import { openListingGuide } from "src/actions/listingActions";
import { makeStyles } from "@material-ui/styles";
import ArrowBackIcon from "@material-ui/icons/ArrowBack";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import HeaderPageTitle from "src/components/Layout/HeaderPageTitle";
import useStepGuideChannel from "src/views/management/ListingDetail/Hook/useStepGuideChannel";
import { convertIdToName } from "src/utils/helper";
import { CHANNEL_NO_ORDER_SETTING } from "src/constants/index";

const useStyles = makeStyles(theme => ({
  largeIcon: {
    width: 160,
    height: 160
  },
  button: {
    marginTop: theme.spacing(1)
  },
  actionsContainer: {
    marginBottom: theme.spacing(1)
  },
  listItemStyle: {
    margin: 0
  },
  resetContainer: {
    padding: theme.spacing(3)
  },
  root: {
    width: "100%",
    maxWidth: 1350,
    backgroundColor: theme.palette.background.paper,
    padding: 0,
    "& .MuiListItem-root": {
      maxWidth: 650,
      padding: theme.spacing(1),
      paddingLeft: 0,
      paddingRight: 0,
      borderTop: "1px solid rgba(0, 0, 0, .125)",
      borderBottom: "1px solid rgba(0, 0, 0, .125)",
      "&:not(:last-child)": {
        borderBottom: 0
      }
    }
  },
  inline: {
    display: "inline"
  },
  listProductStyle: {
    width: 20,
    height: 20,
    color: "white",
    backgroundColor: "#546e7a",
    fontSize: 13
  },
  listItemIcon: {
    minWidth: 0,
    paddingRight: theme.spacing(1),
    marginTop: 0
  },
  listStyle: {
    listStylePosition: "inside",
    listStyleType: "none"
  },
  linkStyle: {
    cursor: "pointer"
  },
  wixImage: {
    width: 62,
    height: 25
  },
  cartImage: {
    width: 36,
    height: 36,
    borderRadius: 5,
    objectFit: "contain"
  },
  stepperDashboard: {
    "& .MuiStepIcon-completed": {
      color: "#4caf50"
    }
  }
}));

const GuideHelp = ({ channelType, channelID, channelDetail }) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const [textStep, initStep] = useStepGuideChannel();

  const handleDispatch = () => {
    dispatch(openListingGuide(false));
  };

  const channelImage = {
    wix: classes.wixImage
  };

  const handleTitle = `${convertIdToName(
    channelType
  )} Listings - ${channelDetail?.name || "name"}`;

  const isRemoveStepGuideOrder = CHANNEL_NO_ORDER_SETTING.includes(channelType);

  useEffect(() => {
    return () => dispatch(openListingGuide(false));
    // eslint-disable-next-line
  }, []);

  return (
    <React.Fragment>
      <Box display="flex" alignItems="center" mb={2}>
        <Box mr={2}>
          <CartLogo
            id={channelType}
            className={channelImage?.[channelType] || classes.cartImage}
          />
        </Box>

        <HeaderPageTitle color="textPrimary">{handleTitle}</HeaderPageTitle>
        <Box mx={0.5} />
        {!!textStep && <Chip size="small" label={textStep} color="secondary" />}
      </Box>
      <Box display="flex" alignItems="center" onClick={handleDispatch} mb={2}>
        <ArrowBackIcon
          fontSize="small"
          color="primary"
          style={{ cursor: "pointer" }}
        />
        <Link style={{ cursor: "pointer" }}>
          <Typography variant="body2">Back to listing</Typography>
        </Link>
      </Box>
      <Paper>
        <Box p={2}>
          <Typography variant="h4">Step by step guide</Typography>
          <Box py={0.75} />
          <StepperGuide
            classes={classes}
            channelType={channelType}
            activeAll
            removeOrderGuide={isRemoveStepGuideOrder}
            initStep={initStep}
            channelID={channelID}
          />
        </Box>
      </Paper>
    </React.Fragment>
  );
};

export default GuideHelp;
