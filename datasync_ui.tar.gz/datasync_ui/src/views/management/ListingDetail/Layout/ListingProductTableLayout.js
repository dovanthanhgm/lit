import React, { useContext } from "react";
import { useSelector } from "react-redux";
import SourceCart from "src/views/management/ListingDetail/SourceCart";
import TableProductListing from "src/views/management/ListingDetail/TableListing/index";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import useHideImportButton from "src/views/management/ListingDetail/Hook/useHideImportButton";

const ListingProductTableLayout = () => {
  const { firstLoading } = useSelector(state => state.listing.listingDetail);
  const { isOpenGuide } = useSelector(state => state.listing);
  const { channelID } = useContext(ListingDetailChannelDetailContext);

  const { hideImport } = useHideImportButton({ channelID });

  if (firstLoading || isOpenGuide) {
    return null;
  }

  if (hideImport) {
    return <SourceCart />;
  }

  return <TableProductListing />;
};

export default ListingProductTableLayout;
