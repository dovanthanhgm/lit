import React, { useContext, useEffect, useMemo, useState } from "react";
import { useQuery } from "react-query";
import {
  FETCH_LISTING_TABLE_COUNT,
  FETCH_LISTING_TABLE_DATA
} from "src/constants/Listing/index";
import {
  listingDetailCount,
  listingDetailProducts
} from "src/services/channel";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import { handleApiCallProductSpecialTab } from "src/views/management/ListingDetail/TableListing/Tabs";
import { useQueryV2 } from "src/hooks/useQuery";
import { useParams } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { ListingDetailChannelDetailContext } from "src/views/management/ListingDetail/Context/ListingDetailChannelDetail";
import { returnMarketplaceTab } from "src/views/management/MainStore/Helper/index";
import ListingDetailCountProvider from "src/views/management/ListingDetail/Context/ListingDetailCountContext";
import ListingDetailProductsProvider from "src/views/management/ListingDetail/Context/ListingDetailProductsContext";
import { fetchListTemplates } from "src/actions/templates";
import { useGetChannelDetail } from "src/hooks/Listing/useProductListingHook";
import { ListingDetailApiDriver } from "src/views/management/ListingDetail/Context/ListingDetailApiDriver";
import { ProcessContext } from "src/views/management/ListingDetail/Context/ListingDetailProcessContext";
import { isStatusProcessActive } from "src/views/management/ListingDetail/Helper/index";
import {
  DEFAULT_COUNT_API_LISTING_DELAY,
  DEFAULT_PRODUCT_API_LISTING_DELAY
} from "src/views/management/ListingDetail/Constant/index";

const getTotalCount = data => {
  if (data) {
    return Object.values(data).reduce((total, tab) => (total += tab), 0);
  }
  return 0;
};

const ListingDetailTableLayout = ({ children }) => {
  const dispatch = useDispatch();
  const { channelID } = useParams();
  const { limit, search: searchParams, state: stateRouter } = useQueryV2();

  const productFilter = useSelector(state => state.listing.listingFilter);
  const productFilterParams = productFilter?.[`channel_${channelID}`] || {};
  const { search: searchRedux, state: stateRedux } = productFilterParams;
  const search = searchParams || searchRedux || "";
  const state = stateRouter || stateRedux;
  const sort = state?.sort;
  const countState = state?.count || 1;

  const [page, setPage] = useState(1);

  const tableLimit = useMemo(() => {
    const limitTable = parseInt(
      limit || localStorage.getItem("listingRowPerPage") || 25
    );
    if (isNaN(limitTable)) {
      return 25;
    }
    return limitTable;
  }, [limit]);

  const tablePage = useMemo(() => page || 1, [page]);

  const channelDetail = useGetChannelDetail();

  const { setChannelDetail } = useContext(ListingDetailChannelDetailContext);
  const { tableCount, tableProduct, listingApiDriver } = useContext(
    ListingDetailApiDriver
  );
  const { processStatus } = useContext(ProcessContext);

  const channelType = channelDetail.type;

  const [count, setCount] = useState({});
  const [tab, setTab] = useState("draft");
  const [countSuccess, setCountSuccess] = useState(false);
  const [loadingTab, setLoadingTab] = useState(false);
  const [product, setProduct] = useState([]);

  const setLoading = value => {
    dispatch(
      setFieldListingDetailAction({
        loadingCountProduct: value
      })
    );
  };

  const listingCount = useQuery(
    [FETCH_LISTING_TABLE_COUNT, channelID, search, countState],
    async () => listingDetailCount({ channelID, search }),
    {
      retryDelay: 30000,
      refetchIntervalInBackground: true,
      onSuccess: data => {
        setChannelDetail({
          ...channelDetail,
          channelType: channelDetail?.type,
          channelID: channelDetail?.id
        });
        if (!getTotalCount(data)) {
          setProduct([]);
          setLoadingTab(false);
          dispatch(
            setFieldListingDetailAction({
              loadingCountProduct: false
            })
          );
        }
        setCount(data);
        if (!!getTotalCount(data) && (!countSuccess || !data?.[tab])) {
          setTab(returnMarketplaceTab(data));
        }
      },
      refetchInterval: tableCount.delay,
      enabled: tableCount.call,
      // cacheTime: ,
      onSettled: () => {
        setCountSuccess(true);
        listingApiDriver.count.timesControl();
        dispatch(
          setFieldListingDetailAction({
            firstLoading: false
          })
        );
      }
    }
  );
  const countLoading = listingCount?.isFetching || false;

  const productRequest = useQuery(
    [
      FETCH_LISTING_TABLE_DATA,
      channelID,
      tab,
      search,
      tableLimit,
      tablePage,
      sort,
      countState
    ],
    () =>
      listingDetailProducts({
        channelID,
        type: tab,
        search,
        sort,
        page: tablePage,
        limit: tableLimit,
        ...handleApiCallProductSpecialTab(channelType, tab, search)
      }),
    {
      enabled:
        !!listingCount.isSuccess &&
        !countLoading &&
        !!count?.[tab] &&
        tableProduct.call,
      retryDelay: 30000,
      refetchIntervalInBackground: true,
      onSuccess: data => {
        setProduct(data);
        setLoadingTab(false);
        dispatch(
          setFieldListingDetailAction({
            currentTab: tab,
            loadingProduct: false,
            loadingCountProduct: false
          })
        );
      },
      refetchInterval: tableProduct.delay,
      onSettled: () => {
        setLoadingTab(false);
        listingApiDriver.product.timesControl();
        dispatch(
          setFieldListingDetailAction({
            loadingCountProduct: false
          })
        );
      }
    }
  );

  useEffect(() => {
    if (isStatusProcessActive(processStatus)) {
      listingApiDriver.product.start(120000);
      listingApiDriver.count.start(120000);
    } else {
      listingApiDriver.product.start(DEFAULT_PRODUCT_API_LISTING_DELAY, 2);
      listingApiDriver.count.start(DEFAULT_COUNT_API_LISTING_DELAY, 2);
    }
    // eslint-disable-next-line
  }, [processStatus]);

  useEffect(() => {
    listingApiDriver.count.start();
    listingApiDriver.product.start();
    // eslint-disable-next-line
  }, [channelID]);

  useEffect(() => {
    if (!search && !isStatusProcessActive(processStatus)) {
      listingApiDriver.product.start(DEFAULT_PRODUCT_API_LISTING_DELAY, 2);
      listingApiDriver.count.start(DEFAULT_COUNT_API_LISTING_DELAY, 2);
    }
    // eslint-disable-next-line
  }, [search, processStatus]);

  useEffect(() => {
    //when create on main, if user change tab limit page or search, time will be reset
    listingApiDriver.product.start(
      isStatusProcessActive(processStatus)
        ? 120000
        : DEFAULT_PRODUCT_API_LISTING_DELAY,
      !isStatusProcessActive(processStatus) ? 2 : 5
    );
    // eslint-disable-next-line
  }, [limit, tab, page, sort]);

  useEffect(() => {
    setProduct([]);
    setLoading(true);
    // eslint-disable-next-line
  }, [channelID]);

  useEffect(() => {
    dispatch(fetchListTemplates({ type: channelType, id: channelID }));
    // eslint-disable-next-line
  }, [channelType, channelID]);

  return (
    <ListingDetailCountProvider
      count={count}
      setCount={setCount}
      recallCount={listingCount.refetch}
    >
      <ListingDetailProductsProvider
        setListingData={setProduct}
        listingData={product}
        tab={tab}
        page={page}
        setPage={setPage}
        setTab={setTab}
        loadingTab={loadingTab}
        setLoadingTab={setLoadingTab}
        recallProduct={productRequest.refetch}
      >
        {children}
      </ListingDetailProductsProvider>
    </ListingDetailCountProvider>
  );
};

export default ListingDetailTableLayout;
