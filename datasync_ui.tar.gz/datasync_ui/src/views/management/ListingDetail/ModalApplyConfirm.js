import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  makeStyles,
  Typography
} from "@material-ui/core";
import React from "react";
import {
  convertTemplateTypeToName,
  uppercaseOneLetter
} from "src/utils/helper";
import DialogTitle from "src/components/Modal/DialogTitle";

const useStyles = makeStyles(theme => ({
  cardActions: {
    display: "flex",
    flexDirection: "row-reverse"
  },
  mrSmall: {
    marginRight: theme.spacing(1)
  }
}));

export default function ModalApplyConfirm({
  template,
  handleClose,
  handleConfirm
}) {
  const classes = useStyles();

  if (!template) {
    return null;
  }

  return (
    <Dialog open={!!template} onClose={handleClose}>
      <DialogTitle>
        Apply {uppercaseOneLetter(convertTemplateTypeToName(template.type))}
      </DialogTitle>
      <DialogContent dividers>
        <Typography
          className={classes.textInDialog}
          variant="body2"
          color="textPrimary"
        >
          Applying this template will alter the selected Draft listings in
          LitCommerce only. You will still need to publish the listings live to
          your sales channel. Are you sure you want to apply template{" "}
          {template.name} to these listings?
        </Typography>
      </DialogContent>
      <DialogActions
        className={classes.cardActions}
        // onClick={handleCloseAddMore}
      >
        <Button size="small" variant="contained" onClick={handleClose}>
          Cancel
        </Button>
        <Button
          size="small"
          color="primary"
          variant="contained"
          className={classes.mrSmall}
          onClick={handleConfirm}
        >
          Yes, apply {convertTemplateTypeToName(template.type)}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
