import { Box } from "@material-ui/core";
import React from "react";

export default function BoxCenter(props) {
  return <Box display="flex" alignItems="center" width="100%" height="100%" {...props} />;
}
