import { TablePagination } from "@material-ui/core";
import React, { useContext, useEffect, useState } from "react";
import { useHistory } from "react-router";
import { useQueryV2 } from "src/hooks/useQuery";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { defaultMultiEditLimit } from "src/constants/Listing";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import { useDispatch } from "react-redux";
import wait from "src/utils/wait";

export default function PaginationCustome() {
  const dispatch = useDispatch();
  const history = useHistory();
  const { page = 1, search } = useQueryV2();

  const { countData, setCanSave, startSave } = useContext(MultiEditContext);
  const { limit, currentTab, setLimit } = useContext(MultiEditTableContext);
  const [currentLimit, setCurrentLimit] = useState(limit || 0);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    setCurrentPage(page);
  }, [page]);

  const handlePageChange = async (_, newPage) => {
    if (startSave) {
      return setCanSave({ page: newPage > 0 ? newPage + 1 : 1 });
    }
    const params = new URLSearchParams(search);
    if (newPage > 0) {
      params.set("page", newPage + 1);
    } else {
      params.delete("page");
    }
    //add laoding
    setCurrentPage(newPage > 0 ? newPage + 1 : 1);
    await wait(300);
    dispatch(
      setFieldListingDetailAction({
        loadingCountProduct: true
      })
    );
    history.push({ page: newPage > 0 ? newPage + 1 : 1, search });
  };

  const handleLimitChange = async event => {
    if (startSave) {
      return setCanSave({ limit: event.target.value });
    }
    localStorage.setItem("listingRowPerPage", event.target.value);
    const params = new URLSearchParams(search);
    params.delete("page");
    setCurrentPage(1);
    setCurrentLimit(event.target.value);

    await wait(300);
    setLimit(event.target.value);
    history.push({ page: 1, search });
  };

  const handleLimit = () => {
    if (typeof limit === "number") {
      return currentLimit;
    }
    return isNaN(currentLimit) ? defaultMultiEditLimit : currentLimit;
  };

  return (
    <TablePagination
      rowsPerPageOptions={[25, 50, 100]}
      count={countData?.[currentTab] ?? 0}
      component="div"
      rowsPerPage={handleLimit()}
      page={currentPage - 1}
      onChangeRowsPerPage={handleLimitChange}
      onChangePage={handlePageChange}
    />
  );
}
