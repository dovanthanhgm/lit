import { cloneDeep } from "lodash";
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState
} from "react";
import { useDispatch, useSelector } from "react-redux";
import { updateFieldMultiEditAction } from "src/reducers/multiEdit";
import { getColumnsGrid, getColumnsGridFromString } from "src/utils/multyEdit";

const min = 50;
let columns = [];

let cloumsgrid = [];
export function useResize({ tableHeaders }) {
  const headerBeingResized = useRef(null);
  const [, setFlag] = useState(false);

  useLayoutEffect(() => {
    cloumsgrid = getColumnsGrid(tableHeaders, cloumsgrid);
    const tables = document.getElementsByClassName("tableResize");
    Array.from(tables).forEach(table => {
      table.style.gridTemplateColumns = cloumsgrid
        .map(({ width }) => width)
        .join(" ");
    });
    setFlag(pre => !pre);
  }, [tableHeaders]);

  const onMouseMove = e =>
    requestAnimationFrame(() => {
      const tables = document.getElementsByClassName("tableResize");
      const table = tables[0];
      const horizontalScrollOffset = table.scrollLeft;
      const column = columns.find(({ header }) =>
        header.includes(headerBeingResized.current)
      );
      if (column) {
        const width =
          horizontalScrollOffset + // 0
          e.clientX -
          column.header[0].offsetLeft -
          table.getBoundingClientRect().x +
          5;

        column.size = Math.max(min, width) + "px"; // Enforce our minimum
        columns.forEach(column => {
          if (column.size.startsWith("minmax")) {
            // isn't fixed yet (it would be a pixel value otherwise)
            column.size = parseInt(column.header[0].clientWidth, 10) + "px";
          }
        });
        Array.from(tables).forEach(item => {
          item.style.gridTemplateColumns = columns
            .map(({ size, i }) => size)
            .join(" ");
        });

        // use for change sticky left "Name (Title)" column
        if (column.header[0]?.classList?.contains("column-sku")) {
          const allTitleColumn = document.getElementsByClassName("column-name");
          Array.from(allTitleColumn).forEach(item => {
            item.style.left = 72 + width + "px";
          });
        }
      }
    });

  // Clean up event listeners, classes, etc.
  const onMouseUp = useCallback(() => {
    const table = document.getElementsByClassName("tableResize")[0];
    cloumsgrid = getColumnsGridFromString(
      tableHeaders,
      table.style.gridTemplateColumns
    );
    window.removeEventListener("mousemove", onMouseMove);
    window.removeEventListener("mouseup", onMouseUp);
    if (headerBeingResized?.current?.classList) {
      headerBeingResized.current.classList.remove("header--being-resized");
    }
    headerBeingResized.current = null;
  }, [tableHeaders]);

  // Get ready, they're about to resize
  const initResize = useCallback(
    ({ target }) => {
      headerBeingResized.current = target.parentNode;
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      window.addEventListener("mousemove", onMouseMove);
      window.addEventListener("mouseup", onMouseUp);
      headerBeingResized.current.classList.add("header--being-resized");
    },
    [onMouseUp]
  );

  useEffect(() => {
    let parent;
    columns = [];
    let i = 0;
    document.querySelectorAll("th").forEach(header => {
      if (header.className?.includes("canResize")) {
        if (parent && header.className?.includes("isLastChild")) {
          columns.push({
            header: [header, parent],
            // The initial size value for grid-template-columns:
            size: cloumsgrid?.[i]?.width || `minmax(${min}px, 1fr)`
          });
          parent = null;
        } else {
          columns.push({
            header: [header],
            // The initial size value for grid-template-columns:
            size: cloumsgrid?.[i]?.width || `minmax(${min}px, 1fr)`
          });
        }
        i++;
      } else {
        parent = header;
      }

      if (header.querySelector(".resize-handle")) {
        header
          .querySelector(".resize-handle")
          .removeEventListener("mousedown", initResize);
        header
          .querySelector(".resize-handle")
          .addEventListener("mousedown", initResize);
      }
    });
  }, [initResize]);

  return { cloumsgrid };
}

export const useSelectRow = ({ cloneList }) => {
  const selectedItems = useSelector(state => state.multiEdit.selectedItems);
  const dispatch = useDispatch();

  const [lastSelectedRow, setLastSelectedRow] = useState(-1)

  const handleSelectOneItem = (itemId, selectedIndex, isPressShip) => {
    let _selected = cloneDeep(selectedItems);
    
    let shiftSelected =[]
    if(isPressShip){
      shiftSelected =
        selectedIndex > lastSelectedRow
        ? cloneList.slice(lastSelectedRow, selectedIndex + 1)
        : cloneList.slice(selectedIndex, lastSelectedRow + 1);
    } //Because slice doesnt take the second index element into the new Array

    const shiftSelectedIds = shiftSelected.map(selected => selected.publish_id);

    let _newSelected = [];

    if (!selectedItems.includes(itemId)) {
      if (isPressShip) {
        _newSelected = [...new Set([..._selected, ...shiftSelectedIds, itemId])];
        
        setLastSelectedRow(() => selectedIndex);
        dispatch(
          updateFieldMultiEditAction({
            selectedItems: [..._newSelected]
          })
          );
        return;
      } else {
        setLastSelectedRow(() => selectedIndex);
        _newSelected = [...new Set([..._selected, itemId])];
        dispatch(
          updateFieldMultiEditAction({
            selectedItems: [..._newSelected]
          })
        );
      }
    } else {
      if(isPressShip){
        _newSelected = _selected.filter(selected => !shiftSelectedIds.includes(selected));

        let _lastSelected = selectedIndex;

        if (_newSelected.length !== 0)  
           _lastSelected = selectedIndex > lastSelectedRow ? selectedIndex + 1 : selectedIndex - 1;
          // When the new length is 0, the last select index is equal to the rowNumber
          /* When it's not, we consider the new index and the last index, if the new one is bigger, it means that we have to check those ones
          that are under, we need to add 1 to last selectedRow, so that when we get the new shiftSelected items, it would only get the items that 
          are not already previously selected. Same goes to the above items.
          But still, I highly recommend you read the logic and log it out step to step to fully understand it */
        setLastSelectedRow(() => _lastSelected);

        dispatch(
          updateFieldMultiEditAction({
            selectedItems: [..._newSelected]
          })
        );
      } else{
        setLastSelectedRow(() => selectedIndex);
        dispatch(
          updateFieldMultiEditAction({
            selectedItems: selectedItems.filter(id => id !== itemId)
          })
        );
      }
    }
  };

  const handleSelectAllItems = event => {
    if (event.target.checked) {
      dispatch(
        updateFieldMultiEditAction({
          selectedItems: cloneList.map(item => item.publish_id)
        })
        );
      } else {
      setLastSelectedRow(-1)
      dispatch(
        updateFieldMultiEditAction({
          selectedItems: []
        })
      );
    }
  };

  return {
    handleSelectOneItem,
    handleSelectAllItems
  };
};

export const calculateRowPerPage = limit => {
  const parsePage = parseInt(localStorage.getItem("listingRowPerPage"));
  if (!isNaN(parsePage)) {
    return parsePage;
  }
  return parseInt(limit) || 10;
};
