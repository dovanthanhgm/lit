export const redirectUrl = params => {
  let search = ``;
  let symbol = "?";
  Object.keys(params).forEach(key => {
    if (params[key] || params[key] === false) {
      search += `${symbol}${key}=${
        ["title", "sku", "asin"].includes(key)
          ? params[key].trim()
          : params[key]
      }`;
      symbol = "&";
    }
  });
  return search;
};
