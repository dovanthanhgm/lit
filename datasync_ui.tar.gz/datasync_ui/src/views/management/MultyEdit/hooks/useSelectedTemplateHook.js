import { useSelector } from "react-redux";

const useSelectedTemplateHook = data => {
  const templateList = useSelector(
    state => state?.templates?.listTemplates?.["category"]
  );

  const templateSelected = templateList?.find(
    item => item.id === data.templates?.category
  );

  const templateName = templateSelected?.name || "";

  return { templateName };
};

export default useSelectedTemplateHook;
