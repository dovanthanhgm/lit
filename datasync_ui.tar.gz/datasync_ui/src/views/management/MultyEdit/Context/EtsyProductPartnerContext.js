import React from "react";
import useShippingProfile from "src/views/management/ListingEditProduct/Hooks/Channel/Etsy/useShippingProfile";

export const EtsyProductPartnerContext = React.createContext({
  partner: [],
  dataShipping: []
});

const EtsyProductPartnerProvider = ({ channelID, channelType, children }) => {
  const { partner, dataShipping } = useShippingProfile({
    channelID,
    channelType
  });

  return (
    <EtsyProductPartnerContext.Provider
      value={{
        partner,
        dataShipping
      }}
    >
      {children}
    </EtsyProductPartnerContext.Provider>
  );
};

export default EtsyProductPartnerProvider;
