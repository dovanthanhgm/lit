import React, { useEffect, useState } from "react";
import {
  etsySectionPath,
  getLocalstorageValue,
  handleSetLocalValue
} from "src/helper/handleLocalstorageValue";
import { getSectionEtsyTemplates } from "src/services/templates";

export const EtsySectionContext = React.createContext({
  section: [],
  setSection: function() {},
  fetchSection: function () {}
});

const EtsySectionProvider = ({ channelID, children }) => {
  const pathSection = etsySectionPath(channelID);

  const initLocalSection = getLocalstorageValue({
    pathValue: pathSection,
    defaultValue: null
  });
  const [section, setSection] = useState(initLocalSection || []);

  async function fetchSection() {
    const data = await getSectionEtsyTemplates({ channel_id: channelID });
    if (data?.data) {
      setSection(data?.data);
      handleSetLocalValue({ pathValue: pathSection, value: data.data });
    }
  }

  useEffect(() => {
    if (!initLocalSection) {
      fetchSection().catch(e => {
        handleSetLocalValue({ pathValue: pathSection, value: [] });
      });
    }
    // eslint-disable-next-line
  }, [channelID, setSection]);

  return (
    <EtsySectionContext.Provider
      value={{
        section,
        setSection,
        fetchSection
      }}
    >
      {children}
    </EtsySectionContext.Provider>
  );
};

export default EtsySectionProvider;
