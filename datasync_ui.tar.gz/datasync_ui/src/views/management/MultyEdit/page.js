import { makeStyles } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { turnOnMultiEdit } from "src/actions/listingActions";
import Page from "src/components/Page";
import { topAppBarHeight } from "src/constants";
import MultiEditHeader from "src/views/management/MultyEdit/MultiEditHeader";
import MultiEditLayout from "src/views/management/MultyEdit/Layout/MultiEditLayout";
import MultiEditTableLayout from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    padding: `${theme.spacing(1)}px 0`,
    height: "100%",
    overflow: "hidden"
  },
  modalContainer: {
    top: topAppBarHeight,
    position: "absolute",
    right: 0,
    width: "80%"
    // zIndex: 9999
  }
}));

const multiEditInfo = {
  channelDetail: {},
  setChannelDetail: function() {},
  totalProduct: -1,
  setTotalProduct: function() {},
  canSave: false,
  setCanSave: function() {},
  startSave: false,
  setStartSave: function() {},
  listChangeLength: 0,
  setListChangeLength: function() {},
  countData: {},
  setCountData: function() {}
};

export const MultiEditContext = React.createContext(multiEditInfo);

function PageMultiEdit() {
  const classes = useStyles();
  const dispatch = useDispatch();

  const [channelDetail, setChannelDetail] = useState({});
  const [countData, setCountData] = useState({});
  const [totalProduct, setTotalProduct] = useState(-1);
  const [canSave, setCanSave] = useState(false);
  const [startSave, setStartSave] = useState(false);
  const [listChangeLength, setListChangeLength] = useState(false);

  useEffect(() => {
    dispatch(turnOnMultiEdit(true));
  }, [dispatch]);

  return (
    <Page className={classes.root} title="Multi Edit" noPadding>
      <ErrorBoundaryComponent>
        <MultiEditLayout>
          <MultiEditContext.Provider
            value={{
              setChannelDetail,
              channelDetail,
              setTotalProduct,
              totalProduct,
              canSave,
              setCanSave,
              listChangeLength,
              setListChangeLength,
              setStartSave,
              startSave,
              countData,
              setCountData
            }}
          >
            <MultiEditHeader />
            <MultiEditTableLayout />
          </MultiEditContext.Provider>
        </MultiEditLayout>
      </ErrorBoundaryComponent>
    </Page>
  );
}

export default React.memo(PageMultiEdit);
