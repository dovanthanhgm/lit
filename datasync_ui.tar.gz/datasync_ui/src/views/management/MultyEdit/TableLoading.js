import React, { useContext, useState } from "react";
import LoadingTable from "src/views/management/MultyEdit/Table/LoadingTable";
import { isEmpty } from "lodash";
import { Paper } from "@material-ui/core";
import TabsCustom from "src/views/management/MultyEdit/Tabs";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { makeStyles } from "@material-ui/styles";

const useStyles = makeStyles((theme) => ({
  tableTabContainer: {
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0,
    marginTop: theme.spacing(1),
    boxShadow: 'none',
    border: '1px solid rgba(63,63,68,0.15)',
  }
}));

const TableLoading = () => {
  const classes = useStyles();
  const { countData } = useContext(MultiEditContext);
  const [loadingMulti, setLoadingMulti] = useState(false);

  return (
    <>
      {!isEmpty(countData) && (
        <Paper className={classes.tableTabContainer}>
          <TabsCustom
            loadingMulti={loadingMulti}
            setLoadingMulti={setLoadingMulti}
          />
        </Paper>
      )}
      <LoadingTable
        loadingMulti={loadingMulti}
        setLoadingMulti={setLoadingMulti}
      />
    </>
  );
};

export default TableLoading;
