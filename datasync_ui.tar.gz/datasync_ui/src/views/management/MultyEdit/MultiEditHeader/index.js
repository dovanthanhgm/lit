import React, { useContext, useMemo } from "react";
import { useQuery } from "react-query";
import {
  channelMultiEdit,
  FETCH_LISTING_TABLE_COUNT
} from "src/constants/Listing";
import { listingDetailCount } from "src/services/channel";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router";
import { useQueryV2 } from "src/hooks/useQuery";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import MultiEditHeaderFilter from "src/views/management/MultyEdit/MultiEditHeader/MultiEditHeaderFilter";
import { Redirect } from "react-router-dom";
import { isEmpty } from "lodash";
import LoadingScreen from "src/components/Loading/LoadingScreen";
import ChannelNecessaryInformation from "src/views/management/MultyEdit/Layout/Channel/ChannelNecessaryInformation";
import { fetchListTemplates } from "src/actions/templates";

const getTotalCount = data => {
  if (data) {
    return Object.values(data).reduce((total, tab) => (total += tab), 0);
  }
  return 0;
};

const MultiEditHeader = () => {
  const dispatch = useDispatch();
  const { channelID } = useParams();
  const { search } = useQueryV2();

  const {
    setChannelDetail,
    setTotalProduct,
    totalProduct,
    setCountData
  } = useContext(MultiEditContext);

  const { listings, defaultListing } =
    useSelector(state => state.listing) || [];

  const listChannelById = useMemo(() => {
    return listings.reduce((listChannel, channel) => {
      listChannel[channel.id] = channel.type;
      return listChannel;
    }, {});
  }, [listings]);

  const channelDetail =
    listings?.find(channel => channel?.id?.toString() === channelID) || {};

  const handleSetChannelDetail = ({ channelDetail }) => {
    setChannelDetail(channelDetail);
  };

  useQuery(
    [FETCH_LISTING_TABLE_COUNT, channelID, search],
    async () => listingDetailCount({ channelID, search }),
    {
      retryDelay: 30000,
      // refetchIntervalInBackground: true,
      onSuccess: data => {
        setTotalProduct(getTotalCount(data));
        setCountData(data);
        if (!getTotalCount(data)) {
          dispatch(
            setFieldListingDetailAction({
              loadingCountProduct: false
            })
          );
        }
      },
      refetchInterval: 60000,
      enabled: !!channelID,
      // cacheTime: ,
      onSettled: () => {
        if (channelDetail && !isEmpty(channelDetail)) {
          handleSetChannelDetail({ channelDetail });
          dispatch(
            fetchListTemplates({ type: channelDetail.type, id: channelID })
          );
        }
        dispatch(
          setFieldListingDetailAction({
            firstLoading: false
          })
        );
      }
    }
  );

  if (defaultListing?.id?.toString() === channelID) {
    return <Redirect to={"/products"} />;
  }

  if (!channelMultiEdit.includes(listChannelById[channelID])) {
    return <Redirect to={`/listing/detail/${channelID}`} />;
  }

  if (totalProduct < 0 || isEmpty(channelDetail)) {
    return <LoadingScreen />;
  }

  return (
    <>
      <ChannelNecessaryInformation channelDetail={channelDetail} />
      <MultiEditHeaderFilter />
    </>
  );
};

export default MultiEditHeader;
