import React, { useContext } from "react";
import { Box, Card } from "@material-ui/core";
import Filter from "src/views/management/ListingDetail/Filter";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const MultiEditHeaderFilter = () => {
  const { channelDetail, setCanSave, listChangeLength } = useContext(
    MultiEditContext
  );

  const channelType = channelDetail?.type;

  return (
    <Box display="flex" alignItems="center">
      <Card style={{ width: "100%" }}>
        <Filter
          isMultiEdit
          setCanSave={setCanSave}
          listChangeLength={listChangeLength}
          isAmazon={channelType === "amazon"}
          channelType={channelType}
          channelID={channelDetail.id}
        />
      </Card>
    </Box>
  );
};

export default MultiEditHeaderFilter;
