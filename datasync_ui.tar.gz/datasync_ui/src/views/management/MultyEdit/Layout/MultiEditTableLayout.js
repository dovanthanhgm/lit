import React, { useContext, useState } from "react";
import GroupButton from "src/views/management/MultyEdit/GroupButton";
import { multiEdit } from "src/utils/multyEdit";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { Box, Paper } from "@material-ui/core";
import { useStyles } from "src/views/management/MultyEdit/style";
import Pagination from "src/views/management/MultyEdit/components/Pagination";
import { defaultMultiEditLimit, returnTab } from "src/constants/Listing";
import { useSelector } from "react-redux";
import TableLoading from "src/views/management/MultyEdit/TableLoading";
import MultyEdit from "src/views/management/MultyEdit/index";
import MultiEditEtsyLayout from "src/views/management/MultyEdit/Layout/Channel/Etsy/MultiEditEtsyLayout";
import ReverbMultiEditWrapper from "src/views/channel/Reverb/MultiEdit/Components/ReverbMultiEditWrapper";

const tableContextInfo = {
  listProducts: [],
  setListProducts: function() {},
  tableHeaders: {},
  setTableHeaders: function() {},
  cloneList: [],
  setCloneList: function() {},
  listChanging: [],
  setListChanging: function() {},
  currentTab: "",
  setCurrentTab: function() {},
  limit: defaultMultiEditLimit,
  setLimit: function() {}
};

export const MultiEditTableContext = React.createContext(tableContextInfo);

const ChannelMultiEditWrap = ({ children, channelType }) => {
  const channel = {
    etsy: <MultiEditEtsyLayout>{children}</MultiEditEtsyLayout>,
    reverb: <ReverbMultiEditWrapper>{children}</ReverbMultiEditWrapper>
  };
  if (channel?.[channelType]) {
    return channel[channelType];
  }
  return children;
};

const MultiEditTableLayout = () => {
  const { channelDetail, countData } = useContext(MultiEditContext);
  const channelType = channelDetail.type;
  const classes = useStyles();
  const { firstLoading } = useSelector(state => state.listing.listingDetail);

  const [listProducts, setListProducts] = useState([]);
  const [cloneList, setCloneList] = useState([]);
  const [currentTab, setCurrentTab] = useState(returnTab(countData));
  const [limit, setLimit] = useState(
    localStorage.getItem("listingRowPerPage") || defaultMultiEditLimit
  );
  const [tableHeaders, setTableHeaders] = useState(multiEdit(channelType));

  return (
    <MultiEditTableContext.Provider
      value={{
        listProducts,
        setListProducts,
        tableHeaders,
        setTableHeaders,
        cloneList,
        setCloneList,
        currentTab,
        setCurrentTab,
        limit,
        setLimit,
      }}
    >
      {!firstLoading && (
        <Box
          position="relative"
          overflow="hidden"
          display="flex"
          flexDirection="column"
        >
          <GroupButton />
          <TableLoading />
          <ChannelMultiEditWrap channelType={channelType}>
            <MultyEdit />
          </ChannelMultiEditWrap>
          <Paper className={classes.tablePaginateContainer}>
            <Pagination />
          </Paper>
        </Box>
      )}
    </MultiEditTableContext.Provider>
  );
};

export default MultiEditTableLayout;
