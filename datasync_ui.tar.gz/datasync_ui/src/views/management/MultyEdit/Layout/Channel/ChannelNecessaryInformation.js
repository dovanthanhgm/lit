import React from "react";
import MultiEditEbay from "src/views/management/MultyEdit/Layout/Channel/Ebay";
import MultiEditAmazon from "src/views/management/MultyEdit/Layout/Channel/Amazon";

const ChannelNecessaryInformation = ({ channelDetail }) => {
  const ComponentByChannel = {
    ebay: <MultiEditEbay channelDetail={channelDetail} />,
    amazon: <MultiEditAmazon channelDetail={channelDetail} />
  };

  const type = channelDetail.type;
  return <>{ComponentByChannel?.[type]}</>;
};

export default ChannelNecessaryInformation;
