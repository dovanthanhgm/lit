import React from "react";
import useEbaySetting from "src/hooks/EbaySetting";

const MultiEditEbay = ({ channelDetail }) => {
  const channelID = channelDetail?.id;

  useEbaySetting(channelID);

  return <></>;
};

export default MultiEditEbay;
