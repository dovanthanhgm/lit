import React, { useEffect } from "react";
import { getCategoriesAmazon } from "src/services/products";
import { storeAmazonCategory } from "src/reducers/multiEdit";
import { useDispatch } from "react-redux";
import { useSnackbar } from "notistack";

const MultiEditAmazon = ({ channelDetail }) => {
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();

  const channelID = channelDetail?.id;

  useEffect(() => {
    if (channelDetail && channelDetail?.id) {
      async function fetchCategoriesAmazon() {
        const data = await getCategoriesAmazon({ channel_id: channelID });
        if (data) {
          dispatch(storeAmazonCategory(data?.categories));
        }
      }

      fetchCategoriesAmazon().catch(e => {
        enqueueSnackbar("Get amazon setting error", {
          variant: "error"
        });
        console.log(e);
      });
    }
    // eslint-disable-next-line
  }, [channelID]);

  return <></>;
};

export default MultiEditAmazon;
