import React from "react";
import EtsySectionProvider from "src/views/management/MultyEdit/Context/EtsySectionContext";
import { useParams } from "react-router";
import EtsyProductPartnerProvider from "src/views/management/MultyEdit/Context/EtsyProductPartnerContext";

const MultiEditEtsyLayout = ({ channelType, children }) => {
  const { channelID } = useParams();
  return (
    <EtsyProductPartnerProvider channelID={channelID} channelType={channelType}>
      <EtsySectionProvider channelID={channelID}>
        {children}
      </EtsySectionProvider>
    </EtsyProductPartnerProvider>
  );
};
export default MultiEditEtsyLayout;
