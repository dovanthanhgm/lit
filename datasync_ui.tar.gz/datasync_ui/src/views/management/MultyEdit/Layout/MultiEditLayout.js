import React from "react";
import { QueryClient, QueryClientProvider } from "react-query";
import { ReactQueryDevtools } from "react-query/devtools";
import { useSelector } from "react-redux";
import { Redirect } from "react-router-dom";
import { isEmpty } from "lodash";
import { Box } from "@material-ui/core";
import { withAccessChannelEdit } from "src/hooks/hocs";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false
    }
  }
});

function Layout({ children }) {
  const user = useSelector(state => state?.account.user) || [];

  if (isEmpty(user)) {
    return <Redirect to={"/"} />;
  }
  return (
    <Box
      height="100%"
      overflow="hidden"
      mx={2}
      display="flex"
      flexDirection="column"
    >
      {children}
    </Box>
  );
}

const MultiEditLayout = ({ children }) => {
  return (
    <QueryClientProvider client={queryClient}>
      <Layout children={children} />
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
};

export default withAccessChannelEdit(MultiEditLayout);
