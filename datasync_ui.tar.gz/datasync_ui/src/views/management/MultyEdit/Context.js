import React from "react";

export const MultiEditStickyContext = React.createContext({
  skuColumnWidth: 0
});

export const MultiEditContextStickyContainer = ({
  skuColumnWidth,
  children
}) => {
  return (
    <MultiEditStickyContext.Provider value={{ skuColumnWidth }}>
      {children}
    </MultiEditStickyContext.Provider>
  );
};
