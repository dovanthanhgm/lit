import { makeStyles } from "@material-ui/core";
import grey from "@material-ui/core/colors/grey";

const tableBorder = grey[300];

const stickyColor = '#f4f6f8'
const selectedColor = '#f4f6f8'

export const useStyles = makeStyles(theme => ({
  tableOverflowStyle: {
    borderRadius: 0,
    paddingBottom: "1px",
    overflow: "auto",
    boxShadow: "none",
    border: '1px solid rgba(63,63,68,0.15)',
    borderTop: 'none',
    borderBottom: 'none',
    height: '100vh',
    "&::-webkit-scrollbar": {
      width: "10px",
      height: "10px"
    },
    "&::-webkit-scrollbar-thumb:hover": {
      background: "#a3a3a3"
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: "#cccccc",
      width: "4px",
      height: "4px",
      borderRadius: 10,
      "-webkit-transition":
        "background-color .2s linear, width .2s ease-in-out",
      border: "2px solid transparent",
      backgroundClip: "padding-box",
      "&:hover": {
        overflow: "overlay"
      }
    }
  },
  tableTabContainer: {
    borderBottomRightRadius: 0,
    borderBottomLeftRadius: 0
  },
  tablePaginateContainer: {
    borderTopRightRadius: 0,
    borderTopLeftRadius: 0,
    borderBottomRightRadius: 4,
    borderBottomLeftRadius: 4,
    boxShadow: "none",
    border: '1px solid rgba(63,63,68,0.15)',

    "& .MuiToolbar-root": {
      minHeight: "40px"
    },

    "& .MuiTablePagination-actions .MuiButtonBase-root": {
      paddingTop: "8px",
      paddingBottom: "8px"
    }
  },
  productImage: {
    width: 48,
    height: 48
  },
  titleTemplate: {
    overflow: "hidden",
    textOverflow: "ellipsis",
    display: "inline-block"
  },
  titleTemplateSKU: {
    display: "inline-block"
  },
  customTableHeader: {
    "& th, & td": {
      background: "white"
    }
  },
  customTable: {
    // row selected by click cell or checked
    "& tr.row-selected, & tr.selectedByClick": {
      "& td": {
        background: selectedColor
      },
      "& #normal-cell": {
        backgroundColor: selectedColor
      },
    },

    "& #checkbox-cell": {
      backgroundColor: stickyColor
    },
    "& #image-cell": {
      backgroundColor: stickyColor
    },
    "& #header-cell": {
      backgroundColor: stickyColor
    },
    "& #link-cell": {
      backgroundColor: stickyColor
    },
    "& #status-cell": {
      backgroundColor: stickyColor
    },
    "& #identifier-cell": {
      backgroundColor: stickyColor
    },
    "& #normal-cell": {
      backgroundColor: '#fff'
    },
    "& .MuiTableCell-body.MuiTableCell-sizeSmall": {
      padding: "2px 0 !important"
    },
    "& .MuiTableCell-sizeSmall": {
      border: "0.5px solid" + tableBorder,
      // "&:nth-of-type(even)": {
      //   backgroundColor: "grey"
      // },
      borderTop: "none",
      borderLeft: "none",
      borderWidth: "thin"
    },
    "& .MuiTableCell-head": {
      padding: "4px !important"
    },
    width: "auto",
    flex: 1,
    display: "grid",
    borderCollapse: "collapse",

    "& thead, & tbody, & tr": {
      display: "contents !important"
    },

    "& td": {
      display: "flex !important",
      alignItems: "center",
      height: 38
    },

    "& h5": {
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    },
    "& .MuiInputBase-adornedStart": {
      "& .MuiTypography-root": {
        fontSize: "13px",
        paddingLeft: 4
      },

      "& .MuiInputAdornment-positionStart": {
        marginRight: 0
      }
    },
    "& tr:not(.selectedByClick, .row-selected):hover": {
      "& td": {
        background: "#F4F6F8 !important"
      }
    }
  },
  tablePaddingCustom: {
    paddingLeft: "12px !important"
  },
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  },
  warningText: {
    backgroundColor: theme.palette.warning.main
    // width: 330
  }
}));
