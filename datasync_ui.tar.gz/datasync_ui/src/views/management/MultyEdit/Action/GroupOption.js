import React, { useContext } from "react";
import ListingOption from "src/components/Listings/ListingOption";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const MultiEditGroupOption = ({
  selectedItems,
  handleChangeAction,
  actionSelect
}) => {
  const { currentTab } = useContext(MultiEditTableContext);
  const { channelDetail } = useContext(MultiEditContext);

  return (
    <ListingOption
      handleChangeAction={handleChangeAction}
      disabled={selectedItems.length === 0}
      isMUltiEdit
      selectedItems={selectedItems}
      actionSelect={actionSelect}
      currentTab={currentTab}
      channelDetail={channelDetail}
    />
  );
};

export default MultiEditGroupOption;
