import React, { useContext, useRef } from "react";
import GroupButton from "src/views/management/ListingDetail/GroupBulkButton/GroupButton";
import { useDispatch, useSelector } from "react-redux";
import { ACTIVE_VALUE, DRAFT_VALUE, ERROR_VALUE } from "src/constants/Listing";
import { channelAllProductsAPI } from "src/services/channel";
import { useSnackbar } from "notistack";
import { alertError } from "src/helper/showErrorMessage";
import { updateFieldMultiEditAction } from "src/reducers/multiEdit";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const Action = ({
  currentTab,
  autoSave,
  setCloneList,
  queryString,
  cloneList
}) => {
  const instance = useRef({ timer: 0 });
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const selectedItems = useSelector(state => state.multiEdit.selectedItems);

  const { channelDetail } = useContext(MultiEditContext);
  const channelID = channelDetail?.id;
  const channelType = channelDetail.type;

  const { limit } = useSelector(state => state?.listing?.listingDetail);

  const setSelectedItems = selectedItems => {
    dispatch(updateFieldMultiEditAction({ selectedItems }));
  };

  async function getData() {
    try {
      const data = await channelAllProductsAPI({
        channelID: channelID,
        limit: limit,
        type: currentTab,
        search: queryString
      });
      if (data?.data) {
        let listProduct = data?.data?.reduce((prev, curr) => {
          prev[curr.publish_id] = {
            id: curr?.publish_id,
            status: curr?.publish_status,
            link_status: curr?.link_status,
            publish_action: curr?.publish_action
          };
          return prev;
        }, {});
        setCloneList(prev =>
          prev.map(product => {
            product.publish_status = listProduct[product?.publish_id]?.status;
            product.link_status = listProduct[product?.publish_id]?.link_status;
            product.publish_action =
              listProduct[product?.publish_id]?.publish_action;

            return product;
          })
        );
      }
    } catch (e) {
      const message =
        e?.response?.data?.message ||
        e?.response?.data?.errors ||
        e?.response?.data?.msg ||
        e?.response?.data?.error ||
        e?.response?.data?.message;
      console.log(e);
      enqueueSnackbar(alertError(message) || "Something went wrong", {
        variant: "error"
      });
    }
  }

  const handleChangeStatus = selectedItems => {
    const { id, status } = selectedItems;
    setCloneList(prev =>
      prev.map(product => {
        if (id.includes(product.publish_id)) {
          if ([DRAFT_VALUE, ERROR_VALUE].includes(currentTab)) {
            product.publish_status = status;
          } else {
            return {
              ...product,
              publish_action: selectedItems?.status,
              publish_status:
                channelType === "etsy" && currentTab === ACTIVE_VALUE
                  ? selectedItems?.status
                  : ""
            };
          }
        }
        return product;
      })
    );
    clearTimeout(instance.current.timer);
    instance.current.timer = setTimeout(() => {
      getData();
    }, 15000);
  };

  return (
    <div>
      <GroupButton
        selectedItems={selectedItems}
        channelID={channelID}
        cloneList={cloneList}
        currentTab={currentTab}
        setSelectedItems={setSelectedItems}
        channelType={channelType}
        autoSave={autoSave}
        handleChangeStatus={handleChangeStatus}
        setListProduct={setCloneList}
        getData={getData}
      />
    </div>
  );
};

export default Action;
