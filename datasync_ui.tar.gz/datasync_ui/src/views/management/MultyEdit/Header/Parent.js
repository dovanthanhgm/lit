import {
  Box,
  SvgIcon,
  TableCell,
  Tooltip,
  Typography
} from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import clsx from "clsx";
import React, { useContext, useState } from "react";
import { Maximize2, Minimize2 } from "react-feather";
import { useDispatch, useSelector } from "react-redux";
import { getCurrentTab } from "src/actions/templates";
import OpenInNewIcon from "@material-ui/icons/OpenInNew";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const useStyle = makeStyles(() => ({
  divStyle: {
    position: "absolute",
    height: "100%",
    top: 0,
    right: 0,
    bottom: 0,
    cursor: "col-resize",
    width: 6,
    "&:after": {
      content: '" "',
      position: "absolute",
      top: 0,
      right: 0,
      height: "100%",
      opacity: 0,
      width: 3,
      background: "black"
    }
  }
}));

const notSHowExpandIconList = [
  "about",
  "dimensions",
  // "price_info",
  "identifier",
  "offer_group"
];
const noPaddingHeader = ["link_status", "linked"];

const templateHeader = [
  "paymentTmpl",
  "offerTmpl",
  "brandTmpl",
  "priceTmpl",
  "categoryTmpl",
  "shippingTmpl",
  "titleTmpl"
];

const HeaderTemplate = ({ children, ...props }) => {
  const dispatch = useDispatch();
  const { gridArea } = props;
  const { channelDetail } = useContext(MultiEditContext);
  const channelID = channelDetail.id;
  const { listings } = useSelector(state => state.listing);
  const [open, setOpen] = useState(false);

  const handlePopoverOpen = event => {
    setOpen(true);
  };

  const handlePopoverClose = () => {
    setOpen(false);
  };

  const redirectTemplate = async () => {
    // eslint-disable-next-line
    let getIndex = listings.findIndex(channel => channel.id == channelID) || 0;
    await dispatch(getCurrentTab({ mainTab: getIndex, subTab: 0 }));
    localStorage.setItem("template_tab", getIndex);
    window.open("/settings/templates", "_blank");
  };

  return (
    <>
      <TableCell
        {...props}
        onClick={() => redirectTemplate()}
        style={{
          position: "relative",
          gridArea: gridArea,
          cursor: "pointer"
        }}
        onMouseEnter={handlePopoverOpen}
        onMouseLeave={handlePopoverClose}
      >
        <Box
          display="flex"
          alignItems="center"
          justifyContent="flex-start"
          height="100%"
        >
          {children}
          {open && (
            <OpenInNewIcon fontSize="small" style={{ paddingRight: 4 }} />
          )}
        </Box>
      </TableCell>
    </>
  );
};

function HeaderParent({
  item,
  onClickIconExtand,
  rootStyle,
  gridArea,
  canResize
}) {
  const classes = useStyle();
  const Icon = item.isExtended ? Minimize2 : Maximize2;

  const className = () => {
    let result = canResize
      ? `column-${item.key} canResize`
      : `column-${item.key}`;
    if (item.isLastChild) {
      result += " isLastChild";
    }
    return result;
  };

  const HeaderCell = templateHeader.includes(item?.value)
    ? HeaderTemplate
    : TableCell;

  return (
    <HeaderCell
      className={className()}
      style={{ position: "relative", gridArea: gridArea, ...rootStyle }}
      // id={tableId[item.parentKey] || item.group || item.name}
      id={'header-cell' || item.group || item.name}
      gridArea={gridArea}
    >
      <Box
        display="flex"
        alignItems="center"
        ml={!noPaddingHeader.includes(item.key) ? 1 : 0.5}
        height="100%"
        justifyContent="center"
        // textAlign={item.key === "about" ? "center" : "default"}
      >
        {item.canExtand && !notSHowExpandIconList.includes(item.key) && (
          <Tooltip title={item.isExtended ? "Collapse" : "Expand"}>
            <SvgIcon
              color="primary"
              style={{
                fontSize: 12,
                marginRight: 4,
                cursor: "pointer"
                // transform: "rotate(45deg)"
              }}
              onClick={() => onClickIconExtand(item.value)}
            >
              <Icon />
            </SvgIcon>
          </Tooltip>
        )}
        <Typography
          variant="h5"
          color="textPrimary"
          style={{ fontSize: 13, flex: !item.isExtended && 1 }}
        >
          {item.name}
        </Typography>

        {/*<Box display="flex" alignItems="center">*/}
        {/*  {showIcon && meShowMenu.includes(item.value) && (*/}
        {/*    <HeaderItem colName={item.value} className={classes.menu} />*/}
        {/*  )}*/}
        {/*</Box>*/}
      </Box>
      <div
        className={clsx(classes.divStyle, "resize-handle")}
        style={{ height: item.isExtended ? "calc(100% + 1px)" : "100%" }}
      />
    </HeaderCell>
  );
}

export default HeaderParent;
