import React, { useMemo } from "react";
import HeaderParent from "./Parent";

function Header({ item, index, page, ...props }) {
  const gridArea = useMemo(() => {
    // console.log(item.key, item);
    // console.log(item.key, item.childFields);
    const colSpan = item.canExtand && item.isExtended ? item.childFields.length : 1;

    const rowSpan = item.canExtand && item.isExtended ? 1 : 2;

    // child header
    if (!item.isShow) {
      return `${2} / ${index + 2 - item.headerExtendBefore} / span 1 / span 1`;
    }

    // parent header
    return `${1} / ${index + 3 - item.headerExtendBefore} / span ${rowSpan} / span ${colSpan}`;
  }, [index, item]);

  const canResize = useMemo(() => {
    if (!item.isShow) {
      return true;
    }
    return !item.isExtended;
  }, [item]);

  return <HeaderParent item={item} gridArea={gridArea} canResize={canResize} {...props} />;
}

export default Header;
