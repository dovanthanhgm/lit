import { Box, TableCell, Typography } from "@material-ui/core";
import React from "react";
import { minColWidth } from "src/constants/MultiEdit";

function HeaderChild({ data }) {
  return (
    <TableCell>
      <Box minWidth={minColWidth[data.key]}>
        <Typography variant="h5" color="textPrimary" style={{ fontSize: 13 }}>
          {data.title}
        </Typography>
      </Box>
    </TableCell>
  );
}

export default HeaderChild;
