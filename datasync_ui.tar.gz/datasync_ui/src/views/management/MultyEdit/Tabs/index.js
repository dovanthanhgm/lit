import {
  Box,
  Chip,
  makeStyles,
  Tab,
  Tabs,
  Tooltip,
  Typography
} from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import React, { useContext, useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import {
  DRAFT_VALUE,
  FETCH_LISTING_TABLE_COUNT,
  FETCH_LISTING_TABLE_DATA,
  getTabsFromChannel,
  returnTab
} from "src/constants/Listing";
import { useQueryV2 } from "src/hooks/useQuery";
import { useIsFetching, useQuery } from "react-query";
import { multiEditProductsAPI } from "src/services/channel";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";
import { useParams } from "react-router-dom";
import {
  handleApiCallProductSpecialTab,
  handleLoading
} from "src/views/management/ListingDetail/TableListing/Tabs";

const useStyles = makeStyles(theme => ({
  labelSmall: {
    paddingLeft: theme.spacing(0.5),
    paddingRight: theme.spacing(0.5)
  },
  chip: {
    marginLeft: theme.spacing(1)
  },
  chipNotSelected: {
    marginLeft: theme.spacing(1),
    color: "#546e7a",
    backgroundColor: "#e4e4e4"
  }
}));

const messageHoverDraft =
  "Drafts are products in editing and not published to channel yet. After published, Draft items will be come Active items";

const CustomTooltip = withStyles(() => ({
  tooltip: {
    fontSize: 12,
    maxWidth: 350
  }
}))(Tooltip);

function TabsCustom({ totalListing, isFilter, loadingMulti, setLoadingMulti }) {
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const { channelID } = useParams();
  const isFetching = useIsFetching(FETCH_LISTING_TABLE_COUNT);
  const {
    channelDetail,
    countData,
    setCountData,
    canSave,
    startSave,
    totalProduct
  } = useContext(MultiEditContext);
  const { setListProducts, setCurrentTab, limit } = useContext(
    MultiEditTableContext
  );
  const [tab, setTab] = useState(returnTab(countData));
  const [isReadyFetch, setIsReadyFetch] = useState(false);
  const channelType = channelDetail.type;
  const currentLimit = limit;
  const { sort } = useQueryV2();

  const { search, page = 1 } = useQueryV2();

  const handleTabsChange = (_, value) => {
    if (tab !== value) {
      setTab(value);
      if (!loadingMulti) {
        handleLoading({ setLoadingTab: setLoadingMulti, value: true });
      }
      if (page) {
        const params = new URLSearchParams(search);
        params.delete("page");
        history.push({
          search: params.toString()
        });
      }
    }
  };

  useEffect(() => {
    setIsReadyFetch(!isFetching);
  }, [isFetching]);

  useEffect(() => {
    setIsReadyFetch(true);
  }, [sort, page, tab, limit]);

  const countDataCal = returnTab(countData);

  useEffect(() => {
    if (channelDetail?.id?.toString() === channelID) {
      setTab(prev => countDataCal);
    }
    // eslint-disable-next-line
  }, [channelID, channelDetail.id, countDataCal]);

  useEffect(() => {
    if (channelDetail?.id?.toString() !== channelID) {
      setLoadingMulti(true);
    }
    // eslint-disable-next-line
  }, [channelID, channelDetail.id]);

  useEffect(() => {
    if (!countData[tab]) {
      setTab(prev => countDataCal);
    }
    // eslint-disable-next-line
  }, [countData]);

  useEffect(() => {
    if (!totalProduct) {
      setListProducts([]);
    }
    // eslint-disable-next-line
  }, [totalProduct]);

  useQuery(
    [
      FETCH_LISTING_TABLE_DATA,
      channelID,
      tab,
      search,
      currentLimit,
      page,
      sort
    ],
    () =>
      multiEditProductsAPI({
        channelID,
        type: tab,
        search,
        page,
        limit: currentLimit,
        sortValueString: sort,
        ...handleApiCallProductSpecialTab(channelType, tab, search)
      }),
    {
      // The query will not execute until the userId exists
      enabled:
        !(canSave && startSave) &&
        !!tab &&
        isReadyFetch &&
        channelDetail?.id?.toString() === channelID &&
        !!countData?.[tab],
      retryDelay: 30000,
      onSuccess: data => {
        setListProducts(data);
        setCurrentTab(tab);
      },
      refetchIntervalInBackground: true,
      refetchInterval: 61000,
      onSettled: () => {
        setCountData(prevState => ({ ...prevState, isFetched: false }));
        handleLoading({ setLoadingTab: setLoadingMulti, value: false });
        setIsReadyFetch(false);
        dispatch(
          setFieldListingDetailAction({
            loadingCountProduct: false
          })
        );
      }
    }
  );

  const isSelected = tabItem => tabItem === tab;

  return (
    <Tabs
      onChange={handleTabsChange}
      scrollButtons="auto"
      textColor="secondary"
      value={tab || "active"}
    >
      {getTabsFromChannel(channelType).map(tab => (
        <Tab
          size="small"
          style={
            (!countData?.[tab.value] && !(isFilter && totalListing === 0)) ||
            (isFilter && tab !== tab.value && !countData?.[tab.value])
              ? { display: "none" }
              : null
          }
          key={tab.value}
          value={tab.value}
          disabled={isFilter && !countData?.[tab.value] && totalListing === 0}
          label={
            <Box>
              {tab.value === DRAFT_VALUE && (
                <CustomTooltip
                  title={messageHoverDraft}
                  enterDelay={1000}
                  enterNextDelay={1000}
                  placement="bottom-start"
                >
                  <Box display="flex" alignItems="center">
                    <Typography variant="body2">{tab.label}</Typography>
                    <Chip
                      size="small"
                      label={countData?.[tab.value]}
                      color="primary"
                      classes={{ labelSmall: classes.labelSmall }}
                      className={
                        !isSelected(tab.value)
                          ? classes.chipNotSelected
                          : classes.chip
                      }
                    />
                  </Box>
                </CustomTooltip>
              )}
              {tab.value !== DRAFT_VALUE && (
                <Box display="flex" alignItems="center">
                  <Typography variant="body2">{tab.label}</Typography>
                  <Chip
                    size="small"
                    label={countData?.[tab.value]}
                    color="primary"
                    classes={{ labelSmall: classes.labelSmall }}
                    className={
                      !isSelected(tab.value)
                        ? classes.chipNotSelected
                        : classes.chip
                    }
                  />
                </Box>
              )}
            </Box>
          }
        />
      ))}
    </Tabs>
  );
}

export default TabsCustom;
