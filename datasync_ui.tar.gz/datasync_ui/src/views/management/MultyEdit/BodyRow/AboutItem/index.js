import React, { useEffect, useState } from "react";
import { set } from "lodash";
import { MultiEditAbouts } from "src/utils/multyEdit/index";
import { useSelector } from "react-redux";

const AboutItem = ({ data, headerInfo, setList, ...props }) => {
  const [aboutData, setAboutData] = useState({});

  const templateList = useSelector(
    (state) => state.templates.listTemplates["category"]
  );

  const templateSelected = templateList?.find(
    (item) => item.id === data.templates?.category
  );

  const setValueRow = val => {
    const { name, value } = val.target;
    let rowData = JSON.parse(JSON.stringify(data));
    rowData = set(rowData, `template_data.category.about.${name}`, value);
    setList(rowData, data?.publish_id);
  };

  useEffect(() => {
    setAboutData(data);
  }, [data]);

  if (headerInfo?.isExtended) {
    return (
      <>
        {MultiEditAbouts.map(item => {
          const Component = item.component;

          return (
            <Component
              initValue={aboutData?.template_data?.category?.about?.[item.name]}
              name={item.name}
              key={item.name}
              setValueRow={setValueRow}
              aboutListOption={item.listItems}
              templateName={templateSelected?.name}
              {...props}
            />
          );
        })}
      </>
    );
  }
};

export default AboutItem;
