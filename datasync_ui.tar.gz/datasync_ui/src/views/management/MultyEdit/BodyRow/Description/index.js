import React, { Fragment, useState } from "react";
import { Box, TableCell, Tooltip } from "@material-ui/core";
import MuiLink from "@material-ui/core/Link";
import { makeStyles } from "@material-ui/styles";
import EditDialog from "src/views/management/MultyEdit/BodyRow/Description/EditDialog";
import MultiEditEtsyDescription from "src/components/MultiEdit/Description/Etsy";
import MultiEditAmazonDescription from "src/components/MultiEdit/Description/Amazon";
import MultiEditBigComDescription from "src/components/MultiEdit/Description/BigCom";

const useStyle = makeStyles(() => ({
  root: {
    fontSize: 13,
    cursor: "pointer",
    "&[disabled]": {
      color: "grey",
      cursor: "default",
      "&:hover": {
        textDecoration: "none"
      }
    }
  }
}));

const ChannelBody = ({ channelType, ...props }) => {
  const descriptionByChannel = {
    etsy: <MultiEditEtsyDescription {...props} />,
    amazon: <MultiEditAmazonDescription {...props} />,
    ebay: <MultiEditAmazonDescription {...props} />,
    reverb: <MultiEditAmazonDescription {...props} />,
    bigcommerce: <MultiEditBigComDescription {...props} />,
  };
  if (descriptionByChannel?.[channelType]) {
    return descriptionByChannel[channelType];
  }
};

const MultiEditDescription = ({
  disabled,
  channelType,
  data,
  setList,
  templateName,
  ...props
}) => {
  const classes = useStyle();
  const descriptionData = data?.description;
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(descriptionData);
  const showTooltip = disabled && templateName;
  const WrapperComponent = showTooltip ? Tooltip : Fragment;
  const propsComponent = showTooltip
    ? {
        title: `Editing is disabled, because this field is automatically set by ${templateName} Template.`
      }
    : {};

  const onClick = () => {
    setOpen(true);
  };

  const onCLose = () => {
    setOpen(false);
    setValue(descriptionData);
  };

  return (
    <TableCell {...props}>
      <WrapperComponent {...propsComponent}>
        <Box
          pl={1}
          height="100%"
          width="100%"
          style={{ display: "flex", alignItems: "center" }}
        >
          <MuiLink
            className={classes.root}
            color="primary"
            component="button"
            disabled={disabled}
            onClick={onClick}
          >
            Edit...
          </MuiLink>
        </Box>
      </WrapperComponent>

      {open && (
        <EditDialog
          open={open}
          setOpen={onCLose}
          id="description-dialog-id"
          value={value}
          handleSave={() => {
            const rowData = { ...data };
            rowData.description = value;
            if (data.description !== value) {
              setList(rowData, data?.publish_id);
            }
            setOpen(false);
          }}
          title={`${channelType} Description`}
        >
          <ChannelBody
            channelType={channelType}
            value={value}
            setValue={setValue}
            disabled={disabled}
          />
        </EditDialog>
      )}
    </TableCell>
  );
};

export default MultiEditDescription;
