import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import { Divider } from "@material-ui/core";

export default function EditDialog({
  open,
  setOpen,
  title,
  value,
  id,
  children,
  handleSave
}) {
  const handleClose = () => {
    setOpen(false);
  };

  const isDisable = () => {
    return !value;
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        id={id}
        disableEnforceFocus={true}
      >
        <DialogTitle>{title}</DialogTitle>
        <Divider />
        <DialogContent>{children}</DialogContent>
        <DialogActions>
          <Button
            onClick={handleClose}
            color="default"
            variant="contained"
            size="small"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            color="primary"
            variant="contained"
            size="small"
            autoFocus
            disabled={isDisable()}
          >
            ok
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
