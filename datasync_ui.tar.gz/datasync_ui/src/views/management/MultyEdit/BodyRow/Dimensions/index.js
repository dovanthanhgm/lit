import React from "react";
import { MultiEditTableCellNumber } from "src/components/MultiEdit/MultiEdit";
import { Typography } from "@material-ui/core";

const Dimensions = ({ ...props }) => {
  const unit = props?.unit;
  const data = props?.data;

  const unitStart = data?.[unit];

  return (
    <>
      {["length", "width", "height"].map(item => {
        return (
          <MultiEditTableCellNumber
            startAdornment={
              <Typography
                style={{ marginLeft: 4, opacity: 0.7 }}
                variant="body2"
              >
                {unitStart || "in"}
              </Typography>
            }
            name={item}
            key={item}
            {...props}
          />
        );
      })}
    </>
  );
};

export default Dimensions;
