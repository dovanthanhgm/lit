import React from "react";
import { Badge, Box, Button, Popover, TableCell } from "@material-ui/core";
import { Box as BoxIcon, Link as LinkIcon } from "react-feather";
import LinkOffIcon from "@material-ui/icons/LinkOff";
import SearchIcon from "@material-ui/icons/Search";
import AddIcon from "@material-ui/icons/Add";
import { DRAFT_VALUE, ERROR_VALUE } from "src/constants/Listing";
import { useSelector } from "react-redux";
import useMainStoreMagento from "src/hooks/Listing/useMainStoreMagento";
import useLinkedUnlink from "src/hooks/MultyEdit/useLinkUnLink";
import LinkSearch from "src/components/MultiEdit/Modal/LinkSearch";

const draftErrorStatus = [DRAFT_VALUE, ERROR_VALUE];

const LinkStatus = ({ data, disabled, currentTab, id, setCloneList }) => {
  const linkStatus = data?.link_status;
  const defaultListing = useSelector(state => state?.listing?.defaultListing);
  const { hideCreateOn } = useMainStoreMagento();

  const handleSetListProductData = (prevId, row) => {
    setCloneList(prev =>
      prev.map(product => {
        if (product.publish_id === prevId) {
          return row;
        }
        return product;
      })
    );
  };

  const handleApplyProduct = (id, data) => {
    handleSetListProductData(id, data);
  };

  const {
    handleClickActiveProduct,
    anchorEl,
    openLink,
    handlePopoverOpen,
    handlePopoverClose,
    handleLinkOpen,
    handlePopoverClose2,
    open,
    handleLinkClose
  } = useLinkedUnlink({
    data,
    reFetchProduct: handleApplyProduct
  });

  return (
    <TableCell id={id}>
      <Box display="flex" justifyContent="center" width="100%">
        <Badge
          aria-describedby={open ? "mouse-over-popover" : undefined}
          onMouseEnter={disabled ? function() {} : handlePopoverOpen}
          onMouseMove={disabled ? function() {} : handlePopoverOpen}
          aria-owns={open ? "mouse-over-popover" : undefined}
          aria-haspopup="true"
          color={
            data.link_status === "linked" ||
            draftErrorStatus.includes(currentTab)
              ? "primary"
              : "error"
          }
          variant="dot"
        >
          <LinkIcon size="16" />
        </Badge>
      </Box>
      <Popover
        id="mouse-over-popover"
        open={open}
        anchorEl={anchorEl}
        onClose={handlePopoverClose}
        anchorOrigin={{
          vertical: "top",
          horizontal: "left"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left"
        }}
        transitionDuration={0}
        onMouseMove={handlePopoverClose2}
      >
        <Box onMouseLeave={handlePopoverClose}>
          {(linkStatus === "linked" ||
            draftErrorStatus.includes(currentTab)) && (
            <>
              <Box>
                <Button
                  fullWidth
                  variant="contained"
                  color="default"
                  startIcon={<BoxIcon />}
                  size="small"
                  href={`/products/${data.publish_id}`}
                  target="_blank"
                  // disabled={disableAction}
                >
                  View Linked Product
                </Button>
              </Box>
              {!draftErrorStatus.includes(currentTab) && (
                <Box>
                  <Button
                    fullWidth
                    variant="contained"
                    color="default"
                    startIcon={<LinkOffIcon />}
                    onClick={handleClickActiveProduct(data.link_status)}
                    // disabled={disableAction}
                    size="small"
                  >
                    Unlink from Product
                  </Button>
                </Box>
              )}
            </>
          )}
          {linkStatus === "unlink" && !draftErrorStatus.includes(currentTab) && (
            <Box display={"flex"} flexDirection={"column"}>
              <Button
                fullWidth
                variant="contained"
                color="default"
                startIcon={<SearchIcon />}
                onClick={handleLinkOpen}
                // disabled={disableAction}
                size="small"
              >
                Link to a product
              </Button>
              {!hideCreateOn && (
                <Button
                  fullWidth
                  variant="contained"
                  color="default"
                  startIcon={<AddIcon />}
                  onClick={handleClickActiveProduct(data.link_status)}
                  size="small"
                >
                  Create On {defaultListing?.type}
                </Button>
              )}
            </Box>
          )}
        </Box>
      </Popover>
      {openLink && (
        <LinkSearch
          values={data}
          open={openLink}
          handleClose={handleLinkClose}
          handleApplyProduct={handleApplyProduct}
        />
      )}
    </TableCell>
  );
};

export default LinkStatus;
