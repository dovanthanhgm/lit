import React from "react";
import { showIcon } from "src/views/management/ListingDetail/ListingFunction";
import { useSelector } from "react-redux";
import { Box, TableCell } from "@material-ui/core";
import {
  handleIconListingDetailStatus,
  handleListingDetailIconMessage
} from "src/helper/ListingDetalIconHandle";

const StatusIcon = ({ item, channelType, id }) => {
  const defaultListing = useSelector(state => state?.listing?.defaultListing);

  return (
    <TableCell id={id}>
      <Box display="flex" justifyContent="center" width="100%">
        {showIcon({
          channelType,
          statusCode: handleIconListingDetailStatus(item, channelType),
          defaultChannelType: defaultListing.type,
          tooltipMessage: handleListingDetailIconMessage(item, channelType)
        })}
      </Box>
    </TableCell>
  );
};

export default StatusIcon;
