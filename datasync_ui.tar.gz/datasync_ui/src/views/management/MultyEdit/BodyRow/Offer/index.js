import React from "react";
import CustomMultiSelectBox from "src/components/MultiEdit/SelectBox";
import { condition, taxCode } from "src/constants/template";
import { MultiEditTableCellNumber } from "src/components/MultiEdit/MultiEdit";
import MapOfferInput from "src/components/MultiEdit/Price/Amazon/MapOfferInput";
import OfferSwitch from "src/components/MultiEdit/Price/Amazon/OfferSwitch";
import { set } from "lodash";
import CustomDatePick from "src/components/MultiEdit/Price/Amazon/CustomDatePick";

const AmazonOffer = ({
  headerInfo,
  data,
  disabled,
  setList,
  name,
  isMultiEditOn,
  ...props
}) => {
  const { id } = props;
  const initCondition = data?.template_data?.offer?.condition?.value;
  const initFulfillment = data?.template_data?.offer?.fulfillment;
  const initTax = data?.template_data?.offer?.tax_code;

  const handleChangeCondition = e => {
    let rowData = { ...data };
    rowData = set(
      rowData,
      "template_data.offer.condition.value",
      e.target.value
    );
    setList(rowData, data?.publish_id);
  };

  const setValueRow = e => {
    let rowData = { ...data };
    const { value, name } = e.target;
    rowData = set(rowData, `template_data.offer.${name}`, value);
    setList(rowData, data?.publish_id);
  };

  return (
    <>
      <MultiEditTableCellNumber
        name={"qty"}
        setList={setList}
        data={data}
        id={id}
      />
      <MapOfferInput
        data={data}
        inputType="number"
        setList={setList}
        name="max_order_qty"
        id={id}
        disabled={disabled}
      />
      <CustomMultiSelectBox
        listData={condition}
        name={"condition"}
        initValue={initCondition}
        disabled={disabled}
        setValueRow={handleChangeCondition}
        {...props}
      />
      <MapOfferInput
        data={data}
        setList={setList}
        name="condition_notes"
        id={id}
        disabled={disabled}
      />
      <CustomMultiSelectBox
        listData={taxCode}
        name={"tax_code"}
        initValue={initTax}
        setValueRow={setValueRow}
        disabled={disabled}
        {...props}
      />
      <CustomMultiSelectBox
        listData={[
          { name: "Amazon", value: "fba" },
          { name: "Merchant", value: "fbm" }
        ]}
        name={"fulfillment"}
        initValue={initFulfillment}
        disabled={disabled}
        setValueRow={setValueRow}
        {...props}
      />
      <MapOfferInput
        data={data}
        inputType="number"
        setList={setList}
        name="handling_time"
        id={id}
        disabled={disabled}
      />
      <CustomDatePick
        data={data}
        setList={setList}
        initValue={data?.template_data?.offer?.launch_date ?? ""}
        pathChange="template_data.offer.launch_date"
        name="launch_date"
        id={id}
      />
      <CustomDatePick
        data={data}
        setList={setList}
        name="release_date"
        id={id}
        initValue={data?.template_data?.offer?.release_date ?? ""}
        pathChange="template_data.offer.release_date"
      />
      <CustomDatePick
        data={data}
        setList={setList}
        name="restock_date"
        id={id}
        initValue={data?.template_data?.offer?.restock_date ?? ""}
        pathChange="template_data.offer.restock_date"
      />
      <OfferSwitch
        name="gift_message"
        id={id}
        setList={setList}
        data={data}
        disabled={disabled}
      />
      <OfferSwitch
        name="gift_wrap"
        id={id}
        setList={setList}
        data={data}
        disabled={disabled}
      />
    </>
  );
};

export default AmazonOffer;
