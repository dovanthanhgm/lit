import React, { useEffect, useState } from "react";
import { Box, IconButton, TableCell } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import { BootstrapInput } from "src/components/MultiEdit/MultiEdit";
import SearchIcon from "@material-ui/icons/Search";
import AsinSearchDialog from "src/components/MultiEdit/Modal/AsinSearchDialog";
import DisableFieldVariant from "src/components/MultiEdit/DisableFieldVariant";

const useStyle = makeStyles(theme => ({
  focusCellStyle: {
    border: "2px solid" + theme.palette.primary.main + "!important",
    marginLeft: -1,
    marginTop: -1,
    zIndex: 1
  },
  unFocusCellStyle: {}
}));

const MultiEditAmazonAsin = ({ id, data, setList, name, disableVariant }) => {
  const classes = useStyle();
  const initValue = data.asin;
  const [value, setValue] = useState("");
  const [focusCell, setFocusCell] = useState(false);
  const [open, setOpen] = React.useState(false);
  const [initAsin] = useState(initValue);
  const [initAsinData] = useState(data?.asin_data);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleChange = event => {
    setValue(event.target.value);
  };

  const handleSetValue = (asin, asinData) => {
    setValue(asin);
    const rowData = { ...data };
    rowData.asin = asin;
    rowData.asin_data = asinData;
    setList(rowData, data?.publish_id);
  };

  const handleBlur = () => {
    const rowData = { ...data };
    setFocusCell(false);
    if (value !== initAsin) {
      rowData.asin_data = null;
    } else if (initAsin === value) {
      rowData.asin_data = initAsinData;
    }
    // eslint-disable-next-line
    if (data[name] != value) {
      rowData.asin = value;
      setList(rowData, data?.publish_id);
    }
  };

  useEffect(() => {
    setValue(initValue);
  }, [initValue]);

  return (
    <TableCell
      id={id}
      className={focusCell ? classes.focusCellStyle : classes.unFocusCellStyle}
    >
      {!disableVariant && (
        <>
          {open && (
            <AsinSearchDialog
              data={data}
              open={open}
              setOpen={setOpen}
              setValue={handleSetValue}
            />
          )}
          <Box position="relative" width="100%">
            <BootstrapInput
              name={name}
              value={value}
              onChange={handleChange}
              variant="outlined"
              onFocus={() => setFocusCell(true)}
              onBlur={handleBlur}
              style={{ paddingRight: 30 }}
            />
            <Box
              position="absolute"
              right={4}
              top={"50%"}
              style={{ transform: "translate(0, -50%)" }}
            >
              <IconButton size="small" onClick={handleClickOpen}>
                <SearchIcon fontSize="small" />
              </IconButton>
            </Box>
          </Box>
        </>
      )}
      {disableVariant && (
        <>
          <DisableFieldVariant />
        </>
      )}
    </TableCell>
  );
};

export default MultiEditAmazonAsin;
