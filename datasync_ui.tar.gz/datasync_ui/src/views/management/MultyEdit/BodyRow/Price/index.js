import React from "react";
import { MultiEditTableCellNumber } from "src/components/MultiEdit/MultiEdit";
import MapMsrpInput from "src/components/MultiEdit/Price/Amazon/MapMsrpInput";
import CustomDatePick from "src/components/MultiEdit/Price/Amazon/CustomDatePick";
import { useSelector } from "react-redux";

function PriceGroup({
  headerInfor,
  data,
  disabled,
  setList,
  initProduct,
  channelType,
  name,
  handleSetUndo,
  isMultiEditOn,
  ...props
}) {
  // const init = initProduct?.[name];
  const { id } = props;
  // const [operator] = useState("inc-usd");
  // const [inputValue, setInputValue] = useState("");
  // const [rounding] = useState(0);
  // const [initPrice, setInitPrice] = useState();
  const templateList = useSelector(
    state => state.templates.listTemplates[name]
  );

  const templateSelected = templateList?.find(
    item => item.id === data.templates?.[name]
  );

  // const setValueRow = val => {
  //   const rowData = { ...data };
  //   // handleSetUndo(name, rowData[name], rowData.publish_id);
  //   rowData[name] = val;
  //   // eslint-disable-next-line
  //   if (data[name] != val) {
  //     setList(rowData, name);
  //   }
  // };
  // const price = calculatePrice({
  //   currPrice: initPrice,
  //   operator,
  //   value: inputValue,
  //   rounding
  // });

  // useEffect(() => {
  //   if (price !== data[name] && !isMultiEditOn) {
  //     setValueRow(price);
  //   }
  //   // eslint-disable-next-line
  // }, [price]);

  // useEffect(() => {
  //   setInputValue("");
  //   setInitPrice(init);
  // }, [init]);

  if (headerInfor.isExtended && channelType === "amazon") {
    // const showColor = () => {
    //   if (initPrice < data[name]) {
    //     return classes.increase;
    //   }
    //   if (initPrice === data[name]) {
    //     return;
    //   }
    //   return classes.decrease;
    // };

    return (
      <>
        {/*<Operator*/}
        {/*  id={id}*/}
        {/*  operator={operator}*/}
        {/*  setOperator={setOperator}*/}
        {/*  disabled={isMultiEditOn}*/}
        {/*/>*/}
        {/*<InputNumber*/}
        {/*  value={inputValue}*/}
        {/*  id={id}*/}
        {/*  placeholder="0.00"*/}
        {/*  onChange={e => setInputValue(e.target.value)}*/}
        {/*/>*/}
        {/*<Rounding*/}
        {/*  id={id}*/}
        {/*  rounding={rounding}*/}
        {/*  setRounding={setRounding}*/}
        {/*  disabled={isMultiEditOn}*/}
        {/*/>*/}
        {/*<TableCell id={id}>*/}
        {/*  <Box display="flex" alignItems="center" height="100%" pl={1}>*/}
        {/*    {initPrice}*/}
        {/*  </Box>*/}
        {/*</TableCell>*/}
        {/*<TableCell id={id}>*/}
        {/*  <Box display="flex" alignItems="center" height="100%" pl={1}>*/}
        {/*    <span className={showColor()}>{data[name]}</span>*/}
        {/*  </Box>*/}
        {/*</TableCell>*/}

        <MultiEditTableCellNumber
          data={data}
          handleSetUndo={handleSetUndo}
          setList={setList}
          name="price"
          id={id}
          // startAdornment={<InputAdornment position="start">$</InputAdornment>}
          disabled={disabled}
          templateName={templateSelected?.name}
        />
        <MapMsrpInput
          data={data}
          handleSetUndo={handleSetUndo}
          setList={setList}
          name="map"
          id={id}
          // startAdornment={<InputAdornment position="start">$</InputAdornment>}
          disabled={disabled}
          templateName={templateSelected?.name}
        />
        <MapMsrpInput
          data={data}
          handleSetUndo={handleSetUndo}
          setList={setList}
          name="msrp"
          id={id}
          // startAdornment={<InputAdornment position="start">$</InputAdornment>}
          disabled={disabled}
          templateName={templateSelected?.name}
        />
        <MapMsrpInput
          data={data}
          handleSetUndo={handleSetUndo}
          setList={setList}
          name="special_price"
          id={id}
          // startAdornment={<InputAdornment position="start">$</InputAdornment>}
          disabled={disabled}
          templateName={templateSelected?.name}
        />
        <CustomDatePick
          data={data}
          setList={setList}
          name="sale_start_date"
          id={id}
          disabled={disabled}
          initValue={
            data?.template_data?.price?.special_price?.sale_start_date ?? ""
          }
          pathChange={`template_data.price.special_price.sale_start_date`}
        />
        <CustomDatePick
          data={data}
          initValue={
            data?.template_data?.price?.special_price?.sale_end_date ?? ""
          }
          setList={setList}
          name="sale_end_date"
          pathChange={`template_data.price.special_price.sale_end_date`}
          id={id}
          disabled={disabled}
        />
      </>
    );
  }
  return (
    <MultiEditTableCellNumber
      data={data}
      handleSetUndo={handleSetUndo}
      setList={setList}
      name={name}
      id={id}
      templateName={templateSelected?.name}
      // startAdornment={<InputAdornment position="start">$</InputAdornment>}
      disabled={disabled}
    />
  );
}

export default PriceGroup;
