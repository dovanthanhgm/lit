import { Box, TableCell } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import React, { useMemo } from "react";
import { CustomInputIdentifier } from "src/components/MultiEdit/Input";
import CheckCircleOutlineOutlinedIcon from "@material-ui/icons/CheckCircleOutlineOutlined";
import ErrorOutlineOutlinedIcon from "@material-ui/icons/ErrorOutlineOutlined";
import BoxCenter from "../../components/BoxCenter";

const useStyle = makeStyles(theme => ({
  warningIcon: {
    color: theme.palette.warning.main
  },
  successIcon: {
    color: theme.palette.success.main
  }
}));

const idName = ["asin", "upc", "ean", "isbn"];

export default function IdentifierGroup({
  data,
  setList,
  group,
  disabled,
  headerInfo
}) {
  const classes = useStyle();

  const setValueRow = (val, name) => {
    const rowData = { ...data };
    rowData[name] = val;
    // eslint-disable-next-line
    if (data[name] != val) {
      setList(rowData, data?.publish_id);
    }
  };

  const iconRender = useMemo(() => {
    const isId = idName.some(field => !!data[field]);
    return isId ? (
      <CheckCircleOutlineOutlinedIcon
        className={classes.successIcon}
        fontSize="small"
        style={{ height: "100%" }}
      />
    ) : (
      <ErrorOutlineOutlinedIcon
        className={classes.warningIcon}
        fontSize="small"
        style={{ height: "100%" }}
      />
    );
  }, [data, classes.successIcon, classes.warningIcon]);

  if (headerInfo.isExtended) {
    return (
      <>
        <TableCell id={group}>
          {<BoxCenter pl={1}>{iconRender}</BoxCenter>}
        </TableCell>
        {idName.map(field => {
          return (
            <CustomInputIdentifier
              name={field}
              group={group}
              disabled={disabled}
              initValue={data[field]}
              key={field}
              onChangeValue={setValueRow}
            />
          );
        })}
      </>
    );
  }

  return (
    <TableCell id={group}>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        width="100%"
        height="100%"
      >
        {iconRender}
      </Box>
    </TableCell>
  );
}
