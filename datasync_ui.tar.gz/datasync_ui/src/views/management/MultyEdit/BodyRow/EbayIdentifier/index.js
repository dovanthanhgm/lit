import React from "react";
import { CustomInputIdentifier } from "src/components/MultiEdit/Input/index";

const idName = ["epid", "sku", "upc", "ean", "mpn", "isbn"];
const EbayIdentifier = ({ data, setList, disabled, id }) => {
  const setValueRow = (val, name) => {
    const rowData = { ...data };
    rowData[name] = val;
    // eslint-disable-next-line
    if (data[name] !== val) {
      setList(rowData, data?.publish_id);
    }
  };

  return (
    <>
      {idName.map(field => {
        return (
          <CustomInputIdentifier
            name={field}
            group={id}
            disabled={disabled}
            initValue={data[field]}
            key={field}
            onChangeValue={setValueRow}
          />
        );
      })}
    </>
  );
};

export default EbayIdentifier;
