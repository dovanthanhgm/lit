import React, { useContext, useEffect, useState } from "react";
import useSelect from "src/hooks/MultyEdit/useSelect";
import { TableCell } from "@material-ui/core";
import SelectLayout from "src/components/MultiEdit/SelectLayout";
import { EtsySectionContext } from "src/views/management/MultyEdit/Context/EtsySectionContext";
import { set } from "lodash";

const Section = ({
  dataSection = "",
  disabled,
  onKeyDown,
  setValueRow,
  name,
  listSection = []
}) => {
  const [section, setSection] = useState("");

  const handleChangeSection = e => {
    setSection(e.target.value);
  };

  const handleChangeRowSection = e => {
    setValueRow(section);
  };

  useEffect(() => {
    setSection(dataSection);
  }, [dataSection]);

  return (
    <SelectLayout
      value={section}
      display={1}
      onKeyDown={onKeyDown}
      onChange={handleChangeSection}
      id={"template-menu"}
      handleBlur={handleChangeRowSection}
      name={name}
      disabled={disabled}
    >
      <>
        <option value="please select">Please select</option>
        {listSection.map(sections => {
          return (
            <option
              value={sections?.shop_section_id}
              className="first-select"
              style={{
                textOverflow: "ellipsis",
                overflow: "hidden"
              }}
              key={sections?.shop_section_id}
            >
              {sections?.title}
            </option>
          );
        })}
      </>
    </SelectLayout>
  );
};

const MemoSection = React.memo(Section, function(prev, curr) {
  const listKeyCheck = ["name", "disabled", "dataSection"];
  return (
    listKeyCheck.every(conditions => prev[conditions] === curr[conditions]) ||
    prev.listSection.length !== curr.listSection.length
  );
});

const EtsySection = ({ id, name, disabled, data, setList = function() {} }) => {
  const { section } = useContext(EtsySectionContext);

  const sectionInit = data?.template_data?.category?.advance?.section;
  const {
    handleMouseEnter,
    handleMouseLeave,
    className,
    onKeyDown
  } = useSelect();

  const setValueRow = value => {
    const rowData = Object.assign({}, data);
    set(rowData, "template_data.category.advance.section", value);
    // eslint-disable-next-line
    if (sectionInit !== value) {
      setList(rowData, data?.publish_id);
    }
  };

  return (
    <TableCell
      onFocusCapture={handleMouseEnter}
      onBlurCapture={handleMouseLeave}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={className}
      id={id}
    >
      <MemoSection
        name={name}
        disabled={disabled}
        dataSection={sectionInit}
        onKeyDown={onKeyDown}
        listSection={section}
        setValueRow={setValueRow}
      />
    </TableCell>
  );
};

export default EtsySection;
