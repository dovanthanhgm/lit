import React, { useContext, useEffect, useState } from "react";
import useSelect from "src/hooks/MultyEdit/useSelect";
import { TableCell } from "@material-ui/core";
import SelectLayout from "src/components/MultiEdit/SelectLayout";
import { EtsyProductPartnerContext } from "src/views/management/MultyEdit/Context/EtsyProductPartnerContext";
import { set } from "lodash";
import { listInShowMade } from "src/constants/Listing/index";

const EtsyProductPartner = ({
  id,
  name,
  disabled,
  data,
  setList = function() {}
}) => {
  const { partner } = useContext(EtsyProductPartnerContext);
  const {
    handleMouseEnter,
    handleMouseLeave,
    className,
    onKeyDown
  } = useSelect();

  const [etsyPartner, setEtsyPartner] = useState("");
  const partnerInit =
    data?.template_data?.category?.about?.production_partner_ids;
  const whoMade = data?.template_data?.category?.about?.who_made;
  const isSupply = data?.template_data?.category?.about?.is_supply;
  const whenMade = data?.template_data?.category?.about?.when_made;

  const setValueRow = value => {
    const rowData = Object.assign({}, data);
    set(rowData, "template_data.category.about.production_partner_ids", [
      value
    ]);
    // eslint-disable-next-line
    if (partnerInit !== value) {
      setList(rowData, data?.publish_id);
    }
  };

  const handleChangeSection = e => {
    setEtsyPartner(e.target.value);
  };

  const handleChangeRowSection = e => {
    setValueRow(etsyPartner);
  };

  useEffect(() => {
    setEtsyPartner(partnerInit);
  }, [partnerInit]);

  const isWhoMade =
    whoMade === "someone_else" &&
    [0, "0"].includes(isSupply) &&
    listInShowMade.includes(whenMade);

  if (!isWhoMade) {
    return (
      <TableCell
        onFocusCapture={handleMouseEnter}
        onBlurCapture={handleMouseLeave}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className={className}
        id={id}
      />
    );
  }

  return (
    <TableCell
      onFocusCapture={handleMouseEnter}
      onBlurCapture={handleMouseLeave}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={className}
      id={id}
    >
      <SelectLayout
        value={etsyPartner}
        display={1}
        onKeyDown={onKeyDown}
        onChange={handleChangeSection}
        id={"template-menu"}
        handleBlur={handleChangeRowSection}
        name={name}
        disabled={disabled}
      >
        <>
          <option value="please select">Please select</option>
          {partner.map(partnerItem => {
            return (
              <option
                value={partnerItem?.partner_id}
                className="first-select"
                style={{
                  textOverflow: "ellipsis",
                  overflow: "hidden"
                }}
                key={partnerItem?.partner_id}
              >
                {partnerItem?.title}
              </option>
            );
          })}
        </>
      </SelectLayout>
    </TableCell>
  );
};

export default EtsyProductPartner;
