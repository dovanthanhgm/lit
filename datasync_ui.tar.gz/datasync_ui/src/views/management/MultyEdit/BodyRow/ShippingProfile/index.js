import React, { useContext } from "react";
import { useSelector } from "react-redux";
import CustomMultiSelectBox from "src/components/MultiEdit/SelectBox";
import { EtsyProductPartnerContext } from "src/views/management/MultyEdit/Context/EtsyProductPartnerContext";

const ShippingProfile = ({ ...props }) => {
  const { data, setList, id } = props;
  const { dataShipping } = useContext(EtsyProductPartnerContext);
  const { disabled } = props;
  const listShipping = dataShipping || [];
  const initValue = data?.template_data?.shipping?.shipping_id;

  const templateList = useSelector(
    state => state.templates.listTemplates["category"]
  );

  const templateSelected = templateList?.find(
    item => item.id === data.templates?.category
  );

  const initListShipping = listShipping?.map(shipping => ({
    name: shipping.title,
    value: shipping.shipping_template_id
  }));

  const setValueRow = e => {
    const rowData = { ...data };
    rowData.template_data.shipping = {
      ...rowData.templates.shipping,
      shipping_id: e.target.value
    };
    setList(rowData, data?.publish_id);
  };

  return (
    <CustomMultiSelectBox
      initValue={initValue}
      listData={initListShipping}
      id={id}
      name={"shipping_profile"}
      disabled={disabled}
      setValueRow={setValueRow}
      templateName={templateSelected?.name}
    />
  );
};

export default ShippingProfile;
