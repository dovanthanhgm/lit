import { TableCell } from "@material-ui/core";
import React, { useEffect, useReducer, useState } from "react";
import { InputNumber } from "src/components/MultiEdit/Input";
import { QtyOperator } from "src/components/MultiEdit/Input/MultiEditQuantitty";
import { MultiEditTableCellNumber } from "src/components/MultiEdit/MultiEdit";
import { calculateQuantity } from "src/utils/multyEdit/quantity";
import BoxCenter from "../../components/BoxCenter";
import { makeStyles } from "@material-ui/styles";

const useStyle = makeStyles(theme => ({
  increase: {
    color: theme.palette.primary.main
  },
  decrease: {
    color: theme.palette.error.main
  }
}));

export default function QuantityGroup({
  setList,
  data,
  id,
  name,
  initProduct,
  handleSetUndo,
  headerInfor,
  disabled
}) {
  const init = initProduct?.[name];
  const classes = useStyle();
  const [focusCell, setFocusCell] = useReducer(focusCell => !focusCell, false);
  const [operator, setOperator] = useState("web");
  const [inputValue, setInputValue] = useState(0);
  const [initQty, setInitQty] = useState(data[name]);

  const setValueRow = val => {
    const rowData = { ...data };
    rowData[name] = val;
    // eslint-disable-next-line
    if (data[name] != val) {
      setList(rowData, data?.publish_id);
    }
  };
  const qty = calculateQuantity({
    currentQty: initQty,
    operator,
    value: inputValue
  });

  useEffect(() => {
    if (qty !== data[name] && !disabled) {
      setValueRow(qty);
    }
    // eslint-disable-next-line
  }, [qty]);

  useEffect(() => {
    setInputValue("");
    setInitQty(init);
  }, [init]);

  if (headerInfor.isExtended) {
    const showColor = () => {
      if (initQty < data[name]) {
        return classes.increase;
      }
      if (initQty === data[name]) {
        return;
      }
      return classes.decrease;
    };

    return (
      <>
        <QtyOperator
          setOperator={setOperator}
          operator={operator}
          id={id}
          disabled={disabled}
        />
        <InputNumber
          styles={focusCell}
          value={inputValue}
          placeholder="Enter Amount"
          onFocus={setFocusCell}
          id={id}
          onBlur={() => {
            setFocusCell();
            setInputValue(inputValue);
          }}
          onChange={e => {
            setInputValue(e.target.value);
          }}
        />
        <TableCell id={id}>
          <BoxCenter pl={1}>{initQty}</BoxCenter>
        </TableCell>

        <TableCell id={id}>
          <BoxCenter pl={1}>
            <span className={showColor()}>{data[name]}</span>
          </BoxCenter>
        </TableCell>
      </>
    );
  }
  return (
    <MultiEditTableCellNumber
      name={"qty"}
      setList={setList}
      disabled={disabled}
      handleSetUndo={handleSetUndo}
      data={data}
      id={id}
    />
  );
}
