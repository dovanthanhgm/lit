import { Box, TableCell } from "@material-ui/core";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { InputNumber } from "src/components/MultiEdit/Input";
import { QtyOperator } from "src/components/MultiEdit/Input/MultiEditQuantitty";
import { calculateQuantity } from "src/utils/multyEdit/quantity";
import TextFieldNumber from "src/components/MUI/TextFieldnumber";

export default function EditQuantityMultiEdit({
  headerInfo,
  handleBlur,
  group,
  currentList,
  setShowQtyChange,
  selectedItems,
  setListProducts,
  multiRowValue,
  handleChangeValue
}) {
  const tableExtend = headerInfo?.isExtended;
  const [operator, setOperator] = useState("web");
  const [inputValue, setInputValue] = useState("");

  const listQty = useMemo(() => {
    let initValue = {};
    const aFunc = () =>
      currentList?.forEach(product => {
        initValue[product.publish_id] = product.qty;
      });
    aFunc();
    return initValue;
    // eslint-disable-next-line
  }, []);

  const handleChangeQty = useCallback(() => {
    const qtyData = initValue =>
      calculateQuantity({
        currentQty: initValue,
        operator,
        value: inputValue
      });
    setListProducts(prev =>
      prev.map(product => {
        if (!selectedItems.includes(product.publish_id)) {
          return product;
        }
        let data = { ...product };
        data.qty = qtyData(listQty[data.publish_id]);
        return data;
      })
    );
    // eslint-disable-next-line
  }, [inputValue, operator, listQty, setListProducts, selectedItems]);

  const handleSetOperator = func => e => {
    func(e);
    if (typeof inputValue == "number") {
      setShowQtyChange(true);
    }
  };

  useEffect(() => {
    if (tableExtend) {
      handleChangeQty();
    }
  }, [handleChangeQty, tableExtend]);

  if (headerInfo.isExtended) {
    return (
      <>
        <QtyOperator
          group={group}
          setOperator={handleSetOperator(setOperator)}
          operator={operator}
          isMultiEditOn
        />
        <InputNumber
          group={group}
          value={inputValue}
          disabled={operator === "web"}
          placeholder="Enter Amount"
          onChange={e => {
            setShowQtyChange(true);
            setInputValue(e.target.value);
          }}
        />
        <TableCell id={group} />
        <TableCell id={group} />
        {/*<Box display={"flex"} alignItems="center">*/}
        {/*  <Button*/}
        {/*    size="small"*/}
        {/*    color="primary"*/}
        {/*    onClick={() => setShowQtyChange(false)}*/}
        {/*    className={classes.applyButton}*/}
        {/*  >*/}
        {/*    Update*/}
        {/*  </Button>*/}
        {/*  <Button*/}
        {/*    size="small"*/}
        {/*    onClick={() => {*/}
        {/*      handleCancel();*/}
        {/*      setShowQtyChange(false);*/}
        {/*    }}*/}
        {/*    className={classes.cancelButton}*/}
        {/*  >*/}
        {/*    cancel*/}
        {/*  </Button>*/}
        {/*</Box>*/}
      </>
    );
  }

  return (
    <TableCell id={group}>
      <Box p={1} width="100%">
        <TextFieldNumber
          // name="qty"
          variant="outlined"
          size="small"
          fullWidth
          onBlur={handleBlur}
          onChange={handleChangeValue("qty")}
        />
      </Box>
    </TableCell>
  );
}
