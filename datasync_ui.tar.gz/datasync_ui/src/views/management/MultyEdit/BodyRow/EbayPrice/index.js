import React, { useMemo } from "react";
import { TableCell } from "@material-ui/core";
import { MultiEditTableCellNumber } from "src/components/MultiEdit/MultiEdit";
import EditSpecialPrice from "src/components/MultiEdit/Input/Ebay/EditSpecialPrice";

const EbayPrice = ({ id, data, setList, headerInfo, ...props }) => {
  const { disabled } = props;
  const category = data?.template_data?.category?.listing_type;
  const conEbayFixed = useMemo(() => {
    return category === "FixedPriceItem";
  }, [category]);

  return (
    <>
      {conEbayFixed && (
        <MultiEditTableCellNumber
          data={data}
          setList={setList}
          name={"price"}
          id={id}
          disabled={disabled}
          // startAdornment={<InputAdornment position="start">$</InputAdornment>}
        />
      )}
      {!conEbayFixed && (
        <EditSpecialPrice
          data={data}
          setList={setList}
          name={"template_data.price.auction_price.buy_it_now_price"}
          nameInit={"template_data.price.auction_price.buy_it_now_price.price"}
          id={id}
          {...props}
        />
      )}
      {headerInfo?.isExtended && (
        <>
          {!conEbayFixed && (
            <>
              <EditSpecialPrice
                data={data}
                setList={setList}
                name={"template_data.price.auction_price.start_price"}
                nameInit={"template_data.price.auction_price.start_price.price"}
                id={id}
                {...props}
              />
              <EditSpecialPrice
                data={data}
                setList={setList}
                name={"template_data.price.auction_price.reserve_price"}
                nameInit={
                  "template_data.price.auction_price.reserve_price.price"
                }
                id={id}
                {...props}
              />
            </>
          )}
          {conEbayFixed && (
            <>
              <TableCell id={id} />
              <TableCell id={id} />
            </>
          )}

          <MultiEditTableCellNumber
            data={data}
            isQty
            setList={setList}
            name={"qty"}
            id={id}
          />
        </>
      )}
    </>
  );
};

export default EbayPrice;
