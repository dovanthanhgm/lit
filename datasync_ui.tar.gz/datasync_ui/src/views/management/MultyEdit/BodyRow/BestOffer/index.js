import { Box, TableCell } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { CustomNumber } from "src/components/MultiEdit/Input";
import MultiEditSwitch from "src/components/MultiEdit/Input/MultiEditSwitch";
import BoxCenter from "../../components/BoxCenter";

export default function BestOfferGroup({
  data,
  name,
  id,
  headerInfo,
  setList
}) {
  const checkedData = !!data?.best_offer?.status;
  const minData = data?.best_offer?.min || 0;
  const maxData = data?.best_offer?.max || 0;
  const [check, setCheck] = useState(false);
  const [minAccept, setMinAccept] = useState(0);
  const [maxReject, setMaxReject] = useState(0);

  const handleChangeOffer = (val, subName) => {
    const rowData = { ...data };
    rowData[name] = { ...rowData[name], [subName]: val };
    if (data?.[name]?.[subName] !== val) {
      setList(rowData, data?.publish_id);
    }
  };

  const handleBlur = (value, name) => {
    handleChangeOffer(value, name);
  };

  useEffect(() => {
    setCheck(checkedData);
  }, [checkedData]);

  useEffect(() => {
    setMinAccept(minData);
  }, [minData]);

  useEffect(() => {
    setMaxReject(maxData);
  }, [maxData]);

  if (headerInfo?.isExtended) {
    return (
      <>
        <TableCell id={id}>
          <BoxCenter pl={1}>
            <MultiEditSwitch
              check={check}
              setCheck={setCheck}
              // disabled={isMultiEditOn}
              style={{ height: "100%" }}
            />
          </BoxCenter>
        </TableCell>
        <CustomNumber
          group={id}
          value={minAccept}
          placeholder="0"
          onBlur={() => handleBlur(minAccept, "min")}
          onChange={e => {
            setMinAccept(e.target.value);
          }}
        />
        <CustomNumber
          value={maxReject}
          group={id}
          placeholder="0"
          onBlur={() => handleBlur(maxReject, "max")}
          onChange={e => {
            setMaxReject(e.target.value);
          }}
        />
      </>
    );
  }
  return (
    <TableCell id={id}>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        width="100%"
        height="100%"
      >
        <MultiEditSwitch check={check} setCheck={setCheck} />
      </Box>
    </TableCell>
  );
}
