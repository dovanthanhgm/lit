import React, { useContext, useState } from "react";
import { useSelector } from "react-redux";
import MultiEditSelectBox from "src/components/MultiEdit/Input/MultiEditSelectBox";
import MultiEditTableCell from "src/components/MultiEdit/MultiEdit";
import MultiEditDescription from "src/views/management/MultyEdit/BodyRow/Description/index";
import { MultiEditStickyContext } from "../../Context";

function TitleGroup({ data, tableHeaders, channelType, setList }) {
  const name = "title";
  const [disabledApply, setDisableApply] = useState({});

  const { skuColumnWidth } = useContext(MultiEditStickyContext);

  const disabled = !!data?.templates?.[name] || disabledApply?.[name];
  const templateList = useSelector(
    state => state.templates.listTemplates[name]
  );

  const templateSelected = templateList?.find(
    item => item.id === data.templates?.[name]
  );

  return (
    <>
      {tableHeaders.title?.isShow && (
        <MultiEditTableCell
          style={{
            width: "100%"
          }}
          name="name"
          id={"identifier-cell"}
          setList={setList}
          data={data}
          disabled={disabled}
          templateName={templateSelected?.name}
          rootProps={{
            style: {
              position: "sticky",
              left:
                tableHeaders.sku?.isShow && skuColumnWidth
                  ? skuColumnWidth + 72
                  : 72,
              zIndex: 10
            },
            className: "column-name"
          }}
        />
      )}
      {tableHeaders?.description?.isShow && (
        <MultiEditDescription
          id="normal-cell"
          disabled={disabled}
          data={data}
          setList={setList}
          channelType={channelType}
          templateName={templateSelected?.name}
        />
      )}
      {tableHeaders?.titleTmpl?.isShow && (
        <MultiEditSelectBox
          name="title"
          data={data}
          channelType={channelType}
          id="normal-cell"
          setDisableApply={setDisableApply}
          setList={setList}
        />
      )}
    </>
  );
}

export default TitleGroup;
