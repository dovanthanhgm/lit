import React from "react";
import CustomMultiSelectBox from "src/components/MultiEdit/SelectBox";
import { set } from "lodash";
import {
  listItemAuction,
  listItemFixed
} from "src/components/Template/ebay/Category/EbayFormatAndDuration";

const EbayFormatDuration = ({ id, data, setList, currentTab }) => {
  const dataFormat = data?.template_data?.category?.listing_type;
  const dataDuration = data?.template_data?.category?.duration;

  const listFormat = [
    { value: "Auction", name: "Auction" },
    { value: "FixedPriceItem", name: "Fixed Price Item" }
  ];

  const setValueRow = e => {
    let rowData = { ...data };
    const value = e.target.value;
    rowData = set(rowData, `template_data.category.${e.target.name}`, value);

    setList(rowData, data?.publish_id);
  };

  return (
    <>
      <CustomMultiSelectBox
        listData={listFormat}
        name={"listing_type"}
        disabled={currentTab === "active"}
        id={id}
        initValue={dataFormat}
        setValueRow={setValueRow}
      />
      <CustomMultiSelectBox
        listData={
          dataFormat === "FixedPriceItem" ? listItemFixed : listItemAuction
        }
        disabled={currentTab === "active"}
        name={"duration"}
        id={id}
        initValue={dataDuration}
        setValueRow={setValueRow}
      />
    </>
  );
};

export default EbayFormatDuration;
