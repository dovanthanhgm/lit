import React, { useContext } from "react";
import SearchCategory from "src/components/MultiEdit/Category/SearchCategory";
import CustomMultiSelectBox from "src/components/MultiEdit/SelectBox";
import { useSelector } from "react-redux";
import { set } from "lodash";
import EbayFormatDuration from "src/views/management/MultyEdit/BodyRow/EbayCategory/EbayFormatDuration";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const EbayCategory = ({
  id,
  data,
  setList,
  currentTab,
  headerInfo,
  setOpenSearch,
  channelType,
  setCloneList,
  disabled
}) => {
  const { channelDetail } = useContext(MultiEditContext);
  const channelID = channelDetail.id;
  const listStorageCategory =
    useSelector(
      state => state?.listing?.ebay_setting?.[channelID]?.custom_categories
    )?.map(category => ({
      name: category?.category_name,
      value: category?.category_id
    })) ?? [];

  // const listCondition = useSelector(state => state.listing?.ebay_setting?.[channelID]?.)

  const initPrimaryCategory =
    data?.template_data?.category?.primary_category?.category_name;

  const initSecondCategory =
    data?.template_data?.category?.secondary_category?.category_name;

  const initStoreCategory1 =
    data?.template_data?.category?.store_category_1?.category_id;

  const initStoreCategory2 =
    data?.template_data?.category?.store_category_2?.category_id;

  const setValueRow = (e, categoryName) => {
    let rowData = { ...data };
    const value = e.target.value;
    if (value === "please select") {
      delete rowData.template_data?.category?.[e.target.name];
    } else {
      rowData = set(rowData, `template_data.category.${e.target.name}`, {
        category_id: value,
        category_name: categoryName
      });
    }
    setList(rowData, data?.publish_id);
  };

  return (
    <>
      <SearchCategory
        setOpenSearch={id => {
          setOpenSearch({ id, cate: "primary" });
        }}
        data={data}
        id={id}
        disabled={disabled}
        setCloneList={setCloneList}
        initValue={initPrimaryCategory}
        name={"primary_category"}
        channelType={channelType}
      />
      {headerInfo?.isExtended && (
        <>
          <SearchCategory
            setOpenSearch={id => {
              setOpenSearch({ id, cate: "secondary" });
            }}
            data={data}
            id={id}
            disabled={disabled}
            setCloneList={setCloneList}
            initValue={initSecondCategory}
            name={"secondary_category"}
            channelType={channelType}
          />
          <CustomMultiSelectBox
            listData={listStorageCategory}
            name={"store_category_1"}
            id={id}
            initValue={initStoreCategory1}
            disabled={disabled}
            setValueRow={setValueRow}
          />
          <CustomMultiSelectBox
            listData={listStorageCategory}
            name={"store_category_2"}
            id={id}
            disabled={disabled}
            initValue={initStoreCategory2}
            setValueRow={setValueRow}
          />
          <EbayFormatDuration
            data={data}
            disabled={disabled}
            id={id}
            setList={setList}
            currentTab={currentTab}
          />
        </>
      )}
    </>
  );
};

export default EbayCategory;
