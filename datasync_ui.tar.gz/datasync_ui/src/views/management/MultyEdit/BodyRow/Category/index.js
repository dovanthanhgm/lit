import React from "react";
import { useSelector } from "react-redux";
import SearchCategory from "src/components/MultiEdit/Category/SearchCategory";

const EtsyCategory = ({
  setList,
  style,
  data,
  disabled,
  name,
  setOpenSearch,
  channelType,
  setCloneList,
  ...props
}) => {
  const initValue = data?.template_data?.category?.category?.name;
  const templateList = useSelector(
    (state) => state.templates.listTemplates["category"]
  );

  const templateSelected = templateList?.find(
    (item) => item.id === data.templates?.category
  );

  return (
    <SearchCategory
      initValue={initValue}
      setOpenSearch={setOpenSearch}
      data={data}
      channelType={channelType}
      name="category"
      setCloneList={setCloneList}
      disabled={disabled}
      templateName={templateSelected?.name}
      {...props}
    />
  );
};

export default EtsyCategory;
