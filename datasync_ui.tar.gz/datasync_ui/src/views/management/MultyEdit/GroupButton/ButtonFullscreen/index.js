import { Button } from "@material-ui/core";
import React, { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setFieldListingDetailAction } from "src/actions/listingActions";
import FullscreenIcon from "@material-ui/icons/Fullscreen";
import FullscreenExitIcon from "@material-ui/icons/FullscreenExit";

function ButtonFullscreen(props) {
  const ref = useRef(null);
  const dispatch = useDispatch();

  const isFullScreen = useSelector((state) => state.listing.listingDetail.isFullScreen);
  const onClick = () => {
    dispatch(
      setFieldListingDetailAction({
        isFullScreen: !isFullScreen,
      })
    );
  };

  const Icon = isFullScreen ? FullscreenExitIcon : FullscreenIcon;

  return (
    <Button
      color="primary"
      size="small"
      variant="contained"
      ref={ref}
      onClick={onClick}
      startIcon={<Icon />}
      {...props}
    >
      {isFullScreen ? "Exit" : "Full screen"}
    </Button>
  );
}

export default ButtonFullscreen;
