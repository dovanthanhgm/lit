import React, { useContext } from "react";
import { Button } from "@material-ui/core";
import { useHistory } from "react-router";
import useListingFilterMulti from "src/hooks/Listing/useListingFilterMulti";
import { redirectUrl } from "src/views/management/MultyEdit/hooks/Filter";
import { turnOnMultiEdit } from "src/actions/listingActions";
import { useDispatch } from "react-redux";
import EditIcon from "@material-ui/icons/Edit";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const SwitchMultiMode = () => {
  const { channelDetail } = useContext(MultiEditContext);
  const channelID = channelDetail.id;
  const dispatch = useDispatch();
  const history = useHistory();
  const { urlSearchParam } = useListingFilterMulti();

  const handleSwitch = () => {
    dispatch(turnOnMultiEdit(false));
    history.push(`/listing/detail/${channelID}${redirectUrl(urlSearchParam)}`);
  };

  return (
    <Button
      variant="contained"
      size="small"
      color="primary"
      onClick={handleSwitch}
      startIcon={<EditIcon />}
    >
      Single edit mode
    </Button>
  );
};

export default SwitchMultiMode;
