import {
  Button,
  DialogContent,
  makeStyles,
  Switch,
  Typography,
  DialogActions,
  Dialog,
  DialogTitle,
  Box
} from "@material-ui/core";
import React, { useContext, useEffect } from "react";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";

const useStyles = makeStyles(() => ({
  container: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr",
    gridGap: "10px"
  }
}));

export default function SelectHeader() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const classes = useStyles();
  const { setTableHeaders, tableHeaders } = useContext(MultiEditTableContext);
  const [listHeader, setListHeader] = React.useState(tableHeaders);

  useEffect(() => {
    setListHeader(tableHeaders);
  }, [tableHeaders]);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;

  const tableColumnExtendTrue = ["about", "dimensions"];

  const handleChange = key => () => {
    const handleSetShowNExtend = pre => {
      if (tableColumnExtendTrue?.includes(key)) {
        return { isShow: !pre[key]?.isShow, isExtended: !pre[key]?.isShow };
      }
      return { isShow: !pre[key]?.isShow };
    };

    setListHeader(pre => ({
      ...pre,
      [key]: {
        ...pre[key],
        ...handleSetShowNExtend(pre)
      }
    }));
  };

  const onApply = () => {
    setTableHeaders(listHeader);
    handleClose();
  };

  return (
    <div>
      <Button
        aria-describedby={id}
        variant="contained"
        color="primary"
        size="small"
        onClick={handleClick}
      >
        Columns
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Hide/Show Columns</DialogTitle>
        <DialogContent className={classes.container}>
          {Object.entries(listHeader).map(([key, item], i) => (
            <Box display="flex" alignItems="center" key={i}>
              <Switch
                checked={item.isShow}
                onChange={handleChange(key)}
                color="primary"
                name="checkedB"
                inputProps={{ "aria-label": "primary checkbox" }}
                size="small"
              />
              <Typography
                variant="body1"
                color="textPrimary"
                style={{ fontSize: 13 }}
              >
                {item.name}
              </Typography>
            </Box>
          ))}
        </DialogContent>
        <DialogActions style={{ paddingRight: 24, paddingBottom: 16 }}>
          <Button
            onClick={onApply}
            color="primary"
            size="small"
            variant="contained"
          >
            Apply
          </Button>
        </DialogActions>
      </Dialog>

      {/* <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center"
        }}
      >
        <div style={{ paddingRight: 16 }}>
          {Object.entries(tableHeaders).map(([key, item], i) => (
            <div key={i}>
              <Switch
                checked={item.isShow}
                onChange={handleChange(key)}
                color="primary"
                name="checkedB"
                inputProps={{ "aria-label": "primary checkbox" }}
              />
              <Typography variant="body1" color="textPrimary" display="inline">
                {item.name}
              </Typography>
            </div>
          ))}
        </div>
      </Popover> */}
    </div>
  );
}
