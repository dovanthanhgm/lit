import { Box, makeStyles } from "@material-ui/core";
import React, { useContext } from "react";
import SaveButton from "src/components/MultiEdit/SaveButton";
import SelectHeader from "./SelectHeader";
// import ListingModalProduct from "src/views/management/Listing/listingModalProduct/index";

import { useSelector } from "react-redux";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import useAutoSave from "src/utils/multyEdit/RunAutoSave";
import Action from "src/views/management/MultyEdit/Action/index";
import SwitchMultiMode from "src/views/management/MultyEdit/GroupButton/SwitchMultiMode";
import ButtonFullscreen from "./ButtonFullscreen";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";
import { useQueryV2 } from "src/hooks/useQuery";

const useStyles = makeStyles(theme => ({
  cartImage: {
    width: 40,
    height: 40
  },
  wixImage: {
    // width: 62,
    height: 40
  },
  wishImage: {
    // width: 60,
    height: 40
  }
}));

function GroupButton() {
  const classes = useStyles();
  const { search: queryString } = useQueryV2();

  const { channelDetail } = useContext(MultiEditContext);
  const {
    listProducts,
    cloneList,
    setCloneList,
    tableHeaders,
    currentTab,
    setTableHeaders,
    setListChanging
  } = useContext(MultiEditTableContext);
  const channelType = channelDetail.type;

  const { handleClick } = useAutoSave({
    listProducts,
    cloneList,
    channelType
  });
  const isFullScreen = useSelector(
    state => state.listing.listingDetail.isFullScreen
  );

  const channelImage = {
    wix: classes.wixImage,
    wish: classes.wishImage
  };

  return (
    <Box
      display="flex"
      alignItems="center"
      mt={1}
      justifyContent="space-between"
    >
      <Box display="flex" alignItems="center">
        <Box mr={1}>
          <CartLogo
            isMultiEdit
            id={channelType}
            className={channelImage?.[channelType] || classes.cartImage}
          />
        </Box>
        <Action
          autoSave={handleClick}
          currentTab={currentTab}
          channelType={channelType}
          setCloneList={setCloneList}
          cloneList={cloneList}
          queryString={queryString}
        />
        <SaveButton
          setListChanging={setListChanging}
          listProducts={listProducts}
          channelType={channelType}
          cloneList={cloneList}
        />
      </Box>

      <Box display="flex" alignItems="center">
        <SelectHeader
          tableHeaders={tableHeaders}
          setTableHeaders={setTableHeaders}
        />
        <ButtonFullscreen style={{ margin: "0 8px" }} />
        {!isFullScreen && <SwitchMultiMode />}
      </Box>
    </Box>
  );
}

export default GroupButton;
