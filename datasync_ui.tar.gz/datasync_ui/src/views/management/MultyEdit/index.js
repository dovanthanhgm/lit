import { Box, Card, Table, TableBody } from "@material-ui/core";
import React, { useContext, useEffect, useLayoutEffect, useState } from "react";
import MultiEditField from "src/components/MultiEdit/Input/MultiEditField";
import useMoveCell from "src/hooks/MultyEdit/useMoveCell";
import { multiEdit } from "src/utils/multyEdit";
import { useResize, useSelectRow } from "./hooks";
import TableBodyContent from "src/views/management/MultyEdit/Table/TableBody";
import TableHeader from "src/views/management/MultyEdit/Table/TableHeader";
import clsx from "clsx";
import { useStyles } from "./style";
import "./index.css";
import { useDispatch } from "react-redux";
import { updateFieldMultiEditAction } from "src/reducers/multiEdit";
import useAutoSave from "src/utils/multyEdit/RunAutoSave";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";
import EmptyMultiTable from "src/views/management/MultyEdit/Table/EmptyTable";
import { EtsyProductPartnerContext } from "src/views/management/MultyEdit/Context/EtsyProductPartnerContext";
import { MultiEditContextStickyContainer } from "./Context";

function MultyEdit() {
  const dispatch = useDispatch();
  const classes = useStyles();
  const { channelDetail } = useContext(MultiEditContext);
  const {
    currentTab,
    listProducts,
    cloneList,
    setCloneList,
    tableHeaders,
    setTableHeaders,
  } = useContext(MultiEditTableContext);

  const channelType = channelDetail.type;
  const channelID = channelDetail.id;
  const { dataShipping: listShipping } = useContext(EtsyProductPartnerContext);

  const [listChanging, setListChanging] = useState({});
  const { cloumsgrid } = useResize({ tableHeaders });

  const { handleSelectOneItem, handleSelectAllItems } = useSelectRow({
    cloneList
  });

  const { listChangeLength } = useAutoSave({
    listProducts,
    cloneList,
    channelType
  });

  const handleSetListProductData = (row, name) => {
    setListChanging(prev => ({ ...prev, [name]: {} }));
    setCloneList(prev =>
      prev.map(product => {
        if (product.publish_id === row.publish_id) {
          return row;
        }
        return product;
      })
    );
  };

  useLayoutEffect(() => {
    const listChange = Object.keys(listChanging);

    if (listChange.length > 0) {
      setCloneList(prev => {
        const listWithKey = prev?.reduce((prev, curr) => {
          delete curr.publish_action;
          prev[curr.publish_id] = curr;
          return prev;
        }, {});

        return listProducts.map(product => {
          if (listChange.includes(product?.publish_id)) {
            const oldProdChanging = listWithKey[product.publish_id];
            if (oldProdChanging) return oldProdChanging;
          }
          return product;
        });
      });
    } else {
      setCloneList(JSON.parse(JSON.stringify(listProducts)));
    }
    // eslint-disable-next-line
  }, [listProducts]);

  useLayoutEffect(() => {
    dispatch(updateFieldMultiEditAction({ selectedItems: [] }));
    setListChanging({});
    // eslint-disable-next-line
  }, [channelID, currentTab]);

  useMoveCell();

  useEffect(() => {
    setTableHeaders(multiEdit(channelType));
    // eslint-disable-next-line
  }, [channelType]);

  useEffect(() => {
    if (listChangeLength === 0) {
      setListChanging({});
    }
  }, [listChangeLength]);

  const skuColumnWidth =
    cloumsgrid.find(item => item.key === "sku")?.width?.replace("px", "") || 0;

  return (
    <MultiEditContextStickyContainer skuColumnWidth={parseInt(skuColumnWidth)}>
      <Box
        id="page-multi-edit"
        style={{
          position: "relative",
          background: "#f4f6f8",
          width: "100%",
          flex: 1,
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#fff"
        }}
        overflow="hidden"
      >
        <Card className={classes.tableOverflowStyle}>
          <Box
            style={{
              position: "relative"
            }}
            display="flex"
            flexDirection="column"
          >
            <Box
              position="sticky"
              top="0"
              zIndex={100}
              style={{ background: "white" }}
            >
              <Table
                size="small"
                className={clsx(
                  classes.customTable,
                  classes.customTableHeader,
                  "tableResize"
                )}
                style={{
                  gridTemplateColumns: cloumsgrid
                    .map(({ width }) => width)
                    .join(" "),
                  padding: 0,
                  width: "max-content"
                }}
              >
                <TableHeader
                  rowCount={cloneList?.length}
                  tableHeaders={tableHeaders}
                  selectAll={handleSelectAllItems}
                  setTableHeaders={setTableHeaders}
                  skuColumnWidth={skuColumnWidth}
                />
                <EmptyMultiTable />
                <TableBody style={{ height: "100%", minHeight: 50 }}>
                  <MultiEditField
                    setListChanging={setListChanging}
                    tableHeaders={tableHeaders}
                    setListProducts={setCloneList}
                    listProducts={cloneList}
                    currentList={listProducts}
                    listShipping={listShipping}
                    channelType={channelType}
                    cloumsgridLength={cloumsgrid.length}
                  />
                </TableBody>
              </Table>
            </Box>

            <Table
              id="positionTable"
              size="small"
              className={clsx(classes.customTable, "tableResize")}
              style={{
                gridTemplateColumns: cloumsgrid
                  .map(({ width }) => width)
                  .join(" "),
                width: "max-content"
              }}
            >
              <TableBody>
                <TableBodyContent
                  listProducts={cloneList}
                  channelType={channelType}
                  initList={listProducts}
                  setCloneList={setCloneList}
                  tableHeaders={tableHeaders}
                  listShipping={listShipping}
                  setList={handleSetListProductData}
                  handleCheck={handleSelectOneItem}
                />
              </TableBody>
            </Table>
          </Box>
        </Card>
      </Box>
    </MultiEditContextStickyContainer>
  );
}

export default MultyEdit;
