import { useDispatch, useSelector } from "react-redux";
import { isEqual } from "lodash";
import React, { useContext } from "react";
import {
  fetchListProductAction,
  saveAndClose,
  setFieldListingDetailAction
} from "src/actions/listingActions";
import ListingModalProduct from "src/views/management/Listing/listingModalProduct/index";
import { bodyDataItem } from "src/utils/multyEdit/RunAutoSave";
import { handleSaveMultiEdit } from "src/services/MultyEdit";
import { useSnackbar } from "notistack";
import { MultiEditContext } from "src/views/management/MultyEdit/page";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";

function MultyEdit({
  currentProductDetail,
  setCurrentProductDetail,
  handleSetListProductData,
  openMultiEdit,
  setOpenMulti,
  channelType
}) {
  const { enqueueSnackbar } = useSnackbar();
  const { channelDetail } = useContext(MultiEditContext);
  const { currentTab } = useContext(MultiEditTableContext);

  const channelID = channelDetail.id;

  const dispatch = useDispatch();
  const { marketplaces } = useSelector(state => state?.listing);
  const isMarketPlace = !!marketplaces
    .map(market => market.id)
    .includes(channelType);
  const handleSubmit = async (func = function() {}, data) => {
    let customData = JSON.parse(JSON.stringify(data));
    if (channelType === "amazon") {
      if (
        currentProductDetail?.asin !== data?.asin &&
        isEqual(currentProductDetail?.asin_data, data?.asin_data)
      ) {
        customData = {
          ...JSON.parse(JSON.stringify(data)),
          asin_data: null
        };
      }
    }

    const body = {
      products: [bodyDataItem(customData, channelType)]
    };
    try {
      await handleSaveMultiEdit({
        channelType,
        channel_id: channelID,
        body
      });
      func();
      handleSetListProductData(data);
      dispatch(fetchListProductAction());
    } catch (e) {
      enqueueSnackbar("Save error", {
        variant: "error"
      });
    }
    dispatch(saveAndClose(false));
  };

  const handleModalSave = data => {
    handleSetListProductData(data);
  };

  const getData = () => {
    dispatch(setFieldListingDetailAction({ loadingProduct: true }));
    dispatch(fetchListProductAction());
  };

  return (
    <ListingModalProduct
      productId={currentProductDetail?.publish_id}
      getData={getData}
      multiEditModal={handleModalSave}
      channelID={channelID}
      id={"product-listing-modal-id"}
      status={currentTab}
      openMultiEdit={openMultiEdit}
      isMultiEdit
      setOpenMulti={setOpenMulti}
      setProductDetail={setCurrentProductDetail}
      productDetail={currentProductDetail}
      channelType={channelType}
      multiEditSave={handleSubmit}
      isMarketPlace={isMarketPlace}
    />
  );
}

export default MultyEdit;
