import { Checkbox, TableCell, TableHead, TableRow } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import React, { useContext, useMemo } from "react";
import { useSelector } from "react-redux";
import EachHeader from "src/views/management/MultyEdit/Header";
import { MultiEditStickyContext } from "../Context";

const getRootStyle = (item, isSkuShow, skuColumnWidth) => {
  if (item.key === "sku")
    return {
      position: "sticky",
      left: 72,
      zIndex: 10
    };

  if (item.key === "name")
    return {
      position: "sticky",
      left: isSkuShow && skuColumnWidth ? 72 + skuColumnWidth : 72,
      zIndex: 10
    };

  return {};
};

const useStyle = makeStyles(() => ({
  tableHeaderStyle: {
    userSelect: "none"
  }
}));

function TableHeaderCustome({
  tableHeaders: tableHeadersObject,
  setTableHeaders,
  selectAll,
  rowCount
}) {
  const classes = useStyle();
  const numSelected = useSelector(
    state => state.multiEdit.selectedItems.length
  );
  const tableHeaders = useMemo(() => {
    return Object.values(tableHeadersObject);
  }, [tableHeadersObject]);

  const { skuColumnWidth } = useContext(MultiEditStickyContext);

  const onClickIconExtand = key => {
    setTableHeaders(pre => ({
      ...pre,
      [key]: {
        ...pre[key],
        isExtended: !pre[key]?.isExtended
      }
    }));
  };

  const tableHeadersUI = useMemo(() => {
    let result = [];
    let headerExtendBefore = 0;

    tableHeaders.forEach(item => {
      if (!item.isShow) return;

      result.push({ ...item, headerExtendBefore, parentKey: item.key });
      if (item.canExtand && item.isExtended) {
        result = result.concat(
          item.childFields.map((item2, index) => ({
            ...item2,
            parentKey: item.key,
            isLastChild: index === item.childFields.length - 1,
            headerExtendBefore
          }))
        );

        headerExtendBefore += 1;
      }
    });

    return result;
  }, [tableHeaders]);

  const headerHasExtended = useMemo(() => {
    let result = false;
    for (let i = 0; i < tableHeaders.length; i++) {
      if (
        tableHeaders[i].isShow &&
        tableHeaders[i].canExtand &&
        tableHeaders[i].isExtended
      ) {
        result = true;
        break;
      }
    }
    return result;
  }, [tableHeaders]);

  return (
    <TableHead className={classes.tableHeaderStyle}>
      <TableRow>
        <TableCell
          padding="checkbox"
          style={{
            width: "auto",
            gridArea: "1 / 1 / span 2 / span 1",
            position: "sticky",
            left: 0,
            zIndex: 10
          }}
          className="canResize"
          id='checkbox-cell'
        >
          <Checkbox
            onChange={selectAll}
            indeterminate={numSelected > 0 && numSelected < rowCount}
            checked={rowCount > 0 && numSelected === rowCount}
            style={{ height: "100%" }}
          />
        </TableCell>
        <TableCell
          style={{
            width: "auto",
            gridArea: "1 / 2 / span 2 / span 1",
            position: "sticky",
            left: 32,
            zIndex: 10,
          }}
          className="canResize"
          id='image-cell'
        />
        {tableHeadersUI.map((item, index) => {
          return (
            <EachHeader
              key={item.key + item.parentKey + index}
              item={item}
              showVerticalDivider={tableHeaders.length - 1 !== index}
              onClickIconExtand={onClickIconExtand}
              headerHasExtended={headerHasExtended}
              index={index}
              rootStyle={getRootStyle(
                item,
                tableHeadersObject.sku?.isShow,
                skuColumnWidth
              )}
            />
          );
        })}
      </TableRow>
    </TableHead>
  );
}

export default TableHeaderCustome;
