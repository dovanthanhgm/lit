import React from "react";
import { Box, CircularProgress } from "@material-ui/core";
import { useSelector } from "react-redux";

const LoadingTable = ({ loadingMulti }) => {
  const { loadingCountProduct, firstLoading } = useSelector(
    state => state.listing.listingDetail
  );

  return (
    <>
      {(loadingMulti || firstLoading || loadingCountProduct) && (
        <Box
          zIndex={1000}
          height="100%"
          width="100%"
          top={100}
          position={"absolute"}
          textAlign={"center"}
        >
          <Box position="absolute" left={"50%"} top={88}>
            <CircularProgress style={{ position: "fixed" }} />
          </Box>
        </Box>
      )}
    </>
  );
};

export default LoadingTable;
