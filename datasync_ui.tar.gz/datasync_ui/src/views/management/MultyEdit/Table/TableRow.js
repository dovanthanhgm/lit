import { Box, Checkbox, TableCell, TableRow } from "@material-ui/core";
import React, { useState } from "react";
import MultiEditTableCell from "src/components/MultiEdit/MultiEdit";
import MultiEditSelectBox from "src/components/MultiEdit/Input/MultiEditSelectBox";
import QuantityGroup from "src/views/management/MultyEdit/BodyRow/Quantity";
import PriceGroup from "src/views/management/MultyEdit/BodyRow/Price";
import { useSelector } from "react-redux";
import AboutItem from "src/views/management/MultyEdit/BodyRow/AboutItem";
import Weight from "src/components/MultiEdit/Groups/Weight/Weight";
import Dimensions from "src/views/management/MultyEdit/BodyRow/Dimensions";
import ShippingProfile from "src/views/management/MultyEdit/BodyRow/ShippingProfile";
import LinkStatus from "src/views/management/MultyEdit/BodyRow/LinkStatus";
import StatusIcon from "src/views/management/MultyEdit/BodyRow/LinkStatus/StatusIcon";
import EtsyCategory from "src/views/management/MultyEdit/BodyRow/Category";
import AmazonOffer from "src/views/management/MultyEdit/BodyRow/Offer";
import EbayIdentifier from "src/views/management/MultyEdit/BodyRow/EbayIdentifier";
import EbayPrice from "src/views/management/MultyEdit/BodyRow/EbayPrice";
import EbayCategory from "src/views/management/MultyEdit/BodyRow/EbayCategory";
import TitleGroup from "src/views/management/MultyEdit/BodyRow/Tittle";
import ProductImage from "src/components/MultiEdit/ProductIamge";
import MultiEditAmazonAsin from "src/views/management/MultyEdit/BodyRow/AmazonAsin";
import EtsySection from "src/views/management/MultyEdit/BodyRow/Etsy/EtsySection";
import EtsyProductPartner from "src/views/management/MultyEdit/BodyRow/Etsy/EtsyProductPartner";
import MultiEditReverbCategory from "src/views/channel/Reverb/MultiEdit/Category/MultiEditReverbCategory";
import MultiEditReverbCategoryBrand from "src/views/channel/Reverb/MultiEdit/Category/MultiEditReverbCategoryBrand";
import MultiEditReverbCategoryModel from "src/views/channel/Reverb/MultiEdit/Category/MultiEditReverbCategoryModel";
import MultiEditReverbShippingId from "src/views/channel/Reverb/MultiEdit/Shipping/MultiEditReverbShippingID";
import MultiEditReverbCondition from "src/views/channel/Reverb/MultiEdit/Category/MultiEditReverbCondition";

function TableRowCustome({
  setList,
  currentTab,
  handleCheck,
  channelType,
  data,
  setCloneList,
  initProduct,
  showQtyAfter,
  tableHeaders,
  disableVariant
}) {
  const isItemSelected = useSelector(state =>
    state.multiEdit.selectedItems.includes(data.publish_id)
  );

  const isMultiEditOn = useSelector(state => state.multiEdit.isMultiEditOn);

  const [disabledApply, setDisableApply] = useState({});

  const checkIsDisableField = field => {
    return !!data?.templates?.[field] || disabledApply?.[field];
  };

  return (
    <TableRow className={isItemSelected ? "row-selected" : ""}>
      <TableCell
        width="auto"
        padding="checkbox"
        id='checkbox-cell'
        style={{
          width: "auto",
          padding: 4,
          position: "sticky",
          left: 0,
          zIndex: 10,
        }}
      >
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          style={{ height: "100%", width: "100%" }}
        >
          <Checkbox
            checked={isItemSelected}
            onClick={handleCheck}
            style={{ padding: 0 }}
          />
        </Box>
      </TableCell>
      <TableCell
        width="auto"
        padding="checkbox"
        id="image-cell"
        style={{
          width: "auto",
          justifyContent: "center",
          position: "sticky",
          left: 32,
          zIndex: 10,
        }}
      >
        <ProductImage data={data} channelType={channelType} setList={setList} />
      </TableCell>
      {tableHeaders?.linked.isShow && (
        <LinkStatus
          data={data}
          id="link-cell"
          setCloneList={setCloneList}
          currentTab={currentTab}
        />
      )}
      {tableHeaders?.link_status.isShow && (
        <StatusIcon channelType={channelType} item={data} id="status-cell" />
      )}
      {tableHeaders.sku?.isShow && (
        <MultiEditTableCell
          setList={setList}
          style={{ width: "100%" }}
          data={data}
          id={"identifier-cell"}
          name="sku"
          rootProps={{
            style: { position: "sticky", left: 72, zIndex: 10 }
          }}
        />
      )}
      {tableHeaders.upc?.isShow && (
        <MultiEditTableCell
          setList={setList}
          style={{ width: "100%" }}
          data={data}
          id={"identifier-cell"}
          name="upc"
        />
      )}
      {tableHeaders.asin?.isShow && (
        <MultiEditAmazonAsin
          id={"identifier-cell"}
          setList={setList}
          data={data}
          name="asin"
          disableVariant={disableVariant("asin")}
        />
      )}
      {/*{tableHeaders?.identifier?.isShow && (*/}
      {/*  <IdentifierGroup*/}
      {/*    setList={setList}*/}
      {/*    group="identifier-cell"*/}
      {/*    data={data}*/}
      {/*    headerInfo={tableHeaders.identifier}*/}
      {/*  />*/}
      {/*)}*/}

      <TitleGroup
        data={data}
        tableHeaders={tableHeaders}
        channelType={channelType}
        setList={setList}
      />
      {tableHeaders?.ebay_identifier?.isShow && (
        <EbayIdentifier
          id="identifier-cell"
          data={data}
          setList={setList}
          headerInfo={tableHeaders?.ebay_identifier}
        />
      )}
      {tableHeaders?.qty?.isShow && (
        <QuantityGroup
          data={data}
          id="normal-cell"
          setList={setList}
          name="qty"
          initProduct={initProduct}
          showQtyAfter={showQtyAfter}
          headerInfor={tableHeaders.qty}
        />
      )}
      {tableHeaders?.price?.isShow && (
        <PriceGroup
          setList={setList}
          isMultiEditOn={isMultiEditOn}
          disabled={checkIsDisableField("price")}
          data={data}
          channelType={channelType}
          initProduct={initProduct}
          id="normal-cell"
          name="price"
          headerInfor={tableHeaders.price}
        />
      )}
      {tableHeaders?.price_info?.isShow && (
        <PriceGroup
          setList={setList}
          isMultiEditOn={isMultiEditOn}
          disabled={checkIsDisableField("price")}
          data={data}
          initProduct={initProduct}
          channelType={channelType}
          id="normal-cell"
          name="price"
          headerInfor={tableHeaders.price_info}
        />
      )}
      {tableHeaders?.ebay_pricing?.isShow && (
        <EbayPrice
          id="normal-cell"
          setList={setList}
          data={data}
          headerInfo={tableHeaders.ebay_pricing}
          disabled={checkIsDisableField("price")}
        />
      )}
      {tableHeaders?.priceTmpl?.isShow && (
        <MultiEditSelectBox
          name="price"
          data={data}
          channelType={channelType}
          id="normal-cell"
          setDisableApply={setDisableApply}
          setList={setList}
        />
      )}
      {tableHeaders.etsy_category_id?.isShow && (
        <EtsyCategory
          setList={setList}
          setCloneList={setCloneList}
          style={{ width: "100%" }}
          id="normal-cell"
          channelType={channelType}
          disabled={checkIsDisableField("category")}
          data={data}
          name="etsy_category_id"
        />
      )}
      {tableHeaders.reverb_category_id?.isShow && (
        <MultiEditReverbCategory
          setList={setList}
          setCloneList={setCloneList}
          style={{ width: "100%" }}
          id="normal-cell"
          disabled={checkIsDisableField("category")}
          data={data}
          name="reverb_category_id"
        />
      )}
      {tableHeaders.reverb_category_brand?.isShow && (
        <MultiEditReverbCategoryBrand
          setList={setList}
          setCloneList={setCloneList}
          style={{ width: "100%" }}
          id="normal-cell"
          disabled={checkIsDisableField("category")}
          data={data}
          name="reverb_category_brand"
        />
      )}
      {tableHeaders.reverb_category_model?.isShow && (
        <MultiEditReverbCategoryModel
          setList={setList}
          setCloneList={setCloneList}
          style={{ width: "100%" }}
          id="normal-cell"
          disabled={checkIsDisableField("category")}
          data={data}
          name="reverb_category_model"
        />
      )}
      {tableHeaders.reverb_category_condition?.isShow && (
        <MultiEditReverbCondition
          setList={setList}
          setCloneList={setCloneList}
          style={{ width: "100%" }}
          id="normal-cell"
          disabled={checkIsDisableField("category")}
          data={data}
          name="reverb_category_condition"
        />
      )}

      {tableHeaders?.about?.isShow && (
        <AboutItem
          // isMultiEditOn={isMultiEditOn}
          setList={setList}
          disabled={checkIsDisableField("category")}
          data={data}
          id="normal-cell"
          headerInfo={tableHeaders.about}
        />
      )}
      {tableHeaders?.ebay_category?.isShow && (
        <EbayCategory
          id="normal-cell"
          setList={setList}
          style={{ width: "100%" }}
          disabled={checkIsDisableField("category")}
          currentTab={currentTab}
          data={data}
          channelType={channelType}
          setCloneList={setCloneList}
          headerInfo={tableHeaders.ebay_category}
        />
      )}
      {tableHeaders?.etsySection?.isShow && (
        <EtsySection
          name={"section"}
          data={data}
          id="normal-cell"
          disabled={checkIsDisableField("category")}
          setList={setList}
        />
      )}
      {tableHeaders?.productPartner?.isShow && (
        <EtsyProductPartner
          name={"productPartner"}
          data={data}
          id="normal-cell"
          disabled={checkIsDisableField("category")}
          setList={setList}
        />
      )}
      {tableHeaders?.categoryTmpl?.isShow && (
        <MultiEditSelectBox
          name="category"
          data={data}
          channelType={channelType}
          setDisableApply={setDisableApply}
          setList={setList}
          id="normal-cell"
        />
      )}
      {tableHeaders?.dimensions?.isShow && (
        <Dimensions
          setList={setList}
          data={data}
          id="normal-cell"
          unit={"dimension_units"}
        />
      )}
      {tableHeaders.weight?.isShow && (
        <Weight
          setList={setList}
          style={{ width: "100%" }}
          // disabled={isMultiEditOn}
          data={data}
          id="normal-cell"
          // handleSetUndo={handleSetUndo}
          name="weight"
        />
      )}
      {tableHeaders.shipping_profile?.isShow && (
        <ShippingProfile
          setList={setList}
          disabled={checkIsDisableField("shipping")}
          style={{ width: "100%" }}
          data={data}
          id="normal-cell"
          name="shipping_profile"
        />
      )}
      {tableHeaders.reverb_shipping_id?.isShow && (
        <MultiEditReverbShippingId
          setList={setList}
          setCloneList={setCloneList}
          style={{ width: "100%" }}
          id="normal-cell"
          disabled={checkIsDisableField("shipping")}
          data={data}
          name="reverb_shipping_id"
        />
      )}
      {tableHeaders?.shippingTmpl?.isShow && (
        <MultiEditSelectBox
          name="shipping"
          data={data}
          channelType={channelType}
          setList={setList}
          setDisableApply={setDisableApply}
          id="normal-cell"
        />
      )}

      {/*{tableHeaders?.best_offer?.isShow && (*/}
      {/*  <BestOfferGroup*/}
      {/*    setList={setList}*/}
      {/*    isMultiEditOn={isMultiEditOn}*/}
      {/*    showAfterOffer={showAfterOffer}*/}
      {/*    data={data}*/}
      {/*    name="best_offer"*/}
      {/*    id="offer-class"*/}
      {/*    headerInfo={tableHeaders.best_offer}*/}
      {/*  />*/}
      {/*)}*/}
      {tableHeaders?.offer_group?.isShow && (
        <AmazonOffer
          setList={setList}
          isMultiEditOn={isMultiEditOn}
          // showAfterOffer={showAfterOffer}
          data={data}
          name="best_offer"
          disabled={checkIsDisableField("offer")}
          id="normal-cell"
          headerInfo={tableHeaders.best_offer}
        />
      )}
      {tableHeaders?.offerTmpl?.isShow && (
        <MultiEditSelectBox
          name="offer"
          data={data}
          channelType={channelType}
          setDisableApply={setDisableApply}
          id="normal-cell"
          setList={setList}
        />
      )}
      {tableHeaders?.brandTmpl?.isShow && (
        <MultiEditSelectBox
          name="brand"
          channelType={channelType}
          data={data}
          setList={setList}
          setDisableApply={setDisableApply}
        />
      )}
      {tableHeaders?.paymentTmpl?.isShow && (
        <MultiEditSelectBox
          name="payment"
          channelType={channelType}
          setDisableApply={setDisableApply}
          data={data}
          id="normal-cell"
          setList={setList}
        />
      )}
    </TableRow>
  );
}

export default TableRowCustome;
