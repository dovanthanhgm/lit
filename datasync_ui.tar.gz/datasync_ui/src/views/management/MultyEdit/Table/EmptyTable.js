import React, { useContext } from "react";
import { useQueryV2 } from "src/hooks/useQuery";
import { Box, Typography } from "@material-ui/core";
import { MultiEditContext } from "src/views/management/MultyEdit/page";

const EmptyMultiTable = () => {
  const { search } = useQueryV2();
  const { totalProduct } = useContext(MultiEditContext);

  if (!search && totalProduct === 0) {
    return (
      <Box minHeight={50}>
        <Box
          textAlign="center"
          my={3}
          position="absolute"
          top={"50%"}
          left="50%"
        >
          <Typography variant="body2">No data</Typography>
        </Box>
      </Box>
    );
  }

  if (search && totalProduct === 0) {
    return (
      <Box
        textAlign="center"
        my={3}
        position="absolute"
        top={"50%"}
        minHeight={50}
        left="50%"
      >
        <Typography variant="body2">Not found</Typography>
      </Box>
    );
  }
  return <></>;
};

export default EmptyMultiTable;
