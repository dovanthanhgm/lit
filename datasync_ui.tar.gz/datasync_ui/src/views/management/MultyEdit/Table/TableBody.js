import React, { useContext, useMemo } from "react";
import TableRow from "src/views/management/MultyEdit/Table/TableRow";
import { MultiEditTableContext } from "src/views/management/MultyEdit/Layout/MultiEditTableLayout";

function TableBodyCustome({
  listProducts,
  channelType,
  initList,
  setCloneList,
  showQtyAfter,
  tableHeaders,
  setList,
  handleCheck
}) {
  //init will change if link and unlink, because publish id will change by link product => prev list do not exist publish id current
  // re code below for change
  const { currentTab } = useContext(MultiEditTableContext);
  const initListObject = useMemo(() => {
    return initList.reduce((acc, item) => {
      acc[item.publish_id] = item;
      return acc;
    }, {});
  }, [initList]);

  return (
    <>
      {listProducts.map((item, i) => {
        if (!item) return null;
        const initProduct = initListObject?.[item.publish_id];
        const variationProduct = item?.variant_count > 0;
        const channelDisableEditVariation = col => {
          // if (
          //   ["price", "qty"].includes(col) &&
          //   channelMultiEdit.includes(channelType) &&
          //   variationProduct
          // ) {
          //   return false;
          // }
          return col === "asin" && channelType === "amazon" && variationProduct;
        };

        return (
          <TableRow
            setList={setList}
            currentTab={currentTab}
            handleCheck={e => {
              handleCheck(item.publish_id, i, e.shiftKey)}}
            key={item?.publish_id}
            channelType={channelType}
            data={item}
            setCloneList={setCloneList}
            initProduct={initProduct}
            showQtyAfter={showQtyAfter}
            tableHeaders={tableHeaders}
            disableVariant={channelDisableEditVariation}
          />
        );
      })}
    </>
  );
}

export default TableBodyCustome;
