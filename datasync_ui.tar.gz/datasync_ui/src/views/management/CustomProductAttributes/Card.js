import {
  Box,
  Divider,
  Grid,
  IconButton,
  makeStyles,
  TextField,
  Typography,
} from "@material-ui/core";
import { useSnackbar } from "notistack";
import React, { useRef, useState } from "react";
import { Menu as MenuIcon, Trash2 as Trash2Icon } from "react-feather";

const useStyles = makeStyles(() => ({
  root: {
    "&:hover": {
      textDecoration: "underline",
      color: "blue",
      cursor: "pointer",
    },
  },
}));

export default function Card({
  text,
  handleClick,
  pk,
  newListAttributes,
  setNewListAttributes,
  listAttributes,
  handleSaveListAttributes,
}) {
  const classes = useStyles();

  const ref = useRef(null);
  const { enqueueSnackbar } = useSnackbar();
  const [isEdit, setIsEdit] = useState(false);

  const handleChangeName = async (e) => {
    const { name, value } = e.target;

    const newList = newListAttributes.map((item) =>
      item?.pk?.toString() === name ? { ...item, name: value } : item
    );
    setNewListAttributes(newList);
    if (value?.trim() !== "") {
      try {
        await handleSaveListAttributes(newList, enqueueSnackbar);
      } catch (error) {
        enqueueSnackbar(error?.response?.data?.detail, { variant: "error" });
      }
    }
  };

  const handleEmptyName = (e) => {
    const { name, value } = e.target;
    setIsEdit(false);
    if (value?.trim() === "") {
      const prevItem = listAttributes.filter(
        (item) => item?.pk?.toString() === name
      );
      const newList = newListAttributes.map((item) =>
        item?.pk?.toString() === name ? prevItem[0] : item
      );
      setNewListAttributes(newList);
    }
  };

  return (
    <div>
      <Box ref={ref} pl={3} pr={2}>
        <Grid container justify="flex-start" alignItems="center">
          <Grid item xs={10}>
            {!isEdit && (
              <Typography
                component="span"
                onClick={() => setIsEdit(true)}
                className={classes.root}
                color="primary"
              >
                {text}
              </Typography>
            )}
            {isEdit && (
              <TextField
                value={text}
                rows={2}
                name={pk?.toString()}
                onBlur={handleEmptyName}
                onChange={handleChangeName}
                fullWidth
                size={"small"}
                inputProps={{ maxLength: 24 }}
                variant={"outlined"}
                autoFocus
              />
            )}
          </Grid>
          <Grid item xs={1}>
            <Typography align="right">
              <MenuIcon />
            </Typography>
          </Grid>
          <Grid item xs={1}>
            <Typography align="right">
              <IconButton onClick={handleClick(pk)}>
                <Trash2Icon />
              </IconButton>
            </Typography>
          </Grid>
        </Grid>
      </Box>
      <Divider />
    </div>
  );
}
