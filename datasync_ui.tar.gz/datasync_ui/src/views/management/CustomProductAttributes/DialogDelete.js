import React from "react";
import {
  Typography,
  makeStyles,
  Box,
  Button,
  CardActions,
  CardHeader,
  CardContent,
  Card,
  Divider,
  Dialog,
  // TextField,
  // InputAdornment,
  // Paper,
  // Chip,
} from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {},
  buttonAdd: {
    marginRight: theme.spacing(2),
  },
  cardActions: {
    display: "flex",
    // flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },
  textInDialog: {
    marginBottom: theme.spacing(1),
  },
  mrSmall: {
    marginRight: theme.spacing(1),
  },
  table: {
    marginBottom: theme.spacing(2),
  },
  leftDialogAddMore: {
    width: "20%",
    maxWidth: 300,
  },
  addvariation: {
    marginTop: theme.spacing(0.5),
    cursor: "pointer",
  },
}));

function DialodAddVariation({ handleClose, handleDelete, message }) {
  const classes = useStyles();
  // const [variations, setVariations] = useState([]);

  const handleSaveAction = () => {
    handleDelete();
    handleClose();
  };

  return (
    <Dialog open onClose={handleClose} fullWidth maxWidth="sm">
      <Card>
        <CardHeader title="Are you sure?" />
        <Divider />
        <CardContent>
          <Typography className={classes.textInDialog}>{message}</Typography>

          <Box style={{ height: 30 }} />
        </CardContent>
        <Divider />
        <CardActions className={classes.cardActions}>
          <Button
            size="small"
            color="primary"
            variant="contained"
            className={classes.mrSmall}
            onClick={handleSaveAction}
          >
            Yes, Delete
          </Button>
          <Button size="small" variant="contained" onClick={handleClose}>
            Cancel
          </Button>
        </CardActions>
      </Card>
    </Dialog>
  );
}

export default DialodAddVariation;
