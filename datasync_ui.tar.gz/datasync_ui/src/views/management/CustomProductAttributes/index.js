import {
  Box,
  Card,
  CircularProgress,
  Divider,
  Grid,
  Typography,
} from "@material-ui/core";
import { Formik } from "formik";
import { debounce } from "lodash";
import React, { useEffect, useState } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { Plus as PlusIcon } from "react-feather";
import { useDispatch, useSelector } from "react-redux";
import {
  getListAttributesStart,
  getListAttributesSuccess,
} from "src/actions/attribute";
import Header from "src/components/Header";
import Button from "src/components/MUI/Button";
import Dialog from "src/components/MUI/Dialog";
import TextField from "src/components/MUI/Formik/Text";
import Page from "src/components/Page";
import {
  deleteCustomAttribute,
  postCustomAttribute,
  putListAttributes,
} from "src/services/attributes";
import { ContainerDnd } from "./Container";

const handleSaveListAttributes = debounce(async (newList, enqueueSnackbar) => {
  const seen = new Set();
  const hasDuplicate = newList.some((item) => {
    return seen.size === seen.add(item?.name?.trim()).size;
  });
  if (hasDuplicate) {
    enqueueSnackbar("Duplicate attribute name exists", { variant: "error" });
  } else {
    try {
      const status = await putListAttributes({ listAttributes: newList });
      if (status) return status;
    } catch (error) {
      console.log(error);
    }
  }
}, 1000);

export default function CustomProductAttributes() {
  const dispatch = useDispatch();

  const { listAttributes, loading } = useSelector((state) => state.attributes);

  const [newListAttributes, setNewListAttributes] = useState([]);
  const [openDialog, setOpen] = useState(false);
  const [attributeID, setAttributeID] = useState("");

  const handleClick = (id) => () => {
    setAttributeID(id);
    setOpen(true);
  };

  const handleCloseDialogDelete = () => {
    setOpen(false);
  };

  const handleDeleteVariation = async () => {
    await deleteCustomAttribute({ id: attributeID });
    dispatch(
      getListAttributesSuccess(
        listAttributes.filter((item) => item.id !== attributeID)
      )
    );
    dispatch(getListAttributesStart());
  };

  useEffect(() => {
    dispatch(getListAttributesStart());
  }, [dispatch]);

  useEffect(() => {
    setNewListAttributes(listAttributes);
  }, [listAttributes]);

  return (
    <DndProvider backend={HTML5Backend}>
      <Page>
        <Box ml={3} mr={3}>
          <Formik
            initialValues={{
              name: "",
            }}
            enableReinitialize
            onSubmit={async (values, { resetForm, setErrors }) => {
              try {
                const res = await postCustomAttribute({ name: values.name });

                if (!res.message) {
                  dispatch(getListAttributesSuccess([res, ...listAttributes]));
                  resetForm();
                }
              } catch (error) {
                const name = error.response.data?.name;
                name && setErrors({ name });
              }
            }}
          >
            {({ values, handleSubmit, errors, isSubmitting }) => {
              return (
                <form onSubmit={handleSubmit}>
                  <Box mt={3} mb={3}>
                    <Header headerName={"Custom Product Attributes"} />
                  </Box>
                  <Card>
                    <Box p={2} display="flex">
                      <Grid
                        container
                        spacing={3}
                        justify="flex-start"
                        alignItems="center"
                      >
                        <Grid item xs={6}>
                          <Box mt={errors.name ? 4 : 1}>
                            <TextField
                              fullWidth
                              name="name"
                              placeholder="New Custom Product Attribute"
                            />
                          </Box>
                        </Grid>
                        <Grid item xs={2}>
                          <Box display="flex">
                            <Box mt={1}>
                              <Button
                                color="secondary"
                                startIcon={<PlusIcon />}
                                type="submit"
                                disabled={isSubmitting || !values.name}
                                text="Add"
                                notShowCircle={!values.name}
                              />
                            </Box>
                          </Box>
                        </Grid>
                      </Grid>
                    </Box>

                    {loading && (
                      <Box
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                        mb={2}
                      >
                        <CircularProgress />
                      </Box>
                    )}

                    <Divider />
                    <ContainerDnd
                      handleSaveListAttributes={handleSaveListAttributes}
                      setNewListAttributes={setNewListAttributes}
                      newListAttributes={newListAttributes}
                      listAttributes={listAttributes}
                      handleClick={handleClick}
                    />
                  </Card>
                  {openDialog && (
                    <Dialog
                      open={openDialog}
                      handleClose={handleCloseDialogDelete}
                      header={"Are you sure?"}
                      content={
                        <Typography color="textPrimary" variant="body1">
                          Are you sure you want to delete this atribute?
                        </Typography>
                      }
                      handleConfirm={handleDeleteVariation}
                      nameButton="Yes, Remove"
                    />
                  )}
                </form>
              );
            }}
          </Formik>
        </Box>
      </Page>
    </DndProvider>
  );
}
