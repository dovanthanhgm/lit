import { useSnackbar } from "notistack";
import React from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import Card from "./Card";

const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

export const ContainerDnd = ({
  handleClick,
  listAttributes,
  newListAttributes,
  setNewListAttributes,
  handleSaveListAttributes
}) => {
  const { enqueueSnackbar } = useSnackbar();

  const onDragEnd = async result => {
    if (!result.destination) {
      return;
    }
    const items = reorder(
      newListAttributes,
      result.source.index,
      result.destination.index
    );
    setNewListAttributes(
      items.map((item, i) => {
        return { ...item, position: Math.abs(i - (listAttributes.length - 1)) };
      })
    );

    let newList = items.map((item, i) => {
      return { ...item, position: Math.abs(i - (listAttributes.length - 1)) };
    });

    try {
      await handleSaveListAttributes(newList, enqueueSnackbar);
    } catch (error) {
      enqueueSnackbar(error?.response?.data?.detail, { variant: "error" });
    }
  };

  const renderCard = card => {
    return (
      <Card
        listAttributes={listAttributes}
        setNewListAttributes={setNewListAttributes}
        newListAttributes={newListAttributes}
        pk={card.pk}
        key={card.index}
        text={card.name}
        handleClick={handleClick}
        handleSaveListAttributes={handleSaveListAttributes}
      />
    );
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <Droppable droppableId="droppable">
        {provided => (
          <div {...provided.droppableProps} ref={provided.innerRef}>
            {newListAttributes.map((card, i) => (
              <Draggable
                key={card.pk}
                draggableId={card.pk.toString()}
                index={i}
              >
                {provided => (
                  <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                  >
                    {renderCard(card, i)}
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </DragDropContext>
  );
};
