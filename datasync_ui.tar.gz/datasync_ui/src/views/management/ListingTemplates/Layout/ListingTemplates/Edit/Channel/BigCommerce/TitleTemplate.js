import React from "react";
import FormInfoTitle from "src/components/Template/Etsy/Title/FormInfoTitle";

const BigCommerceTitleTemplate = () => {
  return <FormInfoTitle channelType={"bigcommerce"} isTemplate />;
};

export default BigCommerceTitleTemplate;
