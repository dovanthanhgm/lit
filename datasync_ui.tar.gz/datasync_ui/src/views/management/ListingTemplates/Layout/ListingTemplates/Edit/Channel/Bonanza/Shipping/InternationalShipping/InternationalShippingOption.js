import React, { useState } from "react";
import InternationalTypeSelect, {
  bonanzaCalculatedValue,
  bonanzaDescriptionValue,
  bonanzaFixedValue,
  bonanzaFreeValue
} from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/InternationalTypeSelect";
import BonanzaFlatOptionShipping from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/FlatOption/FlatOptions";
import InternationalCalculatedOptions from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/CalculatedOption/CalculatedOptions";
import InternationalFreeOptions from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/FreeOption/InternationalFreeOptions";
import InternationalDescriptionOptions from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/DescriptionOption/DescriptionOptions";
import { useField } from "formik";

const ShippingOption = ({ isEditListing, name, disabled }) => {
  const [type, setType] = useState("");

  return (
    <div>
      <InternationalTypeSelect
        type={type}
        setType={setType}
        name={name?.type}
        disabled={disabled}
        isEditListing={isEditListing}
      />
      {type === bonanzaFixedValue && (
        <BonanzaFlatOptionShipping
          isEditListing={isEditListing}
          name={name?.rootName}
          disabled={disabled}
        />
      )}
      {type === bonanzaCalculatedValue && (
        <InternationalCalculatedOptions
          isEditListing={isEditListing}
          name={name?.rootName}
          disabled={disabled}
        />
      )}
      {type === bonanzaFreeValue && (
        <InternationalFreeOptions
          isEditListing={isEditListing}
          name={name?.rootName}
          disabled={disabled}
        />
      )}
      {type === bonanzaDescriptionValue && (
        <InternationalDescriptionOptions
          isEditListing={isEditListing}
          name={name?.rootName}
          disabled={disabled}
        />
      )}
    </div>
  );
};
const MemoOptionShipping = React.memo(ShippingOption);

const defaultName = {
  status: "global_shipping"
};

const InternationalShippingOption = ({
  name = defaultName,
  isEditListing,
  disabled
}) => {
  const [{ value: valueStatus }] = useField(name?.status);

  if (!valueStatus) {
    return null;
  }

  return (
    <MemoOptionShipping
      name={name}
      isEditListing={isEditListing}
      disabled={disabled}
    />
  );
};

export default InternationalShippingOption;
