import React from "react";
import BigCategorySearch from "src/components/Template/BigCommerce/Category/CategorySearch";
import Container from "src/components/Template/Container";
import { useParams } from "react-router";

const nameDefault = {
  id: "category.id",
  name: "category.name",
  path: "category.path",
  categories: "categories"
};

const BigCommerceCategory = ({ channelType }) => {
  const { channel_id } = useParams();

  return (
    <Container title="Category">
      <BigCategorySearch
        name={nameDefault}
        channel_id={channel_id}
        channelType={channelType}
      />
    </Container>
  );
};

export default BigCommerceCategory;
