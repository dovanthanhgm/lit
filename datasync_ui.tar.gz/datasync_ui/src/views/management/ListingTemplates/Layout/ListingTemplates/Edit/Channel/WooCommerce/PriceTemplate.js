import React from "react";
import FormInfoPrice from "src/components/Template/Etsy/Price/FormInfoPrice";

const WoocommercePriceTemplate = () => {
  return <FormInfoPrice hideRounding isExtend />;
};

export default WoocommercePriceTemplate;
