import React, { useEffect, useState } from "react";
import { useField } from "formik";
import TextFieldNumber from "src/components/MUI/TextFieldnumber";

const DimensionInput = ({ name, disabled, mapName }) => {
  const [{ value: initValue }, , { setValue: setInitValue }] = useField(name);
  const [, , { setValue: setMapValue }] = useField(mapName);

  const [value, setValue] = useState(0);

  const handleChange = e => {
    setValue(e.target.value);
  };

  const handleBlur = () => {
    setInitValue(value);
    setMapValue("");
  };

  useEffect(() => {
    setValue(initValue);
  }, [initValue]);

  return (
    <TextFieldNumber
      name={name}
      value={value}
      onChange={handleChange}
      onBlur={handleBlur}
      fullWidth
      disabled={disabled}
      variant={"outlined"}
      size={"small"}
    />
  );
};

export default DimensionInput;
