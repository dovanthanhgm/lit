import React from "react";
import { Grid, Typography } from "@material-ui/core";
import SwitchCustom from "src/components/MUI/Formik/Switch";

const InternationalShippingStatus = ({
  isEditListing = false,
  name = "global_shipping",
  disabled
}) => {
  return (
    <Grid container spacing={2} alignItems="center">
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Status
        </Typography>
      </Grid>
      <Grid item xs={9}>
        <SwitchCustom name={name} disabled={disabled} />
      </Grid>
    </Grid>
  );
};

export default InternationalShippingStatus;
