import React from "react";
import {
  Box,
  Grid,
  IconButton,
  Link,
  Paper,
  Typography
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import { makeStyles } from "@material-ui/styles";
import { FieldArray, useField } from "formik";
import {
  bonanzaShipmentCalculatedOption,
  SHIPPING_CAREER
} from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/constants";
import FormikDropDown from "src/components/MUI/Formik/FormikDropDown";
import CheckboxCustom from "src/components/MUI/Formik/Checkbox";
// import ShippingService from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/CalculatedShip/ShippingService";

const useStyles = makeStyles(theme => ({
  iconClose: {
    position: "absolute",
    right: 0,
    top: 0
  },
  boxStyle: {
    position: "relative"
  },
  paperStyle: {
    padding: theme.spacing(1)
  }
}));

const CustomAddItem = ({ name, disabled }) => {
  const classes = useStyles();
  const names = bonanzaShipmentCalculatedOption(name);
  const [{ value: listOption }] = useField(names);

  return (
    <Paper variant="outlined" className={classes.paperStyle}>
      <FieldArray
        name={bonanzaShipmentCalculatedOption(name)}
        render={arrayHelper => (
          <Grid container spacing={2}>
            {listOption.map((option, index) => {
              return (
                <Grid item xs={12} key={index}>
                  <Box
                    p={2}
                    className={classes.boxStyle}
                    bgcolor="background.dark"
                  >
                    <IconButton
                      size="small"
                      onClick={() => arrayHelper.remove(index)}
                      className={classes.iconClose}
                    >
                      <CloseIcon />
                    </IconButton>
                    <Grid container alignItems="center" spacing={1}>
                      <Grid item xs={2}>
                        <Typography variant="h6" align="right">
                          Shipping Carrier
                        </Typography>
                      </Grid>
                      <Grid item xs={9}>
                        <FormikDropDown
                          name={`${names}.${index}.shipping_carrier`}
                          listItem={SHIPPING_CAREER}
                          disabled={disabled}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <Typography variant="h6" align="right">
                          Buyer Pays For Label
                        </Typography>
                      </Grid>
                      <Grid item xs={9}>
                        <CheckboxCustom
                          name={`${names}.${index}.buyer_pays_for_label`}
                          disabled={disabled}
                        />
                      </Grid>
                      {/*<Grid item xs={2}>*/}
                      {/*  <Typography variant="h6" align="right">*/}
                      {/*    Shipping Service*/}
                      {/*  </Typography>*/}
                      {/*</Grid>*/}
                      {/*<Grid item xs={9}>*/}
                      {/*  <ShippingService*/}
                      {/*    name={`${names}.${index}.shipping_carrier`}*/}
                      {/*    nameShipping={`${names}.${index}.shipping_service`}*/}
                      {/*    disabled={disabled}*/}
                      {/*  />*/}
                      {/*</Grid>*/}
                    </Grid>
                  </Box>
                </Grid>
              );
            })}
            {!disabled && listOption?.length < 1 && (
              <Grid item xs={12}>
                <Link
                  onClick={() =>
                    arrayHelper.push({
                      shipping_carrier: "",
                      buyer_pays_for_label: false,
                      shipping_service: ""
                    })
                  }
                >
                  <Typography variant="body2">Add options</Typography>
                </Link>
              </Grid>
            )}
          </Grid>
        )}
      />
    </Paper>
  );
};

export default CustomAddItem;
