import React from "react";
import { FieldArray, useField } from "formik";
import {
  Box,
  Grid,
  IconButton,
  Link,
  Paper,
  Typography
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import FormikDropDown from "src/components/MUI/Formik/FormikDropDown";
import {
  BONANZA_SEE_DESCRIPTION,
  bonanzaInternationalShipmentDescriptionOption,
  SHIP_TO_LOCATION
} from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/constants";
import { makeStyles } from "@material-ui/styles";

const useStyles = makeStyles(theme => ({
  iconClose: {
    position: "absolute",
    right: 0,
    top: 0
  },
  boxStyle: {
    position: "relative"
  },
  paperStyle: {
    padding: theme.spacing(1)
  }
}));

const DescriptionOptionList = ({ name, disabled }) => {
  const classes = useStyles();
  const names = bonanzaInternationalShipmentDescriptionOption(name);
  const [{ value: listOption }] = useField(names);

  return (
    <Paper variant="outlined" className={classes.paperStyle}>
      <FieldArray
        name={names}
        render={arrayHelpers => (
          <Grid container spacing={2}>
            {listOption.map((option, index) => {
              return (
                <Grid item xs={12} key={index}>
                  <Box
                    p={2}
                    className={classes.boxStyle}
                    bgcolor="background.dark"
                  >
                    <IconButton
                      size="small"
                      onClick={() => arrayHelpers.remove(index)}
                      className={classes.iconClose}
                    >
                      <CloseIcon />
                    </IconButton>
                    <Grid container alignItems="center" spacing={1}>
                      <Grid item xs={2}>
                        <Typography variant="h6" align="right">
                          Shipping To Location
                        </Typography>
                      </Grid>
                      <Grid item xs={9}>
                        <FormikDropDown
                          name={`${names}.${index}.ship_to_location`}
                          listItem={SHIP_TO_LOCATION}
                          disabled={disabled}
                        />
                      </Grid>
                    </Grid>
                  </Box>
                </Grid>
              );
            })}
            {!disabled && (
              <Grid item xs={12}>
                <Typography variant="body2">
                  <Link
                    style={{ cursor: "pointer" }}
                    onClick={() =>
                      arrayHelpers.push({
                        shipment_type: BONANZA_SEE_DESCRIPTION,
                        ship_to_location: ""
                      })
                    }
                  >
                    Add options
                  </Link>
                </Typography>
              </Grid>
            )}
          </Grid>
        )}
      />
    </Paper>
  );
};

export default DescriptionOptionList;
