import React from "react";
import FormInfoPrice from "src/components/Template/Etsy/Price/FormInfoPrice";

const BigPriceTemplate = () => {
  return <FormInfoPrice hideRounding isExtend />;
};

export default BigPriceTemplate;
