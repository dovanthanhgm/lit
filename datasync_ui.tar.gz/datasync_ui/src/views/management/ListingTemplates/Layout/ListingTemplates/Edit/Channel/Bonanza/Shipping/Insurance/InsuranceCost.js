import React from "react";
import { Grid, Typography } from "@material-ui/core";
import TextFieldNumber from "src/components/MUI/Formik/Number";
import { useField } from "formik";
import { IncludedInShippingHandling } from "src/constants/Listing/Bonanza/index";

const names = {
  insurance: {
    cost: "insurance_cost",
    option: "insurance_type"
  }
};

const Fee = ({ isEditListing, name, disabled }) => {
  return (
    <Grid container spacing={2} alignItems="center">
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Insurance Fee
        </Typography>
      </Grid>
      <Grid item xs={9}>
        <TextFieldNumber name={name.insurance.cost} disabled={disabled} />
      </Grid>
    </Grid>
  );
};

const MemoFee = React.memo(Fee);

const InsuranceCost = ({ name = names, isEditListing, disabled }) => {
  const [{ value }] = useField(name.insurance.option);

  if (value === IncludedInShippingHandling) {
    return null;
  }
  return (
    <MemoFee name={name} disabled={disabled} isEditListing={isEditListing} />
  );
};

export default InsuranceCost;
