import React from "react";
import FormInfoTitle from "src/components/Template/Etsy/Title/FormInfoTitle";

const WooCommerceTitleTemplate = () => {
  return <FormInfoTitle channelType={"woocommerce"} isTemplate />;
};

export default WooCommerceTitleTemplate;
