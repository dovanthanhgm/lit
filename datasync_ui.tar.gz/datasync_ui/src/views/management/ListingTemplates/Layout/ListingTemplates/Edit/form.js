import { Box, Paper } from "@material-ui/core";
import { Formik } from "formik";
import { useSnackbar } from "notistack";
import React, { useState } from "react";
import Header from "src/components/Header";
import { postCreateTemplates, putTemplates } from "src/services/templates";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";
import { convertFakeToReal } from "src/utils/convertData";
import { convertIdToName, convertTemplateTypeToName } from "src/utils/helper";
import { templateValidate } from "src/utils/Validates";
import View from "./view";
import { alertError } from "src/helper/showErrorMessage";
import { isEmpty } from "lodash";
import SingleAlert from "src/components/Notify/SingleAlert";
import { messageError } from "src/utils/ErrorResponse";
import wait from "src/utils/wait";
import { setToolTipRunningProcess } from "src/actions/accountActions";
import { useDispatch } from "react-redux";
import WarningBusiness from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/ebay/Business/WarningBusiness";
import {
  CONDITION_RSC_ID,
  EBAY_CONDITION_POLICIES_KEY
} from "src/views/channel/Ebay/constants";

const handleChannelSubmitData = ({ channelType, body, type }) => {
  const newBody = Object.assign({}, body);
  const channel = {
    ebay: function() {
      if (type === "category") {
        EBAY_CONDITION_POLICIES_KEY.forEach(item => {
          delete newBody[item];
        });
        delete newBody[CONDITION_RSC_ID];
      }
      if (type === "shipping") {
        if (!newBody?.weight_major) {
          newBody.weight_major = 0;
        }
        if (!newBody?.weight_minor) {
          newBody.weight_minor = 0;
        }
      }
    },
    etsy: function() {
      if (type === "category") {
        if (newBody?.advance?.attributes?.length === 0) {
          delete newBody?.advance?.attributes;
        } else {
          newBody.advance.attributes = newBody?.advance?.attributes?.filter(
            item => item.attribute_id
          );
        }
      }
    },
    tiktok: function() {
      if (type === "category") {
        if (!newBody?.category_rules?.isSizeChartSupport) {
          delete newBody.size_chart_id;
          delete newBody.size_chart_url;
        }
        if (!newBody.category_rules.isSupportExemption) {
          newBody.exemption_of_identifier_code = "";
        }

        newBody.is_cod_open = newBody.category_rules.supportCod
          ? newBody.is_cod_open
          : false;
      }
    }
  };
  if (channel?.[channelType]) {
    channel[channelType]();
  }
  return newBody;
};

export default function FormAddEditTemplate({
  addOrEdit = "add",
  templateID,
  channelID,
  store,
  channelDetail,
  templateType,
  setIsNextTemplate,
  initialValues,
  cancelClick,
  isNextTemplate,
  isFirstSetup,
  handleAddTemplateSuccess,
  step
}) {
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const [errorAlert, setErrorAlert] = useState([]);

  return (
    <>
      <Header
        headerName={`${capitalizeFirstLetter(addOrEdit)} ${convertIdToName(
          channelDetail.type
        )} ${capitalizeFirstLetter(
          convertTemplateTypeToName(templateType)
        )} Template`}
        isTemplate
      />

      {channelDetail.type === "ebay" && templateType === "business" && (
        <Box mb={1}>
          <WarningBusiness />
        </Box>
      )}

      {!isEmpty(errorAlert) && !isNextTemplate && (
        <Box mb={2}>
          <SingleAlert
            content={
              <>
                {errorAlert.map(item => {
                  return item;
                })}
              </>
            }
            type="error"
          />
        </Box>
      )}

      <Paper>
        <Formik
          initialValues={{
            default: false,
            ...initialValues,
            showAdvance: addOrEdit === "edit"
          }}
          validateOnChange={false}
          enableReinitialize
          validationSchema={
            templateValidate[channelDetail.type]?.[templateType]
          }
          onSubmit={async values => {
            let body = convertFakeToReal({
              channelType: channelDetail.type,
              templateType,
              values
            });
            body = handleChannelSubmitData({
              channelType: channelDetail.type,
              body,
              type: templateType
            });

            const saveClose = values.saveClose;
            delete body.saveClose;
            try {
              const res =
                addOrEdit === "edit"
                  ? await putTemplates({
                      typeChannel: channelDetail.type,
                      body: { ...body, type: templateType },
                      channelID,
                      templateID
                    })
                  : await postCreateTemplates({
                      typeChannel: channelDetail.type,
                      body: { ...body, type: templateType },
                      channelID
                    });

              if (res && !res.message) {
                if (isFirstSetup) {
                  return handleAddTemplateSuccess();
                }
                enqueueSnackbar("Success", {
                  variant: "success"
                });
                setErrorAlert([]);
                if (saveClose) {
                  cancelClick();
                }
                await wait(15000);
                dispatch(
                  setToolTipRunningProcess(
                    "Click here to see current running processes"
                  )
                );
              } else {
                throw new Error("Error");
              }
            } catch (e) {
              values.saveClose = false;
              console.log("error", e);
              enqueueSnackbar(
                alertError(messageError(e, "Save template fail")),
                {
                  variant: "error"
                }
              );
            }
          }}
        >
          <View
            cancelClick={cancelClick}
            channelDetail={channelDetail}
            templateType={templateType}
            channelID={channelID}
            addOrEdit={addOrEdit}
            store={store}
            templateID={templateID}
            isFirstSetup={isFirstSetup}
            step={step}
          />
        </Formik>
      </Paper>
    </>
  );
}
