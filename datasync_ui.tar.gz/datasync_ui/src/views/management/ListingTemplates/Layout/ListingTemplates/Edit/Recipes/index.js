import { Box, Grid, Typography, TextField, MenuItem } from "@material-ui/core";
import React, { useEffect } from "react";
import Link from "src/components/MUI/Link";
import { fetchListTemplates } from "src/actions/templates";
import { useDispatch, useSelector } from "react-redux";
import { actionFetchChannelTemplateTitle } from "src/actions/listingActions";
import LoadingScreen from "src/components/Loading/LoadingScreen";
import { isEmpty } from "lodash";
import { Field } from "formik";
import { TextField as TextFieldFormik } from "formik-material-ui";
import useTemplateRoute from "src/hooks/Template/useTemplateRoute";
import TemplateTitle from "src/components/Layout/TemplateTitle";

// const useStyles = makeStyles((theme) => ({
//   root: {
//     "& strong": {
//       color: "#ba000d",
//     },
//     "& a": {
//       color: "#4DA9FF",
//       textDecoration: "none",
//     },
//   },
// avatar: {
//   marginRight: theme.spacing(1),
// },
// list: {
//   width: "100%",
//   maxWidth: "100%",
//   backgroundColor: theme.palette.background.paper,
//   position: "relative",
//   overflow: "auto",
//   maxHeight: 200,
// },
// listSection: {
//   backgroundColor: "inherit",
// },
// ul: {
//   backgroundColor: "inherit",
//   padding: 0,
// },
// }));

// const listItems = [
//   { id: 1, name: "text" },
//   { id: 2, name: "text" },
//   { id: 3, name: "text" },
// ];

export default function Recipes({
  channelID,
  values,
  handleChange,
  // errors,
  // touched,
  channelDetail
}) {
  // const classes = useStyles();
  const { addRoute } = useTemplateRoute();
  const dispatch = useDispatch();
  const templatesTitle = useSelector(
    state => state.listing.channelTemplateTitlesArray
  );
  const { listTemplates } = useSelector(state => state.templates);

  const channel = useSelector(state => state.listing.listings);
  const channelSetting = channel.find(
    // eslint-disable-next-line
    channelItem => channelItem.id == channelID
  );

  const isAmazonGTINExemption =
    channelDetail?.type === "amazon" &&
    channelSetting?.support_amazon_gtin_exemption;

  const listTemplate = () => {
    if (!isAmazonGTINExemption) {
      return templatesTitle.filter(item => item?.type !== "amz_product_type");
    }
    return templatesTitle;
  };
  useEffect(() => {
    if (channelDetail.type) {
      dispatch(fetchListTemplates({ type: channelDetail.type, id: channelID }));
    }
  }, [channelDetail.type, channelID, dispatch]);

  useEffect(() => {
    if (channelDetail.type) {
      dispatch(
        actionFetchChannelTemplateTitle({
          channelType: channelDetail.type,
          realData: true
        })
      );
    }
  }, [channelDetail.type, dispatch]);

  if (isEmpty(listTemplates)) {
    return <LoadingScreen />;
  }

  return (
    <Box mt={2}>
      <TemplateTitle title="1. Select the templates to use in this recipe">
        {/* Category Template */}
        {listTemplate()?.map(item => {
          if (item.type === "recipes" || !listTemplates[item.type]) {
            return null;
          }
          return (
            <Grid
              key={item.type}
              container
              justify="flex-start"
              alignItems="center"
              spacing={3}
            >
              <Grid item xs={3}>
                <Typography align="right" variant="h6">
                  {item.title}
                </Typography>
              </Grid>
              <Grid item xs={4}>
                <TextField
                  fullWidth
                  select
                  variant="outlined"
                  size="small"
                  value={values?.template?.[item.type]}
                  placeholder="Please Select"
                  label={
                    values?.template?.[item.type] !== "" ? "" : "Please Select"
                  }
                  onChange={handleChange}
                  name={"template." + item.type}
                >
                  {listTemplates[item.type]?.map(option => (
                    <MenuItem key={option.id} value={option.id}>
                      <Typography variant="body2">{option.name}</Typography>
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={5}>
                <Typography variant="body2">
                  <Link
                    to={addRoute({
                      channelId: channelDetail.id,
                      templateType: item.type
                    })}
                  >
                    + Add New {item.title}
                  </Link>
                </Typography>
              </Grid>
            </Grid>
          );
        })}
      </TemplateTitle>

      {/*{ !["facebook", "google"].includes(channelDetail.type) &&*/}
      {/*  <Container title="2. Assign this recipe to product categories (optional)">*/}
      {/*    <Box ml={ 5 } display="flex">*/}
      {/*      <Grid container justify="flex-start" alignItems="center" spacing={ 3 }>*/}
      {/*        <Grid item xs={ 8 }>*/}
      {/*          <Typography>*/}
      {/*            This recipe will be automatically applied when building listings*/}
      {/*            for products in these categories.*/}
      {/*          </Typography>*/}
      {/*        </Grid>*/}
      {/*        <Grid item xs={ 4 }>*/}
      {/*          <Typography variant="body1">*/}
      {/*            <Link href="/settings/product_categories">*/}
      {/*              + Add New Product Category*/}
      {/*            </Link>*/}
      {/*          </Typography>*/}
      {/*        </Grid>*/}
      {/*      </Grid>*/}
      {/*    </Box>*/}
      {/*    <Box width="80%" m={ 4 } border="1px solid" display="flex">*/}
      {/*      <List className={ classes.list } subheader={ <li/> }>*/}
      {/*        { listItems?.map(( item, key ) => {*/}
      {/*          return (*/}
      {/*            <li key={ key } className={ classes.listSection }>*/}
      {/*              <ul className={ classes.ul }>*/}
      {/*                <ListItem key={ item.id }>*/}
      {/*                  <ListItemText*/}
      {/*                    primary={*/}
      {/*                      <FormControlLabel*/}
      {/*                        control={*/}
      {/*                          <Checkbox name="checkedB" color="primary"/>*/}
      {/*                        }*/}
      {/*                        label={ item.name }*/}
      {/*                      />*/}
      {/*                    }*/}
      {/*                  />*/}
      {/*                </ListItem>*/}
      {/*              </ul>*/}
      {/*            </li>*/}
      {/*          );*/}
      {/*        }) }*/}
      {/*      </List>*/}
      {/*    </Box>*/}
      {/*  </Container>*/}
      {/*}*/}
      {/*<Divider />*/}

      <TemplateTitle
        title={
          // (["facebook", "google"].includes(channelDetail.type) ? "2" : "3") +
          "2. Give the recipe a descriptive name"
        }
      >
        <Grid container justify="flex-start" alignItems="center" spacing={3}>
          <Grid item xs={3}>
            <Box display="flex" justifyContent="flex-end">
              <Typography align="right" variant="h6">
                Name
              </Typography>
              <strong style={{ color: "red" }}>*</strong>
            </Box>
          </Grid>
          <Grid item xs={9}>
            <Box width="75%">
              <Field
                size="small"
                fullWidth
                component={TextFieldFormik}
                variant="outlined"
                name={"name"}
              />
            </Box>
          </Grid>
        </Grid>
      </TemplateTitle>
    </Box>
  );
}
