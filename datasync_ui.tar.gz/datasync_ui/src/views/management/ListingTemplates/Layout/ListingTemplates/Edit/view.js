import { Box, Divider } from "@material-ui/core";
import { Form, useFormikContext } from "formik";
import React, { useMemo } from "react";
import Button from "src/components/MUI/Button";
import AdvanceOption from "src/components/Template/Etsy/Category/Advance/AdvanceOption";
import FormInfoGroup from "src/components/Template/FormInfoGroup";
import { channelHasAdvance } from "src/utils/template";
import Channel from "./Channel";
import Footer from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Components/Footer";
import Recipes from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Recipes";

export default function View({
  cancelClick,
  channelDetail,
  templateType,
  channelID,
  addOrEdit,
  templateID,
  store,
  isFirstSetup,
  step
}) {
  const {
    values,
    errors,
    touched,
    handleChange,
    setValues,
    handleBlur,
    isSubmitting
  } = useFormikContext();

  const renderBody = ({ type, addOrEdit, ...values }) => {
    if (templateType === "recipes") {
      return (
        <Recipes
          {...values}
          channelID={channelID}
          channelDetail={channelDetail}
        />
      );
    }

    return (
      <Channel
        type={type}
        store={store}
        addOrEdit={addOrEdit}
        templateType={templateType}
        channelID={channelID}
        channelType={channelDetail.type}
        {...values}
      />
    );
  };

  const hasAdvance = useMemo(() => {
    return !!channelHasAdvance[channelDetail.type]?.includes(templateType);
  }, [channelDetail.type, templateType]);

  return (
    <Form>
      <FormInfoGroup
        channelType={channelDetail.type}
        channelName={channelDetail.name}
        templateType={templateType}
        hasAdvance={hasAdvance}
        step={step}
      />
      <Box>
        {renderBody({
          type: channelDetail.type,
          values,
          handleChange,
          errors,
          touched,
          setValues,
          handleBlur,
          addOrEdit
        })}
      </Box>

      {!isFirstSetup && (
        <Footer
          addOrEdit={addOrEdit}
          templateType={templateType}
          cancelClick={cancelClick}
          templateID={templateID}
          channelID={channelID}
          hasAdvance={hasAdvance}
        />
      )}

      {isFirstSetup && (
        <Box>
          {hasAdvance && (
            <Box>
              <Divider />
              <Box display="flex" flexDirection="row-reverse" p={2} mb={2}>
                <AdvanceOption />
              </Box>
            </Box>
          )}

          <Box display="flex" justifyContent="flex-end" mx={2} pb={1}>
            <button
              type="submit"
              disabled
              style={{ display: "none" }}
              aria-hidden="true"
            ></button>
            <Button
              color="primary"
              text="Next"
              type="submit"
              disabled={isSubmitting}
            />
          </Box>
        </Box>
      )}
    </Form>
  );
}
