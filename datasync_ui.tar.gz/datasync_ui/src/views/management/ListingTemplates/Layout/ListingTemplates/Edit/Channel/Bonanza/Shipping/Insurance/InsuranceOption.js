import React from "react";
import { Grid, Typography } from "@material-ui/core";
import FastFieldRadioGroup from "src/components/MUI/Formik/Radio";
import { IncludedInShippingHandling } from "src/constants/Listing/Bonanza/index";

const options = [
  {
    value: IncludedInShippingHandling,
    name: "Included In Shipping Handling"
  },
  { value: "Optional", name: "Optional" },
  { value: "Required", name: "Required" }
];

const names = {
  insurance: {
    option: "insurance_type"
  }
};

const InsuranceOption = ({ name = names, isEditListing, disabled }) => {
  return (
    <Grid container spacing={2} alignItems="flex-start">
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Options
        </Typography>
      </Grid>
      <Grid item xs={9}>
        <FastFieldRadioGroup
          options={options}
          disabled={disabled}
          name={name.insurance.option}
          isVertical
        />
      </Grid>
    </Grid>
  );
};

export default InsuranceOption;
