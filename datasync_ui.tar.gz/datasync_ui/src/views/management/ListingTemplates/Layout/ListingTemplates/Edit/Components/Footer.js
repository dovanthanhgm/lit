import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Divider
} from "@material-ui/core";
import { useFormikContext } from "formik";
import { useSnackbar } from "notistack";
import React, { useState } from "react";
import Header from "src/components/Header";
import ButtonCustom from "src/components/MUI/Button";
import AdvanceOption from "src/components/Template/Etsy/Category/Advance/AdvanceOption";
import { assignRecipesTemplates } from "src/services/templates";

export default function Footer({
  cancelClick,
  templateType,
  addOrEdit,
  templateID,
  channelID,
  hasAdvance
}) {
  const [open, setOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const { values, isSubmitting, handleSubmit, setValues } = useFormikContext();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleAssignTemplates = async () => {
    const body = {
      template_id: templateID
    };
    const res = await assignRecipesTemplates({ channel_id: channelID, body });
    if (res && res.status < 400) {
      enqueueSnackbar("Success", {
        variant: "success"
      });
    } else {
      enqueueSnackbar("Oop!", {
        variant: "error"
      });
    }
    handleClose();
  };

  const saveClose = () => {
    setValues({
      ...values,
      saveClose: true
    });
    handleSubmit();
  };

  return (
    <>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>ASSIGN ALL PRODUCTS</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Do you want to assign all products?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <ButtonCustom
            text="Yes"
            variant="contained"
            onClick={handleAssignTemplates}
            color="primary"
          />
          <Button
            variant="contained"
            onClick={handleClose}
            color="primary"
            size="small"
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      {hasAdvance && (
        <Box>
          <Divider />
          <Box display="flex" flexDirection="row-reverse" p={2} mb={2}>
            <AdvanceOption />
          </Box>
        </Box>
      )}

      <Box display="flex" justifyContent="flex-end" mx={2} pb={1}>
        {addOrEdit === "edit" && templateType === "recipes" && false && (
          <Box>
            {/*anh Nam bao không tìm thấy cái button này nên bỏ đi*/}
            <Button
              onClick={handleClickOpen}
              color="primary"
              size="small"
              variant="contained"
            >
              assign all
            </Button>
          </Box>
        )}
        <Box>
          {/*prevent enter*/}
          <button
            type="submit"
            disabled
            style={{ display: "none" }}
            aria-hidden="true"
          ></button>
          <Header
            groupButton={
              addOrEdit === "edit"
                ? [
                    { name: "Cancel", onClick: cancelClick },
                    {
                      name: "Save",
                      type: "submit",
                      disabled: isSubmitting && !values.saveClose,
                      notShowCircle: isSubmitting && !values.saveClose
                    },
                    {
                      name: "Save & Close",
                      onClick: saveClose,
                      disabled: isSubmitting && values.saveClose,
                      notShowCircle: isSubmitting && !values.saveClose
                    }
                  ]
                : [
                    { name: "Cancel", onClick: cancelClick },
                    {
                      name: "Save",
                      onClick: saveClose,
                      disabled: isSubmitting && values.saveClose,
                      notShowCircle: isSubmitting && !values.saveClose
                    }
                  ]
            }
          />
        </Box>
      </Box>
    </>
  );
}
