import React, { useState } from "react";

export const CategoryRuleContext = React.createContext({
  rules: {},
  setRules: function() {},
  loadingRule: false,
  setLoadingRules: function() {}
});

const CategoryRuleProvider = ({ children }) => {
  const [rules, setRules] = useState({});
  const [loadingRule, setLoadingRules] = useState(false);

  return (
    <CategoryRuleContext.Provider
      value={{
        rules,
        setRules,
        loadingRule,
        setLoadingRules
      }}
    >
      {children}
    </CategoryRuleContext.Provider>
  );
};

export default CategoryRuleProvider;
