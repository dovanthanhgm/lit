import React from "react";
import { Grid, Typography } from "@material-ui/core";
import InternationalFreeOptionList from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/FreeOption/FreeOptionList";

const InternationalFreeOptions = ({
  isEditListing = false,
  name,
  disabled
}) => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Calculated Options Attributes
        </Typography>
      </Grid>
      <Grid item xs={isEditListing ? 8 : 9} lg={7}>
        <InternationalFreeOptionList name={name} disabled={disabled} />
      </Grid>
    </Grid>
  );
};

export default InternationalFreeOptions;
