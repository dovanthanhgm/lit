import React from "react";
import { Grid, Typography } from "@material-ui/core";
import CustomAddItem from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/CalculatedShip/CustomAddItem";

const CalculatedOptionsAttributes = ({
  name,
  isEditListing = false,
  disabled
}) => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Calculated Options Attributes
        </Typography>
      </Grid>
      <Grid item xs={isEditListing ? 8 : 9} lg={7}>
        <CustomAddItem name={name?.rootName} disabled={disabled} />
      </Grid>
    </Grid>
  );
};

export default CalculatedOptionsAttributes;
