import React from "react";
import ShipmentType from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/ShipmentType";
import { useField } from "formik";
import {
  BONANZA_CALCULATED,
  BONANZA_FIXED,
  bonanzaShipmentName
} from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/constants";
import CalculatedShipment from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/CalculatedShip/index";
import BonanzaFixedShipment from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/FixedShip/index";
import { Box } from "@material-ui/core";

const DomesticShippingComponent = ({
  shipType,
  name,
  isEditListing,
  disabled
}) => {
  return (
    <React.Fragment>
      {shipType === BONANZA_CALCULATED && (
        <CalculatedShipment
          name={name}
          isEditListing={isEditListing}
          disabled={disabled}
        />
      )}
      {shipType === BONANZA_FIXED && (
        <BonanzaFixedShipment
          name={name}
          isEditListing={isEditListing}
          disabled={disabled}
        />
      )}
    </React.Fragment>
  );
};

const MemoDomesticShipping = React.memo(DomesticShippingComponent);

const BonanzaDomesticShipping = ({ name, isEditListing = false, disabled }) => {
  const [{ value: shipType }] = useField(bonanzaShipmentName(name?.rootName));

  return (
    <React.Fragment>
      <ShipmentType
        rootName={name?.rootName}
        isEditListing={isEditListing}
        disabled={disabled}
      />
      <Box my={0.5} />
      <MemoDomesticShipping
        shipType={shipType}
        name={name}
        disabled={disabled}
        isEditListing={isEditListing}
      />
    </React.Fragment>
  );
};

export default BonanzaDomesticShipping;
