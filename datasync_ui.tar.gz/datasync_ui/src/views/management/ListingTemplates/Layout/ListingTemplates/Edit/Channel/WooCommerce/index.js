import React from "react";
import WooCommerceTitleTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/WooCommerce/TitleTemplate";
import WoocommercePriceTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/WooCommerce/PriceTemplate";
import BigCategory from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/BigCommerce/Category";

const WooCommerceTemplate = ({ templateType }) => {
  const mapData = {
    price: <WoocommercePriceTemplate />,
    title: <WooCommerceTitleTemplate />,
    category: <BigCategory channelType={"woocommerce"} />
  };
  if (mapData[templateType]) {
    return mapData[templateType];
  }

  return "developing...";
};

export default WooCommerceTemplate;
