import React from "react";
import { Grid, Typography } from "@material-ui/core";
import FormikDropDown from "src/components/MUI/Formik/FormikDropDown";
import { bonanzaShipmentPackage } from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/constants";

const listPackage = [
  { name: "Unspecified", value: "Unspecified" },
  { name: "Large envelope", value: "Large envelope" },
  { name: "Normal package", value: "Normal package" },
  { name: "Large package", value: "Large package" },
  { name: "Very large package", value: "Very large package" },
  {
    name: "USPS Priority Mail Small Flat Rate Box",
    value: "USPS Priority Mail Small Flat Rate Box"
  },
  {
    name: "USPS Priority Mail Medium Flat Rate Box",
    value: "USPS Priority Mail Medium Flat Rate Box"
  },
  {
    name: "USPS Priority Mail Large Flat Rate Box",
    value: "USPS Priority Mail Large Flat Rate Box"
  },
  {
    name: "USPS Priority Mail Flat Rate Envelope",
    value: "USPS Priority Mail Flat Rate Envelope"
  },
  {
    name: "USPS Priority Mail Padded Flat Rate Envelope",
    value: "USPS Priority Mail Padded Flat Rate Envelope"
  },
  {
    name: "USPS Priority Mail Legal Flat Rate Envelope",
    value: "USPS Priority Mail Legal Flat Rate Envelope"
  }
];

const ShipmentPackage = ({ name, isEditListing = false, disabled }) => {
  return (
    <>
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align={"right"}>
          Shipment Package
        </Typography>
      </Grid>
      <Grid item xs={7}>
        <FormikDropDown
          name={bonanzaShipmentPackage(name?.rootName)}
          listItem={listPackage}
          disabled={disabled}
          customLabelDefault={"Please Select Shipment Package"}
        />
      </Grid>
      <Grid item xs={isEditListing ? 2 : 3} />
    </>
  );
};

export default ShipmentPackage;
