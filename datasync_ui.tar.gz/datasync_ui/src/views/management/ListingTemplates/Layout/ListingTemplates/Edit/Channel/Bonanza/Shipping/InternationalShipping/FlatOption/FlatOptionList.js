import React from "react";
import { makeStyles } from "@material-ui/styles";
import { FieldArray, useField } from "formik";
import {
  bonanzaInternationalShipmentFlatOption,
  SHIP_TO_LOCATION
} from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/constants";
import {
  Box,
  Grid,
  IconButton,
  Link,
  Paper,
  Typography
} from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import FormikDropDown from "src/components/MUI/Formik/FormikDropDown";
import TextFieldNumber from "src/components/MUI/Formik/Number";

const useStyles = makeStyles(theme => ({
  iconClose: {
    position: "absolute",
    right: 0,
    top: 0
  },
  boxStyle: {
    position: "relative"
  },
  paperStyle: {
    padding: theme.spacing(1)
  }
}));

const FlatOptionList = ({ name, disabled }) => {
  const classes = useStyles();
  const names = bonanzaInternationalShipmentFlatOption(name);
  const [{ value: listOption }] = useField(names);

  return (
    <Paper variant="outlined" className={classes.paperStyle}>
      <FieldArray
        name={names}
        render={arrayHelpers => (
          <Grid container spacing={2}>
            {listOption.map((option, index) => {
              return (
                <Grid item xs={12} key={index}>
                  <Box
                    p={2}
                    className={classes.boxStyle}
                    bgcolor="background.dark"
                  >
                    <IconButton
                      size="small"
                      onClick={() => arrayHelpers.remove(index)}
                      className={classes.iconClose}
                    >
                      <CloseIcon />
                    </IconButton>
                    <Grid container alignItems="center" spacing={1}>
                      <Grid item xs={2}>
                        <Typography variant="h6" align="right">
                          Ship To Location
                        </Typography>
                      </Grid>
                      <Grid item xs={9}>
                        <FormikDropDown
                          disabled={disabled}
                          name={`${names}.${index}.ship_to_location`}
                          listItem={SHIP_TO_LOCATION}
                        />
                      </Grid>
                      <Grid item xs={2}>
                        <Typography variant="h6" align="right">
                          Shipping Service Cost
                          <span style={{ color: "red" }}>*</span>
                        </Typography>
                      </Grid>
                      <Grid item xs={9}>
                        <TextFieldNumber
                          disabled={disabled}
                          name={`${names}.${index}.shipping_service_cost`}
                        />
                      </Grid>
                    </Grid>
                  </Box>
                </Grid>
              );
            })}
            {!disabled && (
              <Grid item xs={12}>
                <Typography variant="body2">
                  <Link
                    style={{ cursor: "pointer" }}
                    onClick={() =>
                      arrayHelpers.push({
                        shipment_type: "Fixed",
                        ship_to_location: "",
                        shipping_service_cost: 0.0
                      })
                    }
                  >
                    Add options
                  </Link>
                </Typography>
              </Grid>
            )}
          </Grid>
        )}
      />
    </Paper>
  );
};

export default FlatOptionList;
