import React from "react";
import BonanzaShippingTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping";
import BonanzaCategoryTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Category";
import BonanzaPolicyTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Policy";
import PriceTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/wish/Price";
import Title from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Etsy/Title";

const BonanzaTemplate = ({ templateType, ...props }) => {
  const mapData = {
    price: <PriceTemplate />,
    title: <Title channelType={"bonanza"} />,
    shipping: <BonanzaShippingTemplate {...props} />,
    category: <BonanzaCategoryTemplate {...props} />,
    policy: <BonanzaPolicyTemplate />
  };

  if (mapData[templateType]) {
    return mapData[templateType];
  }

  return "developing...";
};

export default BonanzaTemplate;
