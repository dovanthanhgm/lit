import React, { useEffect, useMemo } from "react";
import { Grid, Paper, Tab, Tabs, Typography } from "@material-ui/core";
import { useField } from "formik";

const initArrayKey = value => {
  return Object.keys(value).filter(item => item !== "status");
};

const findOptions = (value = {}) => option => {
  return value[option]?.length > 0;
};

export const bonanzaCalculatedValue = "Calculated";
export const bonanzaFixedValue = "Fixed";
export const bonanzaFreeValue = "Free";
export const bonanzaDescriptionValue = "SeeDescription";

const typeInit = {
  flat_options_attributes: bonanzaFixedValue,
  calculated_options_attributes: bonanzaCalculatedValue,
  free_options_attributes: bonanzaFreeValue,
  description_options_attributes: bonanzaDescriptionValue
};

const shipmentType = [
  { name: "Calculated", value: bonanzaCalculatedValue },
  { name: "Fixed", value: bonanzaFixedValue },
  { name: "Free", value: bonanzaFreeValue },
  { name: "See Description", value: bonanzaDescriptionValue }
];

const InternationalTypeSelect = ({
  isEditListing = false,
  setType,
  type,
  name = "international_shipping",
  disabled
}) => {
  const [{ value }] = useField(name);

  const findInit = useMemo(() => {
    if (!value || Array.isArray(value)) return "";
    const result = initArrayKey(value).find(findOptions(value));
    if (!result) return bonanzaCalculatedValue;
    return typeInit?.[result] || bonanzaCalculatedValue;
    // eslint-disable-next-line
  }, []);

  const handleChange = (event, newValue) => {
    setType(newValue);
  };

  useEffect(() => {
    setType(findInit);
    // eslint-disable-next-line
  }, [findInit]);

  return (
    <Grid container spacing={2} alignItems="center">
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Shipment Type
        </Typography>
      </Grid>
      <Grid item xs={isEditListing ? 8 : 9} lg={7}>
        <Paper square>
          <Tabs
            value={type}
            onChange={handleChange}
            variant="fullWidth"
            indicatorColor="secondary"
          >
            {shipmentType.map(item => {
              return (
                <Tab
                  disabled={disabled}
                  label={<Typography variant="h6">{item.name}</Typography>}
                  value={item.value}
                />
              );
            })}
          </Tabs>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default InternationalTypeSelect;
