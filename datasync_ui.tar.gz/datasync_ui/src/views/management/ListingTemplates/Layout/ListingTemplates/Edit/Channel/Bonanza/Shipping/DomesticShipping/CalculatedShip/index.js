import React from "react";
import { Box, Grid } from "@material-ui/core";
import ShipmentPackage from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/CalculatedShip/ShipmentPackage";
import CalculatedOptionsAttributes from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/CalculatedShip/CalculatedOptionsAttributes";
import UnspecifiedOption from "src/views/management/ListingEditProduct/ListingChannel/Bonanza/Product/ProductTabs/Shipping/UnspecifiedOption";
import PackageWeight from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/DomesticShipping/CalculatedShip/PackageWeight";

const CalculatedShipment = ({ name, isEditListing, disabled }) => {
  return (
    <React.Fragment>
      <Grid container spacing={2} alignItems="center">
        <ShipmentPackage
          name={name}
          isEditListing={isEditListing}
          disabled={disabled}
        />
      </Grid>
      <Grid container spacing={2} alignItems="center">
        <PackageWeight
          names={name}
          isEditListing={isEditListing}
          disabled={disabled}
        />
      </Grid>
      <Box my={1} />
      <Grid container spacing={2} alignItems="flex-start">
        <UnspecifiedOption
          name={name}
          isEditListing={isEditListing}
          disabled={disabled}
        />
      </Grid>

      <Box my={1} />
      <CalculatedOptionsAttributes
        isEditListing={isEditListing}
        name={name}
        disabled={disabled}
      />
    </React.Fragment>
  );
};

export default CalculatedShipment;
