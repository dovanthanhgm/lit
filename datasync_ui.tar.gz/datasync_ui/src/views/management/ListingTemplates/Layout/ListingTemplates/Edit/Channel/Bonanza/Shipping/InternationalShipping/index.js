import React from "react";
import InternationalShippingStatus from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/InternationalShippingStatus";
import InternationalShippingOption from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/InternationalShippingOption";

const BonanzaInternationalShipping = ({
  name,
  isEditListing = false,
  disabled
}) => {
  return (
    <>
      <InternationalShippingStatus
        name={name?.status}
        isEditListing={isEditListing}
        disabled={disabled}
      />
      <InternationalShippingOption
        isEditListing={isEditListing}
        name={name}
        disabled={disabled}
      />
    </>
  );
};

export default BonanzaInternationalShipping;
