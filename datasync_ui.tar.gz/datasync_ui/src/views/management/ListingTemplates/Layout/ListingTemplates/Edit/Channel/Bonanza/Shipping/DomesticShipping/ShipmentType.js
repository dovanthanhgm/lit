import React from "react";
import { Grid, Typography } from "@material-ui/core";
import FormikDropDown from "src/components/MUI/Formik/FormikDropDown";
import { bonanzaShipmentName } from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/constants";
import ErrorMessageFormik from "src/components/MUI/Formik/ErrorMessageFormik";

const shipmentType = [
  { name: "Calculated", value: "Calculated" },
  { name: "Fixed", value: "Fixed" }
  // { name: "Free", value: "Free" },
  // { name: "See Description", value: "SeeDescription" }
];

const ShipmentType = ({ rootName = "", isEditListing = false, disabled }) => {
  return (
    <Grid container spacing={2} alignItems="center">
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align={"right"}>
          Shipment Type
        </Typography>
      </Grid>
      <Grid item xs={7}>
        <FormikDropDown
          listItem={shipmentType}
          disabled={disabled}
          name={bonanzaShipmentName(rootName)}
          customLabelDefault={"Please Select Shipment Type"}
        />
        <ErrorMessageFormik name={bonanzaShipmentName(rootName)} />
      </Grid>
      <Grid item xs={isEditListing ? 2 : 3} />
    </Grid>
  );
};

export default ShipmentType;
