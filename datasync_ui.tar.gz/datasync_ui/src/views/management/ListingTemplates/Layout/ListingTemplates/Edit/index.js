import { Container } from "@material-ui/core";
import { isEmpty } from "lodash";
import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import { actionFetchChannelDetail } from "src/actions/listingActions";
import LoadingScreen from "src/components/Loading/LoadingScreen";
import Page from "src/components/Page";
import { getTemplateDetail } from "src/services/templates";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";
import AIOBar from "src/views/AIOBar";
import FormAddEditTemplate from "./form";
import { useInitValue } from "src/hooks/Template";
import UseStore from "src/hooks/Template/useStore";
import { showAio } from "src/constants/index";
import { withAccessTemplateRecipes } from "src/hooks/hocs";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

function AddNewCategory() {
  const history = useHistory();
  const dispatch = useDispatch();
  const {
    templateType,
    channel_id: channelID,
    template_id: templateID
  } = useParams();

  const [templateDetail, setTemplateDetail] = useState({});
  const addOrEdit = templateID ? "edit" : "add";
  const channelDetail = useSelector(state => state.listing.channelDetail);

  const store = UseStore({
    channelId: channelID,
    channelType: channelDetail.type
  });

  useEffect(() => {
    if (
      channelDetail.type &&
      addOrEdit === "edit" &&
      channelDetail.id.toString() === channelID
    ) {
      async function fetchData() {
        try {
          const data = await getTemplateDetail({
            typeChannel: channelDetail.type,
            channelID,
            templateID
          });
          data && setTemplateDetail(data);
        } catch (e) {
          if (e.response?.status === 404) {
            history.push("/404");
          }
        }
      }

      fetchData();
    }
    // eslint-disable-next-line
  }, [
    channelDetail.type,
    addOrEdit,
    channelID,
    templateID,
    channelDetail.id
    // history,
  ]);

  useEffect(() => {
    dispatch(actionFetchChannelDetail({ channelID }));
  }, [channelID, dispatch]);

  const initialValues = useInitValue({
    channelType: channelDetail.type,
    templateType,
    addOrEdit,
    templateDetail
  });

  const isLoading = useMemo(() => {
    return (
      !initialValues ||
      isEmpty(channelDetail) ||
      (addOrEdit === "edit" && isEmpty(templateDetail))
    );
  }, [addOrEdit, channelDetail, initialValues, templateDetail]);

  if (isLoading) {
    return <LoadingScreen />;
  }

  const cancelClick = () => {
    return history.push("/settings/templates");
  };

  return (
    <Page title={`${capitalizeFirstLetter(addOrEdit)} Templates`}>
      <ErrorBoundaryComponent>
        <Container maxWidth={false}>
          <FormAddEditTemplate
            addOrEdit={addOrEdit}
            templateID={templateID}
            channelID={channelID}
            channelDetail={channelDetail}
            templateType={templateType}
            initialValues={initialValues}
            cancelClick={cancelClick}
            store={store}
          />
        </Container>
      </ErrorBoundaryComponent>
      {showAio && <AIOBar />}
    </Page>
  );
}

export default withAccessTemplateRecipes(AddNewCategory);
