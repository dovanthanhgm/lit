import React from "react";
import { Grid, Typography } from "@material-ui/core";
import DescriptionOptionList from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/InternationalShipping/DescriptionOption/DescriptionOptionList";

const InternationalDescriptionOptions = ({
  name,
  isEditListing = false,
  disabled
}) => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={isEditListing ? 3 : 2}>
        <Typography variant="h6" align="right">
          Description Options Attributes
        </Typography>
      </Grid>
      <Grid item xs={isEditListing ? 8 : 9} lg={7}>
        <DescriptionOptionList name={name} disabled={disabled} />
      </Grid>
    </Grid>
  );
};

export default InternationalDescriptionOptions;
