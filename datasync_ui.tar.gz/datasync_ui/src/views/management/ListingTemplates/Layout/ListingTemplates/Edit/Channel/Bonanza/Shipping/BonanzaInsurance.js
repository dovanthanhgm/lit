import React from "react";
import InsuranceOption from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/Insurance/InsuranceOption";
import InsuranceCost from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Bonanza/Shipping/Insurance/InsuranceCost";

const BonanzaInsurance = ({
  names,
  isEditListing = false,
  disabled = false
}) => {
  return (
    <div>
      <InsuranceOption
        name={names}
        isEditListing={isEditListing}
        disabled={disabled}
      />
      <InsuranceCost
        name={names}
        isEditListing={isEditListing}
        disabled={disabled}
      />
    </div>
  );
};

export default BonanzaInsurance;
