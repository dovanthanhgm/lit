import React, { useEffect } from "react";
import SelectAttribute from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Google/Category/SelectAttribute";
import { useField } from "formik";

const BonanzaMappingValue = ({ name, names, listAttribute }) => {
  const [{ value: initValue }, , { setValue: setValueMapping }] = useField(
    name
  );
  const [{ value: valueMinor }, , { setValue: setMinor }] = useField(
    names.weight_minor
  );
  const [{ value: valueMajor }, , { setValue: setMajor }] = useField(
    names.weight_major
  );

  const isMappingReset = !!valueMajor || !!valueMinor;

  useEffect(() => {
    if (isMappingReset) {
      setValueMapping("");
    }
    // eslint-disable-next-line
  }, [isMappingReset]);

  return (
    <SelectAttribute
      listAttribute={listAttribute}
      handleSetMapping={value => {
        if (![null, undefined].includes(value?.value)) {
          setValueMapping(value.value);
          setMinor(0);
          setMajor(0);
        }
      }}
      customPlaceholder={"Select Main Store Attribute"}
      initValue={initValue || ""}
    />
  );
};

export default BonanzaMappingValue;
