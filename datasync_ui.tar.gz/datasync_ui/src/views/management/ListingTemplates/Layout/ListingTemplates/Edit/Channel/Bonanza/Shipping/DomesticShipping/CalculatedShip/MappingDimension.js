import React from "react";
import SelectAttribute from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/Google/Category/SelectAttribute";
import { useField } from "formik";

const BonanzaMappingDimension = ({ name, valueName = "", listAttribute }) => {
  const [{ value: initValue }, , { setValue: setValueMapping }] = useField(
    name
  );
  const [, , { setValue: setDimensionMapping }] = useField(valueName);

  return (
    <SelectAttribute
      listAttribute={listAttribute}
      handleSetMapping={value => {
        if (![null, undefined].includes(value?.value)) {
          setValueMapping(value.value);
          setDimensionMapping(0);
        }
      }}
      customPlaceholder={"Select Main Store Attribute"}
      initValue={initValue || ""}
    />
  );
};

export default BonanzaMappingDimension;
