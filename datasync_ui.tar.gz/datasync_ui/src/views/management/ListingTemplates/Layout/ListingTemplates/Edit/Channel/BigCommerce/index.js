import React from "react";
import BigCategory from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/BigCommerce/Category";
import BigPriceTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/BigCommerce/PriceTemplate";
import BigCommerceTitleTemplate from "src/views/management/ListingTemplates/Layout/ListingTemplates/Edit/Channel/BigCommerce/TitleTemplate";

const BigCommerceTemplate = ({ templateType, ...props }) => {
  const mapData = {
    category: <BigCategory channelType="bigcommerce" />,
    price: <BigPriceTemplate {...props} />,
    title: <BigCommerceTitleTemplate />
  };
  if (mapData[templateType]) {
    return mapData[templateType];
  }

  return "developing...";
};

export default BigCommerceTemplate;
