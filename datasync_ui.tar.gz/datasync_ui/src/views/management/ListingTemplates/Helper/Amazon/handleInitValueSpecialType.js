import {
  AmazonAgeRecommend,
  AmazonBooleanType,
  AmazonDimensionType,
  AmazonMultiSelectType,
  AmazonMultiTextType,
  AmazonNumberType,
  AmazonPriceType,
  AmazonSelectType,
  AmazonTextType
} from "src/constants/Listing/Amazon/Template";

export const AmazonInitValueByType = {
  [AmazonTextType]: "",
  [AmazonNumberType]: 0,
  [AmazonMultiTextType]: "",
  [AmazonSelectType]: "",
  [AmazonBooleanType]: "no",
  [AmazonDimensionType]: "",
  [AmazonMultiSelectType]: []
};

const handleParse = item => {
  try {
    return JSON.parse(item);
  } catch (e) {
    return item;
  }
};

const ageCheck = item => {
  return {
    ...item,
    value: !!item.value ? handleParse(item.value) : item.value,
    override: !!item.override ? handleParse(item.override) : item.override
  };
};

const booleanCheck = item => {
  return {
    ...item,
    value: !!item.value ? item.value : "no",
    override: !!item.override ? item.override : "no"
  };
};

const multiSelectCheck = item => {
  const handleParse = value => {
    try {
      return JSON.parse(value);
    } catch (e) {
      return [];
    }
  };
  return {
    ...item,
    value: !!item.value ? handleParse(item.value) : [],
    override: !!item.override ? handleParse(item.override) : []
  };
};

export const checkCaseAmazonSpecialType = {
  [AmazonAgeRecommend]: ageCheck,
  [AmazonBooleanType]: booleanCheck,
  [AmazonMultiSelectType]: multiSelectCheck,
  [AmazonPriceType]: multiSelectCheck
};

export const handleInitValueAmazonType = item => {
  if (checkCaseAmazonSpecialType?.[item?.type]) {
    return checkCaseAmazonSpecialType[item.type](item);
  }
  if (!item.override) {
    return { ...item, override: AmazonInitValueByType?.[item.type] };
  }
  return item;
};
