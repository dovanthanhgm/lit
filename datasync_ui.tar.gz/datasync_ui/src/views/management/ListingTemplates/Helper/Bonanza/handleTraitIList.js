import { handleTraitType } from "src/views/management/ListingTemplates/Helper/Bonanza/handleTraitType";

const handleName = (name = "") => {
  if (!name) return "";
  return name;
};

const specificsInit = item => {
  return { name: handleName(item.label), override: "", mapping: "", value: "" };
};
//
// const specificsLists = item => {
//   return {
//     type: handleTraitType(item?.htmlInputType),
//     itemType: item?.htmlInputType || "",
//     id: item?.id || "",
//     name: item?.label,
//     enums: item.traitValues || []
//   };
// };

// const handleSerializeData = (items = []) => {
//   return items.reduce(
//     (prev, curr) => {
//       const prevSpecifics = prev?.specifics || {};
//       const prevList = prev?.lists || {};
//       prev.specifics = {
//         ...prevSpecifics,
//         [handleName(curr.label)]: specificsInit(curr)
//       };
//       prev.lists = {
//         ...prevList,
//         [handleName(curr.label)]: specificsLists(curr)
//       };
//       return prev;
//     },
//     {
//       specifics: {},
//       lists: {}
//     }
//   );
// };

const handleSerializeDataListing = (items = []) => {
  return items.reduce((prev, curr) => {
    prev = {
      ...prev,
      [handleName(curr.label)]: {
        type: handleTraitType(curr?.htmlInputType),
        itemType: curr?.htmlInputType || "",
        id: curr?.id || "",
        labelName: curr.label,
        enums: curr.traitValues || [],
        ...specificsInit(curr)
      }
    };
    return prev;
  }, {});
};

// export const handleTraitIList = (items = []) => {
//   if (!items || !items?.length) {
//     return { specifics: {}, lists: {} };
//   }
//   return {
//     specifics: handleSerializeData(items).specifics,
//     lists: handleSerializeData(items).lists
//   };
// };

export const handleTraitIListListing = (items = []) => {
  if (!items || !items?.length) {
    return { specifics: {}, lists: {} };
  }
  return handleSerializeDataListing(items);
};

export const mergeSpecificsWithInitListing = (
  init = [],
  traitData = {},
  isClear = false
) => {
  const initValue = init.reduce((prev, curr) => {
    prev[handleName(curr.name)] = curr;
    return prev;
  }, {});

  return Object.entries(traitData).reduce((prev, curr) => {
    const dataCurr = initValue?.[handleName(curr[0])] || {
      override: "",
      mapping: ""
    };
    prev = [
      ...prev,
      {
        ...curr[1],
        override: isClear ? "" : dataCurr.override,
        mapping: isClear ? "" : dataCurr.mapping
      }
    ];
    return prev;
  }, []);
};

// const handleMergeList = (init = {}, traitItems = {}) => {
//   return Object.entries(init).reduce((prev, curr) => {
//     prev[curr[0]] = {
//       type: traitItems?.[curr[1]?.name]?.type || "",
//       itemType: traitItems?.[curr[1]?.name]?.itemType || "",
//       id: traitItems?.[curr[1]?.name]?.id || "",
//       name: traitItems?.[curr[1]?.name]?.name || curr[1]?.name,
//       enums: traitItems?.[curr[1]?.name]?.enums || []
//     };
//     return prev;
//   }, []);
// };
//
// export const mergeListSpecificsWithInit = (init = {}, traitData = {}) => {
//   return { ...traitData, ...handleMergeList(init, traitData) };
// };
