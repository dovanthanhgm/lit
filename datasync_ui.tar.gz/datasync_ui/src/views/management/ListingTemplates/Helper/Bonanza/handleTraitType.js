const INPUT_TYPE = "textfield";
const DROP_BOX = "dropdown";
const CHECKBOX_SET = "checkbox_set";

export const traitType = {
  textfield: INPUT_TYPE,
  dropdown: DROP_BOX,
  checkbox_set: CHECKBOX_SET
};

export const handleTraitType = type => {
  if (!Object.keys(traitType).includes(type)) return INPUT_TYPE;
  return traitType[type];
};
