import React, { useEffect, useRef, useState } from "react";
import Dialog from "src/components/MUI/Dialog";
import { TextField } from "@material-ui/core";
import { getTemplateDetail, postCreateTemplates } from "src/services/templates";
import { fetchListTemplates } from "src/actions/templates";
import { useDispatch } from "react-redux";
import { useSnackbar } from "notistack";
import { alertError } from "src/helper/showErrorMessage";

const CopyTemplate = ({
  handleClose,
  modalCopy,
  disabled,
  setSubmitting,
  setErrors,
  type,
  channelID
}) => {
  const { enqueueSnackbar } = useSnackbar();

  const dispatch = useDispatch();
  const modalName = modalCopy.name;
  const instance = useRef({ timer: 0 });
  const [template, setTemplate] = useState("");

  const handleChangeTemplate = event => {
    setTemplate(event.target.value);
  };

  const handleConfirm = async () => {
    try {
      setErrors(null);
      setSubmitting(true);
      const data = await getTemplateDetail({
        typeChannel: type,
        channelID,
        templateID: modalCopy.id
      });
      if (data) {
        const body = { ...data, name: template };
        await postCreateTemplates({ typeChannel: type, body, channelID });
        clearTimeout(instance.current.timer);
        instance.current.timer = setTimeout(() => {
          dispatch(fetchListTemplates({ type, id: channelID }));
        }, 500);
        enqueueSnackbar("Success", {
          variant: "success"
        });
      }
    } catch (e) {
      console.log("e", e?.response);
      const message =
        e?.response?.data?.message ||
        e?.response?.data?.errors ||
        e?.response?.data?.msg ||
        e?.response?.data?.error ||
        e?.response?.data?.message;
      setErrors(alertError(message) || "Error copy");
    }
    setSubmitting(false);
  };

  useEffect(() => {
    setTemplate(modalName + " copy");
  }, [modalName]);

  return (
    <>
      <Dialog
        open={modalCopy.open}
        handleClose={handleClose}
        content={
          <>
            <TextField
              variant="outlined"
              size="small"
              fullWidth
              name="duplicate-template"
              value={template}
              onChange={handleChangeTemplate}
            />
          </>
        }
        header="Enter copied template name"
        handleConfirm={handleConfirm}
        nameButton="Copy"
        disabled={disabled}
        fullWidth
        maxWidth="sm"
      />
    </>
  );
};

export default CopyTemplate;
