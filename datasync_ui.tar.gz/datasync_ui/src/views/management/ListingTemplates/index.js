import { Box, Card, Typography } from "@material-ui/core";
import Container from "@material-ui/core/Container";
import { makeStyles } from "@material-ui/core/styles";
import React, { useMemo, useState } from "react";
import Header from "src/components/Header";
import Page from "src/components/Page";
import AIOBar from "src/views/AIOBar";
import Menu from "./Menu";
import { useSelector } from "react-redux";
import { channelAllTemplate } from "src/constants/channelTemplate";
import SingleAlert from "src/components/Notify/SingleAlert";
import { AMAZON_PRODUCT_TYPE_NAME, showAio } from "src/constants/index";
import { withAccessTemplateRecipes } from "src/hooks/hocs";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(3)
    // paddingBottom: 100
  },
  cardStyle: {
    minHeight: 200
  }
}));

/*
 *
 * Edit template here
 *
 * */
const handleTemplate = (template, channel) => {
  if (channel.type === "amazon") {
    const setting = [true, "True", "true", 1, "1"].includes(
      channel?.support_amazon_gtin_exemption
    );
    if (setting) {
      const cloneTemplate = template.filter(
        item => item.type !== "amz_details"
      );
      return [
        ...cloneTemplate,
        {
          type: "amz_product_type",
          title: `Amazon ${AMAZON_PRODUCT_TYPE_NAME}`
        }
      ];
    }
    return template;
  }

  return template;
};

function ListingTemplate() {
  const classes = useStyles();

  const { listings, defaultListing, marketplaces } = useSelector(
    state => state?.listing
  );
  const channelAllTemplates = listings.map(item => {
    return {
      type: item.type,
      name: item.name,
      id: item.id,
      templates: handleTemplate(channelAllTemplate?.[item.type], item)
    };
  });
  const [error, setErrors] = useState(null);

  const isMainMarket = useMemo(() => {
    return marketplaces?.map(item => item.id)?.includes(defaultListing?.type);
  }, [marketplaces, defaultListing]);

  const isNoListingTemplate = useMemo(() => {
    return listings?.length === 0 && !isMainMarket;
  }, [listings, isMainMarket]);

  const mainTemplate = useMemo(() => {
    return [
      {
        type: defaultListing.type,
        name: defaultListing.name,
        id: defaultListing.id,
        templates: channelAllTemplate?.[defaultListing.type]
      }
    ];
  }, [defaultListing]);

  const renderChannelTemplate = [...mainTemplate, ...channelAllTemplates];

  return (
    <Page className={classes.root} title="Listing Template & Recipes">
      <Container maxWidth={false}>
        <Header headerName="Listing Templates & Recipes" />
        {Boolean(error) && (
          <Box mb={1}>
            <SingleAlert
              content={
                <Typography variant="body2">{error.toString()}</Typography>
              }
              type="error"
            />
          </Box>
        )}
        <Card className={classes.cardStyle}>
          {!isNoListingTemplate && (
            <Menu
              listChannel={
                isMainMarket ? renderChannelTemplate : channelAllTemplates
              }
              setErrors={setErrors}
            />
          )}
          {!!isNoListingTemplate && (
            <Box
              minHeight={200}
              width="100%"
              display="flex"
              justifyContent="center"
              alignItems="center"
              // textAlign="center"
            >
              <Typography variant="h4" color="textPrimary">
                You have no listing channel yet
              </Typography>
            </Box>
          )}
        </Card>
      </Container>
      {showAio && <AIOBar />}
    </Page>
  );
}

export default withAccessTemplateRecipes(ListingTemplate);
