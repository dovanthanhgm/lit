import React, { useEffect, useLayoutEffect } from "react";
import { Box, Tab, Tabs } from "@material-ui/core";
import ListingTemplates from "./Layout/ListingTemplates";
import { fetchListTemplates, getCurrentTab } from "src/actions/templates";
import { useDispatch } from "react-redux";
import { actionSetChannelDetail } from "src/actions/listingActions";
import TabLabelCustom from "src/components/Layout/TabLabelCustom";

export default function Layout(props) {
  const dispatch = useDispatch();

  const { id, type, templates, subTab, mainTab } = props;

  const handleChange = (_, newValue) => {
    dispatch(getCurrentTab({ mainTab: mainTab, subTab: newValue }));
  };

  useEffect(() => {
    dispatch(fetchListTemplates({ type, id }));
  }, [dispatch, id, type]);

  useLayoutEffect(() => {
    dispatch(actionSetChannelDetail({ data: {} }));
  }, [dispatch]);

  const hasRecipes = templates?.find(item => item.type === "recipes");

  return (
    <Box pl={3} pr={3}>
      <Tabs variant="fullWidth" value={subTab} onChange={handleChange}>
        <Tab
          label={<TabLabelCustom>Listing Templates</TabLabelCustom>}
          value={0}
        />
        <Tab
          label={<TabLabelCustom>Listing Recipes</TabLabelCustom>}
          value={1}
          disabled={!hasRecipes}
        />
      </Tabs>

      <Box mt={3}>
        <ListingTemplates index={subTab} {...props} />
      </Box>
    </Box>
  );
}
