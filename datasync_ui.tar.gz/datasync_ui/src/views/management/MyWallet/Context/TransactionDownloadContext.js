import React, { useState } from "react";

export const TransactionDownloadContext = React.createContext({
  product: {},
  setProduct: function() {},
  loading: false,
  setLoading: function() {},
  downloadFile: function() {},
  successGen: false,
  setSuccessGen: function() {}
});

const TransactionDownloadProvider = ({ children }) => {
  const [loading, setLoading] = useState(false);
  const [successGen, setSuccessGen] = useState(false);
  const [product, setProduct] = useState({});
  
  const downloadFile = () => {
    setProduct({});
    setSuccessGen(false);
    return document.getElementById(product?.transactionid)?.click?.();
  };

  return (
    <TransactionDownloadContext.Provider
      value={{
        product,
        setProduct,
        loading,
        setLoading,
        downloadFile,
        successGen,
        setSuccessGen
      }}
    >
      {children}
    </TransactionDownloadContext.Provider>
  );
};

export default TransactionDownloadProvider;
