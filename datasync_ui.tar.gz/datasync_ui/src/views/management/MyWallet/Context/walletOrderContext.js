import React, { useState } from "react";
import { walletOrderId } from "src/helper/WalletOrderId";

export const WalletOrderContext = React.createContext({
  product: {},
  setProduct: function() {},
  loading: false,
  setLoading: function() {},
  downloadFile: function() {},
  successGen: false,
  setSuccessGen: function() {}
});

const WalletOrderProvider = ({ children }) => {
  const [loading, setLoading] = useState(false);
  const [successGen, setSuccessGen] = useState(false);
  const [product, setProduct] = useState({});

  const downloadFile = () => {
    setProduct({});
    setSuccessGen(false);
    return document.getElementById(walletOrderId(product?.id))?.click?.();
  };

  return (
    <WalletOrderContext.Provider
      value={{
        product,
        setProduct,
        loading,
        setLoading,
        downloadFile,
        successGen,
        setSuccessGen
      }}
    >
      {children}
    </WalletOrderContext.Provider>
  );
};

export default WalletOrderProvider;
