import React, { useContext } from "react";
import { Button, TableCell } from "@material-ui/core";
import { WalletOrderContext } from "src/views/management/MyWallet/Context/walletOrderContext";

const OrderDownloadInvoiceButton = ({
  loading = false,
  transaction: order
}) => {
  const { setProduct, setLoading, loading: loadingOrder } = useContext(
    WalletOrderContext
  );

  const handleSetProduct = order => {
    setProduct(order);
  };

  const handleClickDownload = () => {
    handleSetProduct(order);
    setLoading(true);
  };

  return (
    <TableCell>
      {!loading && !["pending", "deducted"].includes(order?.status) && (
        <Button
          onClick={handleClickDownload}
          variant="contained"
          color="primary"
          size="small"
          disabled={loadingOrder}
        >
          download
        </Button>
      )}
    </TableCell>
  );
};

export default React.memo(OrderDownloadInvoiceButton);
