import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import Loading from "src/components/Loading/Loading";
import { getOrderList } from "src/services/manage";
import { useSnackbar } from "notistack";
import { convertIdToName } from "src/utils/helper";
import moment from "moment";
import { walletOrderId } from "src/helper/WalletOrderId";
import OrderDownloadInvoiceButton from "src/views/management/MyWallet/OrderListTable/DownloadInvoiceButton";

const orderTypeDisplay = {
  aio: "All in one"
};

const orderTypeText = type => {
  if (type === "aio") {
    return orderTypeDisplay[type];
  }
  return type;
};

function TranscriptionTable({ className, customers, ...rest }) {
  const { enqueueSnackbar } = useSnackbar();

  const [orderList, setOrderList] = useState([]);
  const [loading] = useState(false);
  const [page, setPage] = useState(1);
  const [orderLimit, setOrderLimit] = useState(10);
  const [count, setCount] = useState(10);

  const handlePageChange = (_, newPage) => {
    setPage(newPage + 1);
  };

  const handleLimitChange = event => {
    setOrderLimit(event.target.value);
    localStorage.setItem("orderListRowPerPage", event.target.value);
  };

  useEffect(() => {
    async function fetchOderList() {
      try {
        const data = await getOrderList({
          page: page,
          limit: localStorage.getItem("orderListRowPerPage") ?? orderLimit
        });
        if (data) {
          setOrderList(data.data);
          setCount(data?.count);
        }
      } catch (e) {
        console.log(e);
        setOrderList([]);
        enqueueSnackbar("Error", { variant: "error" });
      }
    }

    fetchOderList();
    // eslint-disable-next-line
  }, [orderLimit, page]);

  return (
    <>
      <PerfectScrollbar>
        <Box minWidth={800}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Order Id</TableCell>
                <TableCell>Order Type</TableCell>
                <TableCell>Price Total</TableCell>
                <TableCell>Note</TableCell>
                <TableCell>Created date</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {orderList?.map(order => {
                return (
                  <TableRow hover key={order.id}>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="h6">
                            {walletOrderId(order?.id)}
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="body2">
                            {orderTypeText(order?.order_type)}
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="body2">
                            {order?.total}
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>
                    <TableCell>
                      {order?.order_type === "aio" && (
                        <Box display="flex" alignItems="center">
                          <div>
                            <Typography color="textPrimary" variant="body2">
                              {convertIdToName(order?.source)}&nbsp;to&nbsp;
                              {convertIdToName(order?.target)}&nbsp;All In One
                              Integration Service
                            </Typography>
                          </div>
                        </Box>
                      )}
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="h6">
                            {order?.custom_requirements}
                          </Typography>
                        </div>
                      </Box>
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="body2">
                            {order?.description}
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>

                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="body2">
                            {moment(order?.created_at).format("LL")},&nbsp;
                            <Typography variant="body2" component="span">
                              {moment(order?.created_at).format("LTS")}
                            </Typography>
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>
                    <OrderDownloadInvoiceButton
                      loading={loading}
                      transaction={order}
                    />
                  </TableRow>
                );
              })}
            </TableBody>

            {loading && (
              <TableBody>
                <TableRow>
                  <TableCell style={{ borderBottom: "none" }}>
                    <Box p={2}>
                      <Loading />
                    </Box>
                  </TableCell>
                </TableRow>
              </TableBody>
            )}
          </Table>

          {orderList?.length === 0 && !loading && (
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              p={1}
            >
              <Typography variant="body2" color="textPrimary">
                No data
              </Typography>
            </Box>
          )}
        </Box>
      </PerfectScrollbar>
      <TablePagination
        component="div"
        count={count}
        onChangePage={handlePageChange}
        onChangeRowsPerPage={handleLimitChange}
        page={page - 1}
        rowsPerPage={
          parseInt(localStorage.getItem("orderListRowPerPage")) || 10
        }
        rowsPerPageOptions={[5, 10, 25]}
      />
    </>
  );
}

export default TranscriptionTable;
