import React, { useContext, useEffect } from "react";
import { PDFDownloadLink } from "@react-pdf/renderer";
import MyDocument from "src/views/management/MyWallet/TransactionsTable/TransactionDownload";
import { useSelector } from "react-redux";
import moment from "moment";
import { isEmpty } from "lodash";
import TransactionButtonDownload from "src/views/management/MyWallet/DownloadPdf/TransactionButtonDownload";
import { TransactionDownloadContext } from "src/views/management/MyWallet/Context/TransactionDownloadContext";

const DownloadTransaction = () => {
  const { product, successGen, downloadFile } = useContext(
    TransactionDownloadContext
  );
  const { user } = useSelector(state => state.account);
  const updateTime = transaction => {
    if (moment(transaction?.created_at).isValid()) {
      return moment(transaction?.created_at).format("YYYY-MM-DD HH:mm:ss");
    }
    return <span>&nbsp;</span>;
  };

  useEffect(() => {
    if (successGen) {
      downloadFile();
    }
    // eslint-disable-next-line
  }, [successGen]);

  return (
    <>
      {product &&
        !isEmpty(product) &&
        !["pending", "deducted"].includes(product?.status) && (
          <PDFDownloadLink
            document={
              <MyDocument
                company={user.company ?? ""}
                name={user?.name || ""}
                date={updateTime(product)}
                address={user?.address || ""}
                total={
                  product?.status === "completed"
                    ? product?.amount
                    : product?.total
                }
                vat="0109852669"
                discount={product?.discount || ""}
                noId={product?.id ?? ""}
                orderId={""}
                note={product?.name}
                orderPrice={
                  product?.status === "completed"
                    ? product?.amount
                    : product?.total
                }
                phone={user?.phone}
              />
            }
            style={{ textDecoration: "none" }}
            fileName={`invoice_${product?.transactionid || ""}`}
          >
            {({ blob, url, loading, error }) => {
              return (
                <TransactionButtonDownload
                  product={product}
                  loading={loading}
                  error={error}
                />
              );
            }}
          </PDFDownloadLink>
        )}
    </>
  );
};

export default DownloadTransaction;
