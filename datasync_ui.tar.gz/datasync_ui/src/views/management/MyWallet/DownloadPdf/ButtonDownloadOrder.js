import React, { useContext, useEffect } from "react";
import { Button } from "@material-ui/core";
import { walletOrderId } from "src/helper/WalletOrderId";
import { WalletOrderContext } from "src/views/management/MyWallet/Context/walletOrderContext";

const ButtonDownloadOrder = ({ loading = false, error = "", product }) => {
  const { setLoading, setSuccessGen } = useContext(WalletOrderContext);

  useEffect(() => {
    if (!loading && !error) {
      setSuccessGen(true);
    }
    setLoading(loading);
    // eslint-disable-next-line
  }, [loading, error]);

  return loading ? (
    "Loading document..."
  ) : (
    <Button
      variant="contained"
      size="small"
      color="primary"
      id={walletOrderId(product?.id)}
    >
      <span style={{ textDecoration: "none" }}>download</span>
    </Button>
  );
};

export default ButtonDownloadOrder;
