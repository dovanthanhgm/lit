import React, { useContext, useEffect } from "react";
import { Button } from "@material-ui/core";
import { TransactionDownloadContext } from "src/views/management/MyWallet/Context/TransactionDownloadContext";

const TransactionButtonDownload = ({
  loading = false,
  error = "",
  product
}) => {
  const { setLoading, setSuccessGen } = useContext(TransactionDownloadContext);

  useEffect(() => {
    if (!loading && !error) {
      setSuccessGen(true);
    }
    setLoading(loading);
    // eslint-disable-next-line
  }, [loading, error]);

  return loading ? (
    "Loading document..."
  ) : (
    <Button
      variant="contained"
      size="small"
      color="primary"
      id={product?.transactionid}
    >
      <span style={{ textDecoration: "none" }}>download</span>
    </Button>
  );
};

export default TransactionButtonDownload;
