import React, { useContext, useEffect } from "react";
import { PDFDownloadLink } from "@react-pdf/renderer";
import MyDocument from "src/views/management/MyWallet/TransactionsTable/TransactionDownload";
import { Box } from "@material-ui/core";
import { isEmpty } from "lodash";
import { WalletOrderContext } from "src/views/management/MyWallet/Context/walletOrderContext";
import { walletOrderId } from "src/helper/WalletOrderId";
import { useSelector } from "react-redux";
import moment from "moment";
import ButtonDownloadOrder from "src/views/management/MyWallet/DownloadPdf/ButtonDownloadOrder";

const DownloadOrder = () => {
  const { product, successGen, downloadFile } = useContext(WalletOrderContext);
  const { user } = useSelector(state => state.account);

  const updateTime = transaction => {
    if (moment(transaction?.created_at).isValid()) {
      return moment(transaction?.created_at).format("YYYY-MM-DD HH:mm:ss");
    }
    return <span>&nbsp;</span>;
  };

  const note =
    (product?.custom_requirements || "") + ". " + (product?.description || "");

  useEffect(() => {
    if (successGen) {
      downloadFile();
    }
    // eslint-disable-next-line
  }, [successGen]);

  return (
    <Box display="none">
      {product && !isEmpty(product) && (
        <PDFDownloadLink
          document={
            <MyDocument
              company={user.company ?? ""}
              name={user?.name || ""}
              date={updateTime(product)}
              address={user?.address || ""}
              total={product?.total}
              vat="0109852669"
              discount={product?.discount || ""}
              noId={walletOrderId(product?.id) ?? ""}
              orderId={""}
              note={note}
              orderPrice={product?.total}
              phone={user?.phone}
            />
          }
          style={{ textDecoration: "none" }}
          fileName={`invoice_${walletOrderId(product?.id) || ""}`}
        >
          {({ blob, url, loading, error }) => {
            return (
              <ButtonDownloadOrder
                loading={loading}
                error={error}
                product={product}
              />
            );
          }}
        </PDFDownloadLink>
      )}
    </Box>
  );
};

export default DownloadOrder;
