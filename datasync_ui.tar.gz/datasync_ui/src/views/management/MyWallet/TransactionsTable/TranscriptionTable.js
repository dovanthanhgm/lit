import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography
} from "@material-ui/core";
import moment from "moment";
import React, { useEffect, useState } from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import Label from "src/components/Label";
import Loading from "src/components/Loading/Loading";
import { getPaymentHistory } from "src/services/manage";
import { useSnackbar } from "notistack";
import DownloadInvoiceButton from "src/views/management/MyWallet/TransactionsTable/DownloadInvoiceButton";

function getTransactionStatus(status) {
  const map = {
    open: {
      text: "Open",
      color: "primary"
    },
    canceled: {
      text: "Cancelled",
      color: "error"
    },
    shipping: {
      text: "Shipping",
      color: "secondary"
    },
    ready_to_ship: {
      text: "Ready to ship",
      color: "warning"
    },
    awaiting_payment: {
      text: "Awaiting payment",
      color: "warning"
    },
    completed: {
      text: "Completed",
      color: "success"
    }
  };

  if (status in map) {
    const { text, color } = map[status];
    return <Label color={color}>{text}</Label>;
  } else {
    return <Label>{status}</Label>;
  }
}

function TranscriptionTable({ className, customers, ...rest }) {
  const { enqueueSnackbar } = useSnackbar();

  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [count, setCount] = useState(25);

  const transactionAmount = (status, id, transaction) => {
    if (status === "deducted") {
      return `-$${transaction?.total}`;
    }
    return `+$${transaction?.amount}`;
  };

  useEffect(() => {
    const getData = async () => {
      try {
        setLoading(true);
        const res = await getPaymentHistory({
          page: page,
          limit: localStorage.getItem("transactionRowPerPage") ?? limit
        });
        setCount(res.count);
        setTransactions(res.data);
        setLoading(false);
      } catch (e) {
        console.log(e);
        setTransactions([]);
        setLoading(false);
        enqueueSnackbar("Error", { variant: "error" });
      }
    };

    getData();
    // eslint-disable-next-line
  }, [limit, page]);

  const handlePageChange = (_, newPage) => {
    setPage(newPage + 1);
  };

  const handleLimitChange = event => {
    setLimit(event.target.value);
    localStorage.setItem("transactionRowPerPage", event.target.value);
  };

  return (
    <>
      <PerfectScrollbar>
        <Box minWidth={800}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Customer</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>Transaction ID</TableCell>
                <TableCell>Discount</TableCell>
                <TableCell>Method</TableCell>
                <TableCell>Create date</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions?.map(transaction => {
                return (
                  <TableRow hover key={transaction.id}>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <div>
                          <Typography color="textPrimary" variant="h6">
                            {transaction?.payer_email}
                          </Typography>
                          <Typography variant="body2" color="textSecondary">
                            {transaction?.payer_email}
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>
                    <TableCell>
                      {getTransactionStatus(transaction?.status)}
                    </TableCell>
                    <TableCell>
                      {transactionAmount(
                        transaction?.status,
                        transaction?.transactionid,
                        transaction
                      )}
                    </TableCell>
                    <TableCell>{transaction.transactionid}</TableCell>
                    <TableCell>{transaction.discount}</TableCell>
                    <TableCell>{transaction.method}</TableCell>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <div>
                          {moment(transaction.created_at).format("LL")}
                          <Typography variant="body2">
                            {moment(transaction.created_at).format("LTS")}
                          </Typography>
                        </div>
                      </Box>
                    </TableCell>
                    <DownloadInvoiceButton
                      transaction={transaction}
                      loading={loading}
                    />
                  </TableRow>
                );
              })}
            </TableBody>

            {loading && (
              <TableBody>
                <TableRow>
                  <TableCell style={{ borderBottom: "none" }}>
                    <Box p={2}>
                      <Loading />
                    </Box>
                  </TableCell>
                </TableRow>
              </TableBody>
            )}
          </Table>

          {transactions?.length === 0 && !loading && (
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              p={1}
            >
              <Typography variant="body2" color="textPrimary">
                No data
              </Typography>
            </Box>
          )}
        </Box>
      </PerfectScrollbar>
      <TablePagination
        component="div"
        count={count}
        onChangePage={handlePageChange}
        onChangeRowsPerPage={handleLimitChange}
        page={page - 1}
        rowsPerPage={
          parseInt(localStorage.getItem("transactionRowPerPage")) || 10
        }
        rowsPerPageOptions={[5, 10, 25]}
      />
    </>
  );
}

export default TranscriptionTable;
