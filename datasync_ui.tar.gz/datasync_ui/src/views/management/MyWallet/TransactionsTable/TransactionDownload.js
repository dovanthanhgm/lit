import React from "react";
import {
  Document,
  Font,
  Image,
  Link,
  Page,
  StyleSheet,
  Text,
  View
} from "@react-pdf/renderer";

import OpenSansRegular from "src/assets/font/OpenSans/OpenSans-Regular.ttf";
import OpenSansBold from "src/assets/font/OpenSans/OpenSans-Bold.ttf";
// Create styles
const styles = StyleSheet.create({
  page: {
    padding: 40,
    backgroundColor: "#FFFFFF"
  },
  invoiceHeader: {
    marginBottom: 50
  },
  section: {
    margin: 10,
    padding: 10
  },
  invoice: {
    fontSize: 40,
    fontFamily: "OpenSans"
  },
  oceanSoftText: {
    fontSize: 16,
    fontWeight: "bold",
    fontFamily: "OpenSans"
  },
  pdfContent: {
    fontSize: 14,
    margin: 6,
    fontFamily: "OpenSans",
    marginLeft: 0
  },
  ccStyle: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 70
  },
  viewStyle: {
    // justifyContent: "flex-end",
    display: "flex",
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-between",
    marginBottom: 30
    // flexDirection: 'row'
  },
  viewPage: {
    textAlign: "center"
  },
  thankText: {
    fontSize: 16,
    fontWeight: "bold",
    fontFamily: "OpenSans",
    textAlign: "center"
  },
  thankTextContent: {
    fontWeight: 600
  },
  tableContent: {
    display: "flex",
    borderBottom: "1pt solid black",
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-between"
    // border: "1px solid #EEE"
  },
  lastBottomBorder: {
    display: "flex",
    flexDirection: "row",
    width: "100%",
    justifyContent: "space-between"
  },
  tableItem: {
    display: "flex",
    flexDirection: "row",
    width: "70%",
    paddingTop: 8,
    paddingBottom: 8,
    justifyContent: "flex-end"
  },
  tableItemRight: {
    display: "flex",
    borderLeft: "1pt solid black",
    justifyContent: "flex-start",
    flexDirection: "row",
    width: "30%",
    paddingTop: 8,
    paddingBottom: 8
  },
  tableText: {
    marginLeft: 10,
    fontSize: 12,
    fontFamily: "OpenSans",
    marginRight: 10
  },
  tableTextHeader: {
    fontSize: 13,
    fontWeight: "bold",
    fontFamily: "OpenSans",
    marginLeft: 10,
    marginRight: 10
  },
  tableBorder: {
    border: "1pt solid black",
    marginBottom: 50
  },
  billTo: {
    fontSize: 16,
    fontWeight: "bold",
    fontFamily: "OpenSans"
  },
  detailInvoice: {
    marginBottom: 20
  },
  image: {
    width: 200,
    height: 46
  },
  invoiceInfo: {
    fontSize: 12,
    fontFamily: "OpenSans",
    margin: 6,
    marginLeft: 0
  }
});

Font.register({
  family: "OpenSans",
  fonts: [
    {
      src: OpenSansRegular,
      fontWeight: 400
    },
    {
      src: OpenSansBold,
      fontWeight: "bold"
    }
  ]
});

// Create Document Component
const MyDocument = ({
  name,
  date,
  vat,
  noId,
  address,
  company,
  phone,
  orderId,
  note,
  orderPrice,
  total,
  discount
}) => {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.viewStyle}>
          <Image style={styles.image} src="/static/images/logo/logoLit2.jpg" />
          <Text style={styles.invoice}>INVOICE</Text>
        </View>
        <View style={styles.ccStyle}>
          <View>
            <Text style={styles.oceanSoftText}>LitCommerce JSC</Text>
            <Text style={styles.pdfContent}>
              Add: Lilama Tower, 56 To Huu St, Hanoi, Vietnam.
            </Text>
            <Text style={styles.pdfContent}>
              Email: contact@litcommerce.com
            </Text>
            <Text style={styles.pdfContent}>
              Website:{" "}
              <Link src="https://litcommerce.com">https://litcommerce.com</Link>
            </Text>
            <Text style={styles.pdfContent}>VAT: {vat}</Text>
          </View>
          <View>
            <Text style={styles.invoiceInfo}>No: #{noId}</Text>
            <Text style={styles.invoiceInfo}>Date: {date}</Text>
          </View>
        </View>

        <View style={styles.detailInvoice}>
          <Text style={styles.billTo}>BILL TO</Text>
          <Text style={styles.pdfContent}>Name: {name || ""}</Text>
          <Text style={styles.pdfContent}>Company: {company || ""}</Text>
          <Text style={styles.pdfContent}>Address: {address || ""}</Text>
          <Text style={styles.pdfContent}>Phone: {phone || ""}</Text>
        </View>
        <View style={styles.tableBorder}>
          <View style={styles.tableContent}>
            <View style={styles.tableItem}>
              <Text style={styles.tableTextHeader}>Description</Text>
            </View>
            <View style={styles.tableItemRight}>
              <Text style={styles.tableTextHeader}>Amount</Text>
            </View>
          </View>
          <View style={styles.tableContent}>
            <View style={styles.tableItem}>
              <Text style={styles.tableText}>{note}</Text>
            </View>
            <View style={styles.tableItemRight}>
              <Text style={styles.tableText}>${orderPrice || 0}</Text>
            </View>
          </View>
          <View style={styles.tableContent}>
            <View style={styles.tableItem}>
              <Text style={styles.tableText}>Discount</Text>
            </View>
            <View style={styles.tableItemRight}>
              <Text style={styles.tableText}>${discount || 0}</Text>
            </View>
          </View>
          <View style={styles.lastBottomBorder}>
            <View style={styles.tableItem}>
              <Text style={styles.tableText}>Total</Text>
            </View>
            <View style={styles.tableItemRight}>
              <Text style={styles.tableText}>${total}</Text>
            </View>
          </View>
        </View>
        <View style={styles.thankText}>
          <Text style={styles.thankTextContent}>
            Thank You For Your Business
          </Text>
        </View>
      </Page>
    </Document>
  );
};

export default MyDocument;
