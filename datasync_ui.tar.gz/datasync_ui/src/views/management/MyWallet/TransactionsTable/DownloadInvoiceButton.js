import React, { useContext } from "react";
import { Button, TableCell } from "@material-ui/core";
import { TransactionDownloadContext } from "src/views/management/MyWallet/Context/TransactionDownloadContext";

const DownloadInvoiceButton = ({ loading = false, transaction }) => {
  const { setProduct, setLoading, loading: loadingOrder } = useContext(
    TransactionDownloadContext
  );

  const handleSetProduct = transaction => {
    setProduct(transaction);
  };

  const handleClickDownload = () => {
    handleSetProduct(transaction);
    setLoading(true);
  };

  return (
    <TableCell>
      {!loading && !["pending", "deducted"].includes(transaction?.status) && (
        <Button
          onClick={handleClickDownload}
          variant="contained"
          color="primary"
          size="small"
          disabled={loadingOrder}
        >
          download
        </Button>
      )}
    </TableCell>
  );
};

export default React.memo(DownloadInvoiceButton);
