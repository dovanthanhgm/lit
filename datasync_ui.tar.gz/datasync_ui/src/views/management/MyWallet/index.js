import {
  Box,
  Card,
  CardHeader,
  Container,
  Divider,
  makeStyles
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router";
import Header from "src/components/Header";
import Page from "src/components/Page";
import SingleAlert from "src/components/Notify/SingleAlert";
import { getPaymentHistoryId } from "src/services/manage";
// import CurrentBalance from "./CurrentBalance";
import OrderListTable from "./OrderListTable";
import TranscriptionTable from "./TransactionsTable/TranscriptionTable";
import WalletOrderProvider from "src/views/management/MyWallet/Context/walletOrderContext";
import DownloadOrder from "src/views/management/MyWallet/DownloadPdf/DownloadOrder";
import DownloadTransaction from "src/views/management/MyWallet/DownloadPdf/DownloadTransaction";
import TransactionDownloadProvider from "src/views/management/MyWallet/Context/TransactionDownloadContext";
import ErrorBoundaryComponent from "src/views/reports/CrashApp/ErrorBoundaryComponent";

const useStyles = makeStyles(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(3),
    paddingBottom: 100
  },
  textItalic: {
    fontStyle: "italic"
  },
  buttonPurchase: {
    margin: theme.spacing(2)
  },
  cardContainer: {
    marginTop: theme.spacing(3)
  }
}));

// const stateOptions = [30, 50, 100, 500, 1000];

function MyWallet() {
  const classes = useStyles();
  const location = useLocation();
  let { payment_id } = useParams();
  // const { balance } = useSelector(state => state.account.user);

  // const [purchaseValue, setPurchaseValue] = useState(stateOptions[0]);
  const [amount, setAmount] = useState(0);
  // const handleChange = e => {
  //   setPurchaseValue(e.target.value);
  // };
  //
  // const onClickPurchase = async () => {
  //   try {
  //     const api = `/api/payments/process`;
  //     const res = await axios.post(api, { amount: purchaseValue });
  //     const url = res?.data;
  //     if (url) {
  //       window.location.href = url;
  //     }
  //   } catch (e) {
  //     console.log(e);
  //   }
  // };

  useEffect(() => {
    async function fetchData() {
      const data = await getPaymentHistoryId({ payment_id });
      if (data) {
        setAmount(data.amount);
      }
    }

    payment_id && fetchData();
  }, [payment_id]);

  return (
    <Page className={classes.root} title="Billing">
      <ErrorBoundaryComponent>
        <Container maxWidth={false}>
          <Header headerName={"Billing"} />

          {location.pathname === "/billing/payment-failed" && (
            <Box my={3}>
              <SingleAlert content={`Payment Cancelled`} type={"error"} />
            </Box>
          )}

          {location.pathname === `/billing/payment-success/${payment_id}` && (
            <Box my={3}>
              <SingleAlert
                content={`Thank you! You have successfully paid ${amount} USD.`}
                type={"success"}
              />
            </Box>
          )}
          {/*<Grid item lg={3} sm={6} xs={12}>*/}
          {/*  <CurrentBalance balance={balance} />*/}
          {/*</Grid>*/}

          {/*<Card className={classes.cardContainer}>*/}
          {/*  <CardHeader title="Add Funds: One-time Purchase" />*/}
          {/*  <Divider />*/}
          {/*  <CardContent>*/}
          {/*    <Typography variant="body2" color="textPrimary">*/}
          {/*      Add funds to your wallet with a one-time payment*/}
          {/*    </Typography>*/}

          {/*    <Box mt={1} display="flex" alignItems="center">*/}
          {/*      <TextField*/}
          {/*        name="state"*/}
          {/*        onChange={handleChange}*/}
          {/*        select*/}
          {/*        SelectProps={{ native: true }}*/}
          {/*        value={purchaseValue}*/}
          {/*        variant="outlined"*/}
          {/*        size="small"*/}
          {/*      >*/}
          {/*        {stateOptions.map(state => (*/}
          {/*          <option key={state} value={state}>*/}
          {/*            ${state.toFixed(2)}*/}
          {/*          </option>*/}
          {/*        ))}*/}
          {/*      </TextField>*/}

          {/*      <Button*/}
          {/*        className={classes.buttonPurchase}*/}
          {/*        color="secondary"*/}
          {/*        variant="contained"*/}
          {/*        onClick={onClickPurchase}*/}
          {/*      >*/}
          {/*        Purchase*/}
          {/*      </Button>*/}
          {/*    </Box>*/}
          {/*  </CardContent>*/}
          {/*</Card>*/}
          <WalletOrderProvider>
            <Card>
              <DownloadOrder />

              <CardHeader title="Order List" />
              <Divider />
              <OrderListTable />
            </Card>
          </WalletOrderProvider>

          <TransactionDownloadProvider>
            <Card className={classes.cardContainer}>
              <DownloadTransaction />
              <CardHeader title="Transactions" />
              <Divider />
              <TranscriptionTable />
            </Card>
          </TransactionDownloadProvider>
        </Container>
      </ErrorBoundaryComponent>
    </Page>
  );
}

export default MyWallet;
