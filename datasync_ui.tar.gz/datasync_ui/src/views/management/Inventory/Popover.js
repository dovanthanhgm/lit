import React from "react";
import {
  Popover,
  Box,
  Card,
  Table,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import MoreVertIcon from "@material-ui/icons/MoreVert";

const useStyles = makeStyles((theme) => ({
  multiple: {
    "&:hover": {
      cursor: "pointer",
    },
  },
  popover: {
    pointerEvents: "none",
  },
  paper: {
    padding: theme.spacing(1),
  },
}));

export default function MouseOverPopover({ inventories }) {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  return (
    <Box
      display="flex"
      alignItems="center"
      className={classes.multiple}
      onMouseEnter={handlePopoverOpen}
      onMouseLeave={handlePopoverClose}
    >
      <MoreVertIcon></MoreVertIcon>
      <Typography color="textSecondary" variant="body2">
        (multiple)
      </Typography>

      <Popover
        id="mouse-over-popover"
        className={classes.popover}
        classes={{
          paper: classes.paper,
        }}
        open={open}
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: "center",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "center",
          horizontal: "left",
        }}
        onClose={handlePopoverClose}
        disableRestoreFocus
      >
        <Card>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Location</TableCell>
                <TableCell>Available</TableCell>
                <TableCell>Reserved</TableCell>
                <TableCell>On hand</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {inventories &&
                inventories.map((item, index) => {
                  return (
                    <TableRow key={index}>
                      <TableCell>{item.location_name}</TableCell>
                      <TableCell align="center">{item.available}</TableCell>
                      <TableCell align="center">{item.reserved}</TableCell>
                      <TableCell align="center">{item.on_hand}</TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
        </Card>
      </Popover>
    </Box>
  );
}
