import {
  Backdrop,
  Box,
  Card,
  Checkbox,
  CircularProgress,
  Container,
  Link,
  makeStyles,
  SvgIcon,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from "@material-ui/core";
import moment from "moment";
import React, { useEffect, useState } from "react";
import { Image as ImageIcon } from "react-feather";
import PerfectScrollbar from "react-perfect-scrollbar";
import { useDispatch } from "react-redux";
import { Link as RouterLink } from "react-router-dom";
import { actionGetWarehouses } from "src/actions/warehouse";
import Page from "src/components/Page";
import TableSkeleton from "src/components/Skeleton/Table";
import FilterComponent from "./Filter";
import MultyInventory from "./Popover";

const useStyles = makeStyles((theme) => ({
  root: {},
  imageCell: {
    fontSize: 0,
    width: 48,
    flexBasis: 48,
    flexGrow: 0,
    flexShrink: 0,
  },
  image: {
    height: 48,
    width: 48,
  },
  backdrop: {
    zIndex: 2,
    color: "#fff",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 200,
    maxWidth: 300,
  },
}));

function Results({
  products,
  changePage,
  changeLimit,
  page,
  limit,
  total,
  loading,
  setLoading,
  setTotal,
  changeInventories,
}) {
  const classes = useStyles();
  const dispatch = useDispatch();

  const [selectedProducts, setSelectedProducts] = useState([]);

  const handleSelectAllProducts = (event) => {
    setSelectedProducts(
      event.target.checked ? products.map((product) => product._id) : []
    );
  };

  const handleSelectOneProduct = (productId) => () => {
    if (!selectedProducts.includes(productId)) {
      setSelectedProducts((prevSelected) => [...prevSelected, productId]);
    } else {
      setSelectedProducts((prevSelected) =>
        prevSelected.filter((id) => id !== productId)
      );
    }
  };

  const handlePageChange = (event, newPage) => {
    setLoading(true);
    changePage(newPage);
  };

  const handleLimitChange = (event) => {
    setLoading(true);
    changeLimit(event.target.value);
  };

  const selectedSomeProducts =
    selectedProducts.length > 0 && selectedProducts.length < products?.length;
  const selectedAllProducts = selectedProducts.length === products?.length;

  useEffect(() => {
    dispatch(actionGetWarehouses());
  }, [dispatch]);

  return (
    <Page>
      <Container maxWidth={false}>
        <Box pb={2}>
          <FilterComponent
            page={page}
            limit={limit}
            setTotal={setTotal}
            changeInventories={changeInventories}
          />
        </Box>
        <Card>
          <PerfectScrollbar>
            <Box minWidth={800}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell size="small" padding="checkbox">
                      <Checkbox
                        checked={selectedAllProducts}
                        indeterminate={selectedSomeProducts}
                        onChange={handleSelectAllProducts}
                      />
                    </TableCell>
                    <TableCell size="small" />
                    <TableCell size="small">
                      {/* <TableSortLabel
                    active
                    direction={sort ? sort : "asc"}
                    onClick={handleSortName}
                  > */}
                      Name
                      {/* </TableSortLabel> */}
                    </TableCell>
                    <TableCell size="small">SKU</TableCell>
                    <TableCell size="small">Condition</TableCell>
                    <TableCell size="small">Location</TableCell>
                    {/* <TableCell size="small">Bin Location</TableCell> */}
                    <TableCell size="small">Available</TableCell>
                    <TableCell size="small">Reserved</TableCell>
                    <TableCell size="small">On Hand</TableCell>
                    <TableCell size="small">Price</TableCell>
                    <TableCell size="small">Last Modified</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {products?.length > 0 &&
                    products.map((product) => {
                      const isProductSelected = selectedProducts.includes(
                        product._id
                      );
                      const productInventories = product.inventories || [];

                      return (
                        <TableRow
                          hover
                          key={product._id}
                          selected={isProductSelected}
                        >
                          <TableCell size="small" padding="checkbox">
                            <Checkbox
                              checked={isProductSelected}
                              onChange={handleSelectOneProduct(product._id)}
                              value={isProductSelected}
                            />
                          </TableCell>
                          <TableCell size="small" className={classes.imageCell}>
                            {product.thumb_image?.url ? (
                              <img
                                alt=""
                                src={product.thumb_image.url}
                                className={classes.image}
                              />
                            ) : (
                              <Box p={2} bgcolor="background.dark">
                                <SvgIcon>
                                  <ImageIcon />
                                </SvgIcon>
                              </Box>
                            )}
                          </TableCell>
                          <TableCell size="small">
                            <Link
                              component={RouterLink}
                              to={`/products/${product._id}`}
                            >
                              <Typography variant="body2" color="textPrimary">
                                {product.name}
                              </Typography>
                            </Link>

                            {/* <Typography variant="body2" color="textPrimary">
                          Varies on: Size, Color
                        </Typography> */}
                          </TableCell>
                          <TableCell size="small">
                            <Link
                              component={RouterLink}
                              to={`/products/${product._id}`}
                            >
                              <Typography variant="body2" color="textPrimary">
                                {product.sku}
                              </Typography>
                            </Link>
                          </TableCell>
                          <TableCell size="small" align="center">
                            New
                          </TableCell>
                          <TableCell>
                            {productInventories.length > 1 ? (
                              <MultyInventory
                                inventories={productInventories}
                              />
                            ) : (
                              productInventories[0]?.location_name
                            )}
                          </TableCell>
                          {/* <TableCell>Bin Location</TableCell> */}
                          <TableCell>
                            {productInventories[0]?.available}
                          </TableCell>
                          <TableCell>
                            {productInventories[0]?.reserved}
                          </TableCell>
                          <TableCell>
                            {productInventories[0]?.on_hand}
                          </TableCell>
                          <TableCell>{product.price}</TableCell>
                          <TableCell size="small" align="right">
                            {moment(product.updated_at).format("MMMM DD, YYYY")}
                          </TableCell>
                        </TableRow>
                      );
                    })}

                  {!products && <TableSkeleton column={12} />}

                  {loading && (
                    <Backdrop className={classes.backdrop} open invisible>
                      <CircularProgress color="inherit" />
                    </Backdrop>
                  )}
                </TableBody>
              </Table>

              {products && products.length === 0 && (
                <Box
                  display="flex"
                  justifyContent="center"
                  alignItems="center"
                  p={1}
                >
                  <Typography className={classes.noData}>No data</Typography>
                </Box>
              )}

              {products && (
                <TablePagination
                  component="div"
                  count={total}
                  onChangePage={handlePageChange}
                  onChangeRowsPerPage={handleLimitChange}
                  page={page}
                  rowsPerPage={limit}
                  rowsPerPageOptions={[10, 25, 50]}
                />
              )}
            </Box>
          </PerfectScrollbar>
        </Card>
      </Container>
    </Page>
  );
}

export default Results;
