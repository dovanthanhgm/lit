import {
  Box,
  FormControl,
  FormControlLabel,
  InputAdornment,
  InputLabel,
  Link,
  makeStyles,
  MenuItem,
  Paper,
  Radio,
  SvgIcon,
  Typography,
} from "@material-ui/core";
import { Search as SearchIcon } from "@material-ui/icons";
import { Field, Formik } from "formik";
import {
  RadioGroup as RadioGroupFormik,
  Select as SelectFormik,
} from "formik-material-ui";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import ButtonCustom from "src/components/MUI/Button";
import TextFieldFormik from "src/components/MUI/Formik/Text";
import { getListInventoriesAPI } from "src/services/manage";

const useStyles = makeStyles((theme) => ({
  root: {},
  imageCell: {
    fontSize: 0,
    width: 48,
    flexBasis: 48,
    flexGrow: 0,
    flexShrink: 0,
  },
  image: {
    height: 48,
    width: 48,
  },
  backdrop: {
    zIndex: 2,
    color: "#fff",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 200,
    maxWidth: 300,
  },
}));

const types = [
  {
    value: "available",
    label: "Available",
  },
  {
    value: "reserved",
    label: "Reserved",
  },
  {
    value: "on_hand",
    label: "On hand",
  },
];

function Filter({ page, limit, setTotal, changeInventories }) {
  const classes = useStyles();
  const { warehouses } = useSelector((state) => state.warehouse);
  const [showMore, setShowmore] = useState(false);

  const handleShowMore = () => {
    setShowmore(!showMore);
  };

  return (
    <Paper component={Box} py={1}>
      <Formik
        initialValues={{
          query: "",
          condition: "",
          location: "",
          from: "",
          to: "",
          type: "available",
        }}
        enableReinitialize
        onSubmit={async (values, { setSubmitting }) => {
          let typeFrom = "";
          let typeTo = "";
          if (values.from) {
            typeFrom = `min_${values.type}`;
          }
          if (values.to) {
            typeTo = `max_${values.type}`;
          }
          try {
            const res = await getListInventoriesAPI({
              page,
              limit,
              query: values.query,
              condition: values.condition,
              location: values.location,
              [typeFrom]: values.from,
              [typeTo]: values.to,
            });
            if (res?.code === 200) {
              changeInventories(res?.data);
              setTotal(res.count);
            }
          } catch (error) {
            console.log("error", error);
          } finally {
            setSubmitting(false);
          }
        }}
      >
        {({ values, handleSubmit, isSubmitting, resetForm }) => {
          const conditions = Object.values(values).find(
            (item) => !["available", "reserved", "on_hand", ""].includes(item)
          );

          const handleResetForm = async () => {
            resetForm();
            try {
              const res = await getListInventoriesAPI({
                page,
                limit,
              });
              if (res?.code === 200) {
                changeInventories(res?.data);
                setTotal(res.count);
              }
            } catch (error) {
              console.log("error", error);
            } finally {
            }
          };

          return (
            <form onSubmit={handleSubmit}>
              <Box
                m={2}
                display="flex"
                justifyContent="space-between"
                alignItems="center"
              >
                <Box display="flex" alignItems="center">
                  <Box mr={2}>
                    <TextFieldFormik
                      fullWidth
                      label="Search inventory"
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SvgIcon fontSize="small" color="action">
                              <SearchIcon />
                            </SvgIcon>
                          </InputAdornment>
                        ),
                      }}
                      name="query"
                    />
                  </Box>
                  <Box mr={2}>
                    <FormControl
                      variant="outlined"
                      size="small"
                      className={classes.formControl}
                    >
                      <InputLabel>Conditions</InputLabel>
                      <Field
                        component={SelectFormik}
                        name="condition"
                        label="Conditions"
                      >
                        {[
                          {
                            name: "All Conditions",
                            value: "",
                          },
                          {
                            name: "New",
                            value: "new",
                          },
                          {
                            name: "Used",
                            value: "used",
                          },
                          {
                            name: "Reconditioned",
                            value: "reconditioned",
                          },
                        ].map((items, key) => (
                          <MenuItem key={key} value={items.value}>
                            <Box>{items.name}</Box>
                          </MenuItem>
                        ))}
                      </Field>
                    </FormControl>
                  </Box>
                  <Box mr={2}>
                    <FormControl
                      variant="outlined"
                      size="small"
                      className={classes.formControl}
                    >
                      <InputLabel>Locations</InputLabel>
                      <Field
                        component={SelectFormik}
                        name="location"
                        label="Locations"
                      >
                        {warehouses.map((items) => (
                          <MenuItem key={items.id} value={items.id}>
                            <Box>{items.name}</Box>
                          </MenuItem>
                        ))}
                      </Field>
                    </FormControl>
                  </Box>
                  <Box mr={2}>
                    <Typography color="primary">
                      <Link variant="body2" onClick={handleShowMore}>
                        {!showMore ? "Show more filters" : "Hide filters"}
                      </Link>
                    </Typography>
                  </Box>
                </Box>

                <Box display="flex">
                  <Box mr={2}>
                    <ButtonCustom
                      type="submit"
                      color="secondary"
                      text="Apply filter"
                      disabled={isSubmitting || !conditions}
                      notShowCircle={!conditions}
                    />
                  </Box>
                  <Box>
                    <ButtonCustom
                      disabled={isSubmitting || !conditions}
                      notShowCircle={isSubmitting || !conditions}
                      color="secondary"
                      onClick={handleResetForm}
                      text="Clear Filter"
                    />
                  </Box>
                </Box>
              </Box>
              {showMore && (
                <Box m={2} display="flex">
                  <Box pr={2}>
                    <TextFieldFormik
                      fullWidth
                      name="from"
                      label="Inventory From"
                    />
                  </Box>
                  <Box pr={2}>
                    <TextFieldFormik fullWidth name="to" label="Inventory To" />
                  </Box>
                  <FormControl component="fieldset">
                    <Field component={RadioGroupFormik} name="type">
                      <Box display="flex">
                        {types.map((item) => (
                          <FormControlLabel
                            key={item.value}
                            control={<Radio />}
                            {...item}
                          />
                        ))}
                      </Box>
                    </Field>
                  </FormControl>
                </Box>
              )}
            </form>
          );
        }}
      </Formik>
    </Paper>
  );
}

export default Filter;
