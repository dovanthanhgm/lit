import React, { useState, useEffect, useCallback } from "react";
import { Box, Container, makeStyles } from "@material-ui/core";
import { useHistory } from "react-router";
import Page from "src/components/Page";
import Header from "src/components/Header";
import { getListInventoriesAPI } from "src/services/manage";
import Result from "./Result";
import TutorialDialogs from "src/components/Modal/TutorialDialog"
import { goTutorial } from "src/actions/accountActions";
import { useDispatch, useSelector } from "react-redux";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(3),
    paddingBottom: 100,
  },
}));

function Warehouses() {
  const classes = useStyles();
  const history = useHistory();
  const dispatch = useDispatch();

  const [inventories, setInventories] = useState();
  const [page, setPage] = useState(0);
  const [limit, setLimit] = useState(10);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(true);

  const { go_tutorial } = useSelector((state) => state.account);

  const handleClose = () => {
    setOpen(false);
    dispatch(goTutorial(false));
  };

  const getProducts = useCallback(() => {
    const callApi = async () => {
      const res = await getListInventoriesAPI({ page, limit });
      if (res?.code === 200) {
        setInventories(res.data);
        setTotal(res.count);
        setLoading(false);
      }
    };
    callApi();
  }, [page, limit]);

  useEffect(() => {
    getProducts();
  }, [getProducts]);

  const handleAddlocation = () => {
    setPage(1);
  };

  const handleManageLocations = () => {
    history.push("/warehouses");
  };
  const handleExport = () => {
    history.push("/export-data");
  };

  return (
    <Page className={classes.root} title="Listing">
      <Container maxWidth={false}>
        <Header
          headerName={`Inventory`}
          groupButton={[
            {
              name: `Import from CSV`,
              onClick: handleAddlocation,
            },
            {
              name: `Manage locations`,
              onClick: handleManageLocations,
            },
            {
              name: `Export`,
              onClick: handleExport,
            },
          ]}
        />

        <Box mt={2}>
          <Result
            products={inventories}
            total={total}
            page={page}
            limit={limit}
            changePage={setPage}
            changeLimit={setLimit}
            loading={loading}
            setLoading={setLoading}
            setTotal={setTotal}
            changeInventories={(values) => setInventories(values)}
          />
        </Box>

        {go_tutorial &&
        <Box>
          <TutorialDialogs handleClose={handleClose} open={open} tab={"listing"}/>
        </Box>
        }
        {/* {page === 0 && (
          <Result
            warehouses={warehouses}
            handleEditWarehouse={handleEditWarehouse}
          />
        )}

        {page === 1 && (
          <UpdateWarehouseForm warehouse={warehouse} setPage={setPage} />
        )} */}
      </Container>
    </Page>
  );
}

export default Warehouses;
