import { Box, CardHeader, Paper } from "@material-ui/core";
import React from "react";

// const useStyles = makeStyles((theme) => ({
//   root: {},
//   button: {
//     margin: theme.spacing(1),
//   },
// }));

export default function Shipments() {
  // const classes = useStyles();
  // const [open, setOpen] = useState(false);

  // const handleClick = () => {
  //   setOpen(!open);
  //   return;
  // };

  return (
    <Box ml={2} mr={2}>
      <Paper>
        <CardHeader title="Shipments" />
      </Paper>
    </Box>
  );
}
