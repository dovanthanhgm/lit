import {
  Badge,
  Box,
  Button,
  Container,
  IconButton,
  makeStyles,
  Tooltip,
  Typography
} from "@material-ui/core";
import { isEmpty } from "lodash";
import { useSnackbar } from "notistack";
import React, { useContext, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Redirect } from "react-router";
import { getOrderDetailStart } from "src/actions/orderActions";
import Page from "src/components/Page";
import Header from "./Header";
import InfoOrderDetails from "src/views/management/OrderDetailsView/Modal/OrderDetail/InfoOrderDetails";
import CreateShippingLabel from "./Modal/CreateShippingLabel";
import Notes from "./Notes";
import OrderItems from "./OrderItems";
import ButtonCustom from "src/components/MUI/Button";
import SyncIcon from "@material-ui/icons/Sync";
import { syncOrderDetail, updateOrderUnlinkTab } from "src/services/orders";
import SingleAlert from "src/components/Notify/SingleAlert";
import CloseIcon from "@material-ui/icons/Close";
import useUserExp from "src/hooks/useUserExp";
import { Link as LinkIcon } from "react-feather";
import WalmartRefundOrderInfo from "src/views/management/OrderDetailsView/Modal/OrderDetail/WalmartRefundOrderInfo";
import Loading from "src/components/Loading/Loading";
import { OpenOrderDetailDialogContext } from "src/views/management/OrderListView/Context/OpenOrderDetailDialog";

const useStyles = makeStyles(theme => ({
  root: {
    // backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    position: "relative"
  },
  closeButton: {
    // position: "absolute",
    // left: theme.spacing(0),
    // top: theme.spacing(0.5),
    color: theme.palette.grey[500]
  },
  orderContainer: {
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1)
  }
}));

const noti = {
  updateSuccess: {
    title: "Update Success",
    variant: "success"
  },
  deleteSuccess: {
    title: "Delete Success",
    variant: "success"
  },
  createSuccess: {
    title: "Create Success",
    variant: "success"
  },
  updateFailed: {
    title: "Ooops!",
    variant: "error"
  },
  deleteFailed: {
    title: "Ooops!",
    variant: "error"
  },
  createFailed: {
    title: "Ooops!",
    variant: "error"
  }
};

const ERROR_GUIDE =
  "Order failed during import to mainstore. Try clicking SYNC ORDER, if the order still can't be entered, please contact us for a solution";

function OrderDetailsView() {
  const classes = useStyles();
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const { expired, isUserFree } = useUserExp();
  const { handleCloseModal, orderID, openOrderId } = useContext(
    OpenOrderDetailDialogContext
  );
  const { warehouses } = useSelector(state => state.warehouse);
  const {
    notifiOrder,
    isLoadingDetail,
    getOrderDetailFalse,
    orderDetail
  } = useSelector(state => state.order);
  const { listings, defaultListing } = useSelector(state => state.listing);

  const isRefundOrder = orderDetail?.refund_order || false;

  const getChannel = order =>
    listings?.find(channel => {
      return channel.id.toString() === order?.channel_id?.toString();
    });

  const [syncOrder, setSyncOrder] = useState(false);
  const [open, setOpen] = useState({
    multipleFBA: false,
    sendToFBA: false,
    createShippingLabel: false
  });
  const [updateButton, setUpdateButton] = useState(false);

  const handleClose = () => {
    setOpen({
      multipleFBA: false,
      sendToFBA: false,
      createShippingLabel: false
    });
  };

  const errorMessage = () => {
    if (orderDetail?.error_message) {
      return (
        <Box>
          <Box>{orderDetail?.error_message}</Box>
          <Box>{ERROR_GUIDE}</Box>
        </Box>
      );
    }
    return ERROR_GUIDE;
  };

  const handleErrorStatus = () => {
    let listOrder = [];
    const defaultId = defaultListing?.id;
    if (typeof orderDetail?.channel === "object" && defaultId) {
      listOrder = Object.values(orderDetail?.channel).reduce((prev, curr) => {
        prev[curr.channel_id] = curr;
        return prev;
      }, {});
    }
    return listOrder[defaultId]?.status;
  };

  const orderShowUpdateButton =
    orderDetail.link_status === "unlink" || handleErrorStatus() === "error";

  const handleSyncOrder = async () => {
    setSyncOrder(true);
    try {
      const request = await syncOrderDetail({ order_ids: orderID });
      if (request.status < 400) {
        dispatch(getOrderDetailStart({ order_id: orderID, loading: true }));
        enqueueSnackbar("Success", { variant: "success" });
        setSyncOrder(false);
      }
    } catch (e) {
      console.log("errors", e);
      enqueueSnackbar("Error", { variant: "error" });
      setSyncOrder(false);
    }
  };

  const handleUpdateOrders = async () => {
    try {
      setUpdateButton(true);
      const res = await updateOrderUnlinkTab({ order_ids: orderDetail?.id });
      if (res.status < 400) {
        enqueueSnackbar("Success", { variant: "success" });
      }
    } catch (e) {
      // setUpdateButton(false);
      console.log("errors", e);
      enqueueSnackbar("Error", { variant: "error" });
    }
  };

  const handleShowSetting = () => {
    const channel = getChannel(orderDetail);
    const setting =
      channel?.settings?.order?.status === "enable" ? "On" : "Off";
    const color =
      channel?.settings?.order?.status === "enable"
        ? "success.main"
        : "error.main";
    const id = channel?.id || orderDetail?.channel_id;
    return { color, setting, id };
  };

  const handleShowUpdateTo = () => {
    return !["completed", "canceled"].includes(orderDetail.status);
  };

  const orderSetting = () => {
    if (["shipping"].includes(orderDetail?.status)) {
      return !!orderDetail?.setting_order;
    }
    return true;
  };

  const orderUpdateStatusHasId = () => {
    const channel = getChannel(orderDetail);
    const channelId = channel?.id;
    const orderId = orderDetail?.channel?.[`channel_${channelId}`]?.order_id;

    return !!orderId;
  };

  useEffect(() => {
    noti?.[notifiOrder] &&
      enqueueSnackbar(noti?.[notifiOrder]?.title, {
        variant: noti?.[notifiOrder]?.variant
      });
  }, [notifiOrder, dispatch, enqueueSnackbar]);

  useEffect(() => {
    if (openOrderId) {
      dispatch(getOrderDetailStart({ order_id: orderID }));
    }
    // eslint-disable-next-line
  }, [orderID, openOrderId]);

  if (getOrderDetailFalse) {
    return <Redirect to={"/404"} />;
  }

  return (
    <Page className={classes.root} title="Order Details" noPadding>
      <Box display="flex" alignItems="center">
        <IconButton
          onClick={() => handleCloseModal()}
          className={classes.closeButton}
        >
          <CloseIcon />
        </IconButton>

        {!isLoadingDetail && (
          <Header order_number={orderDetail?.order_number} />
        )}
      </Box>
      <Container maxWidth={false} className={classes.orderContainer}>
        {orderDetail?.link_status === "unlink" && !isLoadingDetail && (
          <Box mb={2}>
            <SingleAlert
              content={
                <Box>
                  Some products in your order are unlinked. Please hover
                  on&nbsp;&nbsp;
                  <Badge color={"error"} variant="dot">
                    <LinkIcon size="20" />
                  </Badge>
                  &nbsp;&nbsp;to create linkings for those products. Click Sync
                  Order button to recalculate the product quantities in
                  LitCommerce.
                </Box>
              }
              type={"warning"}
            />
          </Box>
        )}
        {handleErrorStatus() === "error" && !isLoadingDetail && (
          <Box mb={2}>
            <SingleAlert content={errorMessage()} type={"warning"} />
          </Box>
        )}
        <Box
          display="flex"
          alignItems="center"
          mb={2}
          justifyContent="space-between"
        >
          {/*<Box display="flex" alignItems="center" mb={2}>*/}
          {/*  <ArrowBackIcon fontSize="small" color="primary" />*/}
          {/*  <Link to={`/orders`}>Back to Orders</Link>*/}
          {/*</Box>*/}
          <Box flexGrow={1}>
            {orderShowUpdateButton && !isLoadingDetail && (
              <Tooltip
                title={
                  expired || isUserFree
                    ? "This feature is only available for paid customers"
                    : ""
                }
              >
                <span>
                  <ButtonCustom
                    text={
                      <Typography
                        style={{ fontSize: 13, whiteSpace: "nowrap" }}
                      >
                        Sync Order
                      </Typography>
                    }
                    color="primary"
                    startIcon={<SyncIcon />}
                    onClick={handleUpdateOrders}
                    disabled={updateButton || expired}
                    notShowCircle={!updateButton}
                  />
                </span>
              </Tooltip>
            )}
          </Box>

          {!isLoadingDetail && (
            <Box display="flex" alignItems="center" ml={1}>
              <Typography variant="body2">
                Automatically import orders to Main Store & Sync Order
                Status:&nbsp;
                <Box component="span" color={handleShowSetting().color}>
                  <Typography variant="h6" component="span">
                    {handleShowSetting().setting}
                  </Typography>
                </Box>
              </Typography>
              <Box mx={1} />
              {orderSetting() && (
                <React.Fragment>
                  <Button
                    href={`/listing/${handleShowSetting().id}/settings`}
                    variant="contained"
                    color="primary"
                    size="small"
                  >
                    Settings
                  </Button>
                  <Box mx={0.5} />
                  {!orderShowUpdateButton &&
                    handleShowUpdateTo() &&
                    !isLoadingDetail &&
                    orderUpdateStatusHasId() && (
                      <ButtonCustom
                        text={
                          <Typography
                            style={{ whiteSpace: "nowrap", fontSize: 13 }}
                          >
                            Update status to {getChannel(orderDetail)?.type}
                          </Typography>
                        }
                        color="primary"
                        startIcon={<SyncIcon />}
                        onClick={handleSyncOrder}
                        disabled={syncOrder}
                        notShowCircle={!syncOrder}
                      />
                    )}
                </React.Fragment>
              )}
            </Box>
          )}
        </Box>

        <>
          {isLoadingDetail ? (
            <Loading />
          ) : (
            <Box>
              {!isEmpty(orderDetail) && (
                <>
                  {/*padding = 4*/}
                  <Box pl={4} pr={4}>
                    {isRefundOrder && (
                      <WalmartRefundOrderInfo orderDetail={orderDetail} />
                    )}
                    {!isRefundOrder && (
                      <InfoOrderDetails orderDetail={orderDetail} />
                    )}
                  </Box>
                  {/*padding = 2, component = 2 */}
                  <Box p={2} pb={0}>
                    <OrderItems
                      warehouses={warehouses}
                      orderDetail={orderDetail}
                      order_id={orderID}
                    />
                  </Box>
                  <Box p={2} pb={0}>
                    <Notes order_id={orderID} orderDetail={orderDetail} />
                  </Box>
                </>
              )}
              <CreateShippingLabel
                open={open.createShippingLabel}
                handleClose={handleClose}
              />
            </Box>
          )}
        </>
      </Container>
      <Box pb={12.5} />
    </Page>
  );
}

export default OrderDetailsView;
