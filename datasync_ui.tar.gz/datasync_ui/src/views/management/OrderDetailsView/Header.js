import PropTypes from "prop-types";
import React from "react";
import HeaderPageTitle from "src/components/Layout/HeaderPageTitle";

function Header({ order_number, className, ...rest }) {
  return <HeaderPageTitle>Order / {order_number}</HeaderPageTitle>;
}

Header.propTypes = {
  className: PropTypes.string,
  order_id: PropTypes.string
};

export default Header;
