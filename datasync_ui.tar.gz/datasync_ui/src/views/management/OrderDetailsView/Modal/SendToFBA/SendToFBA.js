import {
  Box,
  Divider,
  Grid,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import { Field, Formik } from "formik";
import { TextField as TextFieldFormik } from "formik-material-ui";
import { useSnackbar } from "notistack";
import React from "react";
import NumberFormat from "react-number-format";
import { useParams } from "react-router";
import FieldSelect from "src/components/Dropdown/FieldSelect";
import ButtonCustom from "src/components/MUI/Button";
import { sendToFBA } from "src/services/orders";

const useStyles = makeStyles((theme) => ({
  root: {},
}));

const listShippingSpeed = [
  { name: "Standard", value: "Standard" },
  { name: "Expedited", value: "Expedited" },
  { name: "Priority", value: "Priority" },
];

const CustomNumberFormat = (props) => (
  <NumberFormat allowNegative={false} {...props} />
);

const CustomTextField = (props) => (
  <TextFieldFormik
    InputProps={{
      inputComponent: CustomNumberFormat,
    }}
    variant="outlined"
    size="small"
    {...props}
  />
);

export default function SendToFBASingle({ prdsSendToFBA }) {
  const classes = useStyles();
  const { order_id } = useParams();
  const { enqueueSnackbar } = useSnackbar();

  return (
    <Box className={classes.root}>
      <Formik
        initialValues={{
          products: prdsSendToFBA?.map((product, key) => ({
            ...product,
            [`shipment${key}`]: 0,
          })),
          shippingSpeed: "Standard",
        }}
        onSubmit={async (values, { setSubmitting }) => {
          let products = {};
          products = values?.products?.reduce((prev, curr) => {
            prev[curr.id] = curr.qty;
            return prev;
          }, {});

          const body = {
            products: products,
            location_id: values.products[0].warehouse_id,
            shipping_speed: values.shippingSpeed,
          };

          try {
            const res = await sendToFBA({ body, order_id });
            if (res && res.status < 400) {
              enqueueSnackbar(`Save success`, {
                variant: "success",
              });
            } else {
              enqueueSnackbar(`Oop!`, {
                variant: "error",
              });
            }
          } catch (error) {
            console.log("error", error);
            enqueueSnackbar(`Oop!`, {
              variant: "error",
            });
          } finally {
            setSubmitting(false);
          }
        }}
      >
        {({ values, handleChange, handleSubmit, isSubmitting }) => {
          return (
            <form onSubmit={handleSubmit}>
              <Box m={2} mb={2}>
                <Typography align="left" variant="h3">
                  Send to FBA
                </Typography>
              </Box>
              <Divider />
              <Box display="flex" m={2}>
                <Typography align="left" variant="body2">
                  Sending the order to FBA will immediately create a fulfillment
                  order for the items
                </Typography>
              </Box>
              {/* <Divider /> */}
              <Box mb={5}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell width="45%">Item</TableCell>
                      <TableCell width="25%">To be Fulfilled</TableCell>
                      <TableCell width="30%">In this Shipment</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {values.products?.map((product, key) => {
                      return (
                        <TableRow key={key}>
                          <TableCell>
                            <Typography algin="left" variant="body2">
                              {product.product_name}
                            </Typography>
                            <Typography
                              color="secondary"
                              algin="left"
                              variant="body2"
                            >
                              {product.product_sku}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography align="center">
                              {product.qty}
                            </Typography>
                          </TableCell>
                          <TableCell align="center">
                            <Box width="80%">
                              <Field
                                name={`products[${key}].shipment${key}`}
                                component={CustomTextField}
                              />
                            </Box>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </Box>

              {/* <Divider /> */}
              <Box width="100%" m={2} mb={3}>
                <Grid
                  container
                  justify="flex-start"
                  alignItems="center"
                  spacing={3}
                >
                  <Grid item xs={3}>
                    <Typography
                      align="right"
                      variant="h6"
                      color="textPrimary"
                      className={classes.text}
                    >
                      FBA Account
                    </Typography>
                  </Grid>
                  <Grid item xs={9}>
                    <Box display="flex" justifyItems="center">
                      <Typography
                        align="right"
                        variant="h6"
                        color="textPrimary"
                        className={classes.text}
                      >
                        FBA - Briteseller Amazon
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      align="right"
                      variant="h6"
                      color="textPrimary"
                      className={classes.text}
                    >
                      Requested Shipping
                    </Typography>
                  </Grid>
                  <Grid item xs={9}>
                    <Box display="flex" justifyItems="center">
                      <Typography
                        align="right"
                        variant="h6"
                        color="textPrimary"
                        className={classes.text}
                      >
                        --
                      </Typography>
                    </Box>
                  </Grid>

                  <Grid item xs={3}>
                    <Typography variant="h6" color="textPrimary" align="right">
                      Shipping Speed
                    </Typography>
                  </Grid>
                  <Grid item xs={9}>
                    <Box width="30%" display="flex" alignItems="center">
                      <FieldSelect
                        name="shippingSpeed"
                        items={listShippingSpeed}
                      />
                    </Box>
                  </Grid>
                </Grid>
                <Box py={2} display="flex">
                  <Box>
                    <ButtonCustom
                      text="Send to FBA"
                      color="primary"
                      size="small"
                      type="submit"
                      disabled={
                        values.products?.filter(
                          (value, key) => value[`shipment${key}`] > value.qty
                        ).length > 0 || isSubmitting
                      }
                      notShowCircle={
                        values.products?.filter(
                          (value, key) => value[`shipment${key}`] > value.qty
                        ).length > 0
                      }
                    />
                  </Box>
                  <Box px={2}>
                    <ButtonCustom
                      text="Cancel"
                      type="submit"
                      color="primary"
                      size="small"
                      disabled={
                        values.products?.filter(
                          (value, key) => value[`shipment${key}`] > value.qty
                        ).length > 0 || isSubmitting
                      }
                      notShowCircle
                    />
                  </Box>
                </Box>
              </Box>
            </form>
          );
        }}
      </Formik>
    </Box>
  );
}
