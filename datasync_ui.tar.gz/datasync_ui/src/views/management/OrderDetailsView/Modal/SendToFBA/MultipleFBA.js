import {
  Box,
  Divider,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import React from "react";
import ButtonCustom from "src/components/MUI/Button";

const useStyles = makeStyles((theme) => ({
  root: {},
}));

export default function MultipleFBA({
  FBAWarehouses,
  orderDetail,
  handleClose,
  handleOpenFBA,
  handleUpdatePrds,
}) {
  const classes = useStyles();

  const handleClick = (value) => () => {
    handleClose();
    handleOpenFBA();
    handleUpdatePrds(value);
  };

  return (
    <Box className={classes.root} p={3}>
      <Box m={2} mb={2}>
        <Typography align="left" variant="h3">
          Multiple FBA warehouse locations assigned
        </Typography>
      </Box>
      <Divider />
      <Box display="flex" m={2}>
        <Typography align="left" variant="body2">
          This order has items assigned to more than one warehouse. Choosse
          which warehouse yoou want to fulfill from.
        </Typography>
      </Box>
      {/* <Divider /> */}
      <Box mb={2}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell width="50%">
                <Typography variant="subtitle2">Warehouse</Typography>
              </TableCell>
              <TableCell width="20%">
                <Typography variant="subtitle2"># of Items</Typography>
              </TableCell>
              <TableCell width="30%" align="right"></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {FBAWarehouses.map((FBAWarehouse, index) => {
              let indexOfItems = orderDetail?.products
                ?.filter(
                  (product) =>
                    product.warehouse_inventories?.[FBAWarehouse.id] >= 0
                )
                .map((item) => ({ ...item, warehouse_id: FBAWarehouse.id }));

              return (
                <TableRow key={index}>
                  <TableCell>
                    <Typography algin="left" variant="body2">
                      {FBAWarehouse?.name}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography>{indexOfItems.length}</Typography>
                  </TableCell>
                  <TableCell align="right">
                    <ButtonCustom
                      variant="contained"
                      color="secondary"
                      text="Send to FBA"
                      size="small"
                      onClick={handleClick(indexOfItems)}
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Box>
    </Box>
  );
}
