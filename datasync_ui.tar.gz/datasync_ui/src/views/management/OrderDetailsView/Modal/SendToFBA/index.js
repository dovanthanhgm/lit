import { Dialog, makeStyles } from "@material-ui/core";
import React from "react";
import MultipleFBA from "./MultipleFBA";
import SendToFBASingle from "./SendToFBA";

const useStyles = makeStyles((theme) => ({
  root: {},
}));

export default function SendToFBA({
  handleClose,
  FBAWarehouses,
  orderDetail,
  openMultipleFBA,
  openSendToFBA,
  handleOpenFBA,
  handleUpdatePrds,
  prdsSendToFBA,
  prdSendToFBASingle,
}) {
  const classes = useStyles();

  return (
    <>
      <Dialog
        fullWidth
        className={classes.root}
        open={openMultipleFBA}
        onClose={handleClose}
      >
        <MultipleFBA
          FBAWarehouses={FBAWarehouses}
          orderDetail={orderDetail}
          handleClose={handleClose}
          handleOpenFBA={handleOpenFBA}
          handleUpdatePrds={handleUpdatePrds}
        />
      </Dialog>

      <Dialog
        fullWidth
        className={classes.root}
        open={openSendToFBA}
        onClose={handleClose}
      >
        <SendToFBASingle
          prdsSendToFBA={
            prdsSendToFBA.length > 0 ? prdsSendToFBA : prdSendToFBASingle
          }
        />
      </Dialog>
    </>
  );
}
