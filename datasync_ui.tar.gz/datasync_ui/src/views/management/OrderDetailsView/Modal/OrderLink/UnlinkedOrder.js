import React from "react";
import {
  Badge,
  Box,
  Link,
  Paper,
  Tooltip,
  Typography
} from "@material-ui/core";
import { Link as LinkIcon } from "react-feather";
import { capitalizeFirstLetter } from "src/utils/CapitalizeFirstLetter";
import WhiteToolTip from "src/components/Tooltip/WhiteToolTip";
import authService from "src/services/authService";

const notVariantNoIdMessage = (channelId, channelType) => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography variant="body2">
        This product does not exist in LitCommerce and is unlinked. Please
        follow these steps:
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to your&nbsp;
        <Link href={`/listing/detail/${channelId}`} target="_blank">
          Channel Listing
        </Link>
        ,&nbsp;
        <Typography variant="body2" component="span">
          click "Import from {capitalizeFirstLetter(channelType)}" to import new
          products including this one from {capitalizeFirstLetter(channelType)}
          &nbsp;to LitCommerce
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Link this product to the correct product in Main Store
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          3.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const noVariantHaveIdMessage = productId => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography>
        This product exists in LitCommerce but is unlinked. Please follow these
        steps:
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to this&nbsp;
        <Link href={`/products/${productId}`} target="_blank">
          Product page
        </Link>
        ,&nbsp;
        <Typography variant="body2" component="span">
          link it to the correct product in Main Store
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const isVariantNoIdMessage = (channelID, channelType) => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography variant="body2">
        This product does not exist in LitCommerce and is unlinked. Please
        follow these steps:
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to your&nbsp;
        <Link href={`/listing/detail/${channelID}`} target="_blank">
          Channel List
        </Link>
        ,&nbsp;
        <Typography variant="body2" component="span">
          click "Import from {capitalizeFirstLetter(channelType)}" to import new
          products including this one from {capitalizeFirstLetter(channelType)}
          &nbsp;to LitCommerce
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Link the parent product of this to the correct parent product in Main
          Store
        </Typography>
      </Typography>
      <Typography>
        <Typography component={"span"} variant="body2">
          3.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Link this variant to the correct variant in Main Store
        </Typography>
      </Typography>
      <Typography>
        <Typography component={"span"} variant="body2">
          4.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const isParentLinkNoPrdIdMessage = (
  channelID,
  channelType,
  productsId
) => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography variant="body2">
        This product variant does not exist in LitCommerce, parent product
        exists but is unlinked. Please follow these steps:
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to the&nbsp;
        <Link href={`/listing/${channelID}/${productsId}`} target="_blank">
          Parent product page
        </Link>
        , click "Update from&nbsp;
        {capitalizeFirstLetter(channelType)}" to import new variants including
        this one.
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Link the parent product of this to the correct parent product in Main
          Store
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          3.
        </Typography>
        &nbsp;Link this variant to the correct variant in Main Store
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          4.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const isParentNoPrdIdMessage = (channelID, productsId) => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography variant="body2">
        This product variant exists in LitCommerce, parent product exists but is
        unlinked. Please follow these steps:
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to the&nbsp;
        <Link href={`/listing/${channelID}/${productsId}`} target="_blank">
          Parent product page
        </Link>
        ,&nbsp;
        <Typography variant="body2" component="span">
          link the parent product of this to the correct parent product in Main
          Store.
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Link this variant to the correct variant in Main Store
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          3.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const isParentPrdIdMessage = (channelID, channelType, productsId) => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography variant="body2">
        This product variant does not exist in LitCommerce, parent product
        exists and is linked. Please follow these steps:
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to the&nbsp;
        <Link href={`/listing/${channelID}/${productsId}`} target="_blank">
          Parent product page
        </Link>
        , click "Update from {capitalizeFirstLetter(channelType)}" to import new
        variants including this one.
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Link this variant to the correct variant in Main Store
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          3.
        </Typography>
        &nbsp;
        <Typography variant="body2" component="span">
          Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const isParentLinkPrdIdMessage = (channelID, productsId) => () => {
  return (
    <Box color={"black"} p={1}>
      <Typography variant="body2">
        This product variant exists in LitCommerce but is unlinked, parent
        product exists and is linked. Please follow these steps:
      </Typography>

      <Typography>
        <Typography component={"span"} variant="body2">
          1.
        </Typography>
        &nbsp;Go to the &nbsp;
        <Link href={`/listing/${channelID}/${productsId}`} target="_blank">
          Parent product page
        </Link>
        ,
        <Typography variant="body2" component="span">
          link this variant to the correct variant in Main Store
        </Typography>
      </Typography>
      <Typography variant="body2">
        <Typography component={"span"} variant="body2">
          2.
        </Typography>
        <Typography variant="body2" component="span">
          &nbsp;Click "Sync Order" on this page
        </Typography>
      </Typography>
    </Box>
  );
};

const UnlinkedOrderDetail = ({ product, channelId, channelType }) => {
  const isParentId = product.parent_id;
  const parentLinked = product.parent_link_status === "linked";

  const unlinkType = {
    notVariantNoId: () => notVariantNoIdMessage(channelId, channelType),
    noVariantHaveId: () => noVariantHaveIdMessage(product?.id),
    isVariantNoId: () => isVariantNoIdMessage(channelId, channelType),
    isParentLinkNoPrdId: () =>
      isParentLinkNoPrdIdMessage(channelId, channelType, isParentId),
    isParentNoPrdId: () => isParentNoPrdIdMessage(channelId, isParentId),
    isParentPrdId: () =>
      isParentPrdIdMessage(channelId, channelType, isParentId),
    isParentLinkPrdId: () => isParentLinkPrdIdMessage(channelId, isParentId),
    default: () => "unlink"
  };

  const hasParentInLit = product => {
    const isParentNoPrdId = !product.id && product.is_variant && !parentLinked;
    const isParentPrdId = !!product.id && product.is_variant && !parentLinked;

    const isParentLinkNoPrdId =
      !product.id && product.is_variant && parentLinked;

    const isParentLinkPrdId =
      !!product.id && product.is_variant && parentLinked;

    if (isParentLinkNoPrdId) {
      return "isParentLinkNoPrdId";
    } else if (isParentNoPrdId) {
      return "isParentNoPrdId";
    } else if (isParentPrdId) {
      return "isParentPrdId";
    } else if (isParentLinkPrdId) {
      return "isParentLinkPrdId";
    } else {
      return "default";
    }
  };

  const doNotExistInLitC = product => {
    const notVariantNoId = !product.is_variant && !product.id;
    const noVariantHaveId = !product.is_variant && !!product.id;
    const isVariantNoId = product.is_variant && !product.id;

    if (notVariantNoId) {
      return "notVariantNoId";
    } else if (noVariantHaveId) {
      return "noVariantHaveId";
    } else if (isVariantNoId) {
      return "isVariantNoId";
    } else {
      return "default";
    }
  };

  const tooltipTile = () => {
    if (!channelId) return "";
    if (isParentId) {
      return unlinkType?.[hasParentInLit(product)]();
    }
    return unlinkType?.[doNotExistInLitC(product)]();
  };

  const loginByToken = authService.getLoginByToken();
  const loginByAdmin = authService.getLoginByAdmin();

  if (loginByAdmin || loginByToken) {
    console.log("product.is_variant", product.is_variant);
    console.log("product.id", product.id);
    console.log("product.parent_link_status", product.parent_link_status);
    console.log("product.parent_id", product.parent_id);
  }
  if (tooltipTile() === "unlink") {
    return (
      <Tooltip title={"Unlinked"}>
        <Box m={1} display="flex" pl={2}>
          <Badge color={"error"} variant="dot">
            <LinkIcon size="20" />
          </Badge>
        </Box>
      </Tooltip>
    );
  }

  return (
    <WhiteToolTip
      title={
        <Paper>
          <Box p={2}>{tooltipTile()}</Box>
        </Paper>
      }
    >
      <Box m={1} display="flex" pl={2}>
        <Badge color={"error"} variant="dot">
          <LinkIcon size="20" />
        </Badge>
      </Box>
    </WhiteToolTip>
  );
};

export default UnlinkedOrderDetail;
