import React, { useMemo } from "react";
import { Badge, Box, Divider, Paper, Typography } from "@material-ui/core";
import { Link as LinkIcon } from "react-feather";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import { makeStyles } from "@material-ui/styles";
import OrderLinkData from "src/views/management/OrderDetailsView/Modal/OrderLink/OrderLinkData";
import { useSelector } from "react-redux";
import UnlinkedOrderDetail from "src/views/management/OrderDetailsView/Modal/OrderLink/UnlinkedOrder";
import { withStyles } from "@material-ui/core/styles";
import Tooltip from "@material-ui/core/Tooltip";

const useStyles = makeStyles(theme => ({
  cartImage: {
    width: 32,
    height: 32
  }
}));

const LightTooltipLinkOrder = withStyles(theme => ({
  tooltip: {
    backgroundColor: "#f5f5f9",
    boxShadow: theme.shadows[1],
    maxWidth: 768,
    padding: 4,
    left: 32
  },
  arrow: {
    "&:before": {
      border: "1px solid #E6E8ED"
    },
    color: "#f5f5f9"
  }
}))(Tooltip);

const OrderInfo = ({ defaultListing, hoverProduct }) => {
  const classes = useStyles();
  return (
    <Paper>
      <Box display="flex" alignItems="center" p={1} position={"relative"}>
        <CartLogo id={defaultListing.type} className={classes.cartImage} />
        <Box px={1} />
        <Typography variant="h6">Main Store Product</Typography>
      </Box>
      <Divider />
      <Box display="flex" alignItems="center" justifyContent={"center"} p={1}>
        <OrderLinkData order={hoverProduct} />
      </Box>
    </Paper>
  );
};

const LinkOrderInfo = ({ order, hoverProduct = {}, orderDetail }) => {
  const { defaultListing } = useSelector(state => state.listing);
  const orderOfChannel = useMemo(() => {
    return orderDetail.channel[`channel_${orderDetail?.channel_id}`];
  }, [orderDetail]);

  if (order?.link_status === "linked") {
    return (
      <LightTooltipLinkOrder
        arrow
        title={
          <OrderInfo
            hoverProduct={hoverProduct}
            defaultListing={defaultListing}
          />
        }
        placement="top-end"
        interactive
        enterNextDelay={100}
        // classes={{ arrow: classes.arrow }}
      >
        <Box m={1} display="flex" pl={2}>
          <Badge color={"primary"} variant="dot">
            <LinkIcon size="20" />
          </Badge>
        </Box>
      </LightTooltipLinkOrder>
    );
  }

  return (
    <UnlinkedOrderDetail
      channelType={orderOfChannel?.channel_type}
      channelId={orderOfChannel?.channel_id}
      product={order}
    />
  );
};

export default LinkOrderInfo;
