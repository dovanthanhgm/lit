import React from "react";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography
} from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import clsx from "clsx";

const useStyles = makeStyles(theme => ({
  productImage: {
    width: 48,
    height: 48
  },
  nameOverFlow: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  linkText: {
    color: theme.palette.primary.main,
    cursor: "pointer",
    textDecoration: "underline"
  }
}));

const OrderLinkData = ({ order }) => {
  const classes = useStyles();

  const handleOpenDetail = () => {
    window.open(`/products/${order._id}`, "_blank");
  };

  return (
    <Box display="flex" flexDirection={"column"}>
      <Table size={"small"}>
        <TableHead>
          <TableRow>
            {/*<TableCell />*/}
            <TableCell>Name</TableCell>
            <TableCell>SKU</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          <TableRow>
            {/*<TableCell>*/}
            {/*  <ImageProduct*/}
            {/*    className={classes.productImage}*/}
            {/*    src={order?.thumb_image?.url}*/}
            {/*    paddingImageFail={3}*/}
            {/*  />*/}
            {/*</TableCell>*/}
            <TableCell>
              <Tooltip title={order?.name}>
                <Box maxWidth={200}>
                  <Typography
                    variant="body2"
                    onClick={handleOpenDetail}
                    className={clsx(classes.nameOverFlow, classes.linkText)}
                  >
                    {order?.name}
                  </Typography>
                </Box>
              </Tooltip>
            </TableCell>
            <TableCell>
              <Typography variant="body2">{order?.sku}</Typography>
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>

      <Box my={1} />
      {order.is_variant && (
        <Box>
          {order?.attributes?.map((item, index) => {
            return (
              <Typography
                variant="caption"
                component="span"
                style={index === 0 ? {} : { marginLeft: 8 }}
              >
                {item?.attribute_name}: {`${item?.attribute_value_name}`}
                {index === order?.attributes.length - 1 ? "" : ","}
              </Typography>
            );
          })}
        </Box>
      )}
    </Box>
  );
};

export default OrderLinkData;
