import React, { useContext } from "react";
import OpenModal80 from "src/components/Modal/OpenModal80";
import OrderDetailsView from "src/views/management/OrderDetailsView/index";
import { OpenOrderDetailDialogContext } from "src/views/management/OrderListView/Context/OpenOrderDetailDialog";

const OrderModalDetail = () => {
  const { open, handleCloseModal, openOrderId } = useContext(
    OpenOrderDetailDialogContext
  );

  return (
    <OpenModal80
      open={Boolean(!!open || !!openOrderId)}
      onClose={handleCloseModal}
    >
      <>{<OrderDetailsView />}</>
    </OpenModal80>
  );
};

export default OrderModalDetail;
