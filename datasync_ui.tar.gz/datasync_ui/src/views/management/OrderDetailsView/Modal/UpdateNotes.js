import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
} from "@material-ui/core";
import { Formik } from "formik";
import React from "react";

export default function ModalUpdateNotes({
  handleClose,
  open,
  item,
  order_id,
  history_id,
}) {
  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <Formik
        initialValues={{
          comment: item.comment,
        }}
        enableReinitialize
        onSubmit={async (values) => {
          try {
            const params = {
              order_id: order_id,
              history_id: history_id,
              comment: values.comment,
            };
            // dispatch(putNotesStart({ params }));
          } catch (error) {
            console.log("error", error);
          }
        }}
      >
        {({ values, handleSubmit, handleChange }) => {
          return (
            <form onSubmit={handleSubmit}>
              <DialogTitle id={order_id}>
                "Use Google's location service?"
              </DialogTitle>
              <DialogContent>
                <DialogContentText id="alert-dialog-description">
                  <TextField
                    name="comment"
                    onChange={handleChange}
                    size="small"
                    variant="outlined"
                    value={values.comment}
                    multiline
                  />
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  Cancel
                </Button>
                <Button type="submit" color="primary" autoFocus>
                  Edit
                </Button>
              </DialogActions>
            </form>
          );
        }}
      </Formik>
    </Dialog>
  );
}
