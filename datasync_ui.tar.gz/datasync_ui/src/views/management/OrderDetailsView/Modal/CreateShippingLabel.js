import {
  Box,
  Button,
  Checkbox,
  Divider,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
} from "@material-ui/core";
import Popover from "@material-ui/core/Popover";
import Typography from "@material-ui/core/Typography";
import CheckIcon from "@material-ui/icons/Check";
import CloseIcon from "@material-ui/icons/Close";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { NumberFormatCustom } from "src/components/InputField/FieldNumberFormat";

const useStyles = makeStyles((theme) => ({
  root: {
    width: 900,
  },
  typography: {
    padding: theme.spacing(2),
  },
  textWeight: {
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1),
  },
}));

export default function CreateShippingLabel({ open, handleClose }) {
  const classes = useStyles();
  const [isOpenAddFund, setAddFund] = useState(false);

  // const [selectedDate, setSelectedDate] = useState(
  //   new Date("2014-08-18T21:11:54")
  // );

  // const handleDateChange = (date) => {
  //   setSelectedDate(date);
  // };

  const handleAddFund = () => {
    setAddFund(!isOpenAddFund);
  };

  return (
    <Popover
      className={classes.root}
      open={open}
      onClose={handleClose}
      anchorOrigin={{
        vertical: 150,
        horizontal: 450,
      }}
      // anchorPosition={{ left: 200, top: 100 }}
    >
      <Box minWidth={800} m={2} mb={3}>
        <Grid container spacing={3}>
          <Grid item xs={6}>
            <Typography align="left" variant="h3">
              Package Information
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography align="right" variant="body2">
              Wallet balance: $0.00
            </Typography>
            <Box>
              {!isOpenAddFund && (
                <Link onClick={handleAddFund} to="#">
                  <Typography align="right">+ Add funds</Typography>
                </Link>
              )}
              {isOpenAddFund && (
                <Box>
                  <TextField size="small" variant="outlined" />
                  <IconButton aria-label="checked">
                    <CheckIcon />
                  </IconButton>
                  <IconButton onClick={handleAddFund} aria-label="close">
                    <CloseIcon />
                  </IconButton>
                </Box>
              )}
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Divider />
      <Box mb={5}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell width="45%">Item</TableCell>
              <TableCell width="15%">To be Fulfilled</TableCell>
              <TableCell width="40%" align="right">
                In this Shipment
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell>
                <Typography algin="left" variant="body2">
                  Fingerless Gloves,Jushye Women Ladies...
                </Typography>
                <Typography color="secondary" algin="left" variant="body2">
                  LT_GLOVE_1
                </Typography>
              </TableCell>
              <TableCell>
                <Typography>{1}</Typography>
              </TableCell>
              <TableCell align="right">
                <TextField
                  variant="outlined"
                  size="small"
                  InputProps={{
                    inputComponent: NumberFormatCustom
                  }}
                />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Box>

      {/* <Divider /> */}
      <Box m={2} mb={3}>
        <Typography align="left" variant="subtitle2">
          Package Information
        </Typography>

        <Grid container justify="flex-start" alignItems="center" spacing={3}>
          <Grid item xs={3}>
            <Typography
              align="right"
              variant="h6"
              color="textPrimary"
              className={classes.text}
            >
              Package Type
            </Typography>
          </Grid>
          <Grid item xs={9}>
            <TextField select variant="outlined" size="small" />
          </Grid>
          <Grid item xs={3}>
            <Typography
              align="right"
              variant="h6"
              color="textPrimary"
              className={classes.text}
            >
              Package Weight
            </Typography>
          </Grid>
          <Grid item xs={9}>
            <Box display="flex" alignItems="center">
              <TextField
                name="weight"
                variant="outlined"
                size="small"
                InputProps={{
                  inputComponent: NumberFormatCustom
                }}
              />
              <Typography
                variant="h6"
                color="textPrimary"
                className={classes.textWeight}
              >
                lbs
              </Typography>
              <TextField
                width="25%"
                name="weightOz"
                variant="outlined"
                size="small"
                InputProps={{
                  inputComponent: NumberFormatCustom
                }}
              />
              <Typography
                variant="h6"
                color="textPrimary"
                className={classes.textWeight}
              >
                oz
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={3}>
            <Typography variant="h6" color="textPrimary" align="right">
              Package Dimensions
            </Typography>
          </Grid>
          <Grid item xs={9}>
            <Box display="flex" alignItems="center">
              <TextField
                width="25%"
                name="length"
                variant="outlined"
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">L</InputAdornment>
                  ),
                  inputComponent: NumberFormatCustom
                }}
              />
              <Typography
                variant="h6"
                color="textPrimary"
                className={classes.textWeight}
              >
                x
              </Typography>
              <TextField
                width="25%"
                name="width"
                variant="outlined"
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">W</InputAdornment>
                  ),
                  inputComponent: NumberFormatCustom
                }}
              />
              <Typography
                variant="h6"
                color="textPrimary"
                className={classes.textWeight}
              >
                x
              </Typography>
              <TextField
                width="25%"
                name="height"
                variant="outlined"
                size="small"
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">H</InputAdornment>
                  ),
                  inputComponent: NumberFormatCustom
                }}
              />
              <Typography
                variant="h6"
                color="textPrimary"
                className={classes.textWeight}
              >
                inches
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box>
      {/* -------------------------------------------------- */}
      <Divider />
      <Box m={2} mb={3}>
        <Typography align="left" variant="subtitle2">
          Shipment Details
        </Typography>
        <Grid container justify="flex-start" alignItems="center" spacing={3}>
          <Grid item xs={3}>
            <Typography
              align="right"
              variant="h6"
              color="textPrimary"
              className={classes.text}
            >
              Ship Date
            </Typography>
          </Grid>
          <Grid item xs={9}>
            <Box display="flex" alignItems="center">
              <TextField
                id="date"
                type="date"
                defaultValue="2022-01-01"
                className={classes.textField}
                InputLabelProps={{
                  shrink: true,
                }}
                variant="outlined"
                size="small"
              />
              <Typography
                variant="caption"
                color="textPrimary"
                className={classes.textWeight}
              >
                Must be today or later
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={3}>
            <Typography
              align="right"
              variant="h6"
              color="textPrimary"
              className={classes.text}
            >
              Add Discounted Insurance
            </Typography>
          </Grid>
          <Grid item xs={9}>
            <Box display="flex" alignItems="center">
              <TextField name="weight" variant="outlined" size="small" />
              <Typography
                variant="caption"
                color="textPrimary"
                className={classes.textWeight}
              >
                Third-party insurance provided by Shipsurance. By using
                insurance, you agree to the Insurance Terms
              </Typography>
            </Box>
          </Grid>

          <Grid item xs={3}>
            <Typography variant="h6" color="textPrimary" align="right">
              Signature Confirmation
            </Typography>
          </Grid>
          <Grid item xs={9}>
            <FormControlLabel
              control={<Checkbox name="checkedA" />}
              label="Additional fees apply. Not available for all carriers."
            />
          </Grid>
        </Grid>
      </Box>
      <Divider />
      <Box mt={5}>
        <Grid container spacing={3}>
          <Grid item xs={6}>
            <Box align="left" m={2}>
              <Button variant="outlined" size="small" color="primary">
                Cancel
              </Button>
            </Box>
          </Grid>
          <Grid item xs={6}>
            <Box align="right" m={2}>
              <Button variant="contained" size="small" color="primary">
                Next
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Popover>
  );
}
