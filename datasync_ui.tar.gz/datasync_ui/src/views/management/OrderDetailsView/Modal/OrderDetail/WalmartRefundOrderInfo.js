import React from "react";
import useOrderInfo from "src/hooks/Orders/useOrderInfo";
import { Grid } from "@material-ui/core";
import ChannelOrderContainer from "src/components/OrdersDetail/ChannelOrderContainer";

const WalmartRefundOrderInfo = ({ orderDetail }) => {
  const {
    orderOfSource,
    orderOfChannel,
    getOrderTrackingCompany,
    getOrderTrackingURL,
    handleGetCountry,
    item
  } = useOrderInfo({ orderDetail });

  return (
    <Grid container spacing={3}>
      <Grid item xs={8} lg={6}>
        <ChannelOrderContainer
          orderDetail={orderDetail}
          channelType={item?.type}
          refundOrderId={orderDetail?.return_order_id || ""}
          channelName={item?.name}
          customorderIdWalmart={1234}
          orderID={orderOfChannel?.order_number || orderOfChannel?.order_id}
          orderStatus={orderOfChannel.order_status}
          orderDate={orderOfChannel.created_at}
          isWalmart
          shippedDate={
            orderOfSource?.shipped_date ?? orderOfSource?.shipped_at ?? ""
          }
          trackingCompany={getOrderTrackingCompany({
            defaultOrder: orderDetail,
            order: orderOfChannel
          })}
          trackingNumber={getOrderTrackingURL({
            defaultOrder: orderDetail,
            order: orderOfChannel
          })}
          country={handleGetCountry({
            country: orderOfChannel?.shipping_address,
            defaultOrder: orderDetail
          })}
          adminOrderId={orderOfChannel?.order_id}
          customOrderIdWalmart={orderDetail?.additional_details?.[0]?.value}
        />
      </Grid>
      <Grid item xs={6} />
    </Grid>
  );
};

export default WalmartRefundOrderInfo;
