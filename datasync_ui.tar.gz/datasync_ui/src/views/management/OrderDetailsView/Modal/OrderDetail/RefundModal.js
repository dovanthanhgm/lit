import React, { useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  SvgIcon,
  Typography
} from "@material-ui/core";
import { ReactComponent as RefundIC } from "src/assets/icons/refundIcon.svg";
import DialogTitle from "src/components/Modal/DialogTitle";
import { orderProductRefund } from "src/services/orders";
import { useSnackbar } from "notistack";
import { messageError } from "src/utils/ErrorResponse";

const RefundIcon = props => {
  return <SvgIcon component={RefundIC} viewBox="0 0 48 48" {...props} />;
};

const RefundModal = ({ channel_id, orderNumber, order_id }) => {
  const { enqueueSnackbar } = useSnackbar();
  const [openRefund, setOpenRefund] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleRefund = status => {
    setOpenRefund(status);
  };

  const refundOrder = async () => {
    try {
      setLoading(true);
      const data = await orderProductRefund({
        order_id,
        order_number: orderNumber,
        channel_id
      });
      if (data) {
        enqueueSnackbar(data?.data?.message || "Success", {
          variant: "success"
        });
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Refund fail"), { variant: "error" });
    }
    setLoading(false);
  };

  const handleConfirmCancel = () => {
    refundOrder();
    handleRefund(false);
  };

  return (
    <Box mx={0.5}>
      <Button
        color={"primary"}
        size="small"
        variant="contained"
        disabled={loading}
        onClick={() => handleRefund(true)}
      >
        <RefundIcon style={{ fontSize: 16, fill: "white", marginRight: 4 }} />
        Refund Order
      </Button>

      <Dialog
        onClose={() => handleRefund(false)}
        aria-labelledby="customized-dialog-title"
        open={openRefund}
      >
        <DialogTitle
          id="customized-dialog-title"
          onClose={() => handleRefund(false)}
        >
          Refund order
        </DialogTitle>
        <DialogContent dividers>
          <Typography gutterBottom>
            <Typography variant="body1">
              Do you want to refund this order?
            </Typography>
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleConfirmCancel} color="primary" size="small">
            Accept
          </Button>
          <Button onClick={() => handleRefund(false)} size="small">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default RefundModal;
