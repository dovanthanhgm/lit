import React, { useState } from "react";
import { IconButton, SvgIcon, Tooltip } from "@material-ui/core";
import { updateOrderAPI } from "src/services/orders";
import { messageError } from "src/utils/ErrorResponse";
import { useSnackbar } from "notistack";
import { ReactComponent as ConfirmOrderIcon } from "src/assets/icons/confirmOrder.svg";

const ConfirmIcon = props => {
  return (
    <SvgIcon component={ConfirmOrderIcon} viewBox="0 0 512 512" {...props} />
  );
};

const UpdateOrderStatus = ({ channel_id, orderNumber, order_id, index }) => {
  const { enqueueSnackbar } = useSnackbar();

  const [disableUpdate, setDisableUpdate] = useState(false);

  const updateOrder = async () => {
    try {
      setDisableUpdate(true);
      const data = await updateOrderAPI({
        order_id,
        order_number: orderNumber,
        channel_id,
        order_line: index,
        is_all: false
      });
      if (data) {
        enqueueSnackbar(data?.data?.message || "Success", { variant: "error" });
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Update fail"), { variant: "error" });
    }
    setDisableUpdate(false);
  };

  return (
    <Tooltip title={"Confirm"}>
      <IconButton size="small" disabled={disableUpdate} onClick={updateOrder}>
        <ConfirmIcon
          style={{ fontSize: 18, fill: "primary", marginRight: 4 }}
          color={disableUpdate ? "disabled" : "primary"}
        />
      </IconButton>
    </Tooltip>
  );
};

export default UpdateOrderStatus;
