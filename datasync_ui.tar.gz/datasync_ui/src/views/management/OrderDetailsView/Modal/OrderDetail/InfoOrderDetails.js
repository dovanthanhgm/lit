import { Grid } from "@material-ui/core";
import React from "react";
import { useSelector } from "react-redux";
import ChannelOrderContainer from "src/components/OrdersDetail/ChannelOrderContainer";
import useOrderInfo from "src/hooks/Orders/useOrderInfo";

export default function InfoOrderDetails({ orderDetail }) {
  const { defaultListing } = useSelector(state => state?.listing);

  const {
    orderOfSource,
    orderOfChannel,
    getOrderTrackingNumber,
    getOrderTrackingCompany,
    handleGetCountry,
    item
  } = useOrderInfo({ orderDetail });

  return (
    <Grid container spacing={3}>
      <Grid item xs={6}>
        <ChannelOrderContainer
          orderDetail={orderDetail}
          channelType={defaultListing.type}
          channelName="Main Store"
          orderID={orderOfSource?.order_number || orderOfSource?.order_id}
          orderStatus={orderOfSource?.order_status}
          orderDate={orderOfSource?.created_at}
          shippedDate={
            orderOfSource?.shipped_date ?? orderOfSource?.shipped_at ?? ""
          }
          trackingCompany={getOrderTrackingCompany({
            defaultOrder: orderDetail,
            order: orderOfSource
          })}
          trackingNumber={getOrderTrackingNumber({
            defaultOrder: orderDetail,
            order: orderOfSource
          })}
          country={handleGetCountry({
            country: orderOfSource?.shipping_address,
            defaultOrder: orderDetail
          })}
          orderOfChannel={orderOfChannel}
          adminOrderId={orderOfSource?.order_id}
        />
      </Grid>
      <Grid item xs={6}>
        <ChannelOrderContainer
          orderDetail={orderDetail}
          channelType={item?.type}
          channelName={item?.name}
          orderID={orderOfChannel?.order_number || orderOfChannel?.order_id}
          orderStatus={orderOfChannel.order_status}
          orderDate={orderOfChannel.created_at}
          shippedDate={
            orderOfSource?.shipped_date ?? orderOfSource?.shipped_at ?? ""
          }
          trackingCompany={getOrderTrackingCompany({
            defaultOrder: orderDetail,
            order: orderOfChannel
          })}
          trackingNumber={getOrderTrackingNumber({
            defaultOrder: orderDetail,
            order: orderOfChannel
          })}
          country={handleGetCountry({
            country: orderOfChannel?.shipping_address,
            defaultOrder: orderDetail
          })}
          adminOrderId={orderOfChannel?.order_id}
          customOrderIdWalmart={orderDetail?.additional_details?.[0]?.value}
        />
      </Grid>
    </Grid>
  );
}
