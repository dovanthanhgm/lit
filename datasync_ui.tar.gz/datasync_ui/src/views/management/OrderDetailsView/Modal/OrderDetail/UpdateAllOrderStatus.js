import React, { useState } from "react";
import { Box, Button, Tooltip } from "@material-ui/core";
import { updateOrderAPI } from "src/services/orders";
import { messageError } from "src/utils/ErrorResponse";
import { useSnackbar } from "notistack";

const UpdateAllOrderStatus = ({ channel_id, orderNumber, order_id }) => {
  const { enqueueSnackbar } = useSnackbar();

  const [disableUpdate, setDisableUpdate] = useState(false);

  const updateOrder = async () => {
    try {
      setDisableUpdate(true);
      const data = await updateOrderAPI({
        order_id,
        order_number: orderNumber,
        channel_id,
        is_all: true
      });
      if (data) {
        enqueueSnackbar(data?.data?.message || "Success", { variant: "error" });
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Update fail"), { variant: "error" });
    }
    setDisableUpdate(false);
  };

  return (
    <Box mx={0.5}>
      <Tooltip title={"Update order"}>
        <Button
          variant="contained"
          size="small"
          disabled={disableUpdate}
          onClick={updateOrder}
          color="primary"
        >
          Update order status
        </Button>
      </Tooltip>
    </Box>
  );
};

export default UpdateAllOrderStatus;
