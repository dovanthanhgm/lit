import React, { useState } from "react";
import DialogTitle from "src/components/Modal/DialogTitle";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  Tooltip,
  Typography
} from "@material-ui/core";
import { cancelOrderProduct } from "src/services/orders";
import { useSnackbar } from "notistack";
import { messageError } from "src/utils/ErrorResponse";

const CancelAllOrder = ({ channel_id, orderNumber, order_id }) => {
  const { enqueueSnackbar } = useSnackbar();
  const [openCancel, setOpenCancel] = useState(false);
  const [loadingCancel, setLoadingCancel] = useState(false);

  const cancelOrder = async () => {
    const body = {
      order_number: orderNumber,
      order_id,
      is_all: true
    };
    try {
      setLoadingCancel(true);
      const data = await cancelOrderProduct({ channel_id, body });
      if (data) {
      }
      enqueueSnackbar(data?.data?.message || "Success", { variant: "error" });
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Cancel fail"), { variant: "error" });
    }
    setLoadingCancel(false);
  };

  const handleConfirmCancel = () => {
    cancelOrder();
    setOpenCancel(false);
  };

  const handleCloseCancel = () => {
    setOpenCancel(false);
  };

  const handleOpenCancel = () => {
    setOpenCancel(true);
  };

  return (
    <Box mx={0.5}>
      <Tooltip title={"Cancel order"}>
        <Button
          variant="contained"
          size="small"
          color="primary"
          disabled={loadingCancel}
          onClick={handleOpenCancel}
        >
          Cancel Order
        </Button>
      </Tooltip>
      <Dialog
        onClose={handleCloseCancel}
        aria-labelledby="customized-dialog-title"
        open={openCancel}
      >
        <DialogTitle id="customized-dialog-title" onClose={handleCloseCancel}>
          Cancel order
        </DialogTitle>
        <DialogContent dividers>
          <Typography gutterBottom>
            <Typography variant="body1">
              Do you want to cancel this order?
            </Typography>
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleConfirmCancel} color="primary" size="small">
            Accept
          </Button>
          <Button onClick={handleConfirmCancel} size="small">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CancelAllOrder;
