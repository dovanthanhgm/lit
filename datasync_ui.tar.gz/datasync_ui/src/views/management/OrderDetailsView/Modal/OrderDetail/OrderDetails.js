import {
  Avatar,
  Box,
  Card,
  CardHeader,
  Divider,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from "@material-ui/core";
import clsx from "clsx";
import PropTypes from "prop-types";
import React from "react";
import { useSelector } from "react-redux";

const useStyles = makeStyles((theme) => ({
  root: {
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
  },
  avatar: {
    marginRight: theme.spacing(1),
  },
}));

const paymentStatusColors = {
  awaiting_payment: "warning",
  ready_to_ship: "warning",
  shipping: "warning",
  open: "#8BD55D",
  completed: "success",
  canceled: "#e74c3c",
};

const tableHeadName = [
  "Order Date",
  "Order Status",
  "Requested Shipping",
  "Ship By Date",
  "Deliver By Date",
  "Sales Channel",
  "Sales Channel Order #",
];

function OrderDetails({ orderDetail, className, ...rest }) {
  const classes = useStyles();
  const { listings } = useSelector((state) => state.listing);

  return (
    <Card className={clsx(classes.root, className)} {...rest}>
      <CardHeader title="Order Details" />
      <Divider />
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              {tableHeadName.map((item, key) => (
                <TableCell key={key} align="left" size="small">
                  {item}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            <TableRow>
              {/* Order Date */}
              <TableCell size="small">
                <Typography variant="body2">
                  {orderDetail.created_at}
                </Typography>
              </TableCell>

              {/* Order Status */}
              <TableCell size="small">
                <Box
                  bgcolor={paymentStatusColors[orderDetail.status]}
                  alignItems="center"
                  justifyItems="center"
                  borderRadius={16}
                >
                  <Typography align="center">{orderDetail.status}</Typography>
                </Box>
                <Box pt={1} display="flex">
                  <Box
                    borderRadius="50%"
                    color={orderDetail?.payment?.status ? "#8BD55D" : "#9e9e9e"}
                    bgcolor={
                      orderDetail?.payment?.status ? "#8BD55D" : "#fafafa"
                    }
                    border={1}
                    width={18}
                    height={18}
                  />
                  <Box ml={1}>
                    <Typography variant="caption">Paid</Typography>
                  </Box>
                </Box>
                <Box pt={1} display="flex">
                  <Box
                    borderRadius="50%"
                    color={
                      orderDetail?.shipping?.status ? "#8BD55D" : "#9e9e9e"
                    }
                    bgcolor={
                      orderDetail?.shipping?.status ? "#8BD55D" : "#fafafa"
                    }
                    border={1}
                    width={18}
                    height={18}
                  />
                  <Box ml={1}>
                    <Typography variant="caption">Shipped</Typography>
                  </Box>
                </Box>
              </TableCell>

              {/* Requested Shipping */}
              <TableCell size="small">
                {orderDetail?.shipping?.["method"]}
              </TableCell>

              {/* Ship By Date */}
              <TableCell size="small">Ship By Date</TableCell>

              {/* Deliver By Date */}
              <TableCell size="small">Deliver By Date</TableCell>

              {/* Sales Channel */}
              <TableCell size="small">
                <Box alignItems="center" display="flex">
                  {listings.map((item, key) =>
                    item.id === orderDetail.channel_id ? (
                      <Box
                        display="flex"
                        justifyItems="center"
                        alignItems="center"
                        key={key}
                      >
                        <Avatar
                          className={classes.avatar}
                          variant="square"
                          src={`/static/images/markets/${item.type}.svg`}
                        />
                        <Typography variant="body2">{item.name}</Typography>
                      </Box>
                    ) : (
                      ""
                    )
                  )}
                </Box>
              </TableCell>

              {/* Sales Channel Order # */}
              <TableCell size="small">
                <Box>
                  <Typography variant="body2">
                    {orderDetail.order_number}
                  </Typography>
                </Box>
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Card>
  );
}

OrderDetails.propTypes = {
  className: PropTypes.string,
  orderDetail: PropTypes.object.isRequired,
};

export default OrderDetails;
