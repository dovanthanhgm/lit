import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  makeStyles,
  TableBody,
  TableCell,
  TableRow,
  Tooltip,
  Typography
} from "@material-ui/core";
import Link from "src/components/MUI/Link";
import LinkOrderInfo from "src/views/management/OrderDetailsView/Modal/OrderLink/LinkOrderInfo";
import authService from "src/services/authService";
import { useSelector } from "react-redux";
import { getOrderProductDetail } from "src/services/orders";
// import CancelOrderModal from "src/views/management/OrderDetailsView/Modal/OrderDetail/CancelOrderModal";
// import UpdateOrderStatus from "src/views/management/OrderDetailsView/Modal/OrderDetail/UpdateOrderStatus";

const useStyles = makeStyles(theme => ({
  root: {},
  tableCell: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: 280
  },
  tableCellAction: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    width: 100
  }
}));

const OrderDetailRow = ({ orderDetail, channelType }) => {
  const classes = useStyles();
  const loginByToken = authService.getLoginByToken();
  const { defaultListing } = useSelector(state => state.listing);
  const productsList = orderDetail?.products || [];
  const shippingTitle = orderDetail?.shipping?.title;
  const shippingMethod = orderDetail?.shipping?.method;

  const shippingType = () => {
    const shipType = shippingTitle || shippingMethod;
    if (shipType) {
      return `(${shipType})`;
    }
    return "";
  };

  const listProductPopupData = useMemo(
    () =>
      productsList?.reduce((prevProduct, currProduct) => {
        if (currProduct?.link_status === "linked") {
          prevProduct = [...prevProduct, currProduct.id];
        }
        return prevProduct;
      }, []),
    [productsList]
  );
  const [mainProducts, setMainProducts] = useState({});

  const isBigChannel = useMemo(() => {
    return defaultListing.type === "bigcommerce";
  }, [defaultListing.type]);

  const renderProductLink = ({ product }) => {
    if (!!product.id && !!product?.parent_id) {
      return { name: product?.parent_id, sku: product.id };
    }
    return { name: product?.parent_id || product?.id, sku: "" };
  };

  const handleShowAction = () => false;
  // const handleShowAction = () => {
  //   return (
  //     orderDetail?.channel_type === "Walmart" && !orderDetail?.refund_order
  //   );
  // };

  useEffect(() => {
    const getProductList = async () => {
      try {
        const data = await getOrderProductDetail({
          product_ids: listProductPopupData
        });
        if (data) {
          setMainProducts(data);
        }
      } catch (e) {
        console.log(e);
      }
    };

    listProductPopupData?.length > 0 && getProductList();
  }, [listProductPopupData]);

  return (
    <TableBody>
      {orderDetail?.products?.map?.((product, indexProduct) => {
        return (
          <TableRow key={indexProduct}>
            {loginByToken && (
              <TableCell>
                <Typography variant="body2">{product?.product_id}</Typography>
                <Typography variant="body2">{product?.listing_id}</Typography>
              </TableCell>
            )}
            <TableCell
              component="th"
              scope="row"
              size="small"
              style={{ maxWidth: 500 }}
            >
              <Box alignItems="center">
                <Box>
                  {product?.parent_id || product?.id ? (
                    <Link
                      href={`/listing/${orderDetail.channel_id}/${
                        renderProductLink({ product }).name
                      }`}
                      target="_blank"
                    >
                      <Typography variant="body2">
                        {product?.product_name}
                      </Typography>
                    </Link>
                  ) : (
                    <Typography variant="body2">
                      {product?.product_name}
                    </Typography>
                  )}
                </Box>
              </Box>
              <Box display={"flex"}>
                {product?.options?.map((item, index) => {
                  return (
                    <Typography
                      variant="body2"
                      style={index === 0 ? {} : { marginLeft: 8 }}
                    >
                      {item?.option_name}: {`${item?.option_value_name}`}
                      {index === product.options.length - 1 ? "" : ","}
                    </Typography>
                  );
                })}
              </Box>
            </TableCell>
            <TableCell className={classes.tableCell} size="small">
              {!!renderProductLink({ product }).sku ? (
                <Link
                  href={`/listing/${orderDetail.channel_id}/${
                    renderProductLink({ product }).sku
                  }`}
                  target="_blank"
                >
                  <Typography variant="body2">
                    {product?.product_sku}
                  </Typography>
                </Link>
              ) : (
                <Typography variant="body2">{product?.product_sku}</Typography>
              )}
            </TableCell>
            <TableCell
              className={classes.tableCell}
              size="small"
              align="center"
            >
              <LinkOrderInfo
                order={product}
                orderDetail={orderDetail}
                hoverProduct={mainProducts?.[product.id]}
              />
            </TableCell>
            {isBigChannel && (
              <TableCell
                className={classes.tableCell}
                size="small"
                align="center"
              >
                <Typography variant="body2">
                  {product?.product_bpn || ""}
                </Typography>
              </TableCell>
            )}
            <TableCell className={classes.tableCell} size="small" align="right">
              <Typography variant="body2">{product?.qty}</Typography>
            </TableCell>
            <TableCell className={classes.tableCell} size="small" align="right">
              <Typography variant="body2">
                {product.tax_amount || ""}
              </Typography>
            </TableCell>
            <TableCell className={classes.tableCell} size="small" align="right">
              <Typography variant="body2">{product?.price}</Typography>
            </TableCell>
            <TableCell className={classes.tableCell} size="small" align="right">
              <Typography variant="body2">{product?.total}</Typography>
            </TableCell>
            {/*{handleShowAction() && (*/}
            {/*  <TableCell*/}
            {/*    className={classes.tableCellAction}*/}
            {/*    size="small"*/}
            {/*    align="center"*/}
            {/*  >*/}
            {/*    <Box display="flex" alignItems="center">*/}
            {/*      {["ready_to_ship", "open"].includes(orderDetail?.status) && (*/}
            {/*        <CancelOrderModal*/}
            {/*          index={indexProduct}*/}
            {/*          order={product}*/}
            {/*          channel_id={orderDetail.channel_id}*/}
            {/*          order_id={orderDetail.id}*/}
            {/*          orderNumber={orderDetail.channel_order_number}*/}
            {/*        />*/}
            {/*      )}*/}
            {/*      {orderDetail?.status === "ready_to_ship" && (*/}
            {/*        <UpdateOrderStatus*/}
            {/*          orderNumber={orderDetail.channel_order_number}*/}
            {/*          channel_id={orderDetail.channel_id}*/}
            {/*          order_id={orderDetail.id}*/}
            {/*          index={indexProduct}*/}
            {/*        />*/}
            {/*      )}*/}
            {/*    </Box>*/}
            {/*  </TableCell>*/}
            {/*)}*/}
          </TableRow>
        );
      })}
      {/* Subtotal */}
      <TableRow>
        {loginByToken && <TableCell rowSpan={5} />}
        <TableCell rowSpan={5} />
        <TableCell rowSpan={5} />
        <TableCell rowSpan={5} />
        <TableCell rowSpan={5} />
        <TableCell rowSpan={5} />
        {isBigChannel && <TableCell rowSpan={5} />}
        <TableCell
          className={classes.tableCell}
          size="small"
          colSpan={1}
          variant="head"
          align="right"
        >
          Subtotal
        </TableCell>
        <TableCell className={classes.tableCell} size="small" align="right">
          {orderDetail?.["subtotal"]}
        </TableCell>
        {handleShowAction() && <TableCell />}
      </TableRow>

      {/* Shipping */}
      <TableRow>
        <TableCell
          className={classes.tableCell}
          size="small"
          colSpan={1}
          variant="head"
          align="right"
        >
          Shipping
          <Tooltip title={shippingType()}>
            <span>{shippingType()}</span>
          </Tooltip>
        </TableCell>
        <TableCell className={classes.tableCell} size="small" align="right">
          {orderDetail?.shipping?.["amount"]}
        </TableCell>
        {handleShowAction() && <TableCell />}
      </TableRow>

      {/* Tax */}
      <TableRow>
        <TableCell
          className={classes.tableCell}
          size="small"
          colSpan={1}
          variant="head"
          align="right"
        >
          Tax
        </TableCell>
        <TableCell className={classes.tableCell} size="small" align="right">
          {orderDetail?.tax?.["amount"]}
        </TableCell>
        {handleShowAction() && <TableCell />}
      </TableRow>
      <TableRow>
        <TableCell
          className={classes.tableCell}
          size="small"
          colSpan={1}
          variant="head"
          align="right"
        >
          Discount
        </TableCell>
        <TableCell className={classes.tableCell} size="small" align="right">
          {orderDetail?.discount?.["amount"]}
        </TableCell>
        {handleShowAction() && <TableCell />}
      </TableRow>

      {/* Total */}
      <TableRow>
        <TableCell
          className={classes.tableCell}
          size="small"
          colSpan={1}
          variant="head"
          align="right"
          width={170}
        >
          Total
        </TableCell>
        <TableCell
          className={classes.tableCell}
          size="small"
          align="right"
          width={170}
        >
          {orderDetail?.["total"]}
        </TableCell>
        {/*{handleShowAction() && <TableCell />}*/}
      </TableRow>
    </TableBody>
  );
};

export default React.memo(OrderDetailRow);
