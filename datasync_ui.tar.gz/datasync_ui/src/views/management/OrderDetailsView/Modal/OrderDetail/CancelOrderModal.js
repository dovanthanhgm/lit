import React, { useState } from "react";
import DialogTitle from "src/components/Modal/DialogTitle";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  IconButton,
  Tooltip,
  Typography
} from "@material-ui/core";
import CancelIcon from "@material-ui/icons/Cancel";
import { cancelOrderProduct } from "src/services/orders";
import { useSnackbar } from "notistack";
import Label from "src/components/Label";
import { messageError } from "src/utils/ErrorResponse";

function orderProductStatus(status) {
  const map = {
    paid: {
      text: "Paid",
      color: "success"
    },
    canceled: {
      text: "Cancelled",
      color: "error"
    },
    pending: {
      text: "Pending",
      color: "warning"
    },
    completed: {
      text: "completed",
      color: "success"
    }
  };

  if (status in map) {
    const { text, color } = map[status];
    return <Label color={color}>{text}</Label>;
  } else {
    return <Label>{status}</Label>;
  }
}

const CancelOrderModal = ({
  channel_id,
  orderNumber,
  index,
  order,
  order_id
}) => {
  const { enqueueSnackbar } = useSnackbar();
  const [openCancel, setOpenCancel] = useState(false);
  const orderCancelStatus = order.cancel_status;

  const cancelOrder = async () => {
    const body = {
      order_line: index,
      order_number: orderNumber,
      order_id,
      is_all: false
    };
    try {
      const data = await cancelOrderProduct({ channel_id, body });
      if (data) {
        enqueueSnackbar(data?.data?.message || "Success", { variant: "error" });
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Cancel fail"), { variant: "error" });
    }
  };

  const handleConfirmCancel = () => {
    cancelOrder();
    setOpenCancel(false);
  };

  const handleCloseCancel = () => {
    setOpenCancel(false);
  };

  const handleOpenCancel = () => {
    setOpenCancel(true);
  };

  return (
    <Box>
      {orderCancelStatus && orderProductStatus("canceled")}
      {!orderCancelStatus && (
        <Tooltip title={"Cancel"}>
          <IconButton onClick={handleOpenCancel}>
            <CancelIcon color={"error"} fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      <Dialog
        onClose={handleCloseCancel}
        aria-labelledby="customized-dialog-title"
        open={openCancel}
      >
        <DialogTitle id="customized-dialog-title" onClose={handleCloseCancel}>
          Cancel order
        </DialogTitle>
        <DialogContent dividers>
          <Typography gutterBottom>
            <Typography variant="body1">
              Do you want to cancel this order line?
            </Typography>
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleConfirmCancel} color="primary" size="small">
            Accept
          </Button>
          <Button onClick={handleConfirmCancel} size="small">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CancelOrderModal;
