import React, { useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  Typography
} from "@material-ui/core";
import { useSnackbar } from "notistack";
import { confirmOrderAPI } from "src/services/orders";
import { messageError } from "src/utils/ErrorResponse";
import DialogTitle from "src/components/Modal/DialogTitle";

const ConfirmOrder = ({ channel_id, orderNumber, order_id }) => {
  const { enqueueSnackbar } = useSnackbar();
  const [openConfirm, setOpenConfirm] = useState(false);

  const confirmRequest = async () => {
    try {
      const data = await confirmOrderAPI({
        order_id,
        order_number: orderNumber,
        channel_id
      });
      if (data) {
        enqueueSnackbar(data?.data?.message || "Success", { variant: "error" });
      }
    } catch (e) {
      console.log(e);
      enqueueSnackbar(messageError(e, "Error"), { variant: "error" });
    }
  };

  const handleConfirmStatus = status => {
    setOpenConfirm(status);
  };

  const handleConfirm = () => {
    confirmRequest();
    handleConfirmStatus(false);
  };

  return (
    <Box mx={0.5}>
      <Button
        color={"primary"}
        size="small"
        variant="contained"
        onClick={() => confirmRequest(true)}
      >
        Confirm Order
      </Button>

      <Dialog onClose={() => handleConfirmStatus(false)} open={openConfirm}>
        <DialogTitle onClose={() => handleConfirmStatus(false)}>
          Confirm order
        </DialogTitle>
        <DialogContent dividers>
          <Typography gutterBottom>
            <Typography variant="body1">
              Do you want to confirm this order?
            </Typography>
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleConfirm} color="primary" size="small">
            Accept
          </Button>
          <Button onClick={() => handleConfirmStatus(false)} size="small">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ConfirmOrder;
