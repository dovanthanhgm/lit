import {
  Box,
  Button,
  CardHeader,
  Grid,
  makeStyles,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableRow,
  TextField,
  Typography
} from "@material-ui/core";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import SettingsIcon from "@material-ui/icons/Settings";
import { Formik } from "formik";
import moment from "moment";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  createNotesStart,
  deleteNotesStart,
  putNotesStart
} from "src/actions/orderActions";

const useStyles = makeStyles(theme => ({
  root: {
    minHeight: 64,
    padding: theme.spacing(2)
  },
  button: {
    margin: theme.spacing(1)
  },
  cardHeaderStyle: {
    paddingLeft: 0
  }
}));

export default function Notes({ orderDetail, order_id }) {
  const classes = useStyles();
  const dispatch = useDispatch();
  const { isLoadingNotes } = useSelector(state => state.order);

  const [open, setOpen] = useState(false);
  const [openModalDelete, setOpenDelete] = useState(false);
  const [openModalCreate, setOpenCreate] = useState(false);
  const [itemNotes, setItem] = useState({});
  const [commentValue, setCommentValue] = useState("");

  const handleClickOpen = item => () => {
    setItem(item);
    setOpen(!open);
  };

  // const handleClickOpenDelete = item => () => {
  //   setItem(item);
  //   setOpenDelete(!openModalDelete);
  //   return;
  // };

  const handleClose = () => {
    setOpen(false);
    setOpenDelete(false);
    setOpenCreate(false);
  };

  const handleClickDelete = () => {
    try {
      const params = {
        order_id: orderDetail.id,
        history_id: itemNotes.id
      };
      dispatch(deleteNotesStart({ params }));
    } catch (error) {
      console.log("error", error);
    }
  };

  const handleClickCreate = () => {
    try {
      const params = {
        comment: commentValue,
        order_id: orderDetail.id
      };
      dispatch(createNotesStart({ params }));
    } catch (error) {
      console.log("error", error);
    }
  };

  const handleChange = e => {
    const { value } = e.target;
    setCommentValue(value);
  };

  return (
    <Box mr={2} ml={2}>
      <CardHeader title="Notes" className={classes.cardHeaderStyle} />

      <Paper className={classes.root}>
        <Typography align="center" variant="body2" color="textPrimary">
          For your use only -- will not be displayed to the buyer
        </Typography>
        <Box>
          {orderDetail?.history?.map((item, index) => {
            return (
              <Box key={index} pr={3} pl={3} display="flex">
                <Table>
                  <TableBody>
                    <TableRow>
                      <TableCell
                        align="left"
                        size="small"
                        style={{
                          borderBottom:
                            index === orderDetail?.length - 1 ? 0 : 1
                        }}
                      >
                        <Box display="flex">
                          <Grid
                            container
                            justify="center"
                            alignItems="center"
                            spacing={3}
                          >
                            <Grid item xs={12}>
                              <Typography align="left" variant="body2">
                                {item.comment}
                              </Typography>
                            </Grid>
                            <Grid item xs={4}>
                              <Box display="flex" alignItems="center">
                                <Typography
                                  align="left"
                                  variant="caption"
                                  style={{ fontStyle: "italic" }}
                                >
                                  {moment
                                    .tz(item.updated_at, "Asia/Ho_Chi_Minh")
                                    .from(moment.tz("Asia/Ho_Chi_Minh"))}
                                </Typography>

                                {item.source === "api" && (
                                  <Typography align="left">
                                    <Button
                                      size="small"
                                      variant="contained"
                                      color="default"
                                      className={classes.button}
                                      startIcon={<SettingsIcon />}
                                      onClick={handleClickOpen(item)}
                                    >
                                      Edit
                                    </Button>
                                  </Typography>
                                )}
                              </Box>
                            </Grid>
                            <Grid item xs={8} />
                          </Grid>
                        </Box>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </Box>
            );
          })}

          {/* Update */}
          {open && (
            <Dialog
              fullWidth
              open={open}
              onClose={handleClose}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
            >
              <Formik
                initialValues={{
                  comment: itemNotes.comment
                }}
                enableReinitialize
                onSubmit={async values => {
                  try {
                    const params = {
                      order_id: orderDetail.id,
                      history_id: itemNotes.id,
                      comment: values.comment
                    };
                    dispatch(putNotesStart({ params }));
                  } catch (error) {
                    console.log("error", error);
                  }
                }}
              >
                {({ values, handleSubmit, handleChange }) => {
                  return (
                    <form onSubmit={handleSubmit}>
                      <DialogTitle>{"Update Notes"}</DialogTitle>
                      <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                          <Typography>
                            Enter the text you want to edit
                          </Typography>
                          <TextField
                            fullWidth
                            name="comment"
                            onChange={handleChange}
                            size="small"
                            variant="outlined"
                            value={values.comment}
                            multiline
                          />
                        </DialogContentText>
                      </DialogContent>
                      <DialogActions>
                        <Button onClick={handleClose} color="primary">
                          Cancel
                        </Button>
                        <Button
                          disabled={isLoadingNotes}
                          type="submit"
                          color="primary"
                          autoFocus
                        >
                          Edit
                        </Button>
                      </DialogActions>
                    </form>
                  );
                }}
              </Formik>
            </Dialog>
          )}

          {/* Delete */}
          {openModalDelete && (
            <Dialog
              fullWidth
              open={openModalDelete}
              onClose={handleClose}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
            >
              <DialogTitle>{"Delete Notes"}</DialogTitle>
              <DialogContent>
                <DialogContentText id="alert-dialog-description">
                  <Typography>Do you want delete notes?</Typography>
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  Cancel
                </Button>
                <Button
                  onClick={handleClickDelete}
                  color="primary"
                  autoFocus
                  disabled={isLoadingNotes}
                >
                  Delete
                </Button>
              </DialogActions>
            </Dialog>
          )}
          {/* Create */}
          {openModalCreate && (
            <Dialog
              fullWidth
              open={openModalCreate}
              onClose={handleClose}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
            >
              <DialogTitle>{"Create A New Notes"}</DialogTitle>
              <DialogContent>
                <DialogContentText id="alert-dialog-description">
                  <Typography>Enter the text you want to create</Typography>
                  <TextField
                    fullWidth
                    name="comment"
                    onChange={handleChange}
                    size="small"
                    variant="outlined"
                    multiline
                  />
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  Cancel
                </Button>
                <Button
                  disabled={isLoadingNotes}
                  onClick={handleClickCreate}
                  color="primary"
                  autoFocus
                >
                  Create
                </Button>
              </DialogActions>
            </Dialog>
          )}
        </Box>
      </Paper>
    </Box>
  );
}
