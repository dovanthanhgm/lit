import {
  Box,
  CardHeader,
  Paper,
  Table,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from "@material-ui/core";
import PropTypes from "prop-types";
import React, { useMemo } from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import { tableHeadName } from "../../../constants/Order";
import { useSelector } from "react-redux";
import authService from "src/services/authService";
import OrderDetailRow from "src/views/management/OrderDetailsView/Modal/OrderDetail/OrderDetailRow";
// import RefundModal from "src/views/management/OrderDetailsView/Modal/OrderDetail/RefundModal";
// import ConfirmOrder from "src/views/management/OrderDetailsView/Modal/OrderDetail/ConfirmOrder";
// import CancelAllOrder from "src/views/management/OrderDetailsView/Modal/OrderDetail/CancelAllOrder";
// import UpdateAllOrderStatus from "src/views/management/OrderDetailsView/Modal/OrderDetail/UpdateAllOrderStatus";
import { makeStyles } from "@material-ui/styles";
// import { OrderProductsContext } from "src/views/management/OrderListView/Context/OrderProductsContext";

const useStyle = makeStyles(() => ({
  cardHeaderStyle: {
    paddingLeft: 0
  }
}));

function OrderItems({ order_id, orderDetail, warehouses, className, ...rest }) {
  const classes = useStyle();
  const { defaultListing } = useSelector(state => state.listing);
  const loginByToken = authService.getLoginByToken();
  // const { tab } = useContext(OrderProductsContext);

  const isBigChannel = useMemo(() => {
    return defaultListing.type === "bigcommerce";
  }, [defaultListing.type]);

  const isNotWalmartChannel = orderDetail?.channel_type !== "walmart";
  const newTableHeaderName = useMemo(() => {
    let initOrderCol = tableHeadName;
    if (!isBigChannel) {
      initOrderCol = initOrderCol.filter(item => item !== "Bin Picking Number");
    }
    // if (
    //   isNotWalmartChannel ||
    //   (orderDetail?.refund_order && orderDetail?.channel_type === "Walmart")
    // ) {
    //   initOrderCol = initOrderCol.filter(item => item !== "Actions");
    // }
    return initOrderCol;
    // eslint-disable-next-line
  }, [isBigChannel, isNotWalmartChannel]);

  return (
    <PerfectScrollbar>
      <Box mr={2} ml={2} minWidth={700}>
        <Box display="flex" alignItems="center" justifyContent={"flex-end"}>
          <Box flexGrow={1}>
            <CardHeader
              title="Items Ordered"
              className={classes.cardHeaderStyle}
            />
          </Box>
          {/*{(orderDetail.status === "completed" || tab === "refund_walmart") &&*/}
          {/*  orderDetail?.channel_type === "Walmart" && (*/}
          {/*    <RefundModal*/}
          {/*      channel_id={orderDetail.channel_id}*/}
          {/*      order_id={orderDetail.id}*/}
          {/*      orderNumber={orderDetail.channel_order_number}*/}
          {/*    />*/}
          {/*  )}*/}
          {/*{orderDetail.status === "open" &&*/}
          {/*  orderDetail?.channel_type === "Walmart" && (*/}
          {/*    <ConfirmOrder*/}
          {/*      channel_id={orderDetail.channel_id}*/}
          {/*      order_id={orderDetail.id}*/}
          {/*      orderNumber={orderDetail.channel_order_number}*/}
          {/*    />*/}
          {/*  )}*/}
          {/*{orderDetail?.channel_type === "Walmart" &&*/}
          {/*  ["ready_to_ship", "open"].includes(orderDetail?.status) && (*/}
          {/*    <CancelAllOrder*/}
          {/*      channel_id={orderDetail.channel_id}*/}
          {/*      order_id={orderDetail.id}*/}
          {/*      orderNumber={orderDetail.channel_order_number}*/}
          {/*    />*/}
          {/*  )}*/}
          {/*{orderDetail?.channel_type === "Walmart" &&*/}
          {/*  orderDetail?.status === "ready_to_ship" && (*/}
          {/*    <UpdateAllOrderStatus*/}
          {/*      channel_id={orderDetail.channel_id}*/}
          {/*      order_id={orderDetail.id}*/}
          {/*      orderNumber={orderDetail.channel_order_number}*/}
          {/*    />*/}
          {/*  )}*/}
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                {loginByToken && <TableCell>Product id</TableCell>}
                {newTableHeaderName.map((item, key) => (
                  <TableCell
                    key={key}
                    align={
                      ["Status", "Bin Picking Number", "Actions"].includes(item)
                        ? "center"
                        : ["Quantity", "Price", "Total"].includes(item)
                        ? "right"
                        : "left"
                    }
                    size="small"
                  >
                    {item}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <OrderDetailRow
              orderDetail={orderDetail}
              channelType={orderDetail?.channel_type}
            />
          </Table>
        </TableContainer>
      </Box>
    </PerfectScrollbar>
  );
}

OrderItems.propTypes = {
  className: PropTypes.string
};

export default OrderItems;
