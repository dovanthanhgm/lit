/* eslint-disable max-len */
import { IntegratedSelection, SelectionState } from "@devexpress/dx-react-grid";
import {
  Grid,
  Table,
  TableColumnResizing,
  TableHeaderRow,
  TableSelection
} from "@devexpress/dx-react-grid-material-ui";
import { Box, makeStyles, Typography } from "@material-ui/core";
import { useHistory, useParams } from "react-router";
import clsx from "clsx";
import { useSnackbar } from "notistack";
import React, { useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ButtonDelete from "src/components/Button/ButtonDelete";
import ListProductsonChannel from "src/components/Listings/ListProductsonChannel";
import { actionSetLimit } from "src/actions/product";
import authService from "src/services/authService";
import {
  deleteAllProductsAPI,
  deleteSomeProductsAPI
} from "src/services/products";
import useUserExp from "src/hooks/useUserExp";
import UpdateProduct from "src/components/Products/ListProdutcs/UpdateProduct";
import { useQueryV2 } from "src/hooks/useQuery";
import NoDataTable from "src/views/management/ProductListView/NoDataTable";
import { messageError } from "src/utils/ErrorResponse";
import CustomPagination from "src/components/MUI/CustomTable/CustomPagination";
import ProductLoading from "src/views/management/ProductEditView/ProductLoading";
import AllProductTableCell from "src/views/management/MainStore/Component/AllProductTableCell";

const useStyles = makeStyles(theme => ({
  root: {
    position: "relative"
  },
  queryField: {
    width: 500
  },
  image: {
    height: 48,
    width: 48
  },
  cartImage: {
    height: 24,
    width: 24,
    marginRight: theme.spacing(0.25)
  },
  name: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    overflow: "hidden"
  }
}));

const columns = [
  { name: "image", title: " " },
  { name: "name", title: "Name" },
  {
    name: "sku",
    title: "SKU"
  },
  { name: "origin", title: "Origin" },
  { name: "manage_stock", title: "Manage Stock" },
  {
    name: "is_in_stock",
    title: "In Stock"
  },
  { name: "qty", title: "Total Available" },
  { name: "variant_count", title: "Variants" },
  {
    name: "price",
    title: "Price"
  }
];

const widthColumn = {
  image: 80,
  sku: "11%",
  origin: "8%",
  manage_stock: 110,
  is_in_stock: 90,
  qty: 110,
  price: "6%",
  fulfilled: "8%",
  variant_count: "6%",
  updated_time: 130,
  active_listings: 160,
  name: "26%"
  // ((100 - 11 - 8 - 6 - 8 - 6) / 100) * widthScreen -
  // (80 + 110 + 90 + 110 + 130 + 160)
};
const extraColumn = [
  { name: "updated_time", title: "Last Modified" },
  {
    name: "active_listings",
    title: "Active listings"
  }
];

const tableColumnExtensions = [
  { columnName: "image" },
  {
    columnName: "name",
    wordWrapEnabled: false
  },
  { columnName: "sku", wordWrapEnabled: true },
  {
    columnName: "origin",
    wordWrapEnabled: true,
    align: "center"
  },
  { columnName: "manage_stock", align: "center", maxWidth: 50 },
  {
    columnName: "is_in_stock",
    align: "center",
    maxWidth: 50
  },
  { columnName: "qty", align: "center", maxWidth: 150 }, // { columnName: "bpn", align: "center", maxWidth: 150 },
  { columnName: "variant_count", align: "center", maxWidth: 100 },
  {
    columnName: "price",
    align: "center"
  },
  { columnName: "fulfilled", align: "left", maxWidth: 100 },
  {
    columnName: "updated_time",
    align: "right",
    wordWrapEnabled: true
  },
  { name: "active_listings", title: "Active listings", minWidth: 100 },
  {
    columnName: "active_listings",
    align: "right"
  }
];

const columnExtensions = [
  { columnName: "image" },
  { columnName: "name", wordWrapEnabled: true },
  {
    columnName: "sku",
    wordWrapEnabled: true
  },
  { columnName: "origin", wordWrapEnabled: true, align: "center" },
  {
    columnName: "manage_stock",
    align: "center"
  },
  { columnName: "is_in_stock", align: "center" },
  {
    columnName: "qty",
    align: "center"
  },
  { columnName: "variant_count", align: "center" },
  {
    columnName: "price",
    width: 120,
    align: "center"
  },
  { columnName: "fulfilled", align: "left", maxWidth: 100 },
  {
    columnName: "updated_time",
    width: 140,
    align: "right",
    wordWrapEnabled: true
  },
  { name: "active_listings", title: "Active listings", minWidth: 100 },
  {
    columnName: "active_listings",
    minWidth: 125
  }
];

function Results({
  className,
  products,
  page,
  limit,
  isMarket,
  total,
  loading,
  setLoading,
  changeChannel = () => {},
  getProducts
}) {
  const classes = useStyles();
  const { search } = useQueryV2();
  const { productId } = useParams();
  const { enqueueSnackbar } = useSnackbar();
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [disableButton, setDisableButton] = useState(false);
  const { listings, defaultListing } = useSelector(state => state.listing);
  const loginByToken = authService.getLoginByToken();
  const history = useHistory();
  const dispatch = useDispatch();

  const productTableColumn = useMemo(() => {
    if (["ebay"].includes(defaultListing?.type)) {
      return [
        ...columns,
        ...extraColumn.filter(col => col.name !== "updated_time")
      ];
    }
    if (!["amazon"].includes(defaultListing.type)) {
      return [...columns, ...extraColumn];
    }
    if (defaultListing.type === "amazon") {
      return [
        ...columns,
        { name: "fulfilled", title: "Fulfill by" },
        ...extraColumn
      ];
    }
  }, [defaultListing.type]);

  const productTableColumnExtension = useMemo(() => {
    if (!["amazon"].includes(defaultListing.type)) {
      return tableColumnExtensions.filter(
        item => item.columnName !== "fulfilled"
      );
    }
  }, [defaultListing]);

  const { expired } = useUserExp();

  const [columnWidths, setColumnWidths] = useState([
    { columnName: "image", width: widthColumn.image },
    {
      columnName: "name",
      width: widthColumn.name
    },
    { columnName: "sku", width: widthColumn.sku },
    { columnName: "origin", width: widthColumn.origin },
    {
      columnName: "manage_stock",
      width: widthColumn.manage_stock
    },
    { columnName: "is_in_stock", width: widthColumn.is_in_stock },
    { columnName: "qty", width: widthColumn.qty },
    {
      columnName: "price",
      width: widthColumn.price
    }, // { columnName: "bpn", width: "10%" },
    { columnName: "fulfilled", width: widthColumn.fulfilled },
    { columnName: "variant_count", width: widthColumn.variant_count },
    {
      columnName: "updated_time",
      width: widthColumn.updated_time
    },
    { columnName: "active_listings", width: widthColumn.active_listings }
  ]);

  const handlePageChange = (_, newPage) => {
    setLoading(true);
    const params = new URLSearchParams(search);
    if (newPage > 0) {
      params.set("page", newPage + 1);
      setSelectedProducts([]);
    } else {
      params.delete("page");
      setSelectedProducts([]);
    }

    if (productId) {
      history.push("/products?" + params.toString());
    } else {
      history.push({ search: params.toString(), stayPage: "stay" });
    }
  };

  const handleLimitChange = event => {
    handlePageChange(0, 0);
    setLoading(true);
    localStorage.setItem("rowPerPage", event.target.value);
    dispatch(actionSetLimit({ limit: event.target.value }));
    setSelectedProducts([]);
  };

  const handleConfirmDeleteSome = async () => {
    try {
      setLoading(true);
      await deleteSomeProductsAPI({ ids: selectedProducts });
      enqueueSnackbar("Delete success", {
        variant: "success"
      });
      getProducts();
      setLoading(false);
      setSelectedProducts([]);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  const handleConfirmDeleteAll = async () => {
    try {
      await deleteAllProductsAPI();
      enqueueSnackbar("Delete success", {
        variant: "success"
      });
      getProducts();
      setSelectedProducts([]);
    } catch (e) {
      enqueueSnackbar(messageError(e, "Delete failed!"), {
        variant: "error"
      });
    }
  };

  const handleSelectionChange = e => {
    setSelectedProducts(e);
  };

  const handleCustomPage = e => {
    handlePageChange(0, e.target.value);
  };

  return (
    <Box className={clsx(classes.root, className)}>
      <Box px={2}>
        <Box mt={2} mb={1} display="flex" alignItems="center">
          {!expired && (
            <Box
              display="flex"
              alignItems="center"
              mr={1}
              className="second-step"
            >
              <ListProductsonChannel
                listings={listings}
                handleChangeChannel={changeChannel}
                selectedProducts={selectedProducts}
              />
            </Box>
          )}
          <Box display="flex" mr={1}>
            <ButtonDelete
              buttonText="Delete"
              handleConfirm={handleConfirmDeleteSome}
              headerDialog="Are you sure?"
              contentDialog={
                <Typography color="textPrimary" variant="body1">
                  Are you sure you want to remove selected products?
                </Typography>
              }
              buttonTextSubmit="Yes, Remove"
              setDisableButton={setDisableButton}
              disabled={selectedProducts.length === 0 || disableButton}
            />
          </Box>
          {loginByToken && (
            <Box mr={1}>
              <ButtonDelete
                buttonText="Delete All"
                handleConfirm={handleConfirmDeleteAll}
                headerDialog="Are you sure?"
                contentDialog={
                  <Typography color="textPrimary" variant="body1">
                    Are you sure you want to remove all products?
                  </Typography>
                }
                buttonTextSubmit="Yes, Remove"
              />
            </Box>
          )}
          <Box>
            <UpdateProduct
              text={`Update From ${defaultListing?.type}`}
              selectedItems={selectedProducts}
              setSelectedItems={setSelectedProducts}
              disabled={disableButton}
              setDisableButton={setDisableButton}
            />
          </Box>
        </Box>

        <Typography color="textPrimary" variant="body2">
          {selectedProducts.length} products selected
        </Typography>
      </Box>

      <Box position="relative">
        <ProductLoading loading={loading} productLength={total} />
        <Grid
          rows={products}
          columns={productTableColumn}
          getRowId={row => {
            return isMarket ? row.publish_id : row.id;
          }}
        >
          <SelectionState
            selection={selectedProducts}
            onSelectionChange={handleSelectionChange}
          />
          <IntegratedSelection />
          <Table
            noDataRowComponent={() => (
              <NoDataTable isSearch={!!search} loading={loading} />
            )}
            columnExtensions={productTableColumnExtension}
            cellComponent={AllProductTableCell}
          />
          <TableColumnResizing
            columnWidths={columnWidths}
            onColumnWidthsChange={setColumnWidths}
            resizingMode="nextColumn"
            columnExtensions={columnExtensions}
          />
          <TableHeaderRow />
          <TableSelection showSelectAll />
        </Grid>

        <CustomPagination
          total={total}
          page={page - 1}
          limit={parseInt(localStorage.getItem("rowPerPage")) || limit}
          onPageChange={handlePageChange}
          onRowPerPageChange={handleLimitChange}
          onHandleCustomPageChange={handleCustomPage}
        />
      </Box>
    </Box>
  );
}

export default React.memo(Results);
