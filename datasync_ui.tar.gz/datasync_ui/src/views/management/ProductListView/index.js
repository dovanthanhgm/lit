import { Box, Card, Chip, Container, Tab, Tabs } from "@material-ui/core";
import React, { useState } from "react";
import Tour from "reactour";
import SingleAlert from "src/components/Notify/SingleAlert";
import Page from "src/components/Page";
import ProductDetailView from "src/views/pages/Product/ProductDetailView";
import AIOBar from "src/views/AIOBar";
import Header from "./Header";
import Results from "./Results";
import FilterAllProduct from "src/views/management/MainStore/DefaultMainStore/Body/FIlter/FilterAllProduct";
import Loading from "src/components/Loading/Loading";
import LoadingScreen from "src/components/Loading/LoadingScreen";
import Tutorial from "./Tutorial";
import { steps } from "src/constants/Product";
import useProductCustomHook from "../../../hooks/Product/productCustomHook";
import { useSelector } from "react-redux";
import { showAio } from "src/constants/index";
import ProductProvider from "src/context/ProductContext";

function ProductListView() {
  const { defaultListing } = useSelector(state => state.listing);
  const [productTab, setProductTab] = useState("instock");

  const {
    limit,
    isOpenTutorial,
    counts,
    loading,
    setColNameSort,
    colNameSort,
    setSort,
    total,
    products,
    classes,
    sort,
    setLoading,
    page,
    search,
    closeTour,
    paramFilter,
    setParamFilter,
    listError,
    renderTab,
    changeChannel,
    productMatch,
    getProducts,
    handleChangeProductTab,
    load,
    setCountSuccess
  } = useProductCustomHook({ setProductTab, productTab });

  if (!products || !defaultListing) {
    return <LoadingScreen />;
  }

  return (
    <Page className={classes.root} title="Product List">
      <Tour
        steps={steps}
        isOpen={isOpenTutorial}
        onRequestClose={closeTour}
        disableInteraction
        rounded={4}
        closeWithMask={false}
      />
      {load && <Loading />}
      <Container style={{ padding: "0 12px" }} maxWidth={false}>
        <Header
          paramFilter={paramFilter}
          isProduct
          productMatch={productMatch}
          getProduct={getProducts}
        />
        <Tutorial />
        {!!listError && (
          <Box mt={2}>
            <SingleAlert content={listError} type={"warning"} />
          </Box>
        )}
        <Box mt={3}>
          <Card>
            <FilterAllProduct
              setParamFilter={setParamFilter}
              setSort={setSort}
              setColNameSort={setColNameSort}
              setCountSuccess={setCountSuccess}
            />

            {renderTab?.length > 0 && (
              <Tabs onChange={handleChangeProductTab} value={productTab}>
                {renderTab?.map((tab, index) => {
                  return (
                    <Tab
                      size="small"
                      classes={{
                        root: classes.tabRoot
                      }}
                      disabled={counts?.[tab.value] === 0}
                      key={tab?.value || index}
                      value={tab?.value || ""}
                      label={
                        <Box
                          display="flex"
                          alignItems={"center"}
                          justifyContent="center"
                        >
                          {tab?.name}
                          <Chip
                            size="small"
                            label={counts?.[tab.value]}
                            color="primary"
                            classes={{ labelSmall: classes.labelSmall }}
                            className={classes.chip}
                          />
                        </Box>
                      }
                    />
                  );
                })}
              </Tabs>
            )}

            <ProductProvider>
              <>
                <ProductDetailView />

                <Results
                  products={products}
                  page={page}
                  limit={limit}
                  total={total}
                  sort={sort}
                  setColNameSort={setColNameSort}
                  setSort={setSort}
                  colNameSort={colNameSort}
                  loading={loading}
                  setLoading={setLoading}
                  search={search}
                  changeChannel={changeChannel}
                  getProducts={getProducts}
                />
              </>
            </ProductProvider>
          </Card>
        </Box>
      </Container>
      {showAio && <AIOBar />}
    </Page>
  );
}

export default ProductListView;
