import {
  Box,
  Button,
  makeStyles,
  Tooltip,
  Typography,
  useTheme
} from "@material-ui/core";
import clsx from "clsx";
import PropTypes from "prop-types";
import React, { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router";
import { convertIdToName } from "src/utils/helper";
import SingleAlert from "src/components/Notify/SingleAlert";
import { Link } from "react-router-dom";
import { getStatusCode } from "src/services/channel";
import { useDispatch } from "react-redux";
import { showImportAlert } from "src/actions/listingActions";
import ExportProduct from "./ExportProduct";
import BulkUpdate from "./BulkUpdate";
import useUserExp from "src/hooks/useUserExp";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import { importTimeAgo } from "src/constants/Product/index";
import HelpIcon from "@material-ui/icons/Help";

const useStyles = makeStyles(theme => ({
  root: {},
  actionIcon: {
    marginRight: theme.spacing(1)
  },
  cartImage: {
    width: 32,
    height: 32
  },
  button: {
    marginLeft: theme.spacing(1)
  },
  wixImage: {
    width: 62,
    height: 25
  },
  wishImage: {
    width: 60,
    height: 20
  },
  link: {
    textDecoration: "none"
  }
}));

function Header({
  className,
  setPageTotal,
  paramFilter,
  productMatch,
  isProduct,
  getProduct = function() {},
  ...rest
}) {
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const theme = useTheme();
  const { defaultListing } = useSelector(state => state.listing);
  const initUpdate = [1, "1"].includes(defaultListing?.auto_update);
  const { user } = useSelector(state => state.account);
  const isShowButton = defaultListing?.type !== "file";
  const lastImport = defaultListing?.last_imported;
  const [process, setProcess] = useState();

  const channelImage = {
    wix: classes.wixImage,
    wish: classes.wishImage
  };

  const importFromChannel = async () => {
    history.push(`/import-data/listings/${defaultListing?.id}`);
  };
  const { expired } = useUserExp();

  useEffect(() => {
    const getStatus = async () => {
      const res = await getStatusCode(defaultListing.id);
      if (res) {
        setProcess(res);
      }
    };
    getStatus();
    const interval = setInterval(() => {
      if (!document.hidden) {
        getStatus();
      }
    }, 60000);

    return () => {
      dispatch(showImportAlert(false));
      clearInterval(interval);
    };
  }, [defaultListing, dispatch]);

  const isCallProduct = useMemo(() => {
    return ["pushing", "pulling"].includes(process?.[0]?.status);
  }, [process]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isCallProduct) {
        getProduct(true);
      }
    }, 60000);

    return () => {
      clearInterval(interval);
    };
  }, [isCallProduct, getProduct]);

  return (
    <>
      {process?.[0]?.status === "pulling" && (
        <Box mb={3}>
          <SingleAlert
            type="info"
            content={
              <>
                <Box>
                  We'll import your Main Store as quickly as possible, but it
                  may be take some time.
                </Box>
                <Box>
                  You can navigate away from this page - importing won't be
                  affected. We'll notify you when it's done.{" "}
                  <Link to={"/activities"} className={classes.link}>
                    more detail
                  </Link>
                </Box>
              </>
            }
          />
        </Box>
      )}
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        className={clsx(classes.root, className)}
        {...rest}
      >
        <Box flexGrow={1} display="flex" alignItems="center">
          <CartLogo
            id={defaultListing?.type}
            isDefault
            className={
              channelImage?.[defaultListing?.type] || classes.cartImage
            }
          />
          <Typography
            variant="h3"
            color="textPrimary"
            component="span"
            style={{ marginLeft: 8 }}
          >
            All Products
          </Typography>
        </Box>

        {lastImport && (
          <Box display="flex" alignItems="center">
            <Typography variant="body2">
              Last imported {importTimeAgo(lastImport)}
            </Typography>
            &nbsp;
            <Tooltip
              title={
                defaultListing?.type === "file"
                  ? "The last time file was imported into LitCommerce"
                  : "The last time new products were imported into LitCommerce"
              }
            >
              <span>
                <HelpIcon fontSize="small" color="primary" />
              </span>
            </Tooltip>
          </Box>
        )}
        {isProduct && (
          <Box display="flex" alignItems="center" mx={2}>
            <Typography variant="h6" component="span">
              Automatic update:&nbsp;
            </Typography>
            <Box
              color={
                initUpdate
                  ? theme.palette.primary.main
                  : theme.palette.error.main
              }
            >
              {initUpdate && <Typography variant="h6">Enabled</Typography>}
              {!initUpdate && <Typography variant="h6">Disabled</Typography>}
            </Box>
          </Box>
        )}
        {user?.enable_bulk_edit && (
          <>
            {!expired && (
              <ExportProduct
                paramFilter={paramFilter}
                productMatch={productMatch}
              />
            )}
            {/*{!expired && (*/}
            {/*  <Box ml={1.5}>*/}
            {/*    <BulkUpdate />*/}
            {/*  </Box>*/}
            {/*)}*/}
          </>
        )}

        {isShowButton && (
          <Box ml={1.5}>
            <Tooltip title={"Import new products from Main Store."}>
              <span>
                <Button
                  color="primary"
                  variant="contained"
                  size="small"
                  onClick={importFromChannel}
                  className="first-step"
                  disabled={expired}
                >
                  {`Import From ${convertIdToName(defaultListing.type)}`}
                </Button>
              </span>
            </Tooltip>
          </Box>
        )}
        <Box ml={1.5}>
          <Button
            color="primary"
            variant="contained"
            size="small"
            onClick={() => history.push("/source-cart")}
            className="first-step"
          >
            Settings
          </Button>
        </Box>
      </Box>
    </>
  );
}

Header.propTypes = {
  className: PropTypes.string
};

export default Header;
