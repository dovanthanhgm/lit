import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  Link,
  makeStyles,
  Typography
} from "@material-ui/core";
import DialogTitle from "../../../../components/Modal/DialogTitle";
import Grey from "@material-ui/core/colors/grey";
import { useSnackbar } from "notistack";
import {
  getBulkUpdateProcess,
  uploadBulkApi
} from "../../../../services/products";
import ButtonCustom from "../../../../components/MUI/Button";
import { Alert, AlertTitle } from "@material-ui/lab";
import { useSelector } from "react-redux";
import UseDragAndUploadFile from "../../../../hooks/useDragAndUploadFile";

const borderColor = Grey[400];

const useStyles = makeStyles(theme => ({
  uploadButton: {
    cursor: "pointer",
    textTransform: "none"
  },
  fileContainer: {
    minHeight: 200,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderColor: borderColor,
    borderStyle: "dashed"
  }
}));

export default function BulkUpdate() {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const { defaultListing } = useSelector(state => state?.listing);
  const [openBulkUpdate, setOpenBulkUpdate] = useState(false);
  const {
    dropHandler,
    handleChangeFile,
    setFile,
    file,
    dragOverHandler
  } = UseDragAndUploadFile({ enqueueSnackbar });
  const [errorUpload, setErrorUpload] = useState("");
  const [loadingUpload, setLoadingUpload] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [processId, setProcessId] = useState(null);
  const [bulkStatus, setBulkStatus] = useState(null);

  const productChannelId = defaultListing?.id;
  const localProcessIdByChannel = localStorage.getItem(defaultListing?.id);

  const handleBulkModal = () => {
    setOpenBulkUpdate(!openBulkUpdate);
    setFile(null);
  };

  const handleUploadBulk = async () => {
    setLoadingUpload(true);
    setErrorUpload("");
    try {
      const res = await uploadBulkApi({ file });
      setUploadComplete(true);
      setProcessId(res?.process_id);
      setBulkStatus("pulling");
      setFile(null);
      localStorage.setItem(defaultListing?.id, res?.process_id);
    } catch (e) {
      setFile(null);
      const errorMessage =
        e?.response?.data?.message ||
        e?.response?.data?.errors ||
        "error upload";
      setErrorUpload(errorMessage);
    }
    setLoadingUpload(false);
  };

  const getBulkProcessStatus = async () => {
    const processID = processId ?? localProcessIdByChannel;
    const processStatus = await getBulkUpdateProcess({ processId: processID });

    if (processStatus) {
      setBulkStatus(processStatus?.status);
      setUploadComplete(processStatus?.status === "pulling");
      if (processStatus?.status !== "pulling") {
        localStorage.removeItem(defaultListing?.id);
        setProcessId(null);
      }
    }
  };

  useEffect(() => {
    if (processId || localProcessIdByChannel) {
      const interval = setInterval(() => {
        getBulkProcessStatus();
      }, 30000);

      return () => {
        clearInterval(interval);
      };
    }
    // eslint-disable-next-line
  }, [processId, localProcessIdByChannel]);

  useEffect(() => {
    if (productChannelId && localProcessIdByChannel) {
      getBulkProcessStatus();
    }
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    if (productChannelId && productChannelId !== localProcessIdByChannel) {
      localStorage.removeItem(productChannelId);
    }
  }, [productChannelId, localProcessIdByChannel]);

  return (
    <Box>
      <Button
        color="primary"
        variant="contained"
        size="small"
        onClick={handleBulkModal}
        className="first-step"
      >
        Bulk Update
      </Button>
      <Dialog
        fullWidth
        onClose={handleBulkModal}
        aria-labelledby="customized-dialog-title"
        open={openBulkUpdate}
      >
        <DialogTitle
          id="customized-dialog-title"
          onClose={handleBulkModal}
          children={"Export products"}
        >
          {uploadComplete && bulkStatus === "pulling"
            ? "Bulk update in progress"
            : "Bulk Update by CSV"}
        </DialogTitle>
        <DialogContent dividers>
          {errorUpload && (
            <Box mb={1}>
              <Alert severity="error">
                <AlertTitle>Error</AlertTitle>
                {errorUpload}
              </Alert>
            </Box>
          )}
          {!uploadComplete && bulkStatus !== "pulling" && (
            <Box>
              <Typography>
                Use CSV file exported in Bulk Edit format to bulk update your
                product list. Only fields in the file will be updated. Updated
                products will be automatically sync to all your channels.
              </Typography>
              <Box
                border={1}
                borderRadius={4}
                className={classes.fileContainer}
                mt={1}
                id="drop_zone"
                onDrop={dropHandler}
                onDragOver={dragOverHandler}
              >
                {!file && (
                  <Box textAlign="center">
                    <Button
                      variant="contained"
                      component="label"
                      size="small"
                      className={classes.uploadButton}
                    >
                      Add file
                      <input
                        type="file"
                        hidden
                        onChange={handleChangeFile}
                        accept=".csv, text/csv"
                      />
                    </Button>
                    <Box mt={1}>
                      <Typography>or drag it here.</Typography>
                      <Box mt={1}>
                        <Typography variant="body2" color="textSecondary">
                          Max of 10MB and 100,000 rows
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                )}
                {file && (
                  <Box textAlign="center">
                    <Typography variant="h5">{file?.name}</Typography>
                    <Typography>
                      Upload another{" "}
                      <Link component="label" style={{ cursor: "pointer" }}>
                        file{" "}
                        <input type="file" hidden onChange={handleChangeFile} />
                      </Link>{" "}
                      or drag another file here{" "}
                    </Typography>
                    <Box mt={1}>
                      <Typography variant="body2" color="textSecondary">
                        Max of 10MB and 100,000 rows
                      </Typography>
                    </Box>
                  </Box>
                )}
              </Box>
            </Box>
          )}
          {uploadComplete && bulkStatus === "pulling" && (
            <Box>
              <Typography variant="h5">
                We’re currently updating your products in LitCommerce
              </Typography>
              <Box mt={1}>
                <Typography>
                  This could take some time to complete. If you’d like, you can
                  close thi dialog box and continue working
                </Typography>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            onClick={handleBulkModal}
            variant="contained"
            // color="primary"
            size="small"
          >
            {uploadComplete ? "Close" : "Cancel"}
          </Button>
          {!uploadComplete && (
            <ButtonCustom
              text=" Upload and continue"
              onClick={handleUploadBulk}
              variant="contained"
              color="primary"
              notShowCircle={!loadingUpload}
              disabled={loadingUpload || !file}
              size="small"
            />
          )}
        </DialogActions>
      </Dialog>
    </Box>
  );
}
