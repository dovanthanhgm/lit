import React from "react";
import { Box, Typography } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import { useQueryV2 } from "src/hooks/useQuery";
import { useSelector } from "react-redux";

const NoDataTable = () => {
  const { search } = useQueryV2();
  const { loadingProductTable } = useSelector(state => state.product);

  const notFoundMessage = () => {
    if (loadingProductTable) {
      return "";
    }
    return !!search ? (
      <Box textAlign="center" pt={1} pb={1}>
        <SearchIcon fontSize="large" style={{ width: 64, height: 64 }} />
        <Typography variant="h5">No products found</Typography>
        <Box my={1} />
        <Typography variant="body2">
          Try changing the filters or search term
        </Typography>
      </Box>
    ) : (
      <Typography variant="h5">No data</Typography>
    );
  };

  return (
    <tr style={{ height: 160 }}>
      <td
        style={{
          padding: 4,
          paddingBottom: 8,
          position: "absolute",
          top: "55%",
          left: "50%",
          transform: "translate(-50%,-40%)"
        }}
      >
        {notFoundMessage()}
      </td>
    </tr>
  );
};

export default NoDataTable;
