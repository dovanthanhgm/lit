import React from "react";
import { Box, CircularProgress } from "@material-ui/core";

const LoadingProduct = () => {
  return (
    <Box
      zIndex={1000}
      width="100%"
      position={"absolute"}
      textAlign={"center"}
      style={{ height: "calc(100% - 60px)" }}
    >
      <CircularProgress style={{ position: "fixed", top: "50%" }} />
    </Box>
  );
};

export default LoadingProduct;
