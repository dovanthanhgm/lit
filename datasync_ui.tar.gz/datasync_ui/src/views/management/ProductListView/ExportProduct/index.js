import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography
} from "@material-ui/core";
import React, { useState } from "react";
import DialogTitle from "../../../../components/Modal/DialogTitle";
import { exportProduct } from "src/services/manage";
import { useSnackbar } from "notistack";
import ModalExportNotifi from "../../../../components/Modal/ModalImportExport/ModalExportNotifi";
import ButtonCustom from "../../../../components/MUI/Button";

const title = "Export Product Data to CSV";

export default function ExportProduct({ productMatch = 0, paramFilter }) {
  const { enqueueSnackbar } = useSnackbar();
  const [openModal, setOpenModal] = useState();
  const [exportValue, setExportValue] = useState("all");
  const [ExportFieldValue, setExportFieldValue] = useState("bulk");
  const [exportNotify, setExportNotify] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);

  const handleShowExportModal = () => {
    setOpenModal(!openModal);
  };

  const handleExportModal = () => {
    setExportNotify(!exportNotify);
  };

  const handleExportButton = async () => {
    const mapFieldValue = {
      bulk: true,
      full: false
    };

    const exportParams = () => {
      if (exportValue === "all") {
        return {};
      }
      // return object only have value !== ""
      return Object.keys(paramFilter)
        .filter(k => paramFilter[k] !== "")
        .reduce((a, k) => ({ ...a, [k]: paramFilter[k] }), {});
    };

    try {
      setExportLoading(true);
      const body = {
        bulk_edit: mapFieldValue[ExportFieldValue],
        filter: exportParams()
      };
      await exportProduct({ body });
      setExportNotify(true);
    } catch (e) {
      console.log(e);
      enqueueSnackbar(
        e?.response?.data?.message ??
          e?.response?.data?.errors ??
          "error delete",
        {
          variant: "error"
        }
      );
    }
    handleShowExportModal();
    setExportLoading(false);
  };

  const handleChangeExport = event => {
    setExportValue(event.target.value);
  };

  const handleChangeFieldExport = event => {
    setExportFieldValue(event.target.value);
  };

  return (
    <Box>
      <Button
        color="primary"
        variant="contained"
        size="small"
        onClick={handleShowExportModal}
        className="first-step"
      >
        Export
      </Button>
      <Dialog
        fullWidth
        onClose={handleShowExportModal}
        aria-labelledby="customized-dialog-title"
        open={openModal}
      >
        <DialogTitle
          id="customized-dialog-title"
          onClose={handleShowExportModal}
          children={"Export products"}
        >
          Export products
        </DialogTitle>
        <DialogContent dividers>
          <Box mt={2} />
          <Typography variant="h5">Export</Typography>
          <FormControl component="fieldset">
            <RadioGroup
              aria-label="Export"
              name="export"
              value={exportValue}
              onChange={handleChangeExport}
            >
              <FormControlLabel
                value="matching"
                control={<Radio />}
                label={`${productMatch} products matching your search`}
              />
              <FormControlLabel
                value="all"
                control={<Radio />}
                label="All products"
              />
            </RadioGroup>
          </FormControl>
          <Box mt={2} />
          <Typography variant="h5">Export fields</Typography>
          <FormControl component="fieldset">
            <RadioGroup
              aria-label="Export"
              name="export"
              value={ExportFieldValue}
              onChange={handleChangeFieldExport}
            >
              <FormControlLabel
                value="bulk"
                control={<Radio />}
                label="Bulk Edit - for Editing and importing later"
              />
              <FormControlLabel
                value="full"
                control={<Radio />}
                label="Full fields - export everything, can not be used for importing"
              />
            </RadioGroup>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button
            autoFocus
            onClick={handleShowExportModal}
            variant="contained"
            size="small"
          >
            Cancel
          </Button>
          <ButtonCustom
            onClick={handleExportButton}
            variant="contained"
            color="primary"
            size="small"
            disabled={exportLoading}
            notShowCircle={!exportLoading}
            text="Export products"
          />
        </DialogActions>
      </Dialog>
      <ModalExportNotifi
        open={exportNotify}
        title={title}
        handleClose={handleExportModal}
      />
    </Box>
  );
}
