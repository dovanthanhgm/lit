import React, { useContext, useEffect, useState } from "react";
import {
  Box,
  FormControl,
  ListSubheader,
  makeStyles,
  MenuItem,
  Select,
  Tooltip,
  Typography
} from "@material-ui/core";
import { MenuPropsCustom } from "../../../../constants";
import {
  DRAFT_VALUE,
  ERROR_VALUE,
  groupButtonItemPadding
} from "../../../../constants/Listing";
import { AllProductCountContext } from "../../MainStore/Context/AllProductCountContext";
import { useSelector } from "react-redux";
import useUserExp from "../../../../hooks/useUserExp";
import { convertIdToName } from "../../../../utils/helper";
import { actionByChannel } from "src/components/Listings/constants";

const draftErrorStatus = [DRAFT_VALUE, ERROR_VALUE];

const useStyles = makeStyles(theme => ({
  select: {
    marginRight: theme.spacing(1),
    "& .MuiSelect-root": { paddingTop: 8.5, paddingBottom: 8.5 },
    "& .MuiMenu-list": {
      paddingRight: 0
    },
    "& .MuiOutlinedInput-input": {
      paddingLeft: 4
    }
  },
  rootScroll: {
    "&::-webkit-scrollbar": {
      width: "0.6em"
    },
    "&::-webkit-scrollbar-track": {
      boxShadow: "inset 0 0 6px rgba(0,0,0,0.00)",
      webkitBoxShadow: "inset 0 0 6px rgba(0,0,0,0.00)"
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: "rgba(0,0,0,.3)",
      borderRadius: 10
    }
  },
  nameOverFlow: {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  }
}));

const ShowListActionBaseOnChannel = ({ channel = [], title }) => {
  return [
    <ListSubheader
      disableGutters={false}
      disableSticky
      color="inherit"
      key={title}
    >
      <Box px={0} py={1.5}>
        <Typography variant="h6" style={{ color: "#757575" }}>
          {title}
        </Typography>
      </Box>
    </ListSubheader>,
    channel.map(item => {
      return (
        <MenuItem key={item.value} value={item.value} name={item.name}>
          <Box pl={groupButtonItemPadding} key={item.value}>
            <Typography variant="body2">{item.name}</Typography>
          </Box>
        </MenuItem>
      );
    })
  ];
};

const GroupOptionActionProducts = ({
  disabled,
  handleChangeAction,
  actionSelect
}) => {
  const classes = useStyles();
  const { tab: currentTab } = useContext(AllProductCountContext);
  const { defaultListing } = useSelector(state => state?.listing);
  const channelType = defaultListing.type;
  const { isUserFree } = useUserExp();

  const hideInDraftError = !draftErrorStatus.includes(currentTab);
  const hideSyncChannel = !["amazon", "walmartca"].includes(channelType);

  const [selectValue, setSelectValue] = useState("");

  const handleChange = e => {
    const value = e.target.value;
    if (![undefined, null].includes(value)) {
      setSelectValue(e.target.value);
      handleChangeAction(e.target.value);
    }
  };

  const showUpdateFrom = hideInDraftError && hideSyncChannel;
  const nameByChannelType = convertIdToName(channelType);

  useEffect(() => {
    setSelectValue(actionSelect);
  }, [actionSelect]);

  if (!channelType) return null;

  return (
    <FormControl
      className={classes.select}
      variant="outlined"
      size="small"
      disabled={disabled}
    >
      <Select
        value={selectValue}
        id="grouped-select"
        onChange={handleChange}
        displayEmpty
        MenuProps={{
          PaperProps: {
            style: {
              maxHeight: 400
            },
            className: classes.rootScroll
          },
          ...MenuPropsCustom
        }}
      >
        <MenuItem value={""}>
          <Box pl={groupButtonItemPadding}>
            <Typography variant="body2">Select Action</Typography>
          </Box>
        </MenuItem>
        {showUpdateFrom && hideInDraftError && (
          <MenuItem
            value="sync"
            style={{ opacity: isUserFree ? 0.5 : 1, cursor: "default" }}
            name="sync"
          >
            <Tooltip
              title={
                isUserFree
                  ? "This feature is only available for paid customers"
                  : ""
              }
            >
              <Box
                pl={groupButtonItemPadding}
                onClick={() => {
                  if (!isUserFree) {
                    handleChangeAction("sync");
                    setSelectValue("sync");
                  }
                }}
              >
                <Typography variant="body2">
                  Update From {nameByChannelType}
                </Typography>
              </Box>
            </Tooltip>
          </MenuItem>
        )}
        {Object.keys(actionByChannel).includes(channelType) &&
          ShowListActionBaseOnChannel({
            title: actionByChannel[channelType]?.title,
            channel: actionByChannel[channelType]?.option
          })}
      </Select>
    </FormControl>
  );
};

export default GroupOptionActionProducts;
