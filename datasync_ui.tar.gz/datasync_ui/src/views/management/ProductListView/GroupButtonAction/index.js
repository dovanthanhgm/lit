import React, { useContext, useState } from "react";
import { useSelector } from "react-redux";
import { useSnackbar } from "notistack";
import { SelectedProductContext } from "../../MainStore/Context/SelectedProductContext";
import { LISTING_DETAIL_LIST_ACTION } from "src/constants/Listing/index";
import { renewListing, syncFromChannel } from "src/services/channel";
import { Box } from "@material-ui/core";
import CustomizedDialogs from "../../../../components/Modal/ModalChannel/ListingDialog";
import DeleteListingModal from "../../ListingDetail/components/ListingModal/DeleteListing";
import ListingDetailRun from "../../../../components/Button/ListingDetailRun";
import DeleteSome from "../../ListingDetail/GroupBulkButton/DeleteSome";
import MultiEditButton from "../../ListingDetail/GroupBulkButton/MultiEditButton";
import GroupOptionActionProducts from "./GroupOptionAction";
import { AllProductProcessContext } from "../../MainStore/Context/AllProductProcessContext";

const GroupButtonActionProductsMainMarket = () => {
  const { enqueueSnackbar } = useSnackbar();
  const { selectedProduct, setSelectedProduct } = useContext(
    SelectedProductContext
  );
  const { setProcess, setTimeCall, setLimit } = useContext(
    AllProductProcessContext
  );

  const { defaultListing } = useSelector(state => state?.listing);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [actionSelect, setActionSelect] = useState("");
  const [dialogMiss, setDialogMiss] = useState([]);
  const [disableButton, setDisableButton] = useState(false);

  const channelID = defaultListing?.id;

  const handleRenewListing = async action => {
    try {
      await renewListing({
        channel_id: channelID,
        product_ids: selectedProduct,
        action
      });
      setSelectedProduct([]);
      setProcess([{ id: channelID, status: "pulling" }]);
      setTimeCall(121000);
      setLimit(5);
    } catch (e) {
      console.log("error", e);
    }
  };

  const handleSyncFrom = async () => {
    try {
      // syncSelected have to change when syncName change
      await syncFromChannel({
        productList: selectedProduct,
        channelId: channelID
      });
      setSelectedProduct([]);
      setProcess([{ id: channelID, status: "pulling" }]);
      setTimeCall(121000);
      setLimit(5);
      enqueueSnackbar(
        "Request sent successfully. The products you choose will be synced to LitCommerce in a few minutes",
        {
          variant: "success"
        }
      );
    } catch (e) {
      console.log(e);
      enqueueSnackbar("Error", {
        variant: "error"
      });
    }
  };

  const openDeleteAllDialog = () => {
    setOpenDeleteDialog(true);
  };

  const onDeleteSomeSuccess = () => {
    enqueueSnackbar("Delete success", {
      variant: "success"
    });
    setDisableButton(true);
    setSelectedProduct([]);
    // getData();
  };

  const handleChangeAction = event => {
    setActionSelect(event);
    setDisableButton(selectedProduct.length <= 0);
  };

  const handleActionButton = async (runAction = "") => {
    const action = {
      [LISTING_DETAIL_LIST_ACTION.delete_listing]: () => openDeleteAllDialog(),
      [LISTING_DETAIL_LIST_ACTION.sync]: () => handleSyncFrom(),
      [LISTING_DETAIL_LIST_ACTION.end]: () => handleRenewListing("end"),
      [LISTING_DETAIL_LIST_ACTION.relist]: () => handleRenewListing("relist"),
      [LISTING_DETAIL_LIST_ACTION.renew]: () => handleRenewListing("renew")
    };

    return Object.keys(action).includes(runAction)
      ? action?.[runAction]?.() && setActionSelect("")
      : null;
  };

  return (
    <React.Fragment>
      <Box display="flex" alignItems="center" mx={0.5}>
        {dialogMiss && (
          <CustomizedDialogs
            handleClose={() => setDialogMiss([])}
            handleConfirm={() => setDialogMiss([])}
            open={dialogMiss && dialogMiss?.length > 0}
            values={dialogMiss}
            channelId={channelID}
          />
        )}

        {openDeleteDialog && (
          <DeleteListingModal
            channelType={defaultListing.type}
            isOpenDialogDeleteAll={openDeleteDialog}
            handleCloseDeleteDialog={() => setOpenDeleteDialog(false)}
            onDeleteSomeSuccess={onDeleteSomeSuccess}
            channelID={channelID}
          />
        )}

        <Box display="flex" alignItems="center" width="100%" flexGrow={1}>
          <GroupOptionActionProducts
            selectedItems={selectedProduct}
            actionSelect={actionSelect}
            disabled={selectedProduct.length === 0}
            handleChangeAction={handleChangeAction}
          />

          <ListingDetailRun
            actionSelect={actionSelect}
            handleAction={handleActionButton}
            channelID={channelID}
            channelType={defaultListing.type}
            handleDisableActionButton={
              disableButton || selectedProduct.length <= 0 || !actionSelect
            }
          />

          <DeleteSome
            channelID={channelID}
            selectedItems={selectedProduct}
            onDeleteSomeSuccess={onDeleteSomeSuccess}
          />
        </Box>

        <MultiEditButton />
      </Box>
    </React.Fragment>
  );
};

export default GroupButtonActionProductsMainMarket;
