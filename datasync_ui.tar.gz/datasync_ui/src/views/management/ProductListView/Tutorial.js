import { Box } from "@material-ui/core";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { goTutorial } from "src/actions/accountActions";
import TutorialDialogs from "src/components/Modal/TutorialDialog";

function ProductListView() {
  const dispatch = useDispatch();
  const [open, setOpen] = useState(true);

  const { go_tutorial } = useSelector((state) => state.account);

  const handleClose = () => {
    setOpen(false);
    dispatch(goTutorial(false));
  };

  return (
    <Box>
      {go_tutorial && (
        <TutorialDialogs
          handleClose={handleClose}
          open={open}
          tab="listing"
        />
      )}
    </Box>
  );
}

export default ProductListView;
