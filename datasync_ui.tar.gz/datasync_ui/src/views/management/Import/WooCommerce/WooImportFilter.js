import React, { useEffect, useState } from "react";
import {
  IMPORT_ALL_STATUS,
  WOO_CATEGORY_IMPORT,
  WOO_CATEGORY_VALUE,
  WOO_PRODUCT_ID,
  WOO_PRODUCT_IDS_VALUE,
  WOO_PRODUCT_TAG_VALUE,
  WOO_STATUS_VALUE,
  WOO_STOCK_STATUS,
  WOO_STOCK_STATUS_VALUE,
  WOO_TAG_IMPORT
} from "src/constants/importFromChannel";
import { useField } from "formik";
import {
  Box,
  FormControl,
  IconButton,
  MenuItem,
  Select,
  TableCell,
  TableRow,
  Tooltip, Typography
} from "@material-ui/core";
import AddTagsAndMaterial from "src/components/Template/Etsy/Category/Advance/AddTagsAndMaterial";
import { makeStyles } from "@material-ui/styles";
import WooStatusImport from "src/views/management/Import/WooCommerce/WooStatusImport";
import { wooImportSearchTags } from "src/services/manage";
import WooTagImportFilter from "src/views/management/Import/WooCommerce/WooTagImportFilter";
import WooCategoryFilter from "src/views/management/Import/WooCommerce/WooCategoryFilter";
import WooStockStatusFilter from "src/views/management/Import/WooCommerce/WooStockStatusFilter";
import RefreshIcon from "@material-ui/icons/Refresh";

const useStyles = makeStyles(theme => ({
  menuText: {
    ...theme.typography.body2
  }
}));

const optionList = [
  { value: IMPORT_ALL_STATUS, name: "Import all products" },
  {
    name: "Import product by Tag",
    value: WOO_PRODUCT_TAG_VALUE
  },
  { name: "Import product by Category", value: WOO_CATEGORY_VALUE },
  {
    name: "Import product by Status",
    value: WOO_STATUS_VALUE
  },
  { name: "Import product by Stock Status", value: WOO_STOCK_STATUS_VALUE },
  { name: "Import product by Product Id(s)", value: WOO_PRODUCT_IDS_VALUE }
];

const WooImportFilter = ({ channelID }) => {
  const classes = useStyles();

  const [filter, setFilter] = useState(IMPORT_ALL_STATUS);
  const [tags, setTags] = useState([]);
  const [loadingTag, setLoadingTag] = useState(true);
  const [tagCount, setTagCount] = useState(1);

  const [, , { setValue: setInitOption }] = useField("channel_option_filter");
  const [, , { setValue: setImportType }] = useField("imported_type");

  const handleChange = e => {
    setFilter(e.target.value);
    setInitOption(e.target.value);
  };

  useEffect(() => {
    setInitOption(IMPORT_ALL_STATUS);
    setImportType("publish");
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    const getWooTag = async () => {
      setLoadingTag(true);
      const request = await wooImportSearchTags({ channelID });
      if (request) {
        setTags(request);
        setLoadingTag(false);
      }
    };

    getWooTag().catch(e => {
      console.log(e);
      setLoadingTag(false);
    });
  }, [channelID, tagCount]);

  return (
    <TableRow>
      <TableCell
        style={{
          borderBottom: "none"
        }}
      >
        <Typography variant={"h6"}>Filter</Typography>
        <Box mt={2} mb={2}>
          <FormControl variant="outlined" size="small">
            <Select value={filter} onChange={handleChange}>
              {optionList.map(item => {
                return (
                  <MenuItem
                    value={item.value}
                    key={item.value}
                    className={classes.menuText}
                  >
                    {item.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        </Box>
        {filter === WOO_PRODUCT_TAG_VALUE && (
          <Box mb={1} display={"flex"} alignItems={"center"}>
            <Box flexGrow={1}>
              <WooTagImportFilter
                channelID={channelID}
                name={WOO_TAG_IMPORT}
                tags={tags}
                loadingTag={loadingTag}
              />
            </Box>
            <Box ml={1}>
              <Tooltip title={"Refresh tag"}>
                <span>
                  <IconButton
                    size={"small"}
                    color={"primary"}
                    disabled={loadingTag}
                    onClick={() => {
                      setTagCount(tagCount + 1);
                    }}
                  >
                    <RefreshIcon />
                  </IconButton>
                </span>
              </Tooltip>
            </Box>
          </Box>
        )}
        {filter === WOO_CATEGORY_VALUE && (
          <Box mb={1}>
            <WooCategoryFilter
              name={WOO_CATEGORY_IMPORT}
              channelID={channelID}
            />
          </Box>
        )}
        {filter === WOO_STATUS_VALUE && (
          <Box mb={1}>
            <WooStatusImport channelID={channelID} />
          </Box>
        )}
        {filter === WOO_STOCK_STATUS_VALUE && (
          <Box mb={1}>
            <WooStockStatusFilter names={WOO_STOCK_STATUS} />
          </Box>
        )}
        {filter === WOO_PRODUCT_IDS_VALUE && (
          <Box mb={1}>
            <AddTagsAndMaterial
              names={WOO_PRODUCT_ID}
              placeholder={
                "Please enter Product ID(s). Multiple values accepted"
              }
            />
          </Box>
        )}
      </TableCell>
    </TableRow>
  );
};

export default WooImportFilter;