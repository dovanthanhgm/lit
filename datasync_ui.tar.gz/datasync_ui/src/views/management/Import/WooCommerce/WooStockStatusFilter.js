import React from "react";
import { FormControl, MenuItem, Select } from "@material-ui/core";
import { useField } from "formik";
import { WOO_STOCK_STATUS } from "src/constants/importFromChannel";
import { makeStyles } from "@material-ui/styles";

const useStyles = makeStyles(theme => ({
  root: {
    ...theme.typography.body2
  }
}));

const listEtsyImport = [
  { label: "In Stock", value: "instock" },
  { label: "Out Of Stock", value: "outofstock" },
  { label: "On Back Order", value: "onbackorder" }
];

const WooStockStatusFilter = () => {
  const classes = useStyles();
  const [{ value }, , { setValue }] = useField(WOO_STOCK_STATUS);

  const handleChange = e => {
    setValue(e.target.value);
  };

  return (
    <>
      <FormControl variant="outlined" size={"small"} fullWidth>
        <Select value={value} onChange={handleChange} displayEmpty>
          <MenuItem value="" className={classes.root}>
            Please select
          </MenuItem>
          {listEtsyImport.map((item, index) => (
            <MenuItem value={item.value} key={index} className={classes.root}>
              {item.label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </>
  );
};


export default WooStockStatusFilter;