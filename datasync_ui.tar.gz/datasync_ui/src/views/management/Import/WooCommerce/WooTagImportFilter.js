import React from "react";
import { Autocomplete, createFilterOptions } from "@material-ui/lab";
import { Avatar, Chip, TextField } from "@material-ui/core";
import { useField } from "formik";

const filter = createFilterOptions();

const WooTagImportFilter = ({ tags = [], name, loadingTag = true }) => {
  const [, , { setValue }] = useField(name);

  const tagsItemLabel = (name, props) => {
    if (props?.count) {
      return (
        <>
          {name}&ensp;
          <Chip
            variant="outlined"
            color="primary"
            size="small"
            avatar={<Avatar>{props?.count}</Avatar>}
            label={"products available"}
          />
        </>
      );
    }
    return name || "";
  };

  return (
    <Autocomplete
      options={tags}
      size={"small"}
      onChange={(event, newValue) => {
        if (typeof newValue === "string") {
          setValue(newValue);
        } else if (newValue && newValue.inputValue) {
          // Create a new value from the user input
          setValue(newValue.inputValue);
        } else {
          setValue(newValue?.id);
        }
      }}
      filterOptions={(options, params) => {
        const filtered = filter(options, params);
        if (params.inputValue !== "") {
          filtered.push({
            inputValue: params.inputValue,
            title: `Add "${params.inputValue}"`,
            name: `Add "${params.inputValue}"`
          });
        }

        return filtered;
      }}
      noOptionsText={"No tags found"}
      renderOption={option => (
        <React.Fragment>{tagsItemLabel(option?.name, option)}</React.Fragment>
      )}
      getOptionLabel={option => {
        // Value selected with enter, right from the input
        if (typeof option === "string") {
          return option;
        }
        if (option.inputValue) {
          return option.inputValue;
        }
        return option?.name || "";
      }}
      renderInput={params => (
        <TextField
          {...params}
          placeholder={loadingTag ? "Loading tags..." : "Please select tags"}
          variant="outlined"
        />
      )}
    />
  );
};


export default WooTagImportFilter;