import React, { useEffect, useState } from "react";
import { debounce, isEmpty } from "lodash";
import { searchCategoryBigShop } from "src/services/templates";
import {
  Box,
  CircularProgress,
  ListItem,
  MenuList,
  Paper
} from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import { FixedSizeList } from "react-window";
import { itemKey } from "src/components/Template/Etsy/Category/Primary/RowPrimaryCategory";
import { useField } from "formik";

const handleAddShowMore = (prev = []) => {
  if (prev.length >= 20) {
    return [
      ...prev,
      {
        name: "Show More",
        // path: "Show More",
        id: "show_more"
      }
    ];
  } else {
    return prev;
  }
};

const handleSaveListAttributes = debounce(
  async ({
    search,
    setListProduct,
    setLoading,
    channelID,
    page,
    setLoadingShowMore = function() {}
  }) => {
    try {
      setLoading(true);
      const response = await searchCategoryBigShop({
        channel_id: channelID,
        channel: "woocommerce",
        page,
        search: encodeURI(search)
      });

      if (response) {
        let myArray = response.data;

        const isResponseCount =
          response.data.length >= 20 && response?.count > 20;

        if (isResponseCount) {
          const newPrev = (prev = []) =>
            prev.filter(item => item.category_id !== "show_more");
          setListProduct(prev => [
            ...newPrev(prev),
            ...handleAddShowMore(myArray)
          ]);
        } else {
          if (!isEmpty(myArray)) {
            setListProduct(handleAddShowMore(myArray));
          } else {
            setListProduct([]);
          }
        }
      }
    } catch (error) {
      console.log(error);
    }
    setLoadingShowMore(false);
    setLoading(false);
  },
  1000
);

const renderRow = (
  handleClick = function() {},
  handleClickShowMore,
  loading,
  isPathSelected
) => props => {
  const { index, style, data } = props;

  const item = data[index];

  const id = item.id;
  const selected = isPathSelected(id);

  const onClick = () => {
    handleClick({ id, item });
  };

  const onClickShowMore = () => {
    handleClickShowMore();
  };

  if (id === "show_more") {
    return (
      <ListItem
        button
        style={style}
        key={index}
        onClick={onClickShowMore}
        selected={selected}
      >
        {!loading && item.name}
        {loading && (
          <Box position={"relative"} width="100%" textAlign="center">
            <CircularProgress size={30} />
          </Box>
        )}
      </ListItem>
    );
  }

  return (
    <ListItem
      button
      style={style}
      key={index}
      onClick={onClick}
      selected={selected}
    >
      {item.name}
    </ListItem>
  );
};

const WooCategoryFilter = ({ name, channelID }) => {
  const [{ value: valueName }, , { setValue }] = useField(name);
  const [options, setOptions] = useState([]);
  const [search, setSearch] = useState(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(true);
  const [page, setPage] = useState(1);
  const [loadingShowMore, setLoadingShowMore] = useState(false);

  const isPathSelected = path => {
    return path === valueName?.id;
  };

  const handleChangeSearch = e => {
    setPage(1);
    setSearch(e.target.value);
  };

  const handleClick = props => {
    setValue(props.item);
  };

  useEffect(() => {
    //page > 1 for change page
    if (![null, undefined].includes(search) || page > 1) {
      const searchCategory = async () => {
        try {
          await handleSaveListAttributes({
            page,
            search,
            setListProduct: setOptions,
            channelID,
            setLoading,
            prevList: options
          });
        } catch (error) {
          console.log(error);
        }
      };
      searchCategory();
    }
    // eslint-disable-next-line
  }, [search, page, channelID, setOptions]);

  const handleClickShowMore = () => {
    setLoadingShowMore(true);
    setPage(page + 1);
    handleSaveListAttributes({
      page: page + 1,
      search,
      setListProduct: setOptions,
      setLoadingShowMore,
      channelID,
      setLoading,
      params: { page: page + 1 }
    });
  };

  return (
    <>
      <TextField
        fullWidth
        placeholder={"Enter category name"}
        size={"small"}
        variant={"outlined"}
        onClick={() => setOpen(true)}
        value={search}
        onChange={handleChangeSearch}
        InputProps={{
          endAdornment: (
            <React.Fragment>
              {loading ? <CircularProgress color="inherit" size={20} /> : null}
            </React.Fragment>
          )
        }}
      />
      {!!options.length && open && (
        <Paper
          style={{
            marginTop: 4
          }}
        >
          <MenuList autoFocusItem id="menu-list-grow">
            <FixedSizeList
              height={options.length < 6 ? options.length * 35 : 400}
              itemSize={35}
              itemCount={options.length}
              itemData={options}
              itemKey={itemKey()}
            >
              {renderRow(
                handleClick,
                handleClickShowMore,
                loadingShowMore,
                isPathSelected
              )}
            </FixedSizeList>
          </MenuList>
        </Paper>
      )}
    </>
  );
};


export default WooCategoryFilter;