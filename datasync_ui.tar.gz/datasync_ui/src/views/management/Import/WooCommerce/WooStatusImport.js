import React from "react";
import { useField } from "formik";
import { TextField } from "@material-ui/core";
import { makeStyles } from "@material-ui/styles";
import { Autocomplete } from "@material-ui/lab";

const useStyles = makeStyles(() => ({
  checkBoxStyle: {
    "& .MuiCheckbox-root": {
      paddingBottom: 0
    }
  }
}));
const listEtsyImport = [
  { label: "Publish", value: "publish" },
  { label: "Draft", value: "draft" },
  { label: "Pending", value: "pending" },
  { label: "Private", value: "private" }
];

const WooStatusImport = () => {
  const classes = useStyles();
  const [{ value: initValue }, , { setValue: setValueType }] = useField(
    "imported_type"
  );

  const handleInitValue = () => {
    return listEtsyImport.find(item => item.value === initValue) || "";
  };

  const handleChange = event => {
    setValueType(event);
  };

  return (
    <div className={classes.checkBoxStyle}>
      <Autocomplete
        options={listEtsyImport}
        size={"small"}
        onChange={(event, newValue) => {
          handleChange(newValue?.value);
        }}
        value={handleInitValue()}
        noOptionsText={"No tags found"}
        getOptionLabel={option => option?.label || ""}
        renderInput={params => (
          <TextField
            {...params}
            placeholder={"Please select status"}
            variant="outlined"
          />
        )}
      />
    </div>
  );
};

export default WooStatusImport;