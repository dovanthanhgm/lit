import { Box, Container } from "@material-ui/core";
// import HorizontalSplitIcon from "@material-ui/icons/HorizontalSplit";
import ListAltIcon from "@material-ui/icons/ListAlt";
import LocalOfferIcon from "@material-ui/icons/LocalOffer";
import React, { useEffect } from "react";
import { useHistory } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import Header from "src/components/Header";
import Page from "src/components/Page";
import Table from "src/components/TableImportExport";
import { actionGetWarehouses } from "src/actions/warehouse";

export default function Export() {
  const history = useHistory();
  const listings = useSelector((state) => state.listing.listings);
  const dispatch = useDispatch();

  const handleImport = (typeFile) => () => {
    switch (typeFile) {
      case "product_csv":
        return history.push(`/import-data/${typeFile}`);
      case "product_image":
        return history.push(`/import-data/${typeFile}`);
      // case "inventory_csv":
      //   return history.push(`/import-data/${typeFile}`);
      default:
        return;
    }
  };

  const handleImportListing = (id) => () => {
    return history.push(`/import-data/listings/${id}`);
  };

  const data = [
    {
      name: "Products",
      Image: ListAltIcon,
      export: [
        {
          title: "CSV File",
          onClick: handleImport("product_csv"),
          src: "/static/images/imex/csv.svg",
          direction: "row",
        },
      ],
    },
    // {
    //   name: "Inventory",
    //   Image: HorizontalSplitIcon,
    //   export: [
    //     {
    //       title: "CSV File",
    //       onClick: handleImport("inventory_csv"),
    //       src: "/static/images/imex/csv.svg",
    //       direction: "row",
    //     },
    //   ],
    // },
    {
      name: "Listings",
      Image: LocalOfferIcon,
      export: listings.map((item) => ({
        title: item.name,
        direction: "row",
        onClick: handleImportListing(item.id),
        type: item.type,
      })),
    },
  ];

  useEffect(() => {
    dispatch(actionGetWarehouses());
  }, [dispatch]);

  return (
    <Page title="Import Data">
      <Container maxWidth={false}>
        <Header headerName="Import data" />
        <Box mt="2">
          <Table type="import" data={data} />
        </Box>
      </Container>
    </Page>
  );
}
