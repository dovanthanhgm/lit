import React from "react";
import {
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  TableCell,
  TableRow,
  Typography
} from "@material-ui/core";
import { useField } from "formik";

// ['ACTIVE', 'ARCHIVED', 'RETIRED']

// const addItem = (item, values = []) => {
//   return [...values, item];
// };
// const removeItem = (item, values = []) => {
//   return values?.filter(items => items !== item);
// };

// const itemInValue = ({ item, values = [] }) => {
//   if (values?.includes(item)) {
//     return removeItem(item, values);
//   }
//   return addItem(item, values);
// };

const LifeCycleStatus = () => {
  const [{ value }, , { setValue }] = useField("walmart_status");

  const handleIsCheck = item => {
    if (!value) return false;
    return value === item;
  };

  const handleAdd = event => {
    setValue(event.target.value);
  };

  return (
    <TableRow>
      <TableCell>
        <FormControl component="fieldset">
          <Typography variant="body2">Lifecycle status</Typography>
          <FormGroup>
            <FormControlLabel
              control={
                <Checkbox
                  checked={handleIsCheck("ACTIVE")}
                  onChange={handleAdd}
                  value="ACTIVE"
                />
              }
              label="Active"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={handleIsCheck("ARCHIVED")}
                  onChange={handleAdd}
                  value="ARCHIVED"
                />
              }
              label="Archived"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={handleIsCheck("RETIRED")}
                  onChange={handleAdd}
                  value="RETIRED"
                />
              }
              label="Retired"
            />
          </FormGroup>
        </FormControl>
      </TableCell>
    </TableRow>
  );
};

export default LifeCycleStatus;
