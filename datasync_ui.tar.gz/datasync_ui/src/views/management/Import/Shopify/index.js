import React from "react";
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Divider,
  Typography
} from "@material-ui/core";
import { Field } from "formik";
import { Checkbox } from "formik-material-ui";
import CartLogo from "src/components/ListImageProduct/CartLogo";
import { makeStyles } from "@material-ui/core/styles";
import { useSelector } from "react-redux";
import ImportOptions from "src/views/management/Import/Shopify/ImportOptions";
import ImportFilter from "src/views/management/Import/Shopify/ImportFilter/ImportFilter";

const useStyles = makeStyles(theme => ({
  cartImage: {
    height: 24,
    width: 24,
    marginRight: theme.spacing(0.25)
  }
}));

const ShopifyMainStoreImport = () => {
  const classes = useStyles();
  const { listings } = useSelector(state => state.listing);
  const { user } = useSelector(state => state.account);

  let channelName = listings.map(item => ({
    name: item.name,
    id: String(item.id),
    type: item.type
  })); //remove current channel

  return (
    <>
      <ImportOptions />
      <Box pb={2} />
      <ImportFilter />
      {user?.group === 1 && <Box pb={2} />}

      {user?.group === 1 && (
        <Card>
          <CardHeader
            title={
              <Typography variant={"h5"}>
                Auto import product to channel
              </Typography>
            }
          />
          <Divider />
          <CardContent>
            <div role="group" aria-labelledby="checkbox-group">
              {channelName.map((item, index) => (
                <Box key={index}>
                  <label style={{ display: "flex", alignItems: "center" }}>
                    <Field
                      type="checkbox"
                      component={Checkbox}
                      name={"auto_import"}
                      value={item.id}
                    />
                    <CartLogo
                      key={`${item.name}${item.type}`}
                      className={classes.cartImage}
                      id={item.type}
                      isHover
                      hoverDetail={item.name}
                    />
                    <Box mx={0.5} />
                    <Typography
                      color="textPrimary"
                      variant="body2"
                      component="span"
                      style={{ cursor: "pointer" }}
                    >
                      {" " + item.name}
                    </Typography>
                  </label>
                </Box>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
};

export default ShopifyMainStoreImport;
