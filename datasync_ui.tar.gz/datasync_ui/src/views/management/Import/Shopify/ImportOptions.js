import React from "react";
import {
  Card,
  CardContent,
  CardHeader,
  Divider,
  FormControlLabel,
  Typography
} from "@material-ui/core";
import CheckboxFormik from "src/components/MUI/Formik/Checkbox";

const ImportOptions = () => {
  return (
    <Card>
      <CardHeader title={<Typography variant={"h5"}>Options</Typography>} />
      <Divider />
      <CardContent>
        <div role="group" aria-labelledby="checkbox-group">
          <label style={{ display: "flex", alignItems: "center" }}>
            <FormControlLabel
              control={<CheckboxFormik name={"include_deleted"} />}
              label={"Re-import all deleted products"}
            />
          </label>
          {/*<label style={{ display: "flex", alignItems: "center" }}>*/}
          {/*  <FormControlLabel*/}
          {/*    control={<CheckboxFormik name={"collection"} />}*/}
          {/*    label={"Auto import Collections/Categories"}*/}
          {/*  />*/}
          {/*</label>*/}
        </div>
      </CardContent>
    </Card>
  );
};

export default ImportOptions;
