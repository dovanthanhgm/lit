import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  Divider,
  FormControl,
  Grid,
  MenuItem,
  Select,
  Typography
} from "@material-ui/core";
import ImportSpecificsFilter from "src/views/management/Import/Shopify/ImportFilter/ImportSpecificsFilter";
import { useField } from "formik";
import { makeStyles } from "@material-ui/styles";

const useStyles = makeStyles(theme => ({
  textMenuStyle: {
    ...theme.typography.body2
  }
}));

const filterList = [
  { value: "all", name: "All products" },
  { value: "published", name: "Published products only" },
  { value: "filter", name: "Apply filters ..." }
];

const ImportFilter = () => {
  const classes = useStyles();
  const [value, setValue] = useState("all");
  const [, , { setValue: setValueAll }] = useField("import_all");
  const [, , { setValue: setPublished }] = useField("include_published");

  const handleChange = e => {
    const changeType = {
      all: () => {
        setValueAll(true);
        setPublished(false);
      },
      published: () => {
        setValueAll(false);
        setPublished(true);
      },
      filter: () => {
        setValueAll(false);
        setPublished(false);
      }
    };
    changeType[e.target.value]();
    setValue(e.target.value);
  };

  return (
    <Card>
      <CardHeader title={<Typography variant={"h5"}>Filter</Typography>} />
      <Divider />
      <CardContent>
        <Grid container spacing={2}>
          <Grid item xs={3}>
            <FormControl variant="outlined" size="small" fullWidth>
              <Select value={value} onChange={handleChange}>
                {filterList.map(item => {
                  return (
                    <MenuItem
                      value={item.value}
                      key={item.value}
                      className={classes.textMenuStyle}
                    >
                      {item.name}
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>{" "}
          </Grid>
        </Grid>
        {value === "filter" && <ImportSpecificsFilter />}
      </CardContent>
    </Card>
  );
};

export default ImportFilter;
