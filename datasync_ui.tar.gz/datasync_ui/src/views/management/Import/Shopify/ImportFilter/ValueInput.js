import React from "react";
import TextFieldString from "src/components/MUI/Formik/Text";
import AddTagsAndMaterial from "src/components/Template/Etsy/Category/Advance/AddTagsAndMaterial";
import { Box } from "@material-ui/core";
import {
  EXCLUDE_TAG,
  INCLUDE_COLLECTION_ID,
  INCLUDE_PRODUCT_IDS,
  INCLUDE_TYPE,
  INCLUDE_VENDOR
} from "src/constants/importFromChannel";

const VendorInput = () => {
  return (
    <TextFieldString
      name={INCLUDE_VENDOR}
      fullWidth
      placeholder={"Please enter Vendor. One value accepted."}
    />
  );
};

const ProductTypeInput = () => {
  return (
    <TextFieldString
      name={INCLUDE_TYPE}
      fullWidth
      placeholder={"Please enter Product Type. One value accepted."}
    />
  );
};

const ProductIDInput = () => {
  return (
    <AddTagsAndMaterial
      names={INCLUDE_PRODUCT_IDS}
      placeholder={"Please enter Product ID(s). Multiple values accepted"}
    />
  );
};

const ExcludeTagInput = () => {
  return (
    <TextFieldString
      name={EXCLUDE_TAG}
      fullWidth
      placeholder={"Please enter Exclude tag.. One value accepted."}
    />
  );
};

const CollectionIDInput = () => {
  return (
    <TextFieldString
      name={INCLUDE_COLLECTION_ID}
      fullWidth
      placeholder={"Please enter Product Type. One value accepted."}
    />
  );
};

const ValueInput = ({ typeImport }) => {
  const inputByType = {
    [INCLUDE_PRODUCT_IDS]: <ProductIDInput />,
    [INCLUDE_COLLECTION_ID]: <CollectionIDInput />,
    [INCLUDE_TYPE]: <ProductTypeInput />,
    [INCLUDE_VENDOR]: <VendorInput />,
    [EXCLUDE_TAG]: <ExcludeTagInput />
  };
  return <Box mt={3}>{inputByType[typeImport]}</Box>;
};

export default ValueInput;
