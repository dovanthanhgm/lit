import React, { useState } from "react";
import {
  Box,
  FormControl,
  Grid,
  MenuItem,
  Select,
  Typography
} from "@material-ui/core";
import ValueInput from "src/views/management/Import/Shopify/ImportFilter/ValueInput";
import { makeStyles } from "@material-ui/styles";
import { useField } from "formik";
import {
  EXCLUDE_TAG,
  INCLUDE_COLLECTION_ID,
  INCLUDE_PRODUCT_IDS,
  INCLUDE_TYPE,
  INCLUDE_VENDOR
} from "src/constants/importFromChannel";

const useStyles = makeStyles(theme => ({
  textMenuStyle: {
    ...theme.typography.body2
  }
}));

const specificsList = [
  { value: INCLUDE_PRODUCT_IDS, name: "Product ID" },
  { value: INCLUDE_COLLECTION_ID, name: "Collection ID" },
  { value: INCLUDE_TYPE, name: "Product Type" },
  { value: INCLUDE_VENDOR, name: "Vendor" },
  { value: EXCLUDE_TAG, name: "Exclude Tag" },
];

const ImportSpecificsFilter = () => {
  const classes = useStyles();
  const [typeImport, setTypeImport] = useState(INCLUDE_PRODUCT_IDS);
  const [, , { setValue: setShopifyFilter }] = useField("shopify_filter");

  const handleChange = e => {
    setTypeImport(e.target.value);
    setShopifyFilter(e.target.value);
  };

  return (
    <Box my={2}>
      <Typography variant={"h6"}>Apply specific filter</Typography>
      <Box my={0.5} />
      <Grid container spacing={2}>
        <Grid item xs={3}>
          <FormControl variant="outlined" size="small">
            <Select value={typeImport} onChange={handleChange}>
              {specificsList.map(item => {
                return (
                  <MenuItem
                    value={item.value}
                    key={item.value}
                    className={classes.textMenuStyle}
                  >
                    {item.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        </Grid>
      </Grid>
      <ValueInput typeImport={typeImport} />
    </Box>
  );
};

export default ImportSpecificsFilter;
