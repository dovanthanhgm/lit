import React from "react";
import { Box, Checkbox, FormControlLabel, Typography } from "@material-ui/core";
import { useField } from "formik";
import { useSelector } from "react-redux";
import { channelKeepActive } from "src/views/management/Listing/constant";
import { Alert } from "@material-ui/lab";

const ImportWarningDialog = () => {
  const [{ value, onChange }] = useField("check_warning");
  const { defaultListing } = useSelector(state => state?.listing);
  const channelDefaultType = defaultListing?.type;

  return (
    <Box mt={1}>
      <Alert severity="warning">
        If you import Expired/Inactive/Sold Out products, please make sure these
        products will not be auto linked to existing Products in your Main Store
        and getting auto Active by your Inventory Sync configuration. For
        example: an Expired product is imported and auto linked with an existing
        products in your Main Store, then you enable Inventory Sync with
        settings: Turn on "Keep my products active if products in Main Store
        is&nbsp;
        {channelKeepActive(channelDefaultType)}", or "Minimum Quantity" is
        enabled with value >= 1. In that case your Expired/Inactive/Sold Out
        product will be auto Active unexpectedly.
        <Box>
          <FormControlLabel
            style={{
              paddingTop: 0
            }}
            control={
              <Checkbox
                style={{
                  paddingTop: 4,
                  paddingBottom: 4
                }}
                checked={value}
                onChange={onChange}
                name="check_warning"
                color="primary"
              />
            }
            label={<Typography variant={"body2"}>I have read and understood.</Typography>}
          />
        </Box>
      </Alert>

    </Box>
  );
};

export default ImportWarningDialog;