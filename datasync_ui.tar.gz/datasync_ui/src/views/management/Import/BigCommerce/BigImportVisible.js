import React from "react";
import {
  Checkbox,
  FormControlLabel,
} from "@material-ui/core";
import { useField } from "formik";

const BigImportVisible = ({ name }) => {
  const [{ value }, , { setValue }] = useField(name);

  const handleChange = (e) => {
    setValue(e.target.value === 'true')
  }

  return (
    <>
      <FormControlLabel
        control={
          <Checkbox
            checked={value}
            value={'true'}
            onChange={handleChange}
            color="primary"
          />
        }
        label="Yes"
      />
      <FormControlLabel
        control={
          <Checkbox
            checked={!value}
            value={'false'}
            onChange={handleChange}
            color="primary"
          />
        }
        label="No"
      />
    </>
  );
};

export default BigImportVisible;