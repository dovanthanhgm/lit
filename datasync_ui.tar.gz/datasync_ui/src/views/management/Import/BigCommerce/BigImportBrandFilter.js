import React from "react";
import { debounce } from "lodash";
import { bigImportSearchBrand } from "src/services/manage";
import BigImportSearchFilter from "src/views/management/Import/BigCommerce/BigImportSearchFilter";

const handleSaveListAttributes = debounce(
  async ({ search, setListProduct, setLoading, channelID }) => {
    try {
      setLoading(true);
      const response = await bigImportSearchBrand({
        channelID,
        brand: encodeURI(search)
      });
      if (response) {
        let myArray = response.data;
        setListProduct(myArray);
      }
    } catch (error) {
      console.log(error);
    }
    setLoading(false);
  },
  1000
);

const BigImportBrandFilter = ({ name, channelID }) => {
  return (
    <BigImportSearchFilter
      name={name}
      placeholder={'Enter Brand'}
      channelID={channelID}
      handleSaveListAttributes={handleSaveListAttributes}
    />
  );
};

export default BigImportBrandFilter;