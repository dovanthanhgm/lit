import React, { useEffect, useState } from "react";
import {
  BIG_BRAND_ID,
  BIG_BRAND_ID_VALUE,
  BIG_CATEGORIES,
  BIG_CATEGORY_VALUE,
  BIG_IS_IS_VISIBLE,
  BIG_IS_VISIBLE_VALUE,
  BIG_PRODUCT_ID,
  BIG_PRODUCT_IDS_VALUE,
  IMPORT_ALL_STATUS
} from "src/constants/importFromChannel";
import { useField } from "formik";
import { makeStyles } from "@material-ui/styles";
import {
  Box,
  FormControl,
  MenuItem,
  Select,
  TableCell,
  TableRow,
  Typography
} from "@material-ui/core";
import AddTagsAndMaterial from "src/components/Template/Etsy/Category/Advance/AddTagsAndMaterial";
import BigImportVisible from "src/views/management/Import/BigCommerce/BigImportVisible";
import BigImportBrandFilter from "src/views/management/Import/BigCommerce/BigImportBrandFilter";
// import BigImportCategories from "src/views/management/Import/BigCommerce/BigImportCategories";
import BigCommerceEnterCategory from "src/views/channel/BigCommerce/import/BigCommerceEnterCategory";

const useStyles = makeStyles(theme => ({
  menuText: {
    ...theme.typography.body2
  }
}));

const optionList = [
  { value: IMPORT_ALL_STATUS, name: "Import all products" },
  // {
  //   name: "Import product by Brand",
  //   value: BIG_BRAND_ID_VALUE
  // },
  { name: "Import product by visible", value: BIG_IS_VISIBLE_VALUE },
  {
    name: "Import product by Category",
    value: BIG_CATEGORY_VALUE
  },
  { name: "Import product by Product Id(s)", value: BIG_PRODUCT_IDS_VALUE }
];

const BigImportFilter = ({ channelID }) => {
  const classes = useStyles();

  const [filter, setFilter] = useState(IMPORT_ALL_STATUS);

  const [, , { setValue: setInitOption }] = useField("channel_option_filter");

  const handleChange = e => {
    setFilter(e.target.value);
    setInitOption(e.target.value);
  };

  useEffect(() => {
    setInitOption(IMPORT_ALL_STATUS);
    // eslint-disable-next-line
  }, []);

  return (
    <TableRow>
      <TableCell
        style={{
          borderBottom: "none"
        }}
      >
        <Typography variant={"h6"}>Filter</Typography>
        <Box mt={2} mb={2}>
          <FormControl variant="outlined" size="small">
            <Select value={filter} onChange={handleChange}>
              {optionList.map(item => {
                return (
                  <MenuItem
                    value={item.value}
                    key={item.value}
                    className={classes.menuText}
                  >
                    {item.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        </Box>
        {filter === BIG_BRAND_ID_VALUE && (
          <Box mb={1}>
            <BigImportBrandFilter channelID={channelID} name={BIG_BRAND_ID} />
          </Box>
        )}
        {filter === BIG_IS_VISIBLE_VALUE && (
          <Box mb={1}>
            <BigImportVisible name={BIG_IS_IS_VISIBLE} />
          </Box>
        )}
        {filter === BIG_CATEGORY_VALUE && (
          <Box mb={1}>
            <BigCommerceEnterCategory names={BIG_CATEGORIES} channelID={channelID} />
          </Box>
        )}
        {filter === BIG_PRODUCT_IDS_VALUE && (
          <Box mb={1}>
            <AddTagsAndMaterial
              names={BIG_PRODUCT_ID}
              placeholder={
                "Please enter Product ID(s). Multiple values accepted"
              }
            />
          </Box>
        )}
      </TableCell>
    </TableRow>
  );
};

export default BigImportFilter;