import React, { useEffect, useState } from "react";
import Autocomplete from "@material-ui/lab/Autocomplete";
import Chip from "@material-ui/core/Chip";
import { CircularProgress } from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import { useField } from "formik";

const BigImportSearchFilter = ({ channelID, name, handleSaveListAttributes = function (){}, placeholder = 'Search' }) => {
  const [, , { setValue }] = useField(name);
  const [categoryValue, setCategoryValue] = useState("");
  const [openSearch, setOpenSearch] = useState(false);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState(null);
  const [options, setOptions] = useState([]);

  const handleChangeSearch = e => {
    setSearch(e.target.value);
  };

  useEffect(() => {
    if (![null, undefined].includes(search) && openSearch) {
      const searchCategory = async () => {
        try {
          await handleSaveListAttributes({
            search,
            setListProduct: setOptions,
            channelID,
            setLoading
          });
        } catch (e) {
          console.log(e);
        }
      };
      searchCategory();
    }
    // eslint-disable-next-line
  }, [search, openSearch]);

  return (
    <Autocomplete
      // multiple
      size="small"
      value={categoryValue}
      onChange={async (event, newValue, situation) => {
        if (!newValue) {
          if (situation === "clear") {
            setSearch("");
            await setCategoryValue("");
          }
        } else {
          setValue(newValue?.id);
          await setCategoryValue(newValue);
        }
      }}
      onMouseEnter={() => {
        setOpenSearch(true);
      }}
      onInput={handleChangeSearch}
      options={options}
      getOptionLabel={option => {
        const handleShowLabel = () => {
          if (option?.value === "show") {
            return categoryValue?.name || "";
          }
          return option?.name || "";
        };
        return handleShowLabel();
      }}
      renderTags={(tagValue, getTagProps) =>
        tagValue.map((option, index) => (
          <Chip label={option?.name} {...getTagProps({ index })} />
        ))
      }
      renderOption={(option, { selected }) => {
        return <React.Fragment>{option?.name}</React.Fragment>;
      }}
      fullWidth
      renderInput={params => (
        <TextField
          {...params}
          placeholder={placeholder}
          variant="outlined"
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <React.Fragment>
                {loading ? (
                  <CircularProgress color="inherit" size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </React.Fragment>
            )
          }}
        />
      )}
    />
  );
};

export default BigImportSearchFilter;