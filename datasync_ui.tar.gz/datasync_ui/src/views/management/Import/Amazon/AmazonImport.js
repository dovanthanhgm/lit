import React, { useEffect, useState } from 'react';
import { Box, FormControl, MenuItem, Select, TableCell, TableRow } from '@material-ui/core';
import {
   IMPORT_ALL_STATUS,
   AMAZON_PRODUCT_SKU,
   AMAZON_PRODUCT_SKU_VALUES
} from 'src/constants/importFromChannel';
import { Form, useField } from 'formik';
import AddTagsAndMaterial from 'src/components/Template/Etsy/Category/Advance/AddTagsAndMaterial';
import { makeStyles } from '@material-ui/styles';

const optionList = [
   { value: IMPORT_ALL_STATUS, name: 'Import all products' },
   { name: 'Import product by Product SKU(s)', value: AMAZON_PRODUCT_SKU_VALUES }
];

const useStyles = makeStyles(theme => ({
   menuText: {
      ...theme.typography.body2
   }
}));

function AmazonImport() {
   const classes = useStyles();

   const [filter, setFilter] = useState(IMPORT_ALL_STATUS);

   const [, , { setValue: setInitOption }] = useField('channel_option_filter');

   const handleChange = e => {
      setFilter(e.target.value);
      setInitOption(e.target.value);
   };

   useEffect(() => {
      setInitOption(IMPORT_ALL_STATUS);
      // eslint-disable-next-line
   }, []);

   return (
      <TableRow>
         <TableCell
            style={{
               borderBottom: 'none'
            }}
         >
            <Box mt={2} mb={2}>
               <FormControl variant='outlined' size='small'>
                  <Select value={filter} onChange={handleChange}>
                     {optionList.map(item => {
                        return (
                           <MenuItem
                              value={item.value}
                              key={item.value}
                              className={classes.menuText}
                           >
                              {item.name}
                           </MenuItem>
                        );
                     })}
                  </Select>
               </FormControl>
            </Box>
            {filter === AMAZON_PRODUCT_SKU_VALUES && (
               <Box mb={1}>
                  <Form>
                     <AddTagsAndMaterial
                        limit={100}
                        names={AMAZON_PRODUCT_SKU}
                        placeholder={'Please enter Product SKU(s). Multiple values accepted'}
                     />
                  </Form>
               </Box>
            )}
         </TableCell>
      </TableRow>
   );
}

export default AmazonImport;
