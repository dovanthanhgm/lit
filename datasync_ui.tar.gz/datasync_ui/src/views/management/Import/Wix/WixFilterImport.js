import React, {useEffect, useState} from "react";
import {
  Box,
  FormControl,
  MenuItem,
  Select,
  TableCell,
  TableRow
} from "@material-ui/core";
import {
  IMPORT_ALL_STATUS,
  WIX_COLLECTION_ID,
  WIX_COLLECTION_IDS_VALUE,
  WIX_PRODUCT_ID,
  WIX_PRODUCT_IDS_VALUE
} from "src/constants/importFromChannel";
import {Form, useField} from "formik";
import AddTagsAndMaterial from "src/components/Template/Etsy/Category/Advance/AddTagsAndMaterial";
import {makeStyles} from "@material-ui/styles";

const useStyles = makeStyles(theme => ({
  menuText: {
    ...theme.typography.body2
  }
}));

const optionList = [
  { value: IMPORT_ALL_STATUS, name: "Import all products" },
  {
    name: "Import product by Collection Id(s)",
    value: WIX_COLLECTION_IDS_VALUE
  },
  { name: "Import product by Product Id(s)", value: WIX_PRODUCT_IDS_VALUE }
];

const WixFilterImport = () => {
  const classes = useStyles();

  const [filter, setFilter] = useState(IMPORT_ALL_STATUS);

  const [, , { setValue: setInitOption }] = useField("channel_option_filter");

  const handleChange = e => {
    setFilter(e.target.value);
    setInitOption(e.target.value);
  };


  useEffect(() => {
    setInitOption(IMPORT_ALL_STATUS)
    // eslint-disable-next-line
  }, [])

  return (
    <TableRow>
      <TableCell
        style={{
          borderBottom: "none"
        }}
      >
        <Box mt={2} mb={2}>
          <FormControl variant="outlined" size="small">
            <Select value={filter} onChange={handleChange}>
              {optionList.map(item => {
                return (
                  <MenuItem
                    value={item.value}
                    key={item.value}
                    className={classes.menuText}
                  >
                    {item.name}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        </Box>
        {filter === WIX_COLLECTION_IDS_VALUE && (
          <Box mb={1}>
            <Form>
              <AddTagsAndMaterial
                names={WIX_COLLECTION_ID}
                limit={100}
                placeholder={
                  "Please enter Collection ID(s). Multiple values accepted"
                }
              />
            </Form>
          </Box>
        )}
        {filter === WIX_PRODUCT_IDS_VALUE && (
          <Box mb={1}>
            <Form>
              <AddTagsAndMaterial
                limit={100}
                names={WIX_PRODUCT_ID}
                placeholder={
                  "Please enter Product ID(s). Multiple values accepted"
                }
              />
            </Form>
          </Box>
        )}
      </TableCell>
    </TableRow>
  );
};

export default WixFilterImport;