import { Container, makeStyles } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { actionGetWarehouses } from "src/actions/warehouse";
import Header from "src/components/Header";
import Page from "src/components/Page";
import Result from "./Result";
import UpdateWarehouseForm from "./Update";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: "100%",
    paddingTop: theme.spacing(3),
    paddingBottom: 100,
  },
}));

function Warehouses() {
  const classes = useStyles();
  const dispatch = useDispatch();
  const warehouses = useSelector((state) => state.warehouse.warehouses);

  const [warehouse, setWarehouse] = useState();
  const [page, setPage] = useState(0);

  useEffect(() => {
    if (page === 0) {
      dispatch(actionGetWarehouses());
    }
  }, [dispatch, page]);

  const handleAddlocation = () => {
    setPage(1);
  };

  const handleEditWarehouse = (index) => {
    setWarehouse(warehouses[index]);
    handleAddlocation();
  };

  return (
    <Page className={classes.root} title="Listing">
      <Container maxWidth={false}>
        <Header
          headerName={`Warehouse Locations`}
          groupButton={
            page === 0
              ? [
                  {
                    name: `Add Location`,
                    onClick: handleAddlocation,
                  },
                ]
              : []
          }
        />

        {page === 0 && (
          <Result
            warehouses={warehouses}
            handleEditWarehouse={handleEditWarehouse}
            setWarehouse={setWarehouse}
          />
        )}

        {page === 1 && (
          <UpdateWarehouseForm warehouse={warehouse} setPage={setPage} />
        )}
      </Container>
    </Page>
  );
}

export default Warehouses;
