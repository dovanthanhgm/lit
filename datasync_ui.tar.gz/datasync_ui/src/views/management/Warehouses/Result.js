/* eslint-disable max-len */
import React from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import {
  Box,
  Button,
  Card,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  makeStyles,
} from "@material-ui/core";
import { useSnackbar } from "notistack";
import { useDispatch, useSelector } from "react-redux";

import TableSkeleton from "src/components/Skeleton/Table";
import ButtonDelete from "src/components/Button/ButtonDelete";
import { deleteWarehouseAPI } from "src/services/manage";
import { actionSetWarehouses } from "src/actions/warehouse";
import Loading from "src/components/Loading/Loading";

const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: theme.spacing(2),
  },
  circle: {
    borderBottom: "none",
  },
}));

function Results({ warehouses, handleEditWarehouse }) {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const loading = useSelector((state) => state.warehouse.isLoading);

  const handleEdit = (index) => () => {
    handleEditWarehouse(index);
  };

  const handleDelete = (itemDelete) => async () => {
    await deleteWarehouseAPI({ warehouseId: itemDelete.id });
    enqueueSnackbar("Success", {
      variant: "success",
    });
    dispatch(
      actionSetWarehouses({
        warehouses: warehouses.filter((item) => item.id !== itemDelete.id),
      })
    );
  };

  return (
    <Card className={classes.root}>
      <PerfectScrollbar>
        <Box minWidth={800}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell size="small" width="25%">
                  Location Name
                </TableCell>
                <TableCell size="small" width="35%">
                  Address
                </TableCell>
                <TableCell size="small" width="30%">
                  Inventory Source
                </TableCell>
                <TableCell size="small" width="10%" align="right" />
              </TableRow>
            </TableHead>
            <TableBody>
              {warehouses?.length > 0 &&
                warehouses.map((item, index) => {
                  return (
                    <TableRow hover key={item.id}>
                      <TableCell>{item.name}</TableCell>
                      <TableCell>{item.address}</TableCell>
                      <TableCell>{item.source}</TableCell>

                      <TableCell>
                        <Box display="flex">
                          <Box>
                            <Button
                              size="small"
                              color="secondary"
                              variant="contained"
                              onClick={handleEdit(index)}
                            >
                              Edit
                            </Button>
                          </Box>

                          {item.default !== 1 && (
                            <Box ml={2}>
                              <ButtonDelete
                                buttonText="Delete"
                                handleConfirm={handleDelete(item)}
                                headerDialog="Are you sure?"
                                contentDialog={
                                  <Typography
                                    color="textPrimary"
                                    variant="body1"
                                  >
                                    Are you sure you want to remove this
                                    warehouse?
                                  </Typography>
                                }
                                buttonTextSubmit="Yes, Remove"
                              />
                            </Box>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}

              {!warehouses && <TableSkeleton column={4} />}
            </TableBody>

            {loading && (
              <TableBody>
                <TableRow>
                  <TableCell className={classes.circle}>
                    <Box p={2}>
                      <Loading />
                    </Box>
                  </TableCell>
                </TableRow>
              </TableBody>
            )}
          </Table>

          {!loading && warehouses?.length === 0 && (
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              p={1}
            >
              <Typography className={classes.noData}>No data</Typography>
            </Box>
          )}
        </Box>
      </PerfectScrollbar>
    </Card>
  );
}

export default Results;
