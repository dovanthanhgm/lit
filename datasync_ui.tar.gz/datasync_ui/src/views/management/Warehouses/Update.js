/* eslint-disable max-len */
import React, { useState } from "react";
import {
  Box,
  Button,
  Card,
  TextField,
  makeStyles,
  Grid,
  Divider,
  Typography,
} from "@material-ui/core";
import Autocomplete from "@material-ui/lab/Autocomplete";
import * as Yup from "yup";
import { Formik, Field } from "formik";
import { useSnackbar } from "notistack";
import { TextField as TextFieldFormik } from "formik-material-ui";
import { addWarehouseAPI, editWarehouseAPI } from "src/services/manage";
import Link from "src/components/MUI/Link";
import dataCountry from "src/constants/country.json";

const useStyles = makeStyles((theme) => ({
  formContainer: {
    padding: theme.spacing(2),
    marginTop: theme.spacing(2),
  },
}));

const data = [
  {
    id: "sender_name",
    label: "Sender Name",
  },
  {
    id: "company_name",
    label: "Company Name",
  },
  {
    id: "email",
    label: "Email",
  },
  {
    id: "phone",
    label: "Phone Number",
  },
  {
    id: "address",
    label: "Address",
  },
  {
    id: "address_2",
    label: "Address 2",
  },
  {
    id: "city",
    label: "City",
  },
  {
    id: "state",
    label: "State",
  },
  {
    id: "postcode",
    label: "Zip Code",
  },
];

const dataCountryKeys = Object.keys(dataCountry);

const options = dataCountryKeys.map((key) => {
  return { id: key, content: dataCountry[key] };
});

function UpdateWarehouseForm({ warehouse, setPage }) {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();
  const [valueCountry, setvalueCountry] = useState("");

  const handleClickBack = () => {
    setPage(0);
  };

  let initialValues = {
    name: "",
    country: "",
  };

  data.forEach((item) => {
    initialValues[item.id] = "";
  });

  if (warehouse) {
    initialValues = {
      ...warehouse,
      country: options.find((option) => option.id === warehouse.country),
    };
  }

  const handleChangeComplete = (handleChange) => (e, newValue) => {
    if (newValue) {
      handleChange({
        target: {
          name: "country",
          value: newValue,
        },
      });
    }
  };

  return (
    <Box>
      <Link onClick={handleClickBack}>Back to Warehouses</Link>
      <Card className={classes.formContainer}>
        <Formik
          initialValues={initialValues}
          validationSchema={Yup.object().shape({
            name: Yup.string().required("Reqired"),
            postcode: Yup.number()
              .typeError("Zip Code must be a number")
              .required("Reqired"),
          })}
          onSubmit={async (
            values,
            { resetForm, setErrors, setStatus, setSubmitting }
          ) => {
            try {
              let res;
              const country =
                typeof values.country === "object"
                  ? values.country.id
                  : values.country;
              if (warehouse) {
                res = await editWarehouseAPI({
                  warehouse: { ...warehouse, ...values, country },
                });
              } else {
                res = await addWarehouseAPI({
                  warehouse: { ...values, country },
                });
              }

              if (!res) {
                enqueueSnackbar("Something went wrong", {
                  variant: "error",
                });
              } else {
                enqueueSnackbar("Success", {
                  variant: "success",
                });
                setPage(0);
              }
            } catch (error) {
              setStatus({ success: false });
              setErrors({ submit: error.message });
              setSubmitting(false);
            }
          }}
        >
          {({ handleChange, handleSubmit, isSubmitting, values }) => (
            <form onSubmit={handleSubmit}>
              <Box>
                <Box mb={2}>
                  <Grid container justify="center">
                    <Grid item xs={6}>
                      <Field
                        component={TextFieldFormik}
                        fullWidth
                        name="name"
                        variant="outlined"
                        size="small"
                        label="Location Name"
                      />
                    </Grid>
                  </Grid>
                </Box>

                <Divider />

                <Box mt={1} mb={1}>
                  <Typography variant="body1" color="textPrimary">
                    Warehouse locations provide origin information (ship from
                    address) and shipment return information for orders shipped
                    through LitCommerce.
                  </Typography>
                </Box>

                <Grid container spacing={3}>
                  {data.map((item) => (
                    <Grid item xs={6} key={item.id}>
                      <Field
                        component={TextFieldFormik}
                        fullWidth
                        name={item.id}
                        variant="outlined"
                        size="small"
                        label={item.label}
                      />
                    </Grid>
                  ))}

                  <Grid item xs={6}>
                    <Autocomplete
                      options={options}
                      getOptionLabel={(option) => option.content || ""}
                      size="small"
                      fullWidth
                      onChange={handleChangeComplete(handleChange)}
                      onInputChange={(_, newInputValue) => {
                        setvalueCountry(newInputValue);
                      }}
                      value={values.country}
                      inputValue={valueCountry}
                      renderInput={(params) => {
                        return (
                          <TextField
                            {...params}
                            label="Country"
                            variant="outlined"
                          />
                        );
                      }}
                    />
                  </Grid>
                </Grid>

                <Box mt={2} display="flex" flexDirection="row-reverse">
                  <Box ml={1}>
                    <Button
                      variant="contained"
                      type="submit"
                      size="small"
                      onClick={handleClickBack}
                    >
                      Cancel
                    </Button>
                  </Box>
                  <Button
                    variant="contained"
                    color="secondary"
                    type="submit"
                    disabled={isSubmitting}
                    size="small"
                  >
                    {warehouse ? "Update Location" : "Create Location"}
                  </Button>
                </Box>
              </Box>
            </form>
          )}
        </Formik>
      </Card>
    </Box>
  );
}

export default UpdateWarehouseForm;
