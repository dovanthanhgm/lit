import React, { useEffect, useState } from 'react';
import { AcceptInvitation } from "src/services/account";
import {
    Box,
    Button,
    Container,
    Typography,
    useTheme,
    useMediaQuery,
    makeStyles,
    LinearProgress
  } from '@material-ui/core';
import { useHistory, useParams, Link as RouterLink } from "react-router-dom";
import authService from "src/services/authService";
import Page from 'src/components/Page';
import { SILENT_LOGIN } from "src/actions/accountActions";
import { useDispatch } from 'react-redux';

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    minHeight: '100%',
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(3),
    paddingTop: 80,
    paddingBottom: 80
  },
  image: {
    maxWidth: '100%',
    width: 560,
    maxHeight: 300,
    height: 'auto'
  }
}));

const InvitationAccepted = () => {
    const { token } = useParams();
    const history = useHistory();
    const classes = useStyles();
    const theme = useTheme();
    const [ invite, setInvite] = useState(true);
    const dispatch = useDispatch();
    const mobileDevice = useMediaQuery(theme.breakpoints.down('sm'));
    const accepted = async () => {
        const body = {
            "token": token
        };
        try{
            const request = await AcceptInvitation({body: body});
            if(request.status === 200){
                authService.setSession(request.data.data['accessToken'], null, null, request.data.data['permissionsToken'], request.data.data['selfToken']);
                const user = await authService.loginInWithToken();
                let date = new Date(Date.parse(user.created_at));
                date = date.setDate(date.getDate() + 7);
                let today = new Date();
                today = today.setDate(today.getDate());
                if(today > date){
                    setInvite(false);
                }
                else{
                    dispatch({
                        type: SILENT_LOGIN,
                        payload: {
                          user
                        }
                      });
                    history.push('/');
                }
            }
        }
        catch(e){
            console.log(e);
            setInvite(false);
        }
    }

    useEffect(() => {
        accepted();
    });

    return (
    <Page
        className={classes.root}
        title={invite ? "Redirecting" : "Oops ..."}
    >
        <Container maxWidth="lg">
            <Typography
                align="center"
                variant={mobileDevice ? 'h4' : 'h1'}
                color="textPrimary"
            >
                {invite ? "Redirecting ..." : "Invitation is no longer exist"}
            </Typography>
            <Typography
                align="center"
                variant="subtitle2"
                color="textSecondary"
            >
                {invite ? 
                "Please wait for a moment. We are on redirecting you to LitCommerce Dashboard."
                :
                "It seems like your invitation have been deleted or expired. Please contact your supervisor for more information."}
            </Typography>
            {invite ? 
            (<LinearProgress />) 
            : 
            (
                <Box
                    mt={6}
                    display="flex"
                    justifyContent="center"
                    >
                    <Button
                        color="secondary"
                        component={RouterLink}
                        to="/login"
                        variant="outlined"
                    >
                        To login
                    </Button>
                </Box>
            )
            }
        </Container>
    </Page>
    );
};

export default InvitationAccepted;