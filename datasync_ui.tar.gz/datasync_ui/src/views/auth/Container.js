import React from "react";
import {
  Box,
  Grid,
  makeStyles,
  Typography,
  useMediaQuery,
  useTheme
} from "@material-ui/core";
import bgImage from "src/assets/images/loginBackground.png";
import bgImageTiktok from "src/assets/images/tiktok_register.svg";
// import logoLit from "src/assets/images/logoLit2.png";
import Page from "src/components/Page";

import Header from "./LoginView/Header";
import ConnectDescription from "src/views/pages/TiktokRegister/ConnectDescription";

const useStyles = makeStyles(theme => ({
  root: {
    justifyContent: "center",
    backgroundColor: theme.palette.background.dark,
    height: "100%",
    alignItems: "center",
    backgroundImage: "linear-gradient(90deg,#4a4aff 45%,#4aa0ff 100%)"
  },
  gridStyle: {
    backgroundImage: `url(${bgImage})`,
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",

    "@media (min-width:960px)": { minHeight: "100vh" }
  },
  gridStyleTiktok: {
    backgroundImage: `url(${bgImageTiktok})`,
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",

    "@media (min-width:960px)": { minHeight: "100vh" }
  },
  icon: {
    width: 20,
    height: 20
  },
  logoStyle: {
    height: 60,
    objectFit: "contain"
  },
  itemGrid: {
    height: "100%"
  }
}));

function Container({ children, title, isRegisterTiktok = false }) {
  const theme = useTheme();
  const classes = useStyles();
  const isBigScreen = useMediaQuery(`(min-width: 960px)`);
  const breakPointHiddenLogo = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <Page
      title={title}
      className={classes.root}
      style={{ padding: 0, minHeight: "100%", height: "auto" }}
      noPadding
    >
      {!isBigScreen && <Header />}
      <Grid container className={classes.gridStyle}>
        <Grid
          item
          xs={isBigScreen ? 6 : 12}
          style={{
            minHeight: !isBigScreen ? "calc(100vh - 84px)" : "100%"
          }}
        >
          <Box
            width="100%"
            bgcolor="white"
            display="flex"
            alignItems="center"
            justifyContent="center"
            // height={isBigScreen && "100%"}
            minHeight={!isBigScreen ? "calc(100vh - 84px)" : "100%"}
          >
            {children}
          </Box>
        </Grid>
        {isBigScreen && (
          <Grid
            item
            xs={6}
            style={{
              minHeight: !isBigScreen ? "calc(100vh - 84px)" : "100%"
            }}
          >
            <Box
              width="100%"
              minHeight={!isBigScreen ? "calc(100vh - 84px)" : "100%"}
              alignItems="center"
              justifyContent="center"
              display="flex"
            >
              <Box
                width={breakPointHiddenLogo ? 400 : 500}
                textAlign="center"
                display="flex"
                flexDirection="column"
                alignItems="center"
                color="white"
              >
                <img
                  alt="Logo"
                  src={"/static/litcommerce-logo-white.svg"}
                  className={classes.logoStyle}
                />
                <Box mb={6} />
                {/*{isRegisterTiktok && (*/}
                <>
                  <img src={bgImageTiktok} alt="litLogo" width="100%" />
                  <Box mb={10} />
                  <Typography variant="h2">
                    Sell Everywhere Never Been Easier
                  </Typography>
                  <Box mb={3.5} />
                  <ConnectDescription />
                </>
                {/*)}*/}
                {/*{!isRegisterTiktok && (*/}
                {/*  <>*/}
                {/*    <img src={logoLit} alt="litLogo" width="100%" />*/}
                {/*    <Box mb={10} />*/}
                {/*    <Typography variant="h2">*/}
                {/*      Sell Everywhere Never Been Easier*/}
                {/*    </Typography>*/}
                {/*    <Box mb={3.5} />*/}
                {/*    <Typography variant="body1">*/}
                {/*      LitCommerce – a multichannel selling expert that helps you*/}
                {/*      list and sell products on the world’s largest online*/}
                {/*      marketplaces such as Amazon, Etsy, Ebay, Walmart, and*/}
                {/*      more!*/}
                {/*    </Typography>*/}
                {/*  </>*/}
                {/*)}*/}
              </Box>
            </Box>
          </Grid>
        )}
      </Grid>
    </Page>
  );
}

export default Container;
