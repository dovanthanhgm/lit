import { Box, Link, makeStyles, Typography } from "@material-ui/core";
import React from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router";
import { Link as RouterLink } from "react-router-dom";
import SingleAlert from "src/components/Notify/SingleAlert";
import ForgotPasswordForm from "./ForgotPasswordForm";
import ContainerTemplate from "../Container";

const useStyles = makeStyles(theme => ({
  root: {
    justifyContent: "center",
    backgroundColor: theme.palette.background.dark,
    display: "flex",
    height: "100%",
    minHeight: "100%",
    flexDirection: "column",
    paddingBottom: 80,
    paddingTop: 80,
    alignItems: "center"
  },
  body: {
    width: 600,
    maxWidth: 600,
    padding: `0 ${theme.spacing(3)}px`
  },
  icon: {
    width: 22,
    height: 22
  }
}));

function ForgetPassword() {
  const classes = useStyles();
  const history = useHistory();
  const { notifiRequest } = useSelector(state => state.account);

  const handleSubmitSuccess = () => {
    history.push("/");
  };

  return (
    <ContainerTemplate title="Forget Password">
      <Box className={classes.body}>
        {notifiRequest?.type === "resetPasswordFailure" && (
          <Box py={3}>
            <SingleAlert
              content={notifiRequest?.error?.errors?.email.map((item, key) => (
                <Box key={key}>{item}</Box>
              ))}
              type="error"
            />
          </Box>
        )}
        <Typography variant="h3" color="textPrimary" align="center">
          Forgot your password?
        </Typography>
        <Box mt={2}>
          <ForgotPasswordForm onSubmitSuccess={handleSubmitSuccess} />
        </Box>
        <Box my={2}>
          <Typography variant="body2" color="textSecondary">
            Nevermind, I remembered.
            <Link
              component={RouterLink}
              to="/login"
              variant="body2"
              color="primary"
            >
              Let me sign in again.
            </Link>
          </Typography>
        </Box>
      </Box>
    </ContainerTemplate>
  );
}

export default ForgetPassword;
