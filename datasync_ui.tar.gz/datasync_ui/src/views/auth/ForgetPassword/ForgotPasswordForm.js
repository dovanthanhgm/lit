import { Box, FormHelperText } from "@material-ui/core";
import { Formik } from "formik";
import PropTypes from "prop-types";
import React from "react";
import { useDispatch } from "react-redux";
import { forgotPassword } from "src/actions/accountActions";
import ButtonCustom from "src/components/MUI/Button";
import TextFieldFormik from "src/components/MUI/Formik/Text";
import * as Yup from "yup";

function ForgotPasswordForm({ className, onSubmitSuccess, ...rest }) {
  const dispatch = useDispatch();

  return (
    <Formik
      initialValues={{
        email: ""
      }}
      validationSchema={Yup.object().shape({
        email: Yup.string()
          .email("Must be a valid email")
          .max(255)
          .required("Email is required")
      })}
      onSubmit={async (values, { setStatus, setSubmitting }) => {
        try {
          const data = await dispatch(forgotPassword(values.email));
          data?.code === 200 &&
            data?.message === "Reset Password Email has been sent to email." &&
            onSubmitSuccess();
        } catch (error) {
          setStatus({ success: false });
          setSubmitting(false);
        }
      }}
    >
      {({ errors, handleSubmit, isSubmitting }) => (
        <form noValidate onSubmit={handleSubmit} {...rest}>
          <TextFieldFormik
            fullWidth
            label="Email Address"
            name="email"
            type="email"
            margin="normal"
          />
          <Box mt={2}>
            <ButtonCustom
              color="primary"
              disabled={isSubmitting}
              fullWidth
              size="large"
              type="submit"
              text="Reset Password"
            />

            {errors.submit && (
              <Box mt={3}>
                <FormHelperText error>{errors.submit}</FormHelperText>
              </Box>
            )}
          </Box>
        </form>
      )}
    </Formik>
  );
}

ForgotPasswordForm.propTypes = {
  className: PropTypes.string,
  onSubmitSuccess: PropTypes.func
};

ForgotPasswordForm.defaultProps = {
  onSubmitSuccess: () => {}
};

export default ForgotPasswordForm;
