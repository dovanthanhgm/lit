import { Box, FormHelperText, Link, Typography } from "@material-ui/core";
import { Formik } from "formik";
import PropTypes from "prop-types";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  login,
  openDrawerState,
  openGuideModal,
  setLogOutStatus
} from "src/actions/accountActions";
import ButtonCustom from "src/components/MUI/Button";
import TextFieldFormik from "src/components/MUI/Formik/Text";
import useQuery, { useQueryV2 } from "src/hooks/useQuery";
import * as Yup from "yup";
import { Link as RouterLink } from "react-router-dom";
import { handleResetSession } from "src/utils/ScrispChat";
import authService from "src/services/authService";
import { handleRedirectInstallCart } from "src/views/pages/TiktokRegister/Helper/installTiktokRedirect";
import { useHistory } from "react-router";

function LoginForm({ handleChangeEmail, onSubmitSuccess, ...rest }) {
  const dispatch = useDispatch();
  const history = useHistory();
  const email = useQuery().get("email");
  const isShowGuide = localStorage.getItem("showGuide"); //value get from local is string
  const { cart } = useQueryV2();
  const token = useSelector(state => state?.account?.token_tiktok);

  return (
    <Formik
      initialValues={{
        email: email ? email : "",
        password: ""
      }}
      validationSchema={Yup.object().shape({
        email: Yup.string()
          .email("Must be a valid email")
          .max(255)
          .required("Email is required"),
        password: Yup.string()
          .max(255)
          .required("Password is required")
      })}
      onSubmit={async (values, { setStatus, setSubmitting }) => {
        handleChangeEmail(values.email);
        localStorage.removeItem("openDrawer");
        try {
          if (cart && token) {
            await authService.loginWithEmailAndPassword(
              values.email,
              values.password
            );
            await handleRedirectInstallCart(cart, token, history);
          } else {
            await dispatch(login(values.email, values.password));
            onSubmitSuccess();
            dispatch(openDrawerState(true));
            dispatch(setLogOutStatus(false));
            handleResetSession();
            if (!isShowGuide) {
              localStorage.setItem("showGuide", "close");
              dispatch(openGuideModal(true));
            }
          }
        } catch (error) {
          setStatus({ success: false });
          setSubmitting(false);
        }
      }}
    >
      {({ errors, handleSubmit, isSubmitting }) => (
        <form noValidate onSubmit={handleSubmit} {...rest}>
          <TextFieldFormik
            fullWidth
            label="Email Address"
            margin="normal"
            name="email"
            type="email"
          />
          <TextFieldFormik
            fullWidth
            label="Password"
            margin="normal"
            name="password"
            type="password"
          />
          <Box mb={1.5}>
            <Typography align="right" variant="body2" color="textSecondary">
              <Link
                component={RouterLink}
                to="/forgot-password"
                variant="body2"
                color="primary"
              >
                Forgot your password?
              </Link>
            </Typography>
          </Box>
          <Box>
            <ButtonCustom
              color="secondary"
              style={{ textTransform: "none" }}
              disabled={isSubmitting}
              fullWidth
              size="large"
              type="submit"
              text="Sign in now"
            />
            {errors.submit && (
              <Box mt={3}>
                <FormHelperText error>{errors.submit}</FormHelperText>
              </Box>
            )}
          </Box>
        </form>
      )}
    </Formik>
  );
}

LoginForm.propTypes = {
  className: PropTypes.string,
  onSubmitSuccess: PropTypes.func
};

LoginForm.defaultProps = {
  onSubmitSuccess: () => {}
};

export default LoginForm;
