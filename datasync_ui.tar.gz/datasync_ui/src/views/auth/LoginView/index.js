import {
  Box,
  Button,
  CircularProgress,
  Grid,
  Link,
  makeStyles,
  Typography
} from "@material-ui/core";
import CardGiftcardIcon from "@material-ui/icons/CardGiftcard";
import FacebookIcon from "@material-ui/icons/Facebook";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router";
import { Link as RouterLink, useLocation } from "react-router-dom";
import {
  LOGIN_REQUEST,
  logout,
  resendEmail,
  setUserData
} from "src/actions/accountActions";
import authService from "src/services/authService";
import axios from "src/utils/axios";
import { checkUserAppType } from "src/utils/helper";
import LoginForm from "./LoginForm";
import SingleAlert from "src/components/Notify/SingleAlert";
import { OfferTime } from "src/components/InputField/OfferTime";
import Container from "../Container";
import Cookies from "universal-cookie";
import { handleResetChatSession } from "src/utils/ScrispChat";
import { showEndYearSale } from "src/constants/index";
import useQueryParamInRedirect from "src/hooks/useQueryParamInRedirect";

const useStyles = makeStyles(theme => ({
  icon: {
    width: 20,
    height: 20
  }
}));
const cookies = new Cookies();

const currentHostname =
  window.location.hostname === "localhost" ? "localhost" : ".litcommerce.com";

function LoginView() {
  const classes = useStyles();
  const history = useHistory();
  const { getParamUrlString } = useQueryParamInRedirect();
  const dispatch = useDispatch();
  const location = useLocation();
  const { notifiRequest, emailRegister, sale_data } = useSelector(
    state => state.account
  );

  const [email, setEmail] = useState("");
  const [isLoadingResend, setIsLoadingResend] = useState(false);
  const [alertInactiveAccount, setAlertInactiveAccount] = useState(false);
  const [saleData, setSaleData] = useState({});
  const offerEnds = new Date(saleData?.offer_ends).toDateString();

  useEffect(() => {
    setSaleData(sale_data);
  }, [sale_data]);

  const handleChangeEmail = email => {
    setEmail(email);
  };

  useEffect(() => {
    window.addEventListener("message", messageEvent);
    return () => {
      window.removeEventListener("message", messageEvent);
    };
  });

  const messageEvent = async event => {
    try {
      const data =
        typeof event.data === "string" ? JSON.parse(event.data) : event.data;
      if (data?.id === "litextension") {
        if (data.code === 200 && data?.data?.status !== "inactive") {
          authService.setSession(data.data.access_token);
          const user = await authService.loginInWithToken();

          checkUserAppType(user);

          await dispatch(setUserData(user));
          handleSubmitSuccess();
          setAlertInactiveAccount(false);
        }
        if (data?.data?.status === "inactive") {
          //nếu popup trả về có status = inactive, thì logout acc hiện tại
          //rồi redirect ra page login kèm msg là acc đang inactive
          setAlertInactiveAccount(true);
          dispatch(logout());
          handleResetChatSession();
          history.push("/login");
        }
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  const handleSubmitSuccess = () => {
    history.push(getParamUrlString || "/");
  };

  const handleConnectSocial = name => async () => {
    cookies.remove("accessToken", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("refreshToken", {
      domain: currentHostname,
      path: "/"
    });
    cookies.remove("loginByToken", {
      domain: currentHostname,
      path: "/"
    });
    dispatch({ type: LOGIN_REQUEST });
    const res = await axios.get(`/merchant/${name}/login`);

    if (res?.data) {
      window.open(
        res?.data,
        "_blank",
        "location=yes,height=570,width=520,scrollbars=yes,status=yes"
      );
    }
  };

  const handleResend = async email => {
    setIsLoadingResend(true);
    const body = {
      email: email
    };
    try {
      await dispatch(resendEmail(body));
      setIsLoadingResend(false);
    } catch (error) {
      setIsLoadingResend(false);
    }
  };

  const status = notifiRequest?.error?.status;
  const type = notifiRequest?.type;

  const notifiAll = {
    resetPasswordSuccess: {
      content: (
        <Typography variant="body2">
          Your password was reset! Please check your mail to get your new
          password.&nbsp;
        </Typography>
      ),
      type: "success"
    },
    resetPasswordFailure: {
      content: "",
      type: "none"
    },
    registerSuccess: {
      content: (
        <>
          <Typography variant="body2">
            Thank you, your account registration is completed. Please login.
          </Typography>
        </>
      ),
      type: "success"
    },
    registerFailure: {
      content: (
        <Box display="flex">
          <Typography variant="body2">
            Account registration failed, please check your error detail.
            <Link onClick={() => handleResend(emailRegister)}>Click here</Link>
          </Typography>
          <Box pl={2}>
            {isLoadingResend && <CircularProgress size="25px" />}
          </Box>
        </Box>
      ),
      type: "warning"
    },
    resendEmailSuccess: {
      content: (
        <>
          <Typography variant="subtitle2">
            We have e-mailed your password reset link!
          </Typography>
          <Typography>
            If you do not see it, please also check your spam/junk folder.
            <a
              target="_blank"
              href="https://mail.google.com/mail/u/#inbox"
              rel="noopener noreferrer"
            >
              &nbsp;Click here
            </a>
          </Typography>
        </>
      ),
      type: "success"
    },
    resendEmailFailure: {
      content: (
        <Box display="flex">
          <Typography variant="body2">
            {notifiRequest?.error?.errors?.email?.map(item => (
              <Typography variant="body2">{item}</Typography>
            ))}
          </Typography>
          <Box pl={2}>
            {isLoadingResend && <CircularProgress size="25px" />}
          </Box>
        </Box>
      ),
      type: "error"
    },
    loginFailure: {
      403: {
        status: 403,
        content: (
          <Box display="flex">
            <Typography variant="body2">
              Login failed, your account might not be activated&nbsp;
              <Link onClick={() => handleResend(email)}>Click here</Link>
            </Typography>
            <Box pl={2}>
              {isLoadingResend && <CircularProgress size="25px" />}
            </Box>
          </Box>
        ),
        type: "warning"
      },
      401: {
        status: 401,
        content: "Login failed, invalid email or password.",
        type: "error"
      }
    }
  };

  return (
    <Container title="Login">
      <Box width={500} p={5}>
        <Box>
          {type &&
            (status ? (
              <Box py={2}>
                <SingleAlert
                  content={notifiAll?.[type]?.[status]?.content || "noContent"}
                  type={notifiAll?.[type]?.[status]?.type || "none"}
                />
              </Box>
            ) : (
              <Box py={2}>
                <SingleAlert
                  content={notifiAll[type]?.content || "noContent"}
                  type={notifiAll[type]?.type || "none"}
                />
              </Box>
            ))}
          {alertInactiveAccount && (
            <Box py={2}>
              <SingleAlert
                content="Sorry, your account is inactive and may not login"
                type="info"
              />
            </Box>
          )}
          {saleData.offer_free_plan === "1" && (
            <Box py={2}>
              <SingleAlert
                icon={<CardGiftcardIcon />}
                content={`Special offer: get free Unlimited Plan for ${OfferTime(
                  saleData
                )} (ends in ${offerEnds}).`}
                type="success"
              />
            </Box>
          )}
          {showEndYearSale && (
            <Box py={2}>
              <SingleAlert
                icon={<CardGiftcardIcon />}
                content={
                  <>
                    Sign in to get&nbsp;
                    <Typography
                      style={{ fontWeight: "bold", fontSize: 14 }}
                      component="span"
                    >
                      30%
                    </Typography>
                    &nbsp;discount for all plans.
                  </>
                }
                type="success"
              />
            </Box>
          )}
        </Box>

        <Typography variant="h3" color="textPrimary" align="center">
          Sign in
        </Typography>
        <Box my={3.5}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Button
                startIcon={<FacebookIcon size="small" />}
                variant="contained"
                color="primary"
                fullWidth
                style={{ padding: 8 }}
                onClick={handleConnectSocial("facebook")}
              >
                <Typography
                  variant="body2"
                  style={{ textTransform: "none", fontWeight: 500 }}
                >
                  Login with Facebook
                </Typography>
              </Button>
            </Grid>
            <Grid item xs={12} md={6}>
              <Button
                style={{ padding: 8 }}
                startIcon={
                  <img
                    className={classes.icon}
                    alt=""
                    src={"/static/images/logo/google.svg"}
                  />
                }
                variant="contained"
                fullWidth
                onClick={handleConnectSocial("google")}
              >
                <Typography
                  style={{ textTransform: "none", fontWeight: 500 }}
                  variant="body2"
                >
                  Login with Google
                </Typography>
              </Button>
            </Grid>
          </Grid>
        </Box>
        <Box mx={6}>
          <Typography variant="body2" color="textSecondary" align="center">
            or login with email address
          </Typography>
        </Box>
        <Box mt={2}>
          <LoginForm
            onSubmitSuccess={handleSubmitSuccess}
            handleChangeEmail={handleChangeEmail}
          />
        </Box>
        <Box my={2}>
          <Typography variant="body2" color="textSecondary" align="center">
            Don't have an account?{" "}
            <Link
              component={RouterLink}
              to={`/register${location.search}`}
              variant="body2"
              color="primary"
            >
              Sign up
            </Link>
          </Typography>
        </Box>
      </Box>
    </Container>
  );
}

export default LoginView;
