import { makeStyles } from "@material-ui/core";
import React from "react";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "8px 45px",
    display: "flex",
    justifyContent: "center",
    backgroundColor: theme.palette.background.appbarColor,
  },
  logoStyle: {
    height: 60,
    objectFit: "contain",
  },
}));

function Header() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <img
        alt="Logo"
        src={"/static/litcommerce-logo-white.svg"}
        className={classes.logoStyle}
      />
    </div>
  );
}

export default Header;
