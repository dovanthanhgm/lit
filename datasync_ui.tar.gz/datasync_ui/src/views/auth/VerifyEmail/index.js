import { makeStyles } from "@material-ui/core";
import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router";
import { getResiterEmail, registerEmail } from "src/actions/accountActions";
import Page from "src/components/Page";

const useStyles = makeStyles(theme => ({
  root: {
    justifyContent: "center",
    backgroundColor: theme.palette.background.dark,
    display: "flex",
    height: "100%",
    minHeight: "100%",
    flexDirection: "column",
    paddingBottom: 80,
    paddingTop: 80
  }
}));

function VerifyEmail() {
  const classes = useStyles();
  const history = useHistory();
  const dispatch = useDispatch();
  const { email, token } = useParams();

  useEffect(() => {
    dispatch(getResiterEmail(email));
    const body = {
      email: email,
      token: token
    };
    async function fetchRegisterEmail() {
      await dispatch(registerEmail(body));
      history.push("/login");
    }
    fetchRegisterEmail();
  });

  return <Page className={classes.root} title="Verify Email" noPadding></Page>;
}

export default VerifyEmail;
