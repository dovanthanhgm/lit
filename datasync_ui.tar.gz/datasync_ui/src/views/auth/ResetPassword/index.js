import { Box, Container, Typography } from "@material-ui/core";
import React from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router";
import SingleAlert from "src/components/Notify/SingleAlert";
import ResetPasswordForm from "./ResetPasswordForm";
import ContainerTemplate from "../Container";

function ResetPassword() {
  const history = useHistory();
  const { notifiRequest } = useSelector((state) => state.account);

  const handleSubmitSuccess = () => {
    history.push("/login");
  };

  return (
    <ContainerTemplate title="Reset Password">
      <Container maxWidth="sm">
        {notifiRequest.type === "resetPasswordFailure" && (
          <Box py={3}>
            <SingleAlert
              content={notifiRequest?.error?.errors?.token.map((item) => (
                <Box>{item}</Box>
              ))}
              type="error"
            />
          </Box>
        )}
        <Box>
          <Typography
            gutterBottom
            variant="h3"
            color="textPrimary"
            align="center"
          >
            Reset Password
          </Typography>
          <Box mt={3}>
            <ResetPasswordForm onSubmitSuccess={handleSubmitSuccess} />
          </Box>
        </Box>
      </Container>
    </ContainerTemplate>
  );
}

export default ResetPassword;
