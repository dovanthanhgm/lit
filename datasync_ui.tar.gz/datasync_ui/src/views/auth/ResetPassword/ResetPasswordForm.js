import { Box, FormHelperText, Link, Typography } from "@material-ui/core";
import { Formik } from "formik";
import PropTypes from "prop-types";
import React from "react";
import { useDispatch } from "react-redux";
import { useParams } from "react-router";
import { resetPassword } from "src/actions/accountActions";
import * as Yup from "yup";

import Button from "src/components/MUI/Button";
import TextFieldFormik from "src/components/MUI/Formik/Text";
import CheckboxFormik from "src/components/MUI/Formik/Checkbox";

function ResetPasswordForm({ onSubmitSuccess, ...rest }) {
  const { token } = useParams();
  const dispatch = useDispatch();

  return (
    <Formik
      initialValues={{
        email: "",
        password: "",
        confirmPassword: "",
        policy: false,
      }}
      validationSchema={Yup.object().shape({
        email: Yup.string()
          .email("Must be a valid email")
          .max(255)
          .required("Email is required"),
        password: Yup.string()
          .min(7)
          .max(255)
          .required("Password is required"),
        confirmPassword: Yup.string()
          .min(7)
          .max(255)
          .oneOf([Yup.ref("password")], "Password's not match")
          .required("Required!"),
        policy: Yup.boolean().oneOf([true], "This field must be checked"),
      })}
      onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
        try {
          const body = {
            email: values.email,
            token: token,
            new_password: values.password,
          };
          const data = await dispatch(resetPassword(body));
          if (data) onSubmitSuccess();
        } catch (error) {
          setStatus({ success: false });
          setErrors({ submit: error.message });
          setSubmitting(false);
        }
      }}
    >
      {({ errors, handleSubmit, isSubmitting, touched }) => (
        <form onSubmit={handleSubmit} {...rest}>
          <TextFieldFormik
            fullWidth
            label="Email Address"
            margin="normal"
            name="email"
            type="email"
          />
          <TextFieldFormik
            fullWidth
            label="Password"
            margin="normal"
            name="password"
            type="password"
          />
          <TextFieldFormik
            fullWidth
            label="Confirm Password"
            margin="normal"
            name="confirmPassword"
            type="password"
          />
          <Box alignItems="center" display="flex" mt={2} ml={-1}>
            <CheckboxFormik name="policy" />
            <Typography variant="body2" color="textSecondary">
              I have read the{" "}
              <Link
                component="a"
                href="https://litcommerce.com/terms-and-conditions/"
                color="secondary"
                target="_blank"
              >
                Terms and Conditions
              </Link>
            </Typography>
          </Box>
          {Boolean(touched.policy && errors.policy) && (
            <FormHelperText error>{errors.policy}</FormHelperText>
          )}
          <Box mt={2}>
            <Button
              color="secondary"
              disabled={isSubmitting}
              fullWidth
              size="large"
              type="submit"
              text="Reset Password"
            />
          </Box>
        </form>
      )}
    </Formik>
  );
}

ResetPasswordForm.propTypes = {
  onSubmitSuccess: PropTypes.func,
};

ResetPasswordForm.default = {
  onSubmitSuccess: () => {},
};

export default ResetPasswordForm;
