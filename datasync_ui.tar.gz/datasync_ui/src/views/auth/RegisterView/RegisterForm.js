import { Box, Typography } from "@material-ui/core";
import { Formik } from "formik";
import { useHistory } from "react-router";
import Link from "src/components/MUI/Link";
import PropTypes from "prop-types";
import React, { useEffect, useState } from "react";
import { loadReCaptcha, ReCaptcha } from "react-recaptcha-v3";
import { useDispatch, useSelector } from "react-redux";
import {
  login,
  openDrawerState,
  openGuideModal,
  register
} from "src/actions/accountActions";
import Button from "src/components/MUI/Button";
import TextFieldFormik from "src/components/MUI/Formik/Text";
import * as Yup from "yup";
import useQueryParamInRedirect from "src/hooks/useQueryParamInRedirect";
import authService from "src/services/authService";
import { handleRedirectInstallCart } from "src/views/pages/TiktokRegister/Helper/installTiktokRedirect";
import { useQueryV2 } from "src/hooks/useQuery";
// import CardGiftcardIcon from "@material-ui/icons/CardGiftcard";

const RecaptchaKey = process.env.REACT_APP_RECAPTCHA_SITE_KEY;

function RegisterForm({ msgRequest, setMsgRequest, ...rest }) {
  const dispatch = useDispatch();
  const history = useHistory();
  const recaptchaRef = React.useRef();
  const [recaptcha, setrecaptcha] = useState();
  const isShowGuide = localStorage.getItem("showGuide"); //value get from local is string
  const { getParamUrlString } = useQueryParamInRedirect();
  const { cart } = useQueryV2();
  const token = useSelector(state => state?.account?.token_tiktok);

  const isSquareSpace = getParamUrlString.includes("/merchant/squarespace/");
  const isWooCommerce = getParamUrlString.includes("merchants/woocommerce");

  const handleSubmitSuccess = () => {
    history.push(getParamUrlString || "/");
  };

  useEffect(() => {
    loadReCaptcha(RecaptchaKey);
  }, []);

  const verifyCallback = key => {
    setrecaptcha(key);
  };

  return (
    <Formik
      initialValues={{
        name: "",
        email: "",
        new_pwd: "",
        whatsapp: "",
        skype: ""
        // policy: false,
      }}
      validationSchema={Yup.object().shape({
        name: Yup.string()
          .max(255)
          .required("Name is required"),
        email: Yup.string()
          .email("Must be a valid email")
          .max(255)
          .required("Email is required"),
        new_pwd: Yup.string()
          .min(7, "At least 7 characters")
          .max(255)
          .required("Password is required"),
        skype: Yup.string().max(255),
        whatsapp: Yup.string().max(255)
        // policy: Yup.boolean().oneOf([true], "This field is required"),
      })}
      onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
        try {
          if (recaptcha) {
            const body = {
              ...values,
              pwd: values.new_pwd
            };
            if (isSquareSpace) {
              body.market_app = "squarespace";
            }
            if (isWooCommerce) {
              body.market_app = "woocommerce";
            }
            localStorage.removeItem("openDrawer");
            await dispatch(register({ ...body, recaptcha }));

            if (cart && token) {
              await authService.loginWithEmailAndPassword(
                values.email,
                values.new_pwd
              );
              await handleRedirectInstallCart(cart, token, history);
            } else {
              try {
                await dispatch(login(values.email, values.new_pwd));
                handleSubmitSuccess();
                dispatch(openDrawerState(true));
                if (!isShowGuide) {
                  localStorage.setItem("showGuide", "close");
                  dispatch(openGuideModal(true));
                }
              } catch (error) {
                setStatus({ success: false });
                setSubmitting(false);
              }
            }
          }
        } catch (error) {
          recaptchaRef.current.execute();
          setMsgRequest(error);
          setStatus({ success: false });
          setErrors({ submit: error.message });
          setSubmitting(false);
        }
      }}
    >
      {({ handleSubmit, isSubmitting }) => (
        <form onSubmit={handleSubmit} {...rest}>
          <TextFieldFormik
            fullWidth
            label="Name"
            name="name"
            size="small"
            margin="normal"
          />
          <TextFieldFormik
            fullWidth
            label="Email Address"
            name="email"
            type="email"
            size="small"
            margin="normal"
          />
          <TextFieldFormik
            fullWidth
            label="Password"
            name="new_pwd"
            type="password"
            size="small"
            margin="normal"
            autoComplete="new-password"
          />
          <ReCaptcha
            ref={recaptchaRef}
            sitekey={RecaptchaKey}
            action="Test"
            verifyCallback={verifyCallback}
          />
          <Box justifyItems="center" alignItems="center" my={2}>
            <Typography align="center" variant="body2" color="textSecondary">
              By signing up, you agree to our&nbsp;
              <Link
                component="a"
                color="secondary"
                target="_blank"
                href="https://litcommerce.com/terms-and-conditions/"
              >
                Terms and Conditions&nbsp;
              </Link>
              and&nbsp;
              <Link
                component="a"
                target="_blank"
                href="https://litcommerce.com/privacy-policy/"
                color="secondary"
              >
                Privacy Policy
              </Link>
            </Typography>
          </Box>
          <Box mt={2}>
            <Button
              color="secondary"
              disabled={isSubmitting}
              fullWidth
              size="large"
              type="submit"
              text="Create account"
            />
          </Box>
        </form>
      )}
    </Formik>
  );
}

RegisterForm.propTypes = {
  onSubmitSuccess: PropTypes.func
};

RegisterForm.default = {
  onSubmitSuccess: () => {}
};

export default RegisterForm;
