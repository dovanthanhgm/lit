import {
  Box,
  Container,
  Divider,
  Link,
  makeStyles,
  Typography
} from "@material-ui/core";
import CardGiftcardIcon from "@material-ui/icons/CardGiftcard";
import React, { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { Link as RouterLink } from "react-router-dom";
import SingleAlert from "src/components/Notify/SingleAlert";
import RegisterForm from "./RegisterForm";
import { OfferTime } from "src/components/InputField/OfferTime";

import ContainerTemplate from "../Container";
import { showEndYearSale } from "src/constants/index";

const useStyles = makeStyles(theme => ({
  root: {
    justifyContent: "center",
    backgroundColor: theme.palette.background.dark,
    display: "flex",
    height: "100%",
    minHeight: "100%",
    flexDirection: "column",
    paddingBottom: 80,
    paddingTop: 80
  },
  contentBody: {
    padding: theme.spacing(3)
  }
}));

function RegisterView() {
  const classes = useStyles();
  const { notifiRequest, sale_data } = useSelector(state => state.account);

  const [saleData, setSaleData] = useState({});
  const offerEnds = new Date(saleData?.offer_ends).toDateString();

  useEffect(() => {
    setSaleData(sale_data);
  }, [sale_data]);
  //
  // const handleSubmitSuccess = () => {
  //   history.push(`/login${location.search}`);
  // };

  const errors = useMemo(() => {
    let result = "";
    if (notifiRequest?.error && notifiRequest?.type === "registerFailure") {
      result = notifiRequest?.error?.errors?.email ||
        notifiRequest?.error?.errors?.captcha || ["Register Fail"];
    }

    return result;
  }, [notifiRequest]);

  return (
    <ContainerTemplate title="Register">
      <Container maxWidth="sm">
        {saleData?.offer_free_plan === "1" && (
          <Box py={2} px={3}>
            <SingleAlert
              icon={<CardGiftcardIcon />}
              content={`Special offer: get free Unlimited Plan for ${OfferTime(
                saleData
              )} (ends in ${offerEnds}).`}
              type="success"
            />
          </Box>
        )}
        {showEndYearSale && (
          <Box py={2} px={3}>
            <SingleAlert
              icon={<CardGiftcardIcon />}
              content={
                <>
                  Sign in to get&nbsp;
                  <Typography
                    style={{ fontWeight: "bold", fontSize: 14 }}
                    component="span"
                  >
                    30%
                  </Typography>
                  &nbsp;discount for all plans.
                </>
              }
              type="success"
            />
          </Box>
        )}
        {errors?.map && (
          <Box py={2} px={3}>
            <SingleAlert
              content={errors.map((item, key) => (
                <Box key={key}>{item}</Box>
              ))}
              type="warning"
            />
          </Box>
        )}

        <Box className={classes.contentBody}>
          <Typography
            gutterBottom
            variant="h3"
            color="textPrimary"
            align="center"
          >
            Sign up
          </Typography>
          <Box mt={3}>
            <RegisterForm />
          </Box>
          <Box my={2}>
            <Divider />
          </Box>
          <Typography align="center" variant="body2" color="textSecondary">
            Already have an account?&nbsp;
            <Link
              component={RouterLink}
              to="/login"
              variant="body2"
              color="primary"
            >
              Login here
            </Link>
          </Typography>
        </Box>
      </Container>
    </ContainerTemplate>
  );
}

export default RegisterView;
