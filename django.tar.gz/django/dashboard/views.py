from rest_framework import generics

from rest_framework import generics

from django.http import JsonResponse

from accounts.utils import AccountUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from libs.utils import *
from products.utils import ProductUtils


def total_listing(user_id):
	model_catalog = ProductUtils().get_model_catalog(user_id = user_id)
	channels = Channel.objects.filter(user_id = user_id, deleted_at__isnull = True).exclude(type = 'file')
	data_stats = []
	total_listings = 0
	for channel in channels:
		if channel.default:
			continue
		data_channel = {"channel": channel.name}
		if json_decode(channel.channel_number_products) is not False:
			data_channel.update(json_decode(channel.channel_number_products))
		else:
			channel_type = channel.type
			where = model_catalog.create_where_condition('is_variant', False)
			data = dict()
			product_status = ['error', 'draft']

			channel_product_status = ProductUtils().products_status(channel)
			if not channel_product_status:
				product_status.append('active')
			where_channel_status = where
			for row in product_status:
				where.update(model_catalog.create_where_condition('channel.channel_{}.status'.format(channel.id), row, "="))
				data[row] = model_catalog.count(where)
			if channel_product_status:
				where_channel_status.update(model_catalog.create_where_condition('channel.channel_{}.status'.format(channel.id), 'active', "="))

				status_field, status = channel_product_status
				for row in status:
					where_channel_status.update(model_catalog.create_where_condition(f'channel.channel_{channel.id}.{status_field}', row, "="))
					data[row] = model_catalog.count(where_channel_status)
				where_channel_status.update(model_catalog.create_where_condition(f'channel.channel_{channel.id}.{status_field}', channel_product_status[1], "nin"))
				data['active'] = model_catalog.count(where_channel_status)
			channel.channel_number_products = json_encode(data)
			channel.save()
			data_channel.update(data)
		# for listing in listings:
		# 	try:
		# 		data_channel[listing['channel'].get(f"channel_{channel.id}").get('status')] += 1
		# 	except:
		# 		data_channel[listing['channel'].get(f"channel_{channel.id}").get('status')] = 1

		data_stats.append(data_channel)
		for i in data_channel:
			if i != "channel":
				total_listings += data_channel[i]

	data_listing = {
		"total_listings": total_listings,
		"data": data_stats
	}
	return data_listing


def total_order(user_id):
	import dateutil.relativedelta
	model_order = ProductUtils().get_model_order(user_id = user_id)
	data = []
	total_sale = 0
	sale_today = 0
	current_day = datetime.today()
	for i in range(7):
		date_filter = current_day.strftime("%Y-%m-%d 00:00:00")
		if not i:
			where = model_order.create_where_condition('created_at', date_filter, '>=')
		else:
			where_list = [model_order.create_where_condition('created_at', date_filter, '<')]
			current_day -= dateutil.relativedelta.relativedelta(days = 1)
			date_filter = current_day.strftime("%Y-%m-%d 00:00:00")
			where_list.append(model_order.create_where_condition('created_at', date_filter, '>='))
			where = model_order.create_where_condition(None, where_list, 'and')

		total = model_order.count(where)
		if not i:
			sale_today = total
		total_sale += total
		data.append({
			"time": current_day.strftime("%Y-%b-%d"),
			"total_sale": total
		})
	data.reverse()
	channel_default = ChannelUtils().get_default_channel(user_id)
	where_order_error = model_order.create_where_condition(f'channel.channel_{channel_default.id}.status', 'error')
	where_order_error.update(model_order.create_where_condition('status', 'processed_in_channel', '!='))
	order_error = model_order.count(where_order_error)
	where_order_unlink = model_order.create_where_condition(f'link_status', 'unlink')
	where_order_unlink.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.status', 'error'))
	where_order_unlink.update(model_order.create_where_condition('status', 'processed_in_channel', '!='))

	order_unlink = model_order.count(where_order_unlink)

	data_edit = {
		"total_sale": total_sale,
		"data": data,
		"sale_today": sale_today,
		"order_unlink": order_unlink,
		"order_error": order_error
	}
	return data_edit


class CountListingAPIView(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)

		data_listing = total_listing(user_id)
		return JsonResponse(data_listing, safe = False)


class CountOrderAPIView(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		data_edit = total_order(AccountUtils().get_user_id(request))
		return JsonResponse(data_edit, safe = False)


class DashboardApiView(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)

		order = total_order(user_id)
		listing = total_listing(user_id)
		return JsonResponse({'total_order': order, 'total_listing': listing})
