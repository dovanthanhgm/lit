from django.urls import path

from . import views

urlpatterns = [
	path("/total-listing", views.CountListingAPIView.as_view(), name = "total-listing"),
	path("/total-order", views.CountOrderAPIView.as_view(), name = "total-order"),
	path("/stats", views.DashboardApiView.as_view(), name = "dashboard-stat")
]
