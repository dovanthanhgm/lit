from django.db import models


# Create your models here.
class CrispConversationModel(models.Model):
	session_id = models.CharField(max_length = 125, blank = True, null = False)
	customer_name = models.CharField(max_length = 125, blank = True, null = False)
	customer_email = models.CharField(max_length = 125, blank = True, null = False)
	state = models.CharField(max_length = 125, blank = True, null = False)
	segments = models.TextField(null = True)
	updated_at = models.DateTimeField(null = True)
	created_at = models.DateTimeField(null = True)
	time_last_message = models.IntegerField(null = True)
	have_new_message = models.BooleanField(default = False)
	is_blocked = models.BooleanField(default = False)
	is_skip = models.BooleanField(default = False)
	max_position = models.IntegerField(null = False, default = 0)
	last_message_from = models.CharField(max_length = 125, blank = True, null = False)
	first_max_position_message = models.IntegerField(null = False, default = 0)
	class Meta:
		db_table = "crisp_conversation"
		ordering = ['-id']


class CrispUserModel(models.Model):
	name = models.CharField(max_length = 125, blank = True, null = False)
	email = models.CharField(max_length = 125, blank = True, null = False)
	status = models.BooleanField(default = False)
	level = models.IntegerField(null = True)
	shift_mon = models.CharField(max_length = 255, null = True, blank = True)
	shift_tue = models.CharField(max_length = 255, null = True, blank = True)
	shift_wed = models.CharField(max_length = 255, null = True, blank = True)
	shift_thu = models.CharField(max_length = 255, null = True, blank = True)
	shift_fri = models.CharField(max_length = 255, null = True, blank = True)
	shift_sat = models.CharField(max_length = 255, null = True, blank = True)
	shift_sun = models.CharField(max_length = 255, null = True, blank = True)


	class Meta:
		db_table = "crisp_user"
		ordering = ['id']


class CrispMessageModel(models.Model):
	message_id = models.CharField(max_length = 125, blank = True, null = False)
	session_id = models.CharField(max_length = 125, blank = True, null = False)
	delivered = models.CharField(max_length = 125, blank = True, null = False)
	read = models.CharField(max_length = 125, blank = True, null = False)
	from_user = models.CharField(max_length = 125, blank = True, null = True)
	from_nickname = models.CharField(max_length = 125, blank = True, null = False)
	content = models.TextField(default = False)
	type = models.CharField(max_length = 25, blank = True, null = False)
	origin = models.CharField(max_length = 25, blank = True, null = False)
	timestamp = models.DateTimeField()
	from_operator = models.BooleanField(default = False)
	exceed_one_minute = models.BooleanField(default = False)
	is_first_message = models.BooleanField(default = False)
	shift = models.IntegerField(null = True)
	position = models.IntegerField(null = True)
	message_time = models.IntegerField(null = True)
	response_time = models.IntegerField(null = True)
	accounting = models.IntegerField(null = True)
	message_shift_id = models.CharField(null = True, max_length = 125)

	class Meta:
		db_table = "crisp_message"
		ordering = ['-id']
		unique_together = ['session_id', 'message_id']


class CrispMessageFaults(models.Model):
	session_id = models.CharField(max_length = 125, blank = True, null = False)
	customer_content = models.TextField(default = False, null = True)
	reply_content = models.TextField(default = False, null = True)
	timestamp = models.DateTimeField()
	reply_time = models.DateTimeField()
	message_time = models.IntegerField(null = True)
	shift = models.IntegerField(null = True)
	fault_type = models.IntegerField(choices = ((1, 'Exceed 1m'), (2, 'No reply')))
	accounting_month = models.IntegerField(null = True)
	accounting_day = models.IntegerField(null = True)
	staff_fault = models.TextField(null = True)
	response_time = models.IntegerField(null = True)
	class Meta:
		db_table = "crisp_message_faults"
		ordering = ['-id']

class CrispUserMessageFaults(models.Model):
	session_id = models.CharField(max_length = 125, blank = True, null = False)
	message_fault = models.ForeignKey(CrispMessageFaults, on_delete = models.CASCADE, null = True)
	from_nickname = models.CharField(max_length = 125, blank = True, null = False)
	fault_type = models.IntegerField(choices = ((1, 'Exceed 1m'), (2, 'No reply')))
	accounting_month = models.IntegerField(null = True)
	accounting_day = models.IntegerField(null = True)
	shift = models.IntegerField(null = True)
	response_time = models.IntegerField(null = True)

	class Meta:
		db_table = "crisp_user_message_faults"
		ordering = ['-id']


class CrispConversationNoReply(models.Model):
	session_id = models.CharField(max_length = 125, blank = True, null = False)
	customer_content = models.CharField(max_length = 125, blank = True, null = False)
	timestamp = models.DateTimeField()
	message_time = models.IntegerField(null = True)

	class Meta:
		db_table = "crisp_conversation_no_reply"
		ordering = ['-id']


class CrispUserHistoryModel(models.Model):
	name = models.CharField(max_length = 125, blank = True, null = False)
	email = models.CharField(max_length = 125, blank = True, null = False)
	level = models.IntegerField(null = True)
	shift_mon = models.CharField(max_length = 255, null = True, blank = True)
	shift_tue = models.CharField(max_length = 255, null = True, blank = True)
	shift_wed = models.CharField(max_length = 255, null = True, blank = True)
	shift_thu = models.CharField(max_length = 255, null = True, blank = True)
	shift_fri = models.CharField(max_length = 255, null = True, blank = True)
	shift_sat = models.CharField(max_length = 255, null = True, blank = True)
	shift_sun = models.CharField(max_length = 255, null = True, blank = True)
	accounting = models.IntegerField()

	class Meta:
		db_table = "crisp_user_history"
		ordering = ['-accounting', '-level']


class CrispDailyReportModel(models.Model):
	from_nickname = models.CharField(max_length = 125, blank = True, null = False)
	accounting_month = models.IntegerField(null = True)
	accounting_day = models.IntegerField(null = True)
	number_of_chats = models.IntegerField(null = False, default = 0)
	number_of_emails = models.IntegerField(null = False, default = 0)
	number_of_messages = models.IntegerField(null = False, default = 0)
	number_of_sessions = models.IntegerField(null = False, default = 0)
	session_chats = models.TextField(null = True)
	session_emails = models.TextField(null = True)
	session_shift_emails = models.TextField(null = True)
	session_shift_chats = models.TextField(null = True)

	class Meta:
		db_table = "crisp_daily_report"