import urllib.parse
from collections import OrderedDict
from datetime import datetime
from django import template

from libs.utils import to_int, to_str, get_full_absolute_uri

register = template.Library()


@register.simple_tag()
def shift(index):
	return f"{(index - 1) * 4}.00 - {index * 4}.00"


@register.simple_tag()
def convert_time(frt_time):
	if not frt_time:
		return '--'
	response = []

	if frt_time >= 60 * 60:
		h = to_int(frt_time // (60 * 60))
		response.append(f'{h}h')
		frt_time -= h * 60 * 60
	if frt_time >= 60:
		m = to_int(frt_time // 60)
		response.append(f'{m}m')
		frt_time -= m * 60
	if frt_time:
		response.append(f'{to_int(frt_time)}s')

	return ' '.join(response)


@register.simple_tag()
def accounting_to_date(accounting):
	shift_datetime = datetime.strptime(to_str(accounting), "%Y%m%d")
	return shift_datetime.strftime("%d-%m-%Y")

@register.simple_tag()

def to_monthly_details_url(from_nickname, month):
	url = f"{get_full_absolute_uri('admin:crisp-report')}/2"
	params = {
		'from_nickname': from_nickname,
		'monthfilter': month
	}
	return f"{url}?{urllib.parse.urlencode(OrderedDict(**params))}"
