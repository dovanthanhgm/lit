from datetime import datetime

from django import forms
from django.contrib import admin
from django.db.models import Q
from django.utils.html import format_html
from django_yearmonth_widget.widgets import DjangoYearMonthWidget

from core.myadmin.admin import CoreAdmin, InputFilter
from crisp.models import CrispUserModel, CrispMessageFaults, CrispConversationNoReply, CrispConversationModel, CrispUserHistoryModel
from libs.utils import to_int, nl2br, json_decode, json_encode, to_str


class HorizontalCheckboxSelectMultiple(forms.CheckboxSelectMultiple):
	template_name = 'crisp/widgets/checkbox_select.html'


class CrispUserForm(forms.ModelForm):
	shift_mon = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)
	shift_tue = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)
	shift_wed = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)
	shift_thu = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)
	shift_fri = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)
	shift_sat = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)
	shift_sun = forms.MultipleChoiceField(choices = (('0', '0-4h'), ('1', '4-8h'), ('2', '8-12h'), ('3', '12-16h'), ('4', '16-20h'), ('5', '20-24h')), widget = HorizontalCheckboxSelectMultiple, required = False)


	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		fields = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
		if kwargs.get('instance'):
			instance = kwargs['instance']
			for field in fields:
				value = json_decode(getattr(instance, f'shift_{field}'))
				if value:
					self.initial[f'shift_{field}'] = value


	def clean(self):
		super().clean()
		fields = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
		for field in fields:
			self.cleaned_data[f'shift_{field}'] = json_encode(self.cleaned_data[f'shift_{field}'])


	class Meta:
		model = CrispUserModel
		fields = '__all__'


class CrispUserFormHistory(CrispUserForm):
	accounting = forms.DateField(widget = DjangoYearMonthWidget)

	class Meta:
		model = CrispUserHistoryModel
		fields = '__all__'


	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		if kwargs.get('instance'):
			instance = kwargs['instance']
			if instance.accounting:
				self.initial['accounting'] = datetime.strptime(to_str(instance.accounting), '%Y%m')


	def clean(self):
		super().clean()
		self.cleaned_data['accounting'] = self.cleaned_data['accounting'].strftime("%Y%m")


# Register your models here.
class CrispUserAdmin(CoreAdmin):
	form = CrispUserForm
	# search_fields = ['name', 'type', 'identifier', 'url', 'api', 'sync_price', 'sync_price_config', 'sync_qty',
	#                  'sync_qty_config', 'user__email', 'status', 'created_at', 'updated_at', 'deleted_at']
	# list_filter = (NameFilter, TypeFilter, IdentifierFilter, 'default')
	list_display = ['id', 'name', 'email', 'status', 'level']
	list_display_links = ('id', 'name')


class CrispUserHistoryAdmin(CoreAdmin):
	form = CrispUserFormHistory
	# search_fields = ['name', 'type', 'identifier', 'url', 'api', 'sync_price', 'sync_price_config', 'sync_qty',
	#                  'sync_qty_config', 'user__email', 'status', 'created_at', 'updated_at', 'deleted_at']
	# list_filter = (NameFilter, TypeFilter, IdentifierFilter, 'default')
	list_display = ['id', 'name', 'email', 'level', 'month']
	list_display_links = ('id', 'name')


	def month(self, obj):
		accounting = to_str(obj.accounting)
		return f'{accounting[0:4]}-{accounting[4:]}'


class FromStaffFilter(InputFilter):
	parameter_name = 'from_staff'
	title = ('Staff')


	def queryset(self, request, queryset):
		if self.value() is not None:
			name = self.value()
			return queryset.filter(staff_fault__icontains = name)


class CustomerFilter(InputFilter):
	parameter_name = 'customer_name'
	title = ('Customer')


	def queryset(self, request, queryset):
		if self.value() is not None:
			name = self.value()
			session = CrispConversationModel.objects.filter(Q(customer_name__icontains = name) | Q(customer_email__icontains = name)).values('session_id')

			return queryset.filter(session_id__in = session)


class SessionFilter(InputFilter):
	parameter_name = 'session'
	title = ('Session')


	def queryset(self, request, queryset):
		if self.value() is not None:
			return queryset.filter(session_id = self.value())


class CrispConversationFaultAdmin(CoreAdmin):
	# search_fields = ['name', 'type', 'identifier', 'url', 'api', 'sync_price', 'sync_price_config', 'sync_qty',
	#                  'sync_qty_config', 'user__email', 'status', 'created_at', 'updated_at', 'deleted_at']
	list_filter = (FromStaffFilter, CustomerFilter, SessionFilter, 'fault_type', 'timestamp')
	list_display = ['id', 'session', 'customer_name', 'customer_content', 'timestamp_format', 'reply_content', 'reply_time', 'shift', 'fault_type', 'staff_fault_format', 'response_time_convert']


	def session(self, obj):
		return format_html(f"<a href='https://app.crisp.chat/website/16e453e8-f0c6-490d-8be5-ff3c860d94c0/inbox/{obj.session_id}' target='_blank' class='_link''>{obj.session_id}</a>")


	def customer_name(self, obj):
		session = CrispConversationModel.objects.get(session_id = obj.session_id)
		return session.customer_name


	def timestamp_format(self, obj):
		return obj.timestamp


	timestamp_format.short_description = 'Customer Time'


	def response_time_convert(self, obj):
		response = []

		frt_time = obj.response_time
		if frt_time:
			if frt_time >= 60 * 60:
				h = to_int(frt_time // (60 * 60))
				response.append(f'{h}h')
				frt_time -= h * 60 * 60
			if frt_time >= 60:
				m = to_int(frt_time // 60)
				response.append(f'{m}m')
				frt_time -= m * 60
			if frt_time:
				response.append(f'{to_int(frt_time)}s')
		return ' '.join(response)


	response_time_convert.short_description = 'Response Time'


	def staff_fault_format(self, obj):
		return format_html(nl2br(obj.staff_fault))


	staff_fault_format.short_description = 'Staff'


class CrispConversationNoReplyAdmin(CoreAdmin):
	# search_fields = ['name', 'type', 'identifier', 'url', 'api', 'sync_price', 'sync_price_config', 'sync_qty',
	#                  'sync_qty_config', 'user__email', 'status', 'created_at', 'updated_at', 'deleted_at']
	list_display = ['id', 'session', 'customer_content', 'timestamp']


	def session(self, obj):
		return format_html(f"<a href='https://app.crisp.chat/website/16e453e8-f0c6-490d-8be5-ff3c860d94c0/inbox/{obj.session_id}' target='_blank' class='_link''>{obj.session_id}</a>")


admin.site.register(CrispConversationNoReply, CrispConversationNoReplyAdmin)
admin.site.register(CrispUserModel, CrispUserAdmin)
admin.site.register(CrispUserHistoryModel, CrispUserHistoryAdmin)
admin.site.register(CrispMessageFaults, CrispConversationFaultAdmin)
