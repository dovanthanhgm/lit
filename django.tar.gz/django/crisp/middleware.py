import base64
import hashlib
import hmac

import jwt
from django.http import HttpResponseForbidden, HttpResponseNotFound, HttpResponse
from django.shortcuts import get_object_or_404

from channels.models import Channel
from core.middleware import CustomMiddleware
from datasync_django import settings
from libs.utils import json_decode, base64_to_string, get_private_key, to_int, to_str, log
from merchant.shopify.models import ShopifyApp
from merchant.shopify.utils import MerchantShopifyUtils, is_local


class CrispWebHookMiddleware(CustomMiddleware):
	NAME = 'crisp.middleware.CrispWebHookMiddleware'


	def process_middleware(self, request, view_func, view_args, view_kwargs):
		# if is_local():
		# 	return None

		webhook_key = request.GET.get('key')
		if webhook_key and webhook_key == settings.CRISP_WEBHOOK_KEY:
			return None
		return HttpResponse(status = 401)
