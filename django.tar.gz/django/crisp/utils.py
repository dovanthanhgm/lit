from crisp.api import CrispApi
from crisp.models import CrispConversationModel
from libs.utils import convert_format_time


class CrispUtils:
	def get_conversation(self, session_id):
		try:
			conversation = CrispConversationModel.objects.get(session_id = session_id)
		except CrispConversationModel.DoesNotExist:
			conversation = False
		if not conversation:
			api = CrispApi()
			conversation_data = api.get_conversation(session_id)
			conversation = CrispConversationModel.objects.create(session_id = session_id,
			                                                     customer_name = conversation_data['meta']['nickname'],
			                                                     state = conversation_data['state'],
			                                                     have_new_message = True,
			                                                     customer_email = conversation_data['meta']['email'],
			                                                     updated_at = convert_format_time(conversation_data['updated_at']),
			                                                     created_at = convert_format_time(conversation_data['created_at']),
										segments = ','.join(conversation_data['meta'].get('segments') or []),
			)
		return conversation