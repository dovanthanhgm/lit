from django.http import HttpResponse
from django.shortcuts import render
from rest_framework import generics
from rest_framework.permissions import AllowAny

from crisp.api import CrispApi
from crisp.middleware import CrispWebHookMiddleware
from crisp.models import CrispUserModel
from crisp.utils import CrispUtils


# Create your views here.
class CrispWebhook(generics.CreateAPIView):
	permission_classes = [AllowAny]
	MIDDLEWARE_CLASSES = (CrispWebHookMiddleware.NAME,)

	def post(self, request, *args, **kwargs):
		body = request.data
		if body['event'] == 'session:set_state':
			state = body['data']['state']
			session_id = body['data']['session_id']
			conversation = CrispUtils().get_conversation(session_id)
			if conversation:
				conversation.state = state
				if state in ['unresolved', 'pending']:
					conversation.have_new_message = True
					conversation.is_skip = False
				conversation.save()
		if body['event'] == 'session:set_block':
			is_blocked = body['data']['is_blocked']
			session_id = body['data']['session_id']
			conversation = CrispUtils().get_conversation(session_id)
			if conversation:
				conversation.is_blocked = is_blocked
				if is_blocked:
					conversation.have_new_message = False
				else:
					conversation.have_new_message = True

				conversation.save()
		# if body['event'] == 'people:profile:created':
		# 	user_id = body['data']['people_id']
		# 	user = CrispApi().get_user(user_id)
		# 	CrispUserModel.objects.create(people_id = user['people_id'],
		# 	                              name = user['person'].get('nickname'),
		# 	                              email = user.get('email'),
		# 	                              status = user['active']['now'],
		# 	                              )
		return HttpResponse()
