from crisp_api import Crisp

from datasync_django import settings


class CrispApi:
	_model_api: Crisp or None


	def __init__(self):
		self._client_id = settings.CRISP_CLIENT_ID
		self._client_secret = settings.CRISP_CLIENT_SECRET
		self._website_id = settings.CRISP_WEBSITE_ID
		self._model_api = None


	def get_client_id(self):
		return self._client_id


	def get_client_secret(self):
		return self._client_secret


	def get_website_id(self):
		return self._website_id


	def get_model_api(self):
		if self._model_api:
			return self._model_api
		self._model_api = Crisp()
		self._model_api.set_tier("plugin")
		self._model_api.authenticate(self.get_client_id(), self.get_client_secret())
		return self._model_api


	def get_conversation(self, session_id):
		session = self.get_model_api().website.get_conversation(self.get_website_id(), session_id)
		return session

	def get_user(self, user_id):
		return self.get_model_api().website.get_people_profile(self.get_website_id(), user_id)

	def get_conversations(self, page_number):
		return self.get_model_api().website.list_conversations(self.get_website_id(), page_number)


	def get_users(self, page_number):
		return self.get_model_api().website.list_people_profiles(self.get_website_id(), page_number)


	def get_messages_in_conversation(self, session_id, timestamp_before = False):
		query = {}
		if timestamp_before:
			query['timestamp_before'] = timestamp_before
		return self.get_model_api().website.get_messages_in_conversation(self.get_website_id(), session_id, query)
