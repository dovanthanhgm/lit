from django.urls import path, include

from crisp import views

urlpatterns = [
	path('webhook', include([
		path('', views.CrispWebhook.as_view(), name = 'crisp.webhook'),
	])),

]