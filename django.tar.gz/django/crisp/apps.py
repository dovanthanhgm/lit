from django.apps import AppConfig


class CrispConfig(AppConfig):
    name = 'crisp'


    def ready(self):
        import crisp.signals
