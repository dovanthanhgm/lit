from datetime import date

from django.db.models.signals import post_save
from django.dispatch import receiver
from django.forms import model_to_dict

from crisp.models import CrispUserModel, CrispUserHistoryModel
from libs.utils import to_int


@receiver(post_save, sender = CrispUserModel)
def channel_post_save(sender, instance: CrispUserModel, **kwargs):
	data = model_to_dict(instance)
	today = date.today()
	accounting = to_int(today.strftime('%Y%m'))
	try:
		del data['id']
		del data['status']
		data['accounting'] = accounting
		CrispUserHistoryModel.objects.update_or_create( data, email = data['email'], accounting = accounting)
	except Exception:
		pass
