from django.db import models

# Create your models here.
from processes.models import Process
from servers.models import Server


class ProcessManagement(models.Model):
	# process = models.ForeignKey(Process, on_delete = models.CASCADE, null = True)
	server = models.ForeignKey(Server, on_delete = models.CASCADE, null = False)
	action = models.CharField(null = True, max_length = 255)
	data = models.TextField(null = True)
	start_time = models.DateTimeField(null = True, auto_now = False)
	pid = models.IntegerField(null = False)
	process_id = models.IntegerField(null = False)
	cpu_percent = models.IntegerField(null = True)
	memory_info = models.IntegerField(null = True)
	datasync_info = models.TextField(null = True)

	class Meta:
		db_table = 'process_management'
		ordering = ['id']
		app_label = 'servers'
		verbose_name = 'Process Management'