from functools import update_wrapper

from django.contrib import admin
# Register your models here.
from django.shortcuts import redirect
from django.urls import reverse, path
from django.utils.html import format_html

from core.myadmin.admin import CoreAdmin, InputFilter
from datasync.api.sync import SyncApi
from libs.utils import get_full_absolute_uri, to_int
from process_management.models import ProcessManagement
from processes.models import Process
from processes.utils import ProcessUtils


class ProcessFilter(InputFilter):
	parameter_name = 'process_id'
	title = ('process')


	def queryset(self, request, queryset):
		if self.value() is not None:
			return queryset.filter(process_id = self.value())


class ChannelFilter(InputFilter):
	parameter_name = 'channel'
	title = ('channel')


	def queryset(self, request, queryset):
		if self.value() is not None:
			channel_id = to_int(self.value())
			process_queryset = Process.objects.filter(channel_id = channel_id).values('id')
			return queryset.filter(process_id__in = process_queryset)


class UserFilter(InputFilter):
	parameter_name = 'user'
	title = ('User')


	def queryset(self, request, queryset):
		if self.value() is not None:
			user_id = to_int(self.value())
			process_queryset = Process.objects.filter(user_id = user_id).values('id')
			return queryset.filter(process_id__in = process_queryset)


@admin.register(ProcessManagement)
class ProcessManagementAdmin(CoreAdmin):
	show_change_link = True
	list_display = ['id', 'process_link', 'server_link', 'action', 'start_time', 'pid', 'cpu_percent', 'memory_info_m', 'btn_stop']
	list_filter = [ProcessFilter, ChannelFilter, UserFilter]


	def btn_stop(self, obj):
		return format_html(f"<a href='{get_full_absolute_uri('admin:servers_processmanagement_changelist')}/{obj.id}/stop/'  class='_link' style='color:blue;'>Stop</a>")


	def memory_info_m(self, obj):
		return f"{obj.memory_info}M"


	memory_info_m.short_description = "Memory Info (M)"


	def get_urls(self):
		def wrap(view):
			def wrapper(*args, **kwargs):
				return self.admin_site.admin_view(view)(*args, **kwargs)


			wrapper.model_admin = self
			return update_wrapper(wrapper, view)


		urls = super().get_urls()
		custom_url = [
			path('<path:object_id>/stop/', wrap(self.stop_process), name = 'process_management_stop'),

		]
		return custom_url + urls


	def stop_process(self, request, object_id, form_url = '', extra_context = None):
		obj = ProcessManagement.objects.get(pk = int(object_id))
		stop_process = False
		stop = dict()
		if obj.process_id:
			process = ProcessUtils().get(obj.process_id)
			if process and process.pid == obj.pid:
				end_point = f"/process/stop/{obj.process_id}"
				stop = SyncApi(server_id = obj.server_id).post(end_point)
				stop_process = True
				if stop['result'] == 'success':
					# process = obj.process
					process.status = Process.STOPPED
				process.save()
		if not stop_process:
			end_point = f"/process/stop_pid/{obj.pid}"
			stop = SyncApi(server_id = obj.server_id).post(end_point)
		if stop.get('result') == 'success':
			obj.delete()
		return redirect(get_full_absolute_uri('admin:servers_processmanagement_changelist'))


	def has_delete_permission(self, request, obj = None):
		return False


	def server_link(self, obj):
		link = reverse("admin:servers_server_change", args = (obj.server_id,))
		return format_html(f"<a href='{link}' target='_blank' class='_link''>{obj.server.name}</a>")


	def process_link(self, obj):
		link = reverse("admin:channels_process_change", args = (obj.process_id,))

		return format_html(f"<a href='{link}' target='_blank' class='_link''>{obj.process_id}</a>")
