from django.apps import AppConfig


class ProcessManagementConfig(AppConfig):
    name = 'process_management'
