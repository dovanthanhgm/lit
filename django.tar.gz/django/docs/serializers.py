from merchant.amazon.serializers import *
from merchant.etsy.serializers import *
from merchant.facebook.serializers import *


class ResponseShippingEtsySerializer(ShippingEtsySerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


class ResponseCategoryEtsySerializer(CategoryEtsySerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


# class ResponsePriceTemplateSerializer(ChannelPriceTemplateSerializer):
# 	id = serializers.CharField()
# 	_id = serializers.CharField()
#
#
# class ResponseTitleTemplateSerializer(ChannelTitleTemplateSerializer):
# 	id = serializers.CharField()
# 	_id = serializers.CharField()


class ResponseTemplateCombinationEtsySerializer(TemplateCombinationEtsySerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


# class ResponseAmazonOfferTemplateSerializer(AmazonOfferTemplateSerializer):
# 	id = serializers.CharField()
# 	_id = serializers.CharField()
#
#
# class ResponseAmazonPriceTemplateSerializer(AmazonPriceTemplateSerializer):
# 	id = serializers.CharField()
# 	_id = serializers.CharField()


class ResponseFacebookCategorySerializer(FacebookCategorySerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


class ResponseTitleFacebookSerializer(TitleFacebookSerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


class ResponsePriceFacebookSerializer(PriceFacebookSerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


class ResponseFacebookShippingSerializer(FacebookShippingSerializer):
	id = serializers.CharField()
	_id = serializers.CharField()


class ResponseTemplateFacebookSerializer(TemplateFacebookSerializer):
	id = serializers.CharField()
	_id = serializers.CharField()
