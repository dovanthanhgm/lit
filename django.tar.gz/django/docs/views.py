from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema

from rest_framework.views import APIView
from rest_framework import status
from django.utils.decorators import method_decorator

from activities.serializers import ActivitySerializer
from merchant.amazon.serializers import *
from merchant.ebay.serializers import *
from merchant.etsy.serializers import *
from merchant.facebook.serializers import *
from merchant.google.serializers import *
from merchant.wish.serializers import *

from .serializers import *


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: AmazonOfferTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = AmazonOfferTemplateSerializer,
	responses = {status.HTTP_200_OK: AmazonOfferTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class AmazonTemplateOfferAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: AmazonPriceTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = AmazonPriceTemplateSerializer,
	responses = {status.HTTP_200_OK: AmazonPriceTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class AmazonTemplatePriceAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: AmazonOfferTemplateSerializer
	},
	manual_parameters = []
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = AmazonOfferTemplateSerializer,
	responses = {status.HTTP_200_OK: AmazonOfferTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: abc}"}
))
class AmazonTemplateOfferDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
# @method_decorator(name = 'get', decorator = swagger_auto_schema(
# 	responses = {
# 		status.HTTP_200_OK: ResponseAmazonPriceTemplateSerializer
# 	},
# 	manual_parameters = []
# ))
# @method_decorator(name = 'put', decorator = swagger_auto_schema(
# 	request_body = AmazonPriceTemplateSerializer,
# 	responses = {status.HTTP_200_OK: ResponseAmazonPriceTemplateSerializer}
# ))
# @method_decorator(name = 'delete', decorator = swagger_auto_schema(
# 	responses = {status.HTTP_200_OK: "{message: abc}"}
# ))
class AmazonTemplatePriceDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ShippingEtsySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = ShippingEtsySerializer,
	responses = {status.HTTP_200_OK: ResponseShippingEtsySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateShippingAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: CategoryEtsySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = CategoryEtsySerializer,
	responses = {status.HTTP_200_OK: ResponseCategoryEtsySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateCategoryAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ChannelTitleTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
# @method_decorator(name = 'post', decorator = swagger_auto_schema(
# 	request_body = ChannelTitleTemplateSerializer,
# 	responses = {status.HTTP_200_OK: ResponseTitleTemplateSerializer}
# ))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateTitleAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
# @method_decorator(name = 'get', decorator = swagger_auto_schema(
# 	responses = {
# 		status.HTTP_200_OK: ChannelPriceTemplateSerializer
# 	},
# 	manual_parameters = [
# 		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
# 		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
# 	]
# ))
# @method_decorator(name = 'post', decorator = swagger_auto_schema(
# 	request_body = ChannelPriceTemplateSerializer,
# 	responses = {status.HTTP_200_OK: ResponsePriceTemplateSerializer}
# ))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplatePriceAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: TemplateCombinationEtsySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = TemplateCombinationEtsySerializer,
	responses = {status.HTTP_200_OK: ResponseTemplateCombinationEtsySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateRecipesAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ShippingEtsySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = ShippingEtsySerializer,
	responses = {status.HTTP_200_OK: ResponseShippingEtsySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateShippingDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: CategoryEtsySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = CategoryEtsySerializer,
	responses = {status.HTTP_200_OK: ResponseCategoryEtsySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateCategoryDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ChannelTitleTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
# @method_decorator(name = 'put', decorator = swagger_auto_schema(
# 	request_body = ChannelTitleTemplateSerializer,
# 	responses = {status.HTTP_200_OK: ResponseTitleTemplateSerializer}
# ))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateTitleDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ChannelTitleTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
# @method_decorator(name = 'put', decorator = swagger_auto_schema(
# 	request_body = ChannelTitleTemplateSerializer,
# 	responses = {status.HTTP_200_OK: ResponseTitleTemplateSerializer}
# ))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplatePriceDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: TemplateCombinationEtsySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = TemplateCombinationEtsySerializer,
	responses = {status.HTTP_200_OK: ResponseTemplateCombinationEtsySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EtsyTemplateRecipesDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
class WishTemplateShippingAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
class WishTemplateBrandAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++
class WishTemplateTitleAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
class WishTemplatePriceAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: FacebookCategorySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = FacebookCategorySerializer,
	responses = {status.HTTP_200_OK: ResponseFacebookCategorySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateCategoryAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: TitleFacebookSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = TitleFacebookSerializer,
	responses = {status.HTTP_200_OK: ResponseTitleFacebookSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateTitleAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: PriceFacebookSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = PriceFacebookSerializer,
	responses = {status.HTTP_200_OK: ResponsePriceFacebookSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplatePriceAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ActivitySerializer
	},
	manual_parameters = [
		openapi.Parameter('status', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
class ActivityNotification(APIView):
	def get(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: FacebookShippingSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = FacebookShippingSerializer,
	responses = {status.HTTP_200_OK: ResponseFacebookShippingSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateShippingAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: TemplateFacebookSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = TemplateFacebookSerializer,
	responses = {status.HTTP_200_OK: ResponseTemplateFacebookSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateRecipesAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: FacebookShippingSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = FacebookShippingSerializer,
	responses = {status.HTTP_200_OK: ResponseFacebookShippingSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateShippingDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: FacebookCategorySerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = FacebookCategorySerializer,
	responses = {status.HTTP_200_OK: ResponseFacebookCategorySerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateCategoryDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# +++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: TitleFacebookSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = TitleFacebookSerializer,
	responses = {status.HTTP_200_OK: ResponseTitleFacebookSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateTitleDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: PriceFacebookSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = PriceFacebookSerializer,
	responses = {status.HTTP_200_OK: ResponsePriceFacebookSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplatePriceDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ++++++++++++++++++++++++++++++++++++++++++++++
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: TemplateFacebookSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = TemplateFacebookSerializer,
	responses = {status.HTTP_200_OK: ResponseTemplateFacebookSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class FacebookTemplateRecipesDetailView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def put(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


# ----------------------------Ebay--------------------------
@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: EbayShippingTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = EbayShippingTemplateSerializer,
	responses = {status.HTTP_200_OK: EbayShippingTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EbayTemplateShippingAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass

@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: EbayCategoryTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = EbayCategoryTemplateSerializer,
	responses = {status.HTTP_200_OK: EbayCategoryTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EbayTemplateCategoryAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: EbayPaymentTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = EbayPaymentTemplateSerializer,
	responses = {status.HTTP_200_OK: EbayPaymentTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EbayTemplatePaymentAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: EbayPriceTemplateSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = EbayPriceTemplateSerializer,
	responses = {status.HTTP_200_OK: EbayPriceTemplateSerializer}
))
@method_decorator(name = 'delete', decorator = swagger_auto_schema(
	responses = {status.HTTP_200_OK: "{message: delete success}"}
))
class EbayTemplatePriceAPIView(APIView):

	def get(self, request, *args, **kwargs):
		pass


	def post(self, request, *args, **kwargs):
		pass


	def delete(self, request, *args, **kwargs):
		pass