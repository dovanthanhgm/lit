from django.urls import path, include

from . import views


# urlpatterns = [
# 	path('merchant/amazon/<int:channel_id>/templates', include(
# 		path('', views.AmazonTemplateOfferAPIView.as_view())
# 		# path('/<str:template_id>/', views.AmazonTemplateOfferDetailView.as_view()),
# 	))
# ]
from .views import ActivityNotification

urlpatterns = [
	path('merchant/amazon/<int:channel_id>/templates/offer', views.AmazonTemplateOfferAPIView.as_view()),
	# path('merchant/amazon/<int:channel_id>/templates/<str:template_id>/offer', views.AmazonTemplateOfferDetailView.as_view()),
	path('merchant/amazon/<int:channel_id>/templates/price', views.AmazonTemplatePriceAPIView.as_view()),
	# path('merchant/amazon/<int:channel_id>/templates/<str:template_id>/price', views.AmazonTemplatePriceDetailView.as_view()),

	path('merchant/etsy/<int:channel_id>/templates/shipping', views.EtsyTemplateShippingAPIView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/<str:template_id>/shipping', views.EtsyTemplateShippingDetailView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/price', views.EtsyTemplatePriceAPIView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/<str:template_id>/price', views.EtsyTemplatePriceDetailView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/category', views.EtsyTemplateCategoryAPIView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/<str:template_id>/category', views.EtsyTemplateCategoryDetailView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/title', views.EtsyTemplateTitleAPIView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/<str:template_id>/title', views.EtsyTemplateTitleDetailView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/recipes', views.EtsyTemplateRecipesAPIView.as_view()),
	path('merchant/etsy/<int:channel_id>/templates/<str:template_id>/recipes', views.EtsyTemplateRecipesDetailView.as_view()),

	path('merchant/facebook/<int:channel_id>/templates/shipping', views.FacebookTemplateShippingAPIView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/<str:template_id>/shipping', views.FacebookTemplateShippingDetailView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/price', views.FacebookTemplatePriceAPIView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/<str:template_id>/price', views.FacebookTemplatePriceDetailView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/category', views.FacebookTemplateCategoryAPIView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/<str:template_id>/category', views.FacebookTemplateCategoryDetailView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/title', views.FacebookTemplateTitleAPIView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/<str:template_id>/title', views.FacebookTemplateTitleDetailView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/recipes', views.FacebookTemplateRecipesAPIView.as_view()),
	path('merchant/facebook/<int:channel_id>/templates/<str:template_id>/recipes', views.FacebookTemplateRecipesDetailView.as_view()),
	path('api/activities/notification', ActivityNotification.as_view()),
	path('api/activities/recent', ActivityNotification.as_view()),

	path('merchant/ebay/<int:channel_id>/templates/shipping', views.EbayTemplateShippingAPIView.as_view()),
	path('merchant/ebay/<int:channel_id>/templates/category', views.EbayTemplateCategoryAPIView.as_view()),
	path('merchant/ebay/<int:channel_id>/templates/payment', views.EbayTemplatePaymentAPIView.as_view()),
	path('merchant/ebay/<int:channel_id>/templates/price', views.EbayTemplatePriceAPIView.as_view()),

]