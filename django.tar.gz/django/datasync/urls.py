from django.urls import path

from datasync.views import CartView, CartDetailsView, CartConnector
from . import views

urlpatterns = [
	path("carts", CartView.as_view()),
	path("cart/connector", CartConnector().as_view(), name = 'cart.connector'),
	path("carts/<str:cart_type>", CartDetailsView.as_view()),
	path("channel/setup", views.setup_channel, name = 'channel.setup'),
	path('channel/pull/<int:channel_id>', views.pull_from_channel, name = 'channel.pull'),
	path('channel/verify_connection/<int:channel_id>', views.verify_channel_connection, name = 'channel.verify_connection'),
	path('price-entity', views.PriceEntityApiView.as_view(), name = 'price-entity')
]
