from django.apps import AppConfig


class DatasyncConfig(AppConfig):
    name = 'datasync'
