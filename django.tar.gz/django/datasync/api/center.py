from datasync.api.request import RequestApi
from libs.utils import get_config_ini


class CartCenterApi(RequestApi):
	def __init__(self):
		super().__init__()
		self._api_url = get_config_ini('cart', 'center_url')
		self._private_key = get_config_ini('cart', 'center_private_key')

