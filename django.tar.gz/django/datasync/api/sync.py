from django.forms import model_to_dict

from accounts.models import UserAccount
from channels.models import Channel
from datasync.api.request import RequestApi
from libs.authorization import Authorization
from libs.utils import to_int, to_str, to_len, is_local
from processes.models import Process
from servers.models import Server


class SyncApi(RequestApi):
	def __init__(self, **kwargs):
		super().__init__()
		self._extend_data = {}
		process_id = kwargs.get('process_id')
		server_id = kwargs.get('server_id')
		channel_id = kwargs.get('channel_id')
		self._user_id = kwargs.get('user_id')
		self._user = kwargs.get('user')
		server = kwargs.get('server')
		if server_id:
			server = Server.objects.get(pk = server_id)
		pick_process = False
		if not self._user:
			if not self._user_id:
				if process_id:
					pick_process = Process.objects.get(pk = process_id)
					self._user_id = pick_process.user_id
					self._user = pick_process.user
				elif channel_id:
					pick_process = Process.objects.filter(channel_id = channel_id, type = 'product').first()
					self._user_id = pick_process.user_id
					self._user = pick_process.user
		else:
			self._user_id = self._user.id
		pick_channel = False
		if self._user_id:
			if not self._user:
				self._user = self.get_user(self._user_id)
			channels = Channel.objects.filter(user_id =self._user_id, deleted_at__isnull = True)
			processes = Process.objects.filter(user_id = self._user_id)
			all_channels = dict()
			all_process = dict()

			for channel in channels:
				if pick_process and pick_process.channel_id == channel.id:
					pick_channel = channel
				channel_data = model_to_dict(channel, exclude = ['created_at', 'updated_at', 'deleted_at', 'image', 'last_imported'])
				channel_data['user_id'] = self._user_id
				all_channels[to_str(channel.id)] = channel_data
			for process in processes:
				process_data = model_to_dict(process, exclude = ['created_at', 'updated_at'])
				process_data['user_id'] = self._user_id
				process_data['channel_id'] = process.channel_id
				all_process[to_str(process.id)] = process_data
			self._extend_data['channels'] = all_channels
			self._extend_data['processes'] = all_process
			if self._user:
				user_data = model_to_dict(self._user, exclude = ['created_at', 'updated_at', 'last_access', 'announcements_latest_read_at', 'last_login', 'password','is_superuser','balance','groups','user_permissions'])
				fields = [
					'id', 'email', 'contact_email', 'name', 'is_staff', 'is_expired',
					'phone',
					'address',
					'country',
					
				]
				extend_user_data = {}
				for field in fields:
					extend_user_data[field] = user_data.get(field)
				self._extend_data['user_data'] = extend_user_data

			if self._user.server:
				server = self._user.server
		if not is_local() and pick_channel and pick_channel.type in ['Walmart', 'WalmartCa', 'Reverb', 'OnBuy', 'Bonanza', 'Tiktok']:
			server = Server.objects.get(4)
		if not server:
			server = self.load_balancing_server()
		server.active_tasks = to_int(server.active_tasks) + 1
		server.save()
		self._server_id = server.id
		self._api_url = server.server_url
		self._private_key = server.private_key


	def get_server_id(self):
		return self._server_id


	def get_user(self, user_id):
		try:
			user = UserAccount.objects.get(pk = user_id)
		except UserAccount.DoesNotExist as e:
			return False
		return user


	@staticmethod
	def load_balancing_server():
		servers = Server.objects.filter(status = Server.CONNECTED).order_by('priority')
		min_active_tasks = 0
		min_server = []
		for server in servers:
			active_tasks = to_int(server.active_tasks)
			if not min_active_tasks:
				min_active_tasks = active_tasks
				min_server.append(server)
				continue
			if active_tasks > min_active_tasks:
				continue
			if active_tasks < min_active_tasks:
				min_active_tasks = active_tasks
				min_server = [server]
			else:
				min_server.append(server)
		if to_len(min_server) == 1:
			return min_server[0]
		min_cpu = 0
		choose_server = None
		for server in min_server:
			if not min_cpu or to_int(server.cpu_percent) < min_cpu:
				choose_server = server
				min_cpu = to_int(server.cpu_percent)
		return choose_server


	def get_api_url(self):

		return "{}/{}".format(self._api_url, 'api/v1')


	def get_custom_headers(self):
		custom_headers = dict()
		custom_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64;en; rv:5.0) Gecko/20110619 Firefox/5.0'
		custom_headers['Authorization'] = Authorization(private_key = self.get_private_key(), user_id = self._user_id).encode()

		custom_headers['Content-Type'] = 'application/json'
		return custom_headers


	def get_extend_data(self):
		return self._extend_data