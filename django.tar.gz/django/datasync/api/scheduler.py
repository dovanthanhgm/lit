from datasync.api.sync import SyncApi
from libs.utils import to_int
from servers.models import Server


class SchedulerApi(SyncApi):
	def __init__(self, **kwargs):
		server = kwargs['server']
		del kwargs['server']
		self._api_url = None
		self._private_key = None
		self._extend_data = kwargs
		self._user_id = None
		server.active_tasks = to_int(server.active_tasks) + len(kwargs['processes'])
		server.save()
		self._server_id = server.id
		self._api_url = server.server_url
		self._private_key = server.private_key