from datasync.api.request import RequestApi
from libs.utils import get_config_ini


class CartMigrationApi(RequestApi):
	def __init__(self):
		super().__init__()
		self._api_url = get_config_ini('cart', 'migration_url')
		self._private_key = get_config_ini('cart', 'migration_private_key')

	def get_api_url(self):
		return "{}/{}".format(self._api_url, 'api/v1')