from datasync.api.request import RequestApi
from libs.authorization import Authorization
from libs.utils import get_config_ini


class CallbackApi(RequestApi):
	PREFIX = 'lit'

	def __init__(self, **kwargs):
		super().__init__()
		self._api_url = get_config_ini('callback', 'url')
		self._private_key = get_config_ini('callback', 'private_key')
		self._user_id = kwargs.get('user_id')

	def get_api_url(self):
		return "{}/{}".format(self._api_url, 'api/v1')


	def get_custom_headers(self):
		custom_headers = dict()
		custom_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64;en; rv:5.0) Gecko/20110619 Firefox/5.0'
		custom_headers['Authorization'] = Authorization(private_key = self.get_private_key(), user_id = self._user_id).encode()

		custom_headers['Content-Type'] = 'application/json'
		return custom_headers
