import logging
import time

import requests

from libs.utils import to_str, hash_hmac, to_int, json_decode, log_traceback, log


class RequestApi:
	def __init__(self):
		self._api_url = None
		self._private_key = None


	def post(self, path, data = None, file = None):
		return self.api(path, data, method = 'post', file = file)


	def put(self, path, data = None, file = None):
		return self.api(path, data, method = 'put', file = file)


	def get(self, path, data = None, file = None):
		return self.api(path, data, method = 'get', file = file)


	def delete(self, path):
		return self.api(path, method = 'delete')


	def api(self, path, data = None, method = 'post', time_out = 180, file = None):
		api_url = self.get_api_url()
		url = to_str(api_url).strip('/') + '/' + to_str(path).strip('/')
		custom_header = self.get_custom_headers()
		res = self.request_by_method(method, url, data, custom_header, time_out = time_out, file = file)
		res_data = json_decode(res)
		if res_data is False:
			return {'result': 'error', 'msg': "Can't connect to server"}
		return res_data


	def get_api_url(self):
		return self._api_url


	def get_private_key(self):
		return self._private_key


	def get_custom_headers(self):
		time_request = to_str(to_int(time.time()))
		private_key = self.get_private_key()
		hmac = hash_hmac('sha256', time_request, private_key)
		custom_headers = dict()
		custom_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64;en; rv:5.0) Gecko/20110619 Firefox/5.0'
		custom_headers['Authorization'] = to_str(time_request) + ":" + hmac
		custom_headers['Content-Type'] = 'application/json'
		return custom_headers


	def get_extend_data(self):
		return {}


	def request_by_method(self, method, url, data, custom_headers = None, auth = None, time_out = 180, file = None):
		response_data = False
		response = None
		try:
			request_option = {
				'headers': custom_headers,
				'timeout': time_out,
				'verify':False
			}
			if file:
				if request_option['headers'] and request_option['headers'].get('Content-Type'):
					del request_option['headers']['Content-Type']
				request_option['files'] = file
			if method in ['put', 'post']:
				extend_data = self.get_extend_data()
				if not data:
					data = {}
				if extend_data:
					data.update(extend_data)
				if data:
					request_option['json'] = data
			if method == 'get' and data:
				request_option['params'] = data
			response = requests.request(method = method, url = url, **request_option)
			response_data = response.text
			response.raise_for_status()
		except Exception as errh:
			msg = 'Url ' + url
			# msg += '\n Retry 5 times'
			msg += '\n Method: ' + method
			msg += '\n Status: ' + to_str(response.status_code) if response else ''
			msg += '\n Data: ' + to_str(data)
			msg += '\n Header: ' + to_str(response.headers)
			msg += '\n Response: ' + to_str(response_data)
			msg += '\n Error: ' + to_str(errh)
			log(msg)

		return response_data
