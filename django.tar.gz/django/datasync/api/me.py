import time

import jwt

from datasync.api.request import RequestApi
from libs.utils import get_main_url, get_config_ini, to_str, to_int, get_private_key


class MeApi(RequestApi):
	def __init__(self, **kwargs):
		super().__init__()
		self._api_url = get_main_url()
		self._private_key = get_private_key()
		self._user_id = kwargs.get('user_id')


	def get_api_url(self):
		return "{}/{}".format(self._api_url, 'api')


	def get_custom_headers(self):
		time_request = to_str(to_int(time.time()))
		user_id = to_str(self._user_id)
		data = {
			'time': time_request,
			'user_id': user_id
		}
		private_key = get_private_key()
		jwt_token = jwt.encode(data, private_key, algorithm = 'HS256')
		if isinstance(jwt_token, bytes):
			jwt_token = jwt_token.decode()
		custom_headers = dict()
		custom_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64;en; rv:5.0) Gecko/20110619 Firefox/5.0'
		custom_headers['Authorization'] = "private {}".format(jwt_token)
		custom_headers['Content-Type'] = 'application/json'
		return custom_headers
