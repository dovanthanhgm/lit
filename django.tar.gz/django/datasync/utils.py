from datetime import datetime

from django.shortcuts import get_object_or_404

from accounts.models import UserAccount
from channels.models import Channel
from core.utils import CoreUtils
from libs.models.collections.state import State
from libs.models.construct.state import CONSTRUCT_STATE
from libs.utils import response_success, response_error, json_decode, get_config_ini
from processes.models import Process
from subscription.models import UserSubscription
import dateutil.relativedelta

class DatasyncUtils:
	def before_pull_product(self, channel_id):
		channel = get_object_or_404(Channel, pk = channel_id)
		if channel.status == Channel.STATUS_DISCONNECTED:
			return response_error("The channel is currently disconnected. Please reconnect and try again")
		channel_class = CoreUtils().get_channel_model_utils(channel.type)
		if channel_class and hasattr(channel_class, 'before_pull_product'):
			return getattr(channel_class, 'before_pull_product')(channel)
		return response_success()


	def create_process(self, user_id, channel_id):
		model_state = State()
		model_state.set_user_id(user_id)
		channel = get_object_or_404(Channel, pk = channel_id)
		construct_state = CONSTRUCT_STATE
		construct_state['user_id'] = user_id
		construct_state['channel']['id'] = channel.id
		construct_state['channel']['channel_type'] = channel.type
		construct_state['channel']['name'] = channel.name
		construct_state['channel']['url'] = channel.url
		construct_state['channel']['default'] = channel.default
		construct_state['channel']['identifier'] = channel.identifier
		construct_state['channel']['config']['api'] = json_decode(channel.api) or {}
		state_id = model_state.create(construct_state)
		if state_id:
			state = construct_state
			process = Process.objects.create(user_id = user_id, state_id = state_id, type = 'product', channel_id = channel_id)
			if process:
				state['sync_id'] = process.id
				model_state.update_field(state_id, 'sync_id', process.id)
				return process
		return False


	def add_subscription_trial(self, user_id):
		user = UserAccount.objects.get(pk = user_id)
		if user.tried_it:
			return
		subscription = UserSubscription.objects.filter(user_id = user.id).first()
		if subscription and subscription.plan_id != 1:
			return
		payment_method = 'paypal'
		if user.market_app in ['shopify', 'wix']:
			payment_method = user.market_app
		if subscription:
			UserSubscription.objects.filter(user_id = user.id).delete()
		UserSubscription.objects.create(
			user_id = user.id,
			plan_id = get_config_ini('server', 'default_plan_id'),
			started_at = datetime.now(),
			expired_at = datetime.now() + dateutil.relativedelta.relativedelta(days = 14),
			yearly_paid = False,
			auto_renew = False,
			products_limit = 1000,
			channels_limit = 3,
			payment_method = payment_method,
			subscription_fee = 29
		)
		user.is_trial = True
		user.tried_it = True
		user.save()