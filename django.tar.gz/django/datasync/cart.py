from accounts.utils import AccountUtils
from channels.utils import ChannelUtils
from datasync.api.migration import CartMigrationApi
from datasync.api.sync import SyncApi
from datasync.utils import DatasyncUtils
from libs.utils import to_str, random_token, json_encode, response_error, to_int, to_len
from processes.utils import ProcessUtils
from scheduler.models import Scheduler
from channels.models import Channel
from setup_error_log.models import ErrorLog
from subscription.utils import SubscriptionUtils


class Cart:
	TYPE_CONNECTOR = 'connector'
	TYPE_API = 'api'


	def __int__(self, user = None):
		self._user = user


	def construct_cart_info(self, **kwargs):
		return {
			'type': kwargs.get('type'),
			'description': kwargs.get('description'),
			'label': to_str(kwargs.get('label')).capitalize(),
			'featured': kwargs.get('featured', False),
			'logo': kwargs.get('logo'),
		}


	def connector_cart(self, label, description):
		return self.construct_cart_info(type = self.TYPE_CONNECTOR, label = label, description = description)


	def api_cart(self, label, description):
		return self.construct_cart_info(type = self.TYPE_API, label = label, description = description)


	def list(self):
		return {
			'magento': self.connector_cart('Magento', 'See how our next-generation technology, global partner ecosystem, and extensions marketplace can breathe life into your business.'),
			'woocommerce': self.connector_cart('WooCommerce', 'A completely customizable eCommerce platform built on WordPress.'),
			# 'bigcommerce': self.api_cart('bigcommerce', 'The most feature-rich, scalable ecommerce solution for sellers of all sizes.'),
			# 'shopify': self.api_cart('shopify', 'A complete commerce platform that lets you start, grow, and manage a business.'),
			'3dcart': self.api_cart('3dcart', 'Build Your Own Online Store, Rank Higher & Sell More.'),
			'wix': self.api_cart('wix', 'Sell products and manage fulfillment from one eCommerce platform.'),
		}


	def setup(self, cart_type):
		all_cart = self.list()
		if cart_type not in all_cart:
			return self.TYPE_CONNECTOR
		return all_cart[cart_type]['type']


	def get_api_info(self, cart_type):
		if cart_type == 'shopify':
			return {
				'password': 'Password'
			}
		if cart_type == '3dcart':
			return {}
		data = {'cart_type': cart_type}
		api_info = CartMigrationApi().api('action/get-api-info', data, method = 'post')
		return api_info


	def setup_channel(self, **kwargs):
		data_setup = {
			'channel_type': kwargs.get('channel_type'),
			'channel_name': kwargs.get('channel_name'),
			'channel_url': kwargs.get('channel_url'),
			'user_id': kwargs.get('user_id'),
			'api': kwargs.get('api'),
			'token': kwargs.get('channel_token'),
			'sync_id': kwargs.get('sync_id')
		}
		channels = Channel.objects.filter(user_id = kwargs.get('user_id'))
		if not channels and kwargs.get('channel_type') not in ['woocommerce', 'magento', 'shopify', 'bigcommerce', 'wix', 'squarespace', 'file', 'csv']:
			return response_error(f"You can only choose one of the following Shopping Carts as MainStore: Shopify, WooCommerce, BigCommerce, Wix, SquareSpace.")

		channel_number = Channel.objects.filter(user_id = kwargs.get('user_id'), deleted_at__isnull = True, default = False).count()
		plan = SubscriptionUtils().get_plan_by_user(AccountUtils().get_user(kwargs['user_id']))
		channels_limit = 1
		if to_int(plan['id']) != 1 and not plan.get('expired'):
			channels_limit = to_int(plan['channels_limit'])
		if channel_number > channels_limit:
			return response_error(f"Your current account can only connect up to {channels_limit} channels. Please upgrade to a higher plan to increase the number of channels that can be connected.")
		if not channels:
			data_setup['channel_name'] = "Main Store"
		sync_api = SyncApi(process_id = kwargs.get('sync_id'), user_id = kwargs.get('user_id'))
		setup = sync_api.api('channel/setup', data_setup, method = 'post')
		if not setup:
			return {
				'result': 'error'
			}
		if not setup or setup['result'] != 'success':
			if isinstance(data_setup['api'], dict):
				data_setup['api'] = json_encode(data_setup['api'])
			data_setup['msg_error'] = setup['msg'] if isinstance(setup['msg'], str) and setup.get('msg') else json_encode(setup['msg'])
			allow_fields = ['channel_type', 'channel_name', 'channel_url', 'api', 'token', 'sync_id', 'msg_error', 'user_id']
			error_log = dict()
			for field in allow_fields:
				if data_setup.get(field):
					error_log[field] = data_setup.get(field)
			server_id = sync_api.get_server_id()
			error_log['server_id'] = server_id
			ErrorLog.objects.create(**error_log)
			return setup
		channel_default_id = None
		number_channel = to_len(channels)
		if channels:
			csv_channel = False
			for channel in channels:
				if channel.default:
					channel_default_id = channel.id
				if channel.type == 'file':
					csv_channel = channel
					break
			if csv_channel:
				process = ProcessUtils().get_process_by_type(csv_channel.id)
				if process.status == 'completed':
					pull = Cart().pull_from_channel(process_id = setup['data']['process_id'], data = {'import_all': True})
		# channel_id = setup['data']['channel_id']
		# channel = ChannelUtils().get(channel_id)

		if channel_default_id and number_channel == 1:
			DatasyncUtils().add_subscription_trial(kwargs.get('user_id'))
			process = ProcessUtils().get_process_by_type(channel_default_id)
			if not process:
				process = DatasyncUtils().create_process(kwargs.get('user_id'), channel_default_id)
			if process:
				pull = Cart().pull_from_channel(process_id = process.id, data = {'auto_build': True, 'import_all': True, 'first_pull': True})
		# create_order_process = sync_api.api(f"order/process/{setup['data']['channel_id']}", method = 'post')
		# if create_order_process and create_order_process['data']:
		# 	scheduler_id = random_token(8)
		# 	while True:
		# 		try:
		# 			Scheduler.objects.get(scheduler_id = scheduler_id)
		# 			scheduler_id = random_token(8)
		# 		except Scheduler.DoesNotExist:
		# 			break
		# 	scheduler = Scheduler.objects.create(scheduler_id = scheduler_id, process_id = create_order_process['data'], user_id = kwargs.get('user_id'), status = 'running')
		# 	scheduler_data = {
		# 		"user_id": kwargs['user_id'],
		# 		'process_id': create_order_process['data'],
		# 		"interval": {
		# 			"seconds": 15
		# 		}
		# 	}
		# 	sync_api.post(f"scheduler/{scheduler_id}", scheduler_data)
		return setup


	def pull_from_channel(self, process_id, data = None):
		start = SyncApi(process_id = process_id).api('channel/pull/{}'.format(process_id), method = 'post', data = data)
		return start
