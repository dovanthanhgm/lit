from rest_framework import serializers



class PriceEntitySerializer(serializers.Serializer):
	number_products = serializers.IntegerField(required = True)
	source = serializers.CharField(required = True)
	target = serializers.CharField(required = True)

