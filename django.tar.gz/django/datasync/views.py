import io
import re
import time
import zipfile

import requests
from django.http import JsonResponse, HttpResponseNotFound, HttpResponseForbidden, HttpResponse
from django.shortcuts import get_object_or_404
# Create your views here.
from django.utils.decorators import method_decorator
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, status
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny

from accounts.models import UserToken, UserAccount
from accounts.utils import AccountUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from core.authentication import IsGetOrIsAuthenticated
from core.responses import ResponseObject, PaginationResponse, ErrorResponse
from core.utils import CoreUtils
from datasync.api.sync import SyncApi
from datasync.cart import Cart
from datasync.serializers import PriceEntitySerializer
from datasync.utils import DatasyncUtils
from libs.models.collections.state import State
from libs.models.construct.state import CONSTRUCT_STATE
from libs.utils import json_decode, to_int, random_token, get_full_absolute_uri, base64_to_string, get_config_ini, log_traceback, html_unquote, json_encode, to_str
from merchant.etsy.serializers import GetCategorySerializer
from processes.models import Process
from processes.utils import ProcessUtils
from products.utils import ProductUtils
from user_action_logs.utils import UserActionLogUtils
from user_logs.utils import UserLogsUtils


class CartView(generics.ListAPIView):
	def get(self, request, *args, **kwarg):
		return JsonResponse(Cart().list(), safe = False)


class CartDetailsView(generics.ListAPIView):
	def get(self, request, *args, **kwarg):
		cart_type = kwarg['cart_type']
		carts = Cart()
		if cart_type not in carts.list():
			return HttpResponseNotFound()
		cart_info = carts.list()[cart_type]
		if cart_info['type'] == carts.TYPE_API:
			api_info = carts.get_api_info(cart_type)
			cart_info['api_info'] = api_info
		return JsonResponse(cart_info, safe = False)


class CartConnector(generics.ListAPIView):
	permission_classes = [IsGetOrIsAuthenticated]


	def post(self, request, *args, **kwarg):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		token = random_token()
		UserToken.objects.create(token = token, expires_in = to_int(time.time()) + 60, user_id = user_id)
		return HttpResponse(get_full_absolute_uri('cart.connector') + '?token=' + token)


	def get(self, request, *args, **kwarg):

		token = request.GET.get('token')
		if not token:
			return HttpResponseForbidden()
		try:
			auth_token = UserToken.objects.get(token = token)
		except:
			return HttpResponseNotFound()
		if auth_token.expires_in < to_int(time.time()):
			return HttpResponseForbidden(content = 'Token not found or expired')
		user_id = auth_token.user_id
		auth_token.delete()
		user = UserAccount.objects.get(pk = user_id)
		connector_token = user.token
		if not connector_token:
			connector_token = random_token(32).lower()
			user.token = connector_token
			user.save()
		connector_request = requests.get(get_config_ini('cart', 'migration_ui_url') + "/api/get-connector")
		if connector_request.status_code != 200 or not json_decode(connector_request.text):
			return HttpResponse(status = 400, content = 'Cannot connect connector server')
		connector_data = json_decode(connector_request.text)
		buffer = io.BytesIO()
		zip_file = zipfile.ZipFile(buffer, 'w')
		zip_file.writestr('le_connector/connector.php', base64_to_string(connector_data['data']).replace('__SAMPLE__LECM__TOKEN__', connector_token))
		zip_file.writestr('le_connector/readme.html', base64_to_string(connector_data['readme']))
		zip_file.writestr('le_connector/.htaccess', base64_to_string(connector_data['htaccess']))
		zip_file.close()
		response = HttpResponse(buffer.getvalue())
		response['Content-Type'] = 'application/x-zip-compressed'
		response['Content-Disposition'] = 'attachment; filename=le_connector.zip'

		return response


@api_view(['GET', 'POST'])
def setup_channel(request):
	user_id = AccountUtils().get_user_id(request)
	request_data = json_decode(request.body.decode())
	if not request_data:
		return JsonResponse(ResponseObject(code = 400, message = 'Data invalid').to_dict(), status = 400)
	data = {
		'channel_type': request_data.get('channel_type'),
		'channel_name': request_data.get('channel_name'),
		'channel_url': request_data.get('channel_url'),
		'user_id': user_id,
		'api': request_data.get('api', dict())
	}
	user = AccountUtils().get_user_by_request(request)
	if request_data.get('channel_type') == "reverb":
		data['api']['shop'] = request_data.get('channel_name')
	user = AccountUtils().get_user(user_id)
	token = user.token
	if not token:
		token = random_token(32)
		user.token = token
		user.save()
	data['channel_token'] = token
	if request_data.get('merchant_id'):
		channel_type = request_data.get('channel_type')
		model_class = CoreUtils().get_channel_model_utils(channel_type)

		try:
			channel_data = model_class.get_api_info(request_data.get('merchant_id'))
		except:
			log_traceback()
			return JsonResponse(ResponseObject(code = 400, message = 'Data invalid1').to_dict())
		if channel_data is False:
			return JsonResponse(ResponseObject(code = 400, message = 'Data invalid2').to_dict())
		if channel_data.get('url') and not data['channel_url']:
			data['channel_url'] = channel_data['url']
			del channel_data['url']
		if isinstance(data['api'], dict):
			data['api'].update(channel_data)
		else:
			data['api'] = channel_data
	setup = Cart().setup_channel(**data)
	if not setup or setup['result'] != 'success':
		msg = setup['msg'] if setup else 'Something error'
		return JsonResponse(ResponseObject(code = 400, message = msg).to_dict(), status = 400)

	# if data['channel_type'] == 'file':
	# 	pull = Cart().pull_from_channel(process_id = setup['data']['process_id'], data = {'auto_build': True, 'import_all': True})

	return JsonResponse(ResponseObject(data = setup['data']).to_dict())


@api_view(['GET', 'POST'])
def pull_from_channel(request, channel_id):
	user_id = AccountUtils().get_user_id(request)
	UserLogsUtils().create_log(AccountUtils().get_user_id(request), 'pull')
	UserActionLogUtils().create_log(AccountUtils().get_user_id(request), channel_id, 'pull', request.data, request = request)

	before_pull = DatasyncUtils().before_pull_product(channel_id)
	if before_pull['result'] != 'success':
		return JsonResponse(ResponseObject(code = 400, message = before_pull['msg']).to_dict(), status = 400)
	model_state = State()
	model_state.set_user_id(user_id)
	request_data = request.data
	process = ProcessUtils().get_process_by_type(channel_id)
	state = False
	if not process:
		process = DatasyncUtils().create_process(user_id, channel_id)
		if not process:
			return HttpResponseNotFound()
	# count = ProductUtils().count_total_product_in_channel(channel_id, user_id = process.user_id)
	# if not count:
	# 	request_data['first_pull'] = True
	if not state:
		state = model_state.get(process.state_id)
	if not state.get('pulling'):
		live_process_id = CoreUtils().init_process(user_id = process.user_id, channel_id = channel_id, process_type = 'pull_product')
		request_data['live_process_id'] = live_process_id
		pull = Cart().pull_from_channel(process_id = process.id, data = request_data)
		if not pull or pull['result'] != 'success':
			msg = pull['msg'] if pull else 'Something error'
			CoreUtils().delete_process(process.user_id, live_process_id)
			return JsonResponse(ResponseObject(code = 400, message = msg).to_dict(), status = 400)
		model_state.update_field(process.state_id, 'pulling', True)
	user = process.user
	user.save()
	return JsonResponse(ResponseObject(message = "We'll import your listings as quickly as possible, but it may take some time. You can navigate away from this page - importing won't be affected. We'll notify you when it's done.").to_dict())


@api_view(['GET', 'POST'])
def verify_channel_connection(request, channel_id):
	channel = ChannelUtils().get(channel_id)
	if not channel:
		return HttpResponseNotFound()
	user_id = AccountUtils().get_user_id(request)
	if channel.user.id != user_id:
		return HttpResponseForbidden()
	process = ProcessUtils().get_process_by_type(channel_id)
	data = {
		'channel_type': channel.type,
		'channel_name': channel.name,
		'channel_url': channel.url,
		'user_id': user_id,
		'token': channel.user.token,
	}
	if channel.api:
		data['api'] = json_decode(channel.api)
	verify_connection = SyncApi(channel_id = channel.id).api(f'channel/verify_connection/{process.id}', data = data, method = 'post')
	new_channel = ChannelUtils().get(channel_id)
	if not verify_connection or verify_connection.get('result') != 'success':
		new_channel.status = new_channel.STATUS_DISCONNECTED
		if not AccountUtils().is_paid_user(AccountUtils().get_user_by_request(request)):
			# ChannelUtils().disable_all_scheduler(channel_id)
			new_settings = {
				'price': {'status': 'disable'},
				'qty': {'status': 'disable'},
				'order': {'status': 'disable'},
			}
			pre_settings = new_channel.settings
			ChannelUtils().setting_for_channel(new_channel, new_settings)
			new_channel.settings = json_encode(new_settings)
			new_channel.previous_settings = pre_settings
		new_channel.save()

		return JsonResponse(verify_connection, status = 400)
	else:
		new_channel.status = channel.STATUS_CONNECTED
		if new_channel.previous_settings:
			ChannelUtils().setting_for_channel(new_channel, json_decode(new_channel.previous_settings))
			new_channel.settings = new_channel.previous_settings
			new_channel.previous_settings = None
		# channel.api = verify_connection.get('data')
		verify_connection['data'] = None
		new_channel.save()
		if new_channel.default and AccountUtils().is_paid_user(AccountUtils().get_user_by_request(request)):
			ChannelUtils().enable_refresh_sync(new_channel.id)
		return JsonResponse(verify_connection, status = 200)


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: GetCategorySerializer
	},
	manual_parameters = [
		openapi.Parameter('name', openapi.IN_QUERY, type = openapi.TYPE_STRING),
		openapi.Parameter('parent_id', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),

	]
))
class SearchCategoryView(generics.ListAPIView):
	model_object = None
	CATEGORY_ID_FIELD = 'category_id'
	PATH_FIELD = 'path'
	NAME_FIELD = 'name'
	LIMIT_CATEGORY = 20


	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._categories_ids = list()
		self._channel_id = list()
		self._channel = False
		self._request = False
		self._page = None


	def extra_filter(self):
		return {}


	def exclude_filter(self):
		return {}


	def filter(self, query_filter):
		qs = self.model_object.objects.filter(**query_filter)
		exclude_filter = self.exclude_filter()
		if exclude_filter:
			qs = qs.exclude(**exclude_filter)
		if self._page:
			offset = self.LIMIT_CATEGORY * to_int(self._page) + 1
			limit = offset + self.LIMIT_CATEGORY
			qs = qs[offset:limit]
		response = list()
		if qs and list(qs):
			for row in list(qs):
				if row.id not in self._categories_ids:
					self._categories_ids.append(row.id)
					response.append(row)
		return response


	def get(self, request, *args, **kwargs):
		self._channel_id = kwargs.get('channel_id')
		if self._channel_id:
			self._channel = get_object_or_404(Channel, pk = self._channel_id)
		self._request = request
		name = request.GET.get('name')
		parent_id = request.GET.get('parent_id')
		category_id = request.GET.get('category_id')
		if not to_int(category_id):
			category_id = False
		if not name and isinstance(category_id, str):
			name = category_id
		page = request.GET.get('page')
		self._page = page
		default_filters = {}
		default_filters.update(self.extra_filter())
		if parent_id:
			default_filters['parent_id'] = parent_id
		if category_id:
			default_filters[self.CATEGORY_ID_FIELD] = category_id
		filter_id = False
		response = []
		if name:
			name = html_unquote(name)
			if name.isnumeric():
				default_filters[self.CATEGORY_ID_FIELD] = name
				response = self.filter(default_filters)
				if not response:
					del default_filters[self.CATEGORY_ID_FIELD]
					default_filters[f'{self.CATEGORY_ID_FIELD}__icontains'] = name
					response = self.filter(default_filters)

				filter_id = True

			else:
				default_filters[self.NAME_FIELD] = name
		if not filter_id:
			response = self.filter(default_filters)

			if name:
				if len(response) < self.LIMIT_CATEGORY:
					del default_filters[self.NAME_FIELD]
					default_filters[f'{self.NAME_FIELD}__icontains'] = name
					response += self.filter(default_filters)
				if self.PATH_FIELD:
					if len(response) < self.LIMIT_CATEGORY:
						del default_filters[f'{self.NAME_FIELD}__icontains']
						default_filters[f'{self.PATH_FIELD}__icontains'] = name
						response += self.filter(default_filters)

					if len(response) > self.LIMIT_CATEGORY:
						response = response[0:self.LIMIT_CATEGORY]
		if not response and name:
			default_filters = {}
			default_filters.update(self.extra_filter())
			words = re.findall(r"[\w']+", name)
			default_filters.update({f'{self.PATH_FIELD}__icontains': words[0]})
			qs = self.model_object.objects.filter(**default_filters)
			exclude_filter = self.exclude_filter()
			if exclude_filter:
				qs = qs.exclude(**exclude_filter)
			for index, word in enumerate(words):
				if not index:
					continue
				qs_filter = {f'{self.PATH_FIELD}__icontains': word}
				qs = qs.filter(**qs_filter)
			response = qs[0:20]
		if not response and name:
			response = []
			words = re.findall(r"[\w']+", name)

			default_filters = {
				f'{self.PATH_FIELD}__iregex': '|'.join(words)
			}
			default_filters.update(self.extra_filter())
			qs = self.model_object.objects.filter(**default_filters)
			exclude_filter = self.exclude_filter()
			if exclude_filter:
				qs = qs.exclude(**exclude_filter)
			response_with_char = {}
			for row in qs:
				char_match = 0
				for word in words:
					if getattr(row, self.PATH_FIELD).find(word) != -1:
						char_match += 1
				if not response_with_char.get(char_match):
					response_with_char[char_match] = []
				response_with_char[char_match].append(row)
			char_keys = list(response_with_char.keys())
			char_keys.sort(reverse = True)
			for number_match in char_keys:
				response.extend(response_with_char[number_match])
				response = response[0:20]
				if len(response) >= 20:
					break
		data = {
			"count": len(response),
			"data": [self.category_to_response_data(row) for row in response]
		}
		return JsonResponse(PaginationResponse(**data).to_dict(), safe = False)


	def category_to_response_data(self, row):
		path = getattr(row, self.PATH_FIELD) if self.PATH_FIELD else ''
		path = ' > '.join(list(map(lambda x: to_str(x).strip(), to_str(path).split('>'))))
		response = {
			'category_id': getattr(row, self.CATEGORY_ID_FIELD),
			'path': path,
			'name': getattr(row, self.NAME_FIELD),
		}
		extra = self.extra_response_data(row)
		if extra:
			response.update(extra)
		return response


	def extra_response_data(self, row):
		return {}


class PriceEntityApiView(generics.ListAPIView):
	permission_classes = [AllowAny]
	ALL_CART = ['amazon', 'ebay', 'etsy', 'facebook', 'google', 'bigcommerce', 'magento', 'shopify', 'wix', 'woocommerce', 'squarespace', 'file']


	def get(self, request, *args, **kwargs):
		data = dict(request.GET)
		if data:
			for row, value in data.items():
				if isinstance(value, list):
					data[row] = value[0]
		serializer_data = PriceEntitySerializer(data = data)
		if not serializer_data.is_valid():
			return JsonResponse(ErrorResponse(errors = "Data Invalid").to_dict(), status = 400)
		number_products = to_int(serializer_data.data['number_products'])
		source = serializer_data.data['source'].split(',')
		target = serializer_data.data['target'].split(',')
		return JsonResponse(CoreUtils().get_entity_price(number_products, source, target))
