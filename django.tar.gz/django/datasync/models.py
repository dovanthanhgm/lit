from django.db import models


class TotalUserReport(models.Model):
	report_type = models.CharField(null = True, max_length = 15, choices = (('day', 'Day'), ('week', 'Week'), ('month', 'Month'), ('year', 'Year')))
	accounting = models.IntegerField(null = True)
	total_user = models.IntegerField(null = True)
	total_user_with_mainstore = models.IntegerField(null = True)
	total_user_with_channel = models.IntegerField(null = True)
	total_user_active = models.IntegerField(null = True)
	total_user_expired = models.IntegerField(null = True)
	total_user_trial_expired = models.IntegerField(null = True)
	total_user_trial_active = models.IntegerField(null = True)
	details_user_active = models.TextField(null = True)
	details_user_active_monthly = models.TextField(null = True)

	class Meta:
		db_table = 'total_user_report'
		ordering = ['-id']