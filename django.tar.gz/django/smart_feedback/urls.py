from django.urls import path

from smart_feedback.views import SmartFeedbackApiView

urlpatterns = [
	path('', SmartFeedbackApiView.as_view()),

]
