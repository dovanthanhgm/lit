# Create your views here.
from django.core.mail import send_mail
from django.forms import model_to_dict
from django.http import Http404
from django.template.loader import render_to_string
from rest_framework import generics

from accounts.utils import AccountUtils
from libs.utils import is_local
from smart_feedback.models import SmartFeedback
from smart_feedback.serializers import SmartFeedbackSerializer


class SmartFeedbackApiView(generics.CreateAPIView):
	queryset = SmartFeedback.objects.all()
	serializer_class = SmartFeedbackSerializer
	def perform_create(self, serializer):
		user_id = AccountUtils().get_user_id(self.request)
		user = AccountUtils().get_user_by_request(self.request)
		if user.feedback:
			raise Http404()
		serializer.save(user_id = user_id)
		user.feedback = True
		user.save()
		if not is_local():
			obj = serializer.validated_data
			html_message = render_to_string('admin/feedback/content.html', { 'user': model_to_dict(user), 'obj': obj})
			send_mail(
				subject = f"{self.request.user.email} Feedback",
				message = '',
				from_email = self.request.user.email,
				recipient_list = ['contact@litcommerce.com'],
				html_message = html_message,
				fail_silently = False
			)
