from django.db import models

# Create your models here.
from accounts.models import UserAccount


class SmartFeedback(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True)
	rate = models.CharField(max_length = 25, choices = (('bad', 'Bad'), ('good', 'Good')))
	feedback = models.TextField(null = True)
	more_details = models.TextField(null = True)
	star = models.IntegerField(null = True, choices = ((1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5')))
	created_at = models.DateTimeField(auto_now_add = True)


	class Meta:
		db_table = 'smart_feedback'
		unique_together = (
			["user_id"],
		)
		ordering = ['-id']
