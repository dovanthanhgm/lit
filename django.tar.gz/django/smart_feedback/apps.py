from django.apps import AppConfig


class SmartFeedbackConfig(AppConfig):
    name = 'smart_feedback'
