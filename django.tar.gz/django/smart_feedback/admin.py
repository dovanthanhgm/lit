from django.contrib import admin
from django.db.models import Count
from django.shortcuts import render
from django.urls import path
from django.views.generic import TemplateView

from core.myadmin.admin import CoreAdmin, UserFilter
from libs.utils import json_encode, to_str
from .models import SmartFeedback
class StatsViews(TemplateView):
	def get(self, request, *args, **kwargs):
		query_set = SmartFeedback.objects.all().order_by().values('rate').annotate(total = Count('id'))
		data = list(query_set)
		report_data = []
		report_data.append(['Rate', 'Number'])
		for row in data:
			report_data.append([to_str(row['rate']), row['total']])
		context = {
		'chart_data': json_encode(report_data),
		'chart_title': 'Smart Feedback',
		'chart_id': 'feedback_pie',
	}
		return render(request, 'admin/stats/smart_feedback/report.html', context)


class SmartFeedbackAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'rate', 'feedback', 'more_details', 'star', 'created_at']
	list_filter = [UserFilter, 'star', 'rate']
	def get_urls(self):
		urls = super().get_urls()
		my_urls = [
			path('report/', StatsViews.as_view(), name = 'smart_feedback_report'),
		]
		return my_urls + urls

admin.site.register(SmartFeedback, SmartFeedbackAdmin)
