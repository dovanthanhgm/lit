from rest_framework import serializers

from .models import SmartFeedback


class SmartFeedbackSerializer(serializers.ModelSerializer):
	class Meta:
		model = SmartFeedback
		fields = ["rate", "feedback", "more_details", 'id', 'star']
