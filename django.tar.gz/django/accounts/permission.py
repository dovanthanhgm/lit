from rest_framework import permissions

from accounts.models import AdminAccessToken
from accounts.utils import AccountUtils
from libs.utils import to_str, to_int, is_local


class IsStaff(permissions.BasePermission):
	message = 'Adding customers not allowed.'


	def has_permission(self, request, view):
		# Read permissions are allowed to any request,
		# so we'll always allow GET, HEAD or OPTIONS requests.
		return request.user and request.user.is_staff


class IsLoginByToken(permissions.BasePermission):
	def __init__(self):
		super().__init__()
		self._admin = None


	def has_permission(self, request, view):
		if is_local():
			return True
		if not request.META.get('HTTP_AUTHORIZATION'):
			return False
		access_token = to_str(request.META.get('HTTP_AUTHORIZATION')).split()[-1]
		if not access_token:
			return False
		user_id = AccountUtils().get_user_id(request)
		try:
			admin_token = AdminAccessToken.objects.get(access_token = access_token, user_id = user_id)
		except AdminAccessToken.DoesNotExist:
			return False
		admin_id = admin_token.admin_id
		if not admin_id:
			return False
		admin = AccountUtils().get_user(admin_id)
		if not admin or to_int(admin.is_staff) == 0:
			return False
		self._admin = admin
		return True
