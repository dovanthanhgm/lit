import time
from datetime import datetime, date, timedelta

import dateutil.relativedelta
from background_task.models import Task
from django import template
from django.db.models import Sum, F, Q, Count
from django.db.models.functions import TruncMonth
from django.utils.html import format_html

from accounts.models import UserAccount
from channels.models import Channel
from core.myadmin.utils import MyAdminUtils
from datasync.models import TotalUserReport
from libs.utils import to_int, get_full_absolute_uri, json_encode, json_decode, get_current_time, to_str
from litcommerce_order.models import LitCommerceOrder
from payments.models import PaymentHistory
from processes.models import Process
from subscription.models import UserSubscription, Subscription
from user_action_logs.models import UserActionLogs
from user_logs.models import UserLogs

register = template.Library()


@register.inclusion_tag('admin/dashboard/stats.html')
def user_stats():
	current_time = datetime.fromtimestamp(to_int(time.time()) - 60 * 3).strftime("%Y-%m-%d %H:%M:%S")

	user_online_queryset = UserAccount.objects.filter(last_access__gt = current_time)
	# user_queryset = UserAccount.objects.filter(Q(last_access__lt = current_time) | Q(last_access__isnull = True))
	user_online_number = user_online_queryset.count()
	user_online = list(user_online_queryset[0:5])
	task_queryset = Task.objects.all().values('verbose_name')
	process_queryset = Process.objects.filter(id__in = task_queryset).exclude(type = 'refresh').values('user_id')
	user_scheduler_queryset = UserAccount.objects.filter(id__in = process_queryset)
	user_scheduler_number = user_scheduler_queryset.count()
	user_scheduler = list(user_scheduler_queryset[0:5])
	# stats channels

	return dict(
		user_online = user_online,
		user_online_number = user_online_number,
		user_scheduler = user_scheduler,
		user_scheduler_number = user_scheduler_number,
	)


@register.inclusion_tag('admin/accounts/user/info.html')
def user_info(users):
	return {
		"users": users,
	}


@register.inclusion_tag('admin/accounts/user/number_scheduler.html')
def user_scheduler(users):
	return {
		"users": users,
	}


@register.inclusion_tag('admin/accounts/most_active.html')
def user_most_active():
	today = date.today()
	last_week_start = today - timedelta(days = 7)
	users_stat = UserActionLogs.objects.filter(created_at__gte = last_week_start).values('user_id').annotate(total = Count('id')).order_by('-total')[:5]
	user_ids = [user['user_id'] for user in users_stat]
	users = UserAccount.objects.filter(id__in = user_ids)
	user_stats = {user['user_id']: user for user in users_stat}
	users = sorted(users, key = lambda x: user_stats[x.id]['total'], reverse = True)

	return {
		"users": users,
		"user_stats": user_stats,
	}


@register.simple_tag
def most_active_total(user_id, user_stats):
	return user_stats[user_id]['total']


@register.simple_tag
def list_channels(user_id):
	channels = Channel.objects.filter(user_id = user_id, deleted_at__isnull = True)

	channel_name = list()
	if channels:
		for channel in channels:
			channel_name.append(f"<a href='/admin/channels/channel/{channel.id}/change' target='_blank' class='_link' style='color:grey !important;'>{channel.type}</a>")
	if channels:
		html_channel = f"<a href='/admin/channels/channel/?user__id__exact={user_id}' target='_blank' class='_link' style='color:blue;'>Channel</a>"
		html_channel += '<br/>'
		html_channel += "(" + ', '.join(channel_name) + ")"
		return format_html(html_channel)
	return "--"


@register.simple_tag
def number_scheduler(user_id):
	process_queryset = Process.objects.filter(user_id = user_id).values('id')
	task_queryset = Task.objects.filter(verbose_name__in = process_queryset).count()
	html_channel = f"<a href='{get_full_absolute_uri('admin:background_task_task_changelist')}?email={user_id}' target='_blank' class='_link' style='color:blue;'>{task_queryset}</a>"
	return format_html(html_channel)


@register.inclusion_tag('admin/channels/stats.html')
def channel_stats():
	today = date.today()
	week_start = today
	week_start -= timedelta(days = week_start.weekday())
	week_end = week_start + timedelta(days = 7)
	last_week_start = today - timedelta(days = 7)
	last_week_start -= timedelta(days = week_start.weekday())
	last_week_end = last_week_start + timedelta(days = 7)
	last_month = today - dateutil.relativedelta.relativedelta(months = 1)
	delete_this_week = UserActionLogs.objects.filter(created_at__gte = week_start, created_at__lt = week_end, action = 'delete_channel').count()
	delete_last_week = UserActionLogs.objects.filter(created_at__gte = last_week_start, created_at__lt = last_week_end, action = 'delete_channel').count()
	delete_this_month = UserActionLogs.objects.filter(created_at__year = today.year, created_at__month = today.month, action = 'delete_channel').count()
	delete_last_month = UserActionLogs.objects.filter(created_at__year = last_month.year, created_at__month = last_month.month, action = 'delete_channel').count()
	return {
		'channel_stat': {
			"This Week": dict(
				created = Channel.objects.filter(created_at__gte = week_start, created_at__lt = week_end).count() + delete_this_week,
				deleted = Channel.objects.filter(deleted_at__gte = week_start, deleted_at__lt = week_end).count() + delete_this_week,
			),
			"Last Week": dict(
				created = Channel.objects.filter(created_at__gte = last_week_start, created_at__lt = last_week_end).count() + delete_last_week,
				deleted = Channel.objects.filter(deleted_at__gte = last_week_start, deleted_at__lt = last_week_end).count() + delete_last_week,
			),
			"This Month": dict(
				created = Channel.objects.filter(created_at__year = today.year, created_at__month = today.month).count() + delete_this_month,
				deleted = Channel.objects.filter(deleted_at__year = today.year, deleted_at__month = today.month).count() + delete_this_month,
			),
			"Last Month": dict(
				created = Channel.objects.filter(created_at__year = last_month.year, created_at__month = last_month.month).count() + delete_last_month,
				deleted = Channel.objects.filter(deleted_at__year = last_month.year, deleted_at__month = last_month.month).count() + delete_last_month,
			)
		}
	}


@register.inclusion_tag('admin/dashboard/last_order.html')
def last_order():
	orders = LitCommerceOrder.objects.filter(status = 'completed').order_by('-created_at')[:5]
	return {
		'orders': orders
	}


@register.inclusion_tag('admin/dashboard/last_payment.html')
def last_payment():
	payments = PaymentHistory.objects.filter(status = 'completed').order_by('-created_at')[:5]
	return {
		'payments': payments
	}


@register.inclusion_tag('admin/dashboard/expires_within_1_months.html')
def expires_within_1_month():
	current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")

	expired_time = datetime.fromtimestamp(to_int(time.time())) + dateutil.relativedelta.relativedelta(days = 30)
	plan_queryset = UserSubscription.objects.filter(expired_at__lt = expired_time, expired_at__gt = current_time).exclude(expired_at__isnull = True, plan_id = 1).order_by('expired_at')
	plan_number = plan_queryset.count()
	plan_expired = list(plan_queryset[0:5])
	return {
		'user_expired': plan_expired,
		'number_user_expired': plan_number,
	}


@register.inclusion_tag('admin/stats/line_chart.html')
def admin_user_stats():
	new_user = list(UserAccount.objects.filter(is_staff = False).annotate(month = TruncMonth('created_at')).values('month').annotate(total = Count('id')).values('month', 'total').order_by('-month')[:10])
	new_user.reverse()
	new_user_stats = [
		['Month', 'New Payment User', 'New User', 'New User With MainStore', 'New User With Channel', 'Payment User', 'Expired User']
	]
	new_user_data = {row['month'].strftime('%Y-%m'): to_int(row['total']) for row in new_user}
	new_payment_user_queryset = LitCommerceOrder.objects.filter(status = 'completed').values('user_id')
	new_payment_user = list(UserAccount.objects.filter(id__in = new_payment_user_queryset).annotate(month = TruncMonth('created_at')).values('month').annotate(total = Count('id')).values('month', 'total').order_by('-month')[:10])
	new_payment_user.reverse()
	new_payment_user_data = {row['month'].strftime('%Y-%m'): to_int(row['total']) for row in new_payment_user}
	today = date.today()
	subscription_queryset = list(UserSubscription.objects.exclude(plan_id = 1).filter(Q(expired_at__isnull = False) & Q(expired_at__lte = today)).annotate(month = TruncMonth('expired_at')).values('month').annotate(total = Count('id')).values('month', 'total').order_by('-month')[:10])
	subscription_data = {row['month'].strftime('%Y-%m'): to_int(row['total']) for row in subscription_queryset}
	payment_user_queryset = list(PaymentHistory.objects.filter(status = 'completed').annotate(month = TruncMonth('created_at')).values('month').annotate(total = Count('user_id', distinct = True)).values('month', 'total').order_by('-month')[:10])
	payment_user_data = {row['month'].strftime('%Y-%m'): to_int(row['total']) for row in payment_user_queryset}
	mainstore_query_set = Channel.objects.filter(default = 1, deleted_at__isnull = True).values('user_id')
	user_with_mainstore_queryset = list(UserAccount.objects.filter(id__in = mainstore_query_set, is_staff = False).annotate(month = TruncMonth('created_at')).values('month').annotate(total = Count('id')).values('month', 'total').order_by('-month')[:10])
	user_with_mainstore_data = {row['month'].strftime('%Y-%m'): to_int(row['total']) for row in user_with_mainstore_queryset}
	channel_query_set = Channel.objects.filter(deleted_at__isnull = True).exclude(default = 1).values('user_id')
	user_with_channel_queryset = list(UserAccount.objects.filter(id__in = channel_query_set, is_staff = False).annotate(month = TruncMonth('created_at')).values('month').annotate(total = Count('id')).values('month', 'total').order_by('-month')[:10])
	user_with_channel_data = {row['month'].strftime('%Y-%m'): to_int(row['total']) for row in user_with_channel_queryset}
	for month, total_new_user in new_user_data.items():
		new_user_stats.append((month, new_payment_user_data.get(month, 0), total_new_user, user_with_mainstore_data.get(month, 0), user_with_channel_data.get(month, 0), payment_user_data.get(month, 0), subscription_data.get(month, 0)))
	return {
		'chart_data': json_encode(new_user_stats),
		'chart_title': 'User Stats',
		'chart_id': 'user_stats',
	}
@register.inclusion_tag('admin/stats/line_chart.html')
def admin_user_active_stats():
	plans = Subscription.objects.exclude(id__in = [1, 8]).filter(type = 'system')
	plan_data = {plan.id: plan.name for plan in plans}
	sort_id = [row.id for row in plans]
	title = ['Month', 'Total', 'Total Expired']
	for row in plans:
		title.append(row.name)
	chart_data = [
		title
	]
	total_user_report = list(TotalUserReport.objects.filter(report_type = 'month').order_by('-accounting')[0:11])
	total_user_report.reverse()
	report_data = list()
	for row in total_user_report:
		row_data = {plan['plan_id']:plan['total'] for plan in json_decode(row.details_user_active)}
		row_data['total'] = row.total_user_active
		row_data['expired'] = row.total_user_expired
		row_data['accounting'] = row.accounting
		report_data.append(row_data)
	current_report = MyAdminUtils().total_user_report()
	row_data = {plan['plan_id']: plan['total'] for plan in current_report['details_user_active']}
	row_data['total'] = current_report['total_user_active']
	row_data['expired'] = current_report['total_user_expired']
	row_data['accounting'] = get_current_time('%Y%m')
	report_data.append(row_data)
	for row in report_data:
		accounting = to_str(row['accounting'])
		row_chart_data = [f'{accounting[0:4]}-{accounting[4:]}']
		row_chart_data.append(row.get('total', 0))
		row_chart_data.append(row.get('expired', 0))
		for plan_id in sort_id:
			row_chart_data.append(row.get(plan_id, 0))
		chart_data.append(row_chart_data)
	return {
		'chart_data': json_encode(chart_data),
		'chart_title': 'User Active Stats',
		'chart_id': 'user_active_stats',
	}


@register.inclusion_tag('admin/stats/base_pie.html', takes_context = True)
def duration_stats(context):
	paid_user = UserAccount.objects.exclude(duration_paid__isnull = True).values('duration_paid').annotate(total = Count('id')).order_by('total')
	duration_data = dict()
	duration_data[6] = 0
	for row in paid_user:
		if row['duration_paid'] <= 5:
			duration_data[row['duration_paid']] = row['total']
		else:
			duration_data[6] += row['total']
	duration_stats = list()
	text = ['During the day', '< 1 week', '1-2 weeks', '2-3 weeks', '3-4 weeks', '4-5 weeks', '>5 weeks']
	for week, number in duration_data.items():
		duration_stats.append({
			'label': text[week],
			'total': number
		})
	duration_stats.sort(key = lambda x: x['total'])
	duration_stats.reverse()
	stat_data = list()
	stat_data.append(['Time', 'Number'])
	for row in duration_stats:
		stat_data.append([row['label'], row['total']])
	return {
		'chart_data': json_encode(stat_data),
		'chart_title': 'Duration Paid',
		'chart_id': 'duration_pie',
		# 'mainstore_filter': request.GET.get('mainstore_filter'),
		# 'channels': ['shopify', 'woocommerce', 'bigcommerce', 'wix', 'etsy', 'ebay', 'amazon', 'magento'],
	}