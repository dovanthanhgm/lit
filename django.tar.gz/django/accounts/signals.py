from background_task.models import Task
from django.db.models.signals import pre_delete
from django.dispatch import receiver

from accounts.models import UserAccount
from accounts.utils import AccountUtils
from libs.models.collections.catalog import Catalog
from libs.models.collections.state import State

@receiver(pre_delete, sender=UserAccount)
def process_pre_delete(sender, instance, **kwargs):
	try:
		AccountUtils().close_account(instance.id)
	except Exception:
		pass