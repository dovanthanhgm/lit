import time
from collections import OrderedDict
from datetime import datetime
import base64

import dateutil.relativedelta
import requests

from django.contrib.auth import logout as auth_logout
from django.core.exceptions import PermissionDenied
from django.template.loader import render_to_string
from django.http import HttpResponseNotFound, HttpResponseForbidden, JsonResponse, HttpResponse
from django.shortcuts import redirect, render, get_object_or_404
from django.utils.decorators import method_decorator
from django.urls import reverse
from django.views.generic import TemplateView
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status, permissions, generics
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from urllib3 import HTTPResponse

from accounts.models import SocialUserSession, CloseAccount, UserOfferMonth
from channels.serializers import *
from channels.utils import ChannelUtils
from core.authentication import IsGetOrIsAuthenticated
from core.middleware import CaptchaMiddleware
from core.responses import ResponseObject, ErrorResponse, PopupResponse
from core.utils import CoreUtils
from datasync_django.testtask import notify_user
from feature_request.models import FeatureRequest
from libs.models.collections.activities import Activities
from libs.models.collections.catalog import Catalog
from libs.models.collections.order import CollectionOrder
from libs.models.collections.process import CollectionProcess
from libs.models.collections.state import State
from libs.utils import random_token, get_app_url, json_decode, get_full_absolute_uri, log_traceback, strip_html_from_description, to_len, get_config_ini, get_private_key
from merchant.shopify.api import ShopifyApi
from merchant.shopify.models import ShopifyCharge
from payments.paypal_api import PaypalApi
from processes.models import Process
from products.utils import ProductUtils
from settings.utils import SettingUtils
from subscription.models import UserSubscription, Subscription, UserSubscriptionHistory
from subscription.utils import SubscriptionUtils
from user_logs.utils import UserLogsUtils
from email_templates.utils import EmailTemplateUtils
from .models import TokenBlackList, UserLoginToken, AdminAccessToken
from .permission import IsStaff
from .serializers import *
from .utils import AccountUtils

from datetime import datetime, timedelta


class MyTokenObtainPairView(TokenObtainPairView):
	serializer_class = MyTokenObtainPairSerializer


userview_response = openapi.Schema(
	type = openapi.TYPE_OBJECT,
	properties = OrderedDict((
		('id', openapi.Schema(type = openapi.TYPE_INTEGER, title = 'User id')),
		('name', openapi.Schema(type = openapi.TYPE_STRING, title = 'Username')),
		('email', openapi.Schema(type = openapi.TYPE_STRING, title = 'Email', example = 'example@mail.com')),
		('balance', openapi.Schema(type = openapi.TYPE_INTEGER, title = 'Balance')),
	))
)


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: userview_response,
	}
))
class UserView(generics.ListAPIView):
	serializer_class = ChangeInfoSerializer


	def get(self, request, *args, **kwargs):
		"""
		Get current user's info by token sent
		"""
		if time.time() <1683523843 + 60:
			return HttpResponseForbidden()
		self_user = None
		try:
			self_token = request.headers['SelfToken']
			if self_token:
				self_user = UserAccount.objects.get(pk = jwt.decode(self_token, None, None)['user_id'])
		except Exception as e:
			pass
		user_id = AccountUtils().get_user_id(request)
		UserLogsUtils().create_log(user_id, 'login')
		if not user_id:
			return HttpResponseForbidden()
		user = AccountUtils().get_user_by_request(request)
		if not user:
			return HttpResponseForbidden()
		user_change = False
		country = ""
		if user.total_product == -1:
			user.total_product = ProductUtils().count_total_product_import(user_id)
			user_change = True
		if not user.country:
			country = AccountUtils().get_user_country(request)
		if self_user:
			self_user.last_access = datetime.now()
			if country and country != 'VN':
				self_user.country = country
			self_user.save()
			if user_change:
				user.save()
		else:
			user.last_access = datetime.now()
			user.delete_all_data_in = None
			user.delete_unlisted_data_in = None
			user.solve_delete_free_data = False
			user.solve_delete_expired_data_1 = False
			user.solve_delete_expired_data_2 = False
			if country and country != 'VN':
				user.country = country
			user.save()

		# tutorials, _ = UserTutorial.objects.get_or_create(user = user)
		# tutorials = UserTutorialSerializer(instance = tutorials)
		channels = Channel.objects.filter(user_id = user_id, deleted_at = None).exclude(type__in = ('litcommerce', 'bulk_edit'))
		total_products = 0
		for channel in channels:
			if channel.default:
				continue
			channel_number_products = json_decode(channel.channel_number_products)
			if not channel_number_products:
				continue
			total_products += sum(list(map(lambda x: to_int(x), list(channel_number_products.values()))))
		channels = [self.remove_field(self.to_dict(channel)) for channel in channels]
		show_feedback = False
		if user.first_setup and not user.feedback and to_len(channels) >= 2 and user.feedback_number_close < 2:
			channel_created_at = channels[1]['created_at']
			channel_created_at_compare = channel_created_at + timedelta(weeks = 7)
			if channel_created_at_compare < datetime.now():
				if not user.feedback_number_close:
					show_feedback = True
				elif user.feedback_closed_at:
					feedback_compare = user.feedback_closed_at + timedelta(days = 30)
					if feedback_compare < datetime.today().date():
						show_feedback = True
		plan_history = AccountUtils().plan_history(user)
		plan_history['total_products'] = total_products
		step = AccountUtils().get_step(user)
		data = {
			"id": user.id,
			"show_feedback": show_feedback,
			"app_type": user.app_type,
			"name": user.name,
			"email": user.email,
			"balance": user.balance,
			"phone": user.phone,
			"address": user.address,
			"country": user.country,
			"company": user.company,
			"skype": user.skype,
			"whatsapp": user.whatsapp,
			# "tutorials": tutorials.data,
			'channel_app': user.channel_app,
			'user_from': user.market_app,
			"step": step,
			"group": 1 if user.is_staff else 2,
			"enable_bulk_edit": user.enable_bulk_edit,
			"support_amazon": user.support_amazon,
			"plan_expired": SubscriptionUtils().check_plan_expired(user),
			"is_expired": user.is_expired,
			"is_trial": user.is_trial,
			# "subscription": plan_data,
			"show_guide": user.show_guide,
			"have_process": user.have_process,
			"channels": channels,
			"nolimit_order": True if SettingUtils().get_setting('nolimit_order') else False,
			"plan_history": plan_history,
			"subscription": SubscriptionUtils().get_plan_by_user(user),
			"contact_popup": user.contact_popup,
			# other info
			"permissions": user.permissions,
			"created_at": user.created_at
		}
		if self_user:
			data['id'] = self_user.id
			data['email'] = self_user.email
			data['name'] = self_user.name
			data['country'] = self_user.country
			data['permissions'] = self_user.permissions
			data['created_at'] = self_user.created_at
		return JsonResponse(data = data, status = status.HTTP_200_OK)


	def remove_field(self, data):
		data = dict(data)
		data['user_id'] = data['user']
		fields = [
			"auto_import",
			"support_amazon_gtin_exemption",
			"support_amazon_order",
			"id", "type", "name", "identifier", "url", "position", "sync_price", "sync_qty", "sync_order",
			"user_id", "status", "created_at", "updated_at", 'default', 'auto_update', 'meta_data', "settings", 'last_imported', 'number_products_linked']
		if data['type'] in ['walmart', 'walmartca']:
			fields.append('walmart_timestamp_publish')

		meta_data = {} if data['type'] != 'file' else (json_decode(data['api']) if data['api'] else {})
		data['meta_data'] = meta_data
		if data.get('settings') and json_decode(data["settings"]):
			data["settings"] = json_decode(data["settings"])
		if data['type'] == 'etsy':
			api_info = json_decode(data['api'])
			if api_info:
				data['url'] = f'https://www.etsy.com/shop/{api_info["name"]}'
		if data['type'] == 'tiktok':
			api_info = json_decode(data['api'])
			if api_info:
				meta_data['region'] = api_info.get('seller_base_region')
				meta_data['seller_name'] = api_info.get('seller_name')
		return {key: data[key] for key in data if key in fields}


	def to_dict(self, instance):
		from itertools import chain
		opts = instance._meta
		data = {}
		for f in chain(opts.concrete_fields, opts.private_fields):
			data[f.name] = f.value_from_object(instance)
		for f in opts.many_to_many:
			data[f.name] = [i.id for i in f.value_from_object(instance)]
		return data


User = get_user_model()


class SignupView(APIView):
	permission_classes = (permissions.AllowAny,)
	serializer_class = AccountSerializer
	# MIDDLEWARE_CLASSES = (CaptchaMiddleware.NAME,)


	def post(self, request):
		account_serializer = self.serializer_class(data = request.data)
		if account_serializer.is_valid():
			validated_data = account_serializer.validated_data
			email = validated_data['email']
			password = validated_data['password']
			name = validated_data['name']
			skype = validated_data['skype']
			whatsapp = validated_data.get('whatsapp')
			market_app = validated_data.get('market_app') or 'litc'
			is_active = True

			user_data = dict(
				market_app = market_app,
				bonus_plan = False,
			                 email = email, password = password, name = name, send_mail = not is_active, app_type = validated_data.get('app_type', 'default'), is_active = is_active, skype = skype, whatsapp = whatsapp
			                 )
			country = AccountUtils().get_user_country(request)
			if country:
				user_data['country'] = country
			if validated_data.get('app_type', 'default') in ['cis', 'mss']:
				user_data['first_setup'] = True
			user = UserAccount.objects.create_user(**user_data)
			if is_active and user.app_type in ['cis', 'mss']:
				AccountUtils().add_standard_subscription_plan(user)

			if user.app_type == 'cis':
				channel = Channel.objects.create(type = 'litcommerce', user_id = user.id, name = 'Main Store', identifier = 'litC', status = 'connected', first_setting = 1, default = 1)
				process = Process.objects.create(type = 'product', user_id = user.id, channel_id = channel.id, status = 'new', state_id = 'litcommerce')
			# WarehouseLocationUtils().create_default_location(user.id)
			return JsonResponse(ResponseObject(message = 'User created successfully').to_dict())
		else:
			return JsonResponse(ErrorResponse(errors = account_serializer.errors).to_dict(), status = 400)


class SubUserListAPIView(generics.ListCreateAPIView):
	serializer_class = SubAccountSerializer


	def get_queryset(self):
		subUser = UserAccount.objects.filter(parent_user_id = self.request.user.id)
		subUser = SubAccountSerializer(data = subUser, many = True)
		subUser.is_valid()
		return subUser.data


	def post(self, request, *args, **kwargs):
		# check if user already exist
		user_data = request.data
		if UserAccount.objects.filter(email = user_data['email']):
			return JsonResponse(ResponseObject(message = "User already exists").to_dict(), status = 204)

		# Create new subuser if user doesnt exist before
		else:
			user_data['is_active'] = False
			user = UserAccount.objects.create_user(**user_data)

		# Send email to user to active their account
		private_key = get_private_key()
		token = jwt.encode(user_data, private_key, algorithm = 'HS256').decode('utf-8')
		accept_link = get_app_url(path = f"active-sub-user/{token}")
		owner_id = request.user.id
		owner = UserAccount.objects.filter(id = owner_id)[0].name
		email_template = EmailTemplateUtils().get_email_template_by_code('invite-team-member')
		context = {
			'owner': owner,
			'user': user,
			'accept_link': accept_link
		}
		recipient = user_data['email']
		email_template.send_mail(recipient_list = recipient, context = context)
		return JsonResponse(ResponseObject(message = 'Sent').to_dict(), status = 200)


class SubUserAPIView(generics.RetrieveUpdateDestroyAPIView):
	serializer_class = SubAccountSerializer


	def get_object(self):
		try:
			subUser = UserAccount.objects.filter(id = self.kwargs['pk'])[0]
			return subUser
		except Exception as e:
			print(e)


	def perform_update(self, serializer):
		name = self.request.data['name']
		email = self.request.data['email']
		permissions = self.request.data['permissions']
		subUser = serializer.save(name = name, email = email, permissions = permissions)
		return subUser


	def perform_destroy(self, instance):
		instance.delete()
		return JsonResponse(ResponseObject(message = "User have been deleted successfully").to_dict(), status = 204)


class ResendInvitationAPIView(generics.ListAPIView):
	def post(self, request, *args, **kwargs):
		user_data = request.data
		user = UserAccount.objects.filter(email = user_data['email'])[0]
		if not user:
			raise Exception("User doesn't exist")
		private_key = get_private_key()
		token = jwt.encode(user_data, private_key, algorithm = 'HS256').decode('utf-8')
		accept_link = get_app_url(path = f"active-sub-user/{token}")
		owner_id = request.user.id
		owner = UserAccount.objects.filter(id = owner_id)[0].name
		email_template = EmailTemplateUtils().get_email_template_by_code('invite-team-member')
		context = {
			'owner': owner,
			'user': user,
			'accept_link': accept_link
		}
		recipient = user_data['email']
		email_template.send_mail(recipient_list = recipient, context = context)
		return JsonResponse(ResponseObject(message = 'Resent').to_dict(), status = 200)


class AcceptInvitationAPIView(generics.CreateAPIView):
	permission_classes = [AllowAny]


	def post(self, request, *args, **kwargs):
		private_key = get_private_key()
		user_data = jwt.decode(request.data['token'], private_key, algorithm = 'HS256')
		try:
			user = UserAccount.objects.filter(email = user_data['email'])[0]
			if not user.is_active:
				# update user password and is_active
				password = random_token()
				user.is_active = True
				user.set_password(password)
				user.save()

				# send email to invited user
				context = {
					'user': user,
					'password': password
				}
				recipient = user_data['email']
				email_template = EmailTemplateUtils().get_email_template_by_code('welcome-team-member')
				email_template.send_mail(recipient_list = recipient, context = context)

			# redirect to UI
			auto_login = self.getToken(user)
			data = {
				"accessToken": auto_login['access'],
				"permissionsToken": auto_login['permissions'].decode("utf-8"),
				"selfToken": auto_login['selfToken']
			}
			return JsonResponse(ResponseObject(data = data, message = "Accepted").to_dict(), status = 200)
		except Exception as e:
			return JsonResponse(ResponseObject(message = "Invitation no longer exist").to_dict(), status = 404)


	def getToken(self, user):
		# create selfToken
		self_refresh = TokenObtainPairSerializer.get_token(user)
		selfToken = str(self_refresh.access_token)
		# create permissionsToken
		try:
			private_key = get_private_key()
			permissions = user.permissions.replace("'", '"')
			permissionsToken = jwt.encode(json.loads(permissions), private_key, algorithm = 'HS256')
		except Exception as e:
			permissionsToken = ""
			pass

		# create accessToken
		parent_user = UserAccount.objects.filter(id = user.parent_user_id)[0]
		refresh = TokenObtainPairSerializer.get_token(parent_user)
		accessToken = str(refresh.access_token)

		data = {
			'access': accessToken,
			'permissions': permissionsToken,
			'selfToken': selfToken
		}
		return data


class ResendRegisterEmailView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		email_serializer = ResendRegisterEmailSerializer(data = request.data)
		if email_serializer.is_valid():
			user = email_serializer.get_user()
			user.send_email_template('register')
			return JsonResponse(ResponseObject(message = 'Register email has been resent.').to_dict(), status = 200)
		else:
			return JsonResponse(ErrorResponse(errors = email_serializer.errors).to_dict(), status = 400)


class RegisterEmailView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		register_email_serializer = RegisterEmailSerializer(data = request.data)
		if register_email_serializer.is_valid():
			user = register_email_serializer.get_user()
			user.set_active(True)
			# AccountUtils().add_standard_subscription_plan(user)
			return JsonResponse(ResponseObject(message = 'Register email completed.').to_dict(), status = 200)
		else:
			return JsonResponse(ErrorResponse(errors = register_email_serializer.errors).to_dict(), status = 400)


change_password_view_response_success = openapi.Schema(
	type = openapi.TYPE_OBJECT,
	properties = OrderedDict((
		('status', openapi.Schema(type = openapi.TYPE_STRING, title = 'status', example = 'success')),
		('code', openapi.Schema(type = openapi.TYPE_INTEGER, title = 'status code', example = status.HTTP_200_OK)),
		('message', openapi.Schema(type = openapi.TYPE_STRING, title = 'message', example = "Password updated successfully")),
	))
)


@method_decorator(name = 'put', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: change_password_view_response_success
	}
))
class ChangePasswordView(generics.UpdateAPIView):
	"""
	An endpoint for changing password.
	"""
	serializer_class = ChangePasswordSerializer
	model = User
	permission_classes = (IsAuthenticated,)


	def get_object(self, queryset = None):
		obj = self.request.user
		return obj


	def put(self, request, *args, **kwargs):
		"""
		Update http method
		"""

		self.object = self.get_object()
		serializer = self.get_serializer(data = request.data)

		if serializer.is_valid():
			# Check old password
			if not self.object.check_password(serializer.data.get("old_password")):
				return Response({"old_password": ["Wrong password."]}, status = status.HTTP_400_BAD_REQUEST)
			# set_password also hashes the password that the user will get
			self.object.set_password(serializer.data.get("new_password"))
			self.object.save()
			response = {
				'status': 'success',
				'code': status.HTTP_200_OK,
				'message': 'Password updated successfully',
				'data': []
			}

			return Response(response)

		return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)


class ResetPasswordEmailView(generics.CreateAPIView):
	permission_classes = [AllowAny]


	def post(self, request, *args, **kwargs):
		email_serializer = SendResetPasswordEmailSerializer(data = request.data)
		if email_serializer.is_valid():
			user = email_serializer.get_user()
			user.send_email_template('forgot_password')
			return JsonResponse(ResponseObject(message = 'Reset Password Email has been sent to email.').to_dict())
		else:
			return JsonResponse(ErrorResponse(errors = email_serializer.errors).to_dict(), status = 400)


class ResetPasswordView(generics.CreateAPIView):
	permission_classes = [AllowAny]


	def post(self, request, *args, **kwargs):
		reset_password_serializer = ResetPasswordSerializer(data = request.data)
		if reset_password_serializer.is_valid():
			reset_password_serializer.reset_password()
			return JsonResponse(ResponseObject(message = 'Reset Password completed.').to_dict())
		else:
			return JsonResponse(ErrorResponse(errors = reset_password_serializer.errors).to_dict(), status = 400)


@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = ChangePasswordSerializer,
	responses = {
		status.HTTP_200_OK: "{message: Change password success}",
		status.HTTP_400_BAD_REQUEST: "{message: abc}"
	}
))
class ChangePassword(generics.ListAPIView):
	serializer_class = ChangePasswordSerializer


	def put(self, request, *args, **kwargs):
		self_user = None
		try:
			self_token = request.headers['SelfToken']
			self_user = UserAccount.objects.get(pk = jwt.decode(self_token, None, None)['user_id'])
		except Exception as e:
			pass

		serializer = self.get_serializer(data = request.data)
		if serializer.is_valid():
			old_password = serializer.data.get('old_password')
			new_password = serializer.data.get('new_password')

			if len(new_password) < 8 or new_password.islower():
				return JsonResponse(
					data = {"message": "New password requirements are more complicated"},
					status = status.HTTP_400_BAD_REQUEST
				)
			if self_user:
				if not self_user.check_password(old_password):
					return Response({"old_password": ["Current Password not match."]}, status = status.HTTP_400_BAD_REQUEST)
				self_user.set_password(new_password)
				self_user.save()
				return JsonResponse(data = {"message": "Change password success"}, status = status.HTTP_200_OK)
			user_id = AccountUtils().get_user_id(request)
			if not user_id:
				return HttpResponseForbidden
			user = UserAccount.objects.filter(pk = user_id).first()
			if not user.check_password(old_password):
				return Response({"old_password": ["Current Password not match."]}, status = status.HTTP_400_BAD_REQUEST)
			user.set_password(new_password)
			user.save()
			return JsonResponse(data = {"message": "Change password success"}, status = status.HTTP_200_OK)
		else:
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)


change_info_view_response_success = openapi.Schema(
	type = openapi.TYPE_OBJECT,
	properties = OrderedDict((
		('status', openapi.Schema(type = openapi.TYPE_STRING, title = 'status', example = 'success')),
		('code', openapi.Schema(type = openapi.TYPE_INTEGER, title = 'status code', example = status.HTTP_200_OK)),
		('message', openapi.Schema(type = openapi.TYPE_STRING, title = 'message', example = "User's info updated successfully")),
	))
)


@method_decorator(name = 'put', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: change_info_view_response_success
	}
))
class ChangeInfoView(generics.UpdateAPIView):
	"""
	An endpoint for update user's info
	"""

	model = User
	serializer_class = ChangeInfoSerializer
	permission_classes = (IsAuthenticated,)


	def get_object(self, queryset = None):
		obj = self.request.user
		return obj


	def put(self, request, *args, **kwargs):
		"""
		Update user's info
		"""

		self.object = self.get_object()
		serializer = self.get_serializer(data = request.data)

		if serializer.is_valid():
			self.object.name = serializer.data.get("new_name")
			self.object.email = serializer.data.get("new_email")
			self.object.plan = serializer.data.get("new_plan")
			self.object.skype = serializer.data.get("new_skype")
			self.object.whatsapp = serializer.data.get("new_whatsapp")
			self.object.save()

			response = {
				'status': 'success',
				'code': status.HTTP_200_OK,
				'message': "User's info updated successfully",
				'data': []
			}

			return Response(response)

		return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)


class UserTutorialView(generics.RetrieveUpdateAPIView):
	serializer_class = UserTutorialSerializer
	queryset = UserTutorial.objects.all()


	def get_object(self):
		user_id = AccountUtils().get_user_id(self.request)
		if not user_id:
			raise PermissionDenied
		user = AccountUtils().get_user(user_id)
		obj, _ = UserTutorial.objects.get_or_create(user = user)
		return obj


	def put(self, request, *args, **kwargs):
		return self.partial_update(request, *args, **kwargs)


class RevokeTokenView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		token = str(request.META.get('HTTP_AUTHORIZATION')).split()[-1]
		user_id = AccountUtils().get_user_id(request)
		if user_id:
			blacklist = TokenBlackList(user_id = user_id, token = token)
			blacklist.save()
		auth_logout(request)
		try:
			session_auth = SocialUserSession.objects.filter(user_id = user_id).first()
			if session_auth:
				session_id = session_auth.session_key
				session_auth.delete()

				try:
					from django.contrib.sessions.models import Session
					Session.objects.get(session_key = session_id).delete()
				except Exception as e:
					pass

		except SocialUserSession.DoesNotExist:
			pass
		return Response("Token is inserted into the blacklist")


class SuccessFirstSetup(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		user.first_setup = True
		user.save()
		# if user.app_type in ['default'] and not user.bonus_plan:
		# 	AccountUtils().add_standard_subscription_plan(user)
		return HttpResponse(status = 204)


class AdminLoginByToken(generics.ListAPIView):
	permission_classes = [IsStaff]


	def get(self, request, *args, **kwargs):
		if not request.user.has_perm('accounts.add_userlogintoken'):
			return HttpResponseForbidden()
		token = random_token(32)
		user = AccountUtils().get_user(kwargs['user_id'])
		UserLoginToken.objects.create(token = token, expires_in = to_int(time.time()) + 30, user_id = kwargs['user_id'], admin_id = request.user.id)
		return redirect(get_app_url(f"accounts/login-by-token?token={token}", user))


class LoginByToken(generics.CreateAPIView):
	permission_classes = [AllowAny, ]


	def post(self, request, *args, **kwargs):
		token = kwargs['token']
		try:
			user_token = UserLoginToken.objects.get(token = token)
		except UserLoginToken.DoesNotExist:
			return HttpResponseForbidden()
		if user_token.expires_in < to_int(time.time()):
			return HttpResponseForbidden(content = 'Token not found or expired')
		user_id = user_token.user_id
		user = AccountUtils().get_user(user_id)
		if not user:
			return HttpResponseNotFound()
		refresh = TokenObtainPairSerializer.get_token(user)
		user_token.delete()
		access_token = str(refresh.access_token)
		AdminAccessToken.objects.create(admin_id = user_token.admin_id, user_id = user_id, access_token = access_token)
		admin = AccountUtils().get_user(user_token.admin_id)
		if admin.is_superuser:
			group = 'SuperAdmin'
		else:
			group = ','.join([g.name for g in admin.groups.all()]) if admin.groups.count() else ''
		data = {
			'refresh_token': str(refresh),
			'access_token': access_token,
			'group': group
		}
		return JsonResponse(data, status = status.HTTP_200_OK)


@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = ChangeInfoSerializer,
	responses = {
		status.HTTP_200_OK: "{message: Edit profile s}",
		status.HTTP_400_BAD_REQUEST: "{message: abc}"
	}
))
class ChangeInfo(generics.ListAPIView):
	serializer_class = ChangeInfoSerializer


	def put(self, request, *args, **kwargs):
		self_user = None
		try:
			self_token = request.headers['SelfToken']
			self_user = UserAccount.objects.get(pk = jwt.decode(self_token, None, None)['user_id'])
		except Exception as e:
			print(e)
			pass
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden

		serializer = self.get_serializer(data = request.data)
		user = UserAccount.objects.filter(pk = user_id).first()
		if serializer.is_valid():
			name = serializer.data.get('name')
			country = serializer.data.get('country')
			if self_user:
				self_user.name = name,
				self_user.country = country
				self_user.save()
				data = {
					"userId": self_user.id,
					"email": self_user.email,
					"name": self_user.name,
					"balance": user.balance,
					"phone": user.phone,
					"address": user.address,
					"country": self_user.country,
					"company": user.company,
					"skype": user.skype,
					"whatsapp": user.whatsapp
				}
				return JsonResponse(data = data, safe = False, status = status.HTTP_200_OK)
			user.name = serializer.data.get('name')
			user.phone = serializer.data.get('phone')
			user.address = serializer.data.get('address')
			user.country = serializer.data.get('country')
			user.company = serializer.data.get('company')
			user.skype = serializer.data.get('skype')
			user.whatsapp = serializer.data.get('whatsapp')
			user.save()
			data = {
				"userId": user.id,
				"email": user.email,
				"name": user.name,
				"balance": user.balance,
				"phone": user.phone,
				"address": user.address,
				"country": user.country,
				"company": user.company,
				"skype": user.skype,
				"whatsapp": user.whatsapp
			}
			return JsonResponse(data = data, safe = False, status = status.HTTP_200_OK)
		else:
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)


class PlanHistory(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)

		if not user_id:
			return HttpResponseForbidden()

		plan_history = AccountUtils().plan_history(AccountUtils().get_user_by_request(request))
		return JsonResponse(data = plan_history, safe = False)


class AccountsSocialInactive(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		message = PopupResponse(data = {'status': 'inactive'})
		return render(request, 'popup.html', {'data': message.to_json()})


class TestApi(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		notify_user()
		return JsonResponse({})


class RefreshApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		if user:
			user.last_access = datetime.now()
			user.save()
		return HttpResponse(status = 204)
class Refresh2ApiView(generics.CreateAPIView):
	permission_classes = [AllowAny]
	authentication_classes = []
	def post(self, request, *args, **kwargs):
		test_key = to_int(request.GET.get('test_key', 1))
		if test_key == 1:
			return HttpResponse(status = 204)
		if test_key == 2:
			UserAccount.objects.filter(id = 177).update(last_access = datetime.now())
		if test_key == 3:
			user = AccountUtils().get_user_by_request(request)
			if user:
				user.last_access = datetime.now()
				user.save()
		return HttpResponse(status = 204)

class HideGuideApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		if user:
			user.show_guide = False
			user.save()
		return HttpResponse(status = 204)


class CloseAccountApiView(generics.ListCreateAPIView):
	permission_classes = [IsGetOrIsAuthenticated]


	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		data = request.data
		if not data.get('email'):
			return JsonResponse(ErrorResponse(errors = "Email is empty").to_dict(), status = 400)
		if data['email'] != user.email:
			return JsonResponse(ErrorResponse(errors = "Email is not match").to_dict(), status = 400)
		token = random_token()
		CloseAccount.objects.create(user_id = user.id, token = token, expired_in = to_int(time.time()) + 60 * 15)
		url = get_app_url("close-account", user) + f"/{token}"
		default_channel = ChannelUtils().get_default_channel(user.id)
		context = {
			"close_account_url": url,
			"mainstore": default_channel.url if default_channel else ''
		}
		user.send_email_template('close-account', context)
		return HttpResponse(status = 204)


	def get(self, request, *args, **kwargs):
		token = kwargs.get('token')
		if not token:
			return HttpResponseNotFound()
		try:
			auth_token = CloseAccount.objects.get(token = token)
		except Exception:
			log_traceback()
			return JsonResponse(ErrorResponse(errors = 'Token not found').to_dict(), status = 400)
		if auth_token.expired_in < to_int(time.time()):
			return JsonResponse(ErrorResponse(errors = 'Token expired').to_dict(), status = 400)
		user_id = auth_token.user_id
		AccountUtils().close_account(user_id, user_close = True)
		auth_token.delete()
		return HttpResponse(status = 204)


class CloseContactPopupApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		user.contact_popup += 1
		user.save()
		return HttpResponse(status = 204)


class SkipSetupChannelApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = request.user
		user.skip_setup_channel = True
		user.save()
		return HttpResponse(status = 204)


class SwitchChannelApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = request.user
		if user.first_setup:
			return HttpResponseForbidden()
		channels = list(Channel.objects.filter(user_id = user.id))
		if len(channels) != 2:
			return HttpResponseForbidden()

		mainstore = False
		channel = False
		for row in channels:
			if row.default:
				mainstore = row
			else:
				channel = row
		if not mainstore or not channel or mainstore.is_shopping_cart() or not channel.is_shopping_cart():
			return HttpResponseForbidden()

		model_catalog = ProductUtils().get_model_catalog(user_id = user.id)
		product_in_mainstore = model_catalog.count(model_catalog.create_where_condition(f'channel.channel_{mainstore.id}.status', 'active'))
		if product_in_mainstore:
			return HttpResponseForbidden()

		product_in_channel = model_catalog.count(model_catalog.create_where_condition(f'channel.channel_{channel.id}.status', 'active'))
		if product_in_channel:
			return HttpResponseForbidden()
		channel.default = True
		channel.save()
		mainstore.default = False
		mainstore.name = str(mainstore.type).capitalize()
		mainstore.save()
		processes_mainstore = Process.objects.filter(channel_id = mainstore.id).values('state_id')
		model_state = State()
		model_state.set_user_id(user.id)
		model_state.update_many(model_state.create_where_condition('_id', processes_mainstore, 'in'), {
			'channel.default': False,
			'channel.name': str(mainstore.type).capitalize()
		})
		processes_channel = Process.objects.filter(channel_id = channel.id).values('state_id')

		model_state.update_many(model_state.create_where_condition('_id', processes_channel, 'in'), {
			'channel.default': True,
		})
		return HttpResponse(status = 204)


class AdminCloseAccount(TemplateView):
	def get(self, request, *args, **kwargs):
		user_id = kwargs['user_id']
		AccountUtils().close_account(user_id)
		return redirect(get_full_absolute_uri('admin:accounts_useraccount_change', {'object_id': user_id}))


class CancelSubscription(generics.CreateAPIView):
	def cancel_paypal_subscription(self, user, subscription_id):
		paypal_api = PaypalApi()
		return paypal_api.cancel_subscription(subscription_id)


	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		user_id = AccountUtils().get_user_id(request)
		plan = SubscriptionUtils().get_plan_by_user(AccountUtils().get_user_by_request(request))
		user_plan = plan['user_plan']
		cancel = False
		if user_plan.get('paypal_subscription_id'):
			cancel = self.cancel_paypal_subscription(user, user_plan.get('paypal_subscription_id'))
		else:
			channel = ChannelUtils().get_default_channel(user_id = user_id)
			if channel.type != 'shopify':
				return HttpResponse(status = 403)
			charge = get_object_or_404(ShopifyCharge, user_id = user_id)
			api = ShopifyApi(channel = channel)
			cancel = api.cancel_subscription(charge.charge_id, user, user_plan)
		if cancel:

			if user_plan and user_plan.get('yearly_paid'):
				pricing = f'{plan["yearly_fee"]}/Year'
			else:
				pricing = f'{plan["monthly_fee"]}/Month'

			context = {
				'plan_name': plan['name'],
				'pricing': pricing

			}
			user.send_email_template('subscription-canceled', context)
			UserSubscription.objects.filter(user_id = user_id).update(auto_renew = False)
		return HttpResponse(status = 204)


@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = UserHaveIssueSerializer,
	responses = {
		status.HTTP_200_OK: "{ticket_id: 123}",
		status.HTTP_400_BAD_REQUEST: "{message: abc}"
	}
))
class UserHaveIssue(generics.CreateAPIView):
	MIDDLEWARE_CLASSES = (CaptchaMiddleware.NAME,)


	def get_section(self, section: str):
		sections = {
			'product': 'Products',
			'feature': 'Feature request'
		}
		return sections.get(section, section.capitalize())


	def post(self, request, *args, **kwargs):
		serializer = UserHaveIssueSerializer(data = request.data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		skype = request.data.get('skype')
		whatsapp = request.data.get('whatsapp')
		need_save = False
		if skype and not self.request.user.skype:
			self.request.user.skype = skype
			need_save = True
		if whatsapp and not self.request.user.whatsapp:
			self.request.user.whatsapp = whatsapp
			need_save = True
		if need_save:
			self.request.user.save()
		feature_request = None
		if request.data.get('section') == 'feature':
			feature_request = FeatureRequest.objects.create(
				skype = request.data.get('skype'),
				whatsapp = request.data.get('whatsapp'),
				description = request.data.get('description'),
				user_id = AccountUtils().get_user_id(request),
			)
		comment = request.data
		if comment.get('description'):
			comment['description'] = strip_html_from_description(comment['description'])
		comment['section'] = self.get_section(comment['section'])
		if 'g-recaptcha-response' in comment:
			del comment['g-recaptcha-response']
		comment_msg = "\n".join([f"{field.capitalize()}: {value}" for field, value in comment.items()])
		ticket_data = {
			'subject': f"LitCommerce: {request.user.email} issue",
			'comment': comment_msg,
		}
		ticket_id = CoreUtils().create_ticket_zendesk(request.user, **ticket_data)
		if ticket_id and feature_request:
			feature_request.ticket_id = ticket_id
			feature_request.save()
		return JsonResponse({'ticket_id': ticket_id})


class FeedbackCloseApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		user.feedback_closed_at = datetime.today()
		user.feedback_number_close += 1
		user.save()
		return HttpResponse(status = 204)


class TotalProductApiViews(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		total = 0
		channels = Channel.objects.filter(user_id = user_id, default = False, deleted_at__isnull = True)
		for channel in channels:
			channel_number_products = json_decode(channel.channel_number_products)
			if not channel_number_products:
				continue
			total += sum(list(map(lambda x: to_int(x), list(channel_number_products.values()))))
		return JsonResponse({'total': total})


class ProcessApiView(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		model_process = CollectionProcess()
		model_process.set_user_id(user_id)
		processes = model_process.find_all({}, limit = 100)
		if not processes:
			UserAccount.objects.filter(id = user_id).update(have_process = False)

		return JsonResponse(processes, safe = False)


class OfferFreeMonth(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)
		subscription = UserSubscription.objects.filter(user_id = user.id).exclude(plan_id = 1).first()
		data = {
			'user_id': user.id,
			'status': 'failure',
			'plan_id': 3
		}
		created = True
		if subscription:
			created = False
			# return JsonResponse(ErrorResponse(errors = "Your account is not eligible for the one-month free plan.").to_dict(), status = 400)
		if created:
			subscription_history = UserSubscriptionHistory.objects.filter(user_id = user.id).exclude(new_plan_id = 1).first()
			if subscription_history:
				created = False
		if not created:
			UserOfferMonth.objects.create(**data)
			return JsonResponse(ErrorResponse(errors = "Your account is not eligible for the one-month free plan.").to_dict(), status = 400)
		UserSubscription.objects.filter(user_id = user.id).delete()
		started_at = datetime.today()
		expired_at = started_at + dateutil.relativedelta.relativedelta(days = 30)
		UserSubscription.objects.create(
			plan_id = 3,
			user_id = user.id,
			started_at = started_at,
			expired_at = expired_at,
			yearly_paid = False,
			auto_renew = False
		)
		data['started_at'] = started_at.strftime('%Y-%m-%d')
		data['expired_in'] = expired_at.strftime('%Y-%m-%d')
		data['status'] = 'success'
		UserOfferMonth.objects.create(**data)
		user.is_trial = True
		user.save()
		user.send_email_template('1-month-trial')
		return HttpResponse(status = 204)