import time

from accounts.models import UserActionToken
from libs.utils import json_encode, random_token, to_int, json_decode


class UserActionTokenUtils:
	def create(self, user_id, action, meta_data):
		kwargs = dict(
			user_id = user_id,
			action = action,
			expired_in = to_int(time.time()) + 60
		)
		if meta_data:
			kwargs['meta_data'] = json_encode(meta_data)
		token = f"{to_int(time.time())}-{random_token()}"
		kwargs['token'] = token
		UserActionToken.objects.create(**kwargs)
		return token


	def get(self, token, action):
		try:
			auth_token = UserActionToken.objects.get(token = token, action = action)
		except Exception:
			return False, False
		# if auth_token.expired_in < to_int(time.time()):
		# 	return False,False
		meta_data = auth_token.meta_data
		if meta_data:
			meta_data = json_decode(meta_data)
		return auth_token.user, meta_data