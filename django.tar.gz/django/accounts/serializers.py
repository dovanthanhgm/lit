""" This module is to validate input values """
import time
import json
import jwt

from django.contrib.auth import get_user_model, authenticate
from rest_framework import serializers, exceptions
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from accounts.models import UserAccount
from accounts.utils import AccountUtils
from libs.utils import to_int, get_private_key
from .models import UserTutorial

User = get_user_model()


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
	def validate(self, attrs):
		authenticate_kwargs = {
			self.username_field: attrs[self.username_field],
			'password': attrs['password'],
		}
		try:
			authenticate_kwargs['request'] = self.context['request']
		except KeyError:
			pass
		self.user = authenticate(**authenticate_kwargs)
		if self.user is None:
			raise exceptions.AuthenticationFailed(
				self.error_messages['no_active_account'],
				'no_active_account',
			)
		if not self.user.is_active:
			raise exceptions.PermissionDenied(
				'Account might not be activated.',
				'inactive_account',
			)
		
		data = dict()
		
		if self.user.parent_user_id:
			private_key = get_private_key()
			parent = User.objects.filter(id=self.user.parent_user_id)[0]
			refresh = self.get_token(parent)
			data['refresh'] = str(refresh)
			data['access'] = str(refresh.access_token)
			self_refresh = self.get_token(self.user)
			data['selfToken'] = str(self_refresh.access_token)
			try:
				permissions = self.user.permissions.replace("'",'"')
				data['permissions'] = jwt.encode(json.loads(permissions), private_key, algorithm = 'HS256')
			except Exception as e:
				data['permissions'] = ""
				pass
		else:
			refresh = self.get_token(self.user)
			data['refresh'] = str(refresh)
			data['access'] = str(refresh.access_token)
			
		# Add extra responses here
		data['user'] = {}
		data['user']['name'] = self.user.name
		data['user']['email'] = self.user.email
		return data


# class ChangePasswordSerializer(serializers.Serializer):
# 	"""
# 	Serializer for password change endpoint.
# 	"""
# 	model = UserAccount
# 	old_password = serializers.CharField(required = True)
# 	new_password = serializers.CharField(required = True)


class ChangePasswordSerializer(serializers.Serializer):
	old_password = serializers.CharField(required = True)
	new_password = serializers.CharField(required = True, min_length = 8)


class ChangeInfoSerializer(serializers.Serializer):
	"""
	Serializer for user's info change endpoint.
	"""
	name = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True)
	phone = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True)
	address = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True)
	country = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True)
	company = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True)
	skype = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True, required = False)
	whatsapp = serializers.CharField(max_length = 255, allow_null = True, allow_blank = True, required = False)
	total_product = serializers.IntegerField(allow_null = True, required = False)
	repeat_scheduler = serializers.IntegerField(allow_null = True, required = False)


class UserTutorialSerializer(serializers.ModelSerializer):
	class Meta:
		model = UserTutorial
		exclude = ['id', 'user']


	def validate(self, attrs):
		attrs = {key: value for key, value in attrs.items() if value}
		return attrs


class ChangeInfoResponseSerializer(serializers.Serializer):
	email = serializers.CharField()
	name = serializers.CharField()
	balance = serializers.DecimalField(max_digits = 12, decimal_places = 2)
	created_at = serializers.DateTimeField()
	plan = serializers.CharField()
	is_active = serializers.BooleanField()
	is_staff = serializers.BooleanField()
	token = serializers.CharField()
	phone = serializers.CharField()
	address = serializers.CharField()
	country = serializers.CharField()
	company = serializers.CharField()
	skype = serializers.CharField()
	whatsapp = serializers.CharField()


class AccountSerializer(serializers.ModelSerializer):
	password2 = serializers.CharField()


	class Meta:
		model = UserAccount
		fields = ['email', 'name', 'password', 'password2', 'app_type', 'skype', 'whatsapp', 'permissions', 'market_app']


	def validate_password(self, value):
		if len(value) < 6:
			raise serializers.ValidationError('Password must be at least 6 characters')
		return value


	def validate(self, data):
		if data['password2'] != data['password']:
			raise serializers.ValidationError({'password2': 'Confirm password must match.'})
		return data

class SubAccountSerializer(serializers.ModelSerializer):

	class Meta:
		model = UserAccount
		fields = ['id', 'email', 'name', 'password', 'app_type', 'skype', 'whatsapp', 'permissions', 'is_active', 'created_at']

class SendResetPasswordEmailSerializer(serializers.Serializer):
	email = serializers.EmailField()


	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		self._user = None


	def get_user(self):
		return self._user


	def validate_email(self, value):
		user = AccountUtils().get_user_by_email(value)
		if not user:
			raise serializers.ValidationError(f"Email {value} doesn't exist.")
		self._user = user
		return value


class RegisterEmailSerializer(SendResetPasswordEmailSerializer):
	token = serializers.CharField()


	def validate(self, data):
		user_token = AccountUtils().get_user_token(token = data['token'])
		if not user_token or user_token.expires_in < to_int(time.time()) or user_token.user.email != data['email']:
			raise serializers.ValidationError({'token': 'Invalid or expired token'})
		return data


class ResendRegisterEmailSerializer(SendResetPasswordEmailSerializer):
	def validate_email(self, value):
		value = super().validate_email(value)
		user = self._user
		if user.is_active:
			raise serializers.ValidationError(f"User {value} is active.")
		return value


class ResetPasswordSerializer(serializers.Serializer):
	email = serializers.EmailField()
	token = serializers.CharField()
	new_password = serializers.CharField()


	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		self._user = None


	def validate(self, data):
		user_token = AccountUtils().get_user_token(token = data['token'], delete = False)
		if not user_token:
			raise serializers.ValidationError({'token': 'Invalid token.'})
		if user_token.user.email != data['email']:
			raise serializers.ValidationError({'email': 'Invalid email.'})
		if user_token.expires_in < to_int(time.time()):
			user_token.delete()
			raise serializers.ValidationError({'token': 'Expired token.'})
		user_token.delete()
		self._user = user_token.user
		return data


	def reset_password(self):
		data = self.validated_data
		self._user.reset_password(data['new_password'], mail = True)
		return True


class UserHaveIssueSerializer(serializers.Serializer):
	description = serializers.CharField()
	section = serializers.ChoiceField(choices = (('product', "Products"), ('template', "Template & Recipes"), ('orders', "Orders"), ('settings', "Settings"), ('pricing', "Pricing"), ('feature', "Feature request"), ('other', "Other"), ('issues', 'Issues/Bugs')))
	skype = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	whatsapp = serializers.CharField(required = False, allow_null = True, allow_blank = True)