import time
from decimal import Decimal

from django.contrib.auth.models import (
	AbstractBaseUser, PermissionsMixin,
	BaseUserManager
)
from django.core.validators import MinValueValidator
from django.db import models

from core.utils import CoreUtils
from email_templates.utils import EmailTemplateUtils
from libs.utils import random_token, to_int, get_config_ini
from servers.models import Server


class UserAccountManager(BaseUserManager):
	def create_user(self, email, name = '', password = None, send_mail = False, **kwargs):
		if not email:
			raise ValueError('Users must have an email address')
		if not name:
			name = str(email).split("@")[0]

		email = self.normalize_email(email)
		token = random_token(length = 32).lower()
		user = self.model(email = email, name = name, token = token, **kwargs)

		user.set_password(password)
		user.save()
		if not user.parent_user_id:
			if kwargs.get('is_active') is False:
				user.send_email_template('register')
			else:
				user.send_email_template('welcome')

		return user


	def create_superuser(self, email, name, password):
		user = self.create_user(email, name, password)
		user.is_superuser = True
		user.is_staff = True
		user.is_active = True
		user.save()

		return user


class UserAccount(AbstractBaseUser, PermissionsMixin):
	"""
	This model is used instead of default User of django
	"""
	CHANNEL_TYPE_OPTION = (
		('etsy', 'Etsy'),
		('facebook', 'Facebook'),
		('google', 'Google'),
		('amazon', 'Amazon'),
		('ebay', 'Ebay'),
	)
	email = models.EmailField(max_length = 255, unique = True, null = False)
	contact_email = models.EmailField(max_length = 255, unique = False, null = True)
	name = models.CharField(max_length = 255, null = True)
	balance = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, validators = [MinValueValidator(Decimal('0.0'))], default = Decimal('0.0'))
	created_at = models.DateTimeField(auto_now_add = True)
	is_active = models.BooleanField(default = True)
	is_staff = models.BooleanField(default = False)
	is_trial = models.BooleanField(default = False)
	tried_it = models.BooleanField(default = False)
	is_expired = models.BooleanField(default = False)
	show_guide = models.BooleanField(default = True)
	enable_bulk_edit = models.BooleanField(default = False)
	support_amazon = models.BooleanField(default = False)
	skip_setup_channel = models.BooleanField(default = False)
	token = models.CharField(max_length = 255, null = False, blank = True, default = '')
	phone = models.CharField(max_length = 255, null = True, blank = True, default = '')
	address = models.CharField(max_length = 255, null = True, blank = True, default = '')
	country = models.CharField(max_length = 255, null = True, blank = True, default = '')
	company = models.CharField(max_length = 255, null = True, blank = True, default = '')
	skype = models.CharField(max_length = 255, null = True, blank = True, default = '')
	whatsapp = models.CharField(max_length = 255, null = True, blank = True, default = '')
	app_type = models.CharField(max_length = 25, null = False, blank = False, default = 'default', choices = (('default', 'Default'), ('mss', 'MSS'), ('cis', 'Center Inventory Sync')))
	market_app = models.CharField(max_length = 255, null = True, blank = True, default = 'litc', choices = (("litc", "LitC"), ('shopify', 'Shopify'), ('bigcommerce', 'BigCommerce'), ('wix', 'Wix'), ('squarespace', 'SquareSpace'), ('woocommerce', 'Woocommerce')))
	channel_app = models.CharField(max_length = 255, null = True, blank = True, default = '', choices = CHANNEL_TYPE_OPTION)
	first_setup = models.BooleanField(default = False)
	first_social_login = models.BooleanField(default = False)
	bonus_plan = models.BooleanField(default = False)
	feedback = models.BooleanField(default = False)
	feedback_number_close = models.IntegerField(default = 0)
	feedback_closed_at = models.DateField(null = True, blank = True)
	contact_popup = models.IntegerField(null = False, default = 0)
	announcements_latest_read_at = models.DateTimeField(auto_now_add = False)
	repeat_scheduler = models.IntegerField(null = True, blank = True)
	last_access = models.DateTimeField(null = True, blank = True, auto_now_add = False)
	server = models.ForeignKey(Server, on_delete = models.SET_NULL, blank = True, null = True)
	total_product = models.IntegerField(null = False, default = 0)
	objects = UserAccountManager()
	parent_user_id = models.IntegerField(null = True)
	permissions = models.CharField(max_length = 255, null = True, blank = True, default = '')
	solve_delete_free_data = models.BooleanField(default = False)
	solve_delete_expired_data_1 = models.BooleanField(default = False)
	solve_delete_expired_data_2 = models.BooleanField(default = False)
	delete_all_data_in = models.DateField(null = True, blank = True)
	delete_unlisted_data_in = models.DateField(null = True, blank = True)
	duration_paid = models.IntegerField(null = True, blank = True)
	have_process = models.BooleanField(null = True, default = False)
	USERNAME_FIELD = 'email'
	REQUIRED_FIELDS = ['name']


	class Meta:
		db_table = 'user'
		permissions = (("view_dashboard", "View Dashboard"),)


	def get_full_name(self):
		return self.name


	def __str__(self):
		return self.email


	def reset_password(self, password, mail = True):
		self.set_password(password)
		self.save()
		if mail:
			self.send_email_template('reset_password', extra_context = {'password': password})
		return True


	def set_active(self, mail = False):
		self.is_active = True
		self.save()
		if mail:
			self.send_email_template('welcome')
		return True


	def generate_user_token(self, limit_time = 3600):
		expires_in = to_int(time.time()) + limit_time
		token = random_token(length = 32)
		user_token = UserToken.objects.create(user = self, token = token, expires_in = expires_in)
		return user_token


	@property
	def register_url(self):
		user_token = self.generate_user_token(limit_time = 86400)
		domain_app = get_config_ini('server', 'react_domain', 'http://localhost:3000').strip('/')
		absolute_uri = f'{domain_app}/verify/email={self.email}&token={user_token.token}'
		return absolute_uri


	@property
	def reset_password_url(self):
		user_token = self.generate_user_token(limit_time = 86400)
		domain_app = get_config_ini('server', 'react_domain', 'http://localhost:3000').strip('/')
		absolute_uri = f'{domain_app}/reset-password/{user_token.token}'
		return absolute_uri


	def send_email_template(self, template_code, extra_context = {}):
		email_template = EmailTemplateUtils().get_email_template_by_code(template_code)
		if not email_template:
			return
		context = {'user': self}
		context.update(extra_context)
		recipient = self.email
		if self.contact_email:
			recipient = self.contact_email
		email_template.send_mail(recipient_list = recipient, context = context)
		return True


	def save(self, *args, **kwargs):
		super(UserAccount, self).save(*args, **kwargs)
		if self.repeat_scheduler:
			CoreUtils().update_sync_frequency(self, self.repeat_scheduler)


class UserTutorial(models.Model):
	user = models.OneToOneField(UserAccount, related_name = 'tutorials', on_delete = models.CASCADE)
	create_listing_tutorial = models.BooleanField(default = False)
	enable_inventory_sync_tutorial = models.BooleanField(default = False)
	fulfill_order_tutorial = models.BooleanField(default = False)


class UserToken(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	token = models.TextField(null = False)
	expires_in = models.IntegerField(null = False)


	class Meta:
		db_table = 'user_token'


class TokenBlackList(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	token = models.TextField(null = False)


	class Meta:
		db_table = 'user_token_blacklist'


class TokenMetaData(models.Model):
	token = models.TextField(null = False)
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	meta_data = models.TextField(null = True)


	class Meta:
		db_table = 'user_token_meta_data'


class UserLoginToken(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	token = models.CharField(null = False, max_length = 64)
	expires_in = models.IntegerField(null = False)
	admin = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True, related_name = 'admin_id')


	class Meta:
		db_table = 'user_login_token'


class AdminAccessToken(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	access_token = models.TextField(null = False)
	admin = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True, related_name = 'admin_access_token_id')


class SocialUserSession(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	session_key = models.TextField(null = True)


class CloseAccount(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	token = models.TextField(null = False)
	expired_in = models.IntegerField(null = False)


class UserActionToken(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	token = models.TextField(null = False)
	expired_in = models.IntegerField(null = False)
	meta_data = models.TextField(null = True, blank = True)
	action = models.CharField(choices = (('export_variant', 'Export Variant'),), max_length = 125)


	class Meta:
		db_table = 'user_action_token'


class UserOfferMonth(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	plan_id = models.IntegerField(null = True)
	started_at = models.DateField(null = True)
	expired_in = models.DateField(null = True)
	status = models.CharField(choices = (('success', 'Success'), ('failure', 'Failure')), default = 'failure', max_length = 25)


	class Meta:
		db_table = 'user_offer_month_trial'
