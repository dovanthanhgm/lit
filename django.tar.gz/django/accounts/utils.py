import time
from datetime import datetime

import dateutil.relativedelta
import jwt
import requests
from django.shortcuts import get_object_or_404

from accounts.models import UserAccount, UserToken, TokenMetaData
from channel_templates.utils import ChannelTemplateUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from core.authentication import PrivateKeyAuthentication
from libs.models.collections.activities import Activities
from libs.models.collections.attributes import Attributes
from libs.models.collections.catalog import Catalog
from libs.models.collections.category import Category
from libs.models.collections.order import CollectionOrder
from libs.models.collections.state import State
from libs.utils import get_config_ini, to_int, is_local, to_str, json_decode, get_client_ip, json_encode, log_traceback
from merchant.shopify.models import ShopifyCharge
from settings.utils import SettingUtils
from subscription.models import UserSubscription, UserSubscriptionHistory
from subscription.utils import SubscriptionUtils
from user_action_logs.utils import UserActionLogUtils


class AccountUtils:
	def get_user_id(self, request):
		user_id_default = False
		if is_local():
			user_id_default = to_int(get_config_ini('server', 'customer_default_id', 1))
		user_id = self.get_user_id_by_jwt(request)
		if user_id:
			return to_int(user_id)
		user_id = self.get_user_id_by_private_key(request)
		if user_id:
			return to_int(user_id)
		return False


	def get_user_id_by_jwt(self, request):
		token = str(request.META.get('HTTP_AUTHORIZATION')).split()[-1]
		try:
			token_data = jwt.decode(token, None, None)
			user_id = token_data['user_id']
			return user_id
		except Exception as e:
			return False


	def get_user_id_by_private_key(self, request):
		return PrivateKeyAuthentication().get_user_id(request)


	def get_user(self, user_id):
		try:
			user = UserAccount.objects.get(pk = user_id)
		except UserAccount.DoesNotExist as e:
			return False
		return user


	def get_user_by_request(self, request):
		try:
			if request.user and not request.user.is_anonymous:
				return request.user
		except Exception as e:
			pass
		user_id = self.get_user_id(request)
		if not user_id:
			return False
		try:
			user = UserAccount.objects.get(pk = user_id)
		except UserAccount.DoesNotExist as e:
			return False
		request.user = user
		return user


	@staticmethod
	def get_user_token(token, delete = True):
		try:
			user_token = UserToken.objects.get(token = token)
			if delete:
				user_token.delete()
			return user_token
		except UserToken.DoesNotExist:
			return None


	@staticmethod
	def get_user_by_token(token):
		user = None
		try:
			user_token = UserToken.objects.get(token = token)
			if user_token.expires_in >= to_int(time.time()):
				user = user_token.user
			user_token.delete()
		except UserToken.DoesNotExist:
			pass
		return user


	@staticmethod
	def get_user_by_email(email):
		try:
			user = UserAccount.objects.get(email = email)
			return user
		except UserAccount.DoesNotExist:
			return None


	def get_step(self, user):
		def step_three(first_channel, user):
			return ''
			if not user.skip_setup_channel and not first_channel.first_setting:
				return 'setting'
			else:
				user_plan = SubscriptionUtils().get_plan_by_user(user)
				if user_plan['default']:
					return 3
				user.first_setup = True
				user.save()
				return ''


		if user.first_setup:
			return ''
		if not ChannelUtils().get_default_channel(user.id):
			return 1
		first_channel = False
		if not user.skip_setup_channel:
			first_channel = ChannelUtils().get_first_channel(user.id)
			if not first_channel:
				return 2
			channel_template_utils = ChannelTemplateUtils(channel_id = first_channel.id, channel_type = first_channel.type, user_id = user.id)
			template_type = channel_template_utils.get_required_template(first_channel.type)
			if not template_type:
				return step_three(first_channel, user)
			else:
				templates = channel_template_utils.get_templates()
				if not templates:
					return 2.1
				for index, row in enumerate(template_type):
					for template in templates:
						if template['type'] == row:
							break
					else:
						return f"2.{index + 1}"
		return step_three(first_channel, user)


	def create_new_email(self, email):
		email_exp = email.split('@')
		email_name = email_exp[0]
		index = 1
		new_email = email
		try:
			user = UserAccount.objects.get(email = new_email)
		except UserAccount.DoesNotExist:
			user = False
		while user:
			index += 1
			new_email = f"{email_name}_{index}@{email_exp[1]}"
			try:
				user = UserAccount.objects.get(email = new_email)
			except UserAccount.DoesNotExist:
				user = False
		return new_email


	def allow_free_plan(self):
		if to_int(SettingUtils().get_setting('offer_free_plan')) != 1:
			return False, False
		offer_ends = SettingUtils().get_setting('offer_ends')
		if offer_ends:
			try:
				offer_ends = datetime.strptime(str(offer_ends), "%Y-%m-%d").time()
				if offer_ends < datetime.now():
					return False, False
			except Exception:
				pass
		free_month = to_int(SettingUtils().get_setting('offer_months'))
		if not free_month:
			return False, False
		plan_id = to_int(SettingUtils().get_setting('offer_plan'))
		if not plan_id:
			return False, False
		return free_month, plan_id


	def add_standard_subscription_plan(self, user):
		user.bonus_plan = True
		user.save()
		free_month, plan_id = self.allow_free_plan()
		if user.market_app or not free_month:
			return
		start_time = datetime.now()
		expired_time = start_time + dateutil.relativedelta.relativedelta(months = free_month)
		user_plan = UserSubscription.objects.create(user_id = user.id, plan_id = plan_id, plan_paid_id = plan_id, started_at = start_time.strftime("%Y-%m-%d %H:%M:%S"), expired_at = expired_time.strftime("%Y-%m-%d %H:%M:%S"), yearly_paid = 0)
		subscription_plan = SubscriptionUtils().get_plan_by_user(user)

		if not subscription_plan['default']:
			history_data = {
				'user_id': user.id,
				'new_plan_id': user_plan.plan_id,
				'new_plan_started_at': start_time.strftime("%Y-%m-%d %H:%M:%S"),
				'new_plan_expired_at': expired_time.strftime("%Y-%m-%d %H:%M:%S"),
				'new_plan_yearly_paid': 0,
				'old_plan_id': subscription_plan['id'],
				'old_plan_started_at': subscription_plan['started_at'],
				'old_plan_expired_at': subscription_plan['expired_at'],
				'old_plan_yearly_paid': subscription_plan['yearly_paid'],
			}
			UserSubscriptionHistory.objects.create(**history_data)


	def get_meta_data(self, request):
		token = to_str(request.META.get('HTTP_AUTHORIZATION')).split()[-1]
		try:
			meta_data = TokenMetaData.objects.get(token = token)
		except TokenMetaData.DoesNotExist:
			return {}
		data = json_decode(meta_data.meta_data)
		if not data:
			data = {}
		return data


	def get_user_country(self, request):
		ip_address = get_client_ip(request)
		if not ip_address or ip_address == '127.0.0.1' or ip_address == '127.0.1.1':
			return False
		url = f"http://ipinfo.io/{ip_address}"
		params = {}
		if get_config_ini('server', 'ipinfo_token'):
			params['token'] = get_config_ini('server', 'ipinfo_token')
		try:
			ip_info = requests.get(url).json()
			return ip_info['country']
		except Exception:
			return False


	def plan_history(self, user):
		user_id = user.id
		plan = UserSubscription.objects.filter(user_id = user_id).first()
		if not plan:
			start_at = UserAccount.objects.filter(pk = user_id).first().created_at
		else:
			start_at = plan.started_at

		now = datetime.now()
		t = (now.year - start_at.year) * 12 + now.month - start_at.month
		from dateutil import relativedelta
		if t > 0:
			start_at = start_at + relativedelta.relativedelta(months = t)
			if start_at.day > now.day:
				start_at = start_at - relativedelta.relativedelta(months = 1)
		from products.utils import ProductUtils
		product_utils = ProductUtils(user_id = user_id)
		products = user.total_product
		# model_order = product_utils.get_model_order(user_id = user_id)
		# orders = model_order.count(model_order.create_where_condition("imported_at", start_at.strftime('%Y-%m-%d %H:%M:%S'), ">="))
		#
		start_date = f'{start_at.strftime("%B %d")}'
		end_date = f'{(start_at + relativedelta.relativedelta(months = 1)).strftime("%B %d")}'

		return {
			"total_products": products,
			"total_orders": 0,
			"time": f"{start_date} - {end_date}"
		}


	def close_account(self, user_id, user_close = False):
		from channels.models import Channel
		if user_close:
			try:
				channels = Channel.objects.filter(user_id = user_id)
				for channel in channels:
					try:
						export_channel = ChannelUtils().export_channel(channel)
					except:
						export_channel = ''
					UserActionLogUtils().create_log(user_id, channel.id, 'delete_channel', data = export_channel)
			except:
				log_traceback()
		Channel.objects.filter(user_id = user_id).delete()
		model_delete = [Catalog(), CollectionOrder(), State(), Activities(), Category(), Attributes()]
		for model in model_delete:
			model.set_user_id(user_id)
			model.delete_all()
		user = self.get_user(user_id)
		if user:
			user.first_setup = 0
			user.save()
		return True

	def is_paid_user(self, user):
		plan = SubscriptionUtils().get_plan_by_user(user)
		if to_int(plan.get('id')) != 1 and not plan.get('expired'):
			return True
		return False


	def user_expired(self, user, set_expired = True):
		model_state = State()
		model_state.set_user_id(user.id)
		channels = Channel.objects.filter(user_id = user.id)
		for channel in channels:
			if channel.default:
				ChannelUtils().disable_refresh_sync(channel.id, channel)
				ChannelUtils().delete_webhook(channel)
				continue
			new_settings = {
				'price': {'status': 'disable'},
				'qty': {'status': 'disable'},
				'order': {'status': 'disable'},
			}
			pre_settings = channel.settings
			ChannelUtils().setting_for_channel(channel, new_settings)
			channel.settings = json_encode(new_settings)
			channel.previous_settings = pre_settings

			channel.save()
		if set_expired:
			user.is_expired = True
			user.save()

	def cancel_paypal_subscription(self, user, subscription_id):
		from payments.paypal_api import PaypalApi
		paypal_api = PaypalApi()
		return paypal_api.cancel_subscription(subscription_id)
	def cancel_subscriptions(self, user):
		user_id = user.id
		plan = SubscriptionUtils().get_plan_by_user(user)
		user_plan = plan['user_plan']
		cancel = False
		if user_plan.get('paypal_subscription_id'):
			cancel = self.cancel_paypal_subscription(user, user_plan.get('paypal_subscription_id'))
		else:
			channel = ChannelUtils().get_default_channel(user_id = user_id)
			if channel.type != 'shopify':
				return False
			charge = get_object_or_404(ShopifyCharge, user_id = user_id)
			from merchant.shopify.api import ShopifyApi
			api = ShopifyApi(channel = channel)
			cancel = api.cancel_subscription(charge.charge_id, user, user_plan)
		if cancel:
			if user_plan and user_plan.get('yearly_paid'):
				pricing = f'{plan["yearly_fee"]}/Year'
			else:
				pricing = f'{plan["monthly_fee"]}/Month'

			context = {
				'plan_name': plan['name'],
				'pricing': pricing

			}
			user.send_email_template('subscription-canceled', context)
			UserSubscription.objects.filter(user_id = user_id).update(auto_renew = False)