from datetime import datetime

from background_task.models import Task
from dateutil.utils import today
from django import forms
from django.conf.locale.en import formats as en_formats
from django.contrib import admin, messages
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.auth.models import Permission
from django.core.exceptions import ValidationError
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.shortcuts import redirect
from django.template.loader import render_to_string
from django.urls import path, resolve, reverse
from django.utils.html import format_html
from django.utils.translation import ngettext
from rest_framework_simplejwt.token_blacklist.admin import OutstandingTokenAdmin
from rest_framework_simplejwt.token_blacklist.models import OutstandingToken

from accounts.models import *
from accounts.views import AdminCloseAccount
from channels.models import Channel, choices_channel, choices_mainstore
from channels.utils import ChannelUtils
from channels.views import ChannelImportView
from core.myadmin.admin import CoreAdmin, InputFilter, NameFilter, SelectBoxFilter
from datasync.api.sync import SyncApi
from libs.models.collections.state import State
from libs.utils import random_token, to_int, get_app_url, get_full_absolute_uri, get_current_time, log, is_local, json_decode
from processes.admin import UserFilter
from processes.models import Process
from subscription.models import UserSubscription, UserSubscriptionHistory, Subscription


@admin.register(Permission)
class PermissionAdmin(CoreAdmin):
	search_fields = ['name', 'codename']


	def get_queryset(self, request):
		qs = super().get_queryset(request)
		return qs.select_related('content_type')


class EmailFilter(InputFilter):
	parameter_name = 'email'
	title = ('email')


	def queryset(self, request, queryset):
		if self.value() is not None:
			email = self.value()
			return queryset.filter(email = email)


class UserCreationForm(forms.ModelForm):
	"""A form for creating new users. Includes all the required
	fields, plus a repeated password."""
	password1 = forms.CharField(label = 'Password', widget = forms.PasswordInput)
	password2 = forms.CharField(label = 'Password confirmation', widget = forms.PasswordInput)


	class Meta:
		model = UserAccount
		fields = ('email', 'name')


	def clean_password2(self):
		# Check that the two password entries match
		password1 = self.cleaned_data.get("password1")
		password2 = self.cleaned_data.get("password2")
		if password1 and password2 and password1 != password2:
			raise ValidationError("Passwords don't match")
		return password2


	def save(self, commit = True):
		# Save the provided password in hashed format
		user = super().save(commit = False)
		user.set_password(self.cleaned_data["password1"])
		user.token = random_token(length = 32).lower()
		if commit:
			user.save()
		return user


class UserChangeForm(forms.ModelForm):
	"""A form for updating users. Includes all the fields on
	the user, but replaces the password field with admin's
	password hash display field.
	"""
	password = ReadOnlyPasswordHashField()


	class Meta:
		model = UserAccount
		fields = ('email', 'password', 'name', 'is_active', 'is_staff')


	def clean_password(self):
		# Regardless of what the user provides, return the initial value.
		# This is done here, rather than on the field, because the
		# field does not have access to the initial value
		return self.initial["password"]


class UserSubscriptionHistoryInline(admin.TabularInline):
	model = UserSubscriptionHistory
	fields = ('old_plan', 'old_plan_expired_at', 'old_recurring_payments', 'new_plan', 'new_plan_expired_at', 'new_recurring_payments', 'created_at')
	readonly_fields = ('old_plan', 'old_plan_expired_at', 'new_plan', 'new_plan_expired_at', 'created_at', 'old_recurring_payments', 'new_recurring_payments')
	show_change_link = True
	can_delete = False
	extra = 0


	def old_recurring_payments(self, obj):
		if obj.old_plan_yearly_paid:
			return 'Yearly'
		return 'Monthly'


	def new_recurring_payments(self, obj):
		if obj.new_plan_yearly_paid:
			return 'Yearly'
		return 'Monthly'


	old_recurring_payments.short_description = 'Old Recurring Payments'
	new_recurring_payments.short_description = 'New Recurring Payments'


class UserSubscriptionInline(admin.TabularInline):
	model = UserSubscription
	fields = ('plan', 'started_at', 'expired_at', 'cancelled_at', 'channels_limit', 'products_limit', 'yearly_paid', 'subscription_fee', 'auto_renew', 'paypal_subscription_id', 'payment_method')
	show_change_link = True
	extra = 0
	can_delete = False
	readonly_fields = ('paypal_subscription_id', 'payment_method')


	def formfield_for_foreignkey(self, db_field, request, **kwargs):
		field = super(UserSubscriptionInline, self).formfield_for_foreignkey(db_field, request)
		resolved = resolve(request.path_info)
		if resolved.kwargs.get('object_id'):
			plan = Subscription.objects.filter(user_id = resolved.kwargs['object_id'], type = 'custom')
			if plan:
				field.queryset = field.queryset.filter(user_id = resolved.kwargs['object_id'], type = 'custom')
			else:
				field.queryset = field.queryset.filter(type = 'system')

		return field


class ChannelInline(admin.TabularInline):
	model = Channel
	fields = ('id', 'type', 'name', 'identifier', 'url', 'api', 'position', 'first_setting', 'sync_price', 'sync_qty', 'sync_order', 'status', 'created_at', 'updated_at', 'deleted_at', 'default')
	readonly_fields = ('id', 'type', 'name', 'identifier', 'url', 'api', 'position', 'sync_price', 'sync_qty', 'sync_order', 'status', 'created_at', 'updated_at', 'deleted_at', 'image', 'default')
	show_change_link = True
	can_delete = False
	extra = 0


class StatusFilter(SelectBoxFilter):
	title = 'Status'  # or use _('country') for translated title
	parameter_name = 'status'
	template = 'django_admin_listfilter_dropdown/dropdown_filter.html'

	def lookups(self, request, model_admin):
		return [("online", "online"), ('offline', 'offline')]


	def queryset(self, request, queryset):
		current_time = datetime.fromtimestamp(to_int(time.time()) - 60 * 3).strftime("%Y-%m-%d %H:%M:%S")
		if self.value() == 'online':
			return queryset.filter(last_access__gt = current_time)
		if self.value() == 'offline':
			return queryset.filter(Q(last_access__lt = current_time) | Q(last_access__isnull = True))
class PaidStatusFilter(SelectBoxFilter):
	title = 'Paid Status'  # or use _('country') for translated title
	parameter_name = 'paid_status'

	def lookups(self, request, model_admin):
		return [("active", "Active"), ('expired', 'Expired'),("trial_active", "Trial Active"), ('trial_expired', 'Trial_Expired')]


	def queryset(self, request, queryset):
		if self.value():
			current_time = today().strftime("%Y-%m-%d 00:00:00")
			if self.value().startswith('trial'):
				queryset = queryset.filter(is_trial = True)
			else:
				queryset = queryset.filter(is_trial = False)
			if self.value().endswith('active'):
				subscription_queryset = UserSubscription.objects.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).exclude(plan_id__in = [1, 8]).values('user_id')
			else:
				subscription_queryset = UserSubscription.objects.filter(expired_at__lte = current_time).exclude(plan_id__in = [1, 8]).values('user_id')
			return queryset.filter(id__in = subscription_queryset)

class FromAppFilter(SelectBoxFilter):
	title = 'From'  # or use _('country') for translated title
	parameter_name = 'market_app'


	def lookups(self, request, model_admin):
		return [("litc", "LitC"), ('shopify', 'Shopify'), ('bigcommerce', 'BigCommerce'), ('wix', 'Wix'), ('squarespace', 'SquareSpace'),('woocommerce','WooCommerce')]


	def queryset(self, request, queryset):
		if self.value():
			if self.value() == 'litc':
				return queryset.filter(market_app__isnull = True)
			return queryset.filter(market_app = self.value())


class SchedulerFilter(SelectBoxFilter):
	title = 'Schedule'  # or use _('country') for translated title
	parameter_name = 'schedule'


	def lookups(self, request, model_admin):
		return [("yes", "yes"), ('no', 'no')]


	def queryset(self, request, queryset):
		task_queryset = Task.objects.all().values('verbose_name')
		process_queryset = Process.objects.filter(id__in = task_queryset).exclude(type = 'refresh').values('user_id')
		if self.value() is not None:
			if self.value() == 'yes':
				return queryset.filter(id__in = process_queryset)
			else:
				return queryset.exclude(id__in = process_queryset)


class OrderSyncFilter(SelectBoxFilter):
	title = 'Order Sync'  # or use _('country') for translated title
	parameter_name = 'order_sync'


	def lookups(self, request, model_admin):
		return [("yes", "yes")]


	def queryset(self, request, queryset):
		channel_queryset = Channel.objects.filter(sync_order = True).values('user_id')
		if self.value() is not None:
			if self.value() == 'yes':
				return queryset.filter(id__in = channel_queryset)
			else:
				return queryset.exclude(id__in = channel_queryset)

class ProductErrorFilter(SelectBoxFilter):
	title = 'Has Product Error'  # or use _('country') for translated title
	parameter_name = 'product_error'


	def lookups(self, request, model_admin):
		return [("yes", "yes")]


	def queryset(self, request, queryset):
		channel_queryset = Channel.objects.filter(default = False, channel_number_products__contains = 'error').exclude(channel_number_products__contains = '"error": 0').values('user_id')
		if self.value() is not None:
			if self.value() == 'yes':
				return queryset.filter(id__in = channel_queryset)
			else:
				return queryset.exclude(id__in = channel_queryset)
class ChannelFilter(SelectBoxFilter):
	title = 'Channel'  # or use _('country') for translated title
	parameter_name = 'channel_type'


	def lookups(self, request, model_admin):
		return choices_channel()


	def queryset(self, request, queryset):
		if self.value() is not None:
			channel_queryset = Channel.objects.filter(type = self.value(), default = False).values('user_id')
			return queryset.filter(id__in = channel_queryset)


class MainStoreFilter(SelectBoxFilter):
	title = 'MainStore'  # or use _('country') for translated title
	parameter_name = 'main_type'


	def lookups(self, request, model_admin):
		return choices_mainstore()


	def queryset(self, request, queryset):
		if self.value() is not None:
			channel_queryset = Channel.objects.filter(type = self.value(), default = True).values('user_id')
			return queryset.filter(id__in = channel_queryset)
class PaymentMethodFilter(SelectBoxFilter):
	title = 'Payment Method'  # or use _('country') for translated title
	parameter_name = 'payment method'


	def lookups(self, request, model_admin):
		return [
			['shopify', 'Shopify'],
			['wix', 'Wix'],
			['paypal', 'Paypal'],
		]


	def queryset(self, request, queryset):
		if self.value() is not None:
			if self.value() in ['shopify', 'wix']:
				sub_queryset = UserSubscription.objects.filter(payment_method = self.value()).values('user_id')
			else:
				sub_queryset = UserSubscription.objects.exclude(payment_method__in = ['shopify','wix']).values('user_id')

			return queryset.filter(id__in = sub_queryset)

class UserAdmin(BaseUserAdmin):
	# The forms to add and change user instances
	# form = UserChangeForm
	# add_form = UserCreationForm
	change_form_template = "admin/accounts/user/change_form.html"

	# The fields to be used in displaying the User model.
	# These override the definitions on the base UserAdmin
	# that reference specific fields on auth.User.

	en_formats.DATETIME_FORMAT = "Y/m/d H:i:s"
	list_display = ('id', 'login', 'email_name', 'country', 'go_to_channel', 'active_status', 'from_app', 'created_at', 'payment_method','parent_user','go_to_process', 'scheduler')
	list_display_admin = ['id', 'email', 'name', 'group', 'created_at']
	list_display_links = ('id', 'email_name')
	list_filter = (EmailFilter, NameFilter, MainStoreFilter, ChannelFilter, ProductErrorFilter, PaidStatusFilter, PaymentMethodFilter,'is_staff', 'is_active', StatusFilter, SchedulerFilter, FromAppFilter, OrderSyncFilter)
	inlines = (UserSubscriptionHistoryInline, UserSubscriptionInline, ChannelInline)
	list_per_page = 20
	fieldsets = (
		(None, {'fields': ('email', 'country', 'password', 'repeat_scheduler', 'first_setup')}),
		('Personal info', {'fields': ('name', 'is_active', 'is_staff', 'is_expired', 'is_superuser', 'tried_it')}),
		('Permissions', {'fields': ('groups', 'user_permissions',)}),
		(None, {'fields': ('balance', 'last_login', 'app_type')}),
		(None, {'fields': ('is_trial', 'support_amazon')}),
	)
	# add_fieldsets is not a standard ModelAdmin attribute. UserAdmin
	# overrides get_fieldsets to use this attribute when creating a user.
	add_fieldsets = (
		(None, {
			'classes': ('wide',),
			'fields': ('email', 'name', 'app_type', 'balance', 'password1', 'password2', 'repeat_scheduler', 'is_staff', 'first_setup'),
		}),
	)
	search_fields = ('email', 'name', 'id')
	ordering = ('-id',)
	filter_horizontal = ('groups', 'user_permissions',)

	actions = ['update_is_active', 'update_is_not_active', 'update_is_staff', 'update_is_not_staff']
	processes: dict


	def __init__(self, model, admin_site):

		super().__init__(model, admin_site)
		self.processes = dict()


	def active_status(self, obj):
		subscription = UserSubscription.objects.filter(user_id = obj.id)
		if subscription.first():
			user_subscription = subscription.first()
			if user_subscription.plan_id not in [1,8] and not obj.is_trial:
				today = datetime.strptime(datetime.today().strftime("%Y-%m-%d 00:00:00"), '%Y-%m-%d %H:%M:%S')
				if not user_subscription.expired_at or user_subscription.expired_at.timestamp() >= today.timestamp():

					class_status = 'online'
				else:
					class_status = 'offline'
				template = 'index.html'
				context = {'status': class_status}
				return render_to_string('admin/accounts/status.html', context)


	active_status.short_description = 'Subscription'

	def email_name(self, obj):
		return format_html(f"{obj.email}<br/>{obj.name}")


	email_name.short_description = 'Email'


	def parent_user(self, obj):
		if obj.parent_user_id:
			try:
				parent = UserAccount.objects.get(pk = obj.parent_user_id)
			except:
				parent = False
			if parent:
				url = reverse("admin:accounts_useraccount_change", args = (parent.id,))
				return format_html(f"<a href='{url}' target='_blank' class='_link''>{parent.email}</a>")
		return ''


	def get_list_display(self, request):
		if to_int(request.GET.get('is_staff__exact')) == 1 and not is_local():
			return self.list_display_admin
		return self.list_display


	def group(self, obj):
		"""
		get group, separate by comma, and display empty string if user has no group
		"""
		if obj.is_superuser:
			return 'SuperAdmin'
		return ','.join([g.name for g in obj.groups.all()]) if obj.groups.count() else ''


	def from_app(self, obj):
		if not obj.market_app:
			return 'LitC'
		return obj.market_app


	from_app.short_description = 'From'


	def get_processes(self, obj):
		if self.processes and self.processes.get(obj.id):
			return self.processes[obj.id]
		process = Process.objects.filter(user_id = obj.id)
		self.processes[obj.id] = list(process)
		return self.processes[obj.id]


	def payment_method(self, obj):
		subscription = UserSubscription.objects.filter(user_id = obj.id).first()
		if subscription:
			return subscription.payment_method or 'paypal'
		return '--'

	payment_method.short_description = 'Payment Method'


	def online_status(self, obj):
		now_timestamp = to_int(time.time())
		if not obj.last_access or now_timestamp - 60 * 3 > obj.last_access.timestamp():
			class_status = 'offline'
		else:
			class_status = 'online'
		template = 'index.html'
		context = {'status': class_status}
		return render_to_string('admin/accounts/status.html', context)


	online_status.short_description = "Online"

	def go_to_channel(self, obj):
		channels = Channel.objects.filter(user_id = obj.id, deleted_at__isnull = True)
		channel_name = list()
		if channels:
			for channel in channels:
				number_products = json_decode(channel.channel_number_products)
				extend_text = ''
				if number_products and number_products.get('error'):
					extend_text = f"|<span style='color:red'>{number_products['error']}</span>"
				channel_name.append(f"<a href='{get_full_absolute_uri('admin:channels_channel_change', {'object_id': channel.id})}' target='_blank' class='_link' style='color:grey !important;'>{channel.type}[{channel.number_products_linked}{extend_text}]</a>")
			html_channel = f"<a href='{get_full_absolute_uri('admin:channels_channel_changelist')}?user__id__exact={obj.id}' target='_blank' class='_link' style='color:blue;'>Channel</a>"
			html_channel += '<br/>'
			html_channel += "(" + ', '.join(channel_name) + ")"
			return format_html(html_channel)


	go_to_channel.short_description = 'Channels'


	def go_to_process(self, obj):
		process = self.get_processes(obj)
		if process:
			return format_html(f"<a href='{get_full_absolute_uri('admin:channels_process_changelist')}?user__id__exact={obj.id}' target='_blank' class='_link' style='color:blue;'>Process</a>")


	go_to_process.short_description = 'Processes'


	def login(self, obj):
		if obj.parent_user_id:
			return ''
		url = get_full_absolute_uri('admin_login_by_token', {'user_id': obj.id})
		return format_html(f"<a href='{url}' target='_blank' class='button' style='color:white !important;'>Login</a>")


	def scheduler(self, obj):
		processes = self.get_processes(obj)
		# processes = list(filter(lambda x: x.type != 'refresh', processes))
		process_ids = [process.id for process in processes]
		process_verbose_name = {process.id: process for process in processes}

		user_scheduler = Task.objects.filter(verbose_name__in = process_ids)
		scheduler_type = list()
		if user_scheduler:
			# for scheduler in user_scheduler:
			# 	scheduler_type.append(f"<a href='{get_full_absolute_uri('admin:background_task_task_change', {'object_id': scheduler.id})}' target='_blank' class='_link' style='color:grey !important;'>{process_verbose_name[to_int(scheduler.verbose_name)].type}</a>")
			html_channel = f"<a href='{get_full_absolute_uri('admin:background_task_task_changelist')}?email={obj.id}' target='_blank' class='_link' style='color:blue;'>{user_scheduler.count()}</a>"
			# html_channel += '<br/>'
			# html_channel += "(" + ', '.join(scheduler_type) + ")"
			return format_html(html_channel)
		return 0


	def update_is_active(self, request, queryset):
		updated = queryset.update(is_active = True)
		self.message_user(request, ngettext(
			'%d user was successfully update to is_active.',
			'%d users were successfully update to is_active.',
			updated,
		) % updated, messages.SUCCESS)


	update_is_active.short_description = "update to is active"


	def update_is_not_active(self, request, queryset):
		updated = queryset.update(is_active = False)
		self.message_user(request, ngettext(
			'%d user was successfully update to is not active.',
			'%d users were successfully update to is not active.',
			updated,
		) % updated, messages.SUCCESS)


	update_is_not_active.short_description = "update to is not active"


	def update_is_staff(self, request, queryset):
		updated = queryset.update(is_staff = True)
		self.message_user(request, ngettext(
			'%d user was successfully update to is_staff.',
			'%d users were successfully update to is_staff.',
			updated,
		) % updated, messages.SUCCESS)


	update_is_staff.short_description = "update to is_staff"


	def update_is_not_staff(self, request, queryset):
		updated = queryset.update(is_staff = False)
		self.message_user(request, ngettext(
			'%d user was successfully update to is not staff.',
			'%d users were successfully update to is not staff.',
			updated,
		) % updated, messages.SUCCESS)


	update_is_not_staff.short_description = "update to is not staff"


	def get_urls(self):
		urls = super().get_urls()
		my_urls = [
			path('response_change/', self.response_change),
			path('<int:user_id>/import-channel/', ChannelImportView.as_view(), name = 'channel-import'),
			path('<int:user_id>/close-account/', AdminCloseAccount.as_view(), name = 'close-account')
		]
		return my_urls + urls


	def response_change(self, request, obj):
		if "_clone_for_user" in request.POST:
			sync_api = SyncApi()
			clone = SyncApi().post(f'user/clone/{obj.id}')
			if clone['result'] != 'success':
				messages.error(request, clone['msg'])
			else:
				messages.success(request, 'Success')
				obj.server_id = sync_api.get_server_id()
				obj.save()
			return HttpResponseRedirect("../")

		elif "_login_by_token" in request.POST:
			token = random_token(32)
			UserLoginToken.objects.create(token = token, expires_in = to_int(time.time()) + 30, user_id = obj.id, admin_id = request.user.id)
			return redirect(get_app_url(f"accounts/login-by-token?token={token}", obj))

		elif "_view-channel" in request.POST:
			channels = Channel.objects.filter(user_id = obj.id)
			if not channels:
				messages.error(request, "Channel not found")
				return HttpResponseRedirect("../")
			return get_full_absolute_uri(f"{get_full_absolute_uri('admin:channels_channel_changelist')}?user__id__exact={obj.id}")

		elif "_view-process" in request.POST:
			processes = Process.objects.filter(user_id = obj.id)
			if not processes:
				messages.error(request, "Process not found")
				return HttpResponseRedirect("../")
			return HttpResponseRedirect(f"{get_full_absolute_uri('admin:channels_process_changelist')}?user__id__exact={obj.id}")

		elif "_view-subscription-histories" in request.POST:
			subscription_histories = UserSubscriptionHistory.objects.filter(user_id = obj.id)
			if not subscription_histories:
				messages.error(request, "Subscription history not found")
				return HttpResponseRedirect("../")
			return HttpResponseRedirect(f"{get_full_absolute_uri('admin:subscription_usersubscriptionhistory_changelist')}?user__id__exact={obj.id}")

		return super().response_change(request, obj)


	def account_login(self, obj):
		return None


	#     token = random_token(32)
	#     UserLoginToken.objects.create(token = token, expires_in = to_int(time.time()) + 30, user_id = obj.id, admin_id = obj.id)
	#     return format_html(
	#         '<a class="button" href="{}">Login</a>',
	#         reverse(f"{get_config_ini('server', 'app_url')}/accounts/login-by-token?token={token}"),
	#     )
	# account_login.short_description = 'Login'
	# account_login.allow_tags = True
	def save_model(self, request, obj, form, change):
		create_channel_cis = False
		if not obj.id and obj.app_type == 'cis':
			create_channel_cis = True
		super().save_model(request, obj, form, change)
		if create_channel_cis:
			channel = Channel.objects.create(type = 'litcommerce', user_id = obj.id, name = 'Main Store', identifier = 'litC', status = 'connected', first_setting = 1, default = 1)
			process = Process.objects.create(type = 'product', user_id = obj.id, channel_id = channel.id, status = 'new', state_id = 'litcommerce')
		if obj.is_expired:
			model_state = State()
			model_state.set_user_id(obj.id)
			channels = Channel.objects.filter(user_id = obj.id)
			for channel in channels:
				ChannelUtils().disable_all_scheduler(channel.id)
				update_data = {
					"channel.config.setting.price.status": "disable",
					"channel.config.setting.qty.status": "disable",
					"channel.config.setting.order.status": "disable",
				}
				channel.sync_order = False
				channel.sync_qty = False
				channel.sync_price = False
				channel.auto_update = False
				channel.save()
				log(channel.id, 'channel')

				model_state.update_many(model_state.create_where_condition("channel.id", to_int(channel.id)), update_data)
			UserSubscription.objects.filter(user_id = obj.id).update(expired_at = get_current_time())


	def changelist_view(self, request, extra_context = None):
		extra = extra_context or {}
		is_staff = to_int(request.GET.get('is_staff__exact'))
		if is_staff != 1:
			is_staff = 0
		extra['is_staff'] = is_staff
		return super().changelist_view(request, extra_context = extra)


class UserTokenAdmin(admin.ModelAdmin):
	search_fields = ['user', 'token', 'expires_in']
	list_filter = (UserFilter,)
	list_display = ['user', 'token', 'expires_in']


class CustomOutstandingTokenAdmin(OutstandingTokenAdmin):

	def has_delete_permission(self, *args, **kwargs):
		return True  # or whatever logic you want


admin.site.unregister(OutstandingToken)
admin.site.register(OutstandingToken, CustomOutstandingTokenAdmin)
admin.site.register(UserAccount, UserAdmin)
admin.site.register(UserToken, UserTokenAdmin)
