from django.core.exceptions import PermissionDenied
from django.http import HttpResponseNotFound
from rest_framework_simplejwt.tokens import RefreshToken

from accounts.models import TokenBlackList
from accounts.utils import AccountUtils
from core.middleware import CustomMiddleware
from libs.utils import to_str, get_http_auth, to_len


class UserTokenMiddleware(CustomMiddleware):
	NAME = 'accounts.middleware.UserTokenMiddleware'
	PASS_PATH = ['admin', 'api/token', 'api/settings/free-offer']

	def process_view(self, request, view_func, view_args, view_kwargs):
		request_path = request.path.strip('/')
		for path in self.PASS_PATH:
			if request_path.startswith(path):
				return None
		token = get_http_auth(request)

		token = RefreshToken(token)
		token.blacklist()
		if not token:
			raise PermissionDenied()

		user_list = TokenBlackList.objects.filter(token = token).first()
		if user_list:
			raise PermissionDenied()
		return None
