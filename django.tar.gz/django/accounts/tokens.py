from django.utils.translation import ugettext_lazy as _
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import AccessToken

from accounts.models import TokenBlackList


class CustomAccessToken(AccessToken):
	def verify(self):
		token = self.token
		if isinstance(token, bytes):
			token = token.decode()
		user_list = TokenBlackList.objects.filter(token = token).first()
		if user_list:
			raise TokenError(_('Token is blacklisted'))

		super().verify()
