import copy
import csv
from django.http import HttpResponseNotFound, HttpResponse, JsonResponse, HttpResponseForbidden
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.forms.models import model_to_dict
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import status, generics

from accounts.utils import AccountUtils
from core.responses import *
from datasync.api.sync import SyncApi
from inventories.serializers import InventoriesViewSerializer, ProductInventorySerializer, PutProductInventorySerializer
from libs.utils import to_int, to_str, get_current_time, get_row_from_list_by_field
from libs.storage.google import FileStorageGoogle
from products.utils import ProductUtils
from products.views import ProductAPIView, ProductDownloadTemplate, ProductImportCsv
from channels.utils import ChannelUtils
from channels.models import Channel
from processes.utils import ProcessUtils
from processes.models import Process
from warehouse_locations.utils import WarehouseLocationUtils


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: InventoriesViewSerializer
	},
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		# openapi.Parameter('title', openapi.IN_QUERY, type=openapi.TYPE_STRING),
		# openapi.Parameter('min_price', openapi.IN_QUERY, type=openapi.TYPE_NUMBER),
		# openapi.Parameter('max_price', openapi.IN_QUERY, type=openapi.TYPE_NUMBER),
		openapi.Parameter('min_qty', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('max_qty', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('status', openapi.IN_QUERY, type = openapi.TYPE_STRING),
		openapi.Parameter('location', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
	]
))
class InventoryAPIView(ProductAPIView):
	def select_fields(self):
		return ('_id', 'inventories', 'name', 'sku', 'price', 'thumb_image')


	def get_condition_from_request(self, request, model_catalog, **kwargs):
		where = dict()
		where.update(model_catalog.create_where_condition('import_status', 'active', '='))
		where.update(model_catalog.create_where_condition('variant_count', 0, '='))
		# Filter product name, sku
		query = request.GET.get('query')
		if query:
			where.update({
				'$or': [
					model_catalog.create_where_condition('name', query, 'like'),
					model_catalog.create_where_condition('sku', query, 'like')
				]
			})
		# Filter product condition
		condition = request.GET.get('condition')
		if condition:
			where.update(model_catalog.create_where_condition('condition', condition, '='))
		# Filter quantity
		for field in ('available', 'reserved', 'on_hand'):
			min_qty = request.GET.get(f'min_{field}')
			max_qty = request.GET.get(f'max_{field}')
			if min_qty or max_qty:
				if not request.GET.get('location'):
					where_qty = model_catalog.create_where_condition('inventories.total_{}'.format(field), (to_int(min_qty), to_int(max_qty)), 'erange')
				else:
					where_qty = model_catalog.create_where_condition('inventories.inventory.{}.{}'.format(request.GET.get('location'), field), (to_int(min_qty), to_int(max_qty)), 'erange')
				where.update(where_qty)
		# Filter location
		if request.GET.get('location'):
			where.update(model_catalog.create_where_condition('inventories.inventory.{}.status'.format(request.GET.get('location')), 'active', '='))
		where.update(model_catalog.create_where_condition('import_status', 'active', '='))
		return where


	def process_product_data_before_return(self, product_data, request, *args, **kwargs):
		warehouse_location = WarehouseLocationUtils().get_location_by_user(AccountUtils().get_user_id(request))
		if not warehouse_location:
			return product_data
		location_data = dict()
		for location in warehouse_location:
			location_data[to_str(location.id)] = location.name
		qty_field = ('on_hand', 'available', 'reserved')
		for product in product_data:
			for field in qty_field:
				product[field] = 0
			if product.get('inventories') and product['inventories'].get('inventory'):
				for field in qty_field:
					if 'total_{}'.format(field) in product['inventories']:
						product[field] = product['inventories'].get('total_{}'.format(field), 0)
						del product['inventories']['total_{}'.format(field)]
				inventories = list()
				for location_id, inventory in product['inventories']['inventory'].items():
					if to_str(location_id) not in location_data:
						location_name = 'Default Location'
					else:
						location_name = location_data[to_str(location_id)]
					inventory['location_name'] = location_name
					inventories.append(inventory)
				product['inventories'] = inventories
		return product_data


@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = ProductInventorySerializer,
))
class ProductInventoriesApiView(generics.ListCreateAPIView):
	def get(self, request, *args, **kwargs):
		product_id = kwargs['product_id']
		model_catalog = ProductUtils().get_model_catalog(request, *args, **kwargs)
		try:
			product = model_catalog.get(product_id)
			if not product:
				return HttpResponseNotFound()
		except:
			return HttpResponseNotFound()
		user_id = AccountUtils().get_user_id(request)
		locations = list(map(model_to_dict, WarehouseLocationUtils().get_location_by_user(user_id)))
		inventories = product['inventories']
		inventories['inventory'] = list(inventories['inventory'].values())
		for inventory in inventories['inventory']:
			location = get_row_from_list_by_field(locations, 'id', inventory['location_id'])
			if location:
				inventory['location_name'] = location['name']
				inventory['default'] = location['default']
			else:
				inventory['location_name'] = ''
				inventory['default'] = 2
		inventory_response = {
			'data': inventories,
			'count': len(inventories['inventory'])
		}
		return JsonResponse(ResponseObject(**inventory_response).to_dict(), status = 200)


	def post(self, request, *args, **kwargs):
		"""
		Create or update when exist product's inventory
		"""
		product_id = kwargs['product_id']
		model_catalog = ProductUtils().get_model_catalog(request, *args, **kwargs)
		user_id = AccountUtils().get_user_id(request)
		try:
			product = model_catalog.get(product_id)
			if not product:
				return HttpResponseNotFound()
		except:
			return HttpResponseNotFound()
		locations = list(map(model_to_dict, WarehouseLocationUtils().get_location_by_user(user_id)))
		inventory_serializer = ProductInventorySerializer(data = request.data, context = {'user_id': user_id, 'locations': locations})
		if inventory_serializer.is_valid():
			inventory_data = inventory_serializer.validated_data
			location_id = inventory_data['location_id']
			inventories = product['inventories']
			if to_str(location_id) in inventories['inventory']:
				return JsonResponse(ErrorResponse(errors = {'location_id': ['Location already exists.']}), status = 400)
			inventories['inventory'][to_str(location_id)] = inventory_data
			inventories = ProductUtils.calculate_product_inventory(inventories)
			update_data = {'inventories': inventories, 'qty': inventories['total_available']}
			model_catalog.update(product_id, update_data)
			# response
			inventories['inventory'] = list(inventories['inventory'].values())
			for inventory in inventories['inventory']:
				location = get_row_from_list_by_field(locations, 'id', inventory['location_id'])
				if location:
					inventory['location_name'] = location['name']
					inventory['default'] = location['default']
				else:
					inventory['location_name'] = ''
					inventory['default'] = 2
			inventory_response = {
				'data': inventories,
				'count': len(inventories['inventory'])
			}
			return JsonResponse(ResponseObject(**inventory_response).to_dict(), status = 200)
		else:
			errors = inventory_serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)


	def put(self, request, *args, **kwargs):
		product_id = kwargs['product_id']
		model_catalog = ProductUtils().get_model_catalog(request, *args, **kwargs)
		user_id = AccountUtils().get_user_id(request)
		try:
			product = model_catalog.get(product_id)
			if not product:
				return HttpResponseNotFound()
		except:
			return HttpResponseNotFound()
		if to_int(product['variant_count']) > 0:
			return JsonResponse(ErrorResponse(errors = {'product_id': 'Invalid data.'}).to_dict(), status = 400)
		locations = list(map(model_to_dict, WarehouseLocationUtils().get_location_by_user(user_id)))
		inventories_serializer = PutProductInventorySerializer(data = request.data, context = {'user_id': user_id, 'locations': locations})
		if inventories_serializer.is_valid():
			inventories_data = list(inventories_serializer.validated_data)
			inventories = product['inventories']
			default_inventory = list(inventories['inventory'].values())[0]
			update_inventories = {
				'total_available': 0,
				'total_reserved': 0,
				'total_on_hand': 0,
				'inventory': {
					to_str(default_inventory['location_id']): default_inventory
				},
			}
			for inventory_data in inventories_data:
				location_id = to_str(inventory_data['location_id'])
				if location_id in inventories['inventory']:
					update_inventory = inventories['inventory'][location_id]
					update_inventory['on_hand'] = inventory_data['on_hand']
				else:
					update_inventory = inventory_data
				update_inventory['updated_at'] = inventory_data['updated_at']
				update_inventory['status'] = inventory_data['status']
				update_inventory['available'] = update_inventory['reserved'] + update_inventory['on_hand']
				update_inventories['inventory'][location_id] = update_inventory
			update_inventories = ProductUtils().calculate_product_inventory(update_inventories)
			update_data = {'inventories': update_inventories, 'qty': update_inventories['total_available']}
			model_catalog.update(product_id, update_data)
			# update inventories for parent products
			if product.get('parent_id'):
				model_catalog.update_parent_product_inventories(product['parent_id'])
			# response
			update_inventories['inventory'] = list(update_inventories['inventory'].values())
			for inventory in update_inventories['inventory']:
				location = get_row_from_list_by_field(locations, 'id', inventory['location_id'])
				if location:
					inventory['location_name'] = location['name']
					inventory['default'] = location['default']
				else:
					inventory['location_name'] = ''
					inventory['default'] = 2
			inventory_response = {
				'data': update_inventories,
				'count': len(update_inventories['inventory'])
			}
			return JsonResponse(ResponseObject(**inventory_response).to_dict(), status = 200)
		else:
			return JsonResponse(ErrorResponse(errors = inventories_serializer.errors).to_dict(), status = 400)


class ProductInventoryDetailsAPIView(generics.RetrieveDestroyAPIView):
	def get(self, request, *args, **kwargs):
		product_id = kwargs['product_id']
		inventory_id = kwargs['inventory_id']
		model_catalog = ProductUtils().get_model_catalog(request, *args, **kwargs)
		try:
			product = model_catalog.get(product_id)
			if not product:
				return HttpResponseNotFound()
		except:
			return HttpResponseNotFound()
		inventories = product['inventories']
		if inventory_id not in inventories['inventory'].keys():
			return HttpResponseNotFound()
		inventory = inventories['inventory'][inventory_id]
		return JsonResponse(ResponseObject(data = inventory).to_dict(), status = 200)


	def delete(self, request, *args, **kwargs):
		product_id = kwargs['product_id']
		model_catalog = ProductUtils().get_model_catalog(request, *args, **kwargs)
		try:
			product = model_catalog.get(product_id)
			if not product:
				return HttpResponseNotFound()
		except:
			return HttpResponseNotFound()
		inventories = product['inventories']
		inventory_id = kwargs['inventory_id']
		if inventory_id not in inventories['inventory'].keys():
			return HttpResponseNotFound()
		inventories = product['inventories']
		inventories['inventory'].pop(inventory_id)
		inventories = ProductUtils.calculate_product_inventory(inventories)
		update_data = {'inventories': inventories}
		model_catalog.update(product_id, update_data)
		return JsonResponse(ResponseObject(data = update_data).to_dict(), status = 204)


class InventoryDownloadTemplate(ProductDownloadTemplate):
	template_file = 'inventory_template.csv'


class InventoryExportCsv(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		location_id = request.data.get('location_id')
		if location_id:
			location = WarehouseLocationUtils().get(location_id)
			if location:
				location_id = location.id
		if not location_id:
			JsonResponse(ErrorResponse(errors = f"Missing or invalid location id {location_id}").to_dict(), status = 400)
		export = SyncApi(user_id = user_id).post(f"inventory/export", data = {'location_id': location_id})
		if not export or export['result'] != 'success':
			return JsonResponse(ErrorResponse(errors = "Server error").to_dict(), status = 400)
		return HttpResponse(status = 201)


@method_decorator(csrf_exempt, name = 'dispatch')
class InventoryImportCsv(ProductImportCsv):
	IMPORT_TYPE_CHOICES = ('override', 'adjustment')


	def create_destination_inventory_csv(self, user_id):
		return self.create_destination_product_csv(user_id)


	def post(self, request, *args, **kwargs):
		location_id = request.POST.get('location_id')
		import_type = request.POST.get('import_type')
		if location_id:
			location = WarehouseLocationUtils().get(location_id)
			if location and location.user == request.user:
				location_id = location.id
		if not location_id:
			return JsonResponse(ErrorResponse(errors = f'Missing or invalid location id').to_dict(), status = 400)
		if import_type not in self.IMPORT_TYPE_CHOICES:
			return JsonResponse(ErrorResponse(errors = f'Missing or invalid import type.').to_dict(), status = 400)
		csv_file = request.FILES.get('inventory')
		if not csv_file:
			return JsonResponse(ErrorResponse(errors = 'File invalid').to_dict(), status = 400)
		if csv_file.size > 10485760:
			return JsonResponse(ErrorResponse(errors = 'Maximum file size is 10Mb').to_dict(), status = 400)
		copy_file = copy.deepcopy(csv_file)
		first_line = None
		try:
			data = csv.DictReader(self.decode_utf8(copy_file))
			for row in data:
				first_line = row.keys()
				break
		except Exception:
			return JsonResponse(ErrorResponse(errors = 'File error').to_dict(), status = 400)
		del copy_file
		csv_title_default = SyncApi().post('inventory/csv-file-sample')
		if not isinstance(csv_title_default, list):
			return JsonResponse(ErrorResponse(errors = "Server error").to_dict(), status = 400)
		csv_diff = list(set(csv_title_default) - set(first_line))
		if csv_diff:
			return JsonResponse(ErrorResponse(errors = "The file is not structured correctly").to_dict(), status = 400)
		user_id = AccountUtils().get_user_id(request)
		csv_file_name = self.create_destination_product_csv(user_id)
		csv_file_url = FileStorageGoogle().upload_file_from_raw(csv_file.read(), 'text/csv', csv_file_name)
		channel = ChannelUtils().filter(type = 'file', user_id = user_id)
		if not channel:
			channel = Channel.objects.create(type = 'file', user_id = user_id, name = 'Inventory Csv', api = '{}', identifier = 'inventory_csv')
		channel_id = channel.id
		process = ProcessUtils().filter(channel_id = channel_id, type = 'csv')
		if not process:
			process = Process.objects.create(channel_id = channel_id, type = 'csv', user_id = user_id)
		SyncApi(user_id = user_id).post('inventory/import/csv', data = {'location_id': location_id, 'import_type': import_type, 'file_url': csv_file_url})
		return HttpResponse(status = 201)
