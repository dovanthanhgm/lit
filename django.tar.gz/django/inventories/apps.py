from django.apps import AppConfig


class InventoriesConfig(AppConfig):
	name = 'inventories'
