from rest_framework import serializers

from products.serializers import ImageSerializer
from libs.utils import get_current_time, get_row_from_list_by_field
from warehouse_locations.utils import WarehouseLocationUtils


class InventorySerializer(serializers.ModelSerializer):
	location_id = serializers.IntegerField(
		label = 'Warehouse Location Id',
		default = ''
	)
	location_name = serializers.CharField(
		label = 'Status',
		read_only = True,
		default = ''
	)
	available = serializers.IntegerField(
		label = 'available',
		default = ''
	)
	on_hand = serializers.IntegerField(
		label = 'on_hand',
		default = ''
	)
	reserved = serializers.IntegerField(
		label = 'reserved',
		default = ''
	)
	update_at = serializers.IntegerField(
		label = 'Update At',
		read_only = True,
		default = ''
	)
	status = serializers.IntegerField(
		label = 'Status',
		read_only = True,
		default = ''
	)


class InventoriesSerializer(serializers.ModelSerializer):
	_id = serializers.CharField(
		label = 'Product id',
		default = ''
	)
	total_available = serializers.IntegerField(
		label = 'total_available',
		default = ''
	)
	total_on_hand = serializers.IntegerField(
		label = 'total_on_hand',
		default = ''
	)
	total_reserved = serializers.IntegerField(
		label = 'total_reserved',
		default = ''
	)
	inventory = InventorySerializer(many = True)
	thumb_image = ImageSerializer()
	name = serializers.CharField(
		label = 'Product name',
		default = ''
	)
	sku = serializers.CharField(
		label = 'Product Sku',
		default = ''
	)
	price = serializers.DecimalField(
		label = 'Product Price',
		default = '',
		max_digits = 2,
		decimal_places = 0
	)


class InventoriesViewSerializer(serializers.Serializer):
	code = serializers.IntegerField(label = 'code')
	message = serializers.CharField(label = 'message')
	count = serializers.IntegerField(label = 'count')
	data = InventoriesSerializer(many = True, required = False)


class ProductInventorySerializer(serializers.Serializer):
	location_id = serializers.CharField()
	available = serializers.IntegerField(min_value = 0)
	reserved = serializers.IntegerField(min_value = 0)
	on_hand = serializers.IntegerField(min_value = 0)
	updated_at = serializers.HiddenField(default = get_current_time)
	status = serializers.HiddenField(default = 'active')

	def validate(self, data):
		location_id = data['location_id']
		location = get_row_from_list_by_field(self.context['locations'], 'id', location_id)
		if not location:
			raise serializers.ValidationError({'location_id': 'Location id {} does not exist.'.format(location_id)})
		if self.context['user_id'] != location['user']:
			raise serializers.ValidationError({'location_id': 'Location id {} does not exist.'.format(location_id)})
		data['status'] = location['status']
		return data


class PutProductInventorySerializer(serializers.ListSerializer):
	child = ProductInventorySerializer()

	class Meta:
		ref_name = 'Put Product Inventory Serialzer'
		list_serializer_class = ProductInventorySerializer
