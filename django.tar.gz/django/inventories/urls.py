from django.urls import path, include

from inventories import views

urlpatterns = [
	path('/inventories', include([
		path('', views.InventoryAPIView.as_view(), name = 'inventories'),
		path('/export/csv', views.InventoryExportCsv.as_view(), name = 'inventories.export'),
		path('/import/csv', views.InventoryImportCsv.as_view(), name = 'inventories.import'),
		path('/downloads/template', views.InventoryDownloadTemplate.as_view(), name = 'inventories.template'),
	])),
	path('/products/<str:product_id>/inventories', include([
		path('', views.ProductInventoriesApiView.as_view(), name = 'products.inventories'),
		path('/<str:inventory_id>', views.ProductInventoryDetailsAPIView.as_view(), name = 'products.inventories.details')
	]))
	# re_path(r'^published$', views.product_list_published),
]
