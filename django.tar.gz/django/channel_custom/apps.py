from django.apps import AppConfig


class ChannelCustomConfig(AppConfig):
    name = 'channel_custom'
