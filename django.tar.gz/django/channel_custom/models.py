from django.core.exceptions import ValidationError
from django.db import models

# Create your models here.
from accounts.models import UserAccount
from channels.models import Channel
from libs.utils import json_decode
from processes.models import Process


class ChannelCustom(models.Model):
	name = models.CharField(max_length = 25, blank = False, null = False)
	process = models.ForeignKey(Process, on_delete = models.CASCADE, null = False, default = 0)
	channel = models.ForeignKey(Channel, on_delete = models.CASCADE, null = False, default = 0)
	# url = models.CharField(max_length = 255, null = True)
	# created_at = models.DateTimeField(auto_now_add = True)
	# data = models.TextField(null = False)
	# image = models.CharField(max_length = 255, null = True)
	# note = models.TextField(null = True)
	class Meta:
		db_table = "channel_custom"
		ordering = ['id']
		app_label = 'channels'


	# def clean(self):
	# 	if json_decode(self.data) is False:
	# 		raise ValidationError({"data": "Data are incorrect. Please enter Json format"})
