# Register your models here.
import time

from django import forms
from django.contrib import admin
from django.db import transaction
from django.urls import reverse
from django.utils.html import format_html

from accounts.models import UserAccount
from channel_custom.models import ChannelCustom
from channels.models import Channel
from core.myadmin.admin import CoreAdmin
from datasync.api.me import MeApi
from datasync.api.sync import SyncApi
from datasync.cart import Cart
from libs.utils import json_decode, to_int
from processes.models import Process


class CustomForm(forms.ModelForm):
	image = forms.CharField(required = False, widget = forms.TextInput(attrs = {'size': 50, 'max_length': 200}))
	user = forms.CharField(required = True)
	note = forms.CharField(required = False, widget = forms.Textarea)
	data = forms.CharField(required = False, widget = forms.Textarea)
	name = forms.CharField(required = True)
	url = forms.CharField(required = False, widget = forms.TextInput(attrs = {'size': 50, 'max_length': 200}))
	file_custom = forms.FileField(required = False)


	class Meta:
		# model = ChannelCustom
		fields = '__all__'
		error_messages = {
			'user': {
				'invalid': 'Please enter valid user id',
			},
		}
		exclude = ["process", "channel"]


	def __init__(self, *args, **kwargs):
		instance = kwargs.get('instance')
		if not instance:
			self.base_fields['file_custom'] = forms.FileField(required = True)
			# self.base_fields['file_custom'] = forms.FileField(required = True)
			self.base_fields['user'] = forms.ModelChoiceField(queryset = UserAccount.objects.all(), widget = forms.TextInput, required = True)

		forms.ModelForm.__init__(self, *args, **kwargs)


	@transaction.non_atomic_requests
	def _post_clean(self):
		_clean = super()._post_clean()
		if not self.errors:
			channel_data = {
				'type': 'custom',
				'name': self.data['name'],
				'identifier': to_int(time.time()),
				'image': self.data['image'],
				'url': self.data['url']
			}
			me_api = MeApi(user_id = self.data['user'])
			channel = me_api.post('channels/private', data = channel_data)
			if not channel.get("id"):
				self.add_error("name", channel['errors'])
				return _clean
			channel_id = channel['id']
			process_data = {
				'channel_id': channel_id,
				'user_id': self.data['user'],
			}
			process = me_api.post('processes', data = process_data)
			sync_api = SyncApi(process_id = process['id'])
			clone = sync_api.post(f"process/clone/{process['id']}")
			# end clone

			# begin upload file
			file = self.files['file_custom']
			sync_api.post(f"process/upload-file-custom/{process['id']}", file = {file.field_name: file.file})
			# end upload file
			custom_data = json_decode(self.data['data'])
			if not custom_data:
				custom_data = dict()
			setup = Cart().setup_channel(channel_type = 'custom', channel_name = self.data['name'], channel_url = self.data['url'], user_id = self.data['user'], sync_id = process['id'], **custom_data)
			if not setup or setup['result'] != 'success':
				Process.objects.get(pk = process['id']).delete()
				Channel.objects.get(pk = channel['id']).force_delete()
				self.add_error("data", forms.ValidationError("Data invalid"))
			self.cleaned_data['process_id'] = process['id']
			self.cleaned_data['channel_id'] = channel_id
		return _clean


class ChannelCustomAdmin(CoreAdmin):
	form = CustomForm
	list_display = ['id', 'process_link', 'channel_link', 'user']
	list_per_page = 20


	def process_link(self, obj):
		url = reverse("admin:channels_process_change", args = (obj.process_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.process}</a>")


	def channel_link(self, obj):
		url = reverse("admin:channels_channel_change", args = (obj.channel_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.channel}</a>")


	def user(self, obj):
		url = reverse("admin:accounts_useraccount_change", args = (obj.channel.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.channel.user.email}</a>")


	def save_model(self, request, obj, form, change):
		obj.process_id = form.cleaned_data['process_id']
		obj.channel_id = form.cleaned_data['channel_id']
		return super(ChannelCustomAdmin, self).save_model(request, obj, form, change)


admin.site.register(ChannelCustom, ChannelCustomAdmin)
