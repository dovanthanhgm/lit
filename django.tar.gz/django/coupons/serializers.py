from rest_framework import serializers


class ApplyCouponSerializer(serializers.Serializer):
	code = serializers.CharField()
	amount = serializers.FloatField()
	order_type = serializers.CharField(required = False)