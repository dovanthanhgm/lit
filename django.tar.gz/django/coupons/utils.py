import time
from datetime import datetime

from coupons.models import Coupons, CouponUsage
from libs.utils import to_decimal


class CouponUtils:
	def check_from_date(self, coupon):
		current_time = datetime.today().timestamp()
		if not coupon.from_date or time.mktime(coupon.from_date.timetuple()) <= current_time:
			return True
		return False


	def check_to_date(self, coupon):
		current_time = datetime.today().timestamp()
		if not coupon.to_date or time.mktime(coupon.to_date.timetuple()) >= current_time:
			return True
		return False


	def check_coupon_times_used(self, coupon):
		if not coupon.uses_per_coupon:
			return True
		return coupon.uses_per_coupon > coupon.times_used


	def check_user_times_used(self, coupon, user):
		if not coupon.uses_per_customer:
			return True
		try:
			user_time_used = CouponUsage.objects.get(coupon_id = coupon.id, user_id = user.id)
		except CouponUsage.DoesNotExist:
			return True
		return user_time_used.times_used < coupon.uses_per_customer


	def verify_coupon(self, code, user, amount, coupon_type = None):
		default_response = {
			'result': 'fail',
			'msg': 'Coupon is Invalid',
			'data': {
				'amount': amount,
				'discount': 0,
				'total': amount,
				'code': code
			}
		}
		filter_field = {
			'code': code,
			'status': True
		}
		if coupon_type and coupon_type in ['plan', 'custom', 'aio']:
			filter_field[coupon_type] = True
		try:
			coupon = Coupons.objects.get(**filter_field)
		except Coupons.DoesNotExist:
			default_response['msg'] = "Coupon not found"
			return default_response
		if not self.check_from_date(coupon):
			return default_response
		if not self.check_to_date(coupon):
			return default_response
		if not self.check_coupon_times_used(coupon):
			default_response['msg'] = "Coupon has been used up"
			return default_response
		if not self.check_user_times_used(coupon, user):
			default_response['msg'] = "You have expired using this coupon"
			return default_response
		amount = to_decimal(amount)
		if coupon.discount_type == Coupons.TYPE_PERCENT:
			discount_amount = to_decimal(amount * coupon.discount_amount / 100, 2)
		else:
			discount_amount = coupon.discount_amount
		default_response['result'] = 'success'
		default_response['msg'] = ''
		default_response['data'] = {
			'amount': amount,
			'discount': round(discount_amount),
			'total': to_decimal(amount - round(discount_amount), 2),
			'code': code
		}
		return default_response


	def user_used(self, coupon_code, user):
		try:
			coupon = Coupons.objects.get(code = coupon_code)
		except Coupons.DoesNotExist:
			return False
		try:
			user_time_used = CouponUsage.objects.get(coupon_id = coupon.id, user_id = user.id)
		except CouponUsage.DoesNotExist:
			user_time_used = False
		if not user_time_used:
			CouponUsage.objects.create(coupon_id = coupon.id, user_id = user.id, times_used = 1)
		else:
			user_time_used.times_used += 1
			user_time_used.save()
		coupon.times_used += 1
		coupon.save()
		return True