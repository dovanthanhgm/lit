from django.urls import path

from coupons.views import ApplyCouponApiView

urlpatterns = [
	path("/apply", ApplyCouponApiView.as_view(), name = 'apply_coupon'),
]
