from django.db import models

# Create your models here.
from accounts.models import UserAccount


class Coupons(models.Model):
	TYPE_PERCENT = 'percent'
	TYPE_FIXED = 'fixed'
	name = models.CharField(max_length = 255, null = False, blank = False)
	code = models.CharField(max_length = 255, null = False, blank = False, unique = True)
	description = models.TextField(null = True, blank = True)
	status = models.BooleanField(null = False, blank = False, default = True)
	discount_amount = models.IntegerField(null = False, blank = False)
	discount_type = models.CharField(max_length = 25, null = False, blank = False, choices = ((TYPE_FIXED, 'Fixed'), (TYPE_PERCENT, 'Percent')), default = 'percent')
	uses_per_coupon = models.IntegerField(null = True, blank = True)
	uses_per_customer = models.IntegerField(null = True, blank = True, default = 1)
	from_date = models.DateField(null = True, blank = True)
	to_date = models.DateField(null = True, blank = True)
	times_used = models.IntegerField(null = False, blank = False, default = 0)
	plan = models.BooleanField(null = False, blank = False, default = True)
	custom = models.BooleanField(null = False, blank = False, default = True)
	aio = models.BooleanField(null = False, blank = False, default = True)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)


	class Meta:
		db_table = "coupons"
		ordering = ['id']


class CouponUsage(models.Model):
	coupon = models.ForeignKey(Coupons, on_delete = models.CASCADE, null = True)
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True)
	times_used = models.IntegerField(null = False, blank = False, default = 0)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)


	class Meta:
		db_table = "coupon_usage"
		unique_together = (
			("coupon", "user"),
		)
		ordering = ['id']
