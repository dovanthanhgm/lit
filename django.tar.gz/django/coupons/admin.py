from django.contrib import admin
# Register your models here.
from django.urls import reverse
from django.utils.html import format_html

from core.myadmin.admin import CoreAdmin, UserFilter
from coupons.models import Coupons, CouponUsage


class CouponAdmin(CoreAdmin):
	search_fields = ('code', 'name')
	list_display = ('id', 'name', 'code', 'status', 'discount_amount', 'discount_type', 'from_date', 'to_date', 'times_used')
	list_filter = ('code', 'name')


class CouponUsageAdmin(CoreAdmin):
	list_display = ('user_link', 'coupon_link', 'times_used')
	list_filter = (UserFilter,)


	def coupon_link(self, obj):
		url = reverse("admin:coupons_coupons_change", args = (obj.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.coupon.code}</a>")


	coupon_link.short_description = 'Coupon'


admin.site.register(Coupons, CouponAdmin)
admin.site.register(CouponUsage, CouponUsageAdmin)
