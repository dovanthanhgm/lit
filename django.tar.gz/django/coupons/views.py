# Create your views here.
from django.http import JsonResponse
from rest_framework import generics

from accounts.utils import AccountUtils
from core.responses import ErrorResponse
from coupons.serializers import ApplyCouponSerializer
from coupons.utils import CouponUtils


class ApplyCouponApiView(generics.CreateAPIView):
	serializer_class = ApplyCouponSerializer


	def post(self, request, *args, **kwargs):
		data = request.data
		serializer = self.get_serializer(data = request.data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		valid = CouponUtils().verify_coupon(data['code'], AccountUtils().get_user_by_request(request), data['amount'], data.get('order_type'))
		if valid['result'] != 'success':
			return JsonResponse(ErrorResponse(errors = valid['msg']).to_dict(), status = 400)

		return JsonResponse(valid['data'], safe = True)
