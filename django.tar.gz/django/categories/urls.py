from django.urls import path, include

from categories.views import CategoriesApiView

urlpatterns = [
	path("", CategoriesApiView.as_view()),
]
