from django.http import JsonResponse, HttpResponseForbidden, HttpResponse
from django.shortcuts import render, get_object_or_404

# Create your views here.
from rest_framework import generics

from accounts.utils import AccountUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from datasync.cart import Cart
from libs.models.collections.category import Category
from libs.utils import html_unquote, product_lower_name


class CategoriesApiView(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		page = request.GET.get('pages', request.GET.get('page', 1))
		limit = request.GET.get('limit', 20)
		search = html_unquote(request.GET.get('search')).strip()
		if not search:
			search = html_unquote(request.GET.get('name')).strip()
		search = html_unquote(search)
		model_category = Category()
		model_category.set_user_id(user_id)
		where = {}
		channel_id = kwargs.get('channel_id')

		if search:
			where_search = [
				model_category.create_where_condition('name', search, 'like'),
				model_category.create_where_condition('code', product_lower_name(search), 'like'),
			]
			where = model_category.create_where_condition(None, where_search, 'or')
		if channel_id:
			where.update(model_category.create_where_condition('channel_id', kwargs['channel_id']))
		categories = model_category.find_all(where, limit = limit, pages = page)
		return JsonResponse({
			'data': categories,
			'count': model_category.count(where)
		})


class ChannelFetchCategory(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])
		category_process = ChannelUtils().get_category_process(channel)
		if not category_process:
			return HttpResponseForbidden()
		pull = Cart().pull_from_channel(process_id = category_process.id)
		return HttpResponse(status = 204)