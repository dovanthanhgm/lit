from django.contrib import admin

from .models import *


class TransactionAdmin(admin.ModelAdmin):
    search_fields = ['user__email', 'amount', 'description']
    list_filter = ['user', 'amount', 'description']
    list_display = ['user', 'amount', 'short_description', 'created_at']


# admin.site.register(Transaction, TransactionAdmin)
