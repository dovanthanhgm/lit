from django.urls import path

from .views import TransactionList, TransactionDetail

urlpatterns = [
	path('', TransactionList.as_view()),
	path('/<int:pk>', TransactionDetail.as_view()),
]
