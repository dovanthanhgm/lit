from rest_framework import serializers

from .models import Transaction


class TransactionSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(required = False, allow_null = False)


	class Meta:
		model = Transaction
		fields = ['id', 'user_id', 'amount', 'description']
