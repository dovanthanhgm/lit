from decimal import Decimal
from django.template.defaultfilters import truncatechars

from django.core.validators import MinValueValidator
from django.db import models

from accounts.models import UserAccount


class Transaction(models.Model):
	"""
	Class Transaction
	"""

	user = models.ForeignKey(
		UserAccount,
		on_delete = models.CASCADE,
		null = False
	)
	amount = models.DecimalField(decimal_places = 2, max_digits = 12, null = True,
	                             validators = [MinValueValidator(Decimal('0.0'))])
	description = models.TextField(blank = True, default = '')
	created_at = models.DateTimeField(auto_now_add = True)


	class Meta:
		db_table = 'transaction'

	@property
	def short_description(self):
		return truncatechars(self.description, 30)
