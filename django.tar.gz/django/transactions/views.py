from rest_framework import generics

from .models import Transaction
from .serializers import TransactionSerializer


# Create your views here.
class TransactionList(generics.ListCreateAPIView):
	"""
	List all activities, or create a new Transaction.
	"""
	queryset = Transaction.objects.all()
	serializer_class = TransactionSerializer


class TransactionDetail(generics.RetrieveUpdateDestroyAPIView):
	"""
	Retrieve, update or delete an Transaction instance.
	"""
	queryset = Transaction.objects.all()
	serializer_class = TransactionSerializer
