from django.contrib import admin
from django.contrib.contenttypes.models import ContentType


class ContentType(ContentType):
	class Meta:
		app_label = 'auth'
		proxy = True
		ordering = ['id']


@admin.register(ContentType)
class ContentTypeAdmin(admin.ModelAdmin):
	search_fields = ['app_label', 'model']
	list_display = ['app_label', 'model']
