from django.shortcuts import render
from rest_framework import generics
from rest_framework.permissions import AllowAny

from core.management.commands.scheduler_process import Command
from libs.utils import log
from processes.utils import ProcessUtils
import datetime

class TestApiView(generics.ListAPIView):
	permission_classes = [AllowAny]
	def get(self, request, *args, **kwargs):
		process = ProcessUtils().get(1221)
		process.channel.last_imported = datetime.datetime.now()
		process.channel.save()
		Command().handle()
		return render(request, 'googleca48f8f94500b344.html')
	def post(self, request, *args, **kwargs):
		log("sendgrid web")

		return render(request, 'googleca48f8f94500b344.html')