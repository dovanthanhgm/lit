from admin_tools.menu import items, Menu

from libs.utils import is_local

try:
	# we use django.urls import as version detection as it will fail on django 1.11 and thus we are safe to use
	# gettext_lazy instead of ugettext_lazy instead
	from django.urls import reverse
	from django.utils.translation import gettext_lazy as _
except ImportError:
	from django.core.urlresolvers import reverse
	from django.utils.translation import ugettext_lazy as _


class CustomMenu(Menu):
	def __init__(self, **kwargs):
		super(CustomMenu, self).__init__(**kwargs)
		if is_local():
			self.children += [
				items.AppList(
					_('Applications'),
					exclude = ('django.contrib.*',)
				),
			]
		self.children += [

			items.MenuItem('Dashboard', reverse('admin:index')),
			items.MenuItem('Accounts', children = [
				items.MenuItem('Customer', url = f"{reverse('admin:{}_{}_changelist'.format('accounts', 'useraccount'))}?is_staff__exact=0"),
				items.MenuItem('Administrator', url = f"{reverse('admin:{}_{}_changelist'.format('accounts', 'useraccount'))}?is_staff__exact=1"),
				# items.MenuItem('Logs', url = reverse('admin:{}_{}_changelist'.format('user_logs', 'userlogs'))),
				items.MenuItem('Action Logs', url = reverse('admin:{}_{}_changelist'.format('user_action_logs', 'useractionlogs'))),
				items.MenuItem('Authentication and Authorization', url = reverse('admin:app_list', kwargs = {'app_label': 'auth'}), children = [
					items.MenuItem('Content types', url = reverse('admin:{}_{}_changelist'.format('auth', 'contenttype'))),
					items.MenuItem('Groups', url = reverse('admin:{}_{}_changelist'.format('auth', 'group'))),
					items.MenuItem('Permissions', url = reverse('admin:{}_{}_changelist'.format('auth', 'permission'))),
				]),
				items.MenuItem('Python Social Auth', url = reverse('admin:app_list', kwargs = {'app_label': 'social_django'}), children = [
					items.MenuItem('Associations', url = reverse('admin:{}_{}_changelist'.format('social_django', 'association'))),
					items.MenuItem('Nonces', url = reverse('admin:{}_{}_changelist'.format('social_django', 'nonce'))),
					items.MenuItem('User social auths', url = reverse('admin:{}_{}_changelist'.format('social_django', 'usersocialauth'))),
				]),
			]),
			items.MenuItem('Channels', url = reverse('admin:app_list', kwargs = {'app_label': 'channels'}), children = [
				items.MenuItem('Channel customs', url = reverse('admin:{}_{}_changelist'.format('channels', 'channelcustom'))),
				items.MenuItem('Channels', url = reverse('admin:{}_{}_changelist'.format('channels', 'channel'))),
				items.MenuItem('Process histories', url = reverse('admin:{}_{}_changelist'.format('channels', 'processhistory'))),
				items.MenuItem('Processes', url = reverse('admin:{}_{}_changelist'.format('channels', 'process'))),
			]),
			items.MenuItem('Scheduler', url = reverse('admin:app_list', kwargs = {'app_label': 'background_task'}), children = [
				items.MenuItem('Tasks', url = reverse('admin:{}_{}_changelist'.format('background_task', 'task'))),
				items.MenuItem('Completed Tasks', url = reverse('admin:{}_{}_changelist'.format('background_task', 'completedtask'))),
			]),
			items.MenuItem('Merchant', children = [
				items.MenuItem('Bigcommerce', url = reverse('admin:app_list', kwargs = {'app_label': 'bigcommerce'}), children = [
					items.MenuItem('Bigcommerce App', url = reverse('admin:{}_{}_changelist'.format('bigcommerce', 'bigcommerceapp'))),
					items.MenuItem('Bigcommerce App Token', url = reverse('admin:{}_{}_changelist'.format('bigcommerce', 'bigcommerceappusertoken'))),
					items.MenuItem('Bigcommerce App User', url = reverse('admin:{}_{}_changelist'.format('bigcommerce', 'bigcommerceappuser'))),
				]),
				items.MenuItem('Shopify', url = reverse('admin:app_list', kwargs = {'app_label': 'shopify'}), children = [
					items.MenuItem('Shopify App', url = reverse('admin:{}_{}_changelist'.format('shopify', 'shopifyapp'))),
					items.MenuItem('Shopify App Token', url = reverse('admin:{}_{}_changelist'.format('shopify', 'shopifyappusertoken'))),
					items.MenuItem('Shopify App User', url = reverse('admin:{}_{}_changelist'.format('shopify', 'shopifyappuser'))),
				]),
				items.MenuItem('Wix', url = reverse('admin:app_list', kwargs = {'app_label': 'wix'}), children = [
					items.MenuItem('Wix App', url = reverse('admin:{}_{}_changelist'.format('wix', 'wixapp'))),
					items.MenuItem('Wix App Token', url = reverse('admin:{}_{}_changelist'.format('wix', 'wixappusertoken'))),
					items.MenuItem('Wix App User', url = reverse('admin:{}_{}_changelist'.format('wix', 'wixappuser'))),
					items.MenuItem('Subscription Plan', url = reverse('admin:{}_{}_changelist'.format('wix', 'merchantwixsubscription'))),
				]),
				items.MenuItem('Ebay', url = reverse('admin:{}_{}_changelist'.format('merchant', 'merchantebay'))),
				items.MenuItem('Etsy', url = reverse('admin:{}_{}_changelist'.format('merchant', 'merchantetsy'))),
				items.MenuItem('Facebook', url = reverse('admin:{}_{}_changelist'.format('merchant', 'merchantfacebook'))),
				items.MenuItem('Google', url = reverse('admin:{}_{}_changelist'.format('merchant', 'merchantgoogle'))),
				items.MenuItem('Wish', url = reverse('admin:{}_{}_changelist'.format('merchant', 'merchantwish'))),
				items.MenuItem('Tiktok App', url = reverse('admin:{}_{}_changelist'.format('tiktok', 'merchanttiktokapp'))),
				items.MenuItem('Shopee App', url=reverse('admin:{}_{}_changelist'.format('shopee', 'merchantshopeeapp'))),
			]),
			items.MenuItem('Subscription', url = reverse('admin:app_list', kwargs = {'app_label': 'subscription'}), children = [
				items.MenuItem('System Plan', url = f"{reverse('admin:{}_{}_changelist'.format('subscription', 'subscription'))}?type__exact=system"),
				items.MenuItem('Custom Plan', url = f"{reverse('admin:{}_{}_changelist'.format('subscription', 'subscription'))}?type__exact=custom"),
				items.MenuItem('User subscription historys', url = reverse('admin:{}_{}_changelist'.format('subscription', 'usersubscriptionhistory'))),
				items.MenuItem('User subscriptions', url = reverse('admin:{}_{}_changelist'.format('subscription', 'usersubscription'))),
				items.MenuItem('User Renew Exceptions', url = reverse('admin:{}_{}_changelist'.format('subscription', 'subscriptionrenewexception')) + '?status__exact=0'),
			]),

			items.MenuItem('Order', url = reverse('admin:app_list', kwargs = {'app_label': 'litcommerce_order'}), children = [
				items.MenuItem('Order', url = reverse('admin:{}_{}_changelist'.format('litcommerce_order', 'litcommerceorder'))),
				items.MenuItem('Payment', url = reverse('admin:{}_{}_changelist'.format('litcommerce_order', 'paymenthistory'))),

			]),
			items.MenuItem('Coupons', url = reverse('admin:app_list', kwargs = {'app_label': 'coupons'}), children = [
				items.MenuItem('Coupons', url = reverse('admin:{}_{}_changelist'.format('coupons', 'coupons'))),
				items.MenuItem('Coupon Usage', url = reverse('admin:{}_{}_changelist'.format('coupons', 'couponusage'))),

			]),
			items.MenuItem('Tools', children = [
				items.MenuItem('Servers', url = reverse('admin:app_list', kwargs = {'app_label': 'servers'}), children = [
					items.MenuItem('Process Managements', url = reverse('admin:{}_{}_changelist'.format('servers', 'processmanagement'))),
					items.MenuItem('Servers', url = reverse('admin:{}_{}_changelist'.format('servers', 'server'))),
				]),
				items.MenuItem('Announcements', url = reverse('admin:{}_{}_changelist'.format('announcements', 'announcement'))),
				items.MenuItem('Setting', url = reverse('admin:{}_{}_changelist'.format('settings', 'serversetting'))),
				items.MenuItem('Error Log', url = reverse('admin:{}_{}_changelist'.format('setup_error_log', 'errorlog'))),
				items.MenuItem('Email Templates', url = reverse('admin:{}_{}_changelist'.format('email_templates', 'emailtemplate'))),
				items.MenuItem('Error Templates', url = reverse('admin:{}_{}_changelist'.format('error_templates', 'errortemplates'))),
				items.MenuItem('Feature Request', url = reverse('admin:{}_{}_changelist'.format('feature_request', 'featurerequest'))),
				items.MenuItem('Survey', url = reverse('admin:{}_{}_changelist'.format('survey', 'surveymodel'))),
				items.MenuItem('Feedback', children = [
					items.MenuItem('List', url = reverse('admin:{}_{}_changelist'.format('smart_feedback', 'smartfeedback'))),
					items.MenuItem('Report', url = f"{reverse('admin:{}_{}_changelist'.format('smart_feedback', 'smartfeedback'))}report/"),

				]),
			]),
			items.MenuItem('Stats', children = [
				items.MenuItem('General', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}stats/"),
				items.MenuItem('Users Stats', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}user-stats/"),
				items.MenuItem('Users Active Stats', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}user-active-stats/"),
				items.MenuItem('Duration Paid', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}duration-paid/"),
				items.MenuItem('User Expired Report', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}user-report/"),
			]),
			items.MenuItem('Crisp', children = [
				items.MenuItem('Crisp Report', children = [
					items.MenuItem('Daily', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}cs-report/"),

					items.MenuItem('Monthly', url = f"{reverse('admin:{}_{}_changelist'.format('myadmin', 'myadmin'))}cs-report/1"),
				]),
				items.MenuItem('User', url = f"{reverse('admin:{}_{}_changelist'.format('crisp', 'crispusermodel'))}"),
				items.MenuItem('User History', url = f"{reverse('admin:{}_{}_changelist'.format('crisp', 'crispuserhistorymodel'))}"),
				items.MenuItem('Conservation Fault', url = f"{reverse('admin:{}_{}_changelist'.format('crisp', 'crispmessagefaults'))}"),
				items.MenuItem('Conservation No Reply', url = f"{reverse('admin:{}_{}_changelist'.format('crisp', 'crispconversationnoreply'))}"),

			]),

		]
