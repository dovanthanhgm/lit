from django.contrib import admin
from django.urls import include, path, re_path
from rest_framework_simplejwt.views import TokenRefreshView
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from accounts.views import MyTokenObtainPairView
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

from datasync_django import settings
# from datasync_django.views import TestApiView

schema_view = get_schema_view(
	openapi.Info(
		title = 'Open API',
		default_version = 'v1',
		description = 'Test description',
	),

	public = True,
	permission_classes = (permissions.AllowAny,),
)

admin.site.site_header = 'LitCommerce Admin'
admin.site.site_title = 'LitCommerce Admin'
admin.site.index_title = ""

urlpatterns = [
	re_path('dev/docs', schema_view.with_ui('swagger', cache_timeout = 0), name = 'schema-swagger-ui'),
	path('tinymce/', include('tinymce.urls')),

	path(f'{settings.ADMIN_PATH}/', admin.site.urls),
	path('admin-api', include('core.myadmin.urls')),
	path('api-auth/', include('rest_framework.urls')),
	path('api/login/', MyTokenObtainPairView.as_view(), name = 'token_obtain_pair'),
	# path('test-api', TestApiView.as_view(), name = 'token_refresh'),
	path('api/token/refresh/', TokenRefreshView.as_view(), name = 'token_refresh'),
	path('api/accounts', include('accounts.urls'), name = 'accounts'),
	path('api/email/', include('email_templates.urls'), name = 'email'),
	path('api', include('inventories.urls'), name = 'inventories'),
	path('api', include('products.urls'), name = 'products'),
	path('api/announcements', include('announcements.urls'), name = 'announcements'),
	path('api/feature-request', include('feature_request.urls'), name = 'feature_request'),
	path('api', include('orders.urls'), name = 'orders'),
	path('api/settings', include('settings.urls'), name = 'settings'),
	path('api/channels', include('channels.urls'), name = 'channels'),
	path('api/processes', include('processes.urls'), name = 'processes'),
	path('api/activities', include('activities.urls'), name = 'activities'),
	path('api/categories', include('categories.urls'), name = 'categories'),
	# path('api/transactions', include('transactions.urls'), name = 'transactions'),
	path('api/payments', include('payments.urls'), name = 'payments'),
	path('api/coupons', include('coupons.urls'), name = 'coupons'),
	path('api/feedbacks', include('smart_feedback.urls'), name = 'smart_feedback'),
	# path('api/notifications', include('notifications.urls'), name = 'notifications'),
	path('api/', include('datasync.urls'), name = 'datasync'),
	path('api/warehouses', include('warehouse_locations.urls'), name = 'warehouse'),
	path('api', include('attributes.urls'), name = 'warehouse'),

	path('api/paypal-ipn/', include('paypal.standard.ipn.urls')),

	# path('payments', include('payments.urls')),

	path('auth/', include('social_django.urls', namespace = 'social')),

	# path('merchant/', include('merchant.template.urls'), name = 'template'),

	path('api/token_ebay', include('token_ebay.urls'), name = 'token_ebay'),
	path('merchant/ebay', include('merchant.ebay.urls'), name = 'ebay'),
	path('merchant/etsy', include('merchant.etsy.urls'), name = 'etsy'),
	path('merchant/google', include('merchant.google.urls'), name = 'google'),
	path('merchant/wish', include('merchant.wish.urls'), name = 'wish'),
	path('merchant/amazon', include('merchant.amazon.urls'), name = 'amazon'),
	path('merchant/walmart', include('merchant.walmart.urls'), name = 'walmart'),
	path('merchant/walmartca', include('merchant.walmartca.urls'), name = 'walmartca'),
	# path('merchant/amazon_sp', include('merchant._amazon_SP.urls'), name = 'amazon_sp'),
	path('merchant/facebook', include('merchant.facebook.urls'), name = 'facebook'),
	path('merchant/bigcommerce', include('merchant.bigcommerce.urls'), name = 'bigcommerce'),
	path('merchant/shopify', include('merchant.shopify.urls'), name = 'shopify'),
	path('merchant/woocommerce', include('merchant.woocommerce.urls'), name = 'woocommerce'),
	path('merchant/magento', include('merchant.magento.urls'), name = 'magento'),
	path('merchant/wix', include('merchant.wix.urls'), name = 'wix'),
	path('merchant/squarespace', include('merchant.squarespace.urls'), name = 'squarespace'),
	path('merchant/reverb', include('merchant.reverb.urls'), name = 'reverb'),
	path('merchant/onbuy', include('merchant.onbuy.urls'), name = 'onbuy'),
	path('merchant/tiktok', include('merchant.tiktok.urls'), name = 'tiktok'),
	path('merchant/bonanza', include('merchant.bonanza.urls'), name = 'bonanza'),
	path('merchant/shopee', include('merchant.shopee.urls'), name = 'shopee'),
	path('api', include('channel_templates.urls'), name = 'channel.template'),
	path('api/dashboard', include('dashboard.urls'), name = 'dashboard'),
	path('api/scheduler', include('scheduler.urls'), name = 'scheduler'),
	path('api/subscription', include('subscription.urls'), name = 'subscription'),
	path('docs/', include('docs.urls'), name = 'docs.template'),
	path('admin_tools/', include('admin_tools.urls')),
	path('api/', include('litcommerce_order.urls'), name = 'litcommerce_order'),
	path('api/crisp/', include('crisp.urls'), name = 'crisp'),
	path('api/survey/', include('survey.urls'), name = 'crisp'),
]
urlpatterns += staticfiles_urlpatterns()
