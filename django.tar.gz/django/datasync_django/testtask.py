from background_task import background

@background(schedule=3)
def notify_user():
    # lookup user by id and send them a message
    print(123)