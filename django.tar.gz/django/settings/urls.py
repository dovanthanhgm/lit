from django.urls import path

from . import views

urlpatterns = [
	path("/free-offer", views.FreeOfferApi.as_view(), name = "scheduler-info"),
]
