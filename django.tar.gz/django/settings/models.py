from django.db import models
from django.core.exceptions import ValidationError


def identifier_validate(value):
	if not value.isidentifier():
		raise ValidationError('This field have to be identifier.')
	return value


class ServerSetting(models.Model):
	code = models.CharField(max_length = 255, validators = [identifier_validate], unique = True)
	value = models.TextField(blank = True, null = True)
	description = models.TextField(blank = True, null = True)


	class Meta:
		db_table = 'server_settings'
