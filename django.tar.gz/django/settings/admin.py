from django.contrib import admin

from core.myadmin.admin import InputFilter
from settings.models import ServerSetting


class CodeInputFilter(InputFilter):
	parameter_name = 'code'
	title = 'Code'


	def queryset(self, request, queryset):
		if self.value() is not None:
			return queryset.filter(code__icontains = self.value())


class ValueInputFilter(InputFilter):
	parameter_name = 'value'
	title = 'Value'


	def queryset(self, request, queryset):
		if self.value() is not None:
			return queryset.filter(value__icontains = self.value())


class DescriptionInputFilter(InputFilter):
	parameter_name = 'description'
	title = 'Description'


	def queryset(self, request, queryset):
		if self.value() is not None:
			return queryset.filter(description__icontains = self.value())


class ServerSettingAdmin(admin.ModelAdmin):
	list_display = ['id', 'code', 'value', 'description']
	search_fields = ['code', 'value', 'description']
	list_filter = [CodeInputFilter, ValueInputFilter, DescriptionInputFilter]


admin.site.register(ServerSetting, ServerSettingAdmin)
