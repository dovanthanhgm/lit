from settings.models import ServerSetting


class SettingUtils:
	@staticmethod
	def get_setting(code, default = None):
		try:
			setting = ServerSetting.objects.get(code = code)
			value = setting.value
		except ServerSetting.DoesNotExist:
			value = default
		return value


	def get_settings(self, list_code):
		try:
			settings = ServerSetting.objects.filter(code__in = list_code)
		except ServerSetting.DoesNotExist:
			settings = False
		response = dict()
		for code in list_code:
			response[code] = ''
		if settings:
			for setting in settings:
				response[setting.code] = setting.value
		return response