from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from rest_framework.permissions import AllowAny

from settings.utils import SettingUtils


class FreeOfferApi(generics.ListAPIView):
	permission_classes = [AllowAny]
	def get(self, request, *args, **kwargs):
		list_code = ['offer_free_plan', 'offer_ends', 'offer_months', 'offer_plan']
		settings = SettingUtils().get_settings(list_code)
		return JsonResponse(settings)