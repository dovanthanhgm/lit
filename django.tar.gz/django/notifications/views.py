# Create your views here.
from django.http import HttpResponse
from rest_framework import generics

from accounts.utils import AccountUtils
from core.permission import IsPrivateOrReadOnly
from notifications.filters import NotificationFilter, NotificationNewFilter
from notifications.models import Notifications
from notifications.serializers import NotificationSerializer


class NotificationView(generics.ListCreateAPIView):
	queryset = Notifications.objects.all()
	serializer_class = NotificationSerializer
	permission_classes = [IsPrivateOrReadOnly]
	filterset_class = NotificationFilter


class NotificationNewView(generics.ListAPIView):
	queryset = Notifications.objects.all()
	serializer_class = NotificationSerializer
	filterset_class = NotificationNewFilter


class NotificationRead(generics.GenericAPIView):
	def put(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		try:
			notifications = Notifications.objects.all().filter(status = 'new', user_id = user_id)
		except:
			return HttpResponse(status = 201)
		notifications.update(status = 'read')
		return HttpResponse(status = 201)


class NotificationDetailsView(generics.RetrieveUpdateDestroyAPIView):
	permission_classes = [IsPrivateOrReadOnly]

	queryset = Notifications.objects.all()
	serializer_class = NotificationSerializer
	filterset_class = NotificationFilter
