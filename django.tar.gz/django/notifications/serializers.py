from rest_framework import serializers

from .models import Notifications


class NotificationSerializer(serializers.ModelSerializer):
	message = serializers.CharField(required = True)


	def get_fields(self, *args, **kwargs):
		fields = super(NotificationSerializer, self).get_fields(*args, **kwargs)
		request = self.context.get('request', None)
		if request and getattr(request, 'method', None) != "POST":
			fields['message'].required = False
		return fields


	def update(self, instance, validated_data):
		instance.status = validated_data.get('status', 'read')
		instance.save()
		return instance


	class Meta:
		model = Notifications
		fields = ['id', 'user_id', 'channel_type', 'channel_id', 'message', 'status', 'created_at']
