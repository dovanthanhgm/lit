from django.contrib import admin

from .models import *


class NotificationsAdmin(admin.ModelAdmin):
    search_fields = ['user__email', 'channel__name', 'channel_type', 'message', 'status', 'created_at']
    list_filter = ['user', 'channel', 'channel_type', 'message', 'status', 'created_at']
    list_display = ['user', 'channel', 'channel_type', 'short_message', 'status', 'created_at']


# admin.site.register(Notifications, NotificationsAdmin)
