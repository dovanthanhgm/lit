from django_filters import FilterSet

from accounts.utils import AccountUtils
from .models import Channel, Notifications


class NotificationFilter(FilterSet):
	class Meta:
		model = Notifications
		fields = ['status']


	@property
	def qs(self):
		channel = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return channel.filter(user_id = user_id)


class NotificationNewFilter(NotificationFilter):

	@property
	def qs(self):
		channel = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return channel.filter(user_id = user_id, status = 'new')
