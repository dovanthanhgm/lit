from django.db import models
from django.template.defaultfilters import truncatechars

from accounts.models import UserAccount
from channels.models import Channel


class Notifications(models.Model):
	"""
	Class Activity
	"""

	user = models.ForeignKey(
		UserAccount,
		on_delete = models.CASCADE,
		null = False
	)
	channel = models.ForeignKey(
		Channel,
		on_delete = models.CASCADE,
		null = True
	)
	channel_type = models.CharField(null = True, max_length = 255)
	message = models.TextField(blank = True, default = '')
	status = models.CharField(null = False, default = 'new', max_length = 15)
	created_at = models.DateTimeField(auto_now_add = True)


	class Meta:
		db_table = 'notifications'
		ordering = ['id']

	@property
	def short_message(self):
		return truncatechars(self.message, 30)
