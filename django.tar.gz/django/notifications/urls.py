from django.urls import path

from . import views
from .views import NotificationView, NotificationDetailsView, NotificationNewView, NotificationRead

urlpatterns = [
	path('', NotificationView.as_view(), name = 'notifications'),
	path('/', NotificationView.as_view(), name = 'notifications.slash'),
	path('/new', NotificationNewView.as_view(), name = 'notifications.new'),
	path('/read', NotificationRead.as_view(), name = 'notifications.new'),
	path('/<int:pk>', NotificationDetailsView.as_view(), name = 'notifications.details'),
]
