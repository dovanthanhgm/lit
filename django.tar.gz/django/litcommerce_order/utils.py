from accounts.utils import AccountUtils
from core.utils import CoreUtils
from coupons.utils import CouponUtils
from libs.utils import to_decimal
from litcommerce_order.models import LitCommerceOrder


class LitcommerceOrderUtils():
	def __init__(self, **kwargs):
		self._user_id = kwargs.get('user_id')
		self._user = kwargs.get('user')
		if not self._user and self._user_id:
			self._user = AccountUtils().get_user(self._user_id)
		if not self._user_id:
			self._user_id = self._user.id


	def create_order(self, amount = 0, note = '', order_type = None, order_from = '', payment_id = None, new_balance = False, **kwargs):
		if self._user.is_staff:
			return 0
		amount = to_decimal(amount)
		order_data = dict(
			user_id = self._user_id,
			total = amount,
			subtotal = amount,
			custom_requirements = note,
			payment_id = payment_id,
			status = 'completed',
			order_from = order_from,
			order_type = order_type,
			# discount = kwargs.get('discount', 0),
			# discount_code = kwargs.get('discount_code'),

		)
		if kwargs:
			order_data.update(kwargs)
		order = LitCommerceOrder.objects.create(**order_data)
		if kwargs.get('discount_code'):
			CouponUtils().user_used(kwargs['discount_code'], user = self._user)
		if new_balance:
			CoreUtils().user_new_balance(self._user, amount)
		return order.id
