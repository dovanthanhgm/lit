from rest_framework import serializers

from .models import LitCommerceOrder


class LitCommerceOrderSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)


	class Meta:
		model = LitCommerceOrder
		fields = ["id", "user_id", "order_type", "total", "custom_requirements", "created_at", "payment_id", "status", 'source', 'target', 'number_products', 'description', 'yearly_paid']


class LitcommercePlaceAioOrderSerializer(serializers.Serializer):
	REQUIRED_COUPON = False
	number_products = serializers.IntegerField()
	source = serializers.ListField(child = serializers.ChoiceField(choices = ['amazon', 'ebay', 'etsy', 'facebook', 'google', 'bigcommerce', 'magento', 'shopify', 'wix', 'woocommerce', 'squarespace', 'file', 'csv']))
	target = serializers.ListField(child = serializers.ChoiceField(choices = ['amazon', 'ebay', 'etsy', 'facebook', 'google', 'bigcommerce', 'magento', 'shopify', 'wix', 'woocommerce', 'squarespace']))
	coupon_code = serializers.CharField(required = REQUIRED_COUPON)
	custom_fee = serializers.IntegerField(required = False, allow_null = True)
	custom_requirements = serializers.CharField(required = False, allow_blank = True)
	skype = serializers.CharField(required = False, allow_blank = True, allow_null = True)
	whatsapp = serializers.CharField(required = False, allow_blank = True, allow_null = True)


class LitcommercePlaceAioApplyCouponOrderSerializer(LitcommercePlaceAioOrderSerializer):
	REQUIRED_COUPON = True
