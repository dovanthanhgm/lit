from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from core.myadmin.admin import CoreAdmin, UserFilter, InputFilter
from .models import LitCommerceOrder


class DiscountFilter(InputFilter):
	parameter_name = 'discount_code'
	title = ('Discount Code')
	field_filter = ''


	def filter_user(self, user_ids, request, queryset):
		return queryset.filter(user_id__in = user_ids)


	def queryset(self, request, queryset):
		if self.value() is not None:
			return queryset.filter(discount_code = self.value())


class LitCommerceOrderAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'order_type', 'subtotal', 'discount', 'setup_price', 'subscription_price', 'total', 'subscription_start_date','custom_requirements', 'number_products', 'source', 'target', 'plan_name', 'order_from', 'ticket', 'created_at', 'status']
	list_filter = ('created_at', 'order_type', 'status', DiscountFilter, UserFilter)


	def plan_name(self, obj):
		if obj.plan_id:
			return obj.plan.name
		return ''


	def ticket(self, obj):
		if obj.ticket_id:
			return format_html(f"<a href='https://litextension.zendesk.com/agent/tickets/{obj.ticket_id}' target='_blank' class='_link''>{obj.ticket_id}</a>")
		return ''


	plan_name.short_description = 'Plan'


	def has_add_permission(self, request, obj = None):
		return False


	def user_link(self, obj):
		url = reverse("admin:accounts_useraccount_change", args = (obj.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.user.email}</a>")


	def payment_link(self, obj):
		url = reverse("admin:litcommerce_order_paymenthistory_change", args = (obj.payment_id,))
		if obj.payment:
			return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.payment.total}</a>")
		return ''


admin.site.register(LitCommerceOrder, LitCommerceOrderAdmin)
