from django_filters import FilterSet

from accounts.utils import AccountUtils
from litcommerce_order.models import LitCommerceOrder


class LitCommerceOrderFilter(FilterSet):
	class Meta:
		model = LitCommerceOrder
		exclude = []

	@property
	def qs(self):
		order = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return order.filter(user_id = user_id)
