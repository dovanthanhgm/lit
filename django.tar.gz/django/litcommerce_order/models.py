from dateutil.utils import today
from django.db import models

from accounts.models import UserAccount
from payments.models import PaymentHistory
from subscription.models import Subscription


class LitCommerceOrder(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	order_type = models.CharField(max_length = 25, null = True, choices = (('subscription', 'Subscription'), ('plan', 'Plan'), ('custom', 'Custom'), ('aio', 'AIO'),('cancel_sub', 'Cancel Subscription')))
	order_from = models.CharField(max_length = 25, null = True)
	subtotal = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	discount = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	discount_code = models.CharField(max_length = 25, null = True, blank = True)
	subscription_price = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	setup_price = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	total = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	custom_requirements = models.TextField(null = True, blank = True)
	created_at = models.DateTimeField(auto_now_add = True)
	refund_date = models.DateField(null = True, blank = True)
	subscription_start_date = models.DateField(null = True, blank = True)
	refund = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	payment = models.ForeignKey(PaymentHistory, on_delete = models.CASCADE, null = True, blank = True)
	status = models.CharField(max_length = 25, null = True, blank = True, choices = (('completed', 'Completed'), ('pending', 'Pending'), ('refunded', 'Refunded'), ('partial_refunded', 'Partial Refunded')))
	paypal_subscription_id = models.CharField(max_length = 125, null = True, blank = True)
	number_products = models.IntegerField(default = 0)
	source = models.TextField(null = True, blank = True)
	target = models.TextField(null = True, blank = True)
	custom_fee = models.IntegerField(null = False, default = 0)
	plan = models.ForeignKey(Subscription, on_delete = models.CASCADE, null = True, blank = True)
	yearly_paid = models.BooleanField(default = False)
	ticket_id = models.IntegerField(null = True, blank = True)
	description = models.TextField(null = True, blank = True)

	def save(self, force_insert = False, force_update = False, using = None, update_fields = None):
		if self.refund:
			if self.refund > self.total:
				raise ValueError(
					"Refund cannot be greater than the total"
				)
			if self.refund == self.total:
				self.status = 'refunded'
			else:
				self.status = 'partial_refunded'
			if not self.refund_date:
				self.refund_date = today()
		super(LitCommerceOrder, self).save(force_insert, force_update, using, update_fields)


	class Meta:
		db_table = "litcommerce_order"
		ordering = ['-id']
