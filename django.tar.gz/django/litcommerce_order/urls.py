from django.urls import path, include

from litcommerce_order import views

urlpatterns = [
	path('litcommerce-order', include([
		path('', views.LitCommerceOrderAPIView.as_view(), name = 'litcommerce_order'),
		path('/<int:pk>', views.LitCommerceOrderDetail.as_view(), name = 'litcommerce_order.detail'),
	])),
	path('buy-service/', include([
		path('custom', views.LitcommercePlaceCustomOrder.as_view(), name = 'buy_service.custom'),
		path('aio', views.LitcommercePlaceAioOrder.as_view(), name = 'buy_service.custom.'),
		path('aio/apply-coupon', views.LitcommerceApplyCouponAioOrder.as_view(), name = 'buy_service.aio.apply_coupon'),
		path('aio/calculated', views.LitcommerceCalculatedAioOrder.as_view(), name = 'buy_service.aio.calculated'),
	])),

	path('place-order', views.LitcommercePlaceCustomOrder.as_view(), name = 'litcommerce_place_order'),

]
