from time import time

from django.db.models.query import QuerySet
from django.http import JsonResponse
from rest_framework import generics

from accounts.utils import AccountUtils
from core.permission import IsPrivateOrReadOnly
from core.responses import ErrorResponse, ResponseObject
from core.utils import CoreUtils
from coupons.utils import CouponUtils
from libs.utils import to_decimal, to_int, random_token, json_encode, get_app_url, get_full_absolute_uri
from payments.models import PaymentInformation
from payments.utils import PaymentUtils
from .filters import LitCommerceOrderFilter
from .models import LitCommerceOrder
from .serializers import LitCommerceOrderSerializer, LitcommercePlaceAioOrderSerializer, LitcommercePlaceAioApplyCouponOrderSerializer
from .utils import LitcommerceOrderUtils


class LitCommerceOrderAPIView(generics.ListAPIView):
	permission_classes = [IsPrivateOrReadOnly]
	queryset = LitCommerceOrder.objects.all()
	serializer_class = LitCommerceOrderSerializer
	filterset_class = LitCommerceOrderFilter


	def get_queryset(self):
		"""
		Get the list of items for this view.
		This must be an iterable, and may be a queryset.
		Defaults to using `self.queryset`.

		This method should always be used rather than accessing `self.queryset`
		directly, as `self.queryset` gets evaluated only once, and those results
		are cached for all subsequent requests.

		You may want to override this if you need to provide different
		querysets depending on the incoming request.

		(Eg. return a list of items that is specific to the user)
		"""
		assert self.queryset is not None, (
				"'%s' should either include a `queryset` attribute, "
				"or override the `get_queryset()` method."
				% self.__class__.__name__
		)

		queryset = self.queryset
		if isinstance(queryset, QuerySet):
			# Ensure queryset is re-evaluated on each request.
			queryset = queryset.all()
		return queryset


class LitCommerceOrderDetail(generics.RetrieveAPIView):
	permission_classes = [IsPrivateOrReadOnly]
	filterset_class = LitCommerceOrderFilter

	queryset = LitCommerceOrder.objects.all()
	serializer_class = LitCommerceOrderSerializer


class LitcommercePlaceCustomOrder(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		data = request.data
		amount = to_decimal(data.get('amount'))
		if not amount:
			return JsonResponse(ErrorResponse(errors = 'Data Invalid').to_dict(), status = 400)
		user = AccountUtils().get_user_by_request(request)
		description = "LitCommerce: Buy Custom Service"
		if to_decimal(user.balance) >= amount:
			order_id = LitcommerceOrderUtils(user = user).create_order(amount, data.get('note'), new_balance = True, description = description)
			return JsonResponse(ResponseObject(data = order_id).to_dict())
		token = f"{to_int(time())}-{random_token()}"

		payment_information = {
			'token': token,
			'name': "Buy Custom Service LitCommerce",
			"user_id": user.id,
			"amount": to_decimal(amount) - to_decimal(user.balance),
			"return_url": get_app_url("order-received", user),
			"cancel_url": get_app_url("buy-custom-service", user),
			"status": "pending",
			"type": "custom",
			"method": PaymentUtils().get_payment_method_name(request),
			'meta_data': json_encode({'note': data.get('note'), 'amount': amount, 'description': description})
		}
		PaymentInformation.objects.create(**payment_information)
		return JsonResponse(ResponseObject(code = 'payment', data = get_full_absolute_uri('process_payment_token', {'token': token})).to_dict(), status = 301)


class LitcommercePlaceAioOrder(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		data = request.data
		serializer = LitcommercePlaceAioOrderSerializer(data = request.data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		if data.get('skype') or data.get('whatsapp'):
			if data.get('skype'):
				self.request.user.skype = data['skype']
			if data.get('whatsapp'):
				self.request.user.whatsapp = data['whatsapp']
			self.request.user.save()
		price = CoreUtils().get_entity_price(serializer.data['number_products'], serializer.data['source'], serializer.data['target'])['price']
		if serializer.data.get('custom_fee'):
			price += to_int(serializer.data.get('custom_fee'))
		user = AccountUtils().get_user_by_request(request)
		coupon_code = serializer.data.get('coupon_code')
		# coupon_code = '123456'
		total = price
		subtotal = price
		discount = 0
		discount_info = dict()
		description = f"LitCommerce: {','.join(serializer.data['source'])} to {','.join(serializer.data['target'])} All In One Service"
		kwargs = dict(
			subtotal = subtotal,
			total = total,
			order_type = 'aio',
			number_products = serializer.data['number_products'],
			source = ','.join(serializer.data['source']),
			target = ','.join(serializer.data['target']),
			custom_fee = to_int(serializer.data.get('custom_fee')),
			note = serializer.data.get('custom_requirements'),
			description = description
		)
		if coupon_code:
			validate_coupon = CouponUtils().verify_coupon(coupon_code, user, price, 'aio')
			if validate_coupon['result'] == 'success':
				discount = validate_coupon['data']['discount']
				total = validate_coupon['data']['total']
				discount_info = validate_coupon['data']
		if discount:
			kwargs['discount'] = discount
			kwargs['total'] = total
			kwargs['discount_code'] = discount_info['code']
		if total <= to_decimal(user.balance):
			order_id = LitcommerceOrderUtils(user = user).create_order(total, new_balance = True, **kwargs)

			return JsonResponse(ResponseObject(data = order_id).to_dict())
		token = f"{to_int(time())}-{random_token()}"

		payment_information = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": to_decimal(total),
			"subtotal": to_decimal(subtotal),
			"return_url": get_app_url("order-received", user),
			"cancel_url": get_app_url("buy-aio-service", user),
			"status": "pending",
			"type": "aio",
			"name": description,
			"method": PaymentUtils().get_payment_method_name(request),
			'meta_data': json_encode(kwargs)

		}
		PaymentInformation.objects.create(**payment_information)
		return JsonResponse(ResponseObject(code = 'payment', data = get_full_absolute_uri('process_payment_token', {'token': token})).to_dict(), status = 301)


class LitcommerceApplyCouponAioOrder(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		serializer = LitcommercePlaceAioApplyCouponOrderSerializer(data = request.data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		price = CoreUtils().get_entity_price(serializer.data['number_products'], serializer.data['source'], serializer.data['target'])['price']
		if serializer.data.get('custom_fee'):
			price += to_int(serializer.data.get('custom_fee'))
		user = AccountUtils().get_user_by_request(request)
		coupon_code = serializer.data.get('coupon_code')
		validate_coupon = CouponUtils().verify_coupon(coupon_code, user, price, 'aio')
		return JsonResponse(validate_coupon)


class LitcommerceCalculatedAioOrder(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		serializer = LitcommercePlaceAioOrderSerializer(data = request.data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		calculated = CoreUtils().get_entity_price(serializer.data['number_products'], serializer.data['source'], serializer.data['target'])
		price = calculated['price']
		if serializer.data.get('custom_fee'):
			price += to_int(serializer.data.get('custom_fee'))
		user = AccountUtils().get_user_by_request(request)
		coupon_code = serializer.data.get('coupon_code')
		data = {
			'amount': price,
			'discount': 0,
			'total': price,
			'code': ''
		}
		validate_coupon = CouponUtils().verify_coupon(coupon_code, user, price, 'aio')
		if validate_coupon['result'] == 'success':
			data = validate_coupon['data']
		data['fulfilment_time'] = calculated['fulfilment_time']
		data['included_paid_months'] = calculated['included_paid_months']
		return JsonResponse(data)