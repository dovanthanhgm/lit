from django.apps import AppConfig


class LitcommerceOrderConfig(AppConfig):
    name = 'litcommerce_order'
