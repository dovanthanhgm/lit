import logging

import jwt
from rest_framework import authentication

from accounts.models import UserAccount
from libs.authorization import Authorization
from libs.utils import to_str, get_config_ini, hash_hmac, base64_to_string, to_bool, is_local, get_private_key


class PrivateKeyAuthentication(authentication.BaseAuthentication):
	def authenticate(self, request):
		token = self.get_raw_token(request)
		if not token:
			return None
		user = self.get_user(token)
		if not user:
			return None
		return user, None


	def get_raw_token(self, request):
		return request.META.get('HTTP_AUTHORIZATION')


	def check_token(self, authorization):
		data = Authorization(private_key = get_private_key()).decode(authorization)
		return data

	def get_user(self, authorization):
		data = self.check_token(authorization)
		if not data or not data.get('user_id'):
			return False
		user_id = data['user_id']
		try:
			user = UserAccount.objects.get(pk = user_id)  # get the user
		except UserAccount.DoesNotExist:
			return False
		return user


	def get_user_id(self, request):
		auth = self.authenticate(request)
		if auth is None or not isinstance(auth, (tuple, list)) or len(auth) == 1:
			return False
		return auth[0].id


	def authorize(self, str_request, str_hmac):
		private_key = get_private_key()
		if not private_key:
			return False
		return to_str(str_hmac) == hash_hmac('sha256', str_request, private_key)


class IsPostOrIsAuthenticated(authentication.BaseAuthentication):
	def has_permission(self, request, view):
		# allow all POST requests
		if request.method == 'POST' or is_local():
			return True

		# Otherwise, only allow authenticated requests
		# Post Django 1.10, 'is_authenticated' is a read-only attribute
		return request.user and request.user.is_authenticated


class IsGetOrIsAuthenticated(authentication.BaseAuthentication):
	def has_permission(self, request, view):
		# allow all GET requests
		if request.method == 'GET' or is_local():
			return True

		# Otherwise, only allow authenticated requests
		# Post Django 1.10, 'is_authenticated' is a read-only attribute
		return request.user and request.user.is_authenticated
