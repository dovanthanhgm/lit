from rest_framework import permissions

from core.authentication import PrivateKeyAuthentication


class IsPrivateOrReadOnly(permissions.BasePermission):
	message = 'Permission allow private key authorization.'

	def has_permission(self, request, view):
		# Read permissions are allowed to any request,
		# so we'll always allow GET, HEAD or OPTIONS requests.
		if request.method in permissions.SAFE_METHODS:
			return True

		auth = PrivateKeyAuthentication().authenticate(request)
		return auth is not None
class IsPrivateOrReadDelete(permissions.BasePermission):
	message = 'Permission allow private key authorization.'

	def has_permission(self, request, view):
		# Read permissions are allowed to any request,
		# so we'll always allow GET, HEAD or OPTIONS requests.
		if request.method in permissions.SAFE_METHODS:
			return True
		if request.method in ['DELETE']:
			return True
		auth = PrivateKeyAuthentication().authenticate(request)
		return auth is not None

class IsPrivate(permissions.BasePermission):
	message = 'Permission allow private key authorization.'

	def has_permission(self, request, view):
		# Read permissions are allowed to any request,
		# so we'll always allow GET, HEAD or OPTIONS requests.
		auth = PrivateKeyAuthentication().authenticate(request)
		return auth is not None


class IsPrivateWithoutUser(permissions.BasePermission):
	message = 'Permission allow private key authorization.'

	def has_permission(self, request, view):
		# Read permissions are allowed to any request,
		# so we'll always allow GET, HEAD or OPTIONS requests.
		private_class = PrivateKeyAuthentication()
		token = private_class.get_raw_token(request)
		auth = private_class.check_token(token)
		return True if auth else False