from enum import Enum
from libs.utils import *


class StatusProcess(Enum):
	RUNNING = "running"
	STOPPED = "stopped"
	COMPLETED = "completed"
