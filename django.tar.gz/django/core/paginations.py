from rest_framework import pagination
from rest_framework.response import Response

from core.responses import PaginationResponse


class MetaPagination(pagination.PageNumberPagination):
	code = 200
	message = 'success'

	def get_paginated_response(self, data):
		return Response(PaginationResponse(code = self.code, message = self.message, count = self.page.paginator.count, data = data).to_dict())
