from django.contrib.auth import logout, login


def social_user(backend, uid, user=None, *args, **kwargs):
    provider = backend.name
    social = backend.strategy.storage.user.get_social_auth(provider, uid)
    if social:
        if user and social.user != user:
            logout(backend.strategy.request)
            login(backend.strategy.request, social.user, get_backend(provider))
            backend.strategy.session_set('next', f"/merchant/{get_merchant(provider)}/info")
            user = social.user
        elif not user:
            user = social.user
    return {'social': social,
            'user': user,
            'is_new': user is None,
            'new_association': False}


def get_backend(provider):
    if provider == 'google-oauth2':
        return "social_core.backends.google.GoogleOAuth2"
    if provider == 'facebook':
        return "social_core.backends.facebook.FacebookOAuth2"
    return ''
def get_merchant(provider):
    if provider == 'google-oauth2':
        return "google"
    if provider == 'facebook':
        return "facebook"
    return ''