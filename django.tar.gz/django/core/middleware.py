from hashlib import algorithms_available
import logging

import requests
from django.http import JsonResponse, HttpResponseForbidden
from rest_framework import exceptions
from rest_framework.response import Response

from accounts.utils import AccountUtils
from core.responses import ErrorResponse
from libs.utils import get_config_ini, get_client_ip, get_private_key, json_decode
import jwt


class CustomMiddleware:
	NAME = 'core.middleware.CustomMiddleware'


	def __init__(self, get_response):
		self.get_response = get_response


	def __call__(self, request):
		response = self.get_response(request)
		return response


	def process_middleware(self, request, view_func, view_args, view_kwargs):
		return None


	def process_view(self, request, view_func, view_args, view_kwargs):
		middleware_class = list()
		if hasattr(view_func, 'cls') and hasattr(view_func.cls, 'MIDDLEWARE_CLASSES') and isinstance(view_func.cls.MIDDLEWARE_CLASSES, (list, tuple)):
			middleware_class = view_func.cls.MIDDLEWARE_CLASSES
		if not middleware_class or self.NAME not in middleware_class:
			return None
		return self.process_middleware(request, view_func, view_args, view_kwargs)


class CaptchaMiddleware(CustomMiddleware):
	NAME = 'core.middleware.CaptchaMiddleware'


	def process_middleware(self, request, view_func, view_args, view_kwargs):
		data = json_decode(request.body)
		if not data.get('g-recaptcha-response'):
			return JsonResponse(ErrorResponse(errors = {'captcha': ['Captcha']}).to_dict(), status = 400)
		response = requests.post(
			'https://www.google.com/recaptcha/api/siteverify',
			data = {
				'secret': get_config_ini('recaptcha', 'secret_key'),
				'response': data['g-recaptcha-response'],
			}
		)
		if not response.json()['success']:
			logger = logging.getLogger(__name__)
			logger.error(response.text)
			return JsonResponse(ErrorResponse(errors = {'captcha': [response.json()['error-codes']]}).to_dict(), status = 400)

		return None


class ExpiredMiddleware(CustomMiddleware):
	NAME = 'core.middleware.ExpiredMiddleware'
	def process_middleware(self, request, view_func, view_args, view_kwargs):
		user = AccountUtils().get_user_by_request(request)
		if not user or user.is_expired:
			return HttpResponseForbidden()
		return None


class RequestDateMiddleware(CustomMiddleware):
	NAME = 'core.middleware.RequestDateMiddleware'
	def process_view(self, request, view_func, view_args, view_kwargs):
		request._request_date = request.headers.get('request-date')
		return None


class PermissionMiddleWare(CustomMiddleware):
	def process_view(self, request, view_func, view_args, view_kwargs):
		try:
			url = request.build_absolute_uri()
			self_token = request.headers['selfToken']
			if(self_token):
				if("sub-user" in url):
					# raise exceptions.PermissionDenied("You do not have permission to perform this action. Please ask your supervisor for more information.")
					# return HttpResponseForbidden()
					return Response(status = 403)
				permission_token = request.headers['Permission']
				private_key = get_private_key()
				permissions = jwt.decode(permission_token, private_key, algorithm = 'HS256')
				keys = list(permissions.keys())
				permision_list = ['channel', 'products', 'templates', 'orders']
				for i in range(len(permision_list)):
					if permision_list[i] in url and permissions[keys[i]] == 0:
						# print("You do not have permission to perform this action. Please ask your supervisor for more information.")
						# return HttpResponseForbidden()
						return Response(status = 403)
		except Exception as e:
			# print(e)
			pass
		return None