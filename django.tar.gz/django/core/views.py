from django.http import HttpResponseNotFound, HttpResponse
from django.shortcuts import render
from rest_framework import generics
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from accounts.models import SocialUserSession
from accounts.views import User
from core.authentication import IsGetOrIsAuthenticated
from core.responses import PopupResponse
from libs.utils import get_main_url


class SocialLogin(generics.ListAPIView):
	SOCIAL_TYPE = ''
	CHANNEL_TYPE = ''
	permission_classes = (IsGetOrIsAuthenticated,)


	def get(self, request, *args, **kwargs):
		app_type = kwargs.get('app_type', 'default')
		if app_type not in ['default', 'mss', 'cis']:
			return HttpResponseNotFound()
		from django.contrib.auth import logout as auth_logout
		auth_logout(request)

		next_url = f"/merchant/{self.CHANNEL_TYPE}/info/{app_type}"
		return HttpResponse(get_main_url(path = f'auth/login/{self.SOCIAL_TYPE}/', params = {'next': next_url}))


class SocialGetUserInfo(generics.ListAPIView):
	permission_classes = (IsGetOrIsAuthenticated,)


	def get(self, request, *args, **kwargs):

		user = request.user

		email = user.email if hasattr(user, 'email') else ''
		session_key = request.session.session_key
		if session_key:
			SocialUserSession.objects.create(user_id = user.id, session_key = session_key)
		user = User.objects.get(email = email)
		app_type = kwargs.get('app_type', 'default')
		if not user.first_social_login and app_type in ['default', 'mss', 'cis']:
			user.app_type = app_type
			user.first_social_login = True
			user.save()
		refresh = TokenObtainPairSerializer.get_token(user)
		access_token = str(refresh.access_token)

		message = PopupResponse(data = {
			'refresh_token': str(refresh),
			'access_token': access_token
		})
		return render(request, 'popup.html', {'data': message.to_json()})
