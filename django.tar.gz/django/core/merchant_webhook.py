from background_task import background

from channels.utils import ChannelUtils
from datasync.api.sync import SyncApi


class MerchantWebhook:
	def execute_webhook(self, **kwargs):
		webhook_event = kwargs['event']
		if hasattr(self, f'webhook_entity_{webhook_event}'):
			return getattr(self, f'webhook_entity_{webhook_event}')(**kwargs)


	def webhook_entity_update(self, **kwargs):
		entity = kwargs['entity']
		if entity == 'product':
			return
		data = kwargs['data']
		channel = ChannelUtils().get(channel_id = kwargs['channel_id'])
		if not channel:
			return
		SyncApi(channel_id = kwargs['channel_id']).post(f'merchant/{kwargs["merchant"]}/webhook/{entity}/update', {
			entity: data,
			'channel_id': kwargs['channel_id'],
			'identifier': kwargs['identifier']
		})
		return


	def webhook_entity_delete(self, **kwargs):
		entity = kwargs.get('entity', 'product')
		data = kwargs['data']
		SyncApi(channel_id = kwargs['channel_id']).post(f'merchant/{kwargs["merchant"]}/webhook/{entity}/delete', {
			entity: data,
			'channel_id': kwargs['channel_id'],
			'identifier': kwargs['identifier']
		})
		return


@background(schedule = 1)
def merchant_webhook(**kwargs):
	merchant_utils = MerchantWebhook()
	merchant_utils.execute_webhook(**kwargs)
