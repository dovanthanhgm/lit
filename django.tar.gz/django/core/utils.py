import importlib

import requests

from libs.models.collections.catalog import Catalog
from libs.models.collections.process import CollectionProcess
from libs.utils import to_decimal, to_int, json_decode, to_len, is_local, get_config_ini, string_to_base64, get_current_time
from settings.utils import SettingUtils


class CoreUtils():
	def user_new_balance(self, user, amount):
		amount = to_decimal(amount)
		user.balance = to_decimal(user.balance) - amount
		user.save()
		payment_history_data = {
			'user_id': user.id,
			'payer_email': user.email,
			'amount': amount,
			'total': amount,
			'new_balance': user.balance,
			'status': 'deducted',
			'token': '',
			'name': '',
			'note': ''
		}
		from payments.models import PaymentHistory
		PaymentHistory.objects.create(**payment_history_data)


	def get_channel_model_utils(self, channel_type):
		model_class = None
		try:
			module_class = importlib.import_module("merchant.{}.utils".format(channel_type))
			model_class = getattr(module_class, 'Merchant{}Utils'.format(channel_type.capitalize()))
		except:
			pass
		if not model_class:
			return False
		return model_class()


	def update_sync_frequency(self, user, sync_frequency):
		from processes.models import Process
		process = list(Process.objects.filter(user_id = user.id).values_list('id', flat = True))
		from background_task.models import Task
		Task.objects.filter(verbose_name__in = process).update(repeat = to_int(sync_frequency) * 60)


	def count_product_number(self, channel):
		if not channel:
			return
		model_catalog = Catalog()
		model_catalog.set_user_id(channel.user_id)
		where = model_catalog.create_where_condition(f'channel.channel_{channel.id}.status', 'active')
		where.update(model_catalog.create_where_condition('is_variant', False))
		number_product = model_catalog.count(where)
		number_product_linked = number_product
		if not channel.default:
			where.update(model_catalog.create_where_condition(f'channel.channel_{channel.id}.link_status', 'linked'))
			number_product_linked = model_catalog.count(where)
		channel.number_products = to_int(number_product)
		channel.number_products_linked = to_int(number_product_linked)
		channel.save()


	def get_entity_price(self, number_products, source, target):
		settings = SettingUtils().get_settings(['listing_price_aio', 'listing_time_aio', 'aio_add_price', 'aio_add_time', 'listing_free_months_aio'])
		settings = {field: json_decode(value) for field, value in settings.items()}
		listing_price_aio = [{"entity": to_int(entity), "price": to_int(price)} for entity, price in settings['listing_price_aio'].items()]
		listing_price_aio = sorted(listing_price_aio, key = lambda x: x['entity'])
		listing_time_aio = [{"entity": to_int(entity), "time": to_int(entity_time)} for entity, entity_time in settings['listing_time_aio'].items()]
		listing_time_aio = sorted(listing_time_aio, key = lambda x: x['entity'])
		listing_free_months_aio = [{"entity": to_int(entity), "month": to_int(entity_time)} for entity, entity_time in settings['listing_free_months_aio'].items()]
		listing_free_months_aio = sorted(listing_free_months_aio, key = lambda x: x['entity'])
		res_price = 0
		price_entity = 0
		res_time = 0
		time_entity = 0
		res_months = 0
		for row in listing_price_aio:
			if number_products <= row['entity']:
				price_entity = row['price']
				break
		res_price += price_entity
		for row in listing_time_aio:
			if number_products <= row['entity']:
				time_entity = row['time']
				break
		res_time += time_entity
		for row in listing_free_months_aio:
			if number_products <= row['entity']:
				res_months = row['month']
				break
		if to_len(source) > 1:
			res_price += (to_len(source) - 1) * 0.5 * price_entity
			res_time += (to_len(source) - 1) * 0.5 * time_entity
		if to_len(target) > 1:
			res_price += (to_len(target) - 1) * 0.5 * price_entity
			res_time += (to_len(target) - 1) * 0.5 * time_entity
		for entity_type in [source, target]:
			for cart in entity_type:
				if cart in settings['aio_add_price']:
					res_price *= to_decimal(settings['aio_add_price'][cart])
				if cart in settings['aio_add_time']:
					res_time *= to_decimal(settings['aio_add_time'][cart])
		return {"price": round(res_price), "fulfilment_time": round(res_time), "included_paid_months": res_months}


	def create_ticket_zendesk(self, user, **kwargs):

		tags = kwargs.get('tags')
		if not tags:
			tags = list()
		tags.append('litc')
		tags.append('luudt')
		ticket_data = {
			'subject': kwargs.get('subject'),
			'status': 'open',
			'priority': 'normal',
			'assignee_id': 417191399,
			'submitter_id': 417191399,
			'group_id': 23751916 if not kwargs.get('group') or kwargs['group'] == 'postsale' else 23358575,
			'tags': tags,
			'comment': kwargs.get('comment'),
			'requester': {
				'name': user.name,
				'email': user.email,
			},
			'type': 'task',
			'custom_fields': [
				{'id': 24334399, 'value': 'luudt'},  # assign cho luudt
			]
		}
		if kwargs.get('order_id'):
			ticket_data['custom_fields'].append(
				{
					'id': 23069295,
					'value': kwargs.get('order_id')
				}
			)
		url = "https://litextension.zendesk.com/api/v2/tickets.json"
		zendesk_user = get_config_ini('zendesk', 'user')
		zendesk_token = get_config_ini('zendesk', 'token')
		header_token = string_to_base64(f"{zendesk_user}/token:{zendesk_token}")
		headers = {
			'Content-type': 'application/json',
			'Authorization': f"Basic {header_token}"
		}
		if is_local():
			return False
		ticket_request = requests.post(url, json = {'ticket': ticket_data}, headers = headers)
		if ticket_request.status_code == 201:
			ticket = ticket_request.json()
			ticket_id = ticket['ticket']['id']
			return ticket_id
		return False


	def init_process(self, user_id, channel_id, process_type, total = 0):
		if total and total < 10:
			return 0
		model_process = CollectionProcess()
		model_process.set_user_id(user_id)
		live_process_id =  model_process.create({
			'total': total,
			'status': 'prepare',
			'channel_id': channel_id,
			'imported': 0,
			'error': 0,
			'process_type': process_type,
			'created_at': get_current_time()
		})
		from accounts.models import UserAccount
		UserAccount.objects.filter(id = user_id).update(have_process = True)
		return live_process_id

	def delete_process(self, user_id, process_id):
		if not process_id:
			return
		model_process = CollectionProcess()
		model_process.set_user_id(user_id)
		model_process.delete(process_id)


	def get_new_plan_default_id(self):
		return to_int(get_config_ini('server', 'default_plan_id'))