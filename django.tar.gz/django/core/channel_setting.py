# from rest_framework import generics, status
#
# class ChannelSettingAPIView(generics.ListAPIView):
# 	channel_setting_type = ''
