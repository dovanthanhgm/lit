from rest_framework import serializers

from libs.utils import to_int, to_str


class BaseSerializers(serializers.Serializer):
	def extend_serializers(self, data):
		for field, instance in self.fields.items():
			if isinstance(instance, serializers.IntegerField) and field in data:
				if to_str(data.get(field)):
					if to_str(data.get(field)).isnumeric():
						data[field] = to_int(data[field])
				else:
					data[field] = None
		return data


	def to_internal_value(self, data):
		data = self.extend_serializers(data)
		return super(BaseSerializers, self).to_internal_value(data)


class SerializerWithStatus(BaseSerializers):
	ENABLE = 'enable'
	DISABLE = 'disable'
	REQUIRED_FIELD = []
	status = serializers.ChoiceField(choices = (ENABLE, DISABLE), default = DISABLE, allow_null = True, allow_blank = True)


	def extend_serializers(self, data):
		data = super().extend_serializers(data)
		for field, serializer_class in self.fields.items():
			serializer_class.required = False
		if data.get('status') == self.ENABLE:
			for field in self.REQUIRED_FIELD:
				self.fields[field].required = True
		return data
