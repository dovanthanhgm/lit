from datetime import date

from background_task.models import CompletedTask
from django.core.management.base import BaseCommand
import dateutil.relativedelta

class Command(BaseCommand):
	help = "Import file to django"


	def handle(self, *args, **options):
		today = date.today() - dateutil.relativedelta.relativedelta(days = 7)
		CompletedTask.objects.filter(run_at__lte = today).delete()