from datetime import date

from django.core.management import BaseCommand
from django.forms import model_to_dict

from crisp.models import CrispUserModel, CrispUserHistoryModel
from libs.utils import to_int


class Command(BaseCommand):
	def handle(self, *args, **options):
		users = CrispUserModel.objects.all()
		del_fields = ['id', 'status']
		today = date.today()
		accounting = to_int(today.strftime('%Y%m'))
		for user in users:
			data = model_to_dict(user)
			for field in del_fields:
				del data[field]
			data['accounting'] = accounting
			CrispUserHistoryModel.objects.update_or_create(data, accounting = accounting, email = data['email'])