import sys
from django.core.management.base import BaseCommand

from libs.utils import json_encode
from servers.models import Server
from datasync.api.sync import SyncApi
from servers.utils import ServerUtils


class Command(BaseCommand):
	help = "Update status for datasync servers."

	def handle(self, *args, **options):
		ServerUtils().refresh()
