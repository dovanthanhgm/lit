from django.core.management import BaseCommand

from crisp.api import CrispApi
from crisp.models import CrispConversationModel
from libs.utils import convert_format_time


class Command(BaseCommand):
	def handle(self, *args, **options):
		model = CrispApi()
		page = 1
		while True:
			conversations = model.get_conversations(page)
			if not conversations:
				break
			for conversation_data in conversations:
				CrispConversationModel.objects.create(session_id = conversation_data['session_id'],
				                                      customer_name = conversation_data['meta']['nickname'],
				                                      customer_email = conversation_data['meta']['email'],
				                                      updated_at = convert_format_time(conversation_data['updated_at']),
				                                      created_at = convert_format_time(conversation_data['created_at']),
				                                      state = conversation_data['state'],
				                                      have_new_message = True,
				                                      segments = ','.join(conversation_data['meta'].get('segments') or []),

				                                      )
			page += 1
