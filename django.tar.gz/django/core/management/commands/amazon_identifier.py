from django.core.management.base import BaseCommand

from channels.models import Channel
from libs.models.collections.state import State
from libs.utils import json_decode
from processes.models import Process


class Command(BaseCommand):
	help = "Import file to django"
	MARKETPLACE_IDS = {
		'A2EUQ1WTGCTBG2': 'CA',
		'ATVPDKIKX0DER': 'US',
		'A1AM78C64UM0Y8': 'MX',
		'A2Q3Y263D00KWC': 'BR',
		'A1RKKUPIHCS9HS': 'ES',
		'A1F83G8C2ARO7P': 'GB',
		'A13V1IB3VIYZZH': 'FR',
		'A1805IZSGTT6HS': 'NL',
		'A1PA6795UKMFR9': 'DE',
		'APJ6JRA9NG5V4': 'IT',
		'A2NODRKZP88ZB9': 'SE',
		'A1C3SOZRARQ6R3': 'PL',
		'ARBP9OOSHTCHU': 'EG',
		'A33AVAJ2PDY3EV': 'TR',
		'A2VIGQ35RCS4UG': 'AE',
		'A21TJRUUN4KGV': 'IN',
		'A19VAU5U5O7RUS': 'SG',
		'A39IBJ37TRP1C6': 'AU',
		'A1VC38T7YXB528': 'JP',
	}

	def handle(self, *args, **options):
		channels = Channel.objects.filter(type = 'amazon')
		for channel in channels:
			identifier = channel.identifier
			api = json_decode(channel.api)
			if not api or not api.get('marketplace_id'):
				continue
			identifier += f"-{self.MARKETPLACE_IDS[api['marketplace_id']]}"
			state = State()
			state.set_user_id(channel.user_id)
			processes = Process.objects.filter(channel_id = channel.id)
			for process in processes:
				state.update_field(process.state_id, 'channel.identifier', identifier)
			channel.identifier = identifier
			channel.save()
