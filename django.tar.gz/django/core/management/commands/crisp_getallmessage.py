from datetime import datetime

from django.core.management import BaseCommand

from crisp.api import CrispApi
from crisp.models import CrispConversationModel, CrispMessageModel
from libs.utils import convert_format_time, to_int, to_str, log_traceback


class Command(BaseCommand):
	def handle(self, *args, **options):
		model = CrispApi()
		page = 1
		conversations = CrispConversationModel.objects.filter(have_new_message = True)
		for conversation in conversations:
			first_message_in_shift = {}
			before_timestamp = False
			before_timestamp_filter = False
			time_last_message = to_int(conversation.time_last_message)
			try:
				conversation_data = model.get_conversation(conversation.session_id)
			except:
				conversation_data = False
				conversation.state = 'resolved'
			all_messages = []
			if conversation_data:
				conversation.segments = ','.join(conversation_data['meta'].get('segments') or [])
				first = True
				while True:
					try:
						messages = model.get_messages_in_conversation(conversation.session_id, before_timestamp_filter)
					except Exception:
						messages = False
						conversation.state = 'resolved'
					if not messages:
						break
					if first:
						time_last_message = to_int(to_str(messages[-1]['timestamp'])[0:10])
						if time_last_message <= to_int(conversation.time_last_message) or time_last_message < 1664582400:
							break
						lass_message = messages[-1]
						if 'state:resolved' in to_str(lass_message['content']) and lass_message['from'] == 'operator' and lass_message['type'] == 'event' and to_str(lass_message['user']['nickname']).lower() in list(map(lambda x: to_str(x).lower(), ['litCommerce', 'Jenny Doan', 'Lại Văn Nam', 'Kevin Nguyen'])):
							conversation.is_skip = True
						first = False
					before_timestamp_filter = messages[0]['timestamp']
					before_timestamp = to_int(to_str(messages[0]['timestamp'])[0:10])
					page_messages = []
					for message in messages:
						if not message.get('user'):
							continue
						timestamp = to_int(to_str(message['timestamp'])[0:10])
						if timestamp <= to_int(to_int(conversation.time_last_message)) or timestamp < 1664582400:
							continue
						page_messages.append(message)

					page_messages.reverse()
					all_messages.extend(page_messages)
					if to_int(before_timestamp) < to_int(conversation.time_last_message):
						break
			all_messages.reverse()
			for message in all_messages:
				timestamp = to_int(to_str(message['timestamp'])[0:10])
				try:
					message_time = datetime.fromtimestamp(timestamp)
					accounting = message_time.strftime('%Y%m%d')
					message_hour = message_time.hour
					shift = message_hour // 4
					if shift not in first_message_in_shift:
						first_message = CrispMessageModel.objects.filter(message_shift_id = f"{message['session_id']}-{accounting}-{message_hour // 4}", from_operator = True).exclude(type__in = ['note', 'event']).order_by('message_time').first()
						if first_message:
							first_message_in_shift[shift] = True
						else:
							first_message_in_shift[shift] = False

					message_data = dict(message_id = message['fingerprint'],
					                    delivered = message['delivered'],
					                    session_id = message['session_id'],
					                    read = message['read'],
					                    from_user = message['user'].get('user_id'),
					                    from_nickname = message['user']['nickname'],
					                    content = message['content'],
					                    type = message['type'],
					                    origin = message['origin'],
					                    timestamp = convert_format_time(to_int(to_str(message['timestamp'])[0:10])),
					                    from_operator = True if message['from'] == 'operator' else False,
					                    message_time = timestamp,
					                    shift = message_hour // 4,
					                    accounting = accounting,
					                    message_shift_id = f"{message['session_id']}-{accounting}-{message_hour // 4}"
					                    )
					if message['from'] in ['operator', 'user'] and message['user']['nickname'] not in ['LitCommerce'] and message['type'] not in ['event', 'note']:
						if not conversation.max_position:
							conversation.max_position = 1
							conversation.first_max_position_message = timestamp
						else:
							if message['from'] != conversation.last_message_from:

								start_time = conversation.first_max_position_message
								start_datetime_hour = datetime.fromtimestamp(start_time).hour
								start_datetime_shift = start_datetime_hour // 4
								start_datetime_day = datetime.fromtimestamp(start_time).day
								if message['from'] == 'operator' and start_datetime_hour < 8:
									start_shift_time = message_time.strftime(f'%Y-%m-%d 08:00:00')
									shift_datetime = datetime.strptime(start_shift_time, "%Y-%m-%d %H:%M:%S")
									start_time = shift_datetime.timestamp()
								conversation.max_position += 1
								# if message['from'] == 'operator':
								message_data['response_time'] = timestamp - start_time
								if start_datetime_day == message_time.day and not first_message_in_shift[shift] and message['from'] == 'operator' and start_datetime_hour >= 8 and start_datetime_shift == message_data['shift'] and message_data['response_time'] > 60:
									message_data['exceed_one_minute'] = True
								if message['from'] == 'operator' and not first_message_in_shift[shift]:
									first_message_in_shift[shift] = True
									message_data['is_first_message'] = True
								conversation.first_max_position_message = timestamp
						message_data['position'] = conversation.max_position
						conversation.last_message_from = message['from']

					CrispMessageModel.objects.create(**message_data)

				except Exception as e:
					log_traceback()
					pass
			conversation.time_last_message = time_last_message
			if conversation.state == 'resolved':
				conversation.have_new_message = False
			conversation.save()
