import csv
import os

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from channels.models import Channel
from datasync.views import SyncApi
from libs.models.collections.state import State
from libs.utils import json_decode
from processes.models import Process


class Command(BaseCommand):
	help = "Import file to django"


	def handle(self, *args, **options):
		channels = Channel.objects.filter(type = 'ebay')
		for channel in channels:
			identifier = channel.identifier
			api = json_decode(channel.api)
			if not api or not api.get('marketplace_id'):
				continue
			identifier += f"-{api['marketplace_id']}"
			state = State()
			state.set_user_id(channel.user_id)
			processes = Process.objects.filter(channel_id = channel.id)
			for process in processes:
				state.update_field(process.state_id, 'channel.identifier', identifier)
			channel.identifier = identifier
			channel.save()
