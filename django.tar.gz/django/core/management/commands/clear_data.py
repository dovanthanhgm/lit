from datetime import date

from django.core.management import BaseCommand
import dateutil.relativedelta
from django.db.models import Q

from accounts.models import UserAccount
from channels.models import Channel
from libs.models.collections.activities import Activities
from libs.models.collections.attributes import Attributes
from libs.models.collections.catalog import Catalog
from libs.models.collections.category import Category
from libs.models.collections.order import CollectionOrder
from subscription.models import UserSubscription


class Command(BaseCommand):
	def delete_all(self, user_id):
		model_delete = [Catalog(), CollectionOrder(), Activities(), Category(), Attributes()]
		for model in model_delete:
			model.set_user_id(user_id)
			model.delete_all()
		Channel.objects.filter(user_id = user_id).update(last_imported = None, channel_number_products = None, number_products = 0, number_products_linked = 0)
		UserAccount.objects.filter(id = user_id).update(delete_all_data_in = None)

	def delete_data_for_free_account(self):
		datefilter = date.today() - dateutil.relativedelta.relativedelta(months = 2)
		delete_in = date.today() + dateutil.relativedelta.relativedelta(days = 3)

		queryset = UserSubscription.objects.filter().exclude(plan_id = 1).values('user_id')
		channel_filter = Channel.objects.filter(deleted_at__isnull = True).values('user_id')
		user_free = UserAccount.objects.exclude(id__in = queryset).filter(Q(last_access__isnull = True) | Q(last_access__lte = datefilter.strftime('%Y-%m-%d 23:59:59'))).filter(solve_delete_free_data = False, id__in = channel_filter)[0:200]
		solve_delete_free_data = []
		for user in user_free:
			user.send_email_template('catalog-deleted-reminder')
			solve_delete_free_data.append(user.id)
		UserAccount.objects.filter(id__in = solve_delete_free_data).update(solve_delete_free_data = True, delete_all_data_in = delete_in)


	def delete_all_data_for_expired_account(self):
		datefilter = date.today() - dateutil.relativedelta.relativedelta(years = 1)
		delete_in = date.today() + dateutil.relativedelta.relativedelta(days = 3)
		lasst_access_datefilter = date.today() - dateutil.relativedelta.relativedelta(months = 2)
		channel_filter = Channel.objects.filter(deleted_at__isnull = True).values('user_id')

		queryset = UserSubscription.objects.exclude(plan_id = 1).filter(auto_renew = False, expired_at__lte = datefilter.strftime('%Y-%m-%d 23:59:59')).values('user_id')
		user_expired = UserAccount.objects.filter(Q(last_access__isnull = True) | Q(last_access__lte = lasst_access_datefilter.strftime('%Y-%m-%d 23:59:59'))).filter(id__in = queryset, solve_delete_expired_data_1 = False).filter(id__in = channel_filter)

		solve_delete_free_data = []

		for user in user_expired:
			user.send_email_template('catalog-deleted-reminder')
			user.delete_all_data_in = delete_in
			solve_delete_free_data.append(user.id)
		UserAccount.objects.filter(id__in = solve_delete_free_data).update(solve_delete_expired_data_1 = True, delete_all_data_in = delete_in)


	def delete_unlist_data_for_expired_account(self):
		datefilter = date.today() - dateutil.relativedelta.relativedelta(months = 2)
		delete_in = date.today() + dateutil.relativedelta.relativedelta(days = 3)
		lasst_access_datefilter = date.today() - dateutil.relativedelta.relativedelta(months = 2)
		channel_filter = Channel.objects.filter(deleted_at__isnull = True).values('user_id')

		queryset = UserSubscription.objects.exclude(plan_id = 1).filter(auto_renew = False, expired_at__lte = lasst_access_datefilter.strftime('%Y-%m-%d 23:59:59')).values('user_id')
		solve_delete_free_data = []
		user_expired = UserAccount.objects.exclude(id__in = queryset).filter(Q(last_access__isnull = True) | Q(last_access__lte = datefilter.strftime('%Y-%m-%d 23:59:59'))).filter(solve_delete_expired_data_1 = False, solve_delete_expired_data_2 = True)

		for user in user_expired:
			user.send_email_template('catalog-delete-unlisted-reminder')
			user.delete_unlisted_data_in = delete_in
			solve_delete_free_data.append(user.id)
		UserAccount.objects.filter(id__in = solve_delete_free_data).update(solve_delete_expired_data_2 = True, delete_unlisted_data_in = delete_in)


	def handle(self, *args, **options):
		self.delete_data_for_free_account()
		self.delete_all_data_for_expired_account()
		self.delete_unlist_data_for_expired_account()
		datefilter = date.today() - dateutil.relativedelta.relativedelta(months = 2)
		delete_in = date.today()
		user_expired = UserAccount.objects.exclude(delete_all_data_in__isnull = True).filter(Q(last_access__isnull = True) | Q(last_access__lte = datefilter.strftime('%Y-%m-%d 23:59:59'))).filter(delete_all_data_in__lte = delete_in.strftime('%Y-%m-%d'))
		for user in user_expired:
			self.delete_all(user.id)
