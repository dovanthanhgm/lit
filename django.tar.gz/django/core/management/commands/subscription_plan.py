import time
import traceback

import dateutil.relativedelta
from datetime import date, datetime

from django.core.management import BaseCommand
from django.forms import model_to_dict

from accounts.utils import AccountUtils
from channels.utils import ChannelUtils
from core.utils import CoreUtils
from libs.utils import to_str, notify_admins
from payments.paypal_api import PaypalApi
from subscription.models import UserSubscription, SubscriptionRenewException
from subscription.utils import SubscriptionUtils


class Command(BaseCommand):
	help = "Check subscription is expired."


	def handle(self, *args, **options):
		today = date.today().strftime("%Y-%m-%d 23:59:59")
		plan_expired = UserSubscription.objects.filter(expired_at__lte = today, solve_expired = False).exclude(plan_id = 1)
		paypal_api = PaypalApi()
		for plan in plan_expired:
			try:
				user = plan.user
				subscription_plan = plan.plan
				old_plan = model_to_dict(plan)
				old_plan.update(model_to_dict(subscription_plan))
				old_plan['started_at'] = old_plan['started_at'].strftime("%Y-%m-%d %H:%M:%S")
				old_plan['expired_at'] = old_plan['expired_at'].strftime("%Y-%m-%d %H:%M:%S") if old_plan['expired_at'] else False
				old_plan['expired'] = True
				old_plan['user_plan'] = model_to_dict(subscription_plan)
				old_plan.update(model_to_dict(subscription_plan))
				if plan.auto_renew:
					if plan.paypal_subscription_id:
						subscription = paypal_api.get_subscription_info(plan.paypal_subscription_id)
						if subscription and subscription['status'] == 'ACTIVE':
							next_billing = subscription['billing_info']['next_billing_time']
							next_billing_datetime = datetime.strptime(next_billing, '%Y-%m-%dT%H:%M:%SZ') + dateutil.relativedelta.relativedelta(hours = 7)
							if next_billing_datetime.timestamp() > time.time():
								data = dict(user = user, new_plan = subscription_plan, old_plan = old_plan, yearly_paid = plan.yearly_paid, auto_renew = True)
								data.update(dict(note = f'Auto Renew From Paypal', order_from = 'paypal', paypal_subscription_id = plan.paypal_subscription_id))
								SubscriptionUtils().new_user_subscription_plan(**data)
								continue
					else:
						channel_payment = None
						if plan.channel_payment:
							channel = ChannelUtils().get(plan.channel_payment)
							channel_payment = plan.channel_payment
						else:
							channel = ChannelUtils().get_default_channel(user_id = user.id)
						if channel and channel.type in ['wix', 'shopify']:
							model_utils = CoreUtils().get_channel_model_utils(channel.type)
							before_renew = True
							total = 0
							if model_utils and hasattr(model_utils, 'before_renew_subscription'):
								before_renew, total = model_utils.before_renew_subscription(user, channel)
							if before_renew:
								data = dict(user = user, new_plan = subscription_plan, old_plan = old_plan, yearly_paid = plan.yearly_paid, auto_renew = True, channel_payment = channel_payment)
								data.update(dict(note = f'Auto Renew From {to_str(channel.type).capitalize()} App', order_from = channel.type))
								if total:
									data['total'] = total
									data['subtotal'] = total
								SubscriptionUtils().new_user_subscription_plan(**data)

								continue
					plan.auto_renew = False
				price = subscription_plan.yearly_fee if plan.yearly_paid else subscription_plan.monthly_fee
				if user.balance >= price:
					SubscriptionUtils().new_user_subscription_plan(user, new_plan = subscription_plan, old_plan = old_plan, yearly_paid = plan.yearly_paid, deducted_balance = True)
					context = {
						'plan_name': subscription_plan.name,
						# 'plan_expired_date': plan.expired_at.strftime("%B %d, %Y"),

					}
					user.send_email_template('plan-auto-renewed', context)
					continue
				AccountUtils().user_expired(user)
				if user.is_trial:
					user.send_email_template('free-trial-ended')
				plan.solve_expired = True
				plan.save()
			except Exception:
				notify_admins()
				error = traceback.format_exc()
				SubscriptionRenewException.objects.create(
					user_id = plan.user_id,
					plan_id = plan.id,
					exceptions = error
				)
