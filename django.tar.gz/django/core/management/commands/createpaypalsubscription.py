from django.core.management import BaseCommand

from payments.paypal_api import PaypalApi
from subscription.models import Subscription


class Command(BaseCommand):
	def handle(self, *args, **options):
		paypal_api = PaypalApi()
		subscription = Subscription.objects.filter(paypal_monthly_plan_id__isnull = True).exclude(id = 1)
		for row in subscription:
			paypal_monthly_plan_id = paypal_api.create_subscription_plan(row, yearly_paid = False)
			if not paypal_monthly_plan_id:
				continue
			row.paypal_monthly_plan_id = paypal_monthly_plan_id
			if row.type == 'system':
				paypal_yearly_plan_id = paypal_api.create_subscription_plan(row, yearly_paid = True)
				if not paypal_yearly_plan_id:
					continue
				row.paypal_yearly_plan_id = paypal_yearly_plan_id
			row.save()