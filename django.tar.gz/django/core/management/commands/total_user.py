import dateutil.relativedelta
from datetime import datetime

from django.core.management import BaseCommand

from core.myadmin.utils import MyAdminUtils
from datasync.models import TotalUserReport
from libs.utils import json_encode


class Command(BaseCommand):
	def handle(self, *args, **options):
		report_data = MyAdminUtils().total_user_report()
		report_data['details_user_active'] = json_encode(report_data['details_user_active'])
		report_data['details_user_active_monthly'] = json_encode(report_data['details_user_active_monthly'])
		today = datetime.today()
		accounting_day = (today - dateutil.relativedelta.relativedelta(days = 1)).strftime('%Y%m%d')
		TotalUserReport.objects.update_or_create(defaults = report_data, accounting = accounting_day, report_type = 'day')
		if today.day == 1:
			accounting_month = (today - dateutil.relativedelta.relativedelta(months = 1)).strftime('%Y%m')
			TotalUserReport.objects.update_or_create(defaults = report_data, accounting = accounting_month, report_type = 'month')
			if today.month == 1:
				accounting_year = (today - dateutil.relativedelta.relativedelta(years = 1)).strftime('%Y')
				TotalUserReport.objects.update_or_create(defaults = report_data, accounting = accounting_year, report_type = 'year')
