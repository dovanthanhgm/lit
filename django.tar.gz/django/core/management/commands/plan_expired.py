from datetime import date

from django.core.management import BaseCommand
import dateutil.relativedelta
from django.forms import model_to_dict

from channels.models import Channel
from channels.utils import ChannelUtils
from libs.models.collections.state import State
from libs.utils import to_int
from subscription.models import UserSubscription
from subscription.utils import SubscriptionUtils


class Command(BaseCommand):
	help = "Check subscription is expired."


	def handle(self, *args, **options):
		today = date.today() + dateutil.relativedelta.relativedelta(days = 7)
		plan_expired = UserSubscription.objects.filter(expired_at__lte = today, plan_expired_noti_1 = False, solve_expired = False).exclude(plan_id = 1)
		for plan in plan_expired:
			plan.plan_expired_noti_1 = True
			plan.save()
			user = plan.user
			subscription_plan = plan.plan
			old_plan = model_to_dict(plan)
			old_plan.update(model_to_dict(subscription_plan))
			old_plan['started_at'] = old_plan['started_at'].strftime("%Y-%m-%d %H:%M:%S")
			old_plan['expired_at'] = old_plan['expired_at'].strftime("%Y-%m-%d %H:%M:%S") if old_plan['expired_at'] else False
			old_plan.update(model_to_dict(subscription_plan))
			if plan.auto_renew or not old_plan['expired_at'] or not plan.yearly_paid:
				continue
			price = subscription_plan.yearly_fee if plan.yearly_paid else subscription_plan.monthly_fee
			if user.balance >= price:
				continue
			context = {
				'plan_name': subscription_plan.name,
				'plan_expired_date': plan.expired_at.strftime("%B %d, %Y"),

			}
			user.send_email_template('plan-expired-noti-1', context)