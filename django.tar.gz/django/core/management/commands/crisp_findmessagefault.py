import copy

from django.core.management import BaseCommand
import dateutil.relativedelta
from datetime import date, datetime

from crisp.models import CrispConversationModel, CrispMessageModel, CrispMessageFaults, CrispUserMessageFaults, CrispConversationNoReply, CrispUserModel
from libs.utils import to_int, to_str, json_decode


class Command(BaseCommand):
	def handle(self, *args, **options):
		today = date.today() - dateutil.relativedelta.relativedelta(days = 1)
		self.find_by_accounting(today)

	def find_by_accounting(self, day):
		accounting = to_int(day.strftime('%Y%m%d'))
		weekday = to_str(day.strftime('%a')).lower()
		users = list(CrispUserModel.objects.filter(status = True))
		day.weekday()
		shift_data = list()
		for shift in range(0, 6):
			day_data = list()
			for user in users:
				day_shift = json_decode(getattr(user, f'shift_{weekday}'))
				if day_shift and to_str(shift) in day_shift:
					day_data.append(user.name)

			shift_data.append(day_data)
		conversations_shift0 = CrispMessageModel.objects.filter(accounting = accounting, shift__in = [0, 1], from_operator = False).values('session_id').distinct().order_by('session_id')
		conversations_no_reply = list()
		for row in conversations_shift0:
			check_reply = CrispMessageModel.objects.filter(accounting = accounting, shift__in = [0, 1], session_id = row['session_id']).first()
			if check_reply.from_operator:
				continue
			check_reply = CrispMessageModel.objects.filter(accounting = accounting, shift__in = [0, 1], from_operator = True, session_id = row['session_id']).exclude(type__in = ['event', 'note']).count()
			if not check_reply:
				conversations_no_reply.append(row['session_id'])
		conversations_no_reply_data = {}
		copy_conversations_no_reply = copy.deepcopy(conversations_no_reply)
		conversations_no_reply = []
		for row in copy_conversations_no_reply:

			conversation_data = {}
			first_message, content = self.get_first_message(accounting, [0, 1], row)
			conversation_data['message_time'] = first_message.message_time
			conversation_data['timestamp'] = first_message.timestamp
			conversation_data['content'] = '\n'.join(content)
			if conversation_data['content'].find('Smart Feedback') != -1 or conversation_data['content'].find('**Guest Post Request**') != -1 or ((conversation_data['content'].find('Feature Request**') != -1 or conversation_data['content'].find('Feedback**') != -1 or conversation_data['content'].find('Survey**') != -1) and conversation_data['content'].find('sendgrid.net') != -1):
				continue
			conversations_no_reply.append(row)
			conversations_no_reply_data[row] = conversation_data
		conversation_fault = CrispConversationNoReply.objects.all()
		for row in conversation_fault:
			if row.session_id in conversations_no_reply:
				continue
			conversations_no_reply.append(row.session_id)
			conversations_no_reply_data[row.session_id] = {
				'timestamp': row.timestamp,
				'message_time': row.message_time,
				'content': row.customer_content,
			}
		conversation_in_shift = {}
		for shift in range(2, 6):
			start_hour = shift * 4
			if start_hour < 10:
				start_hour = f'0{start_hour}'
			end_hour = (shift + 1) * 4 - 1
			if end_hour < 10:
				end_hour = f'0{end_hour}'
			start_shift_time = day.strftime(f"%Y-%m-%d {start_hour}:00:00")
			end_shift_time = day.strftime(f"%Y-%m-%d {end_hour}:00:00")
			# staff_in_shift_obj = CrispMessageModel.objects.filter(accounting = accounting, shift = shift, from_operator = True, timestamp__gte = start_shift_time, timestamp__lte = end_shift_time).exclude(type__in = ['event', 'note']).values('from_nickname').distinct().order_by('from_nickname')
			staff_in_shift = shift_data[shift]
			check_reply = CrispMessageModel.objects.filter(accounting = accounting, shift = shift, session_id__in = conversations_no_reply).values('session_id').distinct().order_by('session_id')
			no_reply_in_shift = [row['session_id'] for row in check_reply]
			copy_conversations_no_reply = copy.deepcopy(conversations_no_reply)
			conversations_no_reply = []
			for row in copy_conversations_no_reply:
				if row not in no_reply_in_shift:
					conversation_data = conversations_no_reply_data[row]
					is_fault = self.message_fault(accounting, row, shift, conversation_data, fault_type = 2, staffs = staff_in_shift, conversation_in_shift = conversation_in_shift)
					if is_fault:
						conversations_no_reply.append(row)
			conversations = CrispMessageModel.objects.filter(accounting = accounting, shift = shift, from_operator = False).values('session_id').distinct().order_by('session_id')
			conversation_in_shift[shift] = []
			for session in conversations:
				session_id = session['session_id']
				conversation_in_shift[shift].append(session_id)
				message_shift_id = f"{session_id}-{accounting}-{shift}"
				first_customer_message = CrispMessageModel.objects.filter(message_shift_id = message_shift_id, from_operator = False).order_by('message_time').first()
				first_staff_message = CrispMessageModel.objects.filter(message_shift_id = message_shift_id, from_operator = True).order_by('message_time').first()
				customer_message = CrispMessageModel.objects.filter(message_shift_id = message_shift_id, from_operator = False, position = first_customer_message.position)
				content = []
				for row in customer_message:
					content.append(row.content)
				first_customer_message_data = {
					'message_time': first_customer_message.message_time,
					'timestamp': first_customer_message.timestamp,
					'content': '\n'.join(content),
				}
				if not first_staff_message:
					first_time = datetime.fromtimestamp(first_customer_message.message_time)

					if first_time.hour == (shift * 4 + 3) and first_time.minute > 55:
						continue
					if first_customer_message_data['content'].find('Smart Feedback') != -1 or first_customer_message_data['content'].find('**Guest Post Request**') != -1 or ((first_customer_message_data['content'].find('Feature Request**') != -1 or first_customer_message_data['content'].find('Feedback**') != -1 or first_customer_message_data['content'].find('Survey**') != -1) and first_customer_message_data['content'].find('sendgrid.net') != -1):
						continue
					is_fault = self.message_fault(accounting, session_id, shift, first_customer_message_data, fault_type = 2, staffs = staff_in_shift, conversation_in_shift = conversation_in_shift)
					if is_fault:
						conversations_no_reply.append(session_id)
						conversations_no_reply_data[session_id] = first_customer_message_data
					continue
				first_time = datetime.fromtimestamp(first_customer_message.message_time)
				if first_customer_message.origin != 'chat' or (first_time.hour == (shift * 4 + 3) and first_time.minute > 30):
					continue
				if shift != 2:
					previous_shift_message = CrispMessageModel.objects.filter(session_id = session_id, shift = shift - 1, accounting = accounting).exclude(type__in = ['event', 'note']).last()

					if previous_shift_message:
						last_time_msg = datetime.fromtimestamp(previous_shift_message.message_time)
						if last_time_msg.hour == ((shift - 1) * 4 + 3) and last_time_msg.minute > 30:
							continue

				staff_message = CrispMessageModel.objects.filter(message_shift_id = message_shift_id, from_operator = True, position = first_staff_message.position).exclude(type__in = ['event', 'note'])
				staff_content = []
				for row in staff_message:
					staff_content.append(row.content)
				first_customer_message_data['staff_content'] = '\n'.join(staff_content)
				first_customer_message_data['reply_time'] = first_staff_message.timestamp
				if first_staff_message.message_time - first_customer_message.message_time > 180:
					self.message_fault(accounting, session_id, shift, first_customer_message_data, fault_type = 1, staffs = staff_in_shift, response_time = first_staff_message.message_time - first_customer_message.message_time, conversation_in_shift = conversation_in_shift)
		CrispConversationNoReply.objects.all().delete()
		if conversations_no_reply:
			for row in conversations_no_reply:
				conversation_data = conversations_no_reply_data[row]
				CrispConversationNoReply.objects.create(session_id = row, customer_content = conversation_data['content'], timestamp = conversation_data['timestamp'], message_time = conversation_data['message_time'])

	def get_first_message(self, accounting, shifts, session_id, from_operator = False):
		if not isinstance(shifts, list):
			shifts = [shifts]
		messages = CrispMessageModel.objects.filter(accounting = accounting, shift__in = shifts, from_operator = from_operator, session_id = session_id).order_by('message_time')
		content = []
		first_message = messages[0]
		for index, message in enumerate(messages):
			content.append(message.content)
		return first_message, content


	def is_ignore_session(self, session_id):
		session = CrispConversationModel.objects.filter(session_id = session_id).first()
		if not session or session.is_blocked or session.is_skip:
			return True
		email_ignore = ['shopify.com', 'trustpilot.com', 'bigcommerce.com', 'squarespace.com', 'wix.com', 'walmart.com', 'onbuy.com', 'litcommerce.com']
		for row in email_ignore:
			if session.customer_email.find(f'{row}') != -1:
				return True

		return False

	def message_fault(self, accounting, session_id, shift, conversation_data, fault_type, staffs, response_time = 0, conversation_in_shift = {}):
		if self.is_ignore_session(session_id):
			return False
		if to_str(conversation_data.get('staff_content')).find('Delivered by Zendesk') != -1:
			return False
		if fault_type == 1 and conversation_in_shift.get(shift - 1) and session_id in conversation_in_shift[shift - 1]:
			return False
		data = dict(reply_content = conversation_data.get('staff_content'), customer_content = conversation_data['content'], timestamp = conversation_data['timestamp'], message_time = conversation_data['message_time'], session_id = session_id, shift = shift, fault_type = fault_type, accounting_month = to_str(accounting)[0:6], accounting_day = accounting, staff_fault = '\n'.join(staffs))
		if response_time:
			data['response_time'] = response_time
		if conversation_data.get('reply_time'):
			data['reply_time'] = conversation_data.get('reply_time')
		message_fault = CrispMessageFaults.objects.create(**data)
		for staff in staffs:
			staff_data = dict(message_fault_id = message_fault.id, session_id = session_id, from_nickname = staff, fault_type = fault_type, accounting_month = to_str(accounting)[0:6], accounting_day = accounting, shift = shift)
			if response_time:
				staff_data['response_time'] = response_time
			CrispUserMessageFaults.objects.create(**staff_data)
		return True
