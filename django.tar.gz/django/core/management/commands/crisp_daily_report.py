from datetime import date, datetime

from django.core.management import BaseCommand
from django.db.models import Q, Count
from django.forms import CharField

from crisp.api import CrispApi
from crisp.models import CrispConversationModel, CrispUserModel, CrispMessageModel, CrispUserHistoryModel, CrispDailyReportModel
from libs.utils import convert_format_time, to_int
import dateutil.relativedelta
from django.db.models import Aggregate


class GroupConcat(Aggregate):
	function = 'GROUP_CONCAT'
	template = '%(function)s(%(distinct)s%(expressions)s)'
	allow_distinct = True


	def __init__(self, expression, distinct = False, **extra):
		super(GroupConcat, self).__init__(
			expression,
			distinct = 'DISTINCT ' if distinct else '',
			**extra)


class Command(BaseCommand):

	def handle(self, *args, **options):
		today = date.today() - dateutil.relativedelta.relativedelta(days = 1)
		self.find_by_accounting(today)


	def find_by_accounting(self, today):
		message_shift_ids = list(CrispMessageModel.objects.filter(accounting = today.strftime('%Y%m%d')).values('message_shift_id').distinct().order_by('message_shift_id'))
		message_shift_chat = list(CrispMessageModel.objects.filter(accounting = today.strftime('%Y%m%d'), from_operator = False).exclude(Q(delivered = 'email') & Q(origin = 'email')).values('message_shift_id').distinct().order_by('message_shift_id'))
		message_shift_ids = [row['message_shift_id'] for row in message_shift_ids]
		message_shift_chat = [row['message_shift_id'] for row in message_shift_chat]
		message_shift_emails = list(set(message_shift_ids) - set(message_shift_chat))
		accounting_month = today.strftime('%Y%m')
		if accounting_month == datetime.today().strftime('%Y%m'):
			all_cs_queryset = CrispUserModel.objects.all()
		else:
			all_cs_queryset = CrispUserHistoryModel.objects.filter(accounting = accounting_month)

		all_staff = {}
		for row in all_cs_queryset:
			all_staff[row.name] = row.level
		all_staff_name = list(all_staff.keys())
		time_filter = dict(
			accounting = today.strftime('%Y%m%d'), from_operator = True, from_nickname__in = all_staff_name
		)
		exclude = dict(type__in = ['note', 'event'])
		query_set_chat = CrispMessageModel.objects.filter(message_shift_id__in = message_shift_chat, **time_filter).exclude(**exclude).values('from_nickname').order_by().annotate(total_session = Count('session_id', distinct = True), total_chat = Count('message_shift_id', distinct = True), total_message = Count('message_id', distinct = True), sessions = GroupConcat('session_id', distinct = True), sessions_shift = GroupConcat('message_shift_id'))
		query_set_email = CrispMessageModel.objects.filter(message_shift_id__in = message_shift_emails, **time_filter).exclude(**exclude).values('from_nickname').order_by().annotate(total_session = Count('session_id', distinct = True), total_chat = Count('message_shift_id', distinct = True), total_message = Count('message_id', distinct = True), sessions = GroupConcat('session_id', distinct = True), sessions_shift = GroupConcat('message_shift_id'))
		query_set_chat = list(query_set_chat)
		query_set_email = list(query_set_email)
		staff_chats = {}
		for row in query_set_chat:
			sessions = list(set(row['sessions'].split(',')))
			sessions_shift = list(set(row['sessions_shift'].split(',')))
			row['sessions'] = '\n'.join(sessions)
			row['sessions_shift'] = '\n'.join(sessions_shift)
			staff_chats[row['from_nickname']] = row
		staff_emails = {}
		for row in query_set_email:
			sessions = list(set(row['sessions'].split(',')))
			sessions_shift = list(set(row['sessions_shift'].split(',')))
			row['sessions'] = '\n'.join(sessions)
			row['sessions_shift'] = '\n'.join(sessions_shift)
			staff_emails[row['from_nickname']] = row
		reports = []
		for staff in all_staff_name:
			query_set_chat = CrispMessageModel.objects.filter(message_shift_id__in = message_shift_chat, **time_filter).exclude(**exclude).values('from_nickname').order_by().annotate(total_session = Count('session_id', distinct = True), total_chat = Count('message_shift_id', distinct = True), total_message = Count('message_id', distinct = True), sessions = GroupConcat('session_id'), sessions_shift = GroupConcat('message_shift_id'))

			staff_chat = staff_chats.get(staff) or {}
			staff_email = staff_emails.get(staff) or {}
			staff_data = dict(
				from_nickname = staff,
				accounting_month = accounting_month,
				accounting_day = today.strftime('%Y%m%d'),
				number_of_chats = to_int(staff_chat.get('total_chat')),
				number_of_emails = to_int(staff_email.get('total_chat')),
				number_of_messages = to_int(staff_email.get('total_message')) + to_int(staff_chat.get('total_message')),
				number_of_sessions = to_int(staff_email.get('total_session')) + to_int(staff_chat.get('total_session')),
				session_chats = staff_chat.get('sessions'),
				session_shift_chats = staff_chat.get('sessions_shift'),
				session_emails = staff_email.get('sessions'),
				session_shift_emails = staff_email.get('sessions_shift')
			)
			reports.append(staff_data)
		CrispDailyReportModel.objects.bulk_create([CrispDailyReportModel(**row) for row in reports])
