from __future__ import unicode_literals, absolute_import, division

from django.core.management.base import BaseCommand

from datasync_django.testtask import notify_user


class Command(BaseCommand):
	help = "Fix permissions for proxy models."


	def handle(self, *args, **options):
		notify_user(repeat = 10, verbose_name = 12345)
