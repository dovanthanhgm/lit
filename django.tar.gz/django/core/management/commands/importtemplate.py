import csv
import os

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from datasync.views import SyncApi


class Command(BaseCommand):
	help = "Import file to django"


	def handle(self, *args, **options):
		path = '{}/public/media'.format(settings.BASE_DIR)
		if not os.path.isdir(path):
			os.mkdir(path)
		for template_type in ['product', 'inventory']:
			filename = f'{path}/{template_type}_template.csv'
			title = SyncApi().post(f"{template_type}/csv-file-sample")
			rows = [title]
			with open(filename, 'w') as file:
				writer = csv.writer(file, quoting = csv.QUOTE_NONNUMERIC, delimiter = ',')
				writer.writerows(rows)
