from django.core.management import BaseCommand

from crisp.api import CrispApi
from crisp.models import CrispConversationModel, CrispUserModel
from libs.utils import convert_format_time


class Command(BaseCommand):
	def handle(self, *args, **options):
		model = CrispApi()
		page = 1
		while True:
			conversations = model.get_users(page)
			if not conversations:
				break
			for conversation_data in conversations:
				try:
					CrispUserModel.objects.create(people_id = conversation_data['people_id'],
					                              name = conversation_data['person'].get('nickname', ''),
					                              email = conversation_data['email'],
					                              status = conversation_data['active']['now'],
					                              )
				except Exception:
					pass
			page += 1