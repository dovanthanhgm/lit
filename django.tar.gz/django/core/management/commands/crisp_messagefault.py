import copy

from core.management.commands.crisp_findmessagefault import Command as MessageFaultCommand

import dateutil.relativedelta
from datetime import date, datetime

from crisp.models import CrispConversationModel, CrispMessageModel, CrispMessageFaults, CrispUserMessageFaults, CrispConversationNoReply
from libs.utils import to_int, to_str


class Command(MessageFaultCommand):
	def add_arguments(self, parser):
		# Positional arguments
		parser.add_argument('--m', type = int, nargs='?')
		parser.add_argument('--y', type = int, nargs='?')
		parser.add_argument('--d', type = int, nargs='?')

		# Named (optional) arguments
	def handle(self, *args, **options):
		today = date.today()
		day_report = options.get('d') or today.day
		year = options.get('y') or today.year
		month = options.get('m') or today.month
		for day in range(1, day_report + 1):
			if day < 10:
				day = f'0{day}'
			else:
				day = to_str(day)
			today = datetime.strptime(f"{year}-{month}-{day} 00:00:00", "%Y-%m-%d %H:%M:%S")
			self.find_by_accounting(today)