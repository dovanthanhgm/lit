from background_task.models import Task
from django.core.management import BaseCommand

from channels.models import Channel
from core.utils import CoreUtils
from libs.models.collections.state import State
from processes.models import Process


class Command(BaseCommand):
	def handle(self, *args, **options):
		task_queryset = Task.objects.all().values('verbose_name')
		process_queryset = Process.objects.filter(id__in = task_queryset, type = 'order')
		for process in process_queryset:
			model_state = State()
			model_state.set_user_id(process.user_id)
			state = model_state.get(process.state_id)
			process.channel.sync_qty = True if state['channel']['config']['setting'].get('qty', {}).get('status') != 'disable' else False
			process.channel.sync_price = True if state['channel']['config']['setting'].get('price', {}).get('status') != 'disable' else False
			process.channel.sync_order = True if state['channel']['config']['setting'].get('order', {}).get('status') != 'disable' else False
			process.channel.save()
