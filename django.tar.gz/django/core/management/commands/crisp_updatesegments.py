from django.core.management import BaseCommand

from crisp.api import CrispApi
from crisp.models import CrispConversationModel
from libs.utils import convert_format_time


class Command(BaseCommand):
	def handle(self, *args, **options):
		model = CrispApi()
		page = 1
		while True:
			conversations = model.get_conversations(page)
			if not conversations:
				break
			for conversation_data in conversations:
				if conversation_data['meta'].get('segments'):
					CrispConversationModel.objects.filter(session_id = conversation_data['session_id']).update(segments = ','.join(conversation_data['segments']))
			page += 1