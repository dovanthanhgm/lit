import time
from datetime import datetime

from django.core.management import BaseCommand
from django.db.models import Q

from accounts.models import UserAccount
from accounts.utils import AccountUtils
from libs.utils import to_int
from subscription.models import UserSubscription


class Command(BaseCommand):
	def handle(self, *args, **options):
		q = UserSubscription.objects.all().values('user_id')
		current_time = datetime.fromtimestamp(to_int(time.time()) - 60 * 24 * 60 * 60).strftime("%Y-%m-%d %H:%M:%S")

		users = UserAccount.objects.filter(Q(last_access__lt = current_time) | Q(last_access__isnull = True)).exclude(id__in = q)
		for user in users:
			AccountUtils().close_account(user.id)