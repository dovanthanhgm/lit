import requests
from django.core.mail import send_mail
from django.core.management.base import BaseCommand

from libs.utils import get_config_ini


class Command(BaseCommand):
	help = "Import file to django"


	def handle(self, *args, **options):
		url = get_config_ini('callback', 'url')
		check = requests.get(url)
		if check.status_code != 404:
			html_content = "Callback server has been disconnected"
			subject = "Callback server has been disconnected"
			send_mail(
				subject = subject,
				message = None,
				from_email = 'nam@litcommerce.com',
				recipient_list = ['contact@litcommerce.com'],
				html_message = html_content,
				fail_silently = False
			)