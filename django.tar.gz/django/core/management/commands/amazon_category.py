import requests
from bs4 import BeautifulSoup
from django.core.management.base import BaseCommand

from channels.models import Channel
from libs.models.collections.state import State
from libs.utils import json_decode, to_len
from merchant.amazon.models import MerchantAmazonCategories
from processes.models import Process


class Command(BaseCommand):
	help = "Import file to django"
	MARKETPLACE_IDS = {
		'A2EUQ1WTGCTBG2': 'CA',
		'ATVPDKIKX0DER': 'US',
		'A1AM78C64UM0Y8': 'MX',
		'A2Q3Y263D00KWC': 'BR',
		'A1RKKUPIHCS9HS': 'ES',
		'A1F83G8C2ARO7P': 'GB',
		'A13V1IB3VIYZZH': 'FR',
		'A1805IZSGTT6HS': 'NL',
		'A1PA6795UKMFR9': 'DE',
		'APJ6JRA9NG5V4': 'IT',
		'A2NODRKZP88ZB9': 'SE',
		'A1C3SOZRARQ6R3': 'PL',
		'ARBP9OOSHTCHU': 'EG',
		'A33AVAJ2PDY3EV': 'TR',
		'A2VIGQ35RCS4UG': 'AE',
		'A21TJRUUN4KGV': 'IN',
		'A19VAU5U5O7RUS': 'SG',
		'A39IBJ37TRP1C6': 'AU',
		'A1VC38T7YXB528': 'JP',
	}

	def handle(self, *args, **options):
		parent_id = 0
		marketplace = 'A1F83G8C2ARO7P'
		c = self.get_all_note('https://www.browsenodes.com/amazon.co.uk', parent_id, marketplace)



	def get_all_note(self, url, parent = False, marketplace = False):

		content = requests.get(url).text
		soup = BeautifulSoup(content, 'lxml')
		tbody = soup.find("tbody")  # You can also use this too: all_xml_element_tags = soup.find_all("xs:element", {"minOccurs":"0"})
		all_tr = tbody.find_all('tr')
		all_cate = []
		for tr in all_tr:
			td = tr.find_all('td')
			if not td or to_len(list(td)) < 1:
				continue
			try:
				td[1]
			except:
				continue
			category_data = {
				'category_id': td[1].text.strip(),
				'name': td[0].text.strip(),
				'marketplace': marketplace,
			}
			if parent:
				path = f'{parent["path"]} > {category_data["name"]}'
				category_data['path'] = path
				category_data['parent_id'] = parent['category_id']
			else:
				category_data['path'] = category_data['name']
				category_data['parent_id'] = 0
			if td[-1].find('a'):
				href = td[-1].find('a').attrs['href']
				self.get_all_note(f"https://www.browsenodes.com{href}", {'category_id': category_data['category_id'], 'path': category_data['path'], 'name': category_data['name']}, marketplace)
			all_cate.append(category_data)
		MerchantAmazonCategories.objects.bulk_create([MerchantAmazonCategories(**etsy_cate) for etsy_cate in all_cate])
		return all_cate


