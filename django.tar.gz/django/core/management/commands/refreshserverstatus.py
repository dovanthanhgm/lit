from django.core.management.base import BaseCommand

from servers.utils import ServerUtils


class Command(BaseCommand):
	help = "Update status for datasync servers."

	def handle(self, *args, **options):
		ServerUtils().refresh(False)
