from datetime import datetime
import dateutil.relativedelta
from django.core.management import BaseCommand

from crisp.models import CrispConversationModel, CrispMessageModel


class Command(BaseCommand):
	def handle(self, *args, **options):
		query_set = CrispConversationModel.objects.all()
		conversations = list(query_set)
		for conversation in conversations:
			conversation.time_last_message = 0
			conversation.last_message_from = ''
			conversation.first_max_position_message = 0
			conversation.max_position = 0
			messages = CrispMessageModel.objects.filter(session_id = conversation.session_id).exclude(type__in = ['event', 'note']).order_by('message_time')
			for message in messages:
				timestamp = message.message_time
				message_from = 'operator' if message.from_operator else 'user'
				if not conversation.max_position:
					conversation.max_position = 1
					conversation.first_max_position_message = timestamp
				else:
					if message_from != conversation.last_message_from:
						start_time = conversation.first_max_position_message
						start_datetime_hour = datetime.fromtimestamp(start_time).hour
						if message_from == 'operator' and start_datetime_hour < 8:
							start_shift_time = message.timestamp.strftime(f'%Y-%m-%d 08:00:00')
							shift_datetime = datetime.strptime(start_shift_time, "%Y-%m-%d %H:%M:%S")
							start_time = shift_datetime.timestamp()
						# start_shift_time = shift_datetime - dateutil.relativedelta.relativedelta(hours = 4)
						conversation.max_position += 1
						# if message_from != 'operator':
						message.response_time = timestamp - start_time
						# else:
						# 	message.response_time = min(timestamp - conversation.first_max_position_message, timestamp - shift_datetime.timestamp())

						conversation.first_max_position_message = timestamp
				message.position = conversation.max_position
				message.save()
				conversation.last_message_from = message_from
			conversation.save()