import datetime
import time

from background_task.models import Task
from django.core.management import BaseCommand
from django.utils import timezone

from accounts.models import UserAccount
from channels.models import Channel
from datasync.api.scheduler import SchedulerApi
from datasync.api.sync import SyncApi
from libs.django_json_encode import model_django_to_dict
from libs.utils import get_config_ini, split_list_by_numberarray
from processes.models import Process
from servers.models import Server


class Command(BaseCommand):
	def find_available_task(self, number_tasks):
		now = timezone.now()
		available_tasks = Task.objects.filter(run_at__lt = now)[:number_tasks]
		return available_tasks


	def handle(self, *args, **options):
		number_thread = get_config_ini('server', 'number_thread', 30)


		while True:
			servers = list(Server.objects.filter(status = Server.CONNECTED).order_by('active_tasks'))
			number_servers = len(servers)
			cron_available_tasks = self.find_available_task(number_thread * number_servers)
			if not cron_available_tasks:
				time.sleep(5)
				continue
			server_available_tasks = split_list_by_numberarray(cron_available_tasks, number_servers)
			for index, available_tasks in enumerate(server_available_tasks):
				if not available_tasks:
					continue
				server = servers[index]
				process_ids = [row.verbose_name for row in available_tasks]
				processes_queryset = Process.objects.filter(id__in = process_ids)
				channel_ids = [row.channel_id for row in processes_queryset]
				user_ids = [row.user_id for row in processes_queryset]
				channels = model_django_to_dict(Channel.objects.filter(id__in = channel_ids))
				user_queryset = UserAccount.objects.filter(id__in = user_ids)
				users = model_django_to_dict(user_queryset)
				user_clone = list(filter(lambda x: x.server_id, user_queryset))
				process_clone = list(filter(lambda x: x.user_id in user_clone, processes_queryset))
				process_no_clone = list(filter(lambda x: x.user_id not in user_clone, processes_queryset))
				processes = model_django_to_dict(process_no_clone)

				for process in process_clone:
					# if process.type == 'refresh':
					# 	process.channel.last_imported = datetime.datetime.now()
					# 	process.channel.save()
					sync_api = SyncApi(user_id = process.user_id)
					sync_api.post(f'scheduler/{process.id}')
				kwargs = {
					'users': users,
					'channels': channels,
					'processes': processes,
					'server': server
				}
				scheduler_api = SchedulerApi(**kwargs)
				scheduler_api.post(f'scheduler/multy-process')
				for process in processes_queryset:
					if process.type == 'refresh':
						process.channel.last_imported = datetime.datetime.now()
						process.channel.save()
				for task in available_tasks:
					task.create_completed_task()
					task.create_repetition()
					task.delete()
			time.sleep(0.5)