from django.core.management import BaseCommand

from channels.models import Channel
from core.utils import CoreUtils


class Command(BaseCommand):
	def handle(self, *args, **options):
		channels = Channel.objects.all()
		for channel in channels:
			CoreUtils().count_product_number(channel)
