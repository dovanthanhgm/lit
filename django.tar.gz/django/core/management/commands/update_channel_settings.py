from django.core.management import BaseCommand

from accounts.models import UserAccount
from channels.models import Channel
from channels.utils import ChannelUtils
from libs.models.collections.state import State
from libs.utils import to_int, json_encode
from subscription.models import UserSubscription


class Command(BaseCommand):
	def handle(self, *args, **options):
		qs = UserSubscription.objects.exclude(plan_id = 1, solve_expired = 1, plan_expired_noti_1 = 1).values('user_id')
		paid_channels = Channel.objects.filter(user_id__in = qs).exclude(default = True).order_by('-id')
		state = State()
		for channel in paid_channels:
			state.set_user_id(channel.user_id)
			where = {"channel.id": channel.id}
			current_state = state.find_one(where)
			if not current_state:
				continue
			settings = current_state['channel']['config']['setting']
			channel.settings = json_encode(settings)
			channel.sync_qty = settings.get('qty', {}).get('status') == 'enable'
			channel.sync_price = settings.get('price', {}).get('status') == 'enable'
			channel.sync_order = settings.get('order', {}).get('status') == 'enable'
			channel.save()