import csv
import os
from datetime import date

import requests
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from woocommerce import API

from channels.models import Channel
from channels.utils import ChannelUtils
from datasync.views import SyncApi
from libs.utils import json_decode, get_random_useragent
from subscription.models import UserSubscription


class Command(BaseCommand):
	help = "Import file to django"


	def handle(self, *args, **options):
		today = date.today().strftime("%Y-%m-%d 23:59:59")

		plan_expired = UserSubscription.objects.filter(expired_at__gt = today).exclude(plan_id__in = [1, 8]).values('user_id')
		channels = Channel.objects.filter(default = True, type__in = ['woocommerce', 'shopify', 'bigcommerce'], created_webhook = True).exclude(user_id__in = plan_expired)
		for channel in channels:
			ChannelUtils().delete_webhook(channel)


