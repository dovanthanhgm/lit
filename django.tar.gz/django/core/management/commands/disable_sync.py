from django.core.management import BaseCommand

from accounts.models import UserAccount
from channels.models import Channel
from channels.utils import ChannelUtils
from libs.models.collections.state import State
from libs.utils import to_int
from subscription.models import UserSubscription


class Command(BaseCommand):
	def disable_sync(self, user_id):
		model_state = State()
		model_state.set_user_id(user_id)
		channels = Channel.objects.filter(user_id = user_id)
		for channel in channels:
			ChannelUtils().disable_all_scheduler(channel.id)
			update_data = {
				"channel.config.setting.price.status": "disable",
				"channel.config.setting.qty.status": "disable",
				"channel.config.setting.order.status": "disable",
			}
			channel.sync_order = False
			channel.sync_qty = False
			channel.sync_price = False
			channel.auto_update = False
			channel.save()
			model_state.update_many(model_state.create_where_condition("channel.id", to_int(channel.id)), update_data)


	def handle(self, *args, **options):
		qs = UserSubscription.objects.filter(plan_id = 1).values('user_id')
		user_free = UserAccount.objects.filter(id__in = qs)
		qs = UserSubscription.objects.all().values('user_id')
		user_free1 = UserAccount.objects.exclude(id__in = qs)
		for user in user_free:
			self.disable_sync(user.id)
		for user in user_free1:
			self.disable_sync(user.id)
