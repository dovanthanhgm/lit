import time
from collections import OrderedDict

from django.http import HttpResponseForbidden, JsonResponse, HttpResponseNotFound
from django.utils.decorators import method_decorator
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, status

from accounts.utils import AccountUtils
from core.responses import PaginationResponse, ErrorResponse
from channels.models import Channel
from libs.models.collections.template import Template


class ChoiceSerializer(generics.ListAPIView):
	serializer_class = {}

	def get_serializer_class_datasync(self, template_type):
		if self.serializer_class.get(template_type):
			serializer_cla = self.serializer_class.get(template_type)
			return serializer_cla
		return False


	def get_serializer_datasync(self, *args, **kwargs):
		"""
		Return the serializer instance that should be used for validating and
		deserializing input, and for serializing output.
		"""
		serializer_class = self.get_serializer_class_datasync(kwargs['data']['type'])
		kwargs['context'] = self.get_serializer_context()
		return serializer_class(*args, **kwargs)


class TemplateAPIView(ChoiceSerializer):
	channel_name = ''

	def select_fields(self):
		return None

	def get(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_template = Template()
		model_template.set_user_id(user_id)
		limit = request.GET.get('limit')
		if not limit:
			limit = 20
		page = request.GET.get('page')
		if not page:
			page = 1
		sort_by = request.GET.get('sort')
		template_type = request.GET.get('type')
		channel_id = kwargs['channel_id']
		if template_type:
			where = {"type": template_type, "channel_id": channel_id}
		else:
			where = {"channel_id": channel_id}
		templates = model_template.find_all(where, limit = limit, pages = page, sort = sort_by, select_fields = self.select_fields())
		data = {}
		if template_type:
			data[template_type] = []
			for result in templates:
				if result['type'] == template_type:
					data[template_type].append(result)
		else:
			for template_type in self.serializer_class.keys():
				data[template_type] = []
				for result in templates:
					if result['type'] == template_type:
						data[template_type].append(result)
		for template_type_key, template_data in data.items():
			for row in template_data:
				row['id'] = row['_id']
				del row['_id']
		data = {
			"count": model_template.count(where),
			"data": data,
		}
		return JsonResponse(PaginationResponse(**data).to_dict(), safe=False)

	def post(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		template_type = request.data['type']
		if not self.serializer_class.get(template_type):
			return JsonResponse(data = {"message": f"template_type does not fall into the following"
			                                       f" types: {', '.join(self.serializer_class.keys())} "})
		serializer = self.get_serializer_datasync(data = request.data)

		if serializer.is_valid():
			model_template = Template()
			model_template.set_user_id(user_id)
			data_post = serializer.data
			data_post.update({"channel_id": kwargs['channel_id']})
			template = model_template.create(data_post)
			data_post['_id'] = template
			return JsonResponse(data_post, safe = False)
		else:
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)

	def delete(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_template = Template()
		model_template.set_user_id(user_id)
		model_template.delete_all()
		data = {"message": "delete success"}
		return JsonResponse(data, safe=False)


class TemplateApiCount(TemplateAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)

		if not user_id:
			return HttpResponseForbidden()
		start_time = time.time()
		model_template = Template()
		model_template.set_user_id(user_id)
		where = {}
		data = {
			"count": model_template.count(where),
		}
		end_time = time.time()
		process_time = end_time - start_time
		print("Process Time: ", process_time)
		return JsonResponse(data, safe=False)


template_api_count_response = openapi.Schema(
	type = openapi.TYPE_OBJECT,
	properties = OrderedDict((
		('count', openapi.Schema(type = openapi.TYPE_INTEGER, example = 20)),
	))
)

@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: template_api_count_response
	}
))


class TemplateDetailApiview(ChoiceSerializer):
	channel_name = ''

	def get(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		model_template = Template()
		model_template.set_user_id(user_id)
		template = model_template.get(kwargs['template_id'])
		if not template:
			return HttpResponseNotFound()
		if template['channel_id'] != kwargs['channel_id']:
			return JsonResponse(data = {"message": f"template_id {kwargs['template_id']} have channel_id is {template.channel_id}"})
		return JsonResponse(template)

	def put(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})
		user_id = AccountUtils().get_user_id(request)
		model_template = Template()
		model_template.set_user_id(user_id)
		template = model_template.get(kwargs['template_id'])
		if not template:
			return HttpResponseNotFound()
		if template['channel_id'] == kwargs['channel_id']:
			data_update = self.update_object_data(template, request.data)
			serializer = self.get_serializer_datasync(data = data_update)
			if not serializer.is_valid():
				errors = serializer.errors
				return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
			model_template.update(kwargs['template_id'], data_update)
			template = model_template.get(kwargs['template_id'])
			return JsonResponse(template, safe=False)
		else:
			return JsonResponse(data = {
				"message": f"Template have template_id: {kwargs['template_id']}, channel_id: {template['channel_id']}"
			})

	def update_object_data(self, current_data, update_data):
		new_data = dict()
		for data_key, data_value in current_data.items():
			if not update_data.get(data_key):
				continue
			if isinstance(data_value, dict) and isinstance(update_data.get(data_key), dict):
				data_value = self.update_object_data(data_value, update_data[data_key])
			elif isinstance(data_value, (list, tuple)) and isinstance(update_data[data_key], (list, tuple)):
				data_value = update_data[data_key]
			else:
				data_value = update_data[data_key]
			new_data[data_key] = data_value
		return new_data

	def delete(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})
		user_id = AccountUtils().get_user_id(request)
		model_template = Template()
		model_template.set_user_id(user_id)
		template = model_template.get(kwargs['template_id'])
		if not template:
			return HttpResponseNotFound()
		if template['channel_id'] == kwargs['channel_id']:
			model_template.delete(kwargs['template_id'])
			data = {
				"message": f"Delete template have template_id is {kwargs['template_id']} success",
			}
			return JsonResponse(data, safe = False)
		else:
			return JsonResponse(data = {
				"message": f"Template have template_id: {kwargs['template_id']}, channel_id: {template['channel_id']}"
			})


def check_channel_id(channel_name, channel_id):
	qs = Channel.objects.filter(pk = channel_id).first()
	if not qs:
		return f"No channel_id {channel_id}"
	if qs.type.lower() != channel_name.lower():
		return f"Channel_id {channel_id} is not channel type {channel_name}"
