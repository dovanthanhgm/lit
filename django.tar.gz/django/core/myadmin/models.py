# # Create your models here.
from django.db import models


class MyAdmin(models.Model):
	class Meta:
		permissions = (("delete_all", "Delete All Product"), ('delete_listing', 'Delete All Product In listing'))
from django.db import models

# Create your models here.
