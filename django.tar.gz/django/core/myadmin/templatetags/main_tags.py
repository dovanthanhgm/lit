import time
from datetime import datetime

from dateutil.utils import today
from django import template
from django.db.models import Sum, Count, Q, F
from django.db.models.functions import TruncMonth, TruncDay

from accounts.models import UserAccount
from channels.models import Channel, choices_channel
from core.myadmin.utils import MyAdminUtils
from libs.utils import json_encode, to_int, get_full_absolute_uri
from litcommerce_order.models import LitCommerceOrder
from subscription.models import UserSubscription, Subscription


def get_request_data(request):
	start_date = None
	end_date = None
	daterange = request.GET.get('daterange')
	if daterange:
		daterange = request.GET.get('daterange').split(' - ')
		start_date = daterange[0]
		end_date = daterange[1]
	else:
		current_time = datetime.today()
		start_date = current_time.strftime('%Y-%m-%d')
		end_date = current_time.strftime('%Y-%m-%d')
	data = {
		'start_date': start_date,
		'end_date': end_date,
		'channels': choices_channel(True),

	}
	if request.GET:
		for row, value in request.GET.items():
			data[row] = value
	return data


register = template.Library()


@register.inclusion_tag('admin/stats/revenue.html', takes_context = True)
def revenue_stats(context):
	request = context.request
	revenue = list()
	if request.GET.get('revenue') != 'daily':
		title = 'Monthly'
		queryset = LitCommerceOrder.objects.annotate(month = TruncMonth('created_at')).values('month').annotate(revenue = Sum(F('total') - F('refund'))).values('month', 'revenue').order_by('-month')[:13]
		queryset = list(queryset)
		queryset.reverse()
		revenue.append(['Month', 'Revenue'])
		for row in queryset:
			revenue.append((row['month'].strftime('%Y-%m'), to_int(row['revenue'])))
	else:
		title = 'Daily'

		queryset = LitCommerceOrder.objects.annotate(month = TruncDay('created_at')).values('month').annotate(revenue = Sum(F('total') - F('refund'))).values('month', 'revenue').order_by('-month')[:10]
		queryset = list(queryset)
		queryset.reverse()
		revenue.append(['Month', 'Revenue'])
		for row in queryset:
			revenue.append((row['month'].strftime('%Y-%m-%d'), to_int(row['revenue'])))
	current_time = today()
	created_at = current_time.strftime("%Y-%m-01 00:00:00")
	today_revenue = LitCommerceOrder.objects.filter(created_at__gte = current_time.strftime("%Y-%m-%d 00:00:00")).aggregate(revenue = Sum(F('total') - F('refund')))
	thismonth_revenue = LitCommerceOrder.objects.filter(created_at__gte = created_at).aggregate(revenue = Sum(F('total') - F('refund')))
	report_data = MyAdminUtils().total_user_report()
	active_monthly = sum([row['total'] for row in list(filter(lambda x: not x['yearly_paid'], report_data['details_user_active_monthly']))])
	active_yearly = report_data['total_user_active'] - active_monthly
	user_data = {
		'Total User': {'total': report_data['total_user'], 'link': ''},
		'Total User with MainStore': {'total': report_data['total_user_with_mainstore'], 'link': ''},
		'Total User with MainStore & Channel': {'total': report_data['total_user_with_channel'], 'link': ''},
		'Total Active Paid User': {'total': f"{report_data['total_user_active']} (Monthly {active_monthly}, Yearly: {active_yearly})", 'link': ''},
		'Total Expired User': {'total': report_data['total_user_expired'], 'link': get_full_absolute_uri('admin:subscription_usersubscription_changelist') + '?status=expired'},
		'Total Expired User Trial': {'total': report_data['total_user_trial_expired'], 'link':  get_full_absolute_uri('admin:subscription_usersubscription_changelist') + '?status=trial_expired'},
		'Total Active User Trial': {'total': report_data['total_user_trial_active'], 'link':  get_full_absolute_uri('admin:subscription_usersubscription_changelist') + '?status=trial_active'},
	}
	all_plan = {row.id: row.name for row in Subscription.objects.all()}
	details_user_active = report_data['details_user_active']
	report_details_user_active_monthly = report_data['details_user_active_monthly']
	details_user_active_monthly = dict()
	for row in report_details_user_active_monthly:
		if not details_user_active_monthly.get(row['plan_id']):
			details_user_active_monthly[row['plan_id']] = dict()
		key = 'monthly' if not row['yearly_paid'] else 'yearly'
		details_user_active_monthly[row['plan_id']][key] = row['total']
	details_active = []
	sorted_name = list(all_plan.values())
	for row in details_user_active:
		row['plan_name'] = all_plan[row['plan_id']]
		monthly = details_user_active_monthly.get(row['plan_id'], {}).get('monthly', 0)
		yearly = details_user_active_monthly.get(row['plan_id'], {}).get('yearly', 0)
		plan_detail = []
		if monthly:
			plan_detail.append(f'Monthly: {monthly}')
		if yearly:
			plan_detail.append(f'Yearly: {yearly}')
		row['details'] = ', '.join(plan_detail)
		details_active.append(row)
	details_active.sort(key = lambda x: sorted_name.index(x['plan_name']))

	return {
		'title': title,
		'revenue': json_encode(revenue),
		'today_revenue': to_int(today_revenue.get('revenue')),
		'thismonth_revenue': to_int(thismonth_revenue.get('revenue')),
		'user_data': user_data,
		'details_active': details_active,
	}


@register.inclusion_tag('admin/stats/pie_chart.html', takes_context = True)
def pie_chart(context):
	request = context.request
	data = {
		'channels': choices_channel(True),

	}
	data.update(get_request_data(request))
	return data


@register.inclusion_tag('admin/stats/base_pie.html', takes_context = True)
def channels_stat(context):
	request = context.request
	data_filter = get_request_data(request)
	filter_query = dict()
	current_time = datetime.today()
	if data_filter.get('start_date'):
		filter_query['created_at__gte'] = f"{data_filter.get('start_date')} 00:00:00"
	else:
		filter_query['created_at__gte'] = f"{current_time.strftime('%Y-%m-%d')} 00:00:00"

	if data_filter.get('end_date'):
		filter_query['created_at__lte'] = f"{data_filter.get('end_date')} 23:59:59"
	else:
		filter_query['created_at__lte'] = f"{current_time.strftime('%Y-%m-%d')} 23:59:59"

	user_in_filter = []
	if data_filter.get('user_filter') == 'paid_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('user_filter') == 'expired_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(expired_at__lt = current_time).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('mainstore_filter') and data_filter.get('mainstore_filter') != 'none':
		inner_qs = Channel.objects.filter(default = True, type = data_filter.get('mainstore_filter')).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('channel_filter') and data_filter.get('channel_filter') != 'none':
		filter_query['type'] = data_filter.get('channel_filter')
	user_filter = Q(**filter_query)
	if user_in_filter:
		for row in user_in_filter:
			if not user_filter:
				user_filter = Q(user__in = row)
			else:
				user_filter = user_filter & Q(user__in = row)

	queryset = Channel.objects.filter(user_filter).exclude(default = 1).values('type').annotate(total = Count('id')).values('type', 'total').order_by('-total')
	# if user_filter:
	# 	queryset.filter(user_filter)
	channels = list()
	queryset = list(queryset)
	queryset.sort(key = lambda x: x['total'], reverse = True)
	channels.append(['Channel', 'Number'])
	for channel in queryset:
		channels.append([channel['type'], channel['total']])
	return {
		'chart_data': json_encode(channels),
		'chart_title': 'Channels',
		'chart_id': 'channel_pie',
		'mainstore_filter': request.GET.get('mainstore_filter'),
		'channels': choices_channel(True),
	}


@register.inclusion_tag('admin/stats/base_pie.html', takes_context = True)
def mainstore_stat(context):
	request = context.request
	filter_query = {
		'default': 1
	}
	data_filter = get_request_data(request)

	if data_filter.get('start_date'):
		filter_query['created_at__gte'] = f"{data_filter.get('start_date')} 00:00:00"
	if data_filter.get('end_date'):
		filter_query['created_at__lte'] = f"{data_filter.get('end_date')} 23:59:59"

	user_in_filter = []
	if data_filter.get('user_filter') == 'paid_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('user_filter') == 'expired_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(expired_at__lt = current_time).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('channel_filter') and data_filter.get('channel_filter') != 'none':
		inner_qs = Channel.objects.filter(default = False, type = data_filter.get('channel_filter')).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('mainstore_filter') and data_filter.get('mainstore_filter') != 'none':
		filter_query['type'] = data_filter.get('mainstore_filter')

	user_filter = Q(**filter_query)
	if user_in_filter:
		for row in user_in_filter:
			if not user_filter:
				user_filter = Q(user__in = row)
			else:
				user_filter = user_filter & Q(user__in = row)
	queryset = Channel.objects.filter(user_filter).values('type').annotate(total = Count('id')).values('type', 'total').order_by('-total')
	channels = list()
	queryset = list(queryset)
	queryset.sort(key = lambda x: x['total'], reverse = True)
	channels.append(['Channel', 'Number'])
	for channel in queryset:
		channels.append([channel['type'], channel['total']])
	return {
		'chart_data': json_encode(channels),
		'chart_title': 'MainStore',
		'chart_id': 'mainstore_pie',
		'channel_filter': request.GET.get('channel_filter'),
		'channels': choices_channel(True),

	}


@register.inclusion_tag('admin/stats/base_pie.html', takes_context = True)
def country_user(context):
	request = context.request
	filter_query = {
	}
	data_filter = get_request_data(request)

	if data_filter.get('start_date'):
		filter_query['created_at__gte'] = f"{data_filter.get('start_date')} 00:00:00"
	if data_filter.get('end_date'):
		filter_query['created_at__lte'] = f"{data_filter.get('end_date')} 23:59:59"
	user_in_filter = []
	if data_filter.get('channel_filter') and data_filter.get('channel_filter') != 'none':
		inner_qs = Channel.objects.filter(default = False, type = data_filter.get('channel_filter')).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('mainstore_filter') and data_filter.get('mainstore_filter') != 'none':
		inner_qs = Channel.objects.filter(default = True, type = data_filter.get('mainstore_filter')).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('user_filter') == 'paid_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('user_filter') == 'expired_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(expired_at__lt = current_time).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	# filter_query['id__in'] = inner_qs
	user_filter = Q(**filter_query)
	if user_in_filter:
		for row in user_in_filter:
			if not user_filter:
				user_filter = Q(id__in = row)
			else:
				user_filter = user_filter & Q(id__in = row)
	queryset = UserAccount.objects.filter(user_filter).filter(is_staff = False).exclude(Q(country = '') | Q(country__isnull = True)).values('country').annotate(total = Count('id')).values('country', 'total').order_by('-total')[:9]
	channels = list()
	queryset = list(queryset)
	channels.append(['Country', 'Number'])
	total = 0
	for channel in queryset:
		total += channel['total']
	all_user = UserAccount.objects.filter(user_filter).filter(is_staff = False).count()
	queryset.append({'country': 'Other', 'total': all_user - total})
	queryset.sort(key = lambda x: x['total'], reverse = True)
	for channel in queryset:
		channels.append([channel['country'], channel['total']])

	return {
		'chart_data': json_encode(channels),
		'chart_title': 'User By Country',
		'chart_id': 'country_pie',
	}


@register.inclusion_tag('admin/stats/base_pie.html', takes_context = True)
def user_from(context):
	request = context.request
	filter_query = {
	}
	data_filter = get_request_data(request)

	if data_filter.get('start_date'):
		filter_query['created_at__gte'] = f"{data_filter.get('start_date')} 00:00:00"
	if data_filter.get('end_date'):
		filter_query['created_at__lte'] = f"{data_filter.get('end_date')} 23:59:59"

	user_in_filter = []
	if data_filter.get('user_filter') == 'paid_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('user_filter') == 'expired_user':
		current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
		inner_qs = UserSubscription.objects.filter(expired_at__lt = current_time).exclude(plan_id__in = [1, 8]).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('channel_filter') and data_filter.get('channel_filter') != 'none':
		inner_qs = Channel.objects.filter(default = False, type = data_filter.get('channel_filter')).values('user_id')
		user_in_filter.append(inner_qs)
	if data_filter.get('mainstore_filter') and data_filter.get('mainstore_filter') != 'none':
		inner_qs = Channel.objects.filter(default = True, type = data_filter.get('channel_filter')).values('user_id')
		user_in_filter.append(inner_qs)

	user_filter = Q(**filter_query)
	if user_in_filter:
		for row in user_in_filter:
			if not user_filter:
				user_filter = Q(id__in = row)
			else:
				user_filter = user_filter & Q(id__in = row)
	inner_qs_woo = Channel.objects.filter(default = True, type = 'woocommerce').values('user_id')
	user_in_filter.append(inner_qs_woo)
	user_filter_woo = Q(**filter_query)
	if user_in_filter:
		for row in user_in_filter:
			if not user_filter:
				user_filter_woo = Q(id__in = row)
			else:
				user_filter_woo = user_filter_woo & Q(id__in = row)
	queryset_woo = UserAccount.objects.filter(user_filter_woo).filter(is_staff = False).count()
	queryset = UserAccount.objects.filter(user_filter).filter(is_staff = False).values('market_app').annotate(total = Count('id')).values('market_app', 'total').order_by('-total')
	users = list()
	queryset_data = list(queryset)
	chart_data = list()
	# chart_data.append({'market_app': 'woo', 'total': queryset_woo})
	for row in queryset_data:
		# if row['market_app'] != 'litc':
		chart_data.append(row)
		# else:
		# 	chart_data.append({'market_app': 'litc', 'total': row['total'] - queryset_woo})
	chart_data.sort(key = lambda x: x['total'], reverse = True)
	users.append(['App', 'Number'])
	for channel in chart_data:
		users.append([channel['market_app'], channel['total']])
	return {
		'chart_data': json_encode(users),
		'chart_title': 'User From',
		'chart_id': 'userfrom_pie',
		'channel_filter': request.GET.get('channel_filter'),
		'channels': choices_channel(True),

	}
