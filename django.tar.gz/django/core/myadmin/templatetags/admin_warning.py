import os
from collections import OrderedDict
from datetime import datetime
import urllib.parse
import dateutil.relativedelta
from django import template
from django.db.models import Count
from django.template.loader import render_to_string

from feature_request.models import FeatureRequest
from libs.utils import json_decode, to_str, to_decimal, get_current_time
from litcommerce_order.models import LitCommerceOrder
from processes.models import Process
from servers.models import Server
from setup_error_log.models import ErrorLog
from smart_feedback.models import SmartFeedback
from subscription.models import SubscriptionRenewException

register = template.Library()


@register.inclusion_tag('admin/warning.html')
def show_warning():
	servers = Server.objects.all()
	warnings = list()
	warning_server_msg = list()
	warning_alot = list()
	warning_pid = dict()
	process_ids = dict()
	process_dead = list()
	for server in servers:
		if server.status != 'connected':
			msg = str(render_to_string('admin/warning/server_disconnected.html', {"obj": server}))
			add_warning(warnings, msg)
			continue

		if to_decimal(server.cpu_percent) >= 90 or to_decimal(server.disk_usage_percent) >= 90:
			warning_sv_text = server.name + "("
			if to_decimal(server.cpu_percent) >= 90:
				warning_sv_text += f" cpu:{server.cpu_percent}%"

			if to_decimal(server.disk_usage_percent) >= 90:
				warning_sv_text += f" disk:{server.disk_usage_percent}%"

			warning_sv_text += " )"
			warning_server_msg.append(warning_sv_text)

		processes = json_decode(server.processes) or list()

		for process in processes:
			process_ids[server.id] = list()
			process_ids[server.id].append(process['pid'])
			if process.get('datasync_info'):
				datasync_info = process['datasync_info']
				created_time = datetime.strptime(process['create_time'], "%Y-%m-%d %H:%M:%S")
				if not datasync_info.get('data', dict()).get('sync_id') and datasync_info.get('controller') not in ('channel',) and created_time + dateutil.relativedelta.relativedelta(hours = 1) < datetime.now():
					if not warning_pid.get(server.name):
						warning_pid[server.name] = list()
					warning_pid[server.name].append(process['pid'])
				if to_decimal(process['cpu_percent']) < 90 and to_decimal(to_str(process['memory_info']).replace("M", "")) < 500:
					continue
				warning_alot_text = datasync_info.get('data', dict()).get('sync_id') + "("
				if to_decimal(process['cpu_percent']) >= 90:
					warning_alot_text += f" cpu:{process['cpu_percent']}%"

				if to_decimal(to_str(process['memory_info']).replace("M", "")) >= 500:
					warning_alot_text += f" memory:{process['memory_info']}"

					warning_alot_text += " )"
				warning_alot.append(warning_alot_text)
		for server_id, process_id in process_ids.items():
			process = Process.objects.filter(status__in = ['pulling', 'pushing'], server_id = 1).exclude(pid__in = process_id).values('id')
			for row in process:
				process_dead.append(row['id'])

	if warning_server_msg:
		msg = str(render_to_string('admin/warning/server_overloaded.html', {"warning_server_msg": ",".join(warning_server_msg)}))
		add_warning(warnings, msg)
	if warning_alot:
		msg = str(render_to_string('admin/warning/process_consuming_resource.html', {"warning_alot": ",".join(warning_alot)}))
		add_warning(warnings, msg)
	if process_dead:
		msg = str(render_to_string('admin/warning/process_dead.html', {"processes": process_dead}))
		add_warning(warnings, msg)
	renew_exceptions = SubscriptionRenewException.objects.filter(status = False).count()
	if renew_exceptions:
		msg = str(render_to_string('admin/warning/subscription_renew_exceptions.html', {"number": renew_exceptions}))
		add_warning(warnings, msg)
	setup_error = ErrorLog.objects.filter(created_at__gt = get_current_time("%Y-%m-%d 00:00:00")).values('channel_type').annotate(total = Count('id')).order_by('total')
	if setup_error:
		total = 0
		text = []
		for row in setup_error:
			total += row['total']
			text.append(f'{row["channel_type"]}({row["total"]})')
		if total:
			msg = str(render_to_string('admin/warning/setup_log_error.html', {"number": total, "text": ' '.join(text)}))
			add_errors(warnings, msg)
	status = os.system('service process_tasks status')
	if status != 0:
		msg = "Service Process Tasks is stopped"
		add_errors(warnings, msg)
	new_order = LitCommerceOrder.objects.filter(created_at__gt = get_current_time("%Y-%m-%d 00:00:00"), status = 'completed', total__gt = 0).count()
	if new_order:
		created_at_gte = datetime.now()
		created_at_lt = created_at_gte + dateutil.relativedelta.relativedelta(days = 1)
		data = dict(
			created_at__gte = created_at_gte.strftime("%Y-%m-%d 00:00:00"),
			created_at__lt = created_at_lt.strftime("%Y-%m-%d 00:00:00"),
			status = 'completed',
			total__gt = 0,
		)
		params = urllib.parse.urlencode(OrderedDict(**data))
		msg = str(render_to_string('admin/warning/new_order.html', {"number": new_order, 'params': params}))
		add_success(warnings, msg)
	feature_request = FeatureRequest.objects.filter(created_at__gt = get_current_time("%Y-%m-%d 00:00:00")).count()
	if feature_request:
		created_at_gte = datetime.now()
		created_at_lt = created_at_gte + dateutil.relativedelta.relativedelta(days = 1)
		data = dict(
			created_at__gte = created_at_gte.strftime("%Y-%m-%d 00:00:00"),
			created_at__lt = created_at_lt.strftime("%Y-%m-%d 00:00:00")
		)
		params = urllib.parse.urlencode(OrderedDict(**data))
		msg = str(render_to_string('admin/warning/feature_request.html', {"number": feature_request, 'params': params}))
		add_success(warnings, msg)
	feedback = SmartFeedback.objects.filter(created_at__gt = get_current_time("%Y-%m-%d 00:00:00")).count()

	if feedback:
		created_at_gte = datetime.now()
		created_at_lt = created_at_gte + dateutil.relativedelta.relativedelta(days = 1)
		data = dict(
			created_at__gte = created_at_gte.strftime("%Y-%m-%d 00:00:00"),
			created_at__lt = created_at_lt.strftime("%Y-%m-%d 00:00:00")
		)
		params = urllib.parse.urlencode(OrderedDict(**data))
		msg = str(render_to_string('admin/warning/smart_feedback.html', {"number": feedback, 'params': params}))
		add_success(warnings, msg)
	return {"warnings": warnings}


def add_warning(warnings, message):
	warnings.append({
		'class': 'warning',
		'msg': message
	})
	return warnings


def add_errors(warnings, message):
	warnings.append({
		'class': 'error',
		'msg': message
	})
	return warnings


def add_success(warnings, message):
	warnings.append({
		'class': 'success',
		'msg': message
	})
	return warnings
