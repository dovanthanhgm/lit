from functools import update_wrapper

from django.contrib import admin
from django.urls import path, reverse
from django.utils.html import format_html

from accounts.models import UserAccount
from core.myadmin.models import MyAdmin
from core.myadmin.views import StatsViews, UserStats, CrispReport, UserActiveStats, DurationPaidStatsViews, LitCUserReport

class SelectBoxFilter(admin.SimpleListFilter):
	template = 'django_admin_listfilter_dropdown/dropdown_filter.html'

class InputFilter(admin.SimpleListFilter):
	template = 'admin/input_filter.html'


	def lookups(self, request, model_admin):
		# Dummy, required to show the filter.
		return ((),)


	def choices(self, changelist):
		# Grab only the "all" option.
		all_choice = next(super().choices(changelist))
		all_choice['query_parts'] = (
			(k, v)
			for k, v in changelist.get_filters_params().items()
			if k != self.parameter_name
		)
		yield all_choice
class FieldContainFilter(InputFilter):
	parameter_name = 'name'
	title = ('Name')


	def queryset(self, request, queryset):
		if self.value() is not None:
			name = self.value()
			kwargs = {
				f'{self.parameter_name}__icontains': name
			}
			return queryset.filter(**kwargs)

class NameFilter(InputFilter):
	parameter_name = 'name'
	title = ('Name')


	def queryset(self, request, queryset):
		if self.value() is not None:
			name = self.value()
			return queryset.filter(name__icontains = name)


class UserFilter(InputFilter):
	parameter_name = 'email'
	title = ('email or id')
	field_filter = ''


	def filter_user(self, user_ids, request, queryset):
		return queryset.filter(user_id__in = user_ids)


	def query_none_filter(self, queryset):
		return queryset.none()


	def queryset(self, request, queryset):
		from libs.utils import to_str
		if self.value() is not None:
			email = to_str(self.value()).strip()
			if email.isnumeric():
				users = UserAccount.objects.filter(pk = email)
			else:
				users = UserAccount.objects.filter(email__contains = email)
			user_ids = list(users.values_list('id', flat = True))
			if user_ids:
				return self.filter_user(user_ids, request, queryset)
			else:
				return self.query_none_filter(queryset)


class CoreAdmin(admin.ModelAdmin):
	list_per_page = 20


	def __init__(self, model, admin_site):
		super().__init__(model, admin_site)
		self._change_view_per = True


	def user_link(self, obj):
		url = reverse("admin:accounts_useraccount_change", args = (obj.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.user.email}</a>")


	def get_urls(self):
		def wrap(view):
			def wrapper(*args, **kwargs):
				return self.admin_site.admin_view(view)(*args, **kwargs)


			wrapper.model_admin = self
			return update_wrapper(wrapper, view)


		info = self.model._meta.app_label, self.model._meta.model_name
		urls = super().get_urls()
		custom_url = [
			path('<path:object_id>/view/', wrap(self.change_view), name = '%s_%s_view' % info),

		]
		return custom_url + urls


	def has_change_permission(self, request, obj = None):
		if self.is_view(request):
			return False
		return super(CoreAdmin, self).has_change_permission(request, obj)


	def has_delete_permission(self, request, obj = None):
		if self.is_view(request):
			return False
		return super(CoreAdmin, self).has_delete_permission(request, obj)


	def is_view(self, request):
		return request.path[-6:] == '/view/'


	class Media:
		css = {
			# 'all': ('css/admin/custom.css',)
		}


class CustomAdmin(CoreAdmin):
	def get_urls(self):
		urls = super().get_urls()
		my_urls = [
			path('stats/', StatsViews.as_view(), name = 'admin-stats'),
			path('user-stats/', UserStats.as_view(), name = 'user-stats'),
			path('duration-paid/', DurationPaidStatsViews.as_view(), name = 'duration-user-stats'),
			path('user-active-stats/', UserActiveStats.as_view(), name = 'user-active-stats'),
			path('cs-report/', CrispReport.as_view(), name = 'crisp-report'),
			path('cs-report/<int:index>', CrispReport.as_view(), name = 'crisp-report-index'),
			path('user-report/', LitCUserReport.as_view(), name = 'litc-report'),
			path('user-report/<int:index>', LitCUserReport.as_view(), name = 'litc-report-index'),
		]
		return my_urls + urls


admin.site.register(MyAdmin, CustomAdmin)
