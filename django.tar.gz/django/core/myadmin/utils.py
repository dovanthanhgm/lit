from dateutil.utils import today
from django.db.models import Q, Count

from channels.models import Channel
from subscription.models import UserSubscription


class MyAdminUtils:
	ACTION_PERMISSION = {
		'process_stop': ('channels.manager_process',),
		'process_start': ('channels.manager_process',),
		'process_clone': ('channels.manager_process',)
	}


	def has_permission(self, user, action):
		if action not in self.ACTION_PERMISSION:
			return True
		permissions = self.ACTION_PERMISSION[action]
		for permission in permissions:
			if not user.has_perm(permission):
				return False
		return True


	def total_user_report(self):

		from accounts.models import UserAccount
		current_time = today()
		user_query = UserAccount.objects.filter(is_staff = False).values('id')
		total_user = UserAccount.objects.filter(is_staff = False).count()
		mainstore_query_set = Channel.objects.filter(default = 1, deleted_at__isnull = True).values('user_id')
		total_user_with_mainstore_queryset = UserAccount.objects.filter(id__in = mainstore_query_set, is_staff = False).count()
		channel_query_set = Channel.objects.filter(deleted_at__isnull = True).exclude(default = 1).values('user_id')
		total_user_with_channel_queryset = UserAccount.objects.filter(id__in = channel_query_set, is_staff = False).count()
		# active_queryset = UserSubscription.objects.exclude(plan_id__in = [1, 8]).filter(Q(expired_at__isnull = True) | Q(expired_at__gt = current_time.strftime("%Y-%m-%d 00:00:00"))).values('user_id')
		# total_user_active = UserAccount.objects.filter(id__in = active_queryset, is_staff = False, is_trial = False).count()
		user_query_set = UserAccount.objects.filter(is_staff = False, is_trial = False).values('id')
		user_trial_set = UserAccount.objects.filter(is_staff = False, is_trial = True).values('id')
		expired_queryset = UserSubscription.objects.exclude(plan_id__in = [1, 8]).filter(user_id__in = user_query_set).filter(Q(expired_at__isnull = False) & Q(expired_at__lte = current_time.strftime("%Y-%m-%d 00:00:00"))).count()
		trial_expired_queryset = UserSubscription.objects.exclude(plan_id__in = [1, 8]).filter(user_id__in = user_trial_set).filter(Q(expired_at__isnull = False) & Q(expired_at__lte = current_time.strftime("%Y-%m-%d 00:00:00"))).count()
		trial_active_queryset = UserSubscription.objects.exclude(plan_id__in = [1, 8]).filter(user_id__in = user_trial_set).filter(Q(expired_at__isnull = True) | Q(expired_at__gte = current_time.strftime("%Y-%m-%d 00:00:00"))).count()
		plan_queryset = list(UserSubscription.objects.exclude(plan_id__in = [1, 8]).filter(Q(expired_at__isnull = True) | Q(expired_at__gte = current_time.strftime("%Y-%m-%d 00:00:00"))).filter(user_id__in = user_query_set).values('plan_id', 'yearly_paid').annotate(total = Count('id')).order_by('-total'))
		# plan_autorenew_queryset = list(UserSubscription.objects.exclude(plan_id__in = [1, 8]).filter(Q(expired_at__isnull = True) | Q(expired_at__gte = current_time.strftime("%Y-%m-%d 00:00:00"))).filter(user_id__in = user_query_set).values('yearly_paid').annotate(total = Count('id')).order_by('-total'))
		total_user_active = sum([row['total'] for row in plan_queryset])
		details_user_active = dict()
		for row in plan_queryset:
			if not details_user_active.get(row.get('plan_id')):
				details_user_active[row['plan_id']] = {
					'plan_id': row['plan_id'],
					'total': row['total']
				}
			else:
				details_user_active[row['plan_id']]['total'] += row['total']

		user_data = {
			'total_user': total_user,
			'total_user_with_mainstore': total_user_with_mainstore_queryset,
			'total_user_with_channel': total_user_with_channel_queryset,
			'total_user_active': total_user_active,
			'total_user_trial_active': trial_active_queryset,
			'total_user_expired': expired_queryset,
			'total_user_trial_expired': trial_expired_queryset,
			'details_user_active': list(details_user_active.values()),
			'details_user_active_monthly': plan_queryset,
		}
		return user_data
