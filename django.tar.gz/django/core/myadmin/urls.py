from django.urls import path, include

from core.myadmin.views import ProcessAdminApi

urlpatterns = [
	path('/action/<str:action>', ProcessAdminApi.as_view(), name = 'admin.action'),
]
