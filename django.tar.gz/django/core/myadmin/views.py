import datetime
import dateutil.relativedelta
from django.db.models import Count, Avg, Q, Sum, Value, CharField
from django.db.models.functions import ExtractWeekDay, Concat
from django.forms import model_to_dict
from django.http import HttpResponseForbidden, HttpResponseNotFound, JsonResponse
# Create your views here.
from django.shortcuts import render
from django.template.loader import render_to_string
from django.views.generic import TemplateView
from rest_framework import generics

from accounts.permission import IsStaff
from channels.models import Channel
from core.myadmin.utils import MyAdminUtils
from core.responses import ErrorResponse, ResponseObject
from crisp.models import CrispMessageModel, CrispConversationModel, CrispUserModel, CrispUserMessageFaults, CrispUserHistoryModel, CrispDailyReportModel
from datasync.api.sync import SyncApi
from libs.models.collections.state import State
from libs.utils import to_str, to_int, html_unquote, to_decimal, json_decode, to_len
from processes.utils import ProcessUtils
from scheduler.models import Scheduler
from scheduler.utils import SchedulerUtils
from subscription.models import UserSubscription, Subscription


class ProcessAdminApi(generics.CreateAPIView):
	permission_classes = (IsStaff,)


	def post(self, request, *args, **kwargs):
		action = to_str(kwargs['action']).replace('-', '_').rstrip(' _')
		if not hasattr(self, action):
			return HttpResponseNotFound()
		if not MyAdminUtils().has_permission(request.user, action):
			return HttpResponseForbidden()
		return getattr(self, action)(request, *args, **kwargs)


	def process_action_update(self, process):
		model_state = State()
		model_state.set_user_id(process.user_id)
		state = model_state.get(process.state_id)
		if state['push']['process']['products'].get('custom_condition'):
			post_data = {
				'condition': {
					'products': state['push']['process']['products'].get('custom_condition')
				}
			}
		else:
			post_data = {
				'condition': {
					'products': [
						{
							'field': f"channel.channel_{process.channel_id}.product_id",
							'value': '',
							'condition': '>'
						}
					]
				}
			}
		return SyncApi(process_id = process.id).post('product/update/{}'.format(process.id), data = post_data)


	def process_action_push(self, process):
		model_state = State()
		model_state.set_user_id(process.user_id)
		state = model_state.get(process.state_id)
		if state['push']['process']['products'].get('custom_condition'):
			post_data = {
				'condition': {
					'products': state['push']['process']['products'].get('custom_condition')
				}
			}
		else:
			post_data = {
				'condition': {
					'products': [
						{
							'field': f"channel.channel_{process.channel_id}.product_id",
							'value': '',
							'condition': '>'
						}
					]
				}
			}
		if state['push']['process']['products'].get('src_channel_id'):
			post_data['src_channel_id'] = state['push']['process']['products'].get('src_channel_id')
		return SyncApi(process_id = process.id).post(f"/channel/push/{process.id}", data = post_data)


	def process_action_sync(self, process):
		return SyncApi(process_id = process.id).post('product/sync/{}'.format(process.id))


	def process_action(self, request, *args, **kwargs):
		process_id = request.data.get('process_id')
		action = request.data.get('action')
		if not process_id or action not in ('stop', 'start', 'clone', 'pull', 'push', 'update', 'refresh', 'sync'):
			return HttpResponseNotFound()
		process = ProcessUtils().get(process_id)
		if not process:
			return HttpResponseNotFound()
		if hasattr(self, f"process_action_{action}"):
			action_response = getattr(self, f"process_action_{action}")(process)
		else:
			path = f"/process/{action}/{process_id}"
			if action in ('pull', 'push'):
				path = f"/channel/{action}/{process_id}"
			action_response = SyncApi(process_id = process_id).post(path)
		if not action_response or action_response['result'] != 'success':
			return JsonResponse(ErrorResponse(errors = action_response['msg']).to_dict(), status = 400)
		status = ''
		if action == 'pull':
			status = 'pulling'
		elif action == 'push':
			status = 'pushing'
		elif action == 'start':
			model_state = State()
			model_state.set_user_id(process.user_id)
			state = model_state.get(process.state_id)
			if state['resume']['action'] == 'pull':
				status = 'pulling'
			else:
				status = 'pushing'
		elif action == 'stop':
			status = 'stopped'
		if status:
			process.status = status
			process.save()
		ProcessUtils.save_process_history(user = request.user, sync = process, action = action, detail = action_response)

		res_change = ProcessUtils().extra_change_view(process)
		rendered = render_to_string('admin/channels/process/process.html', res_change)
		return JsonResponse(ResponseObject(data = rendered).to_dict())


	def load_process(self, request, *args, **kwargs):
		process_id = request.data.get('process_id')
		if not process_id:
			return HttpResponseNotFound()
		process = ProcessUtils().get(process_id)
		if not process:
			return HttpResponseNotFound()
		res_change = ProcessUtils().extra_change_view(process)
		rendered = render_to_string('admin/channels/process/process.html', res_change)
		return JsonResponse(ResponseObject(data = rendered).to_dict())


	def scheduler_add_job(self, request, *args, **kwargs):
		scheduler_id = request.data.get('scheduler_id')
		try:
			scheduler = Scheduler.objects.get(pk = scheduler_id)
		except Scheduler.DoesNotExist:
			return HttpResponseNotFound()
		job = SchedulerUtils().add_job(scheduler)
		if not job or job['result'] != 'success':
			msg = job['msg'] if job else 'Something error'
			return JsonResponse(ResponseObject(message = msg, code = 400).to_dict())
		return JsonResponse(ResponseObject().to_dict(), status = 200)


	def scheduler_delete_job(self, request, *args, **kwargs):
		scheduler_id = request.data.get('scheduler_id')
		try:
			scheduler = Scheduler.objects.get(pk = scheduler_id)
		except Scheduler.DoesNotExist:
			return HttpResponseNotFound()
		delete_job = SyncApi(process_id = scheduler.process_id).delete(f"scheduler/{scheduler.id}")
		if not delete_job or delete_job['result'] != 'success':
			msg = delete_job['msg'] if delete_job else 'Something error'
			return JsonResponse(ResponseObject(message = msg, code = 400).to_dict())
		scheduler.status = 'stopped'
		scheduler.save()
		return JsonResponse(ResponseObject().to_dict(), status = 200)


class StatsViews(TemplateView):
	def get(self, request, *args, **kwargs):
		context = kwargs

		return render(request, 'admin/stats/index.html', context)


class UserStats(TemplateView):
	def get(self, request, *args, **kwargs):
		context = kwargs

		return render(request, 'admin/stats/user_stats.html', context)
class DurationPaidStatsViews(TemplateView):
	def get(self, request, *args, **kwargs):
		context = kwargs

		return render(request, 'admin/stats/duration_paid.html', context)
class UserActiveStats(TemplateView):
	def get(self, request, *args, **kwargs):
		context = kwargs

		return render(request, 'admin/stats/user_active_stats.html', context)
class BaseReport(TemplateView):
	REPORT_TYPE = []
	FOLDER_REPORT = ''
	def get(self, request, *args, **kwargs):
		index_report = kwargs.get('index', 0)
		report_type = self.REPORT_TYPE[index_report]
		report_data = getattr(self, report_type['def'])(request, *args, **kwargs)
		return render(request, f'admin/stats/{self.FOLDER_REPORT}/{report_type["template"]}.html', {'folder_report': self.FOLDER_REPORT,'report_data': report_data, 'index_report': index_report, 'menu_report': self.REPORT_TYPE, 'report_type': report_type})
class CrispReport(BaseReport):
	FOLDER_REPORT = 'crisp'
	REPORT_TYPE = [
		{
			'name': 'Daily Report',
			'def': 'daily_report',
			'template': 'daily',
			'date_filter_type': 'datefilter'
		},
		{
			'name': 'Monthly Report',
			'def': 'monthly_report',
			'template': 'monthly',
			'date_filter_type': 'month'
		},
		{
			'name': 'Monthly Details Report',
			'def': 'monthly_details_report',
			'template': 'monthly_details',
			'date_filter_type': 'month',
			'extend_filter': ['all_operator']
		},
		{
			'name': 'Shift Table',
			'def': 'shift_table',
			'template': 'shift_table',
			'date_filter_type': 'month',
			'extend_filter': ['all_operator']
		}
	]

	def monthly_details_report(self, request, *args, **kwargs):

		month_filter = request.GET.get('monthfilter')
		if not month_filter:
			month_filter = datetime.datetime.today().strftime('%Y-%m')
		new_time = datetime.datetime.strptime(f"{month_filter}-01", "%Y-%m-%d")
		next_time = new_time + dateutil.relativedelta.relativedelta(months = 1)
		time_filter = dict(
			timestamp__gte = f"{month_filter}-01 00:00:00", timestamp__lt = next_time.strftime("%Y-%m-%d 00:00:00")
		)
		exclude = dict(type__in = ['note', 'event'])
		query_set = CrispMessageModel.objects.filter(from_operator = True, **time_filter).exclude(**exclude).order_by().values('from_nickname').distinct()
		all_operator = list(query_set)
		all_operator = [row['from_nickname'] for row in all_operator]
		all_operator.sort()
		from_nickname = html_unquote(request.GET.get('from_nickname')) or all_operator[0]

		month_stats = list(CrispMessageModel.objects.filter(**time_filter).filter(Q(from_operator = False) | Q(from_operator = True, from_nickname = from_nickname)).exclude(**exclude).values('accounting', 'session_id', 'from_nickname', 'shift', 'from_operator').order_by().annotate(total = Count('id')))
		all_session_ids = list(set([row['session_id'] for row in month_stats]))
		sessions = list(CrispConversationModel.objects.filter(session_id__in = all_session_ids, is_blocked = False))
		all_sessions = {row.session_id: row for row in sessions}
		all_accounting = list(set([row['accounting'] for row in month_stats]))
		all_accounting.sort()
		month_data = {}
		for accounting in all_accounting:
			stats = list(filter(lambda x: x['accounting'] == accounting, month_stats))
			data = []
			for shift in range(0, 6):
				shift_data = {
					# 'no_operator': []
				}
				messages_in_shift = list(filter(lambda x: x['shift'] == shift, stats))
				if not messages_in_shift:
					data.append([])
					continue
				session_ids = list(set([row['session_id'] for row in messages_in_shift]))
				total_message_from_user = dict()
				for session_id in session_ids:
					if not all_sessions.get(session_id):
						continue
					session_first_message = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, **time_filter).exclude(**exclude).order_by('message_time').first()
					session_last_message = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, **time_filter).exclude(**exclude).order_by('message_time').last()
					session_data = model_to_dict(all_sessions[session_id])
					session_data['first_msg_type'] = session_first_message.origin
					session_data['chat_start'] = session_first_message.timestamp.strftime('%H:%M:%S')
					session_data['chat_end'] = session_last_message.timestamp.strftime('%H:%M:%S')
					total_from_user = 0
					is_from_operator = False
					from_user = list(filter(lambda x: x['session_id'] == session_id and not x['from_operator'], messages_in_shift))
					if from_user:
						from_user = from_user[0]
						from_user['session_data'] = session_data
					from_operator = list(filter(lambda x: x['session_id'] == session_id and x['from_operator'], messages_in_shift))
					if not from_operator:
						continue
						shift_data['no_operator'].append(from_user)
					for row in from_operator:
						row['session_data'] = session_data
						row['total_from_user'] = from_user['total'] if from_user else 0
						session_first_message_operator = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, from_operator = True, from_nickname = row['from_nickname'], **time_filter).exclude(**exclude).order_by('message_time').first()
						art_time = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, from_operator = True, from_nickname = row['from_nickname'], response_time__gt = 0, **time_filter).exclude(**exclude).aggregate(art = Avg('response_time'))
						row['frt'] = to_int(session_first_message_operator.response_time)
						row['art'] = to_int(art_time['art'])
						row['exceed_one_minute'] = session_first_message_operator.exceed_one_minute
						if not shift_data.get(row['from_nickname']):
							shift_data[row['from_nickname']] = []
						shift_data[row['from_nickname']].append(row)

				data.append(shift_data)
			month_data[accounting] = data
		return {'report_data': month_data, 'month_filter': month_filter, 'all_operator': all_operator, 'from_operator': from_nickname}


	def new_monthly_report_by_level(self, request, is_parttime = False, *args, **kwargs):
		month_filter = request.GET.get('monthfilter')
		if not month_filter:
			month_filter = datetime.datetime.today().strftime('%Y-%m')
		accounting = month_filter.replace('-', '')
		default_filter = { 'level__gte': 8}
		if is_parttime:
			default_filter = {'level__lt': 8}

		if month_filter == datetime.datetime.today().strftime('%Y-%m'):
			all_cs_queryset = CrispUserModel.objects.filter(**default_filter)
		else:
			all_cs_queryset = CrispUserHistoryModel.objects.filter(accounting = accounting, **default_filter)

		all_staff = {}
		for row in all_cs_queryset:
			all_staff[row.name] = row.level
		all_staff_name = list(all_staff.keys())
		query_set = CrispDailyReportModel.objects.filter(accounting_month = accounting, from_nickname__in = all_staff_name).values('from_nickname').order_by().annotate(total_session = Sum('number_of_sessions'), total_chat = Sum('number_of_chats'), total_email = Sum('number_of_emails'), total_message = Sum('number_of_messages'))
		stats = list(filter(lambda x: x['total_chat'] + x['total_email'] > 0, list(query_set)))
		stats.sort(key = lambda x: x['total_chat'] + x['total_email'], reverse = True)
		new_time = datetime.datetime.strptime(f"{month_filter}-01", "%Y-%m-%d")
		next_time = new_time + dateutil.relativedelta.relativedelta(months = 1)
		time_filter = dict(
			timestamp__gte = f"{month_filter}-01 00:00:00", timestamp__lt = next_time.strftime("%Y-%m-%d 00:00:00"), from_operator = True, from_nickname__in = all_staff_name
		)
		exclude = dict(type__in = ['note', 'event'])
		exclude['response_time__isnull'] = True
		query_set_each = CrispMessageModel.objects.filter(**time_filter).exclude(**exclude).values('from_nickname').order_by().annotate(art = Avg('response_time'))
		stats_art = {row['from_nickname']: round(to_decimal(row['art'])) for row in list(query_set_each)}
		total_level = 0
		total_chat = 0
		total_email = 0
		for row in stats:
			level = to_int(all_staff.get(row['from_nickname']))
			total_level += level
			total_chat += row['total_chat']
			total_email += row['total_email']
			row['level'] = level
			row['art'] = stats_art.get(row['from_nickname'], 0)
		message_fault = CrispUserMessageFaults.objects.filter(accounting_month = accounting).values('from_nickname', 'fault_type').annotate(total_fault = Count('id')).order_by('total_fault')
		point_workload = total_chat + total_email * 0.25
		if all_staff_name:
			avg_level = total_level / to_len(all_staff_name)
		else:
			avg_level = 0
		for row in stats:
			row['fault_type_1'] = 0
			row['fault_type_2'] = 0
			for staff_data in message_fault:
				if staff_data['from_nickname'] != row['from_nickname']:
					continue
				row[f'fault_type_{staff_data["fault_type"]}'] = staff_data['total_fault']
			if not is_parttime:
				level_workload = avg_level - row['level']
				if level_workload < 0:
					level_workload = 0 - level_workload
				dif_level_workload = level_workload * 0.5
				row_level = row['level']
				if row['level'] < avg_level:
					row_level += dif_level_workload
				elif row['level'] > avg_level:
					row_level -= dif_level_workload
			else:
				row_level = row['level']
			workload = to_decimal(row_level / total_level * point_workload, 2)
			old_workload = to_decimal(row['level'] / total_level * point_workload, 2)
			workload_percent = row['level'] / total_level * 100
			row['workload'] = round(workload)
			row['old_workload'] = round(old_workload)
			row['actual_workload'] = row['total_chat'] + 0.25 * row['total_email'] - row['workload']
			actual_workload_percent = to_decimal(row['actual_workload'] / row['workload'] * 100, 2)
			old_actual_workload_percent = to_decimal(row['actual_workload'] / row['old_workload'] * 100, 2)
			row['actual_workload_percent'] = to_decimal(actual_workload_percent, 2)
			row['old_actual_workload_percent'] = to_decimal(old_actual_workload_percent, 2)
		return total_chat, stats
	def new_monthly_report(self, request, *args, **kwargs):
		month_filter = request.GET.get('monthfilter')
		if not month_filter:
			month_filter = datetime.datetime.today().strftime('%Y-%m')
		accounting = month_filter.replace('-', '')
		parttime_total_chat, parttime_report = self.new_monthly_report_by_level(request, True, *args, **kwargs)
		fulltime_total_chat, fulltime_report = self.new_monthly_report_by_level(request, False, *args, **kwargs)
		total_chat = parttime_total_chat + fulltime_total_chat
		stats = parttime_report + fulltime_report
		month_filter = request.GET.get('monthfilter')
		if not month_filter:
			month_filter = datetime.datetime.today().strftime('%Y-%m')
		accounting = month_filter.replace('-', '')
		new_time = datetime.datetime.strptime(f"{month_filter}-01", "%Y-%m-%d")
		next_time = new_time + dateutil.relativedelta.relativedelta(months = 1)
		time_filter = dict(
			timestamp__gte = f"{month_filter}-01 00:00:00", timestamp__lt = next_time.strftime("%Y-%m-%d 00:00:00"), from_operator = False
		)
		exclude = dict(type__in = ['note', 'event'])
		query_set = CrispMessageModel.objects.filter(**time_filter).exclude(**exclude).annotate(shiftday=Concat(ExtractWeekDay('timestamp'), Value('-'), 'shift', output_field=CharField())) .values('shiftday').order_by().annotate(total_session = Count('session_id', distinct = True), total_chat = Count('message_shift_id', distinct = True), total_message = Count('message_id', distinct = True))
		query_set = list(query_set)
		shift_report = {}
		weekdays = ['Mon', "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
		for row in query_set:
			weekday, shift = to_str(row['shiftday']).split('-')
			weekday_name = weekdays[to_int(weekday) - 1]
			if not shift_report.get(weekday_name):
				shift_report[weekday_name] = []
			row['shift'] = to_int(shift) + 1
			shift_report[weekday_name].append(row)
		return {"month_filter": month_filter, "report_data": stats, 'total_chat': total_chat, 'accounting': accounting, 'shift_report': shift_report}
	def monthly_report(self, request, *args, **kwargs):
		return self.new_monthly_report(request, *args, **kwargs)
		month_filter = request.GET.get('monthfilter')
		if not month_filter:
			month_filter = datetime.datetime.today().strftime('%Y-%m')
		accounting = month_filter.replace('-', '')
		if month_filter == datetime.datetime.today().strftime('%Y-%m'):
			all_cs_queryset = CrispUserModel.objects.all()
		else:
			all_cs_queryset = CrispUserHistoryModel.objects.filter(accounting = accounting)

		all_staff = {}
		for row in all_cs_queryset:
			all_staff[row.name] = row.level
		all_staff_name = list(all_staff.keys())

		new_time = datetime.datetime.strptime(f"{month_filter}-01", "%Y-%m-%d")
		next_time = new_time + dateutil.relativedelta.relativedelta(months = 1)
		time_filter = dict(
			timestamp__gte = f"{month_filter}-01 00:00:00", timestamp__lt = next_time.strftime("%Y-%m-%d 00:00:00"), from_operator = True, from_nickname__in = all_staff_name
		)
		exclude = dict(type__in = ['note', 'event'])
		query_set = CrispMessageModel.objects.filter(**time_filter).exclude(**exclude).values('from_nickname').order_by().annotate(total_session = Count('session_id', distinct = True), total_chat = Count('message_shift_id', distinct = True), total_message = Count('message_id', distinct = True))
		stats = list(query_set)
		stats.sort(key = lambda x: x['total_chat'], reverse = True)
		exclude['response_time__isnull'] = True
		query_set_each = CrispMessageModel.objects.filter(**time_filter).exclude(**exclude).values('from_nickname').order_by().annotate(art = Avg('response_time'))
		stats_art = {row['from_nickname']: round(to_decimal(row['art'])) for row in list(query_set_each)}
		total_level = 0
		total_chat = 0
		for row in stats:
			level = to_int(all_staff.get(row['from_nickname']))
			total_level += level
			total_chat += row['total_chat']
			row['level'] = level
			row['art'] = stats_art.get(row['from_nickname'], 0)
		message_fault = CrispUserMessageFaults.objects.filter(accounting_month = accounting).values('from_nickname', 'fault_type').annotate(total_fault = Count('id')).order_by('total_fault')
		for row in stats:
			row['fault_type_1'] = 0
			row['fault_type_2'] = 0
			for staff_data in message_fault:
				if staff_data['from_nickname'] != row['from_nickname']:
					continue
				row[f'fault_type_{staff_data["fault_type"]}'] = staff_data['total_fault']
			workload = to_decimal(row['level'] / total_level * total_chat, 2)
			workload_percent = row['level'] / total_level * 100
			row['workload'] = round(workload)
			row['actual_workload'] = row['total_chat'] - row['workload']
			actual_workload_percent = to_decimal(row['actual_workload'] / row['workload'] * 100, 2)
			row['actual_workload_percent'] = to_decimal(actual_workload_percent, 2)
		return {"month_filter": month_filter, "report_data": stats, 'total_chat': total_chat, 'accounting': accounting}


	def shift_table(self, request, *args, **kwargs):
		users = list(CrispUserModel.objects.filter(status = True))
		users_nickname = [row.name for row in users]
		report_data = []
		fields = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
		for shift in range(0, 6):
			data = list()
			for day in fields:
				day_data = list()
				for user in users:
					day_shift = json_decode(getattr(user, f'shift_{day}'))
					if day_shift and to_str(shift) in day_shift:
						day_data.append({
							'name': user.name,
							'index': users_nickname.index(user.name) + 1
						})

				data.append(day_data)
			report_data.append(data)
		return {'report_data': report_data}
	def daily_report(self, request, *args, **kwargs):
		date_filter = request.GET.get('datepicker')
		if not date_filter:
			date_filter = datetime.datetime.today().strftime('%Y-%m-%d')
		time_filter = dict(
			timestamp__gte = f"{date_filter} 00:00:00", timestamp__lte = f"{date_filter} 23:59:59"
		)
		exclude = dict(type__in = ['note', 'event'])
		stats = list(CrispMessageModel.objects.filter(**time_filter).exclude(**exclude).values('session_id', 'from_nickname', 'shift', 'from_operator').order_by().annotate(total = Count('id')))
		all_session_ids = list(set([row['session_id'] for row in stats]))
		sessions = list(CrispConversationModel.objects.filter(session_id__in = all_session_ids, is_blocked = False))
		all_sessions = {row.session_id: row for row in sessions}
		data = []
		for shift in range(0, 6):
			shift_data = {
				'no_operator': []
			}
			messages_in_shift = list(filter(lambda x: x['shift'] == shift, stats))
			if not messages_in_shift:
				data.append([])
				continue
			session_ids = list(set([row['session_id'] for row in messages_in_shift]))
			total_message_from_user = dict()
			for session_id in session_ids:
				if not all_sessions.get(session_id):
					continue
				session_first_message = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, **time_filter).exclude(**exclude).order_by('message_time').first()
				session_last_message = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, **time_filter).exclude(**exclude).order_by('message_time').last()
				session_data = model_to_dict(all_sessions[session_id])
				session_data['first_msg_type'] = session_first_message.origin
				session_data['chat_start'] = session_first_message.timestamp.strftime('%H:%M:%S')
				session_data['chat_end'] = session_last_message.timestamp.strftime('%H:%M:%S')
				total_from_user = 0
				is_from_operator = False
				from_user = list(filter(lambda x: x['session_id'] == session_id and not x['from_operator'], messages_in_shift))
				if from_user:
					from_user = from_user[0]
					from_user['session_data'] = session_data
				from_operator = list(filter(lambda x: x['session_id'] == session_id and x['from_operator'], messages_in_shift))
				if not from_operator:
					shift_data['no_operator'].append(from_user)
				for row in from_operator:
					row['session_data'] = session_data
					row['total_from_user'] = from_user['total'] if from_user else 0
					session_first_message_operator = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, from_operator = True, from_nickname = row['from_nickname'], **time_filter).exclude(**exclude).order_by('message_time').first()
					art_time = CrispMessageModel.objects.filter(shift = shift, session_id = session_id, from_operator = True, from_nickname = row['from_nickname'], response_time__gt = 0, **time_filter).exclude(**exclude).aggregate(art = Avg('response_time'))
					row['frt'] = to_int(session_first_message_operator.response_time)
					row['art'] = to_int(art_time['art'])

					if not shift_data.get(row['from_nickname']):
						shift_data[row['from_nickname']] = []
					shift_data[row['from_nickname']].append(row)

			data.append(shift_data)

		return {'report_data': data, 'date_filter': date_filter}


class LitCUserReport(BaseReport):
	FOLDER_REPORT = 'litc'
	REPORT_TYPE = [
		{
			'name': 'User Expired Report',
			'def': 'user_expired_report',
			'template': 'user_expired_report',
			'date_filter_type': 'month',
			'export_support': ['excel', 'csv', 'pdf']
		},
	]
	def user_expired_report(self, request, *args, **kwargs):
		month_filter = request.GET.get('monthfilter')
		if not month_filter:
			month_filter = datetime.datetime.today().strftime('%Y-%m')
		new_time = datetime.datetime.strptime(f"{month_filter}-01", "%Y-%m-%d")
		if month_filter == datetime.datetime.today().strftime('%Y-%m'):
			next_time = datetime.datetime.today()
		else:
			next_time = new_time + dateutil.relativedelta.relativedelta(months = 1)

		time_filter = dict(
			auto_renew = False,
			expired_at__gte = f"{month_filter}-01 00:00:00", expired_at__lt = next_time.strftime("%Y-%m-%d 00:00:00")
		)
		exclude = dict(plan_id__in = [1, 8])
		user_expired = UserSubscription.objects.filter(**time_filter).exclude(**exclude).order_by('expired_at')
		report_data = list()
		plans = Subscription.objects.exclude(id__in = [1, 8]).filter(type = 'system')
		plan_data = {plan.id: plan.name for plan in plans}
		user_ids = [plan.user_id for plan in user_expired]
		channels = Channel.objects.filter(user_id__in = user_ids)
		user_channel = dict()
		for channel in channels:
			if not user_channel.get(channel.user_id):
				user_channel[channel.user_id] = list()
			user_channel[channel.user_id].append({
				'id': channel.id,
				'type': channel.type,
				'number_products_linked': channel.number_products_linked,

			})
		for row in user_expired:
			report_data.append({
				'plan': plan_data[row.plan_id],
				'user': row.user.email,
				'user_id': row.user.id,
				'expired_at': row.expired_at.strftime('%Y-%m-%d'),
				'channels': user_channel.get(row.user.id)
			})
		return {'report_data': report_data, 'month_filter': month_filter}
