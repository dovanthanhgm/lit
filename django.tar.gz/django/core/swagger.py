from drf_yasg.inspectors import PaginatorInspector
from drf_yasg import openapi
from collections import OrderedDict
from rest_framework.pagination import LimitOffsetPagination, PageNumberPagination, CursorPagination


NotHandled = object()


class DjangoRestResponsePagination(PaginatorInspector):
	"""Provides response schema pagination warpping for django-rest-framework's LimitOffsetPagination,
    PageNumberPagination and CursorPagination
    """

	def get_paginated_response(self, paginator, response_schema):
		assert response_schema.type == openapi.TYPE_ARRAY, "array return expected for paged response"
		paged_schema = None
		if isinstance(paginator, (LimitOffsetPagination, PageNumberPagination, CursorPagination)):
			has_count = not isinstance(paginator, CursorPagination)
			paged_schema = openapi.Schema(
				type = openapi.TYPE_OBJECT,
				properties = OrderedDict((
					('code', openapi.Schema(type = openapi.TYPE_INTEGER, title = 'status', example = 200)),
					('message', openapi.Schema(type = openapi.TYPE_STRING, example = 'success')),
					('count', openapi.Schema(type = openapi.TYPE_INTEGER) if has_count else None),
					('data', response_schema),
				)),
				required = ['data']
			)

			if has_count:
				paged_schema.required.insert(0, 'count')

		return paged_schema
