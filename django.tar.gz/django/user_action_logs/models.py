# Create your models here.
from django.db import models

# Create your models here.
from accounts.models import UserAccount
from channels.models import Channel

action_log = (
	('pull', 'Import From Channel'),
	('refresh', 'Update From Channel'),
	('push', 'Save & publish'),
	('channel_save', 'Save Listing'),
	('update', 'Update To Channel'),
	('setting_save', 'Channel Setting Save'),
	('etsy_renew', 'Etsy: Renew'),
	('etsy_delete', 'Etsy: Delete From Etsy'),
	('ebay_relist', 'Ebay: Relist'),
	('ebay_end', 'Ebay: End Listing'),
	('active', 'Active Listing'),
	('delete', 'Delete In LitC'),
	('disable_refresh', 'Disable Auto Update'),
	('disable_autoimport', 'Disable Auto Import'),
	('enable_auto_import', 'Enable Auto Import'),
	('enable_refresh', 'Enable Auto Update'),
	('enable_autoimport', 'Enable Auto Import'),
	('delete_channel', 'Delete Channel'),
	('delete_product', 'Delete Product'),
	('delete_feed', 'Delete Feed'),
	('update_template', 'Update Template'),
)
class UserActionLogs(models.Model):
	"""
	Class Transaction
	"""

	user = models.ForeignKey(
		UserAccount,
		on_delete = models.CASCADE,
		null = False
	)
	action = models.CharField(max_length = 255, null = False, blank = False, choices = action_log)
	channel_id = models.IntegerField(null = True)
	# channel = models.ForeignKey(Channel, on_delete = models.CASCADE)

	data = models.TextField(null = True, blank = True)
	note = models.TextField(null = True, blank = True)
	created_at = models.DateTimeField(auto_now_add = True)
	ip_address = models.CharField(null = True, blank = True, max_length = 255)

	class Meta:
		db_table = 'user_action_logs'
		ordering = ['-id']
