from libs.utils import log_traceback, json_encode, get_client_ip
from user_action_logs.models import UserActionLogs


class UserActionLogUtils:
	def create_log(self, user_id = None, channel_id = None, action = None, data = None, note = None, request = None):
		try:
			if not data and request and request.data:
				data = request.data
			if data and isinstance(data, (dict, list, tuple)):
				data = json_encode(data)
			kwargs = dict(
				user_id = user_id,
				channel_id = channel_id,
				action = action,
				data = data,
				note = note
			)
			if request:
				ip_address = get_client_ip(request)
				if ip_address:
					kwargs['ip_address'] = ip_address
			UserActionLogs.objects.create(**kwargs)
		except Exception:
			log_traceback()
		return
