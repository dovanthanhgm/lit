from django.apps import AppConfig


class UserActionLogsConfig(AppConfig):
    name = 'user_action_logs'
