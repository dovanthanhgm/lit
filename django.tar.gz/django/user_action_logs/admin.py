from django.contrib import admin
# Register your models here.
from django.urls import reverse
from django.utils.html import format_html

from core.myadmin.admin import CoreAdmin, UserFilter, InputFilter
from libs.utils import to_str
from user_action_logs.models import UserActionLogs


class ChannelFilter(InputFilter):
	parameter_name = 'channel'
	title = ('Channel ID',)


	def queryset(self, request, queryset):
		if self.value() is not None and to_str(self.value()).isnumeric():
			channel = self.value()
			return queryset.filter(channel_id = channel)


class UserActionLogsAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'channel_link','ip_address' ,'created_at', 'action', 'data', 'note']
	list_filter = [UserFilter, 'action', ChannelFilter, 'created_at']


	def channel_link(self, obj):
		if obj.channel_id:
			url = reverse("admin:channels_channel_change", args = (obj.channel_id,))
			return format_html(f"<a href='{url}' target='_blank' class='_link''><u>{obj.channel_id}</u></a>")
		return ''


	channel_link.short_description = 'Channel'


	def has_change_permission(self, request, obj = None):
		return False


	# def has_delete_permission(self, request, obj = None):
	# 	return False


	def has_add_permission(self, request):
		return False


admin.site.register(UserActionLogs, UserActionLogsAdmin)
