from django.apps import AppConfig


class AdminplusConfig(AppConfig):
    name = 'adminplus'
