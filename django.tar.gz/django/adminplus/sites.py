from django.conf.urls import url
from django.contrib.admin import AdminSite
from django.utils.module_loading import autodiscover_modules

from adminplus.views import DashboardWelcomeView


class AdminMixin(object):
    """Mixin for AdminSite to allow custom dashboard views."""


    def get_urls(self):
        """Add our dashboard view to the admin urlconf. Deleted the default index."""
        from django.urls import path

        urls = super(AdminMixin, self).get_urls()
        del urls[0]
        custom_url = [url('', self.admin_view(DashboardWelcomeView.as_view()),
                                  name = "index")]

        return custom_url + urls


class SitePlus(AdminSite):
    """
    A Django AdminSite with the AdminMixin to allow registering custom
    dashboard view.
    """

site = SitePlus()