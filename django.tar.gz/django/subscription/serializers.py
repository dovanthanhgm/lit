from rest_framework import serializers

from subscription.models import Subscription


class SubscriptionSerializer(serializers.ModelSerializer):
	class Meta:
		model = Subscription
		fields = ["id", "name", "monthly_fee", "yearly_fee", "description", "products_limit", "orders_limit", "features", "paypal_monthly_plan_id", "paypal_yearly_plan_id"]




