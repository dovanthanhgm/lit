from django_filters import FilterSet

from accounts.utils import AccountUtils
from merchant.wix.models import MerchantWixSubscription
from subscription.models import Subscription


class SubscriptionFilterSystem(FilterSet):
	PLAN_TYPE = 'system'


	class Meta:
		model = Subscription
		fields = ['name', 'monthly_fee', 'yearly_fee', 'description', 'products_limit', 'orders_limit', 'features', 'sync_frequency', 'type', 'user_id']


	@property
	def qs(self):
		channel = super().qs
		return channel.filter(type = self.PLAN_TYPE)


class WixSubscriptionFilter(SubscriptionFilterSystem):
	@property
	def qs(self):
		channel = super().qs
		inner_qs = MerchantWixSubscription.objects.all().values('plan_id')
		return channel.filter(id__in = inner_qs)


class SubscriptionFilterCustom(SubscriptionFilterSystem):
	PLAN_TYPE = 'custom'


	@property
	def qs(self):
		channel = super().qs
		user_id = AccountUtils().get_user_id(self.request)

		return channel.filter(user_id = user_id)