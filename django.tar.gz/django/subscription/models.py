from django.db import models

from accounts.models import UserAccount


# Create your models here.


class Subscription(models.Model):
	name = models.CharField(default = '', null = False, max_length = 25)
	monthly_fee = models.IntegerField(null = False)
	yearly_fee = models.IntegerField(null = False)
	description = models.TextField(null = True, blank = True)
	products_limit = models.IntegerField(null = False, default = 0)
	orders_limit = models.IntegerField(null = False, default = 0)
	feeds_limit = models.IntegerField(null = False, default = 0)
	channels_limit = models.IntegerField(null = False, default = 0)
	features = models.TextField(null = True, blank = True)
	sync_frequency = models.IntegerField(null = False, default = 0)
	order_sync_frequency = models.IntegerField(null = False, default = 0)
	type = models.CharField(max_length = 25, default = 'system', null = False, blank = False, choices = (('system', 'System'), ('custom', 'Custom')))
	user_id = models.IntegerField(null = True, blank = True)
	paypal_monthly_plan_id = models.CharField(null = True, max_length = 125, blank = True)
	paypal_yearly_plan_id = models.CharField(null = True, max_length = 125, blank = True)
	class Meta:
		db_table = "subscription_plan"
		ordering = ['monthly_fee']


	def __str__(self):
		return self.name


class UserSubscription(models.Model):
	user = models.OneToOneField(UserAccount, on_delete = models.CASCADE)
	plan = models.ForeignKey(Subscription, on_delete = models.CASCADE)
	started_at = models.DateTimeField(auto_now_add = False, null = True, blank = True)
	expired_at = models.DateTimeField(auto_now_add = False, null = True, blank = True)
	cancelled_at = models.DateTimeField(auto_now_add = False, null = True, blank = True)
	start_month_at = models.CharField(max_length = 255, null = True)
	yearly_paid = models.IntegerField(choices = ((0, 'No'), (1, 'Yes')), null = False, default = 0)
	plan_paid = models.ForeignKey(Subscription, on_delete = models.CASCADE, related_name = "plan_paid", null = True, blank = True)
	cancel_at_the_end = models.IntegerField(null = False, default = 0, choices = ((0, 'No'), (1, "Yes")))
	auto_renew = models.BooleanField(default = False, null = False)
	solve_expired = models.BooleanField(default = False, null = False)
	plan_expired_noti_1 = models.BooleanField(default = False, null = False)
	products_limit = models.IntegerField(null = True, blank = True)
	orders_limit = models.IntegerField(null = True, blank = True)
	feeds_limit = models.IntegerField(null = True, blank = True)
	channels_limit = models.IntegerField(null = True, blank = True)
	paypal_subscription_id = models.CharField(null = True, blank = True, max_length = 125)
	paypal_payment_failed = models.BooleanField(default = False, null = False)
	payment_method = models.CharField(null = True, blank = True, max_length = 125)
	channel_payment = models.IntegerField(null = True, blank = True)
	subscription_fee = models.IntegerField(null = True, blank = True)

	class Meta:
		db_table = "user_subscription_plan"
		ordering = ['expired_at']


	def __str__(self):
		return 'User {} - {}'.format(self.user, self.plan)


class UserSubscriptionHistory(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE)
	old_plan = models.ForeignKey(Subscription, on_delete = models.CASCADE)
	old_plan_yearly_paid = models.IntegerField(choices = ((0, 'No'), (1, 'Yes')), null = False, default = 0)
	old_plan_started_at = models.DateTimeField(auto_now_add = False, null = True)
	old_plan_expired_at = models.CharField(max_length = 255, null = True)
	old_plan_channels_limit = models.IntegerField( null = True)
	old_plan_products_limit = models.IntegerField( null = True)
	new_plan = models.ForeignKey(Subscription, on_delete = models.CASCADE, related_name = 'new_plan')
	new_plan_yearly_paid = models.IntegerField(choices = ((0, 'No'), (1, 'Yes')), null = False, default = 0)
	new_plan_started_at = models.DateTimeField(auto_now_add = False, null = True)
	new_plan_expired_at = models.CharField(max_length = 255, null = True)
	new_plan_channels_limit = models.IntegerField(null = True)
	new_plan_products_limit = models.IntegerField(null = True)
	created_at = models.DateTimeField(auto_now_add = True, null = True)
	payment_method = models.CharField(null = True, blank = True, max_length = 125)
	channel_payment = models.IntegerField(null = True, blank = True)
	new_plan_subscription_fee = models.IntegerField(null = True)
	old_plan_subscription_fee = models.IntegerField(null = True)

	class Meta:
		db_table = "user_subscription_plan_history"
		ordering = ['-created_at']


	def __str__(self):
		if self.old_plan.id != self.new_plan.id:
			return 'Change {} to {}'.format(self.old_plan, self.new_plan)
		return f"Renew Plan {self.old_plan}"


class TokenPaymentMethod(models.Model):
	access_token = models.TextField(null = False, default = '')
	payment_method = models.CharField(null = False, default = '', max_length = 255)

	class Meta:
		db_table = "token_payment_method"


class SubscriptionRenewException(models.Model):
	user_id = models.IntegerField(null = True, blank = True)
	plan_id = models.IntegerField(null = True, blank = True)

	status = models.BooleanField(default = False)
	created_at = models.DateTimeField(auto_now_add = True, null = True)
	exceptions = models.TextField(null = False)
	class Meta:
		db_table = "subcription_renew_exception"