from django.urls import path

from .views import SubscriptionApiView, SubscriptionApiDetailsView, SubscriptionMeDetailsView, SubscriptionUpgradeApiView, SubscriptionSelectApiView

urlpatterns = [
	path("", SubscriptionApiView.as_view(), name = "subscriptions.list"),
	path("/me/select/<int:plan_id>", SubscriptionSelectApiView.as_view(), name = "subscriptions.upgrade"),
	path("/me/upgrade", SubscriptionUpgradeApiView.as_view(), name = "subscriptions.upgrade"),
	path("/me", SubscriptionMeDetailsView.as_view(), name = "subscriptions.me"),
	path("/<int:pk>", SubscriptionApiDetailsView.as_view(), name = "subscription.details"),
]
