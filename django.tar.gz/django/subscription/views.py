from datetime import datetime
from time import time

from django.db import transaction
from django.forms import model_to_dict
from django.http import HttpResponseNotFound, JsonResponse
# Create your views here.
from django.shortcuts import get_object_or_404
from rest_framework import generics

from accounts.utils import AccountUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from core.permission import IsPrivate
from core.responses import ResponseObject, ErrorResponse, PaginationResponse
from coupons.utils import CouponUtils
from libs.models.collections.catalog import Catalog
from libs.utils import to_int, to_str, to_decimal, random_token, get_full_absolute_uri, get_app_url, json_encode
from payments.models import PaymentHistory, PaymentInformation
from payments.utils import PaymentUtils
from products.utils import ProductUtils
from subscription.filter import SubscriptionFilterSystem, SubscriptionFilterCustom, WixSubscriptionFilter
from subscription.models import Subscription, UserSubscription, UserSubscriptionHistory
from subscription.paginations import SubscriptionPagination
from subscription.serializers import SubscriptionSerializer
from subscription.utils import SubscriptionUtils


class SubscriptionApiView(generics.ListAPIView):
	queryset = Subscription.objects.all().order_by('monthly_fee')
	serializer_class = SubscriptionSerializer
	# pagination_class = SubscriptionPagination
	filterset_class = SubscriptionFilterSystem


	def list(self, request, *args, **kwargs):
		if PaymentUtils().get_payment_method_name(request) == 'wix':
			self.filterset_class = WixSubscriptionFilter

		plan = Subscription.objects.filter(user_id = AccountUtils().get_user_id(request))
		if plan:
			self.filterset_class = SubscriptionFilterCustom

		response = super(SubscriptionApiView, self).list(request, *args, **kwargs)
		data = response.data
		response_data = list()
		plan = SubscriptionUtils().get_plan_by_user(AccountUtils().get_user_by_request(request))
		remaining_days = 0
		if not plan['default'] and not plan['expired'] and plan['expired_at'] and plan['monthly_fee']:
			remaining_days = (datetime.strptime(plan['expired_at'], "%Y-%m-%d %H:%M:%S") - datetime.now()).days
		for row in list(data['data']):
			feature = to_str(row['features']).splitlines()
			row['features'] = feature
			row['remaining_days'] = remaining_days
			row['grand_total'] = SubscriptionUtils().remaining_price(plan, row)
			response_data.append(row)
		return JsonResponse(PaginationResponse(data = response_data, count = data['count']).to_dict())


class SubscriptionApiDetailsView(generics.RetrieveAPIView):
	queryset = Subscription.objects.all()
	serializer_class = SubscriptionSerializer


class SubscriptionMeDetailsView(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user(user_id)
		if not user:
			return HttpResponseNotFound()
		plan_data = SubscriptionUtils().get_plan_by_user(user)
		return JsonResponse(plan_data, safe = True)


class SubscriptionUpgradeApiView(generics.CreateAPIView):
	permission_classes = [IsPrivate]


	def post(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user(user_id)
		if not user.balance:
			# email
			return JsonResponse(ResponseObject(code = 400, message = "Out of money").to_dict())
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		date_expired = datetime.strptime(old_plan['expired_at'], "%Y-%m-%d %H:%M:%S")
		today = datetime.today()
		date_difference = date_expired - today
		month_difference = date_difference.days // 30 + 1
		new_plan = Subscription.objects.filter(monthly_fee__gt = to_int(old_plan['monthly_fee'])).order_by('monthly_fee').first()
		if not new_plan:
			return JsonResponse(ResponseObject(code = 400, message = "plan is maximum").to_dict())

		new_plan = model_to_dict(new_plan)
		price_difference = (to_int(new_plan['monthly_fee']) - to_int(old_plan['monthly_fee'])) * month_difference
		if to_int(user.balance) < price_difference:
			# email
			return JsonResponse(ResponseObject(code = 400, message = "Not enough money").to_dict())
		try:
			with transaction.atomic():
				user.balance = to_int(user.balance) - price_difference
				user.save()
				PaymentHistory.objects.create(user_id = user_id, payer_email = user.email, amount = price_difference, total = price_difference, new_balance = user.balance, status = "completed", note = f"Upgrade plan {old_plan['id']} => {new_plan['id']}", name = f"Upgrade plan {old_plan['name']} => {new_plan['name']}")
				user_plan = UserSubscription.objects.get(pk = old_plan['user_plan_id'])
				user_plan.plan_id = new_plan['id']
				user_plan.plan_paid_id = new_plan['id']
				user_plan.save()
		except Exception as e:
			return JsonResponse(ErrorResponse(errors = str(e)).to_dict(), status = 400)
		subscription_history = {
			'user_id': user_id,
			'old_plan_id': old_plan['id'],
			'old_plan_yearly_paid': old_plan['yearly_paid'],
			'old_plan_started_at': old_plan['started_at'],
			'old_plan_expired_at': old_plan['expired_at'],
			'new_plan_id': new_plan.id,
			'new_plan_yearly_paid': old_plan['yearly_paid'],
			'new_plan_started_at': old_plan['started_at'],
			'new_plan_expired_at': old_plan['expired_at'],

		}
		UserSubscriptionHistory.objects.create(**subscription_history)
		# email
		return JsonResponse(ResponseObject(data = new_plan).to_dict())


class SubscriptionSelectApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		plan_id = kwargs['plan_id']
		plan = get_object_or_404(Subscription, pk = kwargs['plan_id'])
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user_by_request(request)
		yearly_billing = request.data.get('yearly_billing')

		if user.is_staff:
			new_plan = SubscriptionUtils().new_user_subscription_plan(user, plan, yearly_billing, **kwargs)
			return JsonResponse(ResponseObject(data = new_plan).to_dict())
		channel_default = ChannelUtils().get_default_channel(user_id)
		# model_catalog = Catalog()
		# model_catalog.set_user_id(user_id)
		# where = model_catalog.create_where_condition(f'channel.channel_{channel_default.id}.product_id', '', '>')
		# where.update(model_catalog.create_where_condition('is_variant', False))
		total_listing = ProductUtils().count_total_product_import(user_id)
		user.total_product = total_listing
		user.save()
		if plan.products_limit and total_listing > plan.products_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_listing} products, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		if plan.channels_limit:
			total_channel = Channel.objects.filter(user_id = user_id, deleted_at__isnull = True, default = False).count()
			if total_channel > plan.channels_limit:
				return JsonResponse(ErrorResponse(errors = f"You have {total_channel} channels, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		payment_method = PaymentUtils().get_payment_method_name(request)
		if not old_plan['default'] and not old_plan.get('expired'):
			if old_plan['user_plan']['payment_method']:
				payment_method = old_plan['user_plan']['payment_method']
			if payment_method != 'shopify':
				if to_int(plan.monthly_fee) < to_int(old_plan['monthly_fee']):
					return JsonResponse(ErrorResponse(errors = f"Your plan is currently: {old_plan['name']}, you can't choose a lower package.").to_dict(), status = 400)

		# plan_paid_id = old_plan['plan_paid'] if old_plan['plan_paid'] else old_plan['id']
			# plan_paid_id = old_plan['id']
			# plan_paid = SubscriptionUtils().get(plan_paid_id)
			# if to_int(plan_paid.monthly_fee) > to_int(old_plan['monthly_fee']):
			# 	price_paid = plan_paid.monthly_fee if to_int(old_plan['yearly_paid']) != 1 else plan_paid.yearly_fee
			# 	if price_paid >= new_price:
			# 		user_plan = UserSubscription.objects.get(pk = old_plan['user_plan_id'])
			# 		user_plan.plan_id = plan_id
			# 		user_plan.save()
			# 		return JsonResponse(ResponseObject(data = SubscriptionUtils().get_plan_by_user(user)).to_dict())
		new_price = to_decimal(plan.monthly_fee if not yearly_billing else plan.yearly_fee)

		discount = 0
		upgraded = False
		if to_int(old_plan['id']) != 1 and not old_plan.get('expired') and to_int(plan.monthly_fee) != to_int(old_plan['monthly_fee']):
			upgraded = True
			grand_total = SubscriptionUtils().remaining_price(old_plan, model_to_dict(plan))
			if grand_total:
				new_price = grand_total
		total = new_price
		discount_info = dict()
		coupon_code = request.data.get('coupon_code')
		# coupon_code = '123456'
		if coupon_code:
			validate_coupon = CouponUtils().verify_coupon(coupon_code, user, new_price, 'plan')
			if validate_coupon['result'] == 'success':
				discount = validate_coupon['data']['discount']
				total = validate_coupon['data']['total']
				discount_info = validate_coupon['data']
		# if total <= to_decimal(user.balance):
		# 	kwargs = dict()
		# 	if discount:
		# 		kwargs['discount'] = discount
		# 		kwargs['total'] = total
		# 		kwargs['discount_code'] = discount_info['code']
		# 	new_plan = SubscriptionUtils().new_user_subscription_plan(user, plan, yearly_billing, **kwargs)
		# 	return JsonResponse(ResponseObject(data = new_plan).to_dict())
		token = f"{to_int(time())}-{random_token()}"
		name = f"Upgrade Plan {old_plan['name']} => {plan.name}"
		if payment_method == 'shopify':
			name = plan.name

		if old_plan['name'] == plan.name:
			name = f"Renew Plan {plan.name}"
			if yearly_billing:
				name = f"Yearly Package for plan {plan.name}"
		payment_information = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": to_decimal(total),
			"subtotal": to_decimal(new_price),
			"return_url": get_app_url("subscription/change-success", user) if to_int(request.GET.get('first-setup')) != 1 else get_app_url('products', user),
			"cancel_url": get_app_url("subscription/change-error", user),
			"status": "pending",
			"type": "plan",
			"name": f"LitCommerce: {name}",
			"plan_id": plan_id,
			"yearly_paid": 1 if yearly_billing else 0,
			"method": payment_method,
			"upgrade_plan": upgraded
		}
		if payment_information['method'] == PaymentUtils().get_payment_method_default() and old_plan.get('user_plan') and old_plan['user_plan'].get('payment_method'):
			payment_information['method'] = old_plan['user_plan'].get('payment_method')
		meta_data = AccountUtils().get_meta_data(request)
		if not meta_data:
			meta_data = {}
		meta_data['user_id'] = user_id
		if old_plan.get('user_plan') and old_plan['user_plan'].get('channel_payment'):
			meta_data['channel_payment'] = old_plan['user_plan'].get('channel_payment')
		if meta_data:
			payment_information['meta_data'] = json_encode(meta_data)
		if discount:
			payment_information['discount'] = discount
			payment_information['discount_code'] = discount_info['code']
		PaymentInformation.objects.create(**payment_information)
		return JsonResponse(ResponseObject(code = 'payment', data = get_full_absolute_uri('process_payment_token', {'token': token})).to_dict())
