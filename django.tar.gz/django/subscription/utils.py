import copy
import time
from datetime import datetime

import dateutil.relativedelta
from django.db import transaction
from django.forms import model_to_dict

from channels.models import Channel
from core.utils import CoreUtils
from libs.utils import to_decimal, to_int, json_decode, log
from payments.models import PaymentHistory
from payments.pricing import calculated_subscription_pricing
from subscription.models import Subscription, UserSubscription, UserSubscriptionHistory


class SubscriptionUtils:
	def default(self):
		subscription_default = Subscription.objects.get(monthly_fee = 0)
		return subscription_default


	def get(self, subscription_id):
		try:
			subscription_default = Subscription.objects.get(pk = subscription_id)
		except Subscription.DoesNotExist:
			return False
		return subscription_default


	def check_plan_expired(self, user):
		try:
			user_plan = UserSubscription.objects.filter(user_id = user.id).last()
		except UserSubscription.DoesNotExist:
			user_plan = None
		if not user_plan or not user_plan.expired_at:
			return ''
		expired_time = user_plan.expired_at
		if user_plan.expired_at.timestamp() < datetime.now().timestamp():
			return expired_time.strftime("%b %d %Y")
		return ''


	def is_subscription_paypal(self, user):
		try:
			user_plan = UserSubscription.objects.filter(user_id = user.id).last()
		except UserSubscription.DoesNotExist:
			user_plan = None
		if not user_plan or not user_plan.paypal_subscription_id or not user_plan.auto_renew:
			return False
		return True

	def get_plan_by_user(self, user, changed = True):
		plan_default = False
		try:
			user_plan = UserSubscription.objects.filter(user_id = user.id).last()
		except UserSubscription.DoesNotExist:
			user_plan = None
		if not user_plan:
			plan = SubscriptionUtils().default()
			plan_default = True
		else:
			plan = SubscriptionUtils().get(user_plan.plan_id)
		if not plan:
			plan = SubscriptionUtils().default()
			plan_default = True
		plan_data = model_to_dict(plan)
		plan_default_data = {
			"started_at": user.created_at.strftime("%Y-%m-%d %H:%M:%S"),
			"expired_at": False,
			# "start_month_at": user.created_at.strftime("%d %H:%M:%S"),
			"default": True,
			"expired": False

		}
		plan_user_data = copy.deepcopy(plan_default_data)
		if user_plan:
			if user_plan.products_limit:
				plan_data['products_limit'] = user_plan.products_limit
			if user_plan.orders_limit:
				plan_data['orders_limit'] = user_plan.orders_limit
			if user_plan.channels_limit:
				plan_data['channels_limit'] = user_plan.channels_limit
			if user_plan.feeds_limit:
				plan_data['feeds_limit'] = user_plan.feeds_limit
		if not plan_default:
			expired_time = user_plan.expired_at if user_plan.expired_at else False
			plan_user_data = {
				"started_at": user_plan.started_at.strftime("%Y-%m-%d %H:%M:%S"),
				"expired_at": expired_time.strftime("%Y-%m-%d %H:%M:%S") if expired_time else False,
				# "start_month_at": user_plan.started_at.strftime("%d %H:%M:%S"),
				"user_plan_id": user_plan.id,
				"yearly_paid": user_plan.yearly_paid,
				"plan_paid": user_plan.plan_paid_id,
				"default": False,
				"expired": False,
				"auto_renew": user_plan.auto_renew
			}
			if expired_time:
				today = datetime.strptime(datetime.today().strftime("%Y-%m-%d 00:00:00"), '%Y-%m-%d %H:%M:%S')
				if expired_time.timestamp() < today.timestamp():
					plan_user_data['expired'] = True
			plan_return = copy.deepcopy(plan_data)
			plan_return.update(plan_user_data)
		# if user_plan.expired_at and expired_time.timestamp() < datetime.now().timestamp() and changed:
		# 	old_plan = copy.deepcopy(plan_data)
		# 	old_plan.update(plan_user_data)
		# 	plan_user_data = plan_default_data
		# 	plan_default_subscription = SubscriptionUtils().default()
		# 	plan_data = model_to_dict(plan_default_subscription)
		# 	extend = self.expired_plan(user, old_plan)
		# 	if extend:
		# 		return plan_return

		plan_data.update(plan_user_data)
		plan_data['user_plan'] = model_to_dict(user_plan) if user_plan else None
		return plan_data


	def expired_plan(self, user, plan):
		extend = False
		yearly_paid = False
		if plan['yearly_paid'] and user.balance >= plan['yearly_fee']:
			extend = True
			yearly_paid = True
		elif user.balance >= plan['monthly_fee']:
			extend = True
		if extend:
			self.new_user_subscription_plan(user, SubscriptionUtils().get(plan['id']), yearly_paid = yearly_paid, old_plan = plan)
		else:
			self.new_user_subscription_plan(user, SubscriptionUtils().default(), old_plan = plan)
		return extend


	def new_user_subscription_plan(self, user, new_plan, yearly_paid = False, old_plan = False, auto_renew = False, new_plan_auto_renew = False, **kwargs):
		if not old_plan:
			old_plan = self.get_plan_by_user(user)
		price = to_decimal(new_plan.monthly_fee if not yearly_paid else new_plan.yearly_fee)
		plan_price = price
		subtotal = price
		products_limit = kwargs.get('products_limit')
		channels_limit = kwargs.get('channels_limit')
		if 'total' in kwargs:
			price = to_decimal(kwargs['total'])
		if 'subtotal' in kwargs:
			subtotal = to_decimal(kwargs['subtotal'])
		# try:
		with transaction.atomic():
			if kwargs.get('deducted_balance'):
				del kwargs['deducted_balance']
				CoreUtils().user_new_balance(user, price)
				user.balance = to_decimal(user.balance) - price
				if price and not user.is_staff:
					payment_history = dict(balance = user.balance + price, subtotal = subtotal, user_id = user.id, payer_email = user.email, amount = 0, total = price, new_balance = user.balance, status = "deducted", note = f"Upgrade plan {old_plan['name']} => {new_plan.name}")
					if kwargs.get('discount'):
						payment_history['discount'] = kwargs['discount']
					if kwargs.get('discount_code'):
						payment_history['discount_code'] = kwargs['discount_code']
					if kwargs.get('order_from'):
						payment_history['method'] = kwargs['order_from']
					PaymentHistory.objects.create(**payment_history)
			UserSubscription.objects.filter(user_id = user.id).delete()
			start_time = datetime.now()

			if old_plan.get('expired_at') and not old_plan['expired'] and old_plan['id'] == new_plan.id:
				expired_at = datetime.strptime(old_plan['expired_at'], "%Y-%m-%d %H:%M:%S")
				if start_time.timestamp() > expired_at.timestamp():
					expired_at = start_time
			else:
				expired_at = start_time
			if not new_plan.monthly_fee:
				expired_time = False
			else:
				if yearly_paid:
					expired_time = expired_at + dateutil.relativedelta.relativedelta(years = 1)
				else:
					if not kwargs.get('paypal_subscription_id'):
						expired_time = expired_at + dateutil.relativedelta.relativedelta(days = 30)
					else:
						expired_time = expired_at + dateutil.relativedelta.relativedelta(months = 1)

			new_expired_at = expired_time.strftime("%Y-%m-%d %H:%M:%S") if expired_time else None
			if kwargs.get('upgrade_plan') and to_int(old_plan['id']) != 1:
				new_expired_at = old_plan['expired_at']
			if kwargs.get('new_expired_at'):
				new_expired_at = kwargs['new_expired_at']
				del kwargs['new_expired_at']
			user_plan_data = dict(user_id = user.id, plan_id = new_plan.id, started_at = start_time.strftime("%Y-%m-%d %H:%M:%S"), expired_at = new_expired_at, yearly_paid = 1 if yearly_paid else 0)
			if products_limit and channels_limit:
				user_plan_data['products_limit'] = products_limit
				user_plan_data['channels_limit'] = channels_limit
				user_plan_data['subscription_fee'] = calculated_subscription_pricing(channels_limit, products_limit, yearly_paid)
				if new_plan.id == CoreUtils().get_new_plan_default_id():
					price = user_plan_data['subscription_fee']
			if kwargs.get('order_from') in ['shopify', 'wix', 'paypal']:
				user_plan_data['payment_method'] = kwargs['order_from']
			if kwargs.get('channel_payment'):
				user_plan_data['channel_payment'] = kwargs['channel_payment']
			if new_plan_auto_renew or auto_renew:
				user_plan_data['auto_renew'] = True
				if auto_renew:
					if old_plan['user_plan'] and old_plan['user_plan'].get('paypal_subscription_id'):
						user_plan_data['paypal_subscription_id'] = kwargs['paypal_subscription_id']
					if old_plan['user_plan']:
						keep_fields = ['products_limit', 'channels_limit', 'orders_limit', 'subscription_fee']
						for keep_field in keep_fields:
							if old_plan['user_plan'].get(keep_field):
								user_plan_data[keep_field] = old_plan['user_plan'].get(keep_field)
			if kwargs.get('paypal_subscription_id'):
				user_plan_data['paypal_subscription_id'] = kwargs['paypal_subscription_id']
			try:
				user_plan = UserSubscription.objects.create(**user_plan_data)
				subscription_history = {
					'user_id': user.id,
					'old_plan_id': old_plan['id'],
					'old_plan_yearly_paid': 1 if old_plan.get('yearly_paid') else 0,
					'old_plan_started_at': old_plan['started_at'],
					'old_plan_expired_at': old_plan['expired_at'],
					'new_plan_id': new_plan.id,
					'new_plan_yearly_paid': user_plan.yearly_paid,
					'new_plan_started_at': user_plan.started_at,
					'new_plan_expired_at': user_plan.expired_at,
					'payment_method': old_plan.get('payment_method'),
					'channel_payment': old_plan.get('channel_payment'),

				}
				fields = ['channels_limit', 'products_limit', 'subscription_fee']
				for field in fields:
					if old_plan.get(field):
						subscription_history[f'old_plan_{field}'] = old_plan[field]
					if user_plan_data.get(field):
						subscription_history[f'new_plan_{field}'] = user_plan_data[field]

				UserSubscriptionHistory.objects.create(**subscription_history)
				CoreUtils().update_sync_frequency(user, new_plan.sync_frequency)
				user.is_expired = False
				user.is_trial = False
				if not user.duration_paid:
					user_create = user.created_at
					current = datetime.now()
					days = (current-user_create).days
					user.duration_paid = round(days / 7 )
				user.save()
			except Exception as e:
				log(user_plan_data, 'info')
		if to_int(new_plan.id) != 1:
			from channels.utils import ChannelUtils
			channel_utils = ChannelUtils()
			channel = channel_utils.get_default_channel(user.id)
			if channel:
				channel_utils.enable_refresh_sync(channel.id, channel)
				channel.auto_update = 1
				channel.save()
		if (price or kwargs.get('paypal_subscription_id')) and not user.is_staff:
			from litcommerce_order.utils import LitcommerceOrderUtils
			kwargs['plan_id'] = new_plan.id
			kwargs['yearly_paid'] = yearly_paid
			name = f"Upgrade Plan {old_plan['name']} => {new_plan.name}"
			if old_plan['name'] == new_plan.name:
				name = f"Renew Plan {new_plan.name}"
			kwargs['description'] = name
			del_key = ['upgrade_plan', 'new_expired_at', 'channel_payment', 'products_limit', 'channels_limit']
			kwargs['order_type'] = 'plan'
			if kwargs.get('paypal_subscription_id'):
				kwargs['order_type'] = 'subscription'
				kwargs['setup_price'] = price
				kwargs['subscription_price'] = plan_price
			for field in del_key:
				if field in kwargs:
					del kwargs[field]
			kwargs['subtotal'] = subtotal
			kwargs['amount'] = price
			LitcommerceOrderUtils(user = user).create_order(**kwargs)
		if to_int(new_plan.id) != 1:
			channel_default = False
			from channels.utils import ChannelUtils

			if old_plan['expired']:
				channels = Channel.objects.filter(user_id = user.id, deleted_at = None).exclude(type__in = ('litcommerce', 'bulk_edit'))

				for channel in channels:
					if channel.default:
						channel_default = channel
					if channel.default or not channel.previous_settings:
						continue
					ChannelUtils().setting_for_channel(channel, json_decode(channel.previous_settings))
					channel.settings = channel.previous_settings
					channel.previous_settings = None
					channel.save()
			if not channel_default:
				channel_default = ChannelUtils().get_default_channel(user.id)
			if channel_default and channel_default.available_create_webhook():
				ChannelUtils().create_webhook(channel_default)
		return self.get_plan_by_user(user)


	def remaining_price(self, user_plan, plan):
		remaining_days = 0
		if not user_plan['default'] and not user_plan['expired'] and user_plan['expired_at'] and user_plan['monthly_fee']:
			remaining_days = (datetime.strptime(user_plan['expired_at'], "%Y-%m-%d %H:%M:%S") - datetime.now()).days
		grand_total = 0
		if not remaining_days:
			return grand_total
		if user_plan['yearly_paid']:
			diff_price = plan['yearly_fee'] - user_plan['yearly_fee']

			grand_total = to_decimal(diff_price * remaining_days / 365, 1)
		else:
			diff_price = plan['monthly_fee'] - user_plan['monthly_fee']
			grand_total = to_decimal(diff_price * remaining_days / 30, 1)
		return grand_total


	def new_remaining_price(self, user_plan, channel_limit, product_limit, yearly_billing = False):
		remaining_days = 0
		if not user_plan['default'] and not user_plan['expired'] and user_plan['expired_at'] and user_plan['monthly_fee']:
			remaining_days = (datetime.strptime(user_plan['expired_at'], "%Y-%m-%d %H:%M:%S") - datetime.now()).days
		if remaining_days <= 0:
			remaining_days = 0
		grand_total = 0
		if not remaining_days:
			return grand_total
		monthly_fee = calculated_subscription_pricing(channel_limit, product_limit, False)
		yearly_fee = calculated_subscription_pricing(channel_limit, product_limit, True)

		if yearly_billing:
			diff_price = yearly_fee - calculated_subscription_pricing(user_plan['channels_limit'], user_plan['products_limit'], True)

			grand_total = round(diff_price * remaining_days / 365, 1)
		else:
			diff_price = monthly_fee - user_plan['user_plan']['subscription_fee']
			grand_total = round(diff_price * remaining_days / 30, 1)
		return grand_total
