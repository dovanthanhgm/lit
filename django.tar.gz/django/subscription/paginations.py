from core.paginations import MetaPagination


class SubscriptionPagination(MetaPagination):
	page_size = 4
