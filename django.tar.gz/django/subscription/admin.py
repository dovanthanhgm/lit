import time
from datetime import datetime
from functools import update_wrapper

import dateutil.relativedelta
from dateutil.utils import today
from django.contrib import admin
# Register your models here.
from django.contrib.admin import SimpleListFilter
from django.db.models import Q
from django.shortcuts import redirect
from django.urls import reverse, path
from django.utils.html import format_html
from rest_framework import generics

from accounts.models import UserAccount
from accounts.permission import IsStaff
from channels.models import Channel
from core.myadmin.admin import CoreAdmin, InputFilter, UserFilter
from libs.utils import to_int, get_full_absolute_uri, get_app_url
from payments.models import PaypalPlan
from payments.paypal_api import PaypalApi
from subscription.models import Subscription, UserSubscription, UserSubscriptionHistory, SubscriptionRenewException


# class PlanFilter(InputFilter):
# 	parameter_name = 'email'
# 	title = ('email or id')
# 	field_filter = ''
#
#
# 	def queryset(self, request, queryset):
# 		from libs.utils import to_str
# 		if self.value() is not None:
# 			email = to_str(self.value()).strip()
# 			if email.isnumeric():
# 				users = UserAccount.objects.filter(pk = email)
# 			else:
# 				users = UserAccount.objects.filter(email__contains = email)
# 			user_ids = list(users.values_list('id', flat = True))
# 			if user_ids:
# 				return self.filter_user(user_ids, request, queryset)
class SubscriptionAdmin(CoreAdmin):
	list_display = ['id', 'name', 'monthly_fee', 'yearly_fee', 'products_limit', 'orders_limit', 'channels_limit', 'feeds_limit', 'sync_frequency', 'order_sync_frequency', 'paypal_monthly_plan_id', 'paypal_yearly_plan_id']


	def changelist_view(self, request, extra_context = None):
		extra = extra_context or {}
		plan_type = request.GET.get('type__exact')
		if plan_type != 'custom':
			plan_type = 'system'
		extra['plan_type'] = plan_type
		return super().changelist_view(request, extra_context = extra)


class DefaulFilter(InputFilter):
	parameter_name = 'default'
	title = ('Default',)
	type = 'hidden'


	def queryset(self, request, queryset):
		if not request.GET.get('plan__id__exact'):
			return queryset.exclude(plan_id = 1)


class StatusFilter(SimpleListFilter):
	parameter_name = 'status'
	title = ('Status',)


	def lookups(self, request, model_admin):
		return [("on", "on"),("trial_active", "Trial Active"), ('expired', 'Expired'), ('trial_expired', 'Trial Expired'), ('about_expired', 'Expires within 1 month')]


	def queryset(self, request, queryset):
		current_time = today().strftime("%Y-%m-%d 00:00:00")

		if self.value() == 'expired':
			user_query_set = UserAccount.objects.filter(is_staff = False, is_trial = False).values('id')

			return queryset.filter(expired_at__lte = current_time, user_id__in = user_query_set).exclude(plan_id__in = [1, 8])
		if self.value() == 'trial_expired':
			user_query_set = UserAccount.objects.filter(is_staff = False, is_trial = True).values('id')

			return queryset.filter(expired_at__lte = current_time, user_id__in = user_query_set).exclude(plan_id__in = [1, 8])
		if self.value() == 'trial_active':
			user_query_set = UserAccount.objects.filter(is_staff = False, is_trial = True).values('id')

			return queryset.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).filter(user_id__in = user_query_set)

		if self.value() == 'on':
			user_query_set = UserAccount.objects.filter(is_staff = False, is_trial = False).values('id')

			return queryset.filter(Q(expired_at__gt = current_time) | Q(expired_at__isnull = True)).filter(user_id__in = user_query_set)
		if self.value() == 'about_expired':
			current_time = datetime.fromtimestamp(to_int(time.time())).strftime("%Y-%m-%d %H:%M:%S")

			expired_time = datetime.fromtimestamp(to_int(time.time())) + dateutil.relativedelta.relativedelta(days = 30)
			return queryset.filter(expired_at__lt = expired_time, expired_at__gt = current_time)


class UserSubscriptionAdmin(CoreAdmin):
	list_display = ['user_link', 'plan', 'start_time', 'expired_time', 'yearly_paid', 'cancel_at_the_end', 'go_to_channel', 'status', 'login']
	list_filter = ['expired_at', StatusFilter, UserFilter, 'plan']


	def expired_time(self, obj):
		if not obj.expired_at:
			return ''
		return obj.expired_at.strftime('%Y-%m-%d')


	expired_time.short_description = 'Expired At'


	def start_time(self, obj):
		if not obj.started_at:
			return ''
		return obj.started_at.strftime('%Y-%m-%d')


	start_time.short_description = 'Start At'


	def status(self, obj):
		today = datetime.strptime(datetime.today().strftime("%Y-%m-%d 00:00:00"), '%Y-%m-%d %H:%M:%S')

		if not obj.expired_at or obj.expired_at.timestamp() >= today.timestamp():
			return format_html(f'<span style="color:green">on</span>')
		return format_html(f'<span style="color:red">expired</span>')


	def go_to_channel(self, obj):
		channels = Channel.objects.filter(user_id = obj.user_id, deleted_at__isnull = True)
		channel_name = list()
		if channels:
			for channel in channels:
				channel_name.append(f"<a href='{get_full_absolute_uri('admin:channels_channel_change', {'object_id': channel.id})}' target='_blank' class='_link' style='color:grey !important;'>{channel.type}[{channel.number_products_linked}]</a>")
			html_channel = f"<a href='{get_full_absolute_uri('admin:channels_channel_changelist')}?user__id__exact={obj.id}' target='_blank' class='_link' style='color:blue;'>Channel</a>"
			html_channel += '<br/>'
			html_channel += "(" + ', '.join(channel_name) + ")"
			return format_html(html_channel)


	go_to_channel.short_description = 'Channels'


	def login(self, obj):
		url = get_full_absolute_uri('admin_login_by_token', {'user_id': obj.user_id})
		return format_html(f"<a href='{url}' target='_blank' class='button' style='color:white !important;'>Login</a>")


class UserSubscriptionHistoryAdmin(CoreAdmin):
	list_display = ['user', 'old_plan', 'old_plan_expired_at', 'new_plan', 'new_plan_expired_at', 'created_at']


class PaypalPlanAdmin(CoreAdmin):
	list_display = ['name', 'product_id', 'paypal_plan_id', 'plan']
	add_fieldsets = (
		(None, {
			'classes': ('wide',),
			'fields': ('name', 'plan'),
		}),
	)


	def get_fieldsets(self, request, obj = None):
		if not obj:
			return self.add_fieldsets
		return super().get_fieldsets(request, obj)


	def save_model(self, request, obj, form, change):
		if not obj.id:
			paypal_api = PaypalApi()

		return super().save_model(request, obj, form, change)


class SubscriptionRenewExceptionAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'plan_link', 'status', 'exceptions', 'created_at', 'solved']
	list_filter = ['status']
	def get_urls(self):
		def wrap(view):
			def wrapper(*args, **kwargs):
				return self.admin_site.admin_view(view)(*args, **kwargs)


			wrapper.model_admin = self
			return update_wrapper(wrapper, view)


		info = self.model._meta.app_label, self.model._meta.model_name
		urls = super().get_urls()
		custom_url = [
			path('<path:object_id>/solved', SubscriptionRenewExceptionSolved.as_view(), name = '%s_%s_view_solved' % info),

		]
		return custom_url + urls
	def user_link(self, obj):
		user = UserAccount.objects.filter(id = obj.user_id).first()
		if user:
			url = reverse("admin:accounts_useraccount_change", args = (obj.user_id,))

			return format_html(f"<a href='{url}' target='_blank' class='_link''>{user.email}</a>")
		return obj.user_id
	def plan_link(self, obj):
		url = reverse("admin:subscription_usersubscription_change", args = (obj.plan_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.plan_id}</a>")


	def solved(self, obj):
		url = get_full_absolute_uri('admin:subscription_subscriptionrenewexception_view_solved', {'object_id': obj.id})
		return format_html(f"<a href='{url}' class='button' style='color:white !important;'>Solved</a>")


admin.site.register(SubscriptionRenewException, SubscriptionRenewExceptionAdmin)
admin.site.register(PaypalPlan, PaypalPlanAdmin)
admin.site.register(Subscription, SubscriptionAdmin)
admin.site.register(UserSubscription, UserSubscriptionAdmin)
admin.site.register(UserSubscriptionHistory, UserSubscriptionHistoryAdmin)


class SubscriptionRenewExceptionSolved(generics.ListAPIView):
	permission_classes = [IsStaff]


	def get(self, request, *args, **kwargs):
		sub = SubscriptionRenewException.objects.get(pk = kwargs.get('object_id'))
		sub.status = True
		sub.save()
		return redirect(get_full_absolute_uri(f"admin:subscription_subscriptionrenewexception_changelist"))
