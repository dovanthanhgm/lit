import copy

from datasync.api.sync import SyncApi
from libs.utils import to_str, json_encode, log_traceback, log
from process_management.models import ProcessManagement
from servers.models import Server


class ServerUtils:
	def refresh(self, import_process = True):
		if import_process:
			ProcessManagement.objects.all().delete()
		for server in Server.objects.all():
			server_response = SyncApi(server = server).get('server/status')
			if server_response['result'] != 'success':
				log(server_response)
				Server.objects.filter(id = server.id).update(status = 'disconnected')
				html_content = f"Remote Server: {server.name} has been disconnected"
				from django.core.mail import send_mail
				send_mail(
					subject = html_content,
					message = None,
					from_email = 'nam@litcommerce.com',
					recipient_list = ['contact@litcommerce.com'],
					html_message = html_content,
					fail_silently = False
				)
			else:
				server_status = server_response['data']
				server_status['status'] = 'connected'
				processes = copy.deepcopy(server_status['processes'])
				server_status['processes'] = None
				Server.objects.filter(id = server.id).update(**server_status)
				if import_process:
					for process in processes:
						datasync_info = process['datasync_info']
						sync_id = datasync_info.get('data', dict()).get('sync_id')
						ProcessManagement.objects.create(action = datasync_info.get('action'), pid = process['pid'], server_id = server.id, cpu_percent = process['cpu_percent'], memory_info = to_str(process['memory_info']).replace('M', ''), start_time = process['create_time'], data = json_encode(process['datasync_info']), process_id = sync_id)
		return