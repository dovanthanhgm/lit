from django.db import models
from django.urls import reverse
from django.utils.html import format_html


class Server(models.Model):
	STATUS_CHOICES = (
		('connected', 'Connected'),
		('disconnected', 'Disconnected')
	)
	CONNECTED = 'connected'
	DEFAULT_CHOICES = (
		(1, 'Yes'),
		(0, 'No')
	)
	ip_address = models.CharField(max_length = 255)
	name = models.CharField(max_length = 255, blank = True, null = True)
	private_key = models.CharField(max_length = 255, blank = True, default = '')
	port = models.CharField(max_length = 255)
	latitude = models.DecimalField(max_digits = 8, decimal_places = 2, blank = True, null = True)
	longitude = models.DecimalField(max_digits = 8, decimal_places = 2, blank = True, null = True)
	status = models.CharField(default = 'connected', choices = STATUS_CHOICES, max_length = 25)
	default = models.SmallIntegerField(default = 0, choices = DEFAULT_CHOICES)
	active_tasks = models.IntegerField(blank = True, null = True)
	country_code = models.CharField(max_length = 255, blank = True, null = True)
	writeio_mps = models.CharField(max_length = 255, blank = True, null = True)
	readio_mps = models.CharField(max_length = 255, blank = True, null = True)
	disk_usage_percent = models.CharField(max_length = 255, blank = True, null = True)
	memory_percent = models.CharField(max_length = 255, blank = True, null = True)
	cpu_percent = models.CharField(max_length = 255, blank = True, null = True)
	processes = models.TextField(blank = True, null = True)
	last_email_time = models.DateTimeField(blank = True, null = True)
	priority = models.IntegerField(default = 1)

	class Meta:
		db_table = 'servers'
		ordering = ['id']


	def __str__(self):
		return self.name or self.ip_address


	@property
	def server_url(self):
		return f'http://{self.ip_address}:{self.port}'


	def server_link(self, instance):
		url = reverse('admin:%s_%s_change' % (instance._meta.app_label, instance._meta.module_name), args = (instance.id,))
		return format_html(f'<a href="{url}view/">Edit</a>', url)


	readonly_fields = ('admin_link',)
