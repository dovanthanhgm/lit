from django.contrib import admin
from django.shortcuts import redirect
from django.utils.html import format_html

from core.myadmin.admin import CoreAdmin
from libs.utils import get_full_absolute_uri
from servers.models import Server
from servers.utils import ServerUtils


@admin.register(Server)
class ServerAdmin(CoreAdmin):
	list_filter = ['status', 'default', 'ip_address', 'name']
	list_display = ['id', 'custom_status', 'default', 'priority', 'ip_address', 'name', 'private_key', 'port', 'latitude', 'longitude',
	                'active_tasks', 'country_code', 'writeio_mps', 'readio_mps', 'disk_usage_percent',
	                'memory_percent', 'cpu_percent', 'processes', 'last_email_time']
	change_list_template = 'admin/datasync/server/change_list.html'


	def custom_status(self, obj):
		if obj.status == 'connected':
			color = 'blue'
		else:
			color = 'red'
		return format_html(f"<span style='color:{color}'>{obj.status}</span>")


	custom_status.short_description = 'Status'


	def changelist_view(self, request, extra_context = None):
		if request.GET.get('_refresh') == 'Refresh':
			ServerUtils().refresh()
			self.message_user(request, f'Update server completed.\n')
			return redirect(get_full_absolute_uri('admin:servers_processmanagement_changelist'))
		return super().changelist_view(request, extra_context)
