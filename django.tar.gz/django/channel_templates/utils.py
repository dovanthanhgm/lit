import copy
import importlib
import re
import time

from bs4 import BeautifulSoup

from core.utils import CoreUtils
from libs.models.collections.catalog import Catalog
from libs.models.collections.template import Template
from libs.utils import to_decimal, to_str, log_traceback, rounding_price, json_decode, strip_html_from_description, nl2br, attribute_name_to_code, to_len, to_timestamp_or_false


def allow_attribute_title_template():
	return ['sku', 'name', 'description', 'short_description', 'brand', 'price', 'condition', 'condition_notes', 'category', 'manufacturer', 'model', 'ean', 'asin', 'espn', 'upc', 'gtin', 'gcid', 'epid', 'weight', 'width', 'length', 'height', 'product_type', 'cost','tags','meta_title','meta_description', 'msrp']


def format_attribute_value(attribute_name, value, description_format = False):
	if json_decode(value) and isinstance(json_decode(value), list):
		value = ', '.join(list(map(lambda x: to_str(x), json_decode(value))))

	if not description_format or attribute_name in ['description', 'short_description']:
		return value
	if description_format == 'nl2br':
		value = nl2br(value)
	elif description_format == 'br2nl':
		value = strip_html_from_description(value)
	return value

def assign_attribute_to_field(field, product, lower = False, description_format = False):
	field = to_str(field)
	real_field = field.replace('{{vendor}}', '{{brand}}')
	allow_field = allow_attribute_title_template()
	changed = True
	if field.find("{{custom_attributes}}") != -1:
		custom_attributes = []
		for attribute in product['attributes']:
			value = format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)
			custom_attributes.append(f"<p>{attribute['attribute_name']}: {value}</p>")
		if custom_attributes:
			field = to_str(field).replace("<p>{{custom_attributes}}</p>", "\n".join(custom_attributes)).replace("{{custom_attributes}}", "\n".join(custom_attributes))
	fields = re.findall("{{.*?}}", field)

	for row in fields:
		text_replace = row
		split_replace = text_replace.split(' or ')
		all_field_replace = []
		for field_replace in split_replace:
			field_row = attribute_name_to_code(field_replace)
			all_field_replace.append(field_row)

		field = field.replace(text_replace, '{{' + ' or '.join(all_field_replace) + '}}')

	extend_data = {
		'product': product
	}
	for attribute in allow_field:
		value = product.get(attribute)
		if isinstance(value, dict):
			if 'name' in value:
				value = value.get('name')
			else:
				value = ''
		else:
			value = to_str(value)
		value = format_attribute_value(attribute, value, description_format)
		extend_data[attribute] = value
	if product.get('variant_options'):
		variant_options = dict()
		for option in product['variant_options']:
			variant_options[to_str(option['option_name']).lower()] = ', '.join(option['option_values'])
		extend_data['variant_options'] = variant_options
	attributes_extend = []
	if product.get('is_variant'):
		attribute_variants = list(filter(lambda x: x.get('use_variant'), product['attributes']))
		attribute_no_variants = list(filter(lambda x: not x.get('use_variant'), product['attributes']))
		attributes_extend = attribute_variants
		attributes_extend.extend(attribute_no_variants)
	else:
		attributes_extend = product['attributes']
	for attribute in attributes_extend:
		attribute_name = attribute_name_to_code(to_str(attribute['attribute_name']))

		if extend_data.get(attribute_name) and not product.get('is_variant'):
			continue
		value = format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)

		if lower:
			attribute_name = attribute_name.lower()
		if json_decode(value):
			value = json_decode(value)
		extend_data[attribute_name] = value
	images = []
	if product['thumb_image']['url']:
		images.append(product['thumb_image']['url'])
	for image in product['images']:
		images.append(image['url'])
	for index, row in enumerate(images):
		attribute_name = f"product_image_{index + 1}"
		extend_data[attribute_name] = row
	try:
		from jinja2 import Template
		template = Template(field)
		new_value = template.render(extend_data).strip()
		if not new_value:
			template = Template(real_field)
			new_value1 = template.render(extend_data).strip()
			if new_value1:
				new_value = new_value1.split('///')
				if to_len(new_value) == 1:
					new_value = new_value[0]
		return changed, new_value
	except Exception:
		log_traceback()
		return old_assign_attribute_to_field(real_field, product, lower, description_format)
def old_assign_attribute_to_field(field, product, lower = False, description_format = False):
	field = to_str(field)
	allow_field = allow_attribute_title_template()
	changed = False
	for attribute in product['attributes']:
		value = format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)

		attribute_name = to_str(attribute['attribute_name'])
		if lower:
			attribute_name = attribute_name.lower()
		if field.find("{{" + attribute_name + "}}") == -1:
			continue
		changed = True
		field = to_str(field).replace("{{" + attribute_name + "}}", value)
	if field.find("{{custom_attributes}}") != -1:
		custom_attributes = []
		for attribute in product['attributes']:
			value = format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)
			custom_attributes.append(f"<p>{attribute['attribute_name']}: {value}</p>")
		if custom_attributes:
			field = to_str(field).replace("<p>{{custom_attributes}}</p>", "\n".join(custom_attributes)).replace("{{custom_attributes}}", "\n".join(custom_attributes))
	for attribute in allow_field:
		value = product.get(attribute)
		if isinstance(value, dict):
			if 'name' in value:
				value = value.get('name')
			else:
				value = ''
		else:
			value = to_str(value)
		value = format_attribute_value(attribute, value, description_format)
		if field.find("{{" + attribute + "}}") == -1:
			continue
		changed = True
		if not value:
			value = ''
		field = field.replace("{{" + attribute + "}}", value)
	images = []
	if product['thumb_image']['url']:
		images.append( product['thumb_image']['url'])
	for image in product['images']:
		images.append(image['url'])
	for index in range(1, 13):
		attribute_name = f"product_image_{index}"
		if index > len(images):
			continue
		if field.find("{{" + attribute_name + "}}") == -1:
			continue
		field = field.replace("{{" + attribute_name + "}}", images[index - 1])
	fields = re.findall("{{.*?}}", field)
	for row in fields:
		text_replace = row
		row = row.replace('{{', '').replace('}}', '')
		if row.find('.') == -1:
			continue
		obj = row.split('.')
		attribute_name = obj[0]
		attribute = dict()
		for attribute_row in product['attributes']:
			if attribute_row['attribute_name'] == attribute_name:
				attribute = attribute_row
				break
		if not attribute:
			continue
		value = json_decode(attribute['attribute_value_name'])
		if not value:
			continue
		del obj[0]
		for attribute_field in obj:
			try:
				value = value.get(attribute_field, {})
			except:
				value = ''
				break
		field = field.replace(text_replace, to_str(value))
	field = re.sub("{{.*?}}", '', field)
	field = field.replace('<p><img src=""></p>', "").replace('<img src="">', "")
	return changed, field.strip()


def adjustment_price(price_template, price, product = None):
	if price_template.get('custom_price', {}) and price_template.get('custom_price', {}).get('status') == 'enable':
		value = to_decimal(price_template['custom_price']['value'], 2)
		if price_template['custom_price'].get('override') or price_template['custom_price'].get('mapping'):
			value = price_template['custom_price'].get('override') or price_template['custom_price'].get('mapping')
			changed, value = assign_attribute_to_field(value, product)
			value = to_decimal(value, 2)
		if not value:
			return price
		return value
	price = _adjustment_price(price_template['adjustment'], price)
	if price_template.get('extend_adjustment'):
		for row in price_template['extend_adjustment']:
			if not row.get('value'):
				continue
			price = _adjustment_price(row, price)
	if price_template['adjustment'].get('rounding'):
		price = rounding_price(price_template['adjustment'].get('rounding'), price)
	return price


def _adjustment_price(adjustment, price):
	price = to_decimal(price)
	value = to_decimal(adjustment['value'])
	if adjustment['modifier'] == 'percent':
		value = round((price * value) / 100, 2)
	return round(price + value if adjustment['direction'] == 'increment' else price - value, 2)


class ChannelTemplateUtils:
	_model_product: Catalog
	PRICE_CUSTOM_TEMPLATES = ['ebay']
	TITLE_CUSTOM_TEMPLATES = []


	def __init__(self, **kwargs):
		self._model_product = None
		self._model_template = None
		self._user_id = kwargs.get('user_id')
		self._channel_id = kwargs.get('channel_id')
		self._channel_type = kwargs.get('channel_type')


	def get_model_product(self):
		if self._model_product:
			return self._model_product
		self._model_product = Catalog()
		self._model_product.set_user_id(self._user_id)
		return self._model_product


	def get_model_template(self):
		if self._model_template:
			return self._model_template
		self._model_template = Template()
		self._model_template.set_user_id(self._user_id)
		return self._model_template


	def get_template_type(self, channel_type):
		try:
			module_class = importlib.import_module("merchant.{}.views".format(channel_type))
			model_class = getattr(module_class, '{}TemplateAPIView'.format(channel_type.capitalize()))
			template_type = model_class().serializer_class
		except:
			template_type = dict()
		return template_type


	def get_required_template(self, channel_type):
		try:
			module_class = importlib.import_module("merchant.{}.views".format(channel_type))
			model_class = getattr(module_class, '{}TemplateAPIView'.format(channel_type.capitalize()))
			template_type = model_class().required_template
		except:
			template_type = dict()
		return template_type


	def get_template_serializer(self, channel_type):
		try:
			module_class = importlib.import_module("merchant.{}.views".format(channel_type))
			model_class = getattr(module_class, '{}TemplateAPIView'.format(channel_type.capitalize()))
			template_serializers = model_class().serializer_class
		except:
			template_serializers = dict()
		return template_serializers


	def assign_price_template_channel(self, channel_type, price_template, product, **kwargs):
		try:
			module_class = CoreUtils().get_channel_model_utils(channel_type)
			if not module_class:
				return False
			if hasattr(module_class, 'assign_price_template'):
				return getattr(module_class, 'assign_price_template')(price_template, product, **kwargs)
		except:
			log_traceback()
			return False
		return False


	def assign_template_channel(self, channel, template_type, product_ids, products = None, **kwargs):
		try:
			module_class = CoreUtils().get_channel_model_utils(channel.type)
			if not module_class:
				return False
			if hasattr(module_class, f'assign_{template_type}_template_channel'):
				model_catalog = Catalog()
				model_catalog.set_user_id(channel.user_id)
				if not products:
					products = model_catalog.find_all(model_catalog.create_where_condition('_id', product_ids, 'in'))

				return_data = list()
				for product in products:
					product_id = product['_id']
					# product = model_catalog.get(product_id)
					if not product or not product['channel'].get(f'channel_{channel.id}') or not product['channel'][f'channel_{channel.id}'].get('template_data'):
						if not kwargs.get('update') and kwargs.get('template_data'):
							product['channel'][f'channel_{channel.id}']['template_data'][template_type] = kwargs['template_data']

					if kwargs.get('template_data'):
						if not product['channel'][f'channel_{channel.id}'].get('template_data'):
							product['channel'][f'channel_{channel.id}']['template_data'] = {}
						product['channel'][f'channel_{channel.id}']['template_data'][template_type] = kwargs['template_data']
					if not product['channel'][f'channel_{channel.id}'].get('template_data') or not product['channel'][f'channel_{channel.id}']['template_data'].get(template_type):
						continue
					assign = getattr(module_class, f'assign_{template_type}_template_channel')(channel, product, **kwargs)
					return_data.append(assign)
				# if to_int(product.get('variant_count')) > 0:
				# 	variants = product_utils.get_variants(product, channel.id)
				# 	if not variants or not variants.get('count'):
				# 		continue
				# 	for variant in variants['data']:
				# 		if not variant["channel"][f"channel_{channel.id}"]['template_data'].get(template_type):
				# 			variant["channel"][f"channel_{channel.id}"]['template_data'][template_type] = product['channel'][f'channel_{channel.id}']['template_data'][template_type]
				# 		getattr(module_class, f'assign_{template_type}_template_channel')(channel, variant, **kwargs)

				return return_data
		except:
			log_traceback()
			return False
		return False


	def assign_title_template_channel(self, channel_type, title_template, product, **kwargs):
		try:
			module_class = CoreUtils().get_channel_model_utils(channel_type)
			if not module_class:
				return False
			if hasattr(module_class, 'assign_title_template'):
				return getattr(module_class, 'assign_title_template')(title_template, product, **kwargs)
		except:
			return False
		return False


	def unset_template_data(self, template_data, unset = ('_id', 'id', 'type', 'name', 'channel_id')):
		result = copy.deepcopy(template_data)
		for field in unset:
			if field in result:
				del result[field]
		return result


	def assign_price_template(self, price_template, product, update = True, **kwargs):
		if not price_template:
			return True
		assign = self.assign_price_template_channel(self._channel_type, price_template, product, **kwargs)
		if assign:
			return True
		product_id = product['_id']
		model_product = self.get_model_product()
		price = round(self.adjustment_price(price_template, product['price']), 2)
		field = f"channel.channel_{self._channel_id}.price"
		model_product.update(product_id, {field: price})
		channel_type = self._channel_type
		# self.assign_price_template_channel(channel_type, price_template, product, **kwargs)
		return True


	def adjustment_price(self, price_template, price):
		if price_template.get('custom_price') and price_template['custom_price'].get('status') == 'enable':
			return round(price_template['custom_price']['value'], 2)
		price = to_decimal(price)
		value = to_decimal(price_template['adjustment']['value'])
		if price_template['adjustment']['modifier'] == 'percent':
			value = round((price * value) / 100, 2)
		return round(price + value if price_template['adjustment']['direction'] == 'increment' else price - value, 2)


	def allow_attribute_title_template(self):
		return ['sku', 'name', 'description', 'brand', 'price', 'condition', 'condition_notes', 'category', 'manufacturer', 'model', 'ean', 'asin', 'espn', 'upc', 'gtin', 'gcid', 'epid', 'weight', 'width', 'length', 'height', 'cost','msrp']


	def assign_title_template(self, title_template, product, update = True, **kwargs):
		if not title_template:
			return True
		assign = self.assign_title_template_channel(self._channel_type, title_template, product, **kwargs)
		if assign:
			return True
		status_title, title = assign_attribute_to_field(title_template['title'], product)
		status_description, description = assign_attribute_to_field(title_template['description'], product)
		if not status_title and not status_description:
			return product
		model_product = self.get_model_product()
		update_data = dict()
		if status_title:
			update_data[f"channel.channel_{self._channel_id}.name"] = title or '__empty__'
			product['channel'][f'channel_{self._channel_id}']['name'] = title or '__empty__'
		if status_description:
			update_data[f"channel.channel_{self._channel_id}.description"] = description
			product['channel'][f'channel_{self._channel_id}']['description'] = description
		if update:
			model_product.update(product['_id'], update_data)
		# self.assign_title_template_channel(self._channel_type, title_template, product, **kwargs)
		return product


	def get_templates(self):
		where = {"channel_id": self._channel_id}
		templates = self.get_model_template().find_all(where)
		return templates


	def map_construct_data(self, construct, data, overwrite = False):
		if isinstance(construct, dict):
			return_data = dict()
			if not isinstance(data, dict):
				return construct
			for k, v in construct.items():
				return_data[k] = self.map_construct_data(v, data.get(k), k in data)

		elif isinstance(construct, list):
			if not isinstance(data, list) or not data:
				return []
			if not construct:
				return []
			list_construct = construct[0]
			return_data = list()
			for row in data:
				return_data.append(self.map_construct_data(list_construct, row))
		else:
			if overwrite:
				return_data = data
			else:
				return_data = data or construct
		return return_data


class BaseMerchantUtils:
	def is_special_price(self, product):
		special_price = product['special_price']
		if not special_price:
			return False
		if not to_decimal(special_price['price'], 2) or to_decimal(special_price['price']) >= to_decimal(product['price']):
			return False
		if not to_timestamp_or_false(special_price['end_date']) or not to_timestamp_or_false(special_price['start_date']):
			return True
		if to_timestamp_or_false(special_price['start_date']) <= time.time() <= to_timestamp_or_false(special_price['end_date']):
			return True
		return False
	@staticmethod
	def adjustment_price(adjustment, price, rounding = False):
		price = to_decimal(price)
		value = to_decimal(adjustment['value'])
		if adjustment['modifier'] == 'percent':
			value = round((price * value) / 100, 2)
		total_price = price + value if adjustment['direction'] == 'increment' else price - value
		if rounding:
			rounded_price = int(total_price)
			total_price = rounded_price + 0.99 if total_price != rounded_price else total_price - 0.01
		return max(total_price, 0)


	def assign_price_template_channel(self, channel, product, **kwargs):
		model_catalog = Catalog()
		model_catalog.set_user_id(channel.user_id)
		template_data = product['channel'][f'channel_{channel.id}']['template_data'].get('price')
		fields = ['price', 'special_price']
		real_price = product['price']
		field_data = template_data.get('price') or template_data
		update_field = {}
		if field_data:
			price = adjustment_price(field_data, real_price, product)
			product['price'] = price
			product['channel'][f'channel_{channel.id}']['price'] = price
			update_field = {
				f'channel.channel_{channel.id}.template_data.price': template_data,
				f'channel.channel_{channel.id}.price': product['price'],
			}
			if product.get('special_price') and product['special_price'].get('price'):
				real_sale_price = product['special_price'].get('price')
				sale_price = adjustment_price(field_data, real_sale_price, product)
				product['special_price']['price'] = sale_price
				product['channel'][f'channel_{channel.id}']['special_price'] = copy.deepcopy(product['special_price'])
				product['channel'][f'channel_{channel.id}']['special_price']['price'] = sale_price
				update_field[f'channel.channel_{channel.id}.special_price'] = product['channel'][f'channel_{channel.id}']['special_price']

		# for field in fields:
		# 	field_data = template_data.get(field)
		# 	if not field_data:
		# 		continue
		# 	price = adjustment_price(field_data, real_price)
		# 	if field == 'price':
		# 		product['price'] = price
		# 		product['channel'][f'channel_{channel.id}']['price'] = price
		# 	else:
		# 		template_data[field]['price'] = price

		if kwargs.get('update') and update_field:
			model_catalog.update(product['_id'], update_field)
		template_data['price_value'] = product['price']
		return template_data


	def base_assign_price_template_channel(self, channel, product, **kwargs):
		channel_settings = json_decode(channel.settings)
		is_sale_price = False

		if channel_settings and channel_settings.get('price') and channel_settings['price'].get('use_sale_price') == 'enable' and self.is_special_price(product):
			product['price'] = product['special_price']['price']
			is_sale_price = True
			product['channel'][f'channel_{channel.id}']['special_price'] = {
				'price': 0,
				'start_data': '',
				'end_date': ''
			}
		model_catalog = Catalog()
		model_catalog.set_user_id(channel.user_id)
		template_data = product['channel'][f'channel_{channel.id}']['template_data'].get('price')
		real_price = product['price']
		price = adjustment_price(template_data, real_price, product)

		product['price'] = price
		product['channel'][f'channel_{channel.id}']['price'] = price
		update_field = {
			f'channel.channel_{channel.id}.template_data.price': template_data,
			f'channel.channel_{channel.id}.price': product['price'],
		}
		if is_sale_price:
			update_field[f'channel.channel_{channel.id}.special_price'] = {
				'price': 0,
				'start_data': '',
				'end_date': ''
			}
		if kwargs.get('update'):
			model_catalog.update(product['_id'], update_field)
		template_data['price_value'] = product['price']
		return template_data


	# def strip_html_from_description(self, text):
	# 	if not text:
	# 		return ''
	# 	soup = BeautifulSoup(text, 'lxml')
	# 	return soup.getText().strip()

	def is_channel_strip_html_in_description(self, channel):
		return channel.type in ['etsy', 'facebook', 'google', 'ebay']


	def escape_description(self, description):

		try:
			soup = BeautifulSoup(description, 'html.parser')
			description = soup.prettify(formatter = lambda s: s.replace(u'\xa0', ' '))
		except Exception:
			log_traceback()
		return to_str(description).replace('’', "'").replace("”", '"')


	def assign_title_template_channel(self, channel, product, **kwargs):
		model_catalog = Catalog()
		model_catalog.set_user_id(channel.user_id)
		description_format = False
		if self.is_channel_strip_html_in_description(channel):
			if channel.type != 'ebay':
				description = strip_html_from_description(product['description'])
				description_format = 'nl2br'

			else:
				description = self.escape_description(product['description'])
				description_format = 'nl2br'

			product['description'] = description
		title_template = product['channel'][f'channel_{channel.id}']['template_data'].get('title')
		status_title, title = assign_attribute_to_field(title_template['title'], product)
		status_description, description = assign_attribute_to_field(title_template['description'], product, description_format = description_format)
		title_template['name'] = title
		title_template['title'] = title
		title_template['title_value'] = title
		title_template['name_value'] = title
		title_template['description'] = description
		title_template['description_value'] = description
		update_field = {
			f'channel.channel_{channel.id}.template_data.name': title,
			f'channel.channel_{channel.id}.description': description,
			f'channel.channel_{channel.id}.name': title,
		}
		if kwargs.get('update'):
			model_catalog.update(product['_id'], update_field)
		return title_template


	def assign_price_template(self, price_template, product, **kwargs):
		if hasattr(self, 'assign_price_template_channel'):
			return self.assign_price_template_channel(price_template, product, **kwargs)
		product_id = product['_id']
		user_id = kwargs['user_id']
		model_product = Catalog()
		model_product.set_user_id(user_id)
		channel_id = kwargs['channel_id']
		update_fields = dict()
		if price_template['custom_price']['status'] == 'disable':
			rounding = True if price_template['adjustment']['rounding'] == 'enable' else False
			price = self.adjustment_price(price_template['adjustment'], product[price_template['adjustment']['source']], rounding)
			field = f"channel.channel_{channel_id}.price"
			update_fields[field] = price
		special_price_template = price_template['special_price']
		if special_price_template['custom_price']['status'] == 'enable':
			special_price = to_decimal(special_price_template['custom_price']['value'])
		else:
			rounding = True if special_price_template['adjustment']['rounding'] == 'enable' else False
			special_price = self.adjustment_price(special_price_template['adjustment'], product[special_price_template['adjustment']['source']], rounding)
		if special_price_template['status'] == 'enable':
			field = f"channel.channel_{channel_id}.special_price"
			update_fields[field] = {
				'price': special_price,
				'start_date': special_price_template['start_date'],
				'end_date': special_price_template['end_date']
			}
		if update_fields:
			model_product.update(product_id, update_fields)
		return True
