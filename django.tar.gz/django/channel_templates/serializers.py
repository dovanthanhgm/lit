from rest_framework import serializers

from accounts.utils import AccountUtils
from core.serializers import SerializerWithStatus, BaseSerializers
from libs.models.collections.template import Template

all_template_type = ('price', 'shipping', 'title', 'category', 'recipes', 'store', 'inventory', 'personalization', 'payment', 'offer', 'fr_title', 'amz_product_type', 'business', 'amz_seo', 'amz_details')


class BaseTemplateSerializer(BaseSerializers):
	type = serializers.ChoiceField(label = 'Template type', choices = all_template_type, required = True)
	name = serializers.CharField(label = 'Template Name')


	def validate_name(self, value):
		if self.context.get('is_new'):
			user_id = AccountUtils().get_user_id(self.context['request'])
			channel_id = self.context['request'].parser_context['kwargs']['channel_id']
			model_template = Template()
			model_template.set_user_id(user_id)
			if model_template.find_all({'name': value, 'channel_id': channel_id}):
				raise serializers.ValidationError('Channel name already exists.')
		return value


class ChannelTitleTemplateSerializer(BaseTemplateSerializer):
	title = serializers.CharField(label = 'Titlte')


class AdjustmentPriceSerializer(serializers.Serializer):
	direction = serializers.ChoiceField(choices = ('increment', 'decrement'), allow_blank = True, allow_null = True, required = False)
	modifier = serializers.ChoiceField(choices = ('fixed', 'percent'), allow_blank = True, allow_null = True, required = False)
	value = serializers.FloatField()
	rounding = serializers.ChoiceField(choices = ('nearest_099', 'nearest_095', 'nearest_5', 'nearest_1', 'nearest_10', 'nearest_1099', 'nearest_9'), required = False, allow_blank = True, allow_null = True)


	def construct(self):
		return {
			"direction": "",
			"modifier": "",
			"value": 0.0,
			"rounding": ""
		}


class CustomPriceSerializer(SerializerWithStatus):
	REQUIRED_FIELD = ['value']
	value = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	mapping = serializers.CharField(allow_null = True, allow_blank = True, required = False)
	override = serializers.CharField(default = '', allow_null = True, allow_blank = True, required = False)
	def construct(self):
		return {
			"status": "disable",
			"mapping": "",
			"override": "",
			"value": 0.0,
		}

class ChannelPriceTemplateSerializer(BaseTemplateSerializer):
	adjustment = AdjustmentPriceSerializer()
	custom_price = CustomPriceSerializer(required = False)
	default = serializers.BooleanField(default = False)
	extend_adjustment = serializers.ListField(child = AdjustmentPriceSerializer(), required = False)


	def construct(self):
		return {
			"type": "price",
			"name": "",
			"adjustment": AdjustmentPriceSerializer().construct(),
			"extend_adjustment": [
				{
					"direction": "",
					"modifier": "",
					"value": 0.0
				}
			],
			"custom_price": CustomPriceSerializer().construct(),
			"default": False
		}


class ChannelInventoryTemplateSerializer(BaseTemplateSerializer):
	status = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True)
	adjust = serializers.IntegerField(allow_null = True)
	max_qty = serializers.IntegerField(allow_null = True)
	min_qty = serializers.IntegerField(allow_null = True)


	def construct(self):
		return {
			"type": "inventory",
			"name": "",
			"adjust": 0,
			"max_qty": 0,
			"min_qty": 0,
		}


class BaseChannelPriceTemplateSerializer(BaseSerializers):
	adjustment = AdjustmentPriceSerializer()
	custom_price = CustomPriceSerializer()


class ChannelPriceTemplateSerializerWithStatus(SerializerWithStatus):
	adjustment = AdjustmentPriceSerializer()
	custom_price = CustomPriceSerializer()


class ExtendAdjustmentPriceSerializer(AdjustmentPriceSerializer):
	source = serializers.ChoiceField(choices = ('price', 'min_price', 'max_price'))
	rounding = serializers.ChoiceField(choices = ('nearest_099', 'nearest_095', 'nearest_1', 'nearest_10', 'nearest_1099'), required = False, allow_blank = True, allow_null = True)


class ChannelExtendPriceTemplateSerializer(ChannelPriceTemplateSerializer):
	adjustment = ExtendAdjustmentPriceSerializer()


class SpecialPriceSerializer(serializers.Serializer):
	status = serializers.ChoiceField(choices = ('enable', 'disable'))
	adjustment = AdjustmentPriceSerializer()
	custom_price = CustomPriceSerializer()
	start_date = serializers.DateField(allow_null = True, required = False)
	end_date = serializers.DateField(allow_null = True, required = False)


	def validate(self, data):
		errors = dict()
		if data['status'] == 'enable':
			if not data['start_date']:
				errors['start_date'] = 'This field is required.'
			if not data['end_date']:
				errors['end_date'] = 'This field is required.'
		if errors:
			raise serializers.ValidationError(errors)
		return data


class ExtendSpecialPriceSerializer(SpecialPriceSerializer):
	adjustment = ExtendAdjustmentPriceSerializer()


class ChannelTemplatesSerializer(serializers.Serializer):
	channel_type = serializers.CharField(label = 'Channel Type')
	channel_id = serializers.IntegerField(label = 'Channel Id')
	templates = serializers.ListSerializer(label = 'Channel Templates', child = ChannelTitleTemplateSerializer())


class GetChannelTemplatesSerializer(serializers.Serializer):
	code = serializers.IntegerField(label = 'code')
	message = serializers.CharField(label = 'message')
	count = serializers.IntegerField(label = 'count')
	data = ChannelTemplatesSerializer(many = True, required = False)


class BaseTitleSerializer(serializers.Serializer):
	type = serializers.ChoiceField(label = 'Template type', choices = ('price', 'shipping', 'title', 'category', 'recipes'), required = True)
	name = serializers.CharField(label = 'Template Name')
	title = serializers.CharField(label = 'Title')
	description = serializers.CharField(label = 'Description', required = False, allow_null = True, allow_blank = True)
	default = serializers.BooleanField(default = False)


	def construct(self):
		return {
			"type": "title",
			"name": "",
			"title": "",
			"description": "",
			"default": False
		}


class BaseRecipesSerializer(serializers.Serializer):
	category = serializers.CharField(required = False)
	title = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	price = serializers.CharField(required = False, allow_null = True, allow_blank = True)


class BaseTemplateCombinationSerializer(serializers.Serializer):
	name = serializers.CharField()
	type = serializers.CharField(default = 'recipes')
	template = BaseRecipesSerializer()


	def construct(self):
		return {
			"type": "recipes",
			"name": "recipes",
			"template": {
				"title": "",
				"price": "",
				"category": "",
			}
		}
