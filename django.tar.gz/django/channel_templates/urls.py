from django.urls import path, include

from .views import AssignTemplateForProduct, ChannelTemplates, ChannelTemplateDetails, TemplateApplyChange, AssignTemplateToAllProduct

urlpatterns = [
	path("/channels/", include([
		path("<str:channel_type>/<int:channel_id>/<str:template_type>/<str:template_id>", AssignTemplateForProduct.as_view()),
		path("templates", ChannelTemplates.as_view()),
		path("templates/<str:channel_type>", ChannelTemplateDetails.as_view()),
	])),
	path("/templates/", include([
		path("<int:channel_id>/<str:template_id>/apply-change", TemplateApplyChange.as_view(), name = 'template.change'),
		path("<int:channel_id>/assign", AssignTemplateToAllProduct.as_view(), name = 'template.assign')
	]))
]
