from django.apps import AppConfig


class ChannelTemplatesConfig(AppConfig):
    name = 'channel_templates'
