import copy
import time
from collections import OrderedDict

from django.http import HttpResponseForbidden, JsonResponse, HttpResponseNotFound, HttpResponse
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, status

from accounts.utils import AccountUtils
from channel_templates.serializers import GetChannelTemplatesSerializer, ChannelTitleTemplateSerializer
from channel_templates.utils import ChannelTemplateUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from core.responses import PaginationResponse, ErrorResponse
from core.utils import CoreUtils
from datasync.api.sync import SyncApi
from libs.models.collections.catalog import Catalog
from libs.models.collections.template import Template
from libs.utils import to_object_id, to_str, to_int, update_nested_dict, json_decode
from processes.utils import ProcessUtils
from products.utils import ProductUtils
from products.views import ProductChannel
from user_action_logs.utils import UserActionLogUtils


class ChoiceSerializer(generics.ListAPIView):
	serializer_class = {}


	def get_serializer_class_datasync(self, template_type):
		if self.serializer_class.get(template_type):
			serializer_cla = self.serializer_class.get(template_type)
			return serializer_cla
		return False


	def get_serializer_datasync(self, *args, **kwargs):
		"""
		Return the serializer instance that should be used for validating and
		deserializing input, and for serializing output.
		"""
		serializer_class = self.get_serializer_class_datasync(kwargs['data']['type'])
		kwargs['context'] = self.get_serializer_context()
		return serializer_class(*args, **kwargs)


class TemplateAPIView(ChoiceSerializer):
	channel_name = ''
	required_template = []


	def select_fields(self):
		return None


	def get(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_template = Template()
		model_template.set_user_id(user_id)
		# limit = request.GET.get('limit')
		# if not limit:
		# 	limit = 20
		# page = request.GET.get('page')
		# if not page:
		# 	page = 1
		sort_by = request.GET.get('sort', 'name')
		template_type = request.GET.get('type')
		channel_id = kwargs['channel_id']
		if template_type:
			where = {"type": template_type, "channel_id": channel_id}
		else:
			where = {"channel_id": channel_id}
		templates = model_template.find_all(where, sort = sort_by, select_fields = self.select_fields())
		data = {}
		if template_type:
			data[template_type] = []
			for result in templates:
				if result['type'] == template_type:
					data[template_type].append(result)
		else:
			template_types = list(self.serializer_class.keys())
			template_types.append('recipes')
			for template_type in template_types:
				data[template_type] = []
			for result in templates:
				if result['type'] not in data:
					continue
				data[result['type']].append(result)
		for template_type_key, template_data in data.items():
			for row in template_data:
				row['id'] = row['_id']
				del row['_id']
		data = {
			"count": model_template.count(where),
			"data": data,
		}
		return JsonResponse(PaginationResponse(**data).to_dict(), safe = False)


	def post(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		template_type = request.data['type']
		if not self.serializer_class.get(template_type):
			return JsonResponse(data = {"message": f"template_type does not fall into the following"
			                                       f" types: {', '.join(self.serializer_class.keys())} "})
		serializer = self.get_serializer_datasync(data = request.data)
		serializer.context['is_new'] = True
		if serializer.is_valid():
			model_template = Template()
			model_template.set_user_id(user_id)

			data_post = ChannelTemplateUtils().map_construct_data(serializer.construct(), serializer.data)
			if data_post.get('default'):
				data_template = model_template.find_all({"type": serializer.data.get("type"), "channel_id": kwargs['channel_id']})
				if not data_template:
					data_post['default'] = True
				else:
					model_template.update_many({"type": serializer.data.get("type"), "channel_id": int(kwargs['channel_id'])}, {"default": False})
			# else:
			# 	if request.data['type'] in self.required_template:
			# 		where_template = model_template.create_where_condition('default', True)
			# 		where_template.update(model_template.create_where_condition('template_type', request.data['type']))
			# 		where_template.update(model_template.create_where_condition('channel_id', kwargs['channel_id']))
			# 		find_template = model_template.find_one(where_template)
			# 		if not find_template:
			# 			data_post.update({"default": True})
			data_post.update({"channel_id": kwargs['channel_id']})
			template = model_template.create(data_post)
			data_post['_id'] = template
			return JsonResponse(data_post, safe = False)
		else:
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)


	def delete(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_template = Template()
		model_template.set_user_id(user_id)
		model_template.delete_all()
		data = {"message": "delete success"}
		return JsonResponse(data, safe = False)


class TemplateApiCount(TemplateAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)

		if not user_id:
			return HttpResponseForbidden()
		start_time = time.time()
		model_template = Template()
		model_template.set_user_id(user_id)
		where = {}
		data = {
			"count": model_template.count(where),
		}
		end_time = time.time()
		process_time = end_time - start_time
		print("Process Time: ", process_time)
		return JsonResponse(data, safe = False)


template_api_count_response = openapi.Schema(
	type = openapi.TYPE_OBJECT,
	properties = OrderedDict((
		('count', openapi.Schema(type = openapi.TYPE_INTEGER, example = 20)),
	))
)


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: template_api_count_response
	}
))
class TemplateDetailApiview(ChoiceSerializer):
	channel_name = ''


	def get(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		user_id = AccountUtils().get_user_id(request)
		model_template = Template()
		model_template.set_user_id(user_id)
		template = model_template.get(kwargs['template_id'])
		if not template:
			return HttpResponseNotFound()
		if template['channel_id'] != kwargs['channel_id']:
			return JsonResponse(data = {"message": f"template_id {kwargs['template_id']} have channel_id is {template.channel_id}"})
		return JsonResponse(template)


	def put(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		serializer = self.get_serializer_datasync(data = request.data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		data_post = ChannelTemplateUtils().map_construct_data(serializer.construct(), serializer.data)

		user_id = AccountUtils().get_user_id(request)
		model_template = Template()
		model_template.set_user_id(user_id)
		template = model_template.get(kwargs['template_id'])
		if not template:
			return HttpResponseNotFound()

		if template['channel_id'] == kwargs['channel_id']:
			data_update = update_nested_dict(template, data_post)
			if data_update.get('default'):
				model_template.update_many({"type": data_update.get("type"), "channel_id": kwargs['channel_id']}, {"default": False})

			model_template.update(kwargs['template_id'], data_update)
			template = model_template.get(kwargs['template_id'])
			data_log = {
				'template_id': kwargs['template_id'],
				'template_type': request.data.get('type'),
				'old_template': template,
				'new_template': request.data
			}
			template_type = request.data.get('type')
			template_update_data = None
			if template:
				template_update_data = {}
				template_data = ChannelTemplateUtils().unset_template_data(template)
				template_data['edited'] = True
				template_update_data[f"channel.channel_{kwargs['channel_id']}.template_data.{template_type}"] = template_data

			model_product = ProductUtils().get_model_catalog(user_id = user_id)
			where = model_product.create_where_condition(f"channel.channel_{kwargs['channel_id']}.templates.{template_type}", kwargs['template_id'])
			model_product.update_many(where, template_update_data)
			api_info = json_decode(channel.api)
			if not api_info or not api_info.get('skip_update_template'):
				process = ProcessUtils().get_process_by_type(kwargs['channel_id'])
				if process:
					post_data = {
						'condition': {
							'products': [
								{
									'field': f"channel.channel_{kwargs['channel_id']}.templates.{template_type}",
									'value': kwargs['template_id'],
									'condition': '='
								},
								# {
								# 	'field': f"channel.channel_{kwargs['channel_id']}.status",
								# 	'value': ProductChannel.ACTIVE,
								# 	'condition': '='
								# }
							]
						}
					}
					publish = SyncApi(process_id = process.id).post('template/update/{}'.format(process.id), data = post_data)

			UserActionLogUtils().create_log(user_id, kwargs['channel_id'], 'update_template', data = data_log, request = request)

			return JsonResponse(template, safe = False)

		else:
			return JsonResponse(data = {
				"message": f"Template have template_id: {kwargs['template_id']}, channel_id: {template['channel_id']}"
			})


	def update_object_data(self, current_data, update_data):
		new_data = dict()
		for data_key, data_value in update_data.items():
			if update_data.get(data_key) is None and data_key != 'value':
				continue
			elif update_data.get(data_key) is None:  # when start_date and end_date = null
				data_value[data_key] = None
			if isinstance(data_value, dict) and isinstance(update_data.get(data_key), dict):
				data_value = self.update_object_data(data_value, update_data[data_key])
			elif isinstance(data_value, (list, tuple)) and isinstance(update_data[data_key], (list, tuple)):
				data_value = update_data[data_key]
			else:
				data_value = update_data[data_key]
			new_data[data_key] = data_value
		return new_data


	def delete(self, request, *args, **kwargs):
		message = check_channel_id(self.channel_name, kwargs['channel_id'])
		if message:
			return JsonResponse(data = {"message": message})
		user_id = AccountUtils().get_user_id(request)
		model_template = Template()
		model_template.set_user_id(user_id)
		template = model_template.get(kwargs['template_id'])
		if not template:
			return HttpResponseNotFound()
		if template['channel_id'] == kwargs['channel_id']:

			model_template.delete(kwargs['template_id'])
			if template.get('type') != 'price':
				model_catalog = Catalog()
				model_catalog.set_user_id(user_id)
				where = dict()
				where.update(model_catalog.create_where_condition(f'channel.channel_{template["channel_id"]}.templates.{template["type"]}', template['_id']))
				model_catalog.update_many(where, {
					f'channel.channel_{template["channel_id"]}.templates.{template["type"]}': '',
				})
			else:
				delete_price_template = SyncApi(user_id = user_id).post('action/channel/delete-price-template', data = {'template_id': kwargs['template_id'], 'channel_id': kwargs['channel_id']})

			data = {
				"message": f"Delete template have template_id is {kwargs['template_id']} success",
			}
			return JsonResponse(data, safe = False)
		else:
			return JsonResponse(data = {
				"message": f"Template have template_id: {kwargs['template_id']}, channel_id: {template['channel_id']}"
			})


def check_channel_id(channel_name, channel_id):
	qs = Channel.objects.filter(pk = channel_id).first()
	if not qs:
		return f"No channel_id {channel_id}"
	if qs.type.lower() != channel_name.lower():
		return f"Channel_id {channel_id} is not channel type {channel_name}"


@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = openapi.Schema(
		type = openapi.TYPE_OBJECT,
		properties = {
			'listing_ids': openapi.Schema(type = openapi.TYPE_ARRAY, description = 'string', items = openapi.Items(type = openapi.TYPE_STRING)),
		}
	)
))
class AssignTemplateForProduct(generics.ListAPIView):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._user_id = None
		self._model_product = None
		self._channel_id = None
		self._channel_type = None


	def post(self, request, *args, **kwargs):
		message = check_channel_id(kwargs['channel_type'], kwargs['channel_id'])
		if message:
			return JsonResponse(ErrorResponse(errors = message).to_dict(), status = 400)

		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		self._model_product = ProductUtils().get_model_catalog(request, *args, **kwargs)
		self._channel_id = kwargs['channel_id']
		channel_id = kwargs['channel_id']
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		self._channel_type = kwargs['channel_type']
		template_types = ChannelTemplateUtils().get_template_type(self._channel_type)
		if not template_types:
			return JsonResponse(ErrorResponse(errors = 'channel is not template').to_dict(), status = 400)
		if kwargs['template_type'] not in template_types and kwargs['template_type'] != 'recipes':
			return JsonResponse(ErrorResponse(errors = 'template type invalid').to_dict(), status = 400)

		listing_ids = request.data.get("listing_ids")
		if not listing_ids:
			return JsonResponse(data = {"message": "Don't have data requirement"})

		listing_ids_invalid = list(filter(lambda x: not to_object_id(x), listing_ids))
		if listing_ids_invalid:
			return JsonResponse(ErrorResponse(code = 400, errors = {'product_ids': "invalid [{}]".format(", ".join(list(map(lambda x: to_str(x), listing_ids_invalid))))}).to_dict(), status = 400)
		template_recipes = False
		model_template = Template()
		model_template.set_user_id(user_id)
		if ProductUtils().need_apply_template_for_variants(kwargs['template_type'], channel):
			where_variants = self._model_product.create_where_condition('parent_id', listing_ids, 'in')
			count_variants = self._model_product.count(where_variants)
			len_applies = count_variants + len(listing_ids)
			number_template = 1

			if kwargs['template_type'] == 'recipes':
				template_recipes = model_template.get(kwargs['template_id'])
				number_template = 0
				for row in template_types:
					if template_recipes['template'].get(row):
						number_template += 1
			len_applies *= number_template

			if len_applies > 100:
				live_process_id = CoreUtils().init_process(user_id = user_id, channel_id = channel_id, process_type = 'assign_template')
				request_data = request.data

				request_data['live_process_id'] = live_process_id

				SyncApi(user_id = user_id).post(f"channel/{channel_id}/templates/{kwargs['template_type']}/{kwargs['template_id']}", data = request_data)

				return JsonResponse(data = {'code': 'wait'}, status = status.HTTP_201_CREATED)

		price_template_id = None
		title_template_id = None

		template_type_ids = dict()
		template_update = dict()
		products = self._model_product.find_all(self._model_product.create_where_condition('_id', listing_ids, 'in'))

		if kwargs['template_type'] == 'recipes':
			if not template_recipes:
				template_recipes = model_template.get(kwargs['template_id'])
			if not template_recipes:
				return JsonResponse(data = {"message": f"template_recipes_id {kwargs['template_id']} not found"}, safe = False)
			price_template_id = template_recipes.get('price')
			title_template_id = template_recipes.get('title')
			for row in template_types:
				if template_recipes['template'].get(row):
					template_type_ids[row] = template_recipes['template'][row]
			template_type_ids["recipes"] = kwargs['template_id']
			template_update[f"channel.channel_{kwargs['channel_id']}.templates"] = template_type_ids
		# self._model_product.update_many(self._model_product.create_where_condition('_id', listing_ids, 'in'), {f"channel.channel_{kwargs['channel_id']}.templates": template_recipes['template']})
		else:
			if kwargs['template_type'] == 'title':
				title_template_id = kwargs['template_id']
			if kwargs['template_type'] == 'price':
				price_template_id = kwargs['template_id']
			template_type_ids[kwargs['template_type']] = kwargs['template_id']
			template_update[f"channel.channel_{kwargs['channel_id']}.templates.{kwargs['template_type']}"] = kwargs['template_id']
		self._model_product.update_many(self._model_product.create_where_condition('_id', listing_ids, 'in'), template_update)

		template_ids = list(template_type_ids.values())
		templates = model_template.find_all(model_template.create_where_condition('_id', template_ids, 'in'))
		model_utils = ChannelTemplateUtils(user_id = user_id, channel_id = kwargs['channel_id'], channel_type = self._channel_type)

		for product in products:
			for template in templates:
				template_type = template['type']

				if not product.get('template_data'):
					product['template_data'] = dict()
				update_template = model_utils.unset_template_data(template)
				update_template_ids = list()
				product['template_data'][template_type] = update_template
				if not product["channel"][f"channel_{channel_id}"].get('template_data'):
					product["channel"][f"channel_{channel_id}"]['template_data'] = {}
				product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = product['template_data'][template_type]
				template_data = model_utils.assign_template_channel(channel, template_type, [product['_id']], update = True, template_data = product['template_data'][template_type])
				if template_data:
					product['template_data'][template_type] = template_data[0] if isinstance(template_data, list) else template_data
					if product["channel"][f"channel_{channel_id}"]['template_data'].get(template_type):
						product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = update_nested_dict(product["channel"][f"channel_{channel_id}"]['template_data'][template_type], product['template_data'][template_type])
					else:
						product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = product['template_data'][template_type]
				else:
					update_template_ids.append(product['_id'])
				if template_type not in ['title', 'shipping', 'payment'] and (to_int(product.get('variant_count')) > 0 or to_int(product['channel'].get(f'channel_{channel_id}', {}).get('variant_count')) > 0):
					variants = ProductUtils(user_id = user_id).get_variants(product, channel_id)
					if variants['count']:
						for variant in variants['data']:
							if not variant.get('template_data'):
								variant['template_data'] = dict()
							variant['template_data'][template_type] = model_utils.unset_template_data(template)
							variant_template_data = model_utils.assign_template_channel(channel, template_type, [variant['_id']], update = True, template_data = copy.deepcopy(product['template_data'][template_type]))
							if variant_template_data:
								variant['template_data'][template_type] = variant_template_data[0]
								if not variant["channel"][f"channel_{channel_id}"]['template_data'].get(template_type):
									variant["channel"][f"channel_{channel_id}"]['template_data'][template_type] = dict()
								variant["channel"][f"channel_{channel_id}"]['template_data'][template_type] = update_nested_dict(variant["channel"][f"channel_{channel_id}"]['template_data'][template_type], variant_template_data[0])
							else:
								update_template_ids.append(variant['_id'])

						product['variants'] = variants['data']
				if update_template_ids:
					self._model_product.update_many(self._model_product.create_where_condition('_id', update_template_ids, 'in'), {
						f'channel.channel_{channel_id}.template_data.{template_type}': update_template
					})
		return JsonResponse(data = {}, status = status.HTTP_201_CREATED)


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: GetChannelTemplatesSerializer
	}
))
class ChannelTemplates(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		channels = ChannelUtils().get_channel_by_user_id(AccountUtils().get_user_id(request))
		data = list()
		for channel in channels:
			if channel.deleted_at:
				continue
			channel_type = channel.type
			template_type = ChannelTemplateUtils().get_template_type(channel_type)
			if not template_type:
				continue
			template_data = list()
			for row in template_type:
				template_data.append({
					'type': row,
					'title': ChannelUtils().channel_template_title(channel_type, row)
				})
			channel_data = {
				'type': channel_type,
				'name': channel.name,
				'id': channel.id,
				'templates': template_data
			}
			data.append(channel_data)
		return JsonResponse(PaginationResponse(data = data, count = len(data)).to_dict(), safe = False)


@method_decorator(name = 'get', decorator = swagger_auto_schema(
	responses = {
		status.HTTP_200_OK: ChannelTitleTemplateSerializer(many = True)
	}
))
class ChannelTemplateDetails(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		channel_type = kwargs['channel_type']
		template_type = ChannelTemplateUtils().get_template_type(channel_type)
		if not template_type:
			return HttpResponseNotFound()
		template_data = list()
		for row in template_type:
			template_data.append({
				'type': row,
				'title': ChannelUtils().channel_template_title(channel_type, row)
			})
		return JsonResponse(PaginationResponse(data = template_data, count = len(template_data)).to_dict(), safe = False)


class TemplateApplyChange(generics.CreateAPIView):
	_model_template: Template


	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._model_template = None
		self._user_id = None
		self._template = None


	def get_model_template(self, user_id = None):
		if self._model_template:
			return self._model_template
		if not user_id:
			user_id = self._user_id
		self._model_template = Template()
		self._model_template.set_user_id(user_id)
		return self._model_template


	def set_template(self, template):
		self._template = template


	def validate_data(self, request, *args, **kwargs):
		template_id = kwargs['template_id']
		channel_id = kwargs['channel_id']
		user_id = AccountUtils().get_user_id(request)
		product_ids = request.data.get('product_ids')
		if not product_ids:
			return JsonResponse(ErrorResponse(errors = 'product_ids is missing').to_dict(), status = 400)
		listing_ids_invalid = list(filter(lambda x: not to_object_id(x), product_ids))
		if listing_ids_invalid:
			return JsonResponse(ErrorResponse(code = 400, errors = {'product_ids': "invalid [{}]".format(", ".join(list(map(lambda x: to_str(x), listing_ids_invalid))))}).to_dict(), status = 400)
		channel = ChannelUtils().get(channel_id)
		if not channel:
			return HttpResponseNotFound()
		if channel.user_id != user_id:
			return HttpResponseForbidden()
		template = self.get_model_template(user_id = user_id).get(template_id)
		if not template:
			return HttpResponseNotFound()
		if to_int(template['channel_id']) != to_int(channel_id):
			return HttpResponseForbidden()
		self.set_template(template)
		return True


	def post(self, request, *args, **kwargs):
		validate = self.validate_data(request, *args, **kwargs)
		if validate is not True:
			return validate
		template_id = kwargs['template_id']
		channel_id = kwargs['channel_id']
		channel = get_object_or_404(Channel, pk = channel_id)
		user_id = AccountUtils().get_user_id(request)
		product_ids = request.data.get('product_ids')
		model_catalog = ProductUtils().get_model_catalog(user_id = user_id)
		products = model_catalog.find_all(model_catalog.create_where_condition('_id', product_ids, 'in'))
		template_type = self._template['type']
		model_utils = ChannelTemplateUtils(user_id = user_id, channel_id = channel_id, channel_type = self._template['type'])
		for product in products:
			if not product.get('template_data'):
				product['template_data'] = dict()
			product['template_data'][template_type] = model_utils.unset_template_data(self._template)
			if not product["channel"][f"channel_{channel_id}"].get('template_data'):
				product["channel"][f"channel_{channel_id}"]['template_data'] = {}
			product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = product['template_data'][template_type]
			template_data = model_utils.assign_template_channel(channel, template_type, [product['_id']], update = False, template_data = product['template_data'][template_type])
			if template_data:
				product['template_data'][template_type] = template_data[0] if isinstance(template_data, list) else template_data
				# if 'return_data' in product['template_data'][template_type]:
				# 	del product['template_data'][template_type]['return_data']
				if 'need_update_data' in product['template_data'][template_type]:
					product["channel"][f"channel_{channel_id}"].update(product['template_data'][template_type]['need_update_data'])
					del product['template_data'][template_type]['need_update_data']
				if product["channel"][f"channel_{channel_id}"]['template_data'].get(template_type):
					product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = update_nested_dict(product["channel"][f"channel_{channel_id}"]['template_data'][template_type], product['template_data'][template_type])
				else:
					product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = product['template_data'][template_type]
			variants = ProductUtils(user_id = user_id).get_variants(product, channel_id)
			if variants['count']:
				for variant in variants['data']:
					if not variant.get('template_data'):
						variant['template_data'] = dict()
					variant['template_data'][template_type] = model_utils.unset_template_data(self._template)
					variant_template_data = model_utils.assign_template_channel(channel, template_type, [variant['_id']], update = False, template_data = copy.deepcopy(product['template_data'][template_type]))
					if variant_template_data:
						variant['template_data'][template_type] = variant_template_data[0]
						if not variant["channel"][f"channel_{channel_id}"]['template_data'].get(template_type):
							variant["channel"][f"channel_{channel_id}"]['template_data'][template_type] = dict()
						variant["channel"][f"channel_{channel_id}"]['template_data'][template_type] = update_nested_dict(variant["channel"][f"channel_{channel_id}"]['template_data'][template_type], variant_template_data[0])
				product['variants'] = variants['data']

			#
				# product['channel']['channel_{}'.format(channel_id)]['price'] = model_utils.adjustment_price(self._template, product['price'])
				# if to_int(product['variant_count']) > 0:
				# 	variants = model_catalog.find_all(model_catalog.create_where_condition('parent_id', product['_id']))
				# 	for variant in variants:
				# 		variant['channel']['channel_{}'.format(channel_id)]['price'] = model_utils.adjustment_price(self._template, variant['price'])
		products = ProductChannel().process_product_data_before_return(products, request, *args, **kwargs)
		products = self.process_product_data_before_return(products, self._template)
		if len(products) == 1:
			return JsonResponse(products[0], safe = 1)
		return JsonResponse(PaginationResponse(data = products).to_dict())


	def process_product_data_before_return(self, products, template, is_variant = False):
		fields = []
		template_type = template['type']
		if template['type'] == 'price':
			fields.append('price')
		if template['type'] == 'title':
			fields += ['name', 'description']
		product_response = list()
		for product in products:
			product_data = dict()
			for field in fields:
				product_data[field] = product[field]
			product_data['template'] = template
			product_data['template_data'] = product['template_data'].get(template_type) or template
			for field in ['name', 'price', 'description']:
				if field in fields and product_data['template_data'].get(f'{field}_value'):
					product_data[field] = product_data['template_data'].get(f'{field}_value')
					del product_data['template_data'][f'{field}_value']
			if product_data['template_data'].get('return_data'):
				product_data.update(product_data['template_data'].get('return_data'))
				del product_data['template_data']['return_data']
			if product_data['template_data'].get('need_update_data'):
				# product_data.update(product_data['template_data'].get('need_update_data'))
				del product_data['template_data']['need_update_data']
			if is_variant:
				product_data['id'] = product['publish_id']
			else:
				if product.get('variants'):
					product_data['variants'] = self.process_product_data_before_return(product['variants'], template, True)
				# if product.get('variants'):
				# 	for variant in product['variants']:
				# 		variant_data = self.process_product_data_before_return(variant, template)
				# 		variant_data['id'] = variant['publish_id']
				# 		product_data['variants'].append(variant_data)
			product_response.append(product_data)
		return product_response


class AssignTemplateToAllProduct(generics.ListAPIView):

	def post(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		process = ProcessUtils().get_process_by_type(kwargs['channel_id'])
		data = request.data
		data.update({"channel_id": kwargs['channel_id'], "user_id": user_id})
		res = SyncApi(process_id = process.id).post('channel/assign-template/{}'.format(process.id), data = data)
		if res['result'] != 'success':
			return JsonResponse(data = res, status = 400)
		return HttpResponse(status = 204)
