from rest_framework import serializers

from .models import FeatureRequest


class FeatureRequestSerializer(serializers.ModelSerializer):
	class Meta:
		model = FeatureRequest
		fields = ["description", "skype", "whatsapp", 'id', 'created_at']
