from django.apps import AppConfig


class FeatureRequestConfig(AppConfig):
    name = 'feature_request'
