from django.urls import path, include

from feature_request.views import FeatureRequestApiView
from litcommerce_order import views

urlpatterns = [
	path('',  FeatureRequestApiView.as_view()),

]
