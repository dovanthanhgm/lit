from django.db import models


# Create your models here.
from tinymce.models import HTMLField

from accounts.models import UserAccount


class FeatureRequest(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE)
	description = HTMLField()
	skype = models.CharField(null = True, max_length = 255, blank = True)
	whatsapp = models.CharField(null = True, max_length = 255, blank = True)
	added = models.BooleanField(default = False)
	comment = HTMLField(null = True)
	created_at = models.DateTimeField(auto_now_add = True)
	ticket_id = models.IntegerField(null = True)


	class Meta:
		db_table = 'features_request'
		ordering = ['-created_at']
