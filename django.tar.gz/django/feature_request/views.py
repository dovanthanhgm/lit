# Create your views here.
from django.core.mail import send_mail
from rest_framework import generics

from core.middleware import CaptchaMiddleware
from core.utils import CoreUtils
from feature_request.models import FeatureRequest
from feature_request.serializers import FeatureRequestSerializer
from libs.utils import strip_html_from_description, is_local


class FeatureRequestApiView(generics.CreateAPIView):
	queryset = FeatureRequest.objects.all()
	serializer_class = FeatureRequestSerializer
	MIDDLEWARE_CLASSES = (CaptchaMiddleware.NAME,)

	def perform_create(self, serializer):
		skype = serializer.validated_data.get('skype')
		whatsapp = serializer.validated_data.get('whatsapp')
		need_save = False
		if skype and not self.request.user.skype:
			self.request.user.skype = skype
			need_save = True
		if whatsapp and not self.request.user.whatsapp:
			self.request.user.whatsapp = whatsapp
			need_save = True
		if need_save:
			self.request.user.save()
		serializer.save(user = self.request.user)
		comment = serializer.validated_data
		# if comment.get('description'):
		# 	comment['description'] = strip_html_from_description(comment['description'])
		# if 'g-recaptcha-response' in comment:
		# 	del comment['g-recaptcha-response']
		# comment_msg = "\n".join([f"{field.capitalize()}: {value}" for field, value in comment.items()])
		# ticket_data = {
		# 	'subject': f"LitCommerce: {self.request.user.email} Feature Request",
		# 	'comment': comment_msg,
		# }
		if not is_local():
			send_mail(
				subject = f"{self.request.user.email} Feature Request",
				message = '',
				from_email = self.request.user.email,
				recipient_list = ['contact@litcommerce.com'],
				html_message = comment['description'],
				fail_silently = False
			)
		# ticket_id = CoreUtils().create_ticket_zendesk(self.request.user, **ticket_data)