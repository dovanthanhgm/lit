from django.contrib import admin

# Register your models here.
from core.myadmin.admin import CoreAdmin
from feature_request.models import FeatureRequest
from libs.utils import to_str


class FeatureRequestAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'description_non_html', 'skype', 'whatsapp', 'created_at', 'added', 'comment_non_html']
	list_filter = ('created_at',)


	def strip_html_from_description(self, text):
		if not text:
			return ''
		text = to_str(text).replace('<br>', '\n').replace('</br>', '\n')
		from bs4 import BeautifulSoup
		soup = BeautifulSoup(text, 'lxml')
		return soup.getText().strip()


	def description_non_html(self, obj):
		return self.strip_html_from_description(obj.description)


	description_non_html.short_description = 'Description'


	def comment_non_html(self, obj):
		return self.strip_html_from_description(obj.comment)


	comment_non_html.short_description = 'Comment'


admin.site.register(FeatureRequest, FeatureRequestAdmin)
