from django.urls import path

from survey.views import SurveyApiView

urlpatterns = [
	path('', SurveyApiView.as_view()),

]
