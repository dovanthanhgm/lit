from django.db import models

# Create your models here.
from accounts.models import UserAccount


class SurveyModel(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True)
	survey = models.TextField(null = True)
	more_details = models.TextField(null = True, blank = True)
	more_details2 = models.TextField(null = True, blank = True)
	created_at = models.DateTimeField(auto_now_add = True)
	survey_type = models.CharField(max_length = 25, null = False, blank = False, choices = (('Cancel Sub', 'Cancel Sub'), ('Close Account', 'Close Account')))


	class Meta:
		db_table = 'survey'
		ordering = ['-id']
