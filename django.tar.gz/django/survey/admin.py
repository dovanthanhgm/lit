from django.contrib import admin

from core.myadmin.admin import CoreAdmin, UserFilter
from survey.models import SurveyModel


# Register your models here.
class SurveyAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'survey', 'more_details', 'more_details2', 'survey_type', 'created_at']
	list_filter = [UserFilter]

admin.site.register(SurveyModel, SurveyAdmin)