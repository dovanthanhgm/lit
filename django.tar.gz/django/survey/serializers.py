from rest_framework import serializers

from .models import SurveyModel


class SurveySerializer(serializers.ModelSerializer):
	class Meta:
		model = SurveyModel
		fields = ["survey", "survey_type", "more_details", 'id', "more_details2"]
