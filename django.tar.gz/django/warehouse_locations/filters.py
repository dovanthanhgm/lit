from django_filters import FilterSet

from accounts.utils import AccountUtils
from warehouse_locations.models import WarehouseLocation


class WarehouseLocationFilter(FilterSet):
	class Meta:
		model = WarehouseLocation
		fields = ['default', 'status']


	@property
	def qs(self):
		warehouse_location = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return warehouse_location.filter(user_id = user_id, deleted_at = None)
