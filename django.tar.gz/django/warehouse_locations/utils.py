from warehouse_locations.models import WarehouseLocation


class WarehouseLocationUtils:
	def get(self, location_id):
		try:
			location = WarehouseLocation.objects.get(pk = location_id)
		except WarehouseLocation.DoesNotExist:
			return False
		return location


	def create_default_location(self, user_id, **kwargs):
		kwargs['default'] = 1
		kwargs['name'] = 'Warehouse'
		return self.create_location(user_id, **kwargs)


	def get_fba_location(self, user_id, **kwargs):
		get_all = kwargs.pop('get_all', False)
		query_param = {
			**kwargs,
			'user_id': user_id,
			'deleted_at': None,
			'warehouse_type': WarehouseLocation.WAREHOUSE_TYPE_FBA,
		}
		if get_all:
			return WarehouseLocation.objects.filter(**query_param)
		else:
			return WarehouseLocation.objects.filter(**query_param).first()


	def get_or_create_fba_location(self, user_id, **kwargs):
		kwargs['name'] = 'FBA - Amazon Warehouse'
		kwargs['default'] = 1
		kwargs['warehouse_type'] = WarehouseLocation.WAREHOUSE_TYPE_FBA
		fba_location = self.get_fba_location(user_id, channel_id = kwargs.get('channel_id'))
		if fba_location:
			if fba_location.deleted_at is not None:
				fba_location.deleted_at = None
				fba_location.save()
			return fba_location
		else:
			return self.create_location(user_id, **kwargs)


	def create_location(self, user_id, **kwargs):
		location_data = {
			'user_id': user_id,
		}
		for key, value in kwargs.items():
			if key in [field.name for field in WarehouseLocation._meta.get_fields()]:
				location_data[key] = value
		try:
			location = WarehouseLocation.objects.create(**location_data)
		except Exception:
			location = None
		return location


	def get_location_by_user(self, user_id):
		try:
			location = WarehouseLocation.objects.all().filter(user_id = user_id, deleted_at = None)
		except WarehouseLocation.DoesNotExist:
			return False
		return location


	def get_location_default(self, user_id):
		try:
			location = WarehouseLocation.objects.all().filter(user_id = user_id, default = 1, deleted_at = None).first()
		except WarehouseLocation.DoesNotExist:
			location = WarehouseLocation.objects.all().filter(user_id = user_id, deleted_at = None).order_by('-id').first()
		except WarehouseLocation.DoesNotExist:
			return False
		return location
