from rest_framework import serializers

from .models import WarehouseLocation


class WarehouseLocationSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)
	name = serializers.CharField(required = True, allow_null = False)


	def get_fields(self, *args, **kwargs):
		fields = super(WarehouseLocationSerializer, self).get_fields(*args, **kwargs)
		request = self.context.get('request', None)
		if request and getattr(request, 'method', None) != "POST":
			fields['name'].required = False
		return fields


	class Meta:
		model = WarehouseLocation
		fields = ["id", "user_id", "name", "sender_name", "company_name", "email", "phone", "address", "address_2", "city", "state", "postcode", "country", "status", "default", "warehouse_type", "created_at", "updated_at"]
