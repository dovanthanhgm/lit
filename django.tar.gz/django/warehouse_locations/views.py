# Create your views here.
from django.http import HttpResponseNotFound, HttpResponseForbidden, JsonResponse, HttpResponse
from django.forms.models import model_to_dict
from rest_framework import generics
from rest_framework.views import APIView

from accounts.utils import AccountUtils
from channels.models import Channel
from libs.utils import to_int, json_decode, json_encode
from libs.models.collections.state import State
from core.responses import ResponseObject, ErrorResponse
from warehouse_locations.filters import WarehouseLocationFilter
from warehouse_locations.models import WarehouseLocation
from warehouse_locations.serializers import WarehouseLocationSerializer
from warehouse_locations.utils import WarehouseLocationUtils
from products.utils import ProductUtils


class WarehouseLocationView(generics.ListCreateAPIView):
	queryset = WarehouseLocation.objects.all()
	serializer_class = WarehouseLocationSerializer
	filterset_class = WarehouseLocationFilter


	def perform_create(self, serializer):
		user_id = AccountUtils().get_user_id(self.request)
		serializer.save(user_id = user_id)


	def list(self, request, *args, **kwargs):
		queryset = self.filter_queryset(self.get_queryset())
		if not queryset.exists() and to_int(request.GET.get('default')) == WarehouseLocation.DEFAULT:
			user_id = AccountUtils().get_user_id(self.request)
			WarehouseLocationUtils().create_default_location(user_id = user_id)
		return super().list(request, *args, **kwargs)


class WarehouseLocationDetailsView(generics.RetrieveUpdateDestroyAPIView):
	queryset = WarehouseLocation.objects.all()
	serializer_class = WarehouseLocationSerializer
	filterset_class = WarehouseLocationFilter


	def delete(self, request, *args, **kwargs):
		location_id = kwargs['pk']
		warehouse_location = WarehouseLocationUtils().get(location_id)
		if not warehouse_location:
			return HttpResponseNotFound()
		if to_int(warehouse_location.default) == WarehouseLocation.DEFAULT:
			return HttpResponseForbidden()
		state_model = ProductUtils().get_model_state(request, *args, **kwargs)
		state_model.update_many({}, {"$pull": {'channel.config.setting.inventory.active': kwargs['pk']}}, {"multi": True})
		state_model.update_many({}, {"$pull": {'channel.config.setting.inventory.disable': kwargs['pk']}}, {"multi": True})
		return super().delete(request, *args, **kwargs)
