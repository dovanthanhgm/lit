from django.urls import path

from warehouse_locations.views import WarehouseLocationView, WarehouseLocationDetailsView

urlpatterns = [
	path('', WarehouseLocationView.as_view(), name = 'warehouse_location'),
	path('/<int:pk>', WarehouseLocationDetailsView.as_view(), name = 'warehouse_location.details'),
]
