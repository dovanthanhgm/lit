from django.apps import AppConfig


class WarehouseLocationsConfig(AppConfig):
	name = 'warehouse_locations'
	verbose_name = 'Warehouse Locations'


	def ready(self):
		from warehouse_locations.signals import create_warehouse_location
