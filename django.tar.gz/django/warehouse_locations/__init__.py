default_app_config = 'warehouse_locations.apps.WarehouseLocationsConfig'
