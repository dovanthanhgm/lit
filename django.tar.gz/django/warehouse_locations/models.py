from django.db import models
from django.utils import timezone

from accounts.models import UserAccount
from channels.models import Channel


# Create your models here.


class WarehouseLocation(models.Model):
	DEFAULT = 1
	NORMAL = 2
	DEFAULT_CHOICES = (
		(DEFAULT, 'Default'),
		(NORMAL, 'Normal')
	)
	WAREHOUSE_TYPE_DEFAULT = 'default'
	WAREHOUSE_TYPE_FBA = 'fba'
	WAREHOUSE_TYPE_CHOICES = (
		(WAREHOUSE_TYPE_DEFAULT, 'Default'),
		(WAREHOUSE_TYPE_FBA, 'FBA')
	)
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE)
	name = models.CharField(null = False, blank = False, max_length = 255)
	sender_name = models.CharField(null = True, blank = True, max_length = 255)
	company_name = models.CharField(null = True, blank = True, max_length = 255)
	email = models.CharField(null = True, blank = True, max_length = 255)
	phone = models.CharField(null = True, blank = True, max_length = 255)
	address = models.CharField(null = True, blank = True, max_length = 255)
	address_2 = models.CharField(null = True, blank = True, max_length = 255)
	city = models.CharField(null = True, blank = True, max_length = 25)
	state = models.CharField(null = True, blank = True, max_length = 25)
	postcode = models.IntegerField(null = True, blank = True)
	country = models.CharField(max_length = 25, null = True, blank = True)
	status = models.CharField(max_length = 100, blank = False, default = "active")
	default = models.IntegerField(default = NORMAL, choices = DEFAULT_CHOICES)
	warehouse_type = models.CharField(default = WAREHOUSE_TYPE_DEFAULT, choices = WAREHOUSE_TYPE_CHOICES, max_length = 25)
	channel_id = models.IntegerField(null = True, blank = True, default = None)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	deleted_at = models.DateTimeField(null = True, blank = True)


	class Meta:
		db_table = "warehouse_locations"
		ordering = ['id']


	def delete(self, using=None, keep_parents=False):
		self.deleted_at = timezone.now()
		self.save()


	def undelete(self):
		self.deleted_at = None
		self.save()


	def force_delete(self):
		super(WarehouseLocation, self).delete()
