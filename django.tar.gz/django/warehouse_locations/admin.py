from django.contrib import admin
from django.db.models import Q

from core.myadmin.admin import CoreAdmin, InputFilter
from warehouse_locations.models import WarehouseLocation


class UserFilter(InputFilter):
	parameter_name = 'user'
	title = 'User'


	def queryset(self, request, queryset):
		if self.value() is not None:
			name = self.value()
			return queryset.filter(user__email__icontains = name)


class NameFilter(InputFilter):
	parameter_name = 'name'
	title = 'Name'


	def queryset(self, request, queryset):
		if self.value() is not None:
			name = self.value()
			return queryset.filter(name__icontains = name)


class CompanyFilter(InputFilter):
	parameter_name = 'company'
	title = 'Company & Address'


	def queryset(self, request, queryset):
		if self.value() is not None:
			company = self.value()
			return queryset.filter(
				Q(sender_name__icontains = company) |
				Q(company_name__icontains = company) |
				Q(email__icontains = company) |
				Q(phone__icontains = company) |
				Q(address__icontains = company) |
				Q(address_2__icontains = company) |
				Q(city__icontains = company) |
				Q(state__icontains = company) |
				Q(postcode__icontains = company)
			)


class WarehouseLocationAdmin(CoreAdmin):
	search_fields = ('user__email', 'name', 'sender_name', 'company_name', 'email', 'phone', 'address', 'address_2',
	                 'city', 'state', 'postcode')
	list_display = ('user', 'name', 'sender_name', 'company_name', 'email', 'phone', 'default', 'warehouse_type')
	list_filter = (UserFilter, NameFilter, CompanyFilter, 'default', 'warehouse_type')


	def delete_model(self, request, obj):
		"""
		Given a model instance delete it from the database.
		"""
		obj.force_delete()


	def delete_queryset(self, request, queryset):
		"""Given a queryset, delete it from the database."""
		for obj in queryset:
			obj.force_delete()


admin.site.register(WarehouseLocation, WarehouseLocationAdmin)
