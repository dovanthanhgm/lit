from django.db.models.signals import post_save
from django.dispatch import receiver

from libs.models.collections.state import State
from warehouse_locations.models import WarehouseLocation


@receiver(post_save, sender=WarehouseLocation)
def create_warehouse_location(sender, **kwargs):
	warehouse_location = kwargs['instance']
	if warehouse_location and kwargs.get('created'):
		model_state = State()
		model_state.set_user_id(user_id = warehouse_location.user_id)
		update_data = {
			'$push': {
				'channel.config.setting.inventory.active': warehouse_location.id
			}
		}
		model_state.update_many(where = {}, update_data = update_data, raw = True)
	return True
