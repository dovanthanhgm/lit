from rest_framework import generics
from announcements.models import Announcement
from announcements.serializers import AnnouncementSerializer
from django.http import JsonResponse
from libs.utils import to_int
from accounts.utils import AccountUtils


class AnnouncementList(generics.ListAPIView):

	serializer_class = AnnouncementSerializer
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user(user_id)
		page = request.GET.get('page')
		if not page:
			page = 1
		limit = 10
		query_set = Announcement.objects.all().order_by('-created_at')[(to_int(page) - 1) * limit:(to_int(page) - 1) * limit + limit]
		announcements = AnnouncementSerializer(query_set, many = True)
		data = {
			'data': announcements.data,
			'count': len(announcements.data)
		}
		return JsonResponse(data, safe = False)
