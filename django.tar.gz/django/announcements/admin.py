from django.contrib import admin

from core.myadmin.admin import CoreAdmin
from libs.utils import strip_html_from_description
from .models import Announcement

class AnnouncementAdmin(CoreAdmin):
	list_display = ['id', 'description']
	def description(self, obj):
		return strip_html_from_description(obj.content)
admin.site.register(Announcement, AnnouncementAdmin)
