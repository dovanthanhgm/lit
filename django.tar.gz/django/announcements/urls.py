from django.urls import path

from .views import AnnouncementList

urlpatterns = [
	path('', AnnouncementList.as_view()),
]
