from datetime import datetime

from libs.utils import to_int, log_traceback
from user_logs.models import UserLogs


class UserLogsUtils:
	def create_log(self, user_id, action):
		return
		try:
			date = datetime.now().strftime("%Y-%m-%d")
			try:
				logs = UserLogs.objects.get(created_at = date, user_id = user_id)
				setattr(logs, action, to_int(getattr(logs, action)) + 1)
				logs.save()
			except UserLogs.DoesNotExist:
				data = {
					"user_id": user_id,
					action: 1
				}
				logs = UserLogs.objects.create(**data)
		except Exception:
			log_traceback()