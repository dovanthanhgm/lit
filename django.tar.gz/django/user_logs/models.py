from django.db import models

# Create your models here.
from accounts.models import UserAccount


class UserLogs(models.Model):
	"""
	Class Transaction
	"""

	user = models.ForeignKey(
		UserAccount,
		on_delete = models.CASCADE,
		null = False
	)
	pull = models.IntegerField(null = False, default = 0)
	push = models.IntegerField(null = False, default = 0)
	update = models.IntegerField(null = False, default = 0)
	delete = models.IntegerField(null = False, default = 0)
	login = models.IntegerField(null = False, default = 0)
	bulk_edit = models.IntegerField(null = False, default = 0)
	scheduler_refresh = models.IntegerField(null = False, default = 0)
	scheduler_inventory = models.IntegerField(null = False, default = 0)
	scheduler_order = models.IntegerField(null = False, default = 0)
	description = models.TextField(blank = True, default = '')
	created_at = models.DateField(auto_now_add = True)


	class Meta:
		db_table = 'user_logs'