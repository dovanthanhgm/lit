from django.apps import AppConfig


class UserLogsConfig(AppConfig):
    name = 'user_logs'
