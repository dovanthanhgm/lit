from django.contrib import admin

# Register your models here.
from core.myadmin.admin import CoreAdmin, UserFilter
from user_logs.models import UserLogs


class UserlogsAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'pull', 'push', 'update', 'delete', 'login', 'created_at']
	list_filter = [UserFilter, 'created_at']


admin.site.register(UserLogs, UserlogsAdmin)
