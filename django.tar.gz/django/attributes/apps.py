from django.apps import AppConfig


class AttributesConfig(AppConfig):
    name = 'attributes'
