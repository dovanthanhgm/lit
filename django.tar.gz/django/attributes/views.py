#!/usr/bin/python
# -*- coding: utf-8 -*-
from django.db import IntegrityError
from django.http import HttpResponseNotFound, JsonResponse, HttpResponse
from django.utils.decorators import method_decorator
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, serializers, status

from accounts.utils import AccountUtils
from attributes.filters import AttributeFilter
from attributes.serializers import AttributeSerializer, PostProductAttributeSerializer, PutProductAttributeSerializer
from attributes.utils import AttributeUtils
from channels.utils import ChannelUtils
from core.responses import ErrorResponse, ResponseObject
from libs.models.collections.attributes import Attributes
from libs.utils import html_unquote, product_lower_name
from products.utils import ProductUtils


# class AttributeListApiView(generics.ListCreateAPIView):
# 	"""
# 	List all activities, or create a new activity.
# 	"""
#
# 	queryset = Attributes.objects.all().order_by('-position')
# 	serializer_class = AttributeSerializer
# 	filterset_class = AttributeFilter
#
#
# 	def perform_create(self, serializer):
# 		user_id = AccountUtils().get_user_id(self.request)
# 		try:
# 			serializer.save(user_id = user_id)
# 		except IntegrityError as e:
# 			raise serializers.ValidationError({'name': 'Duplicate attribute name'}, code = 200)
# 		except Exception as e:
# 			raise serializers.ValidationError("data invalid", code = 200)
#
#
# 	def put(self, request, format = None):
# 		objects_att = list(request.data)
# 		# objects is a list of OrderedDicts
# 		try:
# 			for o in objects_att:
# 				try:
# 					instance = Attributes.objects.get(
# 						**{self.lookup_field: o.get(self.lookup_field)}
# 					)
# 					for key, value in o.items():
# 						setattr(instance, key, value)
# 				except Attributes.DoesNotExist:
# 					instance = Attributes(**o)
# 				instance.save()
# 			return HttpResponse(status = status.HTTP_204_NO_CONTENT)
# 		except Exception as e:
# 			return JsonResponse({"detail": str(e)}, status = status.HTTP_400_BAD_REQUEST)
#
#
# class AttributeDetailsApi(generics.RetrieveUpdateDestroyAPIView):
# 	queryset = Attributes.objects.all()
# 	serializer_class = AttributeSerializer
# 	filterset_class = AttributeFilter
#
#
# 	def perform_update(self, serializer):
# 		user_id = AccountUtils().get_user_id(self.request)
# 		try:
# 			serializer.save(user_id = user_id)
# 		except IntegrityError as e:
# 			raise serializers.ValidationError({'name': 'Duplicate attribute name'}, code = 200)
# 		except Exception as e:
# 			raise serializers.ValidationError("data invalid", code = 200)
#
#
# @method_decorator(name = 'post', decorator = swagger_auto_schema(
# 	request_body = PostProductAttributeSerializer,
# 	responses = {
# 		status.HTTP_200_OK: PostProductAttributeSerializer,
# 	}
# ))
# @method_decorator(name = 'put', decorator = swagger_auto_schema(
# 	request_body = PutProductAttributeSerializer,
# 	responses = {
# 		status.HTTP_200_OK: PostProductAttributeSerializer,
# 	}
# ))
# class ProductAttributes(generics.CreateAPIView):
# 	def post(self, request, *args, **kwargs):
# 		user_id = AccountUtils().get_user_id(request)
# 		data = PostProductAttributeSerializer(data = request.data)
# 		if not data.is_valid():
# 			return JsonResponse(ErrorResponse(errors = 'data invalid').to_dict(), status = 400)
# 		attribute_data = dict(data.data)
# 		product_id = kwargs['product_id']
# 		model_product = ProductUtils().get_model_catalog(user_id = user_id)
# 		product = model_product.get(product_id)
# 		if not product:
# 			return HttpResponseNotFound()
# 		attributes = product['attributes']
# 		if not attributes:
# 			attributes = list()
# 		for attribute in attributes:
# 			if attribute['attribute_name'] == attribute_data['name']:
# 				return JsonResponse(ErrorResponse(errors = {"name": "attribute name exist"}).to_dict(), status = 400)
# 		attribute = AttributeUtils().filter_by_name(user_id, attribute_data['name']).first()
# 		if not attribute:
# 			attribute = Attributes.objects.create(user_id = user_id, name = attribute_data['name'])
# 		attribute_construct = {
# 			'id': attribute.id,
# 			'code': '',
# 			'attribute_mode': '',
# 			'attribute_type': attribute.type,
# 			'attribute_code': '',
# 			'attribute_name': attribute.name,
# 			'attribute_value_id': '',
# 			'attribute_value_code': '',
# 			'use_variant': False,
# 			'attribute_value_name': attribute_data['value'],
#
# 		}
# 		attributes.append(attribute_construct)
# 		import_response = model_product.update_field(product_id, 'attributes', attributes)
# 		if import_response:
# 			return JsonResponse(ResponseObject(data = attribute_construct).to_dict(), safe = False)
# 		else:
# 			return JsonResponse(ErrorResponse(errors = 'data invalid').to_dict(), status = 400)
#
#
# 	def put(self, request, *args, **kwargs):
# 		user_id = AccountUtils().get_user_id(request)
# 		data = PutProductAttributeSerializer(data = request.data)
# 		if not data.is_valid():
# 			return JsonResponse(ErrorResponse(errors = 'data invalid').to_dict(), status = 400)
# 		attribute_data = list(data.data)
# 		product_id = kwargs['product_id']
# 		model_product = ProductUtils().get_model_catalog(user_id = user_id)
# 		product = model_product.get(product_id)
# 		if not product:
# 			return HttpResponseNotFound()
# 		request_attribute = dict()
# 		for attribute in attribute_data:
# 			request_attribute[attribute['name']] = attribute['value']
# 		attributes = product['attributes']
# 		update_attributes = list()
# 		for attribute in attributes:
# 			if attribute['attribute_name'] in request_attribute:
# 				update_attributes.append(attribute)
# 		for attribute in update_attributes:
# 			attribute['attribute_value_name'] = request_attribute[attribute['attribute_name']]
# 		update_response = model_product.update_field(product_id, 'attributes', update_attributes)
# 		if update_response:
# 			return JsonResponse(ResponseObject(data = {'attributes': update_attributes}).to_dict())
# 		else:
# 			return JsonResponse(ErrorResponse(errors = 'data invalid').to_dict(), status = 400)
class CustomAttributesApiView(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		page = request.GET.get('pages', 1)
		limit = request.GET.get('limit', 20)
		search = html_unquote(request.GET.get('search')).strip()
		if not search:
			search = html_unquote(request.GET.get('name')).strip()
		search = html_unquote(search)
		model_category = Attributes()
		model_category.set_user_id(user_id)
		where = {}
		channel_id = kwargs.get('channel_id')
		if not channel_id:
			channel_default = ChannelUtils().get_default_channel(user_id)
			channel_id = channel_default.id

		if search:
			where_search = [
				model_category.create_where_condition('name', search, 'like'),
				model_category.create_where_condition('code', product_lower_name(search), 'like'),
			]
			where = model_category.create_where_condition(None, where_search, 'or')
		if channel_id:
			where.update(model_category.create_where_condition('channel_id', channel_id))
		categories = model_category.find_all(where)
		return JsonResponse({
			'data': categories,
			'count': model_category.count(where)
		})