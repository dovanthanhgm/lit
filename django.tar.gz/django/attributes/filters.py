from django_filters import FilterSet

from accounts.utils import AccountUtils
from attributes.models import Attributes


class AttributeFilter(FilterSet):
	class Meta:
		model = Attributes
		fields = []


	@property
	def qs(self):
		attribute = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return attribute.filter(user_id = user_id)