from rest_framework import serializers

from .models import Attributes


class AttributeSerializer(serializers.ModelSerializer):
	name = serializers.CharField(required = False)
	pk = serializers.IntegerField(read_only = True)
	created_at = serializers.DateTimeField(read_only = True)
	type = serializers.ChoiceField(choices = ('text', 'select'), required = False)
	user_id = serializers.IntegerField(read_only = True)
	position = serializers.IntegerField(required = False)


	# def get_fields(self, *args, **kwargs):
	# 	fields = super(NotificationSerializer, self).get_fields(*args, **kwargs)
	# 	request = self.context.get('request', None)
	# 	if request and getattr(request, 'method', None) != "POST":
	# 		fields['message'].required = False
	# 	return fields

	# def update(self, instance, validated_data):
	# 	instance.status = validated_data.get('status', 'read')
	# 	instance.save()
	# 	return instance

	class Meta:
		model = Attributes
		fields = ['pk', 'user_id', 'created_at', 'name', 'type', 'position']


class ProductCustomAttributeSerializer(serializers.Serializer):
	pk = serializers.IntegerField(read_only = True)
	name = serializers.CharField()
	value = serializers.CharField()
	class Mete:
		ref_name = 'Product Custom Attribute Serialzer'


class PostProductAttributeSerializer(ProductCustomAttributeSerializer):
	class Meta:
		ref_name = 'Post Product Attribute Serialzer'



class PutProductAttributeSerializer(serializers.ListSerializer):
	child = ProductCustomAttributeSerializer()
	class Meta:
		ref_name = 'Put Product Attribute Serialzer'
		list_serializer_class = ProductCustomAttributeSerializer