from attributes.models import Attributes


class AttributeUtils:
	def filter_by_name(self, user_id, name):
		try:
			attribute = Attributes.objects.filter(user_id = user_id, name = name)
		except Attributes.DoesNotExist:
			return False
		return attribute