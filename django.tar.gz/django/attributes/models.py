from django.db import models

# Create your models here.
from accounts.models import UserAccount


class Attributes(models.Model):
	name = models.CharField(max_length = 25, blank = False, null = False)
	# user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	user_id = models.IntegerField(null = True)
	created_at = models.DateTimeField(auto_now_add = True)
	type = models.CharField(max_length = 11, null = False, default = 'text')
	position = models.PositiveIntegerField(blank = True)

	class Meta:
		db_table = "custom_attributes"
		unique_together = (
			("name", "user_id"),
		)
		ordering = ['id']

	def save(self, *args, **kwargs):
		if self.position is None:
			max_position = Attributes.objects.filter(user = self.user).order_by('-position').first()
			if not max_position:
				max_position = 0
			else:
				max_position = max_position.position + 1
			self.position = max_position
		return super().save(*args, **kwargs)
