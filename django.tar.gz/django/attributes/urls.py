from django.urls import path, include

from attributes.views import CustomAttributesApiView

urlpatterns = [
	path('/attributes', include([
		path('', CustomAttributesApiView.as_view()),
		# path('/<int:pk>', AttributeDetailsApi.as_view()),
	])),
	# path('/products/<str:product_id>/attributes', ProductAttributes.as_view())
]
