import base64
import time

import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from sp_api.api import Catalog, Feeds, Reports, Orders
from sp_api.base import ApiResponse, sp_endpoint, fill_query_params

from libs.utils import obj_to_list


class AmazonApiResponse(ApiResponse):
	def __init__(self, payload = None, errors = None, pagination = None, headers = None, nextToken = None, **kwargs):
		super().__init__(payload, errors, pagination, headers, nextToken, **kwargs)
		self.status_code = kwargs.get('status_code')


class AmazonClientMixin(object):
	@staticmethod
	def _check_response(res) -> ApiResponse:
		return AmazonApiResponse(**res.json(), headers = res.headers, status_code = res.status_code)


	def _request(self, path: str, *, data: dict = None, params: dict = None, headers = None,
	             add_marketplace = True) -> ApiResponse:
		response = super()._request(path= path, data = data, params = params, headers = headers, add_marketplace = add_marketplace)
		retry = 0
		while response.status_code == 429 and retry <= 5:
			retry += 1
			time.sleep(5)
			response = super()._request(path = path, data = data, params = params, headers = headers, add_marketplace = add_marketplace)
		return response

class AmazonCatalog(AmazonClientMixin, Catalog):
	@sp_endpoint('/catalog/2020-12-01/items/{}')
	def get_item_variant(self, asin, **kwargs) -> ApiResponse:
		"""
		get_item_variant(self, asin: str, **kwargs) -> ApiResponse
		Returns a specified item and its attributes.

		**Usage Plan:**

		======================================  ==============
		Rate (requests per second)               Burst
		======================================  ==============
		1                                       1
		======================================  ==============

		For more information, see "Usage Plans and Rate Limits" in the Selling Partner API documentation.

		Args:
			asin: str
			key MarketplaceIds: str
			**kwargs:

		Returns:
			GetCatalogItemResponse:
		"""
		return self._request(fill_query_params(kwargs.pop('path'), asin), params = kwargs)


class AmazonFeed(AmazonClientMixin, Feeds):
	@sp_endpoint('/feeds/2020-09-04/feeds/{}', method = 'DELETE')
	def cancel_feed(self, feed_id: str, **kwargs) -> ApiResponse:
		return self._request(fill_query_params(kwargs.pop('path'), feed_id))


	@sp_endpoint('/feeds/2020-09-04/feeds', method = 'GET')
	def get_feeds(self, feed_types = None, marketplace_ids = None, **kwargs) -> ApiResponse:
		params = {

		}
		if feed_types:
			feed_types = obj_to_list(feed_types)
			params['feedTypes'] = feed_types
		if marketplace_ids:
			params['marketplaceIds'] = obj_to_list(marketplace_ids)
		if kwargs:
			params.update(kwargs)
		return self._request(kwargs.get('path'), params = params)


	@sp_endpoint('/feeds/2020-09-04/documents', method = 'POST')
	def create_feed_document(self, content, content_type = 'text/tsv', **kwargs) -> ApiResponse:
		"""
		create_feed_document(self, content: Content File, content_type='text/tsv', **kwargs) -> ApiResponse
		Creates a feed document for the feed type that you specify.
		This method also encrypts and uploads the file you specify.

		**Usage Plan:**

		======================================  ==============
		Rate (requests per second)               Burst
		======================================  ==============
		0.0083                                  15
		======================================  ==============

		For more information, see "Usage Plans and Rate Limits" in the Selling Partner API documentation.

		Args:
			content: str
			content_type: str
			**kwargs:

		Returns:
			CreateFeedDocumentResponse:

		"""
		data = {
			'contentType': kwargs.get('contentType', content_type)
		}
		response = self._request(kwargs.get('path'), data = {**data, **kwargs})
		upload = requests.put(
			response.payload.get('url'),
			data = self.encrypt_aes(content,
			                        response.payload.get('encryptionDetails').get('key'),
			                        response.payload.get('encryptionDetails').get('initializationVector')
			                        ),
			headers = {'Content-Type': content_type}
		)
		if 200 <= upload.status_code < 300:
			return response
		from sp_api.base.exceptions import SellingApiException
		raise SellingApiException(upload.headers)


	def encrypt_aes(self, text, key, iv):
		key = base64.b64decode(key)
		iv = base64.b64decode(iv)
		aes = AES.new(key, AES.MODE_CBC, iv)
		return aes.encrypt(pad(bytes(text, encoding = 'iso-8859-1'), 16))


class AmazonReport(AmazonClientMixin, Reports):
	@sp_endpoint('/reports/2020-09-04/reports/{}', method = 'DELETE')
	def cancel_report(self, report_id: str, **kwargs) -> ApiResponse:
		return self._request(fill_query_params(kwargs.pop('path'), report_id))


	def decrypt_report_document(self, url, initialization_vector, key, encryption_standard, payload):
		encoding = ['utf-8', 'windows-1252', 'iso-8859-1']
		decrypt_data = super(AmazonReport, self).decrypt_report_document(url, initialization_vector, key, encryption_standard, payload)
		for row in encoding:
			try:
				decrypt_data_encode = decrypt_data.encode('iso-8859-1').decode(row)
				return decrypt_data_encode
			except Exception:
				continue
		return decrypt_data


class AmazonOrder(AmazonClientMixin, Orders):
	@sp_endpoint('/orders/v0/orders', method = 'GET')
	def get_orders(self, created_after = None, marketplace_ids = None, **kwargs) -> ApiResponse:
		params = {}
		if created_after:
			params['CreatedAfter'] = created_after
		if marketplace_ids:
			params['MarketplaceIds'] = obj_to_list(marketplace_ids)
		if kwargs:
			params.update(kwargs)
		return self._request(kwargs.get('path'), params = params)
