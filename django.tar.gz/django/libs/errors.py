class Errors:
	URL_INVALID = 2601
	CHANNEL_NOT_CREATE = 2501
	CHANNEL_EXIST = 2502
	STATE_NOT_CREATE = 2401
	ACTION_INVALID = 2301
	EXCEPTION = 2201
	PROCESS_NOT_CREATE = 2101

	SHOPIFY_SCOPE = 2701  # Thiếu scope
	SHOPIFY_VARIANT_LIMIT = 2702  # full variant
	SHOPIFY_API_INVALID = 2703  # full variant
	SHOPIFY_GET_PRODUCT_FAIL = 2704
	SHOPIFY_PRODUCT_NO_VARIANT = 2705


	def __init__(self):
		self.error_msg = self.error_message()


	def error_message(self):
		return {
			self.URL_INVALID: 'Url invalid. Please enter the correct url',
			self.CHANNEL_NOT_CREATE: 'CHANNEL_NOT_CREATE',
			self.CHANNEL_EXIST: 'CHANNEL_EXIST',
			self.STATE_NOT_CREATE: 'state_NOT_CREATE',
			self.ACTION_INVALID: 'ACTION_INVALID',
			self.EXCEPTION: 'EXCEPTION',
			self.PROCESS_NOT_CREATE: 'PROCESS_NOT_CREATE',
			self.SHOPIFY_SCOPE: 'SHOPIFY_SCOPE',
			self.SHOPIFY_VARIANT_LIMIT: 'SHOPIFY_VARIANT_LIMIT',
			self.SHOPIFY_API_INVALID: 'SHOPIFY_API_INVALID',
			self.SHOPIFY_GET_PRODUCT_FAIL: 'SHOPIFY_GET_PRODUCT_FAIL',
			self.SHOPIFY_PRODUCT_NO_VARIANT: 'SHOPIFY_PRODUCT_NO_VARIANT',
		}


	def get_msg_error(self, error_code):
		if not error_code:
			return ''
		return self.error_msg.get(int(error_code), '')
