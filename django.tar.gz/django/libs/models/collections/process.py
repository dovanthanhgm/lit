from libs.models.collection import ModelCollection


class CollectionProcess(ModelCollection):
	COLLECTION_NAME = 'processes'
