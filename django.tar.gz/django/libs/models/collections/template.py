from libs.models.collection import ModelCollection


class Template(ModelCollection):
	COLLECTION_NAME = 'template'


	def __init__(self, **kwargs):
		super().__init__(**kwargs)


	def get_collection_name(self):
		return self.COLLECTION_NAME


class TemplateRecipe(ModelCollection):
	COLLECTION_NAME = 'template_recipe'


	def __init__(self, **kwargs):
		super().__init__(**kwargs)


	def get_collection_name(self):
		return self.COLLECTION_NAME
