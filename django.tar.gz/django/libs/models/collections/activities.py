from libs.models.collection import ModelCollection


class Activities(ModelCollection):
	COLLECTION_NAME = 'activities'
