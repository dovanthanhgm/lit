from libs.models.collection import ModelCollection


class CollectionOrder(ModelCollection):
	COLLECTION_NAME = 'orders'


	def __init__(self, **kwargs):
		super().__init__(**kwargs)


	def get_collection_name(self):
		return self.COLLECTION_NAME
