from libs.models.collection import ModelCollection


class Shipment(ModelCollection):
	COLLECTION_NAME = 'shipments'
