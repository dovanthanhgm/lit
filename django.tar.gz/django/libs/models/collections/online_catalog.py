from libs.db.online_mongo import OnlineMongo
from libs.models.collections.catalog import Catalog
from libs.models.collections.order import CollectionOrder
from libs.models.collections.state import State
from libs.models.collections.template import Template


class OnlineCatalog(Catalog):
	def get_db(self):
		if self._db:
			return self._db
		if not globals().get('db_mongo'):
			global db_mongo
			db_mongo = OnlineMongo()
		self._db = globals()['db_mongo']
		return self._db

class OnlineOrder(CollectionOrder):
	def get_db(self):
		if self._db:
			return self._db
		if not globals().get('db_mongo'):
			global db_mongo
			db_mongo = OnlineMongo()
		self._db = globals()['db_mongo']
		return self._db
class OnlineTemplate(Template):
	def get_db(self):
		if self._db:
			return self._db
		if not globals().get('db_mongo'):
			global db_mongo
			db_mongo = OnlineMongo()
		self._db = globals()['db_mongo']
		return self._db
class OnlineState(State):
	def get_db(self):
		if self._db:
			return self._db
		if not globals().get('db_mongo'):
			global db_mongo
			db_mongo = OnlineMongo()
		self._db = globals()['db_mongo']
		return self._db