import json

from django.core import serializers
from django.core.serializers.json import DjangoJSONEncoder
from django.db import models
from django.db.models.query import QuerySet
from django.forms.models import model_to_dict

from libs.utils import json_decode, to_int


class JsonEncoder(DjangoJSONEncoder):

    def default(self, obj):
        if isinstance(obj, models.Model):
            return model_to_dict(obj)
        if isinstance(obj, QuerySet):
            obj = list(obj)
            for row in obj:
                row = model_to_dict(row)
                if row.get('user') and to_int(row['user']):
                    row['user_id'] = to_int(row['user'])
            return obj
        return super(JsonEncoder, self).default(obj)

def json_encode_model(data):
    return json.dumps(data, cls=JsonEncoder, indent=2, separators=(',', ': '))

def model_django_to_dict(data):
    def solve_data(row):
        if to_int(row.get('user')):
            row['user_id'] = to_int(row['user'])
        if to_int(row.get('channel')):
            row['channel_id'] = to_int(row['channel'])
        return row
    response = json_decode(json_encode_model(data))
    if isinstance(response, dict):
        response = solve_data(response)
    if isinstance(response, list):
        for row_response in response:
            row_response = solve_data(row_response)
    return response