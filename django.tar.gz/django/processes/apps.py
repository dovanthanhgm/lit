from django.apps import AppConfig


class ProcessConfig(AppConfig):
	name = "processes"
	def ready(self):
		import processes.signals