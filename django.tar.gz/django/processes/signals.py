from background_task.models import Task
from django.db.models.signals import pre_delete, post_save
from django.dispatch import receiver

from datasync.api.callback import CallbackApi
from libs.models.collections.state import State
from processes.models import Process

@receiver(pre_delete, sender=Process)
def process_pre_delete(sender, instance, **kwargs):
	try:
		Task.objects.filter(verbose_name = instance.id).delete()
		model_state = State()
		model_state.set_user_id(instance.user_id)
		model_state.delete(instance.state_id)
	except Exception as e:
		pass

@receiver(post_save, sender=Process)
def process_post_save(sender, instance: Process, **kwargs):
	try:
		channel = instance.channel
		if kwargs.get('created'):
			return
		data = {
			'channel_id': instance.channel_id,
			'user_id': instance.user_id,
			'state_id': instance.state_id,
			'type': instance.type,
			'process_id': instance.id,
		}
		process = CallbackApi(user_id = instance.user_id).post('processes', data)
	except Exception:
		pass