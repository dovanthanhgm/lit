from rest_framework import serializers

from .models import Process


class ProcessSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)
	channel_id = serializers.IntegerField(required = True, allow_null = False)


	def get_fields(self, *args, **kwargs):
		fields = super(ProcessSerializer, self).get_fields(*args, **kwargs)
		request = self.context.get('request', None)
		if request and getattr(request, 'method', None) != "POST":
			fields['channel_id'].required = False
			fields['status'].required = False
		return fields


	class Meta:
		model = Process
		fields = ["id", "user_id", "pid", "server_id", "state_id", "status", "created_at", "updated_at", "channel_id", "type", 'limit', 'config', 'feed_type']
