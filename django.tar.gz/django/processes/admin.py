from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from core.myadmin.admin import CoreAdmin, InputFilter
from datasync.api.sync import SyncApi
from libs.models.collections.state import State
from libs.utils import json_decode
from .models import *
from .utils import ProcessUtils


class UserFilter(InputFilter):
	parameter_name = 'user'
	title = ('User',)


	def queryset(self, request, queryset):
		if self.value() is not None:
			user = self.value()
			return queryset.filter(user__email = user)


class ChannelFilter(InputFilter):
	parameter_name = 'channel'
	title = ('Channel',)


	def queryset(self, request, queryset):
		if self.value() is not None:
			channel = self.value()
			return queryset.filter(channel__id = channel)


class ProcessFilter(InputFilter):
	parameter_name = 'process'
	title = 'Process'


	def queryset(self, request, queryset):
		if self.value() is not None:
			process = self.value()
			return queryset.filter(sync__id = process)


class ProcessAdmin(CoreAdmin):
	def __init__(self, model, admin_site):
		super().__init__(model, admin_site)


	search_fields = ['user__email', 'pid', 'channel__name', 'server__name', 'state_id', 'status', 'type', 'created_at', 'updated_at']
	list_filter = (UserFilter, ChannelFilter, 'status', 'type',)
	list_display = ['id', 'user_link', 'pid', 'channel_link', 'server', 'state_id', 'status', 'type', 'created_at', 'updated_at']
	ordering = ('-id',)
	list_per_page = 20
	change_form_template = "admin/channels/process/change_form.html"


	def user_link(self, obj):
		url = reverse("admin:accounts_useraccount_change", args = (obj.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.user.email}</a>")


	def channel_link(self, obj):
		url = reverse("admin:channels_channel_change", args = (obj.channel_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''><u>{obj.channel.name}</u></a>")


	def get_actions(self, request):
		actions = super(ProcessAdmin, self).get_actions(request)
		# actions.pop('delete_selected', None)
		return actions


	def get_readonly_fields(self, request, obj = None):
		if obj:
			return ['type']
		else:
			return []


	def change_view(self, request, object_id, form_url = '', extra_context = None):
		extra = extra_context or {}
		obj = Process.objects.get(pk = object_id)
		extra.update(ProcessUtils().extra_change_view(obj))
		extra['show_delete'] = False

		return super().change_view(request, object_id, form_url, extra_context = extra)


	def save_form(self, request, form, change):
		if request.POST.get('save_state'):
			state = request.POST.get('state')
			state = json_decode(state)
			if state and request.POST.get('state_id'):
				model_state = State()
				model_state.set_user_id(request.POST.get('user'))
				model_state.update(request.POST.get('state_id'), state)
		return super().save_form(request, form, change)


	def save_model(self, request, obj, form, change):
		return super().save_model(request, obj, form, change)


	def delete_model(self, request, obj):
		"""
		Given a model instance delete it from the database.
		"""
		pid = obj.pid
		end_point = f"/process/stop_pid/{pid}"
		stop = SyncApi(process_id = obj.id).post(end_point)
		super().delete_model(request, obj)


class ProcessHistoryAdmin(CoreAdmin):
	search_fields = ['user__email', 'action', 'created_at', 'updated_at']
	list_filter = (UserFilter, ProcessFilter, 'action', 'author_type', 'created_at', 'updated_at')
	list_display = ['user', 'action', 'sync_id', 'detail', 'created_at', 'updated_at', 'author_type']


admin.site.register(Process, ProcessAdmin)
admin.site.register(ProcessHistory, ProcessHistoryAdmin)
