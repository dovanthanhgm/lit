import datetime

from channels.models import Channel
from libs.models.collections.state import State
from libs.utils import to_int, json_encode, get_config_ini
from processes.models import Process, ProcessHistory


class ProcessUtils:
	TYPE_PRODUCT = 'product'
	TYPE_ORDER = 'order'
	TYPE_INVENTORY = 'inventory'
	TYPE_REFRESH = 'refresh'
	TYPE_CATEGORY = 'category'


	def get(self, process_id):
		try:
			process = Process.objects.get(pk = process_id)
			return process
		except:
			return None


	def filter(self, **kwargs):
		try:
			process = Process.objects.get(**kwargs)
			return process
		except:
			return None


	def get_process_by_type(self, channel_id, process_type = 'product'):
		try:
			process = Process.objects.all().select_related('channel').get(channel_id = channel_id, type = process_type)
		except Process.DoesNotExist:
			return False
		return process


	def convert_time(self, text):
		text1 = text.split(', ')
		text2 = text1[-1].split(':')
		unit = ['h', 'p', 's']
		if len(text1) > 1:
			result = [text1[0]]
		else:
			result = []
		for i in range(len(text2)):
			if int(text2[i]) > 0:
				result.append(str(text2[i]) + ' ' + unit[i])
		return ' '.join(result)


	def dict2obj(self, d):
		if isinstance(d, list):
			d = [self.dict2obj(x) for x in d]
		if not isinstance(d, dict):
			return d


		class C(object):
			pass


		o = C()
		for k in d:
			o.__dict__[k] = self.dict2obj(d[k])
		return o


	def extra_change_view(self, obj):
		process_list, state = self.res_change(obj)
		channels = Channel.objects.filter(pk = obj.channel_id).first()
		extra = dict()
		extra['channel'] = self.dict2obj({
			'api': channels.api,
			'type': channels.type,
			'url': channels.url,
			'state': json_encode(state)
		})
		extra['process_list'] = process_list
		extra['state'] = self.dict2obj(state)
		action = state['resume']['action'] if state['resume']['action'] else 'pull'
		extra['action'] = action
		extra['state_process'] = self.dict2obj(state[action])
		extra['process'] = obj
		extra['migration_ui_url'] = get_config_ini('cart', 'center_url')
		return extra


	def res_change(self, obj):
		model_state = State()
		model_state.set_user_id(obj.user.id)
		state = model_state.get(obj.state_id)
		action = state.get('resume', {}).get('action') if state.get('resume', {}).get('action') else 'pull'
		process = state[action]['process']
		process_list = []
		running_type = state[action]['resume']['type']
		entities = ['taxes', 'categories', 'products', 'orders']
		running_position = entities.index(running_type) if running_type else -1
		for index, name in enumerate(entities):
			if index < running_position:
				status = 'completed'
			elif index == running_position:
				status = 'running'
			else:
				status = 'prepare'
			if not state['config'][name]:
				status = 'not-choose'
			time_start = to_int(process[name]['time_start'])
			time_finish = to_int(process[name]['time_finish'])
			time = ProcessUtils().convert_time(str(datetime.timedelta(seconds = time_finish - time_start))) if time_finish - time_start > 0 else '0s'
			process_list.append({
				'name': name,
				'imported': process[name]['imported'],
				'error': process[name]['error'],
				'total': process[name].get('total_view') or process[name].get('total'),
				'limit': process[name]['limit'],
				'status': status,
				'time': f"Finish: {time}",
			})
		return ProcessUtils().dict2obj(process_list), state


	@staticmethod
	def save_process_history(**kwargs):
		return ProcessHistory.objects.create(**kwargs)
