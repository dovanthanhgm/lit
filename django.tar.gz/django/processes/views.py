from django.http import JsonResponse
from rest_framework import generics

from accounts.utils import AccountUtils
from core.permission import IsPrivate, IsPrivateWithoutUser
from datasync.api.center import CartCenterApi
from products.utils import ProductUtils
from channels.models import Channel
from .filters import ProcessFilter
from .models import Process
from .serializers import ProcessSerializer
from .utils import ProcessUtils


class ProcessList(generics.ListCreateAPIView):
	"""
	List all processes, or create a new process.
	"""
	# authentication_classes = []
	permission_classes = [IsPrivateWithoutUser]

	queryset = Process.objects.all()
	serializer_class = ProcessSerializer
	filterset_class = ProcessFilter


	def perform_create(self, serializer):
		user_id = AccountUtils().get_user_id(self.request)
		serializer.save(user_id = user_id)


class ProcessDetail(generics.RetrieveUpdateDestroyAPIView):
	"""
	Retrieve, update or delete a process instance.
	"""
	authentication_classes = []
	permission_classes = [IsPrivateWithoutUser]

	queryset = Process.objects.all()
	serializer_class = ProcessSerializer


class StateAPIView(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		obj = Process.objects.filter(pk = kwargs['process_id']).first()
		return JsonResponse(ProcessUtils().res_change(obj), safe = False)


class GetCurrentProcess(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		processes = Process.objects.filter(user_id = user_id, type = 'product')
		if not processes:
			return JsonResponse(data = [], safe = False)
		state_ids = [row.state_id for row in processes]
		model_state = ProductUtils().get_model_state(request, *args, **kwargs)
		where = model_state.create_where_condition('pull.resume.process', 'pulling')
		where.update(model_state.create_where_condition('_id', state_ids, 'in'))
		states = model_state.find_all(where)
		data = []
		for state in states:
			process_name = state.get('channel').get('name') + " Import"

			result = state.get('pull').get('process').get('products')
			result.update({
				"process_name": process_name,
				"channel_name": state.get('channel').get('name'),
				"channel_type": state.get('channel').get('channel_type')
			})
			data.append(result)

		return JsonResponse(data = data, safe = False)
