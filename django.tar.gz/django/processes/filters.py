from django_filters import FilterSet

from accounts.utils import AccountUtils
from .models import Channel, Process


class ProcessFilter(FilterSet):
	class Meta:
		model = Process
		fields = ['channel_id', 'status', 'type']