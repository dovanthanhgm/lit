from django.db import models

from accounts.models import UserAccount
from channels.models import Channel
from servers.models import Server


# Create your models here.


class Process(models.Model):
	PUSHING = 'pushing'
	PULLING = 'pulling'
	STOPPED = 'stopped'
	COMPLETED = 'completed'
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE)
	pid = models.IntegerField(null = True, blank = True)
	limit = models.IntegerField(null = True, blank = True)
	server = models.ForeignKey(Server, on_delete = models.SET_NULL, blank = True, null = True)
	state_id = models.CharField(max_length = 25, null = True, blank = True)
	status = models.CharField(max_length = 25, choices = (('stopped', 'stopped'), ('completed', 'completed'), ('pulling', 'pulling'), ('pushing', 'pushing'), ('new', 'new')), default = 'new')
	type = models.CharField(max_length = 100, blank = False, default = "product")
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	channel = models.ForeignKey(Channel, on_delete = models.CASCADE)
	config = models.TextField(null = True, blank = True)
	feed_type = models.CharField(max_length = 25, choices = (('add', 'Add'), ('update', 'Update'), ('delete', 'Delete')), null = True, blank = True)
	default = models.BooleanField(null = False, default = True)
	class Meta:
		db_table = "channel_process"
		ordering = ['id']
		app_label = 'channels'
		verbose_name = 'Process'
		verbose_name_plural = 'Processes'
		permissions = (("manager_process", "Manager process"),)


	def __str__(self):
		return f'Process {self.id}'


class ProcessHistory(models.Model):
	ACTION_CHOICES = (
		('stop', 'Stop'),
		('start', 'Start'),
		('clone', 'Clone'),
		('pull', 'Pull')
	)
	author_type = models.CharField(max_length = 25, default = 'admin')
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, verbose_name = 'Author')
	action = models.CharField(max_length = 25, choices = ACTION_CHOICES)
	sync = models.ForeignKey(Process, on_delete = models.CASCADE)
	detail = models.TextField(blank = True)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)


	class Meta:
		db_table = 'process_history'
		ordering = ['-created_at']
		app_label = 'channels'
		verbose_name = 'Process history'
		verbose_name_plural = 'Process histories'


	def __str__(self):
		return f'{self.sync}: {self.action}'
