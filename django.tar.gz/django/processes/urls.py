from django.urls import path, re_path
from .views import ProcessDetail, ProcessList, StateAPIView, GetCurrentProcess

urlpatterns = [
	path("", ProcessList.as_view()),
	path("/<int:pk>", ProcessDetail.as_view(), name = "detail_process"),
	path("/state/<int:process_id>", StateAPIView.as_view(), name = "abc"),
	path("/current-process", GetCurrentProcess.as_view(), name = "current-process")
]
