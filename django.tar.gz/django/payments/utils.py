import importlib

from django.http import HttpResponseForbidden, Http404

from libs.utils import get_config_ini, to_decimal, to_str
from payments.method.paypal import PaymentPaypal
from payments.models import PaymentInformation, PaymentHistory
from subscription.models import TokenPaymentMethod
from subscription.utils import SubscriptionUtils


class PaymentUtils:
	def get_payment_information(self, token):
		try:
			payment = PaymentInformation.objects.get(token = token)
		except PaymentInformation.DoesNotExist:
			return False
		return payment


	def process_payment(self, payment_information):
		method = self.get_payment_method(payment_information)
		if method.get_payment_method_name() == 'paypal':
			raise Http404()
		return method.process_payment(payment_information)


	def payment_done(self, request, *args, **kwargs):
		token = kwargs['token']
		payment_information = self.get_payment_information(token)
		if not payment_information:
			return HttpResponseForbidden()
		method = self.get_payment_method(payment_information)

		return method.payment_done(payment_information, request)


	def get_payment_method_default(self):
		return get_config_ini('server', 'payment_method_default', 'paypal')


	def get_payment_method_name(self, request, old_plan = False):
		token = to_str(request.META.get('HTTP_AUTHORIZATION')).split()[-1]
		if not token:
			method = self.get_payment_method_default()
		else:
			try:
				payment_method = TokenPaymentMethod.objects.get(access_token = token)
				method = payment_method.payment_method
			except TokenPaymentMethod.DoesNotExist:
				method = self.get_payment_method_default()
		if method != self.get_payment_method_default():
			return method
		from accounts.utils import AccountUtils
		user = AccountUtils().get_user_by_request(request)
		if user.market_app in ['shopify', 'wix']:
			return user.market_app
		return method

	def get_payment_method(self, payment_information: PaymentInformation):
		method = payment_information.method
		if not method:
			method = self.get_payment_method_default()
		if method not in ['paypal']:
			try:
				module_class = importlib.import_module("merchant.{}.utils".format(method))
				model_class = getattr(module_class, 'Merchant{}Utils'.format(method.capitalize()))
				payment_class = model_class().get_payment_class(payment_information)
				if payment_class:
					return payment_class
				return PaymentPaypal()

			except:
				return PaymentPaypal()

		else:
			return PaymentPaypal()



