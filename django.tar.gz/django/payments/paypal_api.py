import uuid
from decimal import Decimal

import requests

from accounts.models import UserAccount
from datasync_django import settings
from libs.utils import get_config_ini, to_str, log_traceback, json_decode, to_decimal, log_api_error
from requests.auth import HTTPBasicAuth

from payments.models import PaymentInformation, PaymentHistory
from settings.models import ServerSetting
from settings.utils import SettingUtils


class PaypalApi:
	def __init__(self):
		self._last_status_code = 0
		self._product_id = None


	def get_last_status_code(self):
		return self._last_status_code


	def is_test(self):
		return settings.PAYPAL_SUBSCRIPTION_MODE == 'test'


	def get_client_id(self):
		return settings.PAYPAL_CLIENT_ID


	def get_client_secret(self):
		return settings.PAYPAL_CLIENT_SECRET


	def get_merchant_id(self):
		return settings.PAYPAL_MERCHANT_ID


	def get_paypal_url(self, api_version):
		url = "https://api-m.sandbox.paypal.com/v" if self.is_test() else 'https://api-m.paypal.com/v'
		return f"{url}{api_version}"


	def create_stc_api(self, user: UserAccount, tracking_id):
		stc_data = {
			'tracking_id': tracking_id,
			'additional_data': [
				{"key": "sender_account_id", "value": user.id},
				{"key": "sender_first_name", "value": user.name},
				{"key": "sender_last_name", "value": user.name},
				{"key": "sender_email", "value": user.email},
				{"key": "sender_phone", "value": user.phone if user.phone else ''},
				{"key": "sender_country_code", "value": user.country if user.country else ''},
				{"key": "sender_create_date", "value": user.created_at.strftime("%Y-%m-%d")},
			]
		}
		stc_response = self.api(f'risk/transaction-contexts/{self.get_merchant_id()}/{tracking_id}', data = stc_data, tracking_id = tracking_id, method = 'put', api_version = 1)
		return stc_response


	def capture_order(self, user, payment):
		order_id = payment.paypal_order_id
		tracking_id = payment.paypal_tracking_id
		request_id = to_str(uuid.uuid4())
		order = self.api(f"checkout/orders/{order_id}/capture", tracking_id = tracking_id, request_id = request_id)
		try:
			payment_status = order['purchase_units'][0]['payments']['captures'][0]['status']
		except Exception:
			payment_status = 'failure'
		if not payment_status:
			payment_status = 'failure'

		if payment_status == 'COMPLETED':
			payment_status = 'completed'

		payment_history_data = {
			'method': 'paypal',
			'user_id': payment.user_id,
			'amount': payment.amount,
			'subtotal': payment.subtotal,
			'discount': payment.discount,
			'discount_code': payment.discount_code,
			'total': payment.total,
			'balance': payment.balance,
			'new_balance': user.balance,
			'status': payment_status,
			'token': payment.token,
			'name': payment.name,
			'type': payment.type,
			'note': payment.note,
			'payer_email': order['payer']['email_address'],
			'transactionid': order['purchase_units'][0]['payments']['captures'][0]['id']

		}
		payment_history = PaymentHistory.objects.create(**payment_history_data)
		if order and order['purchase_units'][0]['payments']['captures'][0]['status'] == 'COMPLETED':
			user.balance += Decimal(payment.amount)
			user.save()

			return payment_history, order
		return False, False


	def get_subscription_info(self, subscription_id):
		return self.api(f"/billing/subscriptions/{subscription_id}", api_version = 1, method = 'get')


	def approve_order(self, user, subscription_id, payment: PaymentInformation):
		subscription = self.get_subscription_info(subscription_id)
		if subscription and subscription['status'] == 'ACTIVE':
			amount = to_decimal(subscription['billing_info']['last_payment']['amount']['value']) if subscription['billing_info'].get('last_payment') else 0
			if amount:
				payment_history_data = {
					'method': 'paypal',
					'user_id': user.id,
					'amount': amount,
					'subtotal': amount,
					'discount': 0,
					'discount_code': '',
					'total': amount,
					'balance': user.balance,
					'new_balance': user.balance,
					'status': 'completed',
					'token': '',
					'name': payment.name,
					'type': payment.type,
					'note': payment.note,
					'payer_email': subscription['subscriber']['email_address'],
					'transactionid': subscription_id

				}
				# user.balance += Decimal(amount)
				# user.save()
				payment_history = PaymentHistory.objects.create(**payment_history_data)
			return True, subscription
		return False, False


	def create_order(self, user, payment_information):
		price = to_decimal(payment_information.amount)
		product_name = payment_information.name
		request_id = to_str(uuid.uuid4())

		order_data = {
			'intent': 'CAPTURE',
			'purchase_units': [
				{
					'amount': {
						"value": price,
						"currency_code": "USD",
						"breakdown": {
							"item_total": {
								"value": price,
								"currency_code": "USD",
							}
						},
					},
					'description': product_name,
					'items': [
						{
							'name': product_name,
							'category': 'DIGITAL_GOODS',
							'quantity': 1,
							'unit_amount': {
								'currency_code': 'USD',
								'value': price
							}
						}
					]
				}
			],
			'payment_source': {
				'paypal': {
					'experience_context': {
						'shipping_preference': 'NO_SHIPPING'
					}
				}

			}
		}
		order = self.api('checkout/orders', order_data, request_id = request_id)
		order_id = order['id']
		tracking_id = order['id']

		src_api = self.create_stc_api(user, tracking_id)

		payment_information.paypal_order_id = order_id
		payment_information.paypal_tracking_id = tracking_id
		payment_information.save()
		return order


	def create_subscription_product(self, product_name):
		if self._product_id:
			return self._product_id
		paypal_product_id = SettingUtils().get_setting('paypal_product_id')
		if paypal_product_id:
			self._product_id = paypal_product_id
			return paypal_product_id
		product_data = {
			'name': 'LitCommerce Multichannel Management',
			'type': 'DIGITAL',
			'category': 'SOFTWARE',
		}
		request_id = to_str(uuid.uuid4())

		product = self.api('catalogs/products', product_data, api_version = 1, request_id = request_id)

		if product and product.get('id'):
			self._product_id = product.get('id')
			ServerSetting.objects.create(code = 'paypal_product_id', value = product.get('id'), description = 'Paypal Product Id, do not delete or edit')
			return product['id']
		return False


	def inactive_subscription_plan(self, plan_name):
		plan = self.api(f'billing/plans/subscription_id', api_version = 1, method = 'delete')


	def create_subscription_plan(self, plan, yearly_paid = True):
		plan_name = plan.name
		if yearly_paid:
			plan_name += ' Yearly'
		else:
			plan_name += ' Monthly'
		product_id = self.create_subscription_product(plan_name)
		if not product_id:
			return False

		plan_data = {
			'billing_cycles': [
				{
					"frequency": {
						"interval_unit": "YEAR" if yearly_paid else "MONTH",
						"interval_count": 1,
					},
					"tenure_type": "REGULAR",
					"sequence": 1,
					"total_cycles": 0,
					"pricing_scheme": {
						"fixed_price": {
							"currency_code": "USD",
							"value": plan.yearly_fee if yearly_paid else plan.monthly_fee
						}
					}
				}
			],
			'name': plan_name,
			'payment_preferences': {
				"auto_bill_outstanding": True,
				"payment_failure_threshold": 1,
				# "setup_fee": {
				# 	"currency_code": "USD",
				# 	"value": plan.yearly_fee if yearly_paid else plan.monthly_fee
				# },
				# "setup_fee_failure_action": "CANCEL"
			},
			'product_id': product_id,
		}
		request_id = to_str(uuid.uuid4())

		plan = self.api('billing/plans', plan_data, api_version = 1, request_id = request_id)
		if plan and plan.get('id'):
			return plan['id']
		return False


	def api(self, path, data = None, tracking_id = None, request_id = None, method = 'post', api_version = 2):
		url = f"{self.get_paypal_url(api_version)}/{to_str(path).strip('/')}"
		headers = dict()
		headers['Content-Type'] = 'application/json'
		if tracking_id:
			headers['PayPal-Client-Metadata-Id'] = tracking_id
		if request_id:
			headers['PayPal-Request-Id'] = request_id
		request_options = {
			'headers': headers,
			'method': method,
			'url': url
		}
		if data:
			if method == 'get':
				request_options['params'] = data
			else:
				request_options['json'] = data
		request_options['auth'] = HTTPBasicAuth(self.get_client_id(), self.get_client_secret())
		response_data = False
		try:
			response = requests.request(**request_options)
			try:
				if response.status_code > 300:
					log_api_error(url = url, method = method, response = response.text, status = response.status_code)
			except:
				pass
			self._last_status_code = response.status_code
			response_data = response.text
			if json_decode(response_data):
				response_data = json_decode(response_data)
		except Exception:
			log_traceback()
			return False
		return response_data


	def cancel_subscription(self, subscription_id):
		cancel = self.api(f'billing/subscriptions/{subscription_id}/cancel', api_version = 1, method = 'post')
		if self._last_status_code < 300:
			return True
		return False


	def create_custom_subscription(self, payload):
		subscription = self.api(f'billing/subscriptions',payload, api_version = 1, method = 'post')
		return subscription