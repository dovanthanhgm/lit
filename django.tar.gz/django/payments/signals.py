from django.conf import settings
from paypal.standard.ipn.signals import valid_ipn_received
from paypal.standard.models import ST_PP_COMPLETED

from accounts.utils import AccountUtils
from payments.method.payment import PaymentMethod
from payments.method.paypal import PaymentPaypal
from payments.utils import PaymentUtils


# @receiver(valid_ipn_received)
def payment_noti(sender, **kwargs):
	"""	Receiver function """
	ipn_obj = sender
	token = ipn_obj.custom
	payment = PaymentUtils().get_payment_information(token)
	if not payment:
		return
	user = AccountUtils().get_user(payment.user_id)
	if not user:
		return
	if ipn_obj.payment_status == ST_PP_COMPLETED:
		if ipn_obj.receiver_email != settings.PAYPAL_RECEIVER_EMAIL:
			payment_status = False
		else:
			payment_status = True
		if payment_status:
			payment_history = PaymentMethod().get_payment_history(token)
			if not payment_history:
				extend_data = {
					'ipn_id': ipn_obj.id,
					'payer_email': ipn_obj.payer_email,
					'transactionid': ipn_obj.txn_id,
				}
				PaymentPaypal().paypal_payment_done(user, payment, "completed", **extend_data)

			else:
				payment.delete()
				payment_history.ipn_id = ipn_obj.id
				payment_history.payer_email = ipn_obj.payer_email
				payment_history.transactionid = ipn_obj.txn_id
				payment_history.status = 'failed' if not payment_status else "completed"
				payment_history.save()
	else:
		payment_status = False


# # connect style
valid_ipn_received.connect(payment_noti)
