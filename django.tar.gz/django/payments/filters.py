from django_filters import FilterSet

from accounts.utils import AccountUtils
from payments.models import PaymentHistory


class PaymentHistoryFilter(FilterSet):
	class Meta:
		model = PaymentHistory
		fields = ['type', 'status']


	@property
	def qs(self):
		warehouse_location = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return warehouse_location.filter(user_id = user_id)
