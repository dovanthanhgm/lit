from decimal import Decimal

from django.conf import settings
from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect
from django.utils.html import format_html
from paypal.standard.forms import PayPalPaymentsForm

from accounts.utils import AccountUtils
from libs.utils import get_full_absolute_uri, get_app_url, log_traceback
from payments.method.payment import PaymentMethod
from payments.models import PaymentHistory


class ExtPayPalPaymentsForm(PayPalPaymentsForm):
	def render(self):
		form_open = u'''<form action="%s" id="litcommerce" method="post">''' % (self.get_endpoint())
		form_close = u'</form>'
		return format_html(form_open + self.as_p() + form_close)


class PaymentPaypal(PaymentMethod):
	METHOD = 'paypal'


	def __init__(self, **kwargs):
		super().__init__(**kwargs)


	def process_payment(self, payment_information):
		paypal_dict = {
			'business': settings.PAYPAL_RECEIVER_EMAIL,
			'amount': payment_information.amount,
			'item_name': payment_information.name,
			'currency_code': 'USD',
			'notify_url': get_full_absolute_uri('paypal-ipn') + "/",
			'return': get_full_absolute_uri('payment_done', {'token': payment_information.token}),
			'cancel_return': get_full_absolute_uri('payment_canceled', {'token': payment_information.token}),
			# custom fields
			'custom': payment_information.token,  # user_id

		}

		form = ExtPayPalPaymentsForm(initial = paypal_dict)
		context = {'form': form}
		self.set_method_payment(payment_information)
		return render(self.request, 'payments/process.html', context)


	def paypal_payment_done(self, user, payment, status = 'pending', **kwargs):
		# if payment.type in ['plan', 'add_fund']:
		try:
			# user.balance += Decimal(payment.amount)
			# user.save()
			payment_history_data = {
				'method': self.METHOD,
				'user_id': payment.user_id,
				'amount': payment.amount,
				'subtotal': payment.subtotal,
				'discount': payment.discount,
				'discount_code': payment.discount_code,
				'total': payment.total,
				'balance': payment.balance,
				'new_balance': user.balance,
				'status': status,
				'token': payment.token,
				'name': payment.name,
				'type': payment.type,
				'note': payment.note
			}
			if kwargs:
				payment_history_data.update(kwargs)
			payment_history = PaymentHistory.objects.create(**payment_history_data)
			order_type = payment.type
			if hasattr(self, f"payment_{order_type}_done"):
				getattr(self, f"payment_{order_type}_done")(user, payment, payment_history, payment.meta_data)
		except Exception:
			log_traceback()
			return False
		return payment_history


	def payment_done(self, payment, request):
		user = AccountUtils().get_user(payment.user_id)
		if not user:
			return HttpResponseForbidden()
		payment_history = self.get_payment_history(payment.token)
		return_url_default = get_app_url("my-wallet", user)
		return_url = payment.return_url if payment.return_url else return_url_default
		if not payment_history:
			payment_history = self.paypal_payment_done(user, payment)

		else:
			payment.delete()
		if payment.type == 'add_fund':
			return_url += f"/{payment_history.id}"

		return redirect(return_url)
