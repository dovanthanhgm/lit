from core.utils import CoreUtils
from libs.utils import get_full_absolute_uri, json_decode, to_decimal, convert_format_time, to_int
from litcommerce_order.models import LitCommerceOrder
from litcommerce_order.utils import LitcommerceOrderUtils
from payments.models import PaymentInformation, PaymentHistory
from subscription.models import Subscription
from subscription.utils import SubscriptionUtils


class PaymentMethod:
	METHOD = 'default'
	NEW_PLAN_AUTO_RENEW = False


	def __init__(self, **kwargs):
		self.request = kwargs.get('request')


	def process_payment(self, payment_information):
		pass


	def create_payment_information(self, user_id, amount, token, **kwargs):
		payment_data = {
			'user_id': user_id,
			'amount': amount,
			'return_url': kwargs.get('return_url'),
			'cancel_url': kwargs.get('cancel_url'),
			'token': token,
			'status': 'pending',
			'name': kwargs.get('name', 'Add Func'),
			'method': self.METHOD
		}
		PaymentInformation.objects.create(**payment_data)


	def set_method_payment(self, payment_information):
		if not payment_information.method:
			payment_information.method = self.METHOD
			payment_information.save()


	def payment_done(self, payment, request):
		pass


	def payment_subscription_done(self, user, payment, subscription, upgrade = False):
		amount = to_decimal(subscription['billing_info']['last_payment']['amount']['value']) if subscription['billing_info'].get('last_payment') else 0
		# if upgrade:
		# 	amount = 0
		kwargs = dict(discount = payment.discount, discount_code = payment.discount_code, total = amount, subtotal = amount, order_from = self.METHOD, new_plan_auto_renew = True, upgrade_plan = False, paypal_subscription_id = subscription['id'])
		meta_data = json_decode(payment.meta_data)
		start_time = meta_data.get('start_time') if meta_data else False
		if start_time:
			start_date = convert_format_time(start_time, old_format = '%Y-%m-%dT%H:%M:%SZ', new_format = '%Y-%m-%d')
			new_expired_at = start_date + " 00:01:00"
			kwargs['subscription_start_date'] = start_date
			kwargs['new_expired_at'] = new_expired_at
		kwargs['channels_limit'] = payment.channels_limit
		kwargs['products_limit'] = payment.products_limit
		old_plan = SubscriptionUtils().get_plan_by_user(user)

		SubscriptionUtils().new_user_subscription_plan(user, SubscriptionUtils().get(payment.plan_id), payment.yearly_paid, old_plan, **kwargs)
		plan_id = payment.plan_id
		plan = Subscription.objects.get(pk = plan_id)
		yearly_paid = payment.yearly_paid
		total = payment.total
		if not upgrade:
			if yearly_paid:
				pricing = f'{total}/Year'
			else:
				pricing = f'{total}/Month'

			context = {
				'plan_name': plan.name,
				'pricing': pricing

			}
			user.send_email_template('subscription-activated', context)
		else:
			old_user_plan = old_plan['user_plan']
			if old_user_plan['yearly_paid']:
				old_pricing = f'{to_int(old_plan["yearly_fee"])}/Year'
			else:
				old_pricing = f'{to_int(old_plan["monthly_fee"])}/Month'
			if yearly_paid:
				pricing = f'{to_int(total)}/Year'
			else:
				pricing = f'{to_int(total)}/Month'

			context = {
				'prev_plan_name': old_plan['name'],
				'prev_pricing': old_pricing,
				'new_plan_name': plan.name,
				'new_pricing': pricing
			}
			user.send_email_template('subscription-updated', context)


	def payment_plan_done(self, user, payment: PaymentInformation, history, meta_data):
		kwargs = dict(discount = payment.discount, discount_code = payment.discount_code, total = payment.total, order_from = self.METHOD, new_plan_auto_renew = self.NEW_PLAN_AUTO_RENEW, upgrade_plan = payment.upgrade_plan)
		if meta_data and json_decode(meta_data):
			meta_data = json_decode(meta_data)
			if meta_data.get('billing_on'):
				new_expired_at = meta_data['billing_on'] + " 00:01:00"
				kwargs['new_expired_at'] = new_expired_at
		if payment.channels_limit:
			kwargs['channels_limit'] = payment.channels_limit
		if payment.products_limit:
			kwargs['products_limit'] = payment.products_limit
		SubscriptionUtils().new_user_subscription_plan(user, SubscriptionUtils().get(payment.plan_id), payment.yearly_paid, **kwargs)
		plan_id = payment.plan_id
		plan = Subscription.objects.get(pk = plan_id)
		context = {
			'plan_name': plan.name,
			'plan_months': 12 if payment.yearly_paid else 1,
			'plan_total': to_int(payment.total)

		}
		user.send_email_template('plan-purchased', context)


	def payment_custom_done(self, user, payment, history, meta_data):
		meta_data = json_decode(meta_data)
		meta_data['order_type'] = 'custom'
		meta_data['payment_id'] = history.id
		meta_data['order_from'] = self.METHOD

		order_id = LitcommerceOrderUtils(user = user).create_order(meta_data['total'], new_balance = True, **meta_data)
		if order_id:
			context = {
				'order_number': f"#{order_id}",
				'order_total': payment.total

			}
			user.send_email_template('custom-purchased', context)


	def payment_aio_done(self, user, payment, history, meta_data):
		meta_data = json_decode(meta_data)
		meta_data['order_type'] = 'aio'
		meta_data['payment_id'] = history.id
		meta_data['order_from'] = self.METHOD
		order_id = LitcommerceOrderUtils(user = user).create_order(meta_data['total'], new_balance = True, **meta_data)
		if order_id:
			context = {
				'order_number': f"#{order_id}",
				'order_total': payment.total

			}
			user.send_email_template('all-one-purchased', context)
			source = meta_data['source'].split(',')
			target = meta_data['target'].split(',')
			source = ','.join(list(map(lambda x: str(x).capitalize(), source)))
			target = ','.join(list(map(lambda x: str(x).capitalize(), target)))
			comment = {
				"source": source,
				"target": target,
				"number Of Products": meta_data['number_products'],
				"Custom requirements": meta_data['note'],
				"Order total": meta_data['total']
			}
			comment_msg = "\n".join([f"{field.capitalize()}: {value}" for field, value in comment.items()])
			ticket_data = {
				'subject': f"LitCommerce: {source} to {target} All In One Integration Service",
				'comment': comment_msg,
				'order_id': order_id
			}
			ticket_id = CoreUtils().create_ticket_zendesk(user, **ticket_data)
			if ticket_id:
				LitCommerceOrder.objects.filter(pk = order_id).update(ticket_id = ticket_id)


	def get_payment_history(self, token):
		try:
			payment = PaymentHistory.objects.get(token = token)
		except PaymentHistory.DoesNotExist:
			return False
		return payment


	def get_success_url(self, token):
		return get_full_absolute_uri('payment_done', {'token': token})


	def get_payment_method_name(self):
		return self.METHOD
