from datetime import datetime
from decimal import Decimal

from django.db import transaction
from django.http import JsonResponse, HttpResponseForbidden
from django.shortcuts import redirect

from accounts.utils import AccountUtils
from channels.models import Channel
from core.responses import ErrorResponse
from libs.utils import get_app_url, to_decimal, get_current_time, json_decode, json_encode, log_traceback
from merchant.shopify.api import ShopifyApi
from merchant.shopify.models import ShopifyCharge, ShopifyApp
from payments.method.payment import PaymentMethod
from payments.models import PaymentHistory, PaymentInformation
from payments.pricing import calculated_subscription_pricing
from subscription.models import Subscription
import dateutil.relativedelta

class OneTimePaymentShopify(PaymentMethod):
	METHOD = 'shopify'

	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._app = ShopifyApp.objects.filter(default = True).first()
		self._channel = kwargs.get('channel')
		self._user_id = kwargs.get('user_id')
		if not self._channel and self._user_id:
			channel_default = Channel.objects.filter(user_id = self._user_id, type = 'shopify').first()
			if channel_default and channel_default.type == 'shopify':
				self._channel = channel_default
		self._model_api = ShopifyApi(channel = self._channel)

	def process_payment(self, payment_information):
		shopify_payment = {
			'application_charge': {
				"name": payment_information.name,
				"price": payment_information.amount,
				"return_url": self.get_success_url(payment_information.token)
			}
		}
		if self._app.mode == 'test':
			shopify_payment['application_charge']['test'] = True
		self.set_method_payment(payment_information)
		payment_result = self._model_api.api("application_charges.json", shopify_payment, api_type = 'post')
		if not payment_result or not payment_result.get('application_charge', dict()).get('confirmation_url'):
			return JsonResponse(ErrorResponse(errors = "Something Error. Can\'t payment at the moment. Please try again later").to_dict(), status = 400)
		return redirect(payment_result['application_charge']['confirmation_url'])


	def payment_done(self, payment, request):
		charge_id = request.query_params.get('charge_id')
		if not charge_id:
			return HttpResponseForbidden()
		user_id = payment.user_id
		shopify_payment = {
			"application_charge": {
				"status": "accepted"
			}
		}
		if self._app.mode == 'test':
			shopify_payment['application_charge']['test'] = True
		return_url_default = get_app_url("my-wallet", AccountUtils().get_user(user_id))
		return_url = payment.return_url if payment.return_url else return_url_default

		payment_result = self._model_api.api(f"application_charges/{charge_id}/activate.json", shopify_payment, api_type = 'post')
		if payment_result and payment_result['application_charge']['status'] == 'active':
			user = AccountUtils().get_user(user_id)
			try:
				with transaction.atomic():
					if payment.type in ['add_fund']:
						user.balance += Decimal(payment.amount)
						user.save()
					payment_history_data = {
						'method': self.METHOD,
						'transactionid': charge_id,
						'user_id': payment.user_id,
						'amount': payment.amount,
						'subtotal': payment.subtotal,
						'discount': payment.discount,
						'discount_code': payment.discount_code,
						'total': payment.total,
						'balance': payment.balance,
						'new_balance': user.balance,
						'status': 'completed',
						'token': payment.token,
						'name': payment.name,
						'type': payment.type,
						'note': payment.note
					}
					payment_history = PaymentHistory.objects.create(**payment_history_data)

					# balance = user.balance
					# user.balance += Decimal(payment_result['application_charge']['price'])
					# user.save()
					# history = PaymentHistory.objects.create(balance = balance, user_id = user_id, payer_email = user.email, amount = payment_result['application_charge']['price'], subtotal = payment_result['application_charge']['price'], total = payment_result['application_charge']['price'], new_balance = user.balance, status = "completed", name = payment_result['application_charge']['name'], transactionid = charge_id, method = self.METHOD, token = payment.token, note = payment.note)
					order_type = payment.type
					if hasattr(self, f"payment_{order_type}_done"):
						getattr(self, f"payment_{order_type}_done")(user, payment, payment_history, payment.meta_data)
					else:
						return_url += f"/{payment_history.id}"
				try:
					recurring_application_charges = self._model_api.api(f"recurring_application_charges.json")
					if recurring_application_charges and recurring_application_charges.get('recurring_application_charges'):
						for recurring_application_charge in recurring_application_charges['recurring_application_charges']:
							if recurring_application_charge['status'] == 'active':
								self._model_api.api(f"recurring_application_charges/{recurring_application_charge['id']}.json", api_type = 'delete')
				except:
					pass
			except Exception as e:
				return redirect(payment.cancel_url)
			payment.delete()
			return redirect(return_url)
		return redirect(payment.cancel_url)


class PaymentShopify(OneTimePaymentShopify):
	NEW_PLAN_AUTO_RENEW = True

	def process_payment(self, payment_information: PaymentInformation):
		if payment_information.type != 'plan' or payment_information.yearly_paid:
			return super(PaymentShopify, self).process_payment(payment_information)
		if payment_information.channels_limit and payment_information.products_limit:
			new_price = calculated_subscription_pricing(payment_information.channels_limit, payment_information.products_limit, False)
		else:
			plan_id = payment_information.plan_id
			plan = Subscription.objects.get(pk = plan_id)
			new_price = plan.monthly_fee
		shopify_payment = {
			'recurring_application_charge': {
				"name": payment_information.name,
				"price": new_price,
				"return_url": self.get_success_url(payment_information.token)
			}
		}
		if self._app.mode == 'test':
			shopify_payment['recurring_application_charge']['test'] = True
		self.set_method_payment(payment_information)

		payment_result = self._model_api.api("recurring_application_charges.json", shopify_payment, api_type = 'post')
		if not payment_result or not payment_result.get('recurring_application_charge', dict()).get('confirmation_url'):
			return JsonResponse(ErrorResponse(errors = "Something Error. Can\'t payment at the moment. Please try again later").to_dict(), status = 400)
		return redirect(payment_result['recurring_application_charge']['confirmation_url'])


	def payment_done(self, payment, request):
		if payment.type != 'plan' or payment.yearly_paid:
			return super(PaymentShopify, self).process_payment(payment)
		charge_id = request.query_params.get('charge_id')
		if not charge_id:
			return HttpResponseForbidden()
		user_id = payment.user_id
		shopify_payment = {
			"recurring_application_charge": {
				"status": "accepted"
			}
		}
		if self._app.mode == 'test':
			shopify_payment['recurring_application_charge']['test'] = True
		return_url_default = get_app_url("my-wallet", AccountUtils().get_user(user_id))
		return_url = payment.return_url if payment.return_url else return_url_default

		payment_result = self._model_api.api(f"recurring_application_charges/{charge_id}/activate.json", shopify_payment, api_type = 'post')
		if payment_result and payment_result['recurring_application_charge']['status'] == 'active':
			ShopifyCharge.objects.update_or_create(defaults = {'charge_id': charge_id}, user_id = user_id)
			user = AccountUtils().get_user(user_id)
			try:
				with transaction.atomic():
					if payment.type in ['add_fund']:
						user.balance += Decimal(payment.amount)
						user.save()
					current_time = datetime.today() - dateutil.relativedelta.relativedelta(hours = 7)

					if payment.total > 0 and payment_result['recurring_application_charge']['billing_on'] != current_time.strftime('%Y-%m-%d'):
						billing_on = datetime.strptime(payment_result['recurring_application_charge']['billing_on'], '%Y-%m-%d')
						delta = billing_on - current_time
						delta_days = delta.days + 1
						if 0 < delta_days < 30:
							price = to_decimal(payment_result['recurring_application_charge']['price'])
							payment.total = to_decimal(price / 30 * delta.days, 2)
							meta_data = json_decode(payment.meta_data)
							if not meta_data:
								meta_data = {}
							meta_data['billing_on'] = payment_result['recurring_application_charge']['billing_on']
							payment.meta_data = json_encode(meta_data)
					payment_history_data = {
						'method': self.METHOD,
						'transactionid': charge_id,
						'user_id': payment.user_id,
						'amount': payment.amount,
						'subtotal': payment.subtotal,
						'discount': payment.discount,
						'discount_code': payment.discount_code,
						'total': payment.total,
						'balance': payment.balance,
						'new_balance': user.balance,
						'status': 'completed',
						'token': payment.token,
						'name': payment.name,
						'type': payment.type,
						'note': payment.note
					}
					payment_history = PaymentHistory.objects.create(**payment_history_data)

					# balance = user.balance
					# user.balance += Decimal(payment_result['application_charge']['price'])
					# user.save()
					# history = PaymentHistory.objects.create(balance = balance, user_id = user_id, payer_email = user.email, amount = payment_result['application_charge']['price'], subtotal = payment_result['application_charge']['price'], total = payment_result['application_charge']['price'], new_balance = user.balance, status = "completed", name = payment_result['application_charge']['name'], transactionid = charge_id, method = self.METHOD, token = payment.token, note = payment.note)
					order_type = payment.type
					if hasattr(self, f"payment_{order_type}_done"):
						getattr(self, f"payment_{order_type}_done")(user, payment, payment_history, payment.meta_data)
					else:
						return_url += f"/{payment_history.id}"
			except Exception as e:
				log_traceback()
				return redirect(payment.cancel_url)
			payment.delete()
			return redirect(return_url)
		return redirect(payment.cancel_url)