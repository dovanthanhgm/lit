import time
from decimal import Decimal

from django.http import HttpResponseForbidden, JsonResponse
from django.shortcuts import redirect

from accounts.utils import AccountUtils
from core.responses import ErrorResponse
from libs.utils import get_app_url
from merchant.wix.api import MerchantWixApi
from merchant.wix.models import MerchantWixSubscription
from payments.method.payment import PaymentMethod
from payments.models import PaymentHistory


class PaymentWix(PaymentMethod):
	METHOD = 'wix'
	NEW_PLAN_AUTO_RENEW = True
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._app = kwargs.get('app')
		self._instance_id = kwargs.get('instance_id')
		self._user_id = kwargs.get('user_id')


	def process_payment(self, payment_information):
		plan_id = payment_information.plan_id
		try:
			wix_plan = MerchantWixSubscription.objects.get(plan_id = plan_id)
		except MerchantWixSubscription.DoesNotExist:
			return HttpResponseForbidden()
		payment_information.custom = wix_plan.wix_plan_id
		payment_information.save()
		wix_payment = {
			'productId': wix_plan.wix_plan_id,
			'successUrl': self.get_success_url(payment_information.token),
			'testCheckout': True if self._app.mode == 'test' else False,
			'billingCycle': 'YEARLY' if payment_information.yearly_paid else 'MONTHLY'
		}
		wix_api = MerchantWixApi(app = self._app, user_id = self._user_id, instance_id = self._instance_id)
		response = wix_api.post('apps/v1/checkout', wix_payment)
		if wix_api.get_last_status_code() != 200 or not response or not response.get('checkoutUrl'):
			return JsonResponse(ErrorResponse(errors = "Something Error. Can\'t payment at the moment. Please try again later").to_dict(), status = 400)
		return redirect(response.get('checkoutUrl'))


	def payment_done(self, payment, request):
		user = AccountUtils().get_user(payment.user_id)
		if not user:
			return HttpResponseForbidden()
		return_url_default = get_app_url("my-wallet", user)
		return_url = payment.return_url if payment.return_url else return_url_default
		new_plan = False
		new_plan = True
		# if payment.type in ['plan', 'add_fund']:
		# user.balance += Decimal(payment.amount)
		# user.save()
		payment_history_data = {
			'method': self.METHOD,
			'user_id': payment.user_id,
			'amount': payment.amount,
			'subtotal': payment.subtotal,
			'discount': payment.discount,
			'discount_code': payment.discount_code,
			'total': payment.total,
			'balance': payment.balance,
			'new_balance': user.balance,
			'status': 'pending',
			'token': payment.token,
			'name': payment.name,
			'type': payment.type,
			'note': payment.note,
			'custom': payment.custom
		}
		payment_history = PaymentHistory.objects.create(**payment_history_data)
		order_type = payment.type
		if hasattr(self, f"payment_{order_type}_done"):
			getattr(self, f"payment_{order_type}_done")(user, payment, payment_history, payment.meta_data)
		else:
			return_url += f"/{payment_history.id}"
		payment.delete()

		return redirect(return_url)