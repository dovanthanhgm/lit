from datetime import datetime
from decimal import Decimal
from time import time

from django.db.models import Q
from django.forms import model_to_dict
from django.http.response import HttpResponseForbidden, JsonResponse, HttpResponse
from django.shortcuts import redirect, get_object_or_404
from rest_framework import generics
from rest_framework.permissions import AllowAny

from accounts.utils import AccountUtils
from channels.models import Channel
from channels.utils import ChannelUtils
# Customize PayPalPaymentsForm
from core.authentication import IsGetOrIsAuthenticated
from core.responses import ResponseObject, ErrorResponse
from core.utils import CoreUtils
from coupons.utils import CouponUtils
from libs.utils import to_decimal, get_config_ini, random_token, to_int, get_full_absolute_uri, get_app_url, json_encode, json_decode, log_traceback, get_current_time, to_str
from litcommerce_order.models import LitCommerceOrder
from litcommerce_order.serializers import LitcommercePlaceAioOrderSerializer
from merchant.shopify.middleware import ShopifyWebHookMiddleware
from payments.models import PaymentHistory, PaymentInformation, PaypalSubscriptionActive, PaypalWebhookModels
from payments.utils import PaymentUtils
from products.utils import ProductUtils
from subscription.models import Subscription, UserSubscription
from subscription.utils import SubscriptionUtils
from .filters import PaymentHistoryFilter
from .method.paypal import PaymentPaypal
from .method.shopify import PaymentShopify
from .middleware import PaypalWebHookMiddleware
from .paypal_api import PaypalApi
from .pricing import SUBSCRIPTION_PRICING, SUBSCRIPTION_PRICING_EACH_CHANNEL, calculated_subscription_pricing
from .serializers import PaymentHistorySerializer


class ProcessPaymentView(generics.ListCreateAPIView):
	def post(self, request, *args, **kwargs):
		token = f"{to_int(time())}-{random_token()}"
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user(user_id)
		amount = to_decimal(request.data.get('amount', request.GET.get('amount')), 2)

		payment_information = {
			'token': token,
			"user_id": user_id,
			"amount": amount,
			"return_url": get_app_url("my-wallet/payment-success", user),
			"cancel_url": get_app_url("my-wallet/payment-error", user),
			"status": "pending",
			"type": "add_fund",
			"name": "Add fund to LitCommerce",
			'method': PaymentUtils().get_payment_method_name(request)
		}
		meta_data = AccountUtils().get_meta_data(request)
		if meta_data:
			payment_information['meta_data'] = json_encode(meta_data)
		PaymentInformation.objects.create(**payment_information)
		return HttpResponse(get_full_absolute_uri('process_payment_token', {'token': token}))


class ProcessPaymentByTokenView(generics.ListAPIView):
	permission_classes = [AllowAny]


	def get(self, request, *args, **kwargs):
		token = kwargs['token']
		payment_information = PaymentUtils().get_payment_information(token)
		if not payment_information:
			return HttpResponseForbidden()
		token = f"{to_int(time())}-{random_token()}"
		payment_information.token = token
		payment_information.save()
		return PaymentUtils().process_payment(payment_information)


# paypal_dict = {
# 	'business': settings.PAYPAL_RECEIVER_EMAIL,
# 	'amount': payment_information.amount,
# 	'item_name': payment_information.name,
# 	'currency_code': 'USD',
# 	'notify_url': get_full_absolute_uri('paypal-ipn') + "/",
# 	'return': get_full_absolute_uri('payment_done', {'token': token}),
# 	'cancel_return': get_full_absolute_uri('payment_canceled', {'token': token}),
# 	# custom fields
# 	'custom': token,  # user_id
#
# }
# form = ExtPayPalPaymentsForm(initial = paypal_dict)
# context = {'form': form}
# return render(request, 'payments/process.html', context)


class PaymentDoneView(generics.ListAPIView):
	permission_classes = (IsGetOrIsAuthenticated,)


	def get(self, request, *args, **kwargs):
		return PaymentUtils().payment_done(request, *args, **kwargs)


class PaymentCanceledView(generics.ListAPIView):
	permission_classes = (IsGetOrIsAuthenticated,)


	def get(self, request, *args, **kwargs):
		token = kwargs['token']
		payment = PaymentUtils().get_payment_information(token)
		if not payment:
			return redirect(get_app_url())
		return_url_default = get_app_url("my-wallet", payment.user)
		return_url = payment.cancel_url if payment.cancel_url else return_url_default
		return redirect(return_url)


class PaymentHistoryView(generics.ListAPIView):
	queryset = PaymentHistory.objects.all().order_by('-id')
	serializer_class = PaymentHistorySerializer
	filterset_class = PaymentHistoryFilter


class PaymentHistoryDetailsView(generics.RetrieveAPIView):
	queryset = PaymentHistory.objects.all()
	serializer_class = PaymentHistorySerializer
	filterset_class = PaymentHistoryFilter


class PaypalCreateOrder(generics.CreateAPIView):
	def before_order(self, user, order_data):
		order_type = order_data.get('order_type')
		if not hasattr(self, f"before_order_{order_type}"):
			return False, False
		return getattr(self, f"before_order_{order_type}")(user, order_data['order_data'])


	def before_order_plan(self, user, order_data):
		plan_id = order_data['plan_id']
		plan = get_object_or_404(Subscription, pk = plan_id)
		total_listing = ProductUtils().count_total_product_import(user.id)
		user.total_product = total_listing
		user.save()
		if plan.products_limit and total_listing > plan.products_limit:
			return False, f"You have {total_listing} products, the plan you selected is not suitable. Please choose another plan."
		yearly_billing = order_data.get('yearly_paid')
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		new_price = to_decimal(plan.monthly_fee if not yearly_billing else plan.yearly_fee)

		discount = 0
		upgraded = False
		if to_int(old_plan['id']) != 1 and not old_plan.get('expired') and to_int(plan.monthly_fee) > to_int(old_plan['monthly_fee']):
			upgraded = True
			grand_total = SubscriptionUtils().remaining_price(old_plan, model_to_dict(plan))
			if grand_total:
				new_price = grand_total
		total = new_price
		discount_info = dict()
		coupon_code = order_data.get('coupon_code')
		# coupon_code = '123456'
		if coupon_code:
			validate_coupon = CouponUtils().verify_coupon(coupon_code, user, new_price, 'plan')
			if validate_coupon['result'] == 'success':
				discount = validate_coupon['data']['discount']
				total = validate_coupon['data']['total']
				discount_info = validate_coupon['data']
		if total <= to_decimal(user.balance):
			kwargs = dict()
			if discount:
				kwargs['discount'] = discount
				kwargs['total'] = total
				kwargs['discount_code'] = discount_info['code']
			new_plan = SubscriptionUtils().new_user_subscription_plan(user, plan, yearly_billing, **kwargs)
			return JsonResponse(ResponseObject(data = new_plan).to_dict())
		token = f"{to_int(time())}-{random_token()}"

		name = f"Upgrade Plan {old_plan['name']} => {plan.name}"
		if old_plan['name'] == plan.name:
			name = f"Renew Plan {plan.name}"
		payment_information_data = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": to_decimal(total),
			"subtotal": to_decimal(new_price),
			"return_url": get_app_url("subscription/change-success", user),
			"cancel_url": get_app_url("subscription/change-error", user),
			"status": "pending",
			"type": "plan",
			"name": f"LitCommerce: {name}",
			"plan_id": plan_id,
			"yearly_paid": 1 if yearly_billing else 0,
			"method": 'paypal',
			"upgrade_plan": upgraded
		}
		if discount:
			payment_information_data['discount'] = discount
			payment_information_data['discount_code'] = discount_info['code']
		payment_information = PaymentInformation.objects.create(**payment_information_data)
		return True, payment_information


	def before_order_aio(self, user, data):
		serializer = LitcommercePlaceAioOrderSerializer(data = data)
		if not serializer.is_valid():
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		if data.get('skype') or data.get('whatsapp'):
			if data.get('skype'):
				self.request.user.skype = data['skype']
			if data.get('whatsapp'):
				self.request.user.whatsapp = data['whatsapp']
			self.request.user.save()
		price = CoreUtils().get_entity_price(serializer.data['number_products'], serializer.data['source'], serializer.data['target'])['price']
		if serializer.data.get('custom_fee'):
			price += to_int(serializer.data.get('custom_fee'))
		coupon_code = serializer.data.get('coupon_code')
		# coupon_code = '123456'
		total = price
		subtotal = price
		discount = 0
		discount_info = dict()
		description = f"LitCommerce: {','.join(serializer.data['source'])} to {','.join(serializer.data['target'])} All In One Service"
		kwargs = dict(
			subtotal = subtotal,
			total = total,
			order_type = 'aio',
			number_products = serializer.data['number_products'],
			source = ','.join(serializer.data['source']),
			target = ','.join(serializer.data['target']),
			custom_fee = to_int(serializer.data.get('custom_fee')),
			note = serializer.data.get('custom_requirements'),
			description = description
		)
		if coupon_code:
			validate_coupon = CouponUtils().verify_coupon(coupon_code, user, price, 'aio')
			if validate_coupon['result'] == 'success':
				discount = validate_coupon['data']['discount']
				total = validate_coupon['data']['total']
				discount_info = validate_coupon['data']
		if discount:
			kwargs['discount'] = discount
			kwargs['total'] = total
			kwargs['discount_code'] = discount_info['code']
		token = f"{to_int(time())}-{random_token()}"

		payment_information_data = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": to_decimal(total),
			"subtotal": to_decimal(subtotal),
			"return_url": get_app_url("order-received", user),
			"cancel_url": get_app_url("buy-aio-service", user),
			"status": "pending",
			"type": "aio",
			"name": description,
			"method": 'paypal',
			'meta_data': json_encode(kwargs)

		}
		payment_information = PaymentInformation.objects.create(**payment_information_data)
		return True, payment_information


	def before_order_custom(self, user, order_data):
		amount = to_decimal(order_data.get('amount'))
		if not amount:
			return False, False
		description = "LitCommerce: Buy Custom Service"
		token = f"{to_int(time())}-{random_token()}"

		payment_information = {
			'token': token,
			'name': "Buy Custom Service LitCommerce",
			"user_id": user.id,
			"amount": to_decimal(amount) - to_decimal(user.balance),
			"return_url": get_app_url("order-received", user),
			"cancel_url": get_app_url("buy-custom-service", user),
			"status": "pending",
			"type": "custom",
			"method": 'paypal',
			'meta_data': json_encode({'note': order_data.get('note'), 'total': amount, 'description': description})
		}
		payment_information = PaymentInformation.objects.create(**payment_information)
		return True, payment_information


	def before_order_add_fund(self, order_data):
		pass


	def post(self, request, *args, **kwargs):
		user = AccountUtils().get_user_by_request(request)

		paypal_api = PaypalApi()
		before_order_status, payment_information = self.before_order(user, request.data)
		if not before_order_status:
			return JsonResponse(ErrorResponse(errors = payment_information).to_dict(), status = 400)
		order = paypal_api.create_order(user, payment_information)
		return JsonResponse(order)


class PaypalCaptureOrder(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		try:
			payment_information = PaymentInformation.objects.get(paypal_order_id = order_id, status = 'pending')
		except Exception as e:
			return HttpResponseForbidden()
		user = AccountUtils().get_user_by_request(request)
		order_data = request.data
		order_type = order_data.get('order_type')
		paypal_api = PaypalApi()
		payment_history, order = paypal_api.capture_order(user, payment_information)
		if payment_history:
			payment_paypal = PaymentPaypal()
			if hasattr(payment_paypal, f"payment_{order_type}_done"):
				getattr(payment_paypal, f"payment_{order_type}_done")(user, payment_information, payment_history, payment_information.meta_data)
			return JsonResponse(order)
		return HttpResponseForbidden()


class PaypalUpgradeSubscriptionCancelCallback(generics.ListAPIView):
	permission_classes = [AllowAny]


	def get(self, request, *args, **kwargs):
		return redirect(get_app_url('subscription'))


class PaypalUpgradeSubscriptionCallback(generics.ListAPIView):
	permission_classes = [AllowAny]


	def get(self, request, *args, **kwargs):
		token = kwargs.get('token')
		payment_information = PaymentInformation.objects.filter(token = token).first()
		if not payment_information or payment_information.status == 'completed':
			return HttpResponseForbidden()
		meta_data = json_decode(payment_information.meta_data)
		subscription_id = meta_data['paypal_subscription_id']
		paypal_api = PaypalApi()
		subscription = paypal_api.get_subscription_info(subscription_id)
		if not subscription or subscription['status'] != 'ACTIVE':
			return redirect(get_app_url('subscription'))
		user = AccountUtils().get_user(payment_information.user_id)
		payment_paypal = PaymentPaypal()
		payment_paypal.payment_subscription_done(user, payment_information, subscription, True)
		payment_information.status = 'completed'
		payment_information.save()
		return redirect(get_app_url('subscription'))


class PaypalUpgradeSubscription(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		plan_id = kwargs['plan_id']
		plan = get_object_or_404(Subscription, pk = kwargs['plan_id'])
		user = AccountUtils().get_user_by_request(request)
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		if not old_plan['user_plan'].get('paypal_subscription_id') or not old_plan['user_plan'].get('auto_renew'):
			return HttpResponseForbidden()
		if plan.monthly_fee <= old_plan['monthly_fee']:
			return HttpResponseForbidden()

		total_listing = ProductUtils().count_total_product_import(user.id)
		user.total_product = total_listing
		user.save()
		if plan.products_limit and total_listing > plan.products_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_listing} products, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		if plan.channels_limit:
			total_channel = Channel.objects.filter(user_id = user.id, deleted_at__isnull = True, default = False).count()
			if total_channel > plan.channels_limit:
				return JsonResponse(ErrorResponse(errors = f"You have {total_channel} channels, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		upgraded = True
		setup_price = 0
		start_time = False
		if to_int(old_plan['id']) != 1 and not old_plan.get('expired'):
			upgraded = True
			grand_total = SubscriptionUtils().remaining_price(old_plan, model_to_dict(plan))
			if grand_total:
				setup_price = grand_total
			start_time = old_plan['expired_at'][0:10] + "T00:00:00Z"
		yearly_billing = request.data.get('yearly_billing')
		token = f"{to_int(time())}-{random_token()}"
		total = to_decimal(plan.monthly_fee if not yearly_billing else plan.yearly_fee)
		name = f"Upgrade Plan to {plan.name}"
		payment_information = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": total,
			"subtotal": total,
			"return_url": get_app_url("subscription/change-success", user) if to_int(request.GET.get('first-setup')) != 1 else get_app_url('products', user),
			"cancel_url": get_app_url("subscription/change-error", user),
			"status": "pending",
			"type": "subscription",
			"name": f"LitCommerce: {name}",
			"plan_id": plan_id,
			"yearly_paid": 1 if yearly_billing else 0,
			"method": 'paypal',
			"upgrade_plan": upgraded
		}
		new_plan_id = plan.paypal_yearly_plan_id if yearly_billing else plan.paypal_monthly_plan_id
		body = {
			'plan_id': new_plan_id,
			'application_context': {
				'return_url': get_full_absolute_uri('paypal_revise_subscription_callback_done', {'token': token}),
				'cancel_url': get_full_absolute_uri('paypal_revise_subscription_callback_cancel', {'token': token}),
			}
		}
		if upgraded:
			body['effective_time'] = start_time
			if setup_price:
				body['plan'] = {
					'payment_preferences': {
						# "billing_cycles":
						"setup_fee": {
							"currency_code": "USD",
							"value": setup_price
						},
						"setup_fee_failure_action": "CANCEL"
					}
				}
		paypal_api = PaypalApi()
		upgrade = paypal_api.api(f"billing/subscriptions/{old_plan['user_plan'].get('paypal_subscription_id')}/revise", body, api_version = 1, method = 'post')
		if paypal_api.get_last_status_code() < 300:
			body['paypal_subscription_id'] = old_plan['user_plan'].get('paypal_subscription_id')
			payment_information['meta_data'] = json_encode(body)
			url_approve = ''
			for url in upgrade['links']:
				if url['rel'] == 'approve':
					url_approve = url['href']
			if not url_approve:
				subscription = paypal_api.get_subscription_info(old_plan['user_plan'].get('paypal_subscription_id'))
				paypal_plan_id = subscription['plan_id']
				if paypal_plan_id == new_plan_id:
					payment_paypal = PaymentPaypal()
					payment_paypal.payment_subscription_done(user, payment_information, subscription, True)
					# payment_information.status = 'completed'
					# payment_information.save()
					return JsonResponse({'url': get_app_url('subscription')})
				else:
					return JsonResponse(ErrorResponse(errors = "can't upgrade because paypal doesn't return payment accept url").to_dict(), status = 400)

			PaymentInformation.objects.create(**payment_information)
			return JsonResponse({'url': url_approve})
		return JsonResponse(ErrorResponse(errors = upgrade.message).to_dict(), status = 400)


class PaypalSelectSubscription(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		plan_id = kwargs['plan_id']
		is_upgraded = request.data.get('is_upgraded')
		plan = get_object_or_404(Subscription, pk = kwargs['plan_id'])
		user = AccountUtils().get_user_by_request(request)
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		if old_plan['user_plan'] and old_plan['user_plan'].get('paypal_subscription_id') and old_plan['user_plan'].get('auto_renew'):
			if is_upgraded:
				paypal_api = PaypalApi()
				paypal_api.cancel_subscription(old_plan['user_plan'].get('paypal_subscription_id'))
			else:
				return HttpResponseForbidden()
		total_listing = ProductUtils().count_total_product_import(user.id)
		user.total_product = total_listing
		user.save()
		if plan.products_limit and total_listing > plan.products_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_listing} products, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		if plan.channels_limit:
			total_channel = Channel.objects.filter(user_id = user.id, deleted_at__isnull = True, default = False).count()
			if total_channel > plan.channels_limit:
				return JsonResponse(ErrorResponse(errors = f"You have {total_channel} channels, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		upgraded = False
		setup_price = 0
		start_time = False
		if to_int(old_plan['id']) != 1 and not old_plan.get('expired'):
			upgraded = True
			grand_total = SubscriptionUtils().remaining_price(old_plan, model_to_dict(plan))
			if grand_total:
				setup_price = grand_total
			start_time = old_plan['expired_at'][0:10] + "T00:00:00Z"
			if old_plan['expired_at'][0:10] == datetime.today().strftime('%Y-%m-%d'):
				start_time = False

		yearly_billing = request.data.get('yearly_billing')
		token = f"{to_int(time())}-{random_token()}"
		total = to_decimal(plan.monthly_fee if not yearly_billing else plan.yearly_fee)
		name = f"Upgrade Plan to {plan.name}"
		payment_information = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": total,
			"subtotal": total,
			"return_url": get_app_url("subscription/change-success", user) if to_int(request.GET.get('first-setup')) != 1 else get_app_url('products', user),
			"cancel_url": get_app_url("subscription/change-error", user),
			"status": "pending",
			"type": "subscription",
			"name": f"LitCommerce: {name}",
			"plan_id": plan_id,
			"yearly_paid": 1 if yearly_billing else 0,
			"method": 'paypal',
			"upgrade_plan": upgraded
		}
		body = {
			'plan_id': plan.paypal_yearly_plan_id if yearly_billing else plan.paypal_monthly_plan_id,
			'custom_id': user.id
		}
		if upgraded:
			if start_time:
				body['start_time'] = start_time
			if setup_price:
				body['plan'] = {
					'payment_preferences': {
						"setup_fee": {
							"currency_code": "USD",
							"value": setup_price
						},
						"setup_fee_failure_action": "CANCEL"
					}
				}
		payment_information['meta_data'] = json_encode(body)

		PaymentInformation.objects.create(**payment_information)

		return JsonResponse({'paypal_body': body, 'token': token})
class PaypalPickupSubscription(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		plan_id = CoreUtils().get_new_plan_default_id()
		is_upgraded = request.data.get('is_upgraded') or request.data.get('isUpgraded')
		plan = get_object_or_404(Subscription, pk = plan_id)
		user = AccountUtils().get_user_by_request(request)
		products_limit = to_int(request.data.get('products_limit'))
		channels_limit = to_int(request.data.get('channels_limit'))
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		if old_plan['user_plan'] and old_plan['user_plan'].get('paypal_subscription_id') and old_plan['user_plan'].get('auto_renew'):
			if is_upgraded:
				paypal_api = PaypalApi()
				paypal_api.cancel_subscription(old_plan['user_plan'].get('paypal_subscription_id'))
			else:
				return HttpResponseForbidden()
		total_listing = ProductUtils().count_total_product_import(user.id)
		user.total_product = total_listing
		user.save()
		yearly_billing = request.data.get('yearly_billing')

		if total_listing > products_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_listing} products, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		total_channel = Channel.objects.filter(user_id = user.id, deleted_at__isnull = True, default = False).count()
		if total_channel > channels_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_channel} channels, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		upgraded = False
		setup_price = 0
		start_time = False
		if to_int(old_plan['id']) != 1 and not old_plan.get('expired'):
			upgraded = True
			grand_total = SubscriptionUtils().new_remaining_price(old_plan, channels_limit, products_limit, yearly_billing)
			if grand_total and grand_total > 0:
				setup_price = grand_total
			start_time = old_plan['expired_at'][0:10] + "T00:00:00Z"
			if old_plan['expired_at'][0:10] == datetime.today().strftime('%Y-%m-%d'):
				start_time = False

		token = f"{to_int(time())}-{random_token()}"
		total = calculated_subscription_pricing(channels_limit, products_limit, yearly_billing)
		name = f"Subscription with {products_limit} listings and {channels_limit} channels"
		payment_information = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": total,
			"subtotal": total,
			"return_url": get_app_url("subscription/change-success", user) if to_int(request.GET.get('first-setup')) != 1 else get_app_url('products', user),
			"cancel_url": get_app_url("subscription/change-error", user),
			"status": "pending",
			"type": "subscription",
			"name": f"{name}",
			"plan_id": plan_id,
			"yearly_paid": 1 if yearly_billing else 0,
			"method": PaymentUtils().get_payment_method_name(request),
			"upgrade_plan": upgraded,
			"products_limit": products_limit,
			"channels_limit": channels_limit
		}
		body = {
			'plan_id': plan.paypal_yearly_plan_id if yearly_billing else plan.paypal_monthly_plan_id,
			'custom_id': user.id,
			'plan': {
				'billing_cycles': [
					{
						"frequency": {
							"interval_unit": "YEAR" if yearly_billing else "MONTH",
							"interval_count": 1,
						},
						"tenure_type": "REGULAR",
						"sequence": 1,
						"total_cycles": 0,
						"pricing_scheme": {
							"fixed_price": {
								"currency_code": "USD",
								"value": total
							}
						}
					}
				],
			}
		}

		if upgraded:
			if start_time:
				body['start_time'] = start_time
			if setup_price:
				body['plan']['payment_preferences'] = {
						"setup_fee": {
							"currency_code": "USD",
							"value": setup_price
						},
						"setup_fee_failure_action": "CANCEL"
					}
		payment_information['meta_data'] = json_encode(body)

		PaymentInformation.objects.create(**payment_information)

		return JsonResponse({'paypal_body': body, 'token': token})

class PaypalApproveOrder(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		subscription_id = kwargs['subscription_id']
		token = request.data.get('token')
		payment_information = PaymentInformation.objects.filter(token = token).first()
		if not payment_information or payment_information.status == 'completed':
			return HttpResponseForbidden()

		user = AccountUtils().get_user_by_request(request)
		order_data = request.data
		order_type = 'subscription'
		paypal_api = PaypalApi()
		payment_history, subscription = paypal_api.approve_order(user, subscription_id, payment_information)

		if payment_history:
			PaypalSubscriptionActive.objects.create(subscription_id = subscription_id, user_id = user.id)
			payment_paypal = PaymentPaypal()
			payment_paypal.payment_subscription_done(user, payment_information, subscription)
			payment_information.status = 'completed'
			payment_information.save()
			return JsonResponse(subscription)
		return HttpResponseForbidden()


class PaypalWebhook(generics.CreateAPIView):
	permission_classes = [AllowAny]
	MIDDLEWARE_CLASSES = (PaypalWebHookMiddleware.NAME,)


	def webhook_billing_subscription_cancelled(self, data):
		subscription = data['resource']
		subscription_id = subscription['id']
		UserSubscription.objects.filter(paypal_subscription_id = subscription_id).update(auto_renew = False)


	def webhook_billing_subscription_expired(self, data):
		subscription = data['resource']
		subscription_id = subscription['id']

		subscription = UserSubscription.objects.filter(paypal_subscription_id = subscription_id).first()
		if subscription and subscription.user_id:
			user = AccountUtils().get_user(subscription.user_id)
			if user:
				AccountUtils().user_expired(user)
		UserSubscription.objects.filter(paypal_subscription_id = subscription_id).update(auto_renew = False, solve_expired = True)


	def webhook_billing_subscription_activated(self, data):
		subscription_id = data['resource']['id']
		user_id = data['resource'].get('custom_id')
		order = LitCommerceOrder.objects.filter(paypal_subscription_id = subscription_id).first()
		if not order:
			paypal_plan_id = data['resource']['plan_id']
			plan = Subscription.objects.filter(Q(paypal_monthly_plan_id = paypal_plan_id) | Q(paypal_yearly_plan_id = paypal_plan_id)).first()
			payment_information = PaymentInformation.objects.filter(user_id = user_id, plan_id = plan.id, type = 'subscription').last()
			subscription = UserSubscription.objects.filter(paypal_subscription_id = subscription_id).first()
			update = payment_information.upgrade_plan
			PaymentPaypal().payment_subscription_done(
				user = AccountUtils().get_user(user_id),
				payment = payment_information,
				subscription = data['resource'],
				upgrade = update
			)

	def webhook_billing_subscription_payment_failed(self, data):
		subscription_id = data['resource']['id']

		subscription = UserSubscription.objects.filter(paypal_subscription_id = subscription_id).first()
		if subscription and subscription.user_id:
			user = AccountUtils().get_user(subscription.user_id)
			if user:
				AccountUtils().user_expired(user)
			UserSubscription.objects.filter(paypal_subscription_id = subscription_id).update(auto_renew = False, paypal_payment_failed = True, solve_expired = True, expired_at = get_current_time(str_format = '%Y-%m-%d 00:00:00'))
			plan = subscription.plan
			extend_data = {
				'plan_name': plan.name,
			}
			if subscription.yearly_paid:
				extend_data['pricing'] = f'${plan.yearly_fee}/year'
			else:
				extend_data['pricing'] = f'${plan.monthly_fee}/month'
			user.send_email_template('recurring-payment-failed', extend_data)

		paypal_api = PaypalApi()
		return paypal_api.cancel_subscription(subscription_id)

	def post(self, request, *args, **kwargs):
		body = request.data
		if body['event_type']:
			try:
				if 'SUBSCRIPTION' in body['event_type']:
					subscription = body['resource']
					paypal_plan_id = subscription['plan_id']
					plan = Subscription.objects.filter(Q(paypal_monthly_plan_id = paypal_plan_id) | Q(paypal_yearly_plan_id = paypal_plan_id)).first()

					subscription_data = dict(
						user_id = subscription.get('custom_id'),
						payer_email = subscription['subscriber']['email_address'],
						subscription_id = subscription['id'],
						plan_id = plan.id if plan else None,
						event = body['event_type'],
						status = subscription.get('status', ''),
					)
					PaypalWebhookModels.objects.create(**subscription_data)
			except:
				log_traceback(json_encode(body))
			try:
				event_type = body['event_type'].split('.')
				event_type = list(map(lambda x: x.lower(), event_type))
				if hasattr(self, f'webhook_{"_".join(event_type)}'):
					getattr(self, f'webhook_{"_".join(event_type)}')(body)
			except:
				log_traceback(json_encode(body))

		return HttpResponse(status = 200)


class PaypalSubscriptionCreate(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		body = request.data
		paypal_api = PaypalApi()
		return JsonResponse(paypal_api.create_custom_subscription(body))


class SubscriptionPickupApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		plan_id = CoreUtils().get_new_plan_default_id()
		plan = get_object_or_404(Subscription, pk = plan_id)
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user_by_request(request)
		yearly_billing = request.data.get('yearly_billing')

		if user.is_staff:
			new_plan = SubscriptionUtils().new_user_subscription_plan(user, plan, yearly_billing, **kwargs)
			return JsonResponse(ResponseObject(data = new_plan).to_dict())
		products_limit = to_int(request.data.get('products_limit')) or to_int(request.data.get('listings_limit'))
		channels_limit = to_int(request.data.get('channels_limit')) or to_int(request.data.get('channel_limit'))
		total_listing = ProductUtils().count_total_product_import(user_id)
		user.total_product = total_listing
		user.save()
		if total_listing > products_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_listing} products, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		total_channel = Channel.objects.filter(user_id = user.id, deleted_at__isnull = True, default = False).count()
		if total_channel > channels_limit:
			return JsonResponse(ErrorResponse(errors = f"You have {total_channel} channels, the plan you selected is not suitable. Please choose another plan.").to_dict(), status = 400)
		payment_method = PaymentUtils().get_payment_method_name(request)
		old_plan = SubscriptionUtils().get_plan_by_user(user)
		if old_plan['user_plan']['payment_method']:
			payment_method = old_plan['user_plan']['payment_method']
		if not old_plan['default'] and not old_plan.get('expired'):

			if payment_method != 'shopify':
				if to_int(plan.monthly_fee) < to_int(old_plan['monthly_fee']):
					return JsonResponse(ErrorResponse(errors = f"Your plan is currently: {old_plan['name']}, you can't choose a lower package.").to_dict(), status = 400)

		new_price = calculated_subscription_pricing(channels_limit, products_limit, yearly_billing)

		discount = 0
		upgraded = False
		if to_int(old_plan['id']) != 1 and not old_plan.get('expired') and new_price != to_int(old_plan['user_plan']['subscription_fee']):
			upgraded = True
			grand_total = SubscriptionUtils().new_remaining_price(old_plan, channels_limit, products_limit, yearly_billing)
			if yearly_billing and not grand_total:
				upgraded = False
			if not yearly_billing or grand_total:
				new_price = grand_total
		total = new_price
		discount_info = dict()
		coupon_code = request.data.get('coupon_code')
		# coupon_code = '123456'
		if coupon_code:
			validate_coupon = CouponUtils().verify_coupon(coupon_code, user, new_price, 'plan')
			if validate_coupon['result'] == 'success':
				discount = validate_coupon['data']['discount']
				total = validate_coupon['data']['total']
				discount_info = validate_coupon['data']
		# if total <= to_decimal(user.balance):
		# 	kwargs = dict()
		# 	if discount:
		# 		kwargs['discount'] = discount
		# 		kwargs['total'] = total
		# 		kwargs['discount_code'] = discount_info['code']
		# 	new_plan = SubscriptionUtils().new_user_subscription_plan(user, plan, yearly_billing, **kwargs)
		# 	return JsonResponse(ResponseObject(data = new_plan).to_dict())
		token = f"{to_int(time())}-{random_token()}"
		name = f"Upgrade Plan {old_plan['name']} => {plan.name}"
		if payment_method == 'shopify':
			prefix_name = 'Monthly'
			if yearly_billing:
				prefix_name = 'Yearly'
			name = f'LitCommerce: {prefix_name} Package for plan {channels_limit} Channels, {to_int(products_limit/1000)}K Listings'

		payment_information = {
			'token': token,
			"user_id": user.id,
			"amount": to_decimal(total) - to_decimal(user.balance),
			"balance": to_decimal(user.balance),
			"total": to_decimal(total),
			"subtotal": to_decimal(new_price),
			"return_url": get_app_url("subscription/change-success", user) if to_int(request.GET.get('first-setup')) != 1 else get_app_url('products', user),
			"cancel_url": get_app_url("subscription/change-error", user),
			"status": "pending",
			"type": "plan",
			"name": f"{name}",
			"plan_id": plan_id,
			"yearly_paid": 1 if yearly_billing else 0,
			"method": payment_method,
			"upgrade_plan": upgraded,
			'products_limit': products_limit,
			'channels_limit': channels_limit
		}
		if payment_information['method'] == PaymentUtils().get_payment_method_default() and old_plan.get('user_plan') and old_plan['user_plan'].get('payment_method'):
			payment_information['method'] = old_plan['user_plan'].get('payment_method')
		meta_data = AccountUtils().get_meta_data(request)
		if not meta_data:
			meta_data = {}
		meta_data['user_id'] = user_id
		if old_plan.get('user_plan') and old_plan['user_plan'].get('channel_payment'):
			meta_data['channel_payment'] = old_plan['user_plan'].get('channel_payment')
		if meta_data:
			payment_information['meta_data'] = json_encode(meta_data)
		if discount:
			payment_information['discount'] = discount
			payment_information['discount_code'] = discount_info['code']
		PaymentInformation.objects.create(**payment_information)
		return JsonResponse(ResponseObject(code = 'payment', data = get_full_absolute_uri('process_payment_token', {'token': token})).to_dict())
