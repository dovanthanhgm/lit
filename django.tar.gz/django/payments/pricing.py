from libs.utils import to_str, to_int

SUBSCRIPTION_PRICING = {
	'1000': 14,
	'2000': 29,
	'5000': 44,
	'10000': 69,
	'15000': 84,
	'20000': 99,
	'25000': 114,
	'50000': 204,
	'75000': 249,
	'100000': 294,
}
SUBSCRIPTION_PRICING_EACH_CHANNEL = 5
def calculated_subscription_pricing(channels_limit, products_limit, yearly_billing = False):
	total = SUBSCRIPTION_PRICING[to_str(products_limit)] + SUBSCRIPTION_PRICING_EACH_CHANNEL * to_int(channels_limit)
	if yearly_billing:
		total = round((total * 12) / 100 * 70)
	return total