from rest_framework import serializers

from payments.models import PaymentHistory


class PaymentHistorySerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)
	# payer_email = serializers.CharField(required = True, allow_null = False)


	def get_fields(self, *args, **kwargs):
		fields = super(PaymentHistorySerializer, self).get_fields(*args, **kwargs)
		request = self.context.get('request', None)
		if request and getattr(request, 'method', None) != "POST":
			fields['payer_email'].required = False
		return fields


	class Meta:
		model = PaymentHistory
		fields = ["id", "user_id", "payer_email", "transactionid", "amount", "discount", "total", "new_balance", "status", "note", "type", "name", "method", "created_at", "updated_at"]
