from django.urls import path, include

from . import views

urlpatterns = [
	path('/pickup-plan', views.SubscriptionPickupApiView.as_view(), name = 'pickup.plan'),
	path('/process', views.ProcessPaymentView.as_view(), name = 'process_payment'),
	path('/process-by-token/<str:token>', views.ProcessPaymentByTokenView.as_view(), name = 'process_payment_token'),
	path('/done/<str:token>', views.PaymentDoneView.as_view(), name = 'payment_done'),
	path('/canceled/<str:token>', views.PaymentCanceledView.as_view(), name = 'payment_canceled'),
	path('/history', views.PaymentHistoryView.as_view()),
	path('/history/<int:pk>', views.PaymentHistoryDetailsView.as_view()),
	path('/paypal/', include([
		path('order/', include([
			path('create', views.PaypalCreateOrder.as_view()),
			path('capture/<str:order_id>', views.PaypalCaptureOrder.as_view()),
		])),
		path('subscription/', include([
			path('create', views.PaypalSubscriptionCreate.as_view(), name = 'paypal.subscription.create'),
			path('revise/done/<str:token>', views.PaypalUpgradeSubscriptionCallback.as_view(), name = 'paypal_revise_subscription_callback_done'),
			path('revise/cancelled/<str:token>', views.PaypalUpgradeSubscriptionCallback.as_view(), name = 'paypal_revise_subscription_callback_cancel'),
			path('upgrade/<str:plan_id>', views.PaypalUpgradeSubscription.as_view()),
			path('select/<str:plan_id>', views.PaypalSelectSubscription.as_view()),
			path('pickup', views.PaypalPickupSubscription.as_view()),
			path('approve/<str:subscription_id>', views.PaypalApproveOrder.as_view()),
		])),
		path('webhook', include([
			path('', views.PaypalWebhook.as_view()),
		])),
	])),
]
