from django.db import models
from django.db import models

from accounts.models import UserAccount
from subscription.models import Subscription


class PaymentInformation(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	amount = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	discount = models.DecimalField(decimal_places = 2, max_digits = 12, null = True, default = 0)
	total = models.DecimalField(decimal_places = 2, max_digits = 12, null = True, default = 0)
	balance = models.DecimalField(decimal_places = 2, max_digits = 12, null = True, default = 0)
	subtotal = models.DecimalField(decimal_places = 2, max_digits = 12, null = True, default = 0)
	discount_code = models.CharField(null = True, max_length = 255)
	token = models.TextField(null = False)
	return_url = models.CharField(null = True, max_length = 255)
	cancel_url = models.CharField(null = True, max_length = 255)
	status = models.CharField(max_length = 25, choices = (('paid', 'paid'), ('canceled', 'canceled'), ('pending', 'pending')))
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	type = models.CharField(max_length = 25, choices = (('add_func', 'add_func'), ('plan', 'plan')), default = 'add_func')
	note = models.TextField(null = True)
	name = models.CharField(null = True, max_length = 255)
	plan_id = models.IntegerField(null = True)
	yearly_paid = models.IntegerField(null = True, choices = (('0', 'No'), ("1", "Yes")))
	method = models.CharField(null = True, max_length = 255)
	paypal_order_id = models.CharField(null = True, max_length = 255)
	paypal_tracking_id = models.CharField(null = True, max_length = 255)
	meta_data = models.TextField(null = True)
	custom = models.TextField(null = True)
	upgrade_plan = models.BooleanField(default = False, null = False)
	products_limit = models.IntegerField(null = True, blank = True)
	orders_limit = models.IntegerField(null = True, blank = True)
	channels_limit = models.IntegerField(null = True, blank = True)

	class Meta:
		db_table = "payment_information"


class PaymentHistory(models.Model):
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = False)
	payer_email = models.CharField(max_length = 255, null = True, default = '')
	transactionid = models.CharField(max_length = 255, null = True, default = '')
	amount = models.DecimalField(decimal_places = 2, max_digits = 12, null = False, default = 0)
	discount = models.DecimalField(decimal_places = 2, max_digits = 12, null = True)
	discount_code = models.CharField(null = True, blank = True, max_length = 255)
	subtotal = models.DecimalField(decimal_places = 2, max_digits = 12, null = True)
	balance = models.DecimalField(decimal_places = 2, max_digits = 12, null = True)
	total = models.DecimalField(decimal_places = 2, max_digits = 12, null = True)
	new_balance = models.DecimalField(decimal_places = 2, max_digits = 12, null = True)
	status = models.CharField(null = True, max_length = 25)
	note = models.TextField(null = True)
	type = models.CharField(null = True, max_length = 25, choices = (('add_func', 'add_func'), ('plan', 'Plan'), ('custom', 'Custom'), ('aio', 'AIO')))
	method = models.CharField(null = True, max_length = 25, choices = (('paypal', 'Paypal'), ('shopify', 'Shopify'), ('wix', 'Wix')), blank = True)
	token = models.CharField(null = True, max_length = 255)
	name = models.CharField(null = True, max_length = 255)
	ipn_id = models.IntegerField(null = True)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	custom = models.TextField(null = True)


	class Meta:
		db_table = "payment_history"
		app_label = 'litcommerce_order'
		verbose_name = 'Payment History'
		verbose_name_plural = 'Payment History'


class PaypalPlan(models.Model):
	product_id = models.CharField(null = False, max_length = 125, blank = False)
	paypal_plan_id = models.CharField(null = False, max_length = 125, blank = False)
	name = models.CharField(null = False, max_length = 125, blank = False)
	plan = models.ForeignKey(Subscription, on_delete = models.CASCADE, null = False)


	class Meta:
		db_table = "paypal_plan"


class PaypalSubscriptionActive(models.Model):
	user_id = models.IntegerField(null = False)
	subscription_id = models.CharField(null = False, max_length = 125)


	class Meta:
		db_table = 'paypal_subscription_active'


class PaypalWebhookModels(models.Model):
	user_id = models.IntegerField(null = False)
	user_email = models.CharField(max_length = 125)
	payer_email = models.CharField(max_length = 125)
	subscription_id = models.CharField(max_length = 125)
	plan = models.ForeignKey(Subscription, on_delete = models.CASCADE, null = True)
	event = models.CharField(max_length = 125)
	status = models.CharField(max_length = 125)
	created_at = models.DateTimeField(auto_now_add = True)
	class Meta:
		db_table = 'paypal_webhook_event'