import base64
import hashlib
import hmac

import jwt
from django.http import HttpResponseForbidden, HttpResponseNotFound, HttpResponse
from django.shortcuts import get_object_or_404
from paypalrestsdk import WebhookEvent

from channels.models import Channel
from core.middleware import CustomMiddleware
from datasync_django import settings
from libs.utils import json_decode, base64_to_string, get_private_key, to_int, to_str, log
from merchant.shopify.models import ShopifyApp
from merchant.shopify.utils import MerchantShopifyUtils, is_local


class PaypalWebHookMiddleware(CustomMiddleware):
	NAME = 'payments.middleware.PaypalWebHookMiddleware'


	def process_middleware(self, request, view_func, view_args, view_kwargs):
		transmission_id = request.headers.get('Paypal-Transmission-Id')
		timestamp = request.headers.get('Paypal-Transmission-Time')
		actual_signature = request.headers.get('Paypal-Transmission-Sig')
		cert_url = request.headers.get('Paypal-Cert-Url')
		auth_algo = request.headers.get('PayPal-Auth-Algo')
		webhook_id = settings.PAYPAL_WEBHOOK_ID
		if not transmission_id or not timestamp or not actual_signature or not cert_url or not auth_algo or not webhook_id:
			return HttpResponse(status = 401)
		event_body = request.body
		if isinstance(event_body, bytes):
			event_body = event_body.decode()
		try:
			response = WebhookEvent.verify(transmission_id, timestamp, webhook_id, event_body, cert_url, actual_signature, auth_algo)
		except:
			response = False
		if response:
			return None
		return HttpResponse(status = 401)

class ShopifyMandatoryWebHookMiddleware(CustomMiddleware):
	NAME = 'merchant.shopify.middleware.ShopifyMandatoryWebHookMiddleware'


	def process_middleware(self, request, view_func, view_args, view_kwargs):
		data_log = dict()
		hmac_header = request.headers.get('X-Shopify-Hmac-SHA256')
		data = request.body
		if isinstance(data, bytes):
			data = data.decode()
		data_log['data'] = data
		data_log['hmac_header'] = hmac_header
		log(data_log)
		if not hmac_header:
			return HttpResponse(status = 401)
		shopify_app = ShopifyApp.objects.all()

		for app in shopify_app:
			secret_key = app.api_shared_secret
			digest = hmac.new(secret_key.encode(), data.encode('utf-8'), hashlib.sha256).digest()
			computed_hmac = base64.b64encode(digest)
			if hmac.compare_digest(computed_hmac, hmac_header.encode('utf-8')):
				return None
		return HttpResponse(status = 401)