from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from paypal.standard.ipn.models import PayPalIPN

from core.myadmin.admin import CoreAdmin, UserFilter, FieldContainFilter
from .models import PaymentHistory


class TransFilter(FieldContainFilter):
	parameter_name = 'transactionid'
	title = ('Transaction Id')


class PaymentUserFilter(UserFilter):
	def query_none_filter(self, queryset):
		return queryset.filter(payer_email__contains = self.value())


class PaymentHistoryAdmin(CoreAdmin):
	list_display = ['id', 'user_link', 'payer_email', 'transactionid', 'amount', 'subtotal', 'discount', 'total', 'balance', 'new_balance',
	                'status', 'note', 'type', 'method', 'token', 'name', 'ipn_id', 'created_at', 'updated_at']
	list_filter = ['created_at', 'status', PaymentUserFilter, TransFilter, 'type', 'method']


	def has_add_permission(self, request, obj = None):
		return False


	def has_delete_permission(self, request, obj = None):
		return False


	def has_change_permission(self, request, obj = None):
		return False


	def user_link(self, obj):
		url = reverse("admin:accounts_useraccount_change", args = (obj.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.user.email}</a>")


admin.site.unregister(PayPalIPN)
admin.site.register(PaymentHistory, PaymentHistoryAdmin)
