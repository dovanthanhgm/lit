from django.apps import AppConfig


class ErrorTemplateConfig(AppConfig):
    name = 'error_template'
