from django.contrib import admin

# Register your models here.
from core.myadmin.admin import CoreAdmin
from error_templates.models import ErrorTemplates


class ErrorTemplateAdmin(CoreAdmin):
	search_fields = ['channel']
	list_filter = ['channel']
	list_display = ['channel', 'search_by', 'search_input', 'belong_to_tab', 'belong_to_field']


admin.site.register(ErrorTemplates, ErrorTemplateAdmin)
