from django.db import models
from tinymce.models import HTMLField

from channels.models import choices_channel


class ErrorTemplates(models.Model):
	channel = models.CharField(max_length = 255, choices = choices_channel())
	search_by = models.CharField(max_length = 25, choices = (('start_with', 'Start With'), ('contains', 'Contains')))
	search_input = models.TextField(null = False)
	belong_to_tab = models.CharField(max_length = 125, choices = (('category', 'Category'), ('title', 'Title & Description'), ('images', 'Images'), ('price', 'Pricing/Variants'), ('payment', 'Payment & Return'), ('shipping', 'Shipping'), ('identifier', 'Identifier'), ('personalization', 'Personalization'), ('offer', 'Offer'), ('amz_product_type', 'Amazon Listing Details'), ('business', 'Ebay Business Policies'), ('amz_seo', 'Amazon SEO')), null = True, blank = True)
	belong_to_field = models.CharField(max_length = 125, null = True, blank = True)
	error_template = HTMLField()


	class Meta:
		db_table = 'error_templates'
		ordering = ['-id']
