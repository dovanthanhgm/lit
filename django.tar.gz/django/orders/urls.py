from django.urls import path, include

from orders import views

urlpatterns = [
	path('/orders', include([
		path('', views.OrderAPIView.as_view(), name = 'orders'),
		path('/report', views.ReportOrderAPI.as_view(), name = 'orders.report'),
        path('/detail', views.ReportOrderDetailAPI.as_view(), name = 'orders.detail'),
		path('/processed-in-channel', views.ProcessInChannelApi.as_view(), name = 'orders.process_in_channel'),
		path('/sync-list-order', views.ListOrderSyncStatusApi.as_view(), name = 'orders.sync_list'),
		path('/count', views.OrderAPICount.as_view(), name = 'orders.count'),
		path('/downloads', views.OrderExportCsv.as_view(), name = 'orders.downloads'),
		path('/<str:order_id>', include([
			path('', views.OrderDetailAPIView.as_view(), name = 'orders.details'),
			path('/sync-status', views.OrderSyncStatusApi.as_view(), name = 'orders.details.sync_status'),
			path('/history', include([
				path('', views.OrderHistoryAPIView.as_view(), name = 'orders.history'),
				path('/<history_id>', views.OrderHistoryDetailAPIView.as_view(), name = 'orders.history.details')
			])),
			path('/inventories', views.OrderInventoriesAPIView.as_view(), name = 'orders.inventories'),
			path('/shipments', include([
				path('/fba', views.SendToFBAAPIView.as_view(), name = 'orders.shipments.fba'),
			]))
		])),
	])),
	path('/shipments', include([
		path('', views.ShipmentAPIView.as_view(), name = 'shipments'),
	]))
]
