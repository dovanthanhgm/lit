import time
from rest_framework import serializers

from libs.utils import get_current_time, to_int, to_str
from libs.models.collections.catalog import Catalog
from warehouse_locations.utils import WarehouseLocationUtils
from channels.utils import ChannelUtils


class OrderStatusSerializer(serializers.Serializer):
	ORDER_STATUS = ('open', 'awaiting_payment', 'ready_to_ship', 'shipping', 'completed', 'canceled')
	status = serializers.ChoiceField(choices = ORDER_STATUS)


class OrderDistributionSerializer(serializers.Serializer):
	product_id = serializers.CharField()
	warehouse_inventories = serializers.DictField(child = serializers.IntegerField())

	def __init__(self, *args, **kwargs):
		super(OrderDistributionSerializer, self).__init__(*args, **kwargs)
		if not self.context.get('model_catalog'):
			raise TypeError("Missing required context argument: 'model_catalog'")
		if not self.context.get('order_data'):
			raise TypeError("Missing required context argument: 'order_data'")


	def validate_product_id(self, product_id):
		order_data = self.context['order_data']
		model_catalog = self.context['model_catalog']
		try:
			product_data = model_catalog.get(product_id)
			if not product_data:
				raise serializers.ValidationError('Invalid product_id')
		except Exception:
			raise serializers.ValidationError('Invalid product_id')
		if product_id not in order_data['products']:
			raise serializers.ValidationError('Invalid product_id')
		self.context['product_data'] = self.reverse_product_inventories(product_data)
		return product_id


	def validate(self, validated_data):
		warehouse_inventories = validated_data['warehouse_inventories']
		order_data = self.context['order_data']
		product_data = self.context['product_data']
		product_id = product_data['_id']
		order_product_data = order_data['products'][product_id]
		validated_warehouse_locations = dict()
		total_qty = 0
		for location_id, qty in warehouse_inventories.items():
			if location_id in product_data['inventories']['inventory']:
				total_available = product_data['inventories']['inventory'][location_id]['on_hand']
				qty = min(qty, total_available)
				validated_warehouse_locations[location_id] = qty
				total_qty += qty
		if not validated_warehouse_locations or total_qty > order_product_data['qty']:
			raise serializers.ValidationError({'warehouse_inventories': 'Invalid warehouse_locations'})
		validated_data['warehouse_inventories'] = validated_warehouse_locations
		validated_data['product_data'] = product_data
		return validated_data


	def reverse_product_inventories(self, product_data):
		order_data = self.context['order_data']
		product_id = product_data['_id']
		order_product_data = order_data['products'].get(product_id)
		if not order_product_data:
			return product_data
		if order_data['status'] in ['completed', 'canceled']:
			return product_data
		inventories = product_data['inventories']
		for location_id, qty in order_product_data.get('warehouse_inventories', {}).items():
			if location_id in inventories['inventory']:
				inventory = inventories['inventory'][location_id]
				inventory['reserved'] -= qty
				inventory['on_hand'] += qty
		for field in ('available', 'reserved', 'on_hand'):
			inventories[f'total_{field}'] = sum(inventory[field] for inventory in inventories['inventory'].values())
		product_data['inventories'] = inventories
		return product_data


class FBAShipmentSerializer(serializers.Serializer):
	SHIPPING_SPEED_CHOICES = ('Standard', 'Expedited', 'Priority')
	products = serializers.DictField(child = serializers.IntegerField())  # products = {<str:product_id>: <int:qty>}
	location_id = serializers.IntegerField()
	shipping_speed = serializers.ChoiceField(choices = SHIPPING_SPEED_CHOICES)


	def __init__(self, *args, **kwargs):
		super(FBAShipmentSerializer, self).__init__(*args, **kwargs)
		if not self.context.get('order_data'):
			raise TypeError("Missing required context argument: 'order_data'")
		if not self.context.get('user_id'):
			raise TypeError("Missing required context argument: 'user_id'")


	def validate_location_id(self, location_id):
		user_id = self.context['user_id']
		fba_location = WarehouseLocationUtils().get_fba_location(user_id = user_id, id = location_id)
		if not fba_location:
			raise serializers.ValidationError('Invalid fba location_id')
		self.context['fba_location'] = fba_location
		amazon_channel = ChannelUtils().get(fba_location.channel_id)
		if not amazon_channel:
			raise serializers.ValidationError('Invalid fba location - invalid channel_id')
		self.context['fba_channel'] = amazon_channel
		return location_id


	def validate(self, validated_data):
		products = validated_data['products']
		location_id = to_str(validated_data['location_id'])
		order_data = self.context['order_data']
		user_id = self.context['user_id']
		validated_products = dict()
		for product_id, shipment_qty in products.items():
			if product_id not in order_data['product_ids'] or product_id not in order_data['products']:
				continue
			order_product_data = order_data['products'][product_id]
			if location_id not in order_product_data['warehouse_inventories']:
				continue
			shipment_qty = min(shipment_qty, order_product_data['warehouse_inventories'][location_id])
			validated_products[product_id] = shipment_qty
		if not validated_products:
			raise serializers.ValidationError({'products': 'Invalid products. Products might not have fba inventories'})
		model_catalog = Catalog()
		model_catalog.set_user_id(user_id)
		product_ids = list(validated_products.keys())
		products_ext = model_catalog.find_all(
			model_catalog.create_where_condition('_id', product_ids, 'in')
		)
		if not products_ext:
			raise serializers.ValidationError({'products': 'Invalid products. Products might not have fba inventories or have been deleted'})
		self.context['products_ext'] = products_ext
		validated_data['products'] = validated_products
		return validated_data


class OrderHistorySerializer(serializers.Serializer):
	id = serializers.HiddenField(default = lambda: to_int(time.time()))
	code = serializers.HiddenField(default = '')
	status = serializers.HiddenField(default = '')
	comment = serializers.CharField()
	source = serializers.HiddenField(default = 'api')
	created_at = serializers.HiddenField(default = get_current_time)
	updated_at = serializers.HiddenField(default = get_current_time)


class ProductShipmentSerializer(serializers.Serializer):
	id = serializers.CharField(default = '')
	code = serializers.CharField(default = '')
	product_id = serializers.CharField(default = '')
	product_sku = serializers.CharField(default = '')
	product_name = serializers.CharField(default = '')
	qty = serializers.IntegerField(default = 0)
	shipped_qty = serializers.IntegerField(default = 0)
	carrier = serializers.CharField(default = '')
	shipped_at = serializers.CharField(default = '')
	estimated_arrival_at = serializers.CharField(default = '')
	tracking_number = serializers.CharField(default = '')


class ShipmentSerializer(serializers.Serializer):
	STATUS_CHOICES = (
		'completed',
		'processing',
		'canceled',
	)
	id = serializers.CharField(default = '')
	fulfillment_id = serializers.CharField(default = '')
	tracking_number = serializers.CharField(default = '')
	status = serializers.ChoiceField(choices = STATUS_CHOICES, default = 'processing')
	order_id = serializers.CharField(default = '')
	channel_order_number = serializers.CharField(default = '')
	channel_id = serializers.CharField(default = '')
	carrier = serializers.CharField(default = '')
	products = serializers.ListSerializer(child = ProductShipmentSerializer(), allow_empty = True, default = [])
	shipping_address = serializers.DictField(default = {})
	location_id = serializers.CharField(default = '')
	created_at = serializers.CharField(default = '')
	shipped_at = serializers.CharField(default = '')
	error_message = serializers.CharField(default = '')
