from accounts.permission import IsLoginByToken
from libs.utils import is_local


class IsDeleteAllOrder(IsLoginByToken):
	def has_permission(self, request, view):
		if request.method != 'DELETE' or is_local():
			return True
		check = super().has_permission(request, view)
		if not check:
			return False
		return self._admin.has_perm('orders.delete_all')

