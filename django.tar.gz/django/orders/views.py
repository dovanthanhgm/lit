from datetime import timedelta

from django.http.response import JsonResponse, HttpResponseForbidden, HttpResponseNotFound, HttpResponse
from django.utils.decorators import method_decorator
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, status, views

from accounts.utils import AccountUtils
from channels.models import Channel
from channels.utils import ChannelUtils
from processes.models import Process
from core.permission import IsPrivate
from core.responses import PaginationResponse, ResponseObject, ErrorResponse
from datasync.api.sync import SyncApi
from libs.models.collections.catalog import Catalog
from libs.models.collections.order import CollectionOrder
from libs.models.collections.shipment import Shipment
from libs.utils import *
from products.utils import ProductUtils
from .permission import IsDeleteAllOrder
from .serializers import OrderStatusSerializer, OrderHistorySerializer, OrderDistributionSerializer, FBAShipmentSerializer, \
	ProductShipmentSerializer, ShipmentSerializer

@method_decorator(name = 'get', decorator = swagger_auto_schema(
	manual_parameters = [
		openapi.Parameter('limit', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('sort', openapi.IN_QUERY, type = openapi.TYPE_STRING),
		openapi.Parameter('page', openapi.IN_QUERY, type = openapi.TYPE_INTEGER),
		openapi.Parameter('status', openapi.IN_QUERY, type = openapi.TYPE_STRING),
		openapi.Parameter('min_date', openapi.IN_QUERY, type = openapi.TYPE_STRING, default = '%Y-%m-%d'),
		openapi.Parameter('max_date', openapi.IN_QUERY, type = openapi.TYPE_STRING, default = '%Y-%m-%d'),
		openapi.Parameter('query', openapi.IN_QUERY, type = openapi.TYPE_STRING),
		openapi.Parameter('channel_id', openapi.IN_QUERY, type = openapi.TYPE_STRING),
		openapi.Parameter('archived', openapi.IN_QUERY, type = openapi.TYPE_STRING, default = 'false'),
	]
))
class OrderAPIView(generics.ListAPIView):
	FILTER_FIELD = ('status', 'min_date', 'max_date', 'query', 'channel_id', 'is_assigned')
	SORT_FIELD = ('created_at', 'status', 'number_order', 'total', 'updated_at',
	              '-created_at', '-status', '-number_order', '-total', '-updated_at')

	permission_classes = (IsDeleteAllOrder,)

	@staticmethod
	def get_condition_from_request(request, model_order, **kwargs):
		where = dict()
		min_date = request.GET.get('min_date')
		max_date = request.GET.get('max_date')
		status = request.GET.get('status')
		channel_id = request.GET.get('channel_id')
		archived = request.GET.get('archived')
		query = request.GET.get('query')
		is_assigned = request.GET.get('is_assigned')
		link_status = request.GET.get('link_status')

		if archived and archived == 'true':
			archived_day = datetime.today() - timedelta(days = 90)
			max_date = archived_day.strftime('%Y-%m-%d')
		if min_date or max_date:
			where.update(model_order.create_where_condition('created_at', (min_date, max_date), 'erange'))
		if status:
			if status != 'error':
				where.update(model_order.create_where_condition('status', status))
			else:
				where.update(model_order.create_where_condition('status', ['processed_in_channel', 'deleted'], 'nin'))

				channel_default = ChannelUtils().get_default_channel(AccountUtils().get_user_id(request))
				where.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.status', 'error'))
			# where.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.link_status', 'linked'))
		# where.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.link_status', 'linked'))
		else:
			where.update(model_order.create_where_condition('status', 'deleted', '!='))

		if channel_id:
			where.update(model_order.create_where_condition(f'channel.channel_{channel_id}.status', 'active'))
		# if is_assigned and is_assigned == 'true':
		# 	where.update(model_order.create_where_condition('is_assigned', True))
		# elif is_assigned and is_assigned == 'false':
		# 	where.update(model_order.create_where_condition('is_assigned', False))
		if link_status:
			channel_default = ChannelUtils().get_default_channel(AccountUtils().get_user_id(request))
			where.update(model_order.create_where_condition('status', ['processed_in_channel', 'deleted'], 'nin'))

			where.update(model_order.create_where_condition('link_status', link_status))
			where.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.status', 'error', '!='))

		if query:
			where_query = list()
			where_query.append(model_order.create_where_condition('order_number', query, 'like'))
			where_query.append(model_order.create_where_condition('channel_order_number', query, 'like'))
			where_query.append(model_order.create_where_condition('customer.username', query, 'like'))
			where_query.append(model_order.create_where_condition('customer.email', query, 'like'))
			where_query.append(model_order.create_where_condition('customer.first_name', query, 'like'))
			where_query.append(model_order.create_where_condition('customer.middle_name', query, 'like'))
			where_query.append(model_order.create_where_condition('customer.last_name', query, 'like'))
			where_query.append(model_order.create_where_condition('products', {'$elemMatch': model_order.create_where_condition('product_name', query, 'like')}))
			where_query.append(model_order.create_where_condition('products', {'$elemMatch': model_order.create_where_condition('product_sku', query, 'like')}))
			channels = Channel.objects.filter(user_id = AccountUtils().get_user_id(request), deleted_at = None).exclude(type__in = ('litcommerce', 'file'))
			for channel in channels:
				if to_int(to_str(query).split(',')) == 1:
					where_query.append(model_order.create_where_condition(f'channel.channel_{channel.id}.order_number', query, 'like'))
					where_query.append(model_order.create_where_condition(f'channel.channel_{channel.id}.order_id', query, 'like'))
				else:
					list_order = to_str(query).split(',')
					list_order = list(map(lambda x: x.strip(' ,;'), list_order))
					where_query.append(model_order.create_where_condition(f'channel.channel_{channel.id}.order_number', list_order, 'in'))
					where_query.append(model_order.create_where_condition(f'channel.channel_{channel.id}.order_id', list_order, 'in'))
			where_or = model_order.create_where_condition(None, where_query, 'or')
			where = model_order.create_where_condition(None, [where, where_or], 'and')
		return where

	@staticmethod
	def process_order_data_before_return(orders, request, *args, **kwargs):
		for order in orders:
			order_id = order['_id']
			order['id'] = order_id
			del order['_id']
		# order['products'] = list(order['products'])
		return orders

	def select_fields(self):
		return None

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		where = self.get_condition_from_request(request, model_order, **kwargs)
		# order_status_where = copy.deepcopy(where)

		limit = request.GET.get('limit')
		if not limit:
			limit = 20
		page = request.GET.get('page')
		if not page:
			page = 1
		sort_by = request.GET.get('sort')
		if not sort_by or sort_by not in self.SORT_FIELD:
			sort_by = '-created_at'
		orders = model_order.find_all(where, limit = limit, pages = page, sort = sort_by, select_fields = self.select_fields())
		data = {
			"count": model_order.count(where),
			"data": self.process_order_data_before_return(orders, request, *args, **kwargs),
		}
		return JsonResponse(PaginationResponse(**data).to_dict(), safe = False)

	def put(self, request, *args, **kwargs):
		request_data = request.data
		if not request_data or not isinstance(request_data, dict) or not request_data.get('order_ids'):
			return JsonResponse(ResponseObject(status = 400, message = 'Data invalid').to_dict(), status = 400)
		order_ids = request_data['order_ids']
		if order_ids and not isinstance(order_ids, list):
			order_ids = [order_ids]
		model_order = CollectionOrder()
		model_order.set_user_id(AccountUtils().get_user_id(request))
		where = model_order.create_where_condition('_id', order_ids, 'in')
		where.update(model_order.create_where_condition(f'updating', True))
		order_in_process = model_order.find_all(where, select_fields = '_id')
		order_id_in_process = [row['_id'] for row in order_in_process]
		order_valid = list(set(order_ids) - set(order_id_in_process))
		if order_ids:
			model_order.update_many(model_order.create_where_condition('_id', order_valid, 'in'), {'updating': True})
			update = SyncApi(user_id = AccountUtils().get_user_id(request)).api('order', {'order_ids': order_ids}, method = 'put')
		return HttpResponse(status = 204)

	def delete(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		model_order.delete_all()
		ProductUtils().reset_pull(user_id, process_type = 'order')

		data = {"message": "delete success"}
		return JsonResponse(data, safe = False)

class OrderAPICount(OrderAPIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		where = self.get_condition_from_request(request, model_order, **kwargs)
		data = dict()
		for order_status in ['open', 'awaiting_payment', 'ready_to_ship', 'shipping', 'completed', 'canceled', 'refunded', 'partially_refunded', 'processed_in_channel']:
			# order_status_where = copy.deepcopy(where)
			where.update(model_order.create_where_condition('status', order_status))
			data[order_status] = model_order.count(where)
		total = sum(data.values())
		data['count'] = total
		del where['status']
		channel_default = ChannelUtils().get_default_channel(user_id)

		where.update(model_order.create_where_condition('link_status', 'unlink'))
		where.update(model_order.create_where_condition('status', ['processed_in_channel', 'deleted'], 'nin'))
		where.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.status', 'error', '!='))

		data['unlink'] = model_order.count(where)
		del where['link_status']
		del where[f'channel.channel_{channel_default.id}.status']
		where.update(model_order.create_where_condition(f'channel.channel_{channel_default.id}.status', 'error'))
		data['error'] = model_order.count(where)
		return JsonResponse(data, safe = False)

@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = OrderStatusSerializer
))
class OrderDetailAPIView(generics.RetrieveUpdateAPIView):
	@staticmethod
	def process_order_data_before_return(order):
		order_id = order['_id']
		order['id'] = order_id
		del order['_id']
		# order['products'] = list(order['products'].values())
		return order

	def get(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		# model_shipment = Shipment()
		# model_shipment.set_user_id(user_id)
		model_catalog = Catalog()
		model_catalog.set_user_id(user_id)
		try:
			order = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order:
			return HttpResponseNotFound()
		# shipments = model_shipment.find_all(model_shipment.create_where_condition('order_id', order['_id']))
		# order['shipments'] = shipments
		# products = model_catalog.find_all(model_catalog.create_where_condition('_id', list(order['product_ids']), 'in'))
		# products = {product['_id']: product for product in products}
		# product_order = []
		# for product in order['products']:
		# 	# product_id = product['id']
		# 	# if product_id in products.keys():
		# 	# 	product['import_status'] = products[product_id]['import_status']
		# 	# else:
		# 	# 	product['import_status'] = 'draft'
		# 	product_order.append(product)
		# order['products'] = product_order
		data = self.process_order_data_before_return(order)
		return JsonResponse(ResponseObject(data = data).to_dict(), safe = False)

	def put(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order:
			return HttpResponseNotFound()
		status_serializer = OrderStatusSerializer(data = request.data)
		if status_serializer.is_valid():
			status_data = status_serializer.validated_data
			update_field = status_data
			model_order.update(order_id, update_field)
			return HttpResponse(status = 200)
		else:
			return JsonResponse(ErrorResponse(errors = status_serializer.errors), status = 400)

class ListOrderSyncStatusApi(generics.UpdateAPIView):
	permission_classes = [IsPrivate]
	def post(self, request, *args, **kwargs):
		order_ids = request.data.get('order_ids')
		if order_ids:
			sync = SyncApi(user_id = AccountUtils().get_user_id(request)).post(f"order/sync-list", {'order_ids':order_ids})
			if sync['result'] != 'success':
				return JsonResponse(ErrorResponse(errors = sync.get('msg')).to_dict(), status = 400)
		return HttpResponse(status = 204)


class OrderSyncStatusApi(generics.UpdateAPIView):
	def put(self, request, *args, **kwargs):
		sync = SyncApi(user_id = AccountUtils().get_user_id(request)).put(f"order/sync/{kwargs['order_id']}")
		if sync['result'] != 'success':
			return JsonResponse(ErrorResponse(errors = sync.get('msg')).to_dict(), status = 400)
		return HttpResponse(status = 204)

@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = OrderHistorySerializer,
	responses = {
		status.HTTP_201_CREATED: OrderHistorySerializer
	}
))
class OrderHistoryAPIView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order:
			return HttpResponseNotFound()
		history_serializer = OrderHistorySerializer(data = request.data)
		if history_serializer.is_valid():
			history_data = history_serializer.validated_data
			update_data = {'$push': {'history': history_data}}
			model_order.update(order_id, update_data, raw = True)
			return JsonResponse(ResponseObject(data = history_data).to_dict(), status = 201)
		else:
			return JsonResponse(ErrorResponse(errors = history_serializer.errors).to_dict(), status = 400)

@method_decorator(name = 'put', decorator = swagger_auto_schema(
	request_body = OrderHistorySerializer,
	responses = {
		status.HTTP_201_CREATED: OrderHistorySerializer
	}
))
class OrderHistoryDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
	def get(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		history_id = kwargs['history_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order:
			return HttpResponseNotFound()
		history = get_row_from_list_by_field(order['history'], 'id', history_id)
		if not history:
			return HttpResponseNotFound()
		return JsonResponse(ResponseObject(data = history).to_dict(), safe = False, status = 200)

	def put(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		history_id = kwargs['history_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order:
			return HttpResponseNotFound()
		history, index = None, None
		for row_index, row in enumerate(order['history']):
			if str(history_id) == str(row['id']):
				history, index = row, row_index
		if not history:
			return HttpResponseNotFound()
		history_serializer = OrderHistorySerializer(data = request.data)
		if history_serializer.is_valid():
			history_data = history_serializer.validated_data
			history_data['id'] = history_id
			history_data['created_at'] = history['created_at']
			update_data = {f'history.{index}': history_data}
			model_order.update(order_id, update_data)
			return JsonResponse(ResponseObject(data = history_data).to_dict(), status = 200)
		else:
			return JsonResponse(ErrorResponse(errors = history_serializer.errors).to_dict(), status = 400)

	def delete(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		history_id = kwargs['history_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order:
			return HttpResponseNotFound()
		history = get_row_from_list_by_field(order['history'], 'id', history_id)
		if not history:
			return HttpResponseNotFound()
		delete_data = {'$pull': {'history': history}}
		model_order.update(order_id, delete_data, raw = True)
		data = {
			'message': f'Delete history_id: {history_id} complete.'
		}
		return JsonResponse(data = data, safe = False, status = 204)

class OrderExportCsv(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		data = {
			"start_date": request.data.get('start_date'),
			"end_date": request.data.get('end_date')
		}
		user_id = AccountUtils().get_user_id(request)
		export = SyncApi(user_id = user_id).post(f"order/export", data = data)
		if not export or export['result'] != 'success':
			return JsonResponse(ErrorResponse(errors = "Server error").to_dict(), status = 400)
		return HttpResponse(status = 201)

class OrderInventoriesAPIView(generics.UpdateAPIView):
	def put(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order_data = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order_data:
			return HttpResponseNotFound()
		if order_data['status'] in ['completed', 'canceled']:
			return JsonResponse(ErrorResponse(errors = {'order_id': ['Order has been completed or canceled']}).to_dict(), status = 400)
		model_catalog = Catalog()
		model_catalog.set_user_id(user_id)
		context = {
			'order_data': order_data,
			'model_catalog': model_catalog
		}
		inventories_serializer = OrderDistributionSerializer(data = request.data, context = context)
		if inventories_serializer.is_valid():
			validated_data = inventories_serializer.validated_data
			product_data = validated_data['product_data']
			product_id = validated_data['product_id']
			warehouse_inventories = validated_data['warehouse_inventories']
			inventories = product_data['inventories']
			for location_id, qty in warehouse_inventories.items():
				inventory = inventories['inventory'][location_id]
				inventory['reserved'] += qty
				inventory['on_hand'] -= qty
			for field in ('available', 'reserved', 'on_hand'):
				inventories[f'total_{field}'] = sum(inventory[field] for inventory in inventories['inventory'].values())
			model_catalog.update_field(product_id, 'inventories', inventories)
			if product_data['parent_id']:
				model_catalog.update_parent_product_inventories(product_data['parent_id'])
			update_fields = {
				f'products.{product_id}.warehouse_inventories': warehouse_inventories
			}
			# Check order has been assigned inventories location.
			order_data['products'][product_id]['warehouse_inventories'] = warehouse_inventories
			if warehouse_inventories:
				update_fields['is_assigned'] = True
			model_order.update_fields(order_id, update_fields)
			return HttpResponse(status = 204)
		return JsonResponse(ErrorResponse(errors = inventories_serializer.errors).to_dict(), status = 400)

class ShipmentAPIView(generics.ListAPIView):
	FILTER_FIELD = ('status', 'min_ship_date', 'max_ship_date', 'query', 'channel_id')
	SORT_FIELD = ('status', 'channel_order_number', 'channel_id', 'fulfillment_id', 'location_id', 'tracking_number',
	              'created_at', 'shipped_at', 'carrier')

	@staticmethod
	def get_condition_from_request(request, model_shipment, **kwargs):
		where = dict()
		min_date = request.GET.get('min_ship_date')
		max_date = request.GET.get('max_ship_date')
		status = request.GET.get('status')
		channel_id = request.GET.get('channel_id')
		query = request.GET.get('query')

		if min_date or max_date:
			where.update(model_shipment.create_where_condition('shipped_at', (min_date, max_date), 'erange'))
		if status:
			where.update(model_shipment.create_where_condition('status', status))
		if channel_id:
			where.update(model_shipment.create_where_condition('channel_id', channel_id))
		if query:
			where_query = list()
			where_query.append(model_shipment.create_where_condition('carrier', query, 'like'))
			where_query.append(model_shipment.create_where_condition('channel_order_number', query, 'like'))
			where_query.append(model_shipment.create_where_condition('fulfillment_id', query, 'like'))
			where_query.append(model_shipment.create_where_condition('tracking_number', query, 'like'))
			where_query.append(model_shipment.create_where_condition('products', {'$elemMatch': model_shipment.create_where_condition('product_name', query, 'like')}))
			where_query.append(model_shipment.create_where_condition('products', {'$elemMatch': model_shipment.create_where_condition('product_sku', query, 'like')}))
			where_query.append(model_shipment.create_where_condition('products', {'$elemMatch': model_shipment.create_where_condition('tracking_number', query, 'like')}))
			where['$or'] = where_query
		return where

	@staticmethod
	def process_shipment_data_before_return(shipments, request, *args, **kwargs):
		for shipment in shipments:
			shipment_id = shipment['_id']
			shipment['id'] = shipment_id
			del shipment['_id']
		return shipments

	def select_fields(self):
		return None

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_shipment = Shipment()
		model_shipment.set_user_id(user_id)
		where = self.get_condition_from_request(request, model_shipment, **kwargs)
		limit = request.GET.get('limit')
		if not limit:
			limit = 20
		page = request.GET.get('page')
		if not page:
			page = 1
		sort_by = request.GET.get('sort')
		if not sort_by or sort_by not in self.SORT_FIELD:
			sort_by = 'created_at'
		shipments = model_shipment.find_all(where, limit = limit, pages = page, sort = sort_by, select_fields = self.select_fields())
		data = {
			"count": len(shipments),
			"data": self.process_shipment_data_before_return(shipments, request, *args, **kwargs),
		}
		return JsonResponse(PaginationResponse(**data).to_dict(), safe = False)

class SendToFBAAPIView(generics.UpdateAPIView):
	def post(self, request, *args, **kwargs):
		order_id = kwargs['order_id']
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			order_data = model_order.get(order_id)
		except Exception:
			return HttpResponseNotFound()
		if not order_data:
			return HttpResponseNotFound()
		if order_data['status'] in ['completed', 'canceled']:
			return JsonResponse(ErrorResponse(errors = {'order_id': ['Order has been completed or canceled']}).to_dict(), status = 400)
		context = {
			'order_data': order_data,
			'user_id': user_id
		}
		fba_shipment_serializer = FBAShipmentSerializer(data = request.data, context = context)
		if fba_shipment_serializer.is_valid():
			validated_data = fba_shipment_serializer.validated_data
			products = validated_data['products']
			shipping_speed = validated_data['shipping_speed']
			fba_location = fba_shipment_serializer.context['fba_location']
			fba_channel = fba_shipment_serializer.context['fba_channel']
			channel_id = fba_channel.id
			products_ext = fba_shipment_serializer.context['products_ext']

			api_info = json_decode(fba_channel.api)
			if not api_info or not isinstance(api_info, dict):
				return JsonResponse(ErrorResponse(errors = {'location_id': ['Invalid API info']}).to_dict(), status = 400)
			# Construct shipments
			model_shipment = Shipment()
			model_shipment.set_user_id(user_id)
			fulfillment_id = order_data['channel_order_number'] + to_str(to_int(time.time())) if order_data['channel_order_number'] else to_str(to_int(time.time()))
			shipment_serializer = ShipmentSerializer(data = {})
			shipment_serializer.is_valid()
			shipment = shipment_serializer.validated_data
			shipment.update({
				'fulfillment_id': fulfillment_id,
				'status': 'processing',
				'order_id': order_data['_id'],
				'channel_order_number': order_data['channel_order_number'],
				'channel_id': order_data['channel_id'],
				'carrier': 'fba',
				'location_id': to_str(fba_location.id),
			})
			# Request order to FBA
			fba_shipment_data = {
				'MarketplaceId': api_info['marketplace_id'],
				'SellerFulfillmentOrderId': fulfillment_id,
				'ShippingSpeedCategory': shipping_speed,
				'DisplayableOrderId': fulfillment_id,
				'DisplayableOrderDateTime': convert_format_time(order_data['created_at'], new_format = '%Y-%m-%dT%H:%M:%S')
			}
			# Shipment address
			customer = order_data['customer']
			customer_name = ' '.join(list(filter(None, [customer['first_name'], customer['middle_name'], customer['last_name']])))
			shipping_address = order_data['shipping_address']
			fba_shipment_data.update({
				'DestinationAddress.Name': customer_name,
				'DestinationAddress.Line1': shipping_address['address_1'],
				'DestinationAddress.City': shipping_address['city'],
				'DestinationAddress.StateOrProvinceCode': shipping_address['state']['state_code'] or shipping_address['state']['state_name'],
				'DestinationAddress.CountryCode': shipping_address['country']['country_code'],
				'FulfillmentAction': 'Ship',
			})
			if shipping_address['postcode']:
				fba_shipment_data['DestinationAddress.PostalCode'] = shipping_address['postcode']
			if shipping_address['address_2']:
				fba_shipment_data['DestinationAddress.Line2'] = shipping_address['address_2']
			if shipping_address['telephone'] or customer['telephone']:
				fba_shipment_data['DestinationAddress.PhoneNumber'] = shipping_address['telephone'] or customer['telephone']
			# Shipment items
			index = 1
			for product_id, shipment_qty in products.items():
				product_ext_data = get_row_from_list_by_field(products_ext, '_id', product_id)
				if not product_ext_data:
					continue
				product_channel_ext_data = product_ext_data['channel'].get(f'channel_{channel_id}')
				# Insert product to shipment
				shipment_product_serializer = ProductShipmentSerializer(data = {})
				shipment_product_serializer.is_valid()
				shipment_product = shipment_product_serializer.validated_data
				shipment_product.update({
					'id': product_ext_data['_id'],
					'product_id': product_channel_ext_data['product_id'],
					'product_sku': product_channel_ext_data['product_sku'] or product_ext_data['sku'],
					'product_name': product_channel_ext_data['product_name'] or product_ext_data['name'],
					'qty': shipment_qty,
				})
				shipment['products'].append(shipment_product)
				# End
				product_data = {
					'SellerSKU': product_channel_ext_data.get('product_sku'),
					'SellerFulfillmentOrderItemId': product_channel_ext_data.get('product_sku'),
					'Quantity': shipment_qty,
				}
				product_data = {f'Items.member.{index}.{key}': value for key, value in product_data.items()}
				fba_shipment_data.update(product_data)
				index += 1
			amazon = AmazonMWS(api_info['seller_id'], api_info['token'], api_info['marketplace_id'])
			fba_shipment_res = amazon.api(
				session = 'Fulfillment',
				action = 'CreateFulfillmentOrder',
				extra_data = fba_shipment_data
			)
			# Check shipment response and status
			if not fba_shipment_res:
				errors = {'amazon_server': 'Data invalid'}
			elif fba_shipment_res.ErrorResponse:
				error = fba_shipment_res.ErrorResponse.Error
				if isinstance(error, list):
					error = error[0]
				errors = {'amazon_server': error.Message.get('$')}
			else:
				errors = None
			if errors:
				shipment['status'] = 'canceled'
				shipment['error_message'] = list(errors.values())[0]
			shipment_id = model_shipment.create(shipment)
			shipment['id'] = shipment_id
			return JsonResponse(ResponseObject(data = shipment, code = 201).to_dict(), status = 201)
		return JsonResponse(ErrorResponse(errors = fba_shipment_serializer.errors).to_dict(), status = 400)

class ReportOrderAPI(views.APIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		try:
			result = list()
			in_day = False
			start_date = request.GET.get("start_date")
			end_date = request.GET.get("end_date")
			status = request.GET.get("status")
			channel = request.GET.get("channel")
			if not start_date or not end_date:
				if channel:
					processes = Process.objects.filter(user_id=user_id, type='order', channel_id=channel)
				else:
					processes = Process.objects.filter(user_id=user_id, type='order')
				if not processes:
					return JsonResponse(ErrorResponse(errors = "Missing date filter").to_dict(), status = 400)
				for process in processes:
					if not start_date:
						start_date = process.created_at
					if process.created_at < start_date:
						start_date = process.created_at
				start_date = str(start_date).split(" ")[0]
				end_date = str(datetime.now()).split(" ")[0]
			start_time = datetime.strptime(start_date, '%Y-%m-%d').timestamp()
			end_time = datetime.strptime(end_date, '%Y-%m-%d').timestamp()
			if (end_time - start_time) < 86400:
				in_day = True
				gap_time = 10800
				end_time = start_time + 86340 - 10800
			elif (end_time - start_time) >= 86400 and (end_time - start_time) <= 864000:
				gap_time = 86400
			else:
				gap_time = (end_time - start_time)/8
			time = start_time
			while((time - gap_time) < end_time):
				start = datetime.fromtimestamp(time).strftime('%Y-%m-%d %H:%M')
				time = time + gap_time
				end = datetime.fromtimestamp(time).strftime('%Y-%m-%d %H:%M')
				condition = [
					{"created_at": { "$gte": start, "$lt": end }},
					{"status": status},
					{"channel_id": int(channel) if channel else None}
				]
				if not channel or channel == "all":
					condition.pop(2)
				if not status or status == "all":
					condition.pop(1)
				query = [
					{
						"$match": { "$and": condition }
					},
					{"$group": {
						"_id": "$channel_id",
						"total": {
							"$sum": {'$sum': {'$toDecimal':'$total'}}
						},
						"count": {
							"$count": {}
						}
					}},
					{ "$sort" : { "date": 1 }}
				]
				order_data = model_order.select_aggregate(query=query)
				if len(order_data) == 0:
					result.append({
						"start_time": start,
						"end_time": end,
						"channel": "",
						"total": 0,
						"count": 0
					})
				else:
					for item in order_data:
						result.append({
							"start_time": start,
							"end_time": end,
							"channel": item['_id'],
							"total": to_decimal(item['total'].to_decimal(), 2),
							"count": item['count']
						})

			if in_day:
				result[-1]['end_time'] = start_date + " 24:00"
				result.append({
					"start_time": start_date + " 24:00",
					"end_time": end_date + " 24:00",
					"channel": "",
					"total": 0,
					"count": 0
				})
			return JsonResponse(ResponseObject(data = result, code = 200).to_dict(), status = 200)
		except Exception as e:
			log_traceback()
			return HttpResponseNotFound()
		
class ReportOrderDetailAPI(views.APIView):
	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden()
		model_catalog = Catalog()
		model_catalog.set_user_id(user_id)
		model_order = CollectionOrder()
		model_order.set_user_id(user_id)
		channel = request.GET.get("channel")
		if not channel:
			return JsonResponse(ErrorResponse(errors = "Missing params channel id").to_dict(), status = 400)
		result = list()
		try:
			query = [
				{
					"$unwind": "$products"
				},
				{
					"$project": {
						"id": {
							"$cond": [
								{
									"$in": ["$products.parent_id", [False, None]]
								},
								"$products.id",
								"$products.parent_id"
							]
						},
						"qty": "$products.qty",
						"channel": "$channel_id",
						"name": "$products.product_name",
						"sku": "$products.product_sku"
					}
				},
				{
					"$match": {"channel": int(channel)}
				},
				{
					"$group": {
						"_id": "$id",
						"name": {
							"$first": "$name"
						},
						"sku": {
							"$first": "$sku"
						},
						"count": { "$sum" : "$qty" }
					}
				},
				{
					"$project": {
						"id": "$_id",
						"name": "$name",
						"sku": "$sku",
						"count": "$count"
					}
				},
				{
					"$sort": { 
						"count": -1
					}
				},
				{
					"$limit": 20
				}
			]
			order_detail = model_order.select_aggregate(query=query)
			log(order_detail)
			for order in order_detail:
				log(order)
				if order.get('id') and self.is_valid(order.get('id')):
					product = model_catalog.find('_id', order['id'], select_fields=['name', 'sku'])
					if not product:
						result.append({
							"id": order['id'],
							"name": order['name'],
							"sku": order['sku'],
							"count": order['count']
						})
					else:
						result.append({
							"id": order['id'],
							"name": product['name'],
							"sku": product['sku'],
							"count": order['count']
						})
				else:
					result.append({
						"id": order['id'],
						"name": order['name'],
						"sku": order['sku'],
						"count": order['count']
					})
			return JsonResponse(ResponseObject(data = result, code = 200).to_dict(), status = 200)
		except Exception as e:
			log_traceback()
			return HttpResponseNotFound()
		
	def is_valid(self, oid):
		try:
			ObjectId(oid)
			return True
		except Exception:
			log_traceback()
			return False

class ProcessInChannelApi(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		data = request.data
		order_ids = data.get('order_ids')
		if not order_ids:
			return JsonResponse(ErrorResponse(errors = 'Data Invalid').to_dict(), status = 400)
		order_invalid = list(filter(lambda x: not to_object_id(x), order_ids))
		if order_invalid:
			return JsonResponse(ErrorResponse(code = 400, errors = {'product_ids': "invalid [{}]".format(", ".join(list(map(lambda x: to_str(x), order_invalid))))}).to_dict(), status = 400)
		update_data = {
			'status': 'processed_in_channel',
		}
		model_order = CollectionOrder()
		model_order.set_user_id(AccountUtils().get_user_id(request))
		model_order.update_many(model_order.create_where_condition('_id', order_ids, 'in'), update_data)
		return HttpResponse(status = 204)
