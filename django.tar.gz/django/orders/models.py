# # Create your models here.
from django.db import models


class Orders(models.Model):
	class Meta:
		permissions = (("delete_all", "Delete All Order"),)
