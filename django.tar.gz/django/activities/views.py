from django.http import HttpResponseNotFound, JsonResponse
from rest_framework import generics
from django.core.paginator import Paginator

from accounts.utils import AccountUtils
from channels.utils import ChannelUtils
from core.permission import IsPrivateOrReadOnly
from core.responses import PaginationResponse
# Create your views here.
from libs.utils import to_str, to_int
from .utils import ActivityUtils
from announcements.models import Announcement
from announcements.serializers import AnnouncementSerializer

class ActivityList(generics.ListAPIView):
	"""
	List all activities, or create a new activity.
	"""

	def get(self, request, *args, **kwargs):
		model_activity = ActivityUtils().get_activity_model(request = request)
		pass

class ActivityGroupApiView(generics.RetrieveUpdateDestroyAPIView):
	"""
	Retrieve, update or delete an activity instance.
	"""
	permission_classes = [IsPrivateOrReadOnly]
	ACTIVITY_GROUP = ('notification', 'recent', 'process', 'channel_sync', 'main_sync', 'order_sync')

	def get(self, request, *args, **kwargs):
		activity_type = kwargs['activity_group']
		if activity_type not in self.ACTIVITY_GROUP:
			return HttpResponseNotFound()
		func = f"get_{activity_type}"
		data = getattr(ActivityUtils(), func)(request)
		activity_data = data['data']
		if activity_data:
			channels = ChannelUtils().get_channel_by_user_id(AccountUtils().get_user_id(request))
			channel_data = dict()
			for channel in channels:
				channel_data[to_str(channel.id)] = {
					'channel_type': channel.type,
					'channel_name': channel.name
				}
			for row in activity_data:
				if row.get('channel_id') and to_str(row['channel_id']) in channel_data:
					row.update(channel_data[to_str(row['channel_id'])])
			data['data'] = activity_data
		return JsonResponse(PaginationResponse(**data).to_dict())

class NotificationCount(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		model = ActivityUtils().get_activity_model(request = request)
		user_id = AccountUtils().get_user_id(request)
		where = dict()
		where.update(model.create_where_condition('group', ['notification', 'order_sync']))
		where.update(model.create_where_condition('status', 'new'))
		model.count(where)
		user = AccountUtils().get_user(user_id)
		announcements_latest_read_at = user.announcements_latest_read_at if user.announcements_latest_read_at else user.created_at
		unread_announcements = Announcement.objects.filter(created_at__gt = announcements_latest_read_at)
		announcements_serializer = AnnouncementSerializer(unread_announcements, many = True)
		return JsonResponse({'count': to_int(model.count(where)) + len(announcements_serializer.data)})

class ActivityProductChanged(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		model = ActivityUtils().get_activity_model(request = request)
		where = dict()
		where.update(model.create_where_condition('group', 'product_changed'))
		change_type = request.GET.get('change_type')
		if change_type:
			where.update(model.create_where_condition('content', [change_type], 'in'))
		limit = to_int(request.GET.get('limit'))
		if not limit:
			limit = 20
		page = to_int(request.GET.get('page'))
		if not page:
			page = 1
		activities = model.find_all(where, sort = '-_id', limit = limit, pages = page)
		count = model.count(where)
		response = {'data': activities, 'count': count}
		return JsonResponse(PaginationResponse(**response).to_dict())
