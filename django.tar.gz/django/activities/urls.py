from django.urls import path

from .views import ActivityList, ActivityGroupApiView, NotificationCount, ActivityProductChanged

urlpatterns = [
	path('', ActivityList.as_view()),
	path('/<str:activity_group>', ActivityGroupApiView.as_view()),
	path('/notification/count', NotificationCount.as_view()),
	path('/notification/product-changed', ActivityProductChanged.as_view()),
]
