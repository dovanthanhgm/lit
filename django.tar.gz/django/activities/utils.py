from accounts.utils import AccountUtils
from channels.utils import ChannelUtils
from libs.models.collections.activities import Activities
from libs.utils import to_int
from announcements.models import Announcement
from announcements.serializers import AnnouncementSerializer
from datetime import datetime


class ActivityUtils:
	STATUS = ('new', 'read', 'deleted')


	def get_activity_model(self, user_id = None, request = None):
		if not user_id:
			user_id = AccountUtils().get_user_id(request)
		model = Activities()
		model.set_user_id(user_id)
		return model

	def get_notification(self, request):
		status = request.GET.get('status')
		model = self.get_activity_model(request = request)
		page = to_int(request.GET.get('page'))
		if not page:
			page = 1
		where = dict()
		where.update(model.create_where_condition('group', ['notification', 'order_sync'], 'in'))
		# if status and status in self.STATUS:
		# 	where.update(model.create_where_condition('status', status))
		notifications = model.find_all(where, limit = 10, pages = page, sort = '-created_at')
		for notification in notifications:
			if notification['group'] == 'order_sync':
				content = f'There are {to_int(notification.get("total"))} new orders imported into LitCommerce'
				if to_int(notification.get('unliked')) or to_int(notification.get('error')):
					if to_int(notification.get('unlinked')) and to_int(notification.get('error')):
						content += f", including {to_int(notification.get('unlinked'))} unlinked orders and {to_int(to_int(notification.get('error')))} orders with errors when syncing to MainStore"
					elif to_int(notification.get('unlinked')):
						content += f", including {to_int(notification.get('unlinked'))} unlinked orders"
					else:
						content += f", including {to_int(notification.get('error'))} orders with errors when syncing to MainStore"
				notification['content'] = content
		# if notifications and status == 'new':
		model.update_many(where, {'status': 'read'})
		user_id = AccountUtils().get_user_id(request)
		user = AccountUtils().get_user(user_id)
		announcements = self.get_announcements(user, status, notifications, page)
		notifications.extend(announcements)
		notifications = sorted(notifications, key = lambda x: x['created_at'], reverse=True)
		return {
			'data': notifications,
			'count': len(notifications)
		}



	def get_announcements(self, user, status, notifications, page = 1):
		if status != 'read':
			announcements_latest_read_at = user.announcements_latest_read_at if user.announcements_latest_read_at else user.created_at
			announcements = Announcement.objects.filter(created_at__gte = announcements_latest_read_at)
			user.announcements_latest_read_at = datetime.now()
			user.save()
		elif notifications and len(notifications) > 2:
			latest_created_at = notifications[0]['created_at']
			created_at = notifications[-1]['created_at']
			announcements = Announcement.objects.filter(created_at__gte = created_at, created_at__lte = latest_created_at).order_by('-created_at')
		else:
			limit = 10
			announcements = Announcement.objects.filter().order_by('-created_at')[(to_int(page) - 1) * limit:(to_int(page) - 1) * limit + limit]

		announcements_serializer = AnnouncementSerializer(announcements, many = True)
		announcements_data = announcements_serializer.data
		for item in announcements_data:
			item.update({"group": "announcement"})
		return announcements_data


	def get_recent(self, request):
		model = self.get_activity_model(request = request)
		where = dict()
		where.update(model.create_where_condition('group', 'recent'))
		exclude_channel_ids = [channel.id for channel in ChannelUtils().get_deleted_channels_by_user_id(model._user_id)]
		exclude_channel_ids.append("")  # del channel by admin
		where.update(model.create_where_condition('channel_id', exclude_channel_ids, 'nin'))
		recent = model.find_all(where, limit = 15, pages = 1, sort = '-_id')
		return {
			'data': recent,
			'count': len(recent)
		}
	def get_order_sync(self, request):
		model = self.get_activity_model(request = request)
		where = dict()
		where.update(model.create_where_condition('group', 'order_sync'))
		exclude_channel_ids = [channel.id for channel in ChannelUtils().get_deleted_channels_by_user_id(model._user_id)]
		exclude_channel_ids.append("")  # del channel by admin
		where.update(model.create_where_condition('channel_id', exclude_channel_ids, 'nin'))
		recent = model.find_all(where, limit = 15, pages = 1, sort = '-_id')
		for notification in recent:
			content = f'There are {to_int(notification.get("total"))} new orders imported into LitCommerce'
			if to_int(notification.get('unliked')) or to_int(notification.get('error')):
				if to_int(notification.get('unlinked')) and to_int(notification.get('error')):
					content += f", including {to_int(notification.get('unlinked'))} unlinked orders and {to_int(notification.get('error'))} orders with errors when syncing to MainStore"
				elif to_int(notification.get('unlinked')):
					content += f", including {to_int(notification.get('unlinked'))} unlinked orders"
				else:
					content += f", including {to_int(notification.get('error'))} orders with errors when syncing to MainStore"
			notification['description'] = content
		return {
			'data': recent,
			'count': len(recent)
		}
	def get_channel_sync(self, request):
		return self.get_sync_activities(request, 'channel_sync')


	def get_main_sync(self, request):
		return self.get_sync_activities(request, 'main_sync')

	def get_sync_activities(self, request, group):
		model = self.get_activity_model(request = request)
		where = dict()
		where.update(model.create_where_condition('group', group))
		exclude_channel_ids = [channel.id for channel in ChannelUtils().get_deleted_channels_by_user_id(model._user_id)]
		exclude_channel_ids.append("")  # del channel by admin
		where.update(model.create_where_condition('channel_id', exclude_channel_ids, 'nin'))
		recent = model.find_all(where, limit = 20, pages = 1, sort = '-updated_at')
		return {
			'data': recent,
			'count': len(recent)
		}