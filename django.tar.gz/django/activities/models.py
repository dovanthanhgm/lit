from django.db import models
from django.template.defaultfilters import truncatechars

from accounts.models import UserAccount


class Activity(models.Model):
	"""
	Class Activity
	"""

	# user = models.ForeignKey(
	# 	UserAccount,
	# 	on_delete = models.CASCADE,
	# 	null = False
	# )
	user_id = models.IntegerField(default = 0, blank = False, null = True)
	description = models.TextField(blank = True, default = '')
	created_at = models.DateTimeField(auto_now_add = True)


	class Meta:
		db_table = 'activity'
		ordering = ['id']

	@property
	def short_description(self):
		return truncatechars(self.description, 30)
