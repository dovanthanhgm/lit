from django.contrib import admin

from .models import *
from processes.admin import UserFilter


class ActivityAdmin(admin.ModelAdmin):
    search_fields = ['user__email', 'description', 'created_at']
    list_filter = (UserFilter,)
    list_display = ['user', 'short_description', 'created_at']
    list_per_page = 20


# admin.site.register(Activity, ActivityAdmin)
