from rest_framework import serializers

from .models import Activity


class ActivitySerializer(serializers.Serializer):
	group = serializers.ChoiceField(choices = ('notification', 'process', 'recent'))
	code = serializers.CharField()
	activity_type = serializers.CharField()
	status = serializers.ChoiceField(choices = ('new', 'read', 'deleted'))
	content = serializers.CharField()
	created_at = serializers.DateField()
	channel_id = serializers.IntegerField()
	channel_type = serializers.CharField()
	channel_name = serializers.CharField()
	date_requested = serializers.IntegerField()
	description = serializers.CharField()
	result = serializers.ChoiceField(choices = ('success', 'failed'))
	# channel_type = serializers.ChoiceField(choices = ('amazon', 'ebay', 'etsy', 'bigcommerce', 'facebook', 'file', 'google', 'magento', 'shopify', 'wish', 'woocommerce'))
