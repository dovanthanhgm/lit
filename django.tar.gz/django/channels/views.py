import copy

from django.db.models import Max
from django.forms import model_to_dict
from django.http import JsonResponse, HttpResponseForbidden, HttpResponse, HttpResponseNotFound
from django.shortcuts import redirect, get_object_or_404, render
from django.utils.decorators import method_decorator
from django.views.generic import TemplateView
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics, status

from accounts.permission import IsStaff
from accounts.utils import AccountUtils
from core.permission import IsPrivateOrReadOnly, IsPrivate, IsPrivateOrReadDelete
from core.responses import ErrorResponse, ResponseObject
from core.utils import CoreUtils
from datasync.api.sync import SyncApi
from datasync.cart import Cart
from libs.models.collections.activities import Activities
from libs.models.collections.state import State
from libs.models.collections.template import Template
from libs.utils import get_config_ini, to_object_id, to_str, json_decode, get_full_absolute_uri, log_traceback, json_encode, update_nested_dict, to_decimal, to_int
from processes.models import Process
from processes.utils import ProcessUtils
from products.utils import ProductUtils
from user_action_logs.utils import UserActionLogUtils
from .filters import ChannelFilter, ChannelFilterPrivate
from .models import Channel
from .scheduler import start_process
from .serializers import ChannelSerializer, ChannelPrivateSerializer, ChannelSettingSerializer, ChannelListingActionSerializer, GetChannelSerializer, FeedTypeSerializer
from .utils import ChannelUtils


class ChannelList(generics.ListCreateAPIView):
	"""
	List all channels, or create a new channel.
	"""
	# authentication_classes = []
	# permission_classes = [AllowAny]

	queryset = Channel.objects.all()
	filterset_class = ChannelFilter


	def get_serializer_class(self):
		if self.request.method == 'GET':
			return GetChannelSerializer
		return ChannelSerializer


	# permission_classes = [IsPrivateOrReadOnly]

	def perform_create(self, serializer):
		user_id = AccountUtils().get_user_id(self.request)
		try:
			args = Channel.objects.filter(user_id = user_id)
			position = args.aggregate(Max('position'))
			position_max = position['position__max']
		except Exception as e:
			position_max = 1
		serializer.save(user_id = user_id, position = position_max + 1)


class ChannelListPrivate(generics.ListCreateAPIView):
	"""
	List all channels, or create a new channel.
	"""
	# authentication_classes = []
	# permission_classes = [AllowAny]

	queryset = Channel.objects.all()
	serializer_class = ChannelPrivateSerializer
	filterset_class = ChannelFilterPrivate
	permission_classes = [IsPrivateOrReadOnly]


	def perform_create(self, serializer):
		user_id = AccountUtils().get_user_id(self.request)
		try:
			args = Channel.objects.filter(user_id = user_id)
			position = args.aggregate(Max('position'))
			position_max = position['position__max']
		except Exception as e:
			position_max = 1
		if not position_max:
			position_max = 1
		serializer.save(user_id = user_id, position = to_int(position_max) + 1)


	def post(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(self.request)
		try:
			channels = Channel.objects.filter(user_id = user_id, default = 1)
			if not channels and ChannelUtils().is_shopping_cart(request.data['type']):
				request.data['default'] = 1
				request.data['name'] = 'Main Store'
			data = super(ChannelListPrivate, self).post(request, *args, **kwargs)

		except Exception as e:
			log_traceback()
			return JsonResponse(ErrorResponse(errors = e.args).to_dict(), status = 400)
		return data


class ChannelDetail(generics.RetrieveUpdateDestroyAPIView):
	"""
	Retrieve, update or delete an channel instance.
	"""
	# authentication_classes = []
	permission_classes = [IsPrivateOrReadDelete]

	queryset = Channel.objects.all()
	serializer_class = ChannelSerializer
	filterset_class = ChannelFilter


	def delete(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['pk'])
		try:
			export_channel = ChannelUtils().export_channel(channel)
		except:
			export_channel = ''
		UserActionLogUtils().create_log(AccountUtils().get_user_id(request), channel.id, 'delete_channel', data = export_channel, request = request)

		return self.destroy(request, *args, **kwargs)


class ChannelAfterImport(generics.CreateAPIView):
	"""
	Retrieve, update or delete an channel instance.
	"""
	# authentication_classes = []
	permission_classes = [IsPrivateOrReadOnly]


	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['pk'])
		if channel.type != 'file':
			return HttpResponse()
		process = get_object_or_404(Process, pk = kwargs['process_id'])
		# if process.channel_id != channel.id and not process.default
		channels = Channel.objects.filter(user_id = AccountUtils().get_user_id(request)).exclude(pk = kwargs['pk'])
		for row in channels:
			process = ProcessUtils().get_process_by_type(row.id)
			if not process:
				return HttpResponseNotFound()
			pull = Cart().pull_from_channel(process_id = process.id, data = {'import_all': True})


class ChannelDisconnected(generics.CreateAPIView):
	"""
	Retrieve, update or delete an channel instance.
	"""
	# authentication_classes = []
	permission_classes = [IsPrivate]


	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['pk'])
		need_save = False
		if channel.status != Channel.STATUS_DISCONNECTED:
			channel.status = Channel.STATUS_DISCONNECTED
			if channel.type == 'amazon':
				api = json_decode(channel.api)
				if not api:
					api = {}
				api['bk_refresh_token'] = api.get('refresh_token')
				api['refresh_token'] = ''
				channel.api = json_encode(api)
				need_save = True
			need_save = True
		if not channel.email_disconnected:
			user = AccountUtils().get_user_by_request(request)
			if not channel.default:
				template_code = 'channel-disconnected'
			else:
				template_code = 'mainstore-disconnected'
			context = {
				'channel': channel
			}
			user.send_email_template(template_code, context)
			channel.email_disconnected = True
			need_save = True
		if need_save:
			channel.save()
		return HttpResponse(status = 201)

class ChannelDetailPrivate(generics.RetrieveUpdateDestroyAPIView):
	# authentication_classes = []
	# permission_classes = [AllowAny]

	queryset = Channel.objects.all()
	serializer_class = ChannelPrivateSerializer
	filterset_class = ChannelFilterPrivate
	permission_classes = [IsPrivateOrReadOnly]


@method_decorator(name = 'post', decorator = swagger_auto_schema(
	request_body = ChannelSettingSerializer,
	responses = {
		status.HTTP_204_NO_CONTENT: ''
	}
))
class ChannelSettingAPIView(generics.ListAPIView):
	serializer_class = ChannelSettingSerializer
	channel_name = ''


	def post(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		if not user_id:
			return HttpResponseForbidden

		serializer = self.get_serializer(data = request.data)
		if serializer.is_valid():
			ChannelUtils().setting_for_channel(channel, dict(serializer.data.get('setting')), serializer.data.get('name'), request, True)
			# model_state = ProductUtils().get_model_state(request, *args, **kwargs)
			# where = {"channel.id": kwargs['channel_id']}
			#
			# update_settings = dict(serializer.data.get('setting'))
			#
			# if json_decode(channel.settings):
			# 	current_settings = json_decode(channel.settings)
			# else:
			# 	current_state = model_state.find_one(where)
			# 	current_settings = current_state['channel']['config']['setting']
			# data_update = {
			# 	"channel.config.setting": update_settings,
			# 	"channel.name": serializer.data.get('name')
			# }
			# model_state.update_many(where, data_update)
			# channel.name = serializer.data.get('name')
			# channel.first_setting = 1
			# channel.sync_qty = update_settings.get('qty', {}).get('status') == 'enable'
			# channel.sync_price = update_settings.get('price', {}).get('status') == 'enable'
			# channel.sync_order = update_settings.get('order', {}).get('status') == 'enable'
			# channel.settings = json_encode(update_settings)
			# channel.save()
			# ChannelUtils().channel_setting(channel, serializer.data.get('setting'))
			# enable_sync = False
			# # enable_auto_update = False
			# if update_settings.get('price').get('status') == 'enable' or update_settings.get('qty').get('status') == 'enable':
			# 	# enable_auto_update = True
			# 	enable_sync = True
			# 	ChannelUtils().enable_inventory_sync(kwargs['channel_id'])
			# # if serializer.data.get('setting').get('qty').get('status') == 'enable':
			# # 	ChannelUtils().enable_order_sync(kwargs['channel_id'])
			#
			# else:
			# 	ChannelUtils().disable_inventory_sync(kwargs['channel_id'])
			# # ChannelUtils().disable_order_sync(kwargs['channel_id'])
			#
			# if update_settings.get('qty').get('status') == 'enable' or update_settings.get('order', dict()).get('status') == 'enable':
			# 	# enable_auto_update = True
			# 	enable_sync = True
			# 	ChannelUtils().enable_order_sync(kwargs['channel_id'], request._request_date)
			# else:
			# 	ChannelUtils().disable_order_sync(kwargs['channel_id'])
			# if enable_sync:
			# 	refresh_sync = False
			# 	price_fields = ['status', 'direction', 'modifier', 'value']
			# 	for field in price_fields:
			# 		if update_settings.get('price').get(field) != current_settings.get('price', {}).get(field):
			# 			if field != 'status':
			# 				refresh_sync = True
			# 			elif serializer.data.get('setting').get('price').get(field) == 'enable':
			# 				refresh_sync = True
			# 	qty_fields = ['adjust', 'min_qty', 'max_qty', 'status']
			# 	for field in qty_fields:
			# 		if update_settings.get('qty').get(field) != current_settings.get('qty', {}).get(field):
			# 			if field != 'status':
			# 				refresh_sync = True
			# 			elif serializer.data.get('setting').get('qty').get(field) == 'enable':
			# 				refresh_sync = True
			# 	if refresh_sync:
			# 		process = ProcessUtils().get_process_by_type(channel.id, 'inventory')
			# 		model_state.update_field(process.state_id, 'push.process.products.updated_time', 0)
			# if enable_auto_update:
			# 	channel_default = ChannelUtils().get_default_channel(user_id)
			# 	if channel_default:
			# 		ChannelUtils().enable_refresh_sync(channel_default.id)

			return HttpResponse(status = 204)
		else:
			errors = serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)


class GetChannelSettingAPIView(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseForbidden
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		data = model_to_dict(channel)
		del data['api']
		model_state = ProductUtils().get_model_state(request, *args, **kwargs)
		state = model_state.find("channel.id", kwargs['channel_id'])

		if not state:
			return HttpResponseNotFound()

		data['setting'] = state.get('channel').get('config').get('setting')
		# if data['setting']:
		# 	warehouse_active = data['setting'].get('inventory').get('active')
		# 	warehouse_disable = data['setting'].get('inventory').get('disable')
		# 	active = []
		# 	disable = []
		# 	if warehouse_active:
		# 		for i in warehouse_active:
		# 			name = WarehouseLocation.objects.filter(pk = int(i)).first().name
		# 			active.append({"id": i, "name": name})
		#
		# 	if warehouse_disable:
		# 		for i in warehouse_disable:
		# 			name = WarehouseLocation.objects.filter(pk = int(i)).first().name
		# 			disable.append({"id": i, "name": name})
		#
		# 	data['setting']['inventory'] = {"active": active, "disable": disable}

		# data.update({
		# 	'name': state[0].get('channel').get('name'),
		# 	'id': state[0].get('channel').get('id'),
		# 	'status': channel.status if channel else None,
		# 	'type': state[0].get('channel').get('channel_type'),
		# 	'identifier': channel.identifier if channel else None
		# })
		return JsonResponse(data = data, safe = False)


class GoToUser(generics.ListAPIView):
	permission_classes = [IsStaff]


	def get(self, request, *args, **kwargs):
		url = f"{get_config_ini('server', 'api_url')}/admin/accounts/useraccount/{kwargs['user_id']}/change/"
		return redirect(url)


class GetProcessByChannel(generics.ListAPIView):

	def get(self, request, *args, **kwargs):
		user_id = AccountUtils().get_user_id(request)
		if not user_id:
			return HttpResponseNotFound

		processes = Process.objects.filter(user_id = user_id, channel_id = kwargs['channel_id'], type = 'product')
		model_state = State()
		model_state.set_user_id(user_id)
		data = []
		for process in processes:
			state = model_state.get(process.state_id)
			resume_action = state['resume']['action'] or 'pull'
			status = state[resume_action]['resume']['process']
			if state.get('pulling'):
				status = 'pulling'
			if status != 'pulling':
				continue
			data.append({'id': process.id, 'status': status})

		return JsonResponse(data = data, safe = False)


class ChannelListingAction(generics.UpdateAPIView):
	serializer_class = ChannelListingActionSerializer


	def put(self, request, *args, **kwargs):
		data_post = dict(request.data)
		serializer = self.get_serializer(data = data_post)
		if not serializer.is_valid():
			return JsonResponse(ResponseObject(code = 400, message = 'Data invalid').to_dict(), status = 400)

		channel_id = kwargs['channel_id']
		data_post = dict(serializer.data)

		product_ids = data_post['product_ids']
		action = data_post['action']
		channel = ChannelUtils().get(channel_id)
		if not channel:
			return HttpResponseNotFound()
		if not ChannelUtils().channel_allow_action(channel.type, action):
			return HttpResponseForbidden()
		product_invalid = list(filter(lambda x: not to_object_id(x), product_ids))
		if product_invalid:
			return JsonResponse(ErrorResponse(code = 400, errors = {'product_ids': "invalid [{}]".format(
				", ".join(list(map(lambda x: to_str(x), product_invalid))))}).to_dict(), status = 400)
		process = ProcessUtils().get_process_by_type(channel_id)
		if not process:
			return HttpResponseNotFound()

		# model_catalog = ProductUtils().get_model_catalog(request, args, *kwargs)
		# ids = []
		# dict_id = {}
		# for product_id in product_ids:
		# 	parent_id = model_catalog.get(product_id).get('parent_id')
		# 	if parent_id:
		# 		_ids = model_catalog.find_all(model_catalog.create_where_condition('parent_id', parent_id, '='))
		# 		dict_id[parent_id] = _ids
		# 	else:
		# 		dict_id[product_id] = [product_id]
		# for product_id in dict_id:
		# 	ids += dict_id[id]
		post_data = ProductUtils().condition_product_ids(product_ids)
		post_data['mass_action'] = action
		endpoint = f'channel/{channel_id}/mass-action'
		publish = SyncApi(process_id = process.id).post(endpoint, data = post_data)
		if publish['result'] != 'success':
			return JsonResponse(ErrorResponse(code = 400, errors = publish['msg']).to_dict(), status = 400)

		log_action = f'{channel.type}_{action}'
		if action == 'active':
			log_action = 'active'
		UserActionLogUtils().create_log(AccountUtils().get_user_id(request), channel_id, log_action, data = post_data, request = request)

		return JsonResponse(ResponseObject().to_dict())


class ChannelExportView(generics.ListAPIView):
	def get(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])
		# channel_data = model_to_dict(channel)
		# channel_del_field = ['id', 'user', 'deleted_at', 'position']
		# for field in channel_del_field:
		# 	del channel_data[field]
		# process = ProcessUtils().get_process_by_type(channel.id, 'product')
		# state_id = process.state_id
		# model_state = State()
		# model_state.set_user_id(channel.user_id)
		# state_data = model_state.get(state_id)
		# model_template = Template()
		# model_template.set_user_id(channel.user_id)
		# where_template = model_state.create_where_condition('channel_id', channel.id)
		# templates = model_template.find_all(where_template)
		return JsonResponse(ChannelUtils().export_channel(channel))


class ChannelImportView(TemplateView):
	def get(self, request, *args, **kwargs):
		context = kwargs

		return render(request, 'admin/channels/channel/import_channel.html', context)


	def post(self, request, *args, **kwargs):
		data = json_decode(request.POST.get('channel_data'))
		user_id = request.POST.get('user_id')
		if not data:
			return HttpResponseNotFound()
		channel_data = data['channel']
		default = False
		try:
			args = Channel.objects.filter(user_id = user_id)
			for row in args:
				if row.default:
					default = True
			position = args.aggregate(Max('position'))
			position_max = position['position_max']
		except Exception as e:
			position_max = 1
		channel_data['position'] = position_max + 1
		channel_data['name'] += ' Clone'
		channel_data['user_id'] = user_id
		if channel_data.get('default') and default:
			channel_data['default'] = 0
		channel = Channel.objects.create(**channel_data)
		state = data['state']
		if '_id' in state:
			del state['_id']
		state['channel']['id'] = channel.id
		model_state = State()
		model_state.set_user_id(channel.user_id)
		state_id = model_state.create(state)
		process = Process.objects.create(channel_id = channel.id, state_id = state_id, user_id = user_id)
		model_state.update_field(state_id, 'sync_id', process.id)
		model_template = Template()
		model_template.set_user_id(channel.user_id)
		for template in data['templates']:
			if '_id' in template:
				del template['_id']
			template['channel_id'] = channel.id
			model_template.create(template)
		return redirect(get_full_absolute_uri('admin:accounts_useraccount_change', {'object_id': user_id}))


class EnableRefreshProduct(generics.CreateAPIView):
	# permission_classes = [IsPrivate]

	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])
		if channel.default != 1:
			return HttpResponseForbidden()
		ChannelUtils().enable_refresh_sync(kwargs['channel_id'])
		user = AccountUtils().get_user_by_request(request)
		channel.auto_update = 1
		channel.save()
		UserActionLogUtils().create_log(channel.user_id, channel.id, 'enable_refresh', request = request)

		return HttpResponse(status = 201)
class EnableAutoImportProduct(generics.CreateAPIView):
	# permission_classes = [IsPrivate]

	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])
		if channel.default != 1:
			return HttpResponseForbidden()
		# ChannelUtils().enable_refresh_sync(kwargs['channel_id'])
		user = AccountUtils().get_user_by_request(request)
		channel.auto_import = 1
		settings = json_decode(channel.settings)
		if not settings:
			settings = {}
		settings['auto_import_product'] = True
		channel.settings = json_encode(settings)
		channel.save()
		UserActionLogUtils().create_log(channel.user_id, channel.id, 'enable_auto_import', request = request)

		return HttpResponse(status = 201)

class DisableRefreshProduct(generics.CreateAPIView):
	# permission_classes = [IsPrivate]

	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		ChannelUtils().disable_refresh_sync(kwargs['channel_id'], channel)
		# channel.auto_update = 0
		# channel.save()
		UserActionLogUtils().create_log(channel.user_id, channel.id, 'disable_refresh', request = request)

		return HttpResponse(status = 201)
class DisableAutoImportProduct(generics.CreateAPIView):
	# permission_classes = [IsPrivate]

	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])

		channel.auto_import = 0
		settings = json_decode(channel.settings)
		if not settings:
			settings = {}
		settings['auto_import_product'] = False
		channel.settings = json_encode(settings)
		channel.save()
		UserActionLogUtils().create_log(channel.user_id, channel.id, 'disable_autoimport', request = request)

		return HttpResponse(status = 201)

class ChannelReconnectApiView(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		request_data = request.data
		user = AccountUtils().get_user_by_request(request)
		channel_id = kwargs['channel_id']
		channel = get_object_or_404(Channel, pk = channel_id)
		data = {
			'channel_type': channel.type,
			'channel_name': channel.name,
			'channel_url': request_data.get('channel_url') or channel.url,
			'user_id': user.id,
			'api': request_data.get('api', dict()) or json_decode(channel.api) or {}
		}
		if request_data.get('merchant_id'):
			channel_type = request_data.get('channel_type')
			model_class = CoreUtils().get_channel_model_utils(channel_type)
			try:
				channel_data = model_class.get_api_info(request_data.get('merchant_id'))
			except:
				log_traceback()
				return JsonResponse(ResponseObject(code = 400, message = 'Data invalid').to_dict())
			if channel_data is False:
				return JsonResponse(ResponseObject(code = 400, message = 'Data invalid').to_dict())
			if channel_data.get('url') and not data['channel_url']:
				data['channel_url'] = channel_data['url']
				del channel_data['url']
			if isinstance(data['api'], dict):
				data['api'].update(channel_data)
			else:
				data['api'] = channel_data
		process = ProcessUtils().get_process_by_type(channel_id)

		verify_connection = SyncApi(channel_id = channel_id).api(f'channel/verify_connection/{process.id}', data = data, method = 'post')
		if not verify_connection or verify_connection.get('result') != 'success':
			channel.status = channel.STATUS_DISCONNECTED
			channel.save()
			if not channel.is_personal_cart():
				ChannelUtils().disable_all_scheduler(channel_id)

			return JsonResponse(verify_connection, status = 400)
		else:
			channel.status = channel.STATUS_CONNECTED
			# channel.api = verify_connection.get('data')
			verify_connection['data'] = None
			api_info = json_decode(channel.api)
			api_info = update_nested_dict(api_info, data['api'])
			channel.api = json_encode(api_info)
			channel.save()
			if channel.default and AccountUtils().is_paid_user(AccountUtils().get_user_by_request(request)):
				ChannelUtils().enable_refresh_sync(channel.id)
			return JsonResponse(verify_connection, status = 200)


class FeedsApiView(generics.ListCreateAPIView):
	def get(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])
		if channel.type != 'file':
			return HttpResponse(status = 404)
		processes = Process.objects.filter(channel_id = channel.id, type = 'product')
		response = list()
		for process in processes:
			config = json_decode(process.config)
			config['feed_id'] = process.id
			config['feed_type'] = process.feed_type
			config['default'] = process.default
			response.append(config)
		return JsonResponse(response, safe = False)


	def post(self, request, *args, **kwargs):
		channel = get_object_or_404(Channel, pk = kwargs['channel_id'])
		if channel.type != 'file':
			return HttpResponse(status = 404)
		feed_limit = ChannelUtils().get_feeds_limit(AccountUtils().get_user_by_request(request))
		if feed_limit:
			feeds = Process.objects.filter(channel_id = channel.id, type = 'product').count()
			if feeds >= feed_limit:
				return JsonResponse(ErrorResponse(errors = "Your plan has reached its limit on the number of feeds. Please upgrade the plan to continue using").to_dict(), status = 400)

		feed_serializer = FeedTypeSerializer(data = request.data)
		if not feed_serializer.is_valid():
			errors = feed_serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		process_default = Process.objects.get(default = 1, channel_id = channel.id)
		state_id = process_default.state_id
		state_model = State()
		state_model.set_user_id(request.user.id)
		state = state_model.get(state_id)
		new_state = copy.deepcopy(state)
		del new_state['_id']
		state['channel']['config']['api'] = feed_serializer.data
		new_state_id = state_model.create(new_state)
		process_data = {
			'channel_id': channel.id,
			'default': False,
			'feed_type': feed_serializer.data['feed_type'],
			"state_id": new_state_id,
			"user_id": request.user.id,
			"config": json_encode(feed_serializer.data)
		}
		new_process = Process.objects.create(**process_data)
		return_data = feed_serializer.data
		return_data['id'] = new_process.id
		return JsonResponse(return_data)


class FeedDetailsApiView(generics.RetrieveUpdateDestroyAPIView):
	def get(self, request, *args, **kwargs):
		feed = get_object_or_404(Process, pk = kwargs['feed_id'])
		channel = feed.channel
		if channel.id != kwargs['channel_id'] or channel.type != 'file':
			return HttpResponse(status = 404)
		feed_info = json_decode(channel.api)
		if not feed_info:
			feed_info = {}
		config = json_decode(feed.config)
		if config:
			feed_info.update(config)
			feed_info['feed_id'] = feed.id
			feed_info['feed_type'] = feed.feed_type
			feed_info['default'] = feed.default
		activity_model = Activities()
		activity_model.set_user_id(channel.user_id)
		where = activity_model.create_where_condition("feed_id", feed.id)
		where.update(activity_model.create_where_condition("group", 'feed'))
		activities = activity_model.find_all(where, limit = 10, sort = '-_id')
		feed_info['activities'] = activities
		return JsonResponse(feed_info)


	def put(self, request, *args, **kwargs):
		feed = get_object_or_404(Process, pk = kwargs['feed_id'])
		channel = feed.channel
		if channel.id != kwargs['channel_id'] or channel.type != 'file':
			return HttpResponse(status = 404)
		feed_serializer = FeedTypeSerializer(data = request.data)
		if not feed_serializer.is_valid():
			errors = feed_serializer.errors
			return JsonResponse(ErrorResponse(errors = errors).to_dict(), status = 400)
		config = json_decode(feed.config)
		config = feed_serializer.data
		feed.config = json_encode(config)
		feed.save()
		return HttpResponse(status = 204)


	def delete(self, request, *args, **kwargs):
		feed = get_object_or_404(Process, pk = kwargs['feed_id'])
		channel = feed.channel
		if channel.id != kwargs['channel_id'] or channel.type != 'file':
			return HttpResponse(status = 404)
		if feed.default:
			return JsonResponse(ErrorResponse(message = "Cannot delete default feed").to_dict(), status = 400)
		feed_data = model_to_dict(feed)
		feed.delete()
		UserActionLogUtils().create_log(channel.user_id, kwargs['channel_id'], 'delete_feed', data = feed_data, request = request)
		return HttpResponse(status = 204)


class FeedStartProcessApi(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		feed = get_object_or_404(Process, pk = kwargs['feed_id'])
		channel = feed.channel
		if channel.id != kwargs['channel_id'] or channel.type != 'file':
			return HttpResponse(status = 404)
		request_data = request.data
		if feed.feed_type == 'file' and not request_data.get('url'):
			return JsonResponse(ErrorResponse(errors = "Missing Url").to_dict(), status = 400)
		pull = Cart().pull_from_channel(process_id = kwargs['feed_id'], data = request_data)
		return HttpResponse(status = 204)


class FeedEnableSchedulerApi(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		feed = get_object_or_404(Process, pk = kwargs['feed_id'])
		channel = feed.channel
		if channel.id != kwargs['channel_id'] or channel.type != 'file':
			return HttpResponse(status = 404)
		request_data = request.data
		task = ChannelUtils().get_task_by_process(feed)
		if task:
			task.delete()
		repeat = to_int(to_decimal(request_data.get('repeat', '0.5')) * 3600)
		start_process(process_id = feed.id, verbose_name = feed.id, repeat = repeat)
		config = json_decode(feed.config)
		config['scheduler'] = True
		config['repeat'] = request_data.get('repeat', '0.5')
		feed.config = json_encode(config)
		feed.save()
		return HttpResponse(status = 204)


class FeedDisableSchedulerApi(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		feed = get_object_or_404(Process, pk = kwargs['feed_id'])
		channel = feed.channel
		if channel.id != kwargs['channel_id'] or channel.type != 'file':
			return HttpResponse(status = 404)
		request_data = request.data
		task = ChannelUtils().get_task_by_process(feed)
		if task:
			task.delete()
		config = json_decode(feed.config)
		config['scheduler'] = False
		config['repeat'] = request_data.get('repeat', '0.5')
		feed.config = json_encode(config)
		feed.save()
		return HttpResponse(status = 204)
class SkipTemplatesRequire(generics.CreateAPIView):
	def post(self, request, *args, **kwargs):
		channel_id = kwargs['channel_id']
		channel = get_object_or_404(Channel, pk = channel_id)
		if request.data.get('skip_templates', {}):
			if not channel.skip_templates:
				channel.skip_templates = request.data.get('skip_templates')
			else:
				channel.skip_templates += ", " + request.data.get('skip_templates')
		channel.save()
		return HttpResponse(status = 204)

	def get(self, request, *args, **kwargs):
		channel_id = kwargs['channel_id']
		channel = get_object_or_404(Channel, pk = channel_id)
		skip_tempalates = {
			"skip_templates": channel.skip_templates if channel.skip_templates else ""
		}
		return JsonResponse(skip_tempalates, safe = False)

	def delete(self, request, *args, **kwargs):
		channel_id = kwargs['channel_id']
		channel = get_object_or_404(Channel, pk = channel_id)
		channel.skip_templates = ""
		channel.save()
		return HttpResponse(status = 204)