import datetime

from background_task import background

from datasync.api.sync import SyncApi
from libs.utils import log_traceback
from processes.utils import ProcessUtils


@background(schedule = 30)
def start_process(**kwargs):
	process_id = kwargs['process_id']
	process = ProcessUtils().get(process_id)
	# UserLogsUtils().create_log(process.user_id, f'scheduler_{process.type}')

	if not process:
		return
	try:
		if process.type == 'refresh':
			process.channel.last_imported = datetime.datetime.now()
			process.channel.save()
		if process.type == 'order' and process.channel.type in ['facebook','google']:
			return
	except:
		log_traceback()
	sync_api = SyncApi(user_id = process.user_id)
	sync_api.post(f'scheduler/{process.id}')


@background(schedule = 300)
def start_inventory_process(**kwargs):
	process_id = kwargs['process_id']
	process = ProcessUtils().get(process_id)
	# UserLogsUtils().create_log(process.user_id, f'scheduler_{process.type}')

	if not process:
		return
	sync_api = SyncApi(user_id = process.user_id)
	sync_api.post(f'scheduler/{process.id}')