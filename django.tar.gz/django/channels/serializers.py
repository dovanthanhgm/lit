from rest_framework import serializers
from merchant.reverb.serializers import ReverbConditionSerializer

from .models import Channel


class ChannelSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)


	class Meta:
		model = Channel
		fields = ["id", "type", "name", "identifier", "url", "position", "sync_price", "sync_price_config",
		          "sync_qty", "sync_order", "sync_qty_config", "user_id", "status", "created_at", "updated_at", 'default', 'auto_update', 'last_imported']


class GetChannelSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)


	class Meta:
		model = Channel
		fields = ["id", "type", "name", "identifier", "url", "position",
		          "user_id", "status", "created_at", "updated_at", 'default', 'last_imported']


class ChannelPrivateSerializer(serializers.ModelSerializer):
	user_id = serializers.IntegerField(read_only = True)
	default = serializers.IntegerField(required = False)
	last_imported = serializers.DateTimeField(required = False)


	def get_fields(self, *args, **kwargs):
		fields = super(ChannelPrivateSerializer, self).get_fields()
		request = self.context.get('request', None)
		if request and getattr(request, 'method', None) != "POST":
			fields['type'].required = False
			fields['name'].required = False
			fields['identifier'].required = False
		return fields


	class Meta:
		model = Channel
		fields = ["id", "type", "name", "identifier", "url", "api", "position", "sync_price", "sync_price_config",
		          "sync_qty", "sync_qty_config", "user_id", "status", "created_at", "updated_at", "deleted_at", "default", "number_products", "number_products_linked", "custom_linked_product", "last_imported", "settings", "walmart_timestamp_publish"]


class StateChannelConfigPriceSyncSerializer(serializers.Serializer):
	status = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True)
	use_sale_price = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, default = 'disable')
	use_stp = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, default = 'disable')
	direction = serializers.ChoiceField(choices = ('increase', 'decrease'), allow_null = True, allow_blank = True)
	modifier = serializers.ChoiceField(choices = ('fixed', 'percent'), allow_null = True, allow_blank = True)
	value = serializers.FloatField(allow_null = True, default = 0.0)
	rounding = serializers.ChoiceField(choices = ('nearest_099', 'nearest_095', 'nearest_1', 'nearest_10', 'nearest_1099', 'nearest_5', 'nearest_9'), required = False, allow_blank = True, allow_null = True)
	filter_condition = serializers.ListField(child = ReverbConditionSerializer(), allow_empty = True, required = False)

class MagentoStoreSerializer(serializers.Serializer):
	store_id = serializers.IntegerField(required = False, default = 0, allow_null = True)
	store_name = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	rounding = serializers.ChoiceField(choices = ('nearest_099', 'nearest_095', 'nearest_1', 'nearest_10', 'nearest_1099'), required = False, allow_blank = True, allow_null = True)


class StateChannelConfigOrderSyncSerializer(serializers.Serializer):
	status = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True)
	keep_order_number = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	notify_order_unlink = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	order_number_prefix = serializers.CharField(required = False, max_length = 15, allow_null = True, allow_blank = True)
	skip_unpaid_order = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	# etsy
	without_tax = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	# magento
	store = MagentoStoreSerializer(required = False)
	# woocommerce
	send_email = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')
	#shopify
	buyer_accepts_marketing = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')
	send_receipt = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')
	send_fulfillment_receipt = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')

	#walmart
	auto_acknowledgement = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')


class WishWarehouseConfig(serializers.Serializer):
	warehouse_id = serializers.CharField(required = True)
	inventory = serializers.IntegerField(default = 0)
class ShopifyLocationConfig(serializers.Serializer):
	location_id = serializers.IntegerField(required = False, allow_null = True)
	location_name = serializers.CharField(required = False, allow_null = True, allow_blank = True)
class StateChannelConfigQtySyncSerializer(serializers.Serializer):
	status = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True)
	keep_active = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	adjust = serializers.IntegerField(allow_null = True)
	no_manage_stock_qty = serializers.IntegerField(allow_null = True, default = 999, required = False)
	max_qty = serializers.IntegerField(allow_null = True)
	min_qty = serializers.IntegerField(allow_null = True)
	outofstock_threshold = serializers.IntegerField(allow_null = True, required = False, default = 0)
	sync_sku = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')
	# ebay
	out_of_stock_control = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')
	allow_relist = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')
	allow_relist_auction = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False, default = 'disable')

	# ------------
	rounding = serializers.ChoiceField(choices = ('round', 'round_down', 'round_up'), required = False, allow_blank = True, allow_null = True)

	#wish
	warehouse_settings = serializers.ListField(required = False, child = WishWarehouseConfig(), allow_null = True)
	#shopify locations
	locations = serializers.ListField(required = False, allow_null = True, child = ShopifyLocationConfig())
	create_location = ShopifyLocationConfig(required = False, allow_null = True)

class StateChannelConfigInventorySerializer(serializers.Serializer):
	active = serializers.ListField(allow_null = True, allow_empty = True)
	disable = serializers.ListField(allow_empty = True, allow_null = True)

class FacebookProductCatalogSerializer(serializers.Serializer):
	catalog_id = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	name = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	def validate(self, attrs):
		if isinstance(attrs.get('catalog_id'), int):
			attrs['catalog_id'] = str(attrs['catalog_id'])
		return attrs

class CompanyMappingSerializer(serializers.Serializer):
	main_company = serializers.CharField(required = False, allow_null = True, allow_blank = True)
	channel_company = serializers.CharField(required = False, allow_null = True, allow_blank = True)

class CarrierMappingSerializer(serializers.Serializer):
	status = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True)
	company_mapping = serializers.ListField(child = CompanyMappingSerializer(required = False, allow_null = True))


class OtherSettingSerializer(serializers.Serializer):
	clean_description = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	clear_selected = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	sync_title = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	sync_description = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	carrier_mapping = CarrierMappingSerializer(required = False, allow_null = True)



class StateChannelConfigReverbMappingSerializer(serializers.Serializer):
	category_mapping = serializers.BooleanField(allow_null = True)
	# auto_mapping = serializers.BooleanField(allow_null = True)
	# custom_rules = serializers.BooleanField(allow_null = True)
	mapping_value = serializers.ListField(allow_empty = True, allow_null = True)

	def validate(self, attrs):
		if attrs.get('category_mapping') and attrs.get('mapping_value'):
			existed = list()
			for rule in attrs.get('mapping_value'):
				if rule['label'] == "":
					raise serializers.ValidationError("Product type could not be empty.")
				if not rule.get('value') or not rule['value'].get("uuid"):
					raise serializers.ValidationError("Category could not be empty.")
				if rule['label'] in existed:
					raise serializers.ValidationError("Duplicate product type, please check and select again.")
				else:
					existed.append(rule['label'])
		return attrs

class StateChannelConfigSettingSerializer(serializers.Serializer):
	price = StateChannelConfigPriceSyncSerializer(allow_null = True)
	order = StateChannelConfigOrderSyncSerializer(allow_null = True)
	qty = StateChannelConfigQtySyncSerializer(allow_null = True)
	inventory = StateChannelConfigInventorySerializer(allow_null = True)
	fb_product_catalog = FacebookProductCatalogSerializer(required = False)
	clean_description = serializers.ChoiceField(choices = ('enable', 'disable'), allow_null = True, allow_blank = True, required = False)
	images_resize = serializers.ChoiceField(choices = ('square', 'fit', 'crop'), allow_null = True, allow_blank = True, required = False)
	other_setting = OtherSettingSerializer(required = False, allow_null = True)
	reverb_mapping = StateChannelConfigReverbMappingSerializer(required = False, allow_null = True)

class ChannelSettingSerializer(serializers.Serializer):
	name = serializers.CharField()
	setting = StateChannelConfigSettingSerializer(allow_null = True)


class ChannelListingActionSerializer(serializers.Serializer):
	product_ids = serializers.ListField()
	action = serializers.ChoiceField(choices = ('renew', 'active', 'delete', 'end', 'relist', 'unlist'))


class FeedTypeSerializer(serializers.Serializer):
	feed_id = serializers.IntegerField(required = False, read_only = True)
	feed_type = serializers.ChoiceField(choices = ('add', 'update', 'delete'))
	feed_name = serializers.CharField(required = False)
	delimiter = serializers.ChoiceField(required = False, choices = (',', ';', '|'), default = ',')
	
	method = serializers.ChoiceField(choices = ('url', 'file', 'ftp'))
	format = serializers.ChoiceField(choices = ('litc', 'any'))
	mapping = serializers.DictField(required = False)
	first_line = serializers.ListField(child = serializers.CharField(), required = False)
	url = serializers.URLField(required = False, allow_blank = True, allow_null = True)
	host = serializers.CharField(required = False, allow_blank = True, allow_null = True)
	password = serializers.CharField(required = False, allow_blank = True, allow_null = True)
	directory = serializers.CharField(required = False, allow_blank = True, allow_null = True)
	user = serializers.CharField(required = False, allow_blank = True, allow_null = True)
