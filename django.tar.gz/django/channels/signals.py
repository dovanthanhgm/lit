from django.db.models.signals import pre_delete, post_save, pre_save
from django.dispatch import receiver

from channels.models import Channel
from channels.utils import ChannelUtils
from core.utils import CoreUtils
from datasync.api.callback import CallbackApi
from libs.models.collections.catalog import Catalog
from libs.utils import json_decode, log_traceback, to_str, json_encode


@receiver(pre_delete, sender = Channel)
def channel_pre_delete(sender, instance: Channel, **kwargs):
	try:
		ChannelUtils().disable_all_scheduler(instance.id)
		ChannelUtils().delete_all_product(instance)
		model_catalog = Catalog()
		model_catalog.set_user_id(instance.user_id)
		list_index = model_catalog.list_index()
		for index_name, value in list_index.items():
			if to_str(index_name).find(f'channel.channel_{instance.id}.') != -1:
				model_catalog.drop_index(index_name)
		model_channel = CoreUtils().get_channel_model_utils(channel_type = instance.type)
		if model_channel and hasattr(model_channel, 'delete_webhook'):
			model_channel.delete_webhook(instance)
	except Exception as e:
		log_traceback()
		pass


@receiver(pre_save, sender = Channel)
def channel_pre_save(sender, instance: Channel, **kwargs):
	try:
		api_info = json_decode(instance.api)
		if instance.type == 'amazon':
			if instance.support_amazon_gtin_exemption:
				api_info['gtin_exemption'] = True
				if instance.amazon_brand_gtin_exemption:
					api_info['gtin_exemption_brand'] = instance.amazon_brand_gtin_exemption
				elif api_info.get('gtin_exemption_brand'):
					del api_info['gtin_exemption_brand']
				if instance.amazon_node_gtin_exemption:
					api_info['gtin_exemption_node'] = instance.amazon_node_gtin_exemption
				elif api_info.get('gtin_exemption_node'):
					del api_info['gtin_exemption_node']
				if instance.amazon_category_gtin_exemption:
					api_info['gtin_exemption_category'] = instance.amazon_category_gtin_exemption
				elif api_info.get('gtin_exemption_category'):
					del api_info['gtin_exemption_category']
			elif api_info.get('gtin_exemption'):
				del api_info['gtin_exemption']
		if instance.log_request:
			api_info['is_log'] = True
		elif api_info.get('is_log'):
			del api_info['is_log']
		instance.api = json_encode(api_info)

	except Exception:
		pass


@receiver(post_save, sender = Channel)
def channel_post_save(sender, instance: Channel, **kwargs):
	try:
		if not kwargs.get('created'):
			data = {
				'api': instance.api,
				'default': instance.default

			}
			if instance.identifier:
				data['identifier'] = instance.identifier
			if instance.type == 'wix':
				api_info = json_decode(instance.api)
				if api_info.get('instance_id'):
					data['instance_id'] = api_info.get('instance_id')
			CallbackApi(user_id = instance.user_id).put(f'datasync_users/{instance.id}', data)

			return
		data = {
			'channel_type': instance.type,
			'channel_id': instance.id,
			'api': instance.api,
			'default': instance.default,
			'identifier': instance.identifier
		}
		if instance.type == 'wix':
			api_info = json_decode(instance.api)
			data['instance_id'] = api_info.get('instance_id')
		channel = CallbackApi(user_id = instance.user_id).post('datasync_users', data)
	except Exception:
		pass
