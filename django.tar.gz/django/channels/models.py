from django.db import models

from accounts.models import UserAccount


def choices_channel(return_list = False):
	channels = ['Amazon', 'BigCommerce', 'Ebay', 'Etsy', 'Facebook', 'Google', 'Magento', 'Shopify', 'Squarespace', 'Walmart', 'WalmartCa', 'Wish', 'Wix', 'WooCommerce', 'File', 'Reverb', 'OnBuy', 'Bonanza', 'Tiktok', 'Shopee']
	if return_list:
		return channels
	return ((row.lower(), row) for row in channels)


def choices_mainstore():
	channels = ['Shopify', 'WooCommerce', 'Squarespace', 'Wix', 'BigCommerce', 'Magento', 'File']
	return ((row.lower(), row) for row in channels)

# Create your models here.


class Channel(models.Model):
	STATUS_DISCONNECTED = 'disconnected'
	STATUS_CONNECTED = 'connected'
	"""
	Class User - Channels
	"""
	type = models.CharField(max_length = 11, blank = True, choices = choices_channel())
	name = models.CharField(max_length = 255, blank = True)
	identifier = models.CharField(max_length = 255, blank = True)
	url = models.CharField(max_length = 255, blank = True, null = True)
	api = models.TextField(blank = True, null = True)
	position = models.IntegerField(null = False, default = 0)
	first_setting = models.BooleanField(default = 0)
	sync_price = models.BooleanField(default = 0)
	sync_price_config = models.CharField(max_length = 255, blank = True, null = True)
	sync_qty = models.BooleanField(default = 0)
	sync_order = models.BooleanField(default = 0)
	sync_qty_config = models.CharField(max_length = 255, blank = True, null = True)
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True)
	status = models.CharField(max_length = 100, blank = False, default = STATUS_CONNECTED, choices = (('connected', 'Connected'), ('disconnected', 'Disconnected')))
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	deleted_at = models.DateTimeField(null = True, blank = True)
	last_imported = models.DateTimeField(null = True, blank = True)
	image = models.CharField(null = True, blank = True, max_length = 255)
	default = models.IntegerField(choices = ((0, 'No'), (1, 'Yes')), null = False, default = 0)
	auto_update = models.IntegerField(choices = ((0, 'No'), (1, 'Yes')), null = False, default = 0)
	auto_import = models.IntegerField(choices = ((0, 'No'), (1, 'Yes')), null = False, default = 0)
	number_products = models.IntegerField(null = False, default = 0)
	number_products_linked = models.IntegerField(null = False, default = 0)
	custom_linked_product = models.BooleanField(null = False, default = False)
	created_webhook = models.BooleanField(null = False, default = False)
	email_disconnected = models.BooleanField(null = False, default = False)
	settings = models.TextField(blank = True, null = True)
	previous_settings = models.TextField(blank = True, null = True)
	channel_number_products = models.TextField(blank = True, null = True)
	support_amazon_order = models.BooleanField(default = False)
	support_amazon_gtin_exemption = models.BooleanField(default = False)
	log_request = models.BooleanField(default = False)
	amazon_brand_gtin_exemption = models.CharField(null = True, blank = True, max_length = 255)
	amazon_node_gtin_exemption = models.CharField(null = True, blank = True, max_length = 255)
	amazon_category_gtin_exemption = models.CharField(null = True, blank = True, max_length = 255)
	walmart_timestamp_publish = models.BigIntegerField(null = True, blank = True, default = 0)
	skip_templates = models.CharField(null = True, blank = True, max_length = 255, default = "")

	# def delete(self, using = None, keep_parents = False):
	# 	self.deleted_at = timezone.now()
	# 	self.save()

	def force_delete(self):
		super(Channel, self).delete()


	def undelete(self):
		self.deleted_at = None
		self.save()


	def __str__(self):
		return self.name


	def is_shopping_cart(self):
		return self.type in ['woocommerce', 'magento', 'shopify', 'bigcommerce', 'wix', 'squarespace']


	def is_personal_cart(self):
		return self.type in ['woocommerce', 'magento']


	def have_webhook(self):
		return self.type in ['woocommerce', 'shopify', 'wix', 'bigcommerce', 'squarespace']


	def available_create_webhook(self):
		return self.type in ['woocommerce', 'shopify', 'bigcommerce', 'squarespace']


	class Meta:
		db_table = "channel"
		unique_together = (
			("name", "user_id"),
			("identifier", "type", "user_id"),
		)
		ordering = ['id']


class MerchantChannelAuthToken(models.Model):
	token = models.TextField(null = False)
	channel_type = models.CharField(null = False, max_length = 25)
	expires_in = models.IntegerField(null = False)
	user = models.ForeignKey(UserAccount, on_delete = models.CASCADE, null = True)
	extend_data = models.TextField(null = True)


	class Meta:
		db_table = "merchant_channel_token"
