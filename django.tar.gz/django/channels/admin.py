import time
from functools import update_wrapper

from django.contrib import admin
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import redirect
from django.urls import path
from django.urls import reverse
from django.utils.html import format_html

from accounts.models import UserLoginToken
from core.myadmin.admin import CoreAdmin, InputFilter, NameFilter
from core.utils import CoreUtils
from libs.utils import random_token, to_int, get_app_url, get_full_absolute_uri
from processes.models import Process
from .models import *
from .utils import ChannelUtils
from .views import ChannelExportView


class TypeFilter(InputFilter):
	parameter_name = 'type'
	title = ('Type')


	def queryset(self, request, queryset):
		if self.value() is not None:
			type = self.value()
			return queryset.filter(type = type)


class IdentifierFilter(InputFilter):
	parameter_name = 'identifier'
	title = ('Identifier')


	def queryset(self, request, queryset):
		if self.value() is not None:
			identifier = self.value()
			return queryset.filter(identifier__icontains = identifier)


class ProcessInline(admin.TabularInline):
	model = Process
	fields = ('user', 'pid', 'server', 'state_id', 'status', 'type', 'created_at', 'updated_at')
	readonly_fields = ('user', 'pid', 'server', 'state_id', 'status', 'type', 'created_at', 'updated_at')
	show_change_link = True
	can_delete = False
	extra = 0


class ChannelAdmin(CoreAdmin):
	search_fields = ['name', 'type', 'identifier', 'url', 'api', 'sync_price', 'sync_price_config', 'sync_qty',
	                 'sync_qty_config', 'user__email', 'status', 'created_at', 'updated_at', 'deleted_at']
	list_filter = (NameFilter, TypeFilter, IdentifierFilter, 'default')
	list_display = ['id', 'name', 'user_link', 'process_link', 'type', 'identifier', 'url', 'status', 'number_products', 'number_products_linked', 'created_at', 'updated_at', 'deleted_at']
	list_display_links = ('id', 'name')
	inlines = (ProcessInline,)
	ordering = ('-id',)
	list_per_page = 20

	change_form_template = "admin/channels/channel/edit_channel.html"
	dev_field_set = (
		(None, {'fields': ('type', 'name', 'identifier', 'url', 'first_setting','user','status','default','log_request')}),
		('Amazon', {'fields': ('amazon_brand_gtin_exemption','amazon_node_gtin_exemption','amazon_category_gtin_exemption','support_amazon_gtin_exemption')})
	)
	def get_fieldsets(self, request, obj=None):
		return super().get_fieldsets(request, obj)
	def user_link(self, obj):
		url = reverse("admin:accounts_useraccount_change", args = (obj.user_id,))
		return format_html(f"<a href='{url}' target='_blank' class='_link''>{obj.user.email}</a>")


	def process_link(self, obj):
		# url = reverse("admin:channels_process_change", args = (obj.id,))
		process = Process.objects.filter(channel_id = obj.id)
		if process:
			return format_html(f"<a href='/admin/channels/process/?channel__id__exact={obj.id}' target='_blank' class='_link''>Process</a>")


	def change_view(self, request, object_id, form_url = '', extra_context = None):
		extra = extra_context or {}
		obj = Channel.objects.get(pk = object_id)
		extra.update({"have_webhook": obj.default and obj.have_webhook()})
		return super().change_view(request, object_id, form_url, extra_context = extra)


	def get_urls(self):
		def wrap(view):
			def wrapper(*args, **kwargs):
				return self.admin_site.admin_view(view)(*args, **kwargs)


			wrapper.model_admin = self
			return update_wrapper(wrapper, view)


		urls = super().get_urls()
		my_urls = [
			path('response_change/', self.response_change),
			path('<int:channel_id>/export/', wrap(ChannelExportView.as_view()), name = 'channel_export'),

		]
		return my_urls + urls


	def export_channel(self, request, obj, channel_id):
		return JsonResponse({})


	def response_change(self, request, obj):
		if "_login_by_token" in request.POST:
			token = random_token(32)
			UserLoginToken.objects.create(token = token, expires_in = to_int(time.time()) + 30, user_id = obj.id, admin_id = request.user.id)
			return redirect(get_app_url(f"accounts/login-by-token?token={token}", obj))

		if "_view-process" in request.POST:
			process = Process.objects.filter(channel_id = obj.id)

			if not process:
				self.message_user(request, "Process not found")
				return HttpResponseRedirect("../")
			return HttpResponseRedirect(f"{get_full_absolute_uri('admin:channels_process_changelist')}?channel__id__exact={obj.id}")
		if "_verify_webhook" in request.POST:
			from django.contrib import messages
			verify = ChannelUtils().verify_webhook(obj)
			self.message_user(request, f"Order Update Webhook is {'Enable' if verify['order'] else 'Disable'}", level = messages.SUCCESS if verify['order'] else messages.ERROR)
			self.message_user(request, f"Product Delete Webhook is {'Enable' if verify['product'] else 'Disable'}", level = messages.SUCCESS if verify['product'] else messages.ERROR)
			url = reverse("admin:channels_channel_change", args = (obj.id,))
			return HttpResponseRedirect(url)
		if "_create_webhook" in request.POST:
			from django.contrib import messages
			verify = ChannelUtils().create_webhook(obj, force = True)
			url = reverse("admin:channels_channel_change", args = (obj.id,))
			return HttpResponseRedirect(url)
		if "_delete_webhook" in request.POST:
			from django.contrib import messages
			verify = ChannelUtils().delete_webhook(obj)
			url = reverse("admin:channels_channel_change", args = (obj.id,))
			return HttpResponseRedirect(url)
		return super().response_change(request, obj)


	def delete_model(self, request, obj):
		"""
		Given a model instance delete it from the database.
		"""
		obj.force_delete()


	def delete_queryset(self, request, queryset):
		"""Given a queryset, delete it from the database."""
		for obj in queryset:
			obj.force_delete()


admin.site.register(Channel, ChannelAdmin)
