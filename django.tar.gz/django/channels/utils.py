import copy
import time
from datetime import datetime, timedelta

from background_task.models import Task
from django.db.models import Q
from django.forms import model_to_dict

from channels.models import Channel, MerchantChannelAuthToken
from channels.scheduler import start_process, start_inventory_process
from datasync.api.sync import SyncApi
from libs.models.collections.catalog import Catalog
from libs.models.collections.state import State
from libs.models.collections.template import Template
from libs.utils import to_int, get_config_ini, log_traceback, json_decode, json_encode
from processes.models import Process
from processes.utils import ProcessUtils
from subscription.utils import SubscriptionUtils
from user_action_logs.utils import UserActionLogUtils


class ChannelUtils:
	def get(self, channel_id):
		"""

		:rtype: Channel or None
		"""
		try:
			channel = Channel.objects.get(pk = channel_id)
		except Channel.DoesNotExist:
			return None
		return channel


	def get_channel_by_user_id(self, user_id):
		try:
			channel = Channel.objects.filter(user_id = user_id)
		except Channel.DoesNotExist:
			return None
		return channel


	def channel_template_title(self, channel_type, template_type):
		default = template_type.capitalize() + " " + 'Templates'
		templates = {
			'shipping': 'Shipping Templates',
			'title': 'Title & Description Templates',
			'price': 'Pricing Templates',
			'category': 'Category Templates',
			'brand': 'Brand template',
		}
		if templates.get(channel_type):
			return templates[channel_type].get(template_type, templates.get(template_type, default))
		return templates.get(template_type, default)


	def filter(self, **kwargs):
		try:
			channel = Channel.objects.get(**kwargs)
			return channel
		except Exception as e:
			return None


	def get_deleted_channels_by_user_id(self, user_id):
		return Channel.objects.filter(user_id = user_id).exclude(deleted_at = None)


	def get_scheduler_inventory(self, channel_id):
		return self.get_scheduler_by_type(channel_id, ProcessUtils.TYPE_INVENTORY)


	def get_scheduler_order(self, channel_id):
		return self.get_scheduler_by_type(channel_id, ProcessUtils.TYPE_ORDER)


	def get_scheduler_by_type(self, channel_id, process_type):
		process = ProcessUtils().get_process_by_type(channel_id, process_type)
		if not process:
			return None
		task = self.get_task_by_process(process)
		return task


	def get_task_by_process(self, process):
		try:
			task = Task.objects.filter(verbose_name = process.id).first()
		except Task.DoesNotExist:
			return None
		return task


	def create_task(self, process: Process):
		repeat = self.get_repeat_scheduler(process) * 60
		if process.type == ProcessUtils.TYPE_REFRESH and not process.channel.is_shopping_cart():
			repeat *= 5
		if process.channel.type == 'bonanza':
			repeat *= 20
		if process.type != ProcessUtils.TYPE_INVENTORY:
			start_process(process_id = process.id, verbose_name = process.id, repeat = repeat)
		else:
			start_inventory_process(process_id = process.id, verbose_name = process.id, repeat = repeat)



	def create_scheduler_order(self, channel_id):
		self.create_scheduler(channel_id, ProcessUtils.TYPE_ORDER)


	def create_scheduler_inventory(self, channel_id):
		self.create_scheduler(channel_id, ProcessUtils.TYPE_INVENTORY)


	def enable_refresh_sync(self, channel_id, channel = False):
		if channel and channel.type == 'file':
			return
		scheduler = self.get_scheduler_by_type(channel_id, ProcessUtils.TYPE_REFRESH)
		if not scheduler:
			self.create_scheduler_refresh(channel_id)


	def disable_refresh_sync(self, channel_id, channel = None):
		self.disable_sync(channel_id, ProcessUtils.TYPE_REFRESH)
		if not channel:
			channel = self.get(channel_id)
		channel.auto_update = False
		channel.save()


	def create_scheduler_refresh(self, channel_id):
		process = ProcessUtils().get_process_by_type(channel_id, ProcessUtils.TYPE_REFRESH)
		if not process:
			process_product = ProcessUtils().get_process_by_type(channel_id, ProcessUtils.TYPE_PRODUCT)
			model_state = State()
			model_state.set_user_id(process_product.user_id)
			state = model_state.get(process_product.state_id)
			del state['_id']
			if state.get('id'):
				del state['id']
			date_obj = datetime.now() - timedelta(hours = 7)
			state['pull']['process']['products']['last_modified'] = to_int(date_obj.timestamp())
			state_id = model_state.create(state)
			process_data = {
				"channel_id": channel_id,
				"user_id": process_product.user_id,
				"state_id": state_id,
				"type": ProcessUtils.TYPE_REFRESH,
				"status": "new",
			}
			process = Process.objects.create(**process_data)
			model_state.update_field(state_id, 'sync_id', process.id)
		self.create_task(process)


	def create_scheduler(self, channel_id, process_type):
		sync_api = SyncApi(channel_id = channel_id)
		process = ProcessUtils().get_process_by_type(channel_id, process_type)
		if not process:
			if process_type == 'inventory':
				endpoint = f"channel/{channel_id}/create-inventory-process"
			else:
				endpoint = f"order/process/{channel_id}"

			create_inventory_process = sync_api.api(endpoint, method = 'post')
			if create_inventory_process and create_inventory_process['data']:
				process_id = create_inventory_process['data']
				process = ProcessUtils().get(process_id)
		if not process:
			return None
		self.create_task(process)


	def disable_inventory_sync(self, channel_id):
		self.disable_sync(channel_id, ProcessUtils.TYPE_INVENTORY)


	def enable_inventory_sync(self, channel_id):
		scheduler = self.get_scheduler_inventory(channel_id)
		if not scheduler:
			self.create_scheduler_inventory(channel_id)


	def enable_order_sync(self, channel_id, request_date = None):
		scheduler = self.get_scheduler_order(channel_id)
		if not scheduler:
			self.create_scheduler_order(channel_id)
			process = ProcessUtils().get_process_by_type(channel_id, ProcessUtils.TYPE_ORDER)
			if process:
				state_id = process.state_id
				model_state = State()
				model_state.set_user_id(process.user_id)
				if not request_date:
					date_obj = datetime.now() - timedelta(hours = 12)
					request_date = to_int(date_obj.timestamp())
				state = model_state.get(state_id)
				if state:
					model_state.update_field(state_id, "channel.config.start_time", request_date)


	def disable_order_sync(self, channel_id):
		self.disable_sync(channel_id, ProcessUtils.TYPE_ORDER)


	def disable_sync(self, channel_id, process_type):
		index = 1
		while index < 2:
			scheduler = self.get_scheduler_by_type(channel_id, process_type)
			if not scheduler:
				return
			scheduler.delete()
			time.sleep(3)


	def is_shopping_cart(self, cart_type):
		return cart_type in ['woocommerce', 'magento', 'shopify', 'bigcommerce', 'wix', 'squarespace']


	def get_default_channel(self, user_id):
		try:
			channels = Channel.objects.filter(user_id = user_id, default = 1).first()
			return channels
		except Channel.DoesNotExist:
			return False
		# if channels and self.is_shopping_cart(channels.type):
		# 	return channels
		return False


	def get_channel_by_id(self, user_id, channel_id):
		try:
			channels = Channel.objects.filter(user_id = user_id, pk = channel_id).first()
		except Channel.DoesNotExist:
			return False
		if channels:
			return channels
		return False


	def get_first_channel(self, user_id):
		try:
			channels = Channel.objects.filter(user_id = user_id, default = 0).first()
		except Channel.DoesNotExist:
			return False
		return channels


	def get_channel_by_channel_type(self, user_id, channel_type, **kwargs):
		try:
			channels = Channel.objects.filter(user_id = user_id, type = channel_type, **kwargs).first()
		except Channel.DoesNotExist:
			return False
		return channels


	def filter_channel(self, **kwargs):
		try:
			channels = Channel.objects.filter(**kwargs).first()
		except Channel.DoesNotExist:
			return False
		except Exception:
			return False
		return channels


	def channel_allow_action(self, channel_type, action):
		allow_action = ['active', 'delete']
		if channel_type == 'etsy':
			allow_action += ['renew']
		if channel_type == 'ebay':
			allow_action += ['end', 'relist']
		if channel_type == 'reverb':
			allow_action += ['end','ended']
		if channel_type == 'shopee':
			allow_action += ['unlist']
		return action in allow_action


	def get_repeat_scheduler(self, process):
		user = process.user
		if hasattr(user, 'repeat_scheduler') and user.repeat_scheduler:
			return to_int(user.repeat_scheduler)
		user_plan = SubscriptionUtils().get_plan_by_user(user)
		if not user_plan.get('expired'):
			if process.type == 'order':
				return user_plan.get('order_sync_frequency')
			return user_plan.get('sync_frequency')
		return to_int(get_config_ini('server', 'time_repeat_scheduler', 30))


	def disable_all_scheduler(self, channel_id):
		self.disable_inventory_sync(channel_id)
		self.disable_order_sync(channel_id)
		self.disable_refresh_sync(channel_id)


	def channel_setting(self, channel, settings):
		from core.utils import CoreUtils
		model_class = CoreUtils().get_channel_model_utils(channel.type)
		if not model_class:
			return True
		if hasattr(model_class, 'channel_setting'):
			try:
				getattr(model_class, 'channel_setting')(channel, settings)
			except Exception:
				log_traceback()
		return True


	def create_token_channel(self, token, channel_type, user_id):
		MerchantChannelAuthToken.objects.create(token = token, channel_type = channel_type, user_id = user_id, expires_in = to_int(time.time()) + 60)


	def validate_channel_token(self, token, channel_type):
		try:
			auth_token = MerchantChannelAuthToken.objects.get(token = token, channel_type = channel_type)
		except:
			return False
		if auth_token.expires_in < to_int(time.time()):
			return False
		from django.forms import model_to_dict
		return model_to_dict(auth_token)


	def get_feeds_limit(self, user):
		plan = SubscriptionUtils().get_plan_by_user(user)
		if plan.get('expired'):
			return 1
		return plan.get('feeds_limit')


	def get_category_process(self, channel):
		category_process = ProcessUtils().get_process_by_type(channel.id, ProcessUtils.TYPE_CATEGORY)
		if category_process:
			return category_process
		product_process = ProcessUtils().get_process_by_type(channel.id)
		model_state = State()
		model_state.set_user_id(channel.user_id)
		state = model_state.get(product_process.state_id)
		del state['_id']
		state_id = model_state.create(state)
		process_data = dict(
			type = ProcessUtils.TYPE_CATEGORY,
			state_id = state_id,
			channel_id = channel.id,
			user_id = channel.user_id
		)
		process = Process.objects.create(**process_data)
		return process


	def setting_for_channel(self, channel: Channel, update_settings, channel_name = None, request = None, user_setting = False):
		model_state = State()
		model_state.set_user_id(channel.user_id)
		where = {"channel.id": channel.id}

		if json_decode(channel.settings):
			current_settings = json_decode(channel.settings)
		else:
			current_state = model_state.find_one(where)
			if current_state:
				current_settings = current_state['channel']['config']['setting']
			else:
				current_settings = {}
		copy_update_settings = copy.deepcopy(update_settings)

		channel.first_setting = 1
		channel.sync_qty = update_settings.get('qty', {}).get('status') == 'enable'
		api_info = json_decode(channel.api)
		if api_info and api_info.get('skip_sync_inventory'):
			channel.sync_qty = False
			copy_update_settings['qty']['status'] = 'disable'
		data_update = {
			"channel.config.setting": copy_update_settings,
		}

		if channel_name:
			data_update['channel.name'] = channel_name
			channel.name = channel_name
		model_state.update_many(where, data_update)
		channel.sync_price = update_settings.get('price', {}).get('status') == 'enable'
		channel.sync_order = update_settings.get('order', {}).get('status') == 'enable'
		channel.settings = json_encode(update_settings)
		channel.save()
		self.channel_setting(channel, update_settings)
		if not channel.default:
			enable_sync = False
			# enable_auto_update = False
			if update_settings and ((update_settings.get('price', {}) and update_settings['price'].get('status') == 'enable') or (update_settings.get('qty') and update_settings.get('qty').get('status') == 'enable') or (update_settings.get('other_setting') and (update_settings['other_setting'].get('sync_title') == 'enable' or update_settings['other_setting'].get('sync_description') == 'enable'))):
				enable_sync = True
				api_info = json_decode(channel.api)
				if not api_info or not api_info.get('skip_sync_inventory'):
					self.enable_inventory_sync(channel.id)

			else:
				self.disable_inventory_sync(channel.id)

			if (update_settings and update_settings.get('qty', {}) and update_settings['qty'].get('status') == 'enable') or update_settings.get('order', dict()).get('status') == 'enable':
				enable_sync = True
				ChannelUtils().enable_order_sync(channel.id, request._request_date if request else None)
			else:
				ChannelUtils().disable_order_sync(channel.id)
			if enable_sync and user_setting:
				refresh_sync = False
				if update_settings and update_settings.get('price', {}).get('status') == 'enable':
					price_fields = ['direction', 'modifier', 'value', 'status', 'use_sale_price', 'use_stp']
					for field in price_fields:
						if update_settings.get('price', {}).get(field) != current_settings.get('price', {}).get(field):
							if field != 'status':
								refresh_sync = True
							elif current_settings.get('price', {}).get(field) == 'enable':
								refresh_sync = True
				if update_settings and update_settings.get('qty', {}) and update_settings['qty'].get('status') == 'enable':
					qty_fields = ['adjust', 'min_qty', 'max_qty', 'status', 'no_manage_stock_qty', 'outofstock_threshold', 'locations', 'keep_active']
					for field in qty_fields:
						if update_settings['qty'].get(field) != current_settings.get('qty', {}).get(field):
							if field != 'status':
								refresh_sync = True
							elif current_settings.get('qty', {}).get(field) == 'enable':
								refresh_sync = True
				if update_settings.get('other_setting'):
					if update_settings['other_setting'].get('sync_title') == 'enable':
						if not current_settings or not current_settings.get('other_setting') or current_settings['other_setting'].get('sync_title') != 'enable':
							refresh_sync = True
					if update_settings['other_setting'].get('sync_description') == 'enable':
						if not current_settings or not current_settings.get('other_setting') or current_settings['other_setting'].get('sync_description') != 'enable':
							refresh_sync = True

				if refresh_sync:
					process = ProcessUtils().get_process_by_type(channel.id, 'inventory')
					if process:
						model_state.update_field(process.state_id, 'need_refresh', True)
			if user_setting:
				UserActionLogUtils().create_log(channel.user_id, channel.id, 'setting_save', data = {'old_setting': current_settings, 'new_setting': update_settings}, request = request)
			if channel.type == 'etsy':
				query_set = Channel.objects.filter(Q(sync_price = True) | Q(sync_qty = True)).filter(user_id = channel.user_id, type = 'etsy', deleted_at__isnull = True)
				count = query_set.count()
				if count > 3:
					time_scheduler = 60
					if count > 6:
						time_scheduler = 90
					query_set_process = Process.objects.filter(channel_id__in = query_set.values('id')).values('id')
					Task.objects.filter(verbose_name__in = query_set_process).update(repeat = time_scheduler * 60)
		return True


	def delete_all_product(self, channel, status = None):
		user_id = channel.user_id
		channel_actives = Channel.objects.filter(user_id = user_id, deleted_at__isnull = True)
		model_product = Catalog()
		model_product.set_user_id(user_id)
		where = list()
		if status:
			where.append(model_product.create_where_condition(f'channel.channel_{channel.id}.status', status))
		for channel_active in channel_actives:
			if channel_active.id == channel.id:
				continue
			where_row = [
				model_product.create_where_condition(f'channel.channel_{channel_active.id}', {}),
				model_product.create_where_condition(f'channel.channel_{channel_active.id}', False, 'exists')
			]
			where.append(model_product.create_where_condition(None, where_row, 'or'))
		where_delete = model_product.create_where_condition(None, where, 'and')
		model_product.delete_many_document(where_delete)
		where_unset = {}
		if status:
			where_unset.update(model_product.create_where_condition(f'channel.channel_{channel.id}.status', status))
		model_product.unset_many(where_unset, f"channel.channel_{channel.id}")

		return True


	def export_channel(self, channel):
		channel_data = model_to_dict(channel)
		channel_del_field = ['id', 'user', 'deleted_at', 'position']
		for field in channel_del_field:
			del channel_data[field]
		process = ProcessUtils().get_process_by_type(channel.id, 'product')
		state_id = process.state_id
		model_state = State()
		model_state.set_user_id(channel.user_id)
		state_data = model_state.get(state_id)
		model_template = Template()
		model_template.set_user_id(channel.user_id)
		where_template = model_state.create_where_condition('channel_id', channel.id)
		templates = model_template.find_all(where_template)
		return {
			'channel': channel_data,
			'state': state_data,
			'templates': templates
		}


	def create_webhook(self, channel: Channel, force = False):
		if channel.created_webhook and not force:
			return
		from core.utils import CoreUtils
		model_class = CoreUtils().get_channel_model_utils(channel.type)
		if not model_class:
			return True
		if hasattr(model_class, 'create_webhook'):
			try:
				api_info = getattr(model_class, 'create_webhook')(channel)
			except Exception:
				api_info = False
				log_traceback()
			if api_info:
				channel.api = json_encode(api_info)
		channel.created_webhook = True
		channel.save()
		return True


	def delete_webhook(self, channel: Channel):
		from core.utils import CoreUtils
		model_class = CoreUtils().get_channel_model_utils(channel.type)
		if not model_class:
			return True
		if hasattr(model_class, 'delete_webhook'):
			try:
				api_info = getattr(model_class, 'delete_webhook')(channel)
			except Exception:
				api_info = False
				log_traceback()
			if api_info:
				channel.api = json_encode(api_info)
		channel.created_webhook = False
		channel.save()
		return True


	def verify_webhook(self, channel: Channel):
		if not channel.have_webhook():
			return
		from core.utils import CoreUtils
		model_class = CoreUtils().get_channel_model_utils(channel.type)
		if not model_class:
			return True
		model_class = CoreUtils().get_channel_model_utils(channel.type)
		return model_class.verify_webhook(channel)