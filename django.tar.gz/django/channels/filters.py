import jwt

from django_filters import FilterSet

from accounts.utils import AccountUtils
from libs.utils import get_private_key
from .models import Channel


class ChannelFilter(FilterSet):
	class Meta:
		model = Channel
		fields = ['name', 'identifier', 'type', 'status']


	@property
	def qs(self):
		channel = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return channel.filter(user_id = user_id, deleted_at = None).exclude(type__in = ('litcommerce', 'bulk_edit'))


class ChannelFilterPrivate(FilterSet):
	class Meta:
		model = Channel
		fields = ['name', 'identifier', 'type', 'status']


	@property
	def qs(self):
		channel = super().qs
		user_id = AccountUtils().get_user_id(self.request)
		return channel.filter(user_id = user_id)
