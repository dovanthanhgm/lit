from django.urls import path, include

from .views import ChannelList, ChannelDetail, ChannelDetailPrivate, ChannelListPrivate, ChannelSettingAPIView, GetChannelSettingAPIView, GoToUser, GetProcessByChannel, ChannelListingAction, EnableRefreshProduct, DisableRefreshProduct, ChannelReconnectApiView, ChannelAfterImport, FeedsApiView, FeedDetailsApiView, FeedStartProcessApi, FeedDisableSchedulerApi, FeedEnableSchedulerApi, ChannelDisconnected, EnableAutoImportProduct, DisableAutoImportProduct, SkipTemplatesRequire

urlpatterns = [
	path("", ChannelList.as_view()),
	path('/private', include([
		path('', ChannelListPrivate.as_view()),
		path('/<int:pk>', include([
			path('', ChannelDetailPrivate.as_view()),
			path('/disconnected', ChannelDisconnected.as_view()),
			path('/<int:process_id>/after-import', ChannelAfterImport.as_view()),
		])),
	])),
	path("/<int:pk>", ChannelDetail.as_view()),
	path('/<int:channel_id>/', include([
		path('feeds', include([
			path('', FeedsApiView.as_view(), name = 'get_feeds'),
			path('/<int:feed_id>', include([
				path('', FeedDetailsApiView.as_view(), name = 'feed_details'),
				path('/start-process', FeedStartProcessApi.as_view(), name = 'feed_start_process'),
				path('/enable-scheduler', FeedEnableSchedulerApi.as_view(), name = 'feed_enable_scheduler'),
				path('/disable-scheduler', FeedDisableSchedulerApi.as_view(), name = 'feed_disable_scheduler'),

			])),
		])),
		path('process', GetProcessByChannel.as_view(), name = 'get_process'),
		path('setting', ChannelSettingAPIView.as_view()),
		path('state', GetChannelSettingAPIView.as_view(), name = 'edit_channel'),
		path("enable-refresh", EnableRefreshProduct.as_view(), name = 'enable.refresh'),
		path("disable-refresh", DisableRefreshProduct.as_view(), name = 'disable.refresh'),
		path("enable-autoimport", EnableAutoImportProduct.as_view(), name = 'enable.autoimport'),
		path("disable-autoimport", DisableAutoImportProduct.as_view(), name = 'disable.autoimport'),
		path("mass-action", ChannelListingAction.as_view(), name = 'channel.mass_action'),
		path("reconnect", ChannelReconnectApiView.as_view(), name = 'channel.reconnect'),
		path('skip-templates', SkipTemplatesRequire.as_view(), name = 'skip_templates'),
	])),
	# path("/<int:channel_id>/process", GetProcessByChannel.as_view(), name = 'get_process'),
	# path("/<int:channel_id>/setting", ChannelSettingAPIView.as_view()),
	# path("/<int:channel_id>/state", GetChannelSettingAPIView.as_view(), name = 'edit_channel'),
	path('/admin/go-to-user/<int:user_id>', GoToUser.as_view(), name = 'go_to_user'),
]
