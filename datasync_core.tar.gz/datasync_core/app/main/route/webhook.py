import time

from flask import Blueprint, jsonify

from datasync.libs.utils import start_subprocess, get_flask_request_data, log_no_date, to_int, to_str

webhook_path = Blueprint('webhook_path', __name__)

@webhook_path.route("webhook", methods = ['post'])
def user_controller_action():
	request_data = get_flask_request_data()
	buffer = dict()
	buffer['controller'] = 'webhook'
	buffer['action'] = 'execute'
	file_log = to_str(to_int(time.time()))
	log_no_date(request_data, 'webhook', file_log)
	buffer['data'] = {'file_log': file_log}
	create = start_subprocess(buffer, wait = False)
	return jsonify(create)