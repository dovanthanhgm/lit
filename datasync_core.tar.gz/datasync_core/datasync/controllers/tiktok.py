from datasync.controllers.cart import ControllerCart

# from datasync.models.channel import ModelChannel
from datasync.libs.response import Response


class ControllerTiktok(ControllerCart):
	CART_TYPE = 'tiktok'


	def set_product_id(self, data = None):
		self._product_id = data.get('product_id')


