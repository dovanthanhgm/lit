import os

from datasync.libs.utils import get_pub_path, json_decode, to_int, get_controller, log_traceback, log


class ControllerWebhook:
	def __init__(self, kwargs):
		self._file_log = kwargs.get('file_log')
		file = get_pub_path() + f"/log/webhook/{kwargs.get('file_log')}.log"
		with open(file, "r") as f:
			self._data = f.read()
		self._data = json_decode(self._data)
		os.remove(file)


	def execute(self, action_name, data):
		events = self._data['events']
		channels = self._data['channels']
		for channel in channels:
			del channel['id']
			channel['id'] = channel['channel_id']
		processes = self._data['processes']
		for process in processes:
			del process['id']
			process['id'] = process['process_id']
		all_events = dict()
		for row in events:
			channel_id = to_int(row['channel_id'])
			if not all_events.get(channel_id):
				all_events[channel_id] = list()
			all_events[channel_id].append(row)
		for channel_id, channel_events in all_events.items():
			try:
				events_check = list()
				events_set = list()
				for event in channel_events:
					key_check = f"{event['entity_id']}-{event['event']}"
					if key_check in events_check:
						continue
					events_set.append(event)
					events_check.append(key_check)
				user_channel = list(filter(lambda x: to_int(x['channel_id']) == channel_id, channels))[0]
				user_id = to_int(user_channel['user_id'])
				user_channels = list(filter(lambda x: to_int(x['user_id']) == user_id, channels))
				user_processes = list(filter(lambda x: to_int(x['user_id']) == user_id, processes))
				row_data = {
					'channels': {row['id']: row for row in user_channels},
					'user_id': user_id,
					'processes': {row['id']: row for row in user_processes},
					'identifier': channel_events[0]['identifier'],
					'events': events_set,
					'channel_id': channel_id
				}
				channel = list(filter(lambda x: to_int(x['channel_id']) == channel_id, user_channels))[0]
				controller_name = channel['channel_type']
				controller = get_controller(controller_name, row_data)

				controller.webhook(row_data)
			except:
				log_traceback(f'channel/{channel_id}/webhook')
