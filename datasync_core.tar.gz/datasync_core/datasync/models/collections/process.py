from datasync.models.collection import ModelCollection


class CollectionProcess(ModelCollection):
	COLLECTION_NAME = 'processes'
