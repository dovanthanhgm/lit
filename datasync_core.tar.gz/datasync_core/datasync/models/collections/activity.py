import time

from datasync.models.collection import ModelCollection
from datasync.models.constructs.activity import ActivityNotification, ActivityProcess, ActivityRecent, ActivityProductChanged, Activity, ActivityOrderSync


class CollectionActivity(ModelCollection):
	COLLECTION_NAME = 'activities'


	def before_create(self, data, **kwargs):
		fields = ['activity_type', 'code', 'channel_id', 'description', 'date_requested', 'result', 'content']
		for field in fields:
			if kwargs.get(field):
				data[field] = kwargs[field]
		return data


	def create_notification(self, **kwargs):
		data = ActivityNotification()
		data = self.before_create(data, **kwargs)
		return self.create(data.to_dict())

	def create_product_changed(self, **kwargs):
		data = ActivityProductChanged()
		data.product_id = kwargs.get('product_id')
		data.product_name = kwargs.get('product_name')
		data.product_sku = kwargs.get('product_sku')
		data.product_img = kwargs.get('product_img')
		data = self.before_create(data, **kwargs)
		return self.create(data.to_dict())

	def create_feed(self, **kwargs):
		kwargs['group'] = 'feed'
		kwargs['channel_id'] = kwargs['channel_id']
		kwargs['time_created'] = time.time()
		create = self.create(kwargs)
		# where = self.create_where_condition('group', 'feed')
		# where.update(self.create_where_condition('feed_id', kwargs['feed_id']))
		# recent = self.find_all(where, sort = '-_id', limit = 10, select_fields = '_id')
		# recent_ids = [row['_id'] for row in recent]
		# if recent_ids:
		# 	where.update(self.create_where_condition('_id', recent_ids, 'nin'))
		# 	self.delete_many_document(where)
		return create


	def create_process(self, **kwargs):
		data = ActivityProcess()
		data = self.before_create(data, **kwargs)
		return self.create(data.to_dict())


	def create_recent(self, **kwargs):
		data = ActivityRecent()
		data = self.before_create(data, **kwargs)
		create = self.create(data.to_dict())
		# where = self.create_where_condition('group', 'recent')
		# recent = self.find_all(where, sort = '-_id', limit = 20, select_fields = '_id')
		# recent_ids = [row['_id'] for row in recent]
		# if recent_ids:
		# 	where.update(self.create_where_condition('_id', recent_ids, 'nin'))
		# 	self.delete_many_document(where)
		return create


	def create_order_sync(self, **kwargs):
		data = ActivityOrderSync()
		data = self.before_create(data, **kwargs)
		order_data = data.to_dict()
		order_data.update(kwargs)
		create = self.create(order_data)
		# where = self.create_where_condition('group', Activity.GROUP_ORDER_SYNC)
		# recent = self.find_all(where, sort = '-_id', limit = 20, select_fields = '_id')
		# recent_ids = [row['_id'] for row in recent]
		# if recent_ids:
		# 	where.update(self.create_where_condition('_id', recent_ids, 'nin'))
		# 	self.delete_many_document(where)
		return create


	def create_activity(self, group, **kwargs):
		data = Activity()
		data.set_group(group)
		data = self.before_create(data, **kwargs)
		if kwargs.get('updated_at'):
			data['updated_at'] = kwargs['updated_at']
		create = self.create(data.to_dict())
		return create