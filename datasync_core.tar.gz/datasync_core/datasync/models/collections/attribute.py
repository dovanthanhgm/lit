from datasync.models.collection import ModelCollection


class Attributes(ModelCollection):
	COLLECTION_NAME = 'attributes'
