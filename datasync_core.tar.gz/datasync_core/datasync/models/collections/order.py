from datasync.models.collection import ModelCollection


class CollectionOrder(ModelCollection):
	COLLECTION_NAME = 'orders'
