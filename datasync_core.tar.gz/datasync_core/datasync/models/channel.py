import copy
import io
import time
import unicodedata
import uuid
from itertools import product
from PIL import Image
import chardet
import pytz
import requests
import sendgrid
import validators as python_validators
from dateutil import relativedelta
from sendgrid.helpers.mail import *
from jinja2 import Template as JinjaTemplate
from datasync.libs.db.nosql import Nosql
from datasync.libs.errors import Errors
from datasync.libs.messages import Messages
from datasync.libs.response import Response
from datasync.libs.storage.google import ImageStorageGoogle, FileStorageGoogle
from datasync.libs.template_condition import TemplateCondition
from datasync.libs.tracking_company import TrackingCompany
from datasync.libs.utils import *
from datasync.models.collections.activity import CollectionActivity
from datasync.models.collections.attribute import Attributes
from datasync.models.collections.catalog import Catalog
from datasync.models.collections.category import Category
from datasync.models.collections.deleted_product import CollectionDeletedProduct
from datasync.models.collections.order import CollectionOrder
from datasync.models.collections.process import CollectionProcess
from datasync.models.collections.state import State
from datasync.models.collections.template import Template
from datasync.models.constructs.activity import Activity
from datasync.models.constructs.category import CatalogCategory, CategoryChannel
from datasync.models.constructs.order import OrderChannel, Order
from datasync.models.constructs.product import Product, ProductChannel, ProductVariant, ProductSpecialPrice
from datasync.models.constructs.state import SyncState, StateChannelAuth, StateChannelConfigPriceSync, StateChannelConfigQtySync, EntityProcess
from datasync.models.mode import ModelMode


class ModelChannel:
	INIT_INDEX_FIELDS = []
	_state: SyncState or None
	_model_sync_mode: ModelMode or None
	_model_state: State or None
	_db: Nosql or None
	FIELD_EMPTY = '__empty__'
	COLLECTION_CATALOG_NAME = 'catalog'
	COLLECTION_ORDER_NAME = 'order'
	COLLECTION_TEMPLATE_NAME = 'template'
	DOCUMENT_CHANNEL_FIELD = 'channel'
	CONNECTOR_SUFFIX = 'le_connector'
	URL_IMAGE_PROXY = "http://45.56.81.195/img_proxy.php?img="
	PROCESS_STOPPED = 'stopped'
	PROCESS_PUSHING = 'pushing'
	PROCESS_PULLING = 'pulling'
	PROCESS_COMPLETED = 'completed'
	PROCESS_KILLED = 'killed'
	PROCESS_TYPE_PRODUCT = 'product'
	PROCESS_TYPE_CATEGORY = 'category'
	PROCESS_TYPE_ORDER = 'order'
	PROCESS_TYPE_INVENTORY = 'inventory'
	PROCESS_TYPE_REFRESH = 'refresh'
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title']
	SHIPPING_WEIGHT_RANGE = 'shipping_weight_range'
	_model_catalog: Catalog or None
	_model_category: Category or None
	_model_attribute: Attributes or None
	_model_template: Template or None
	_model_order: CollectionOrder or None
	_model_process: CollectionProcess or None
	_storage_image_service: ImageStorageGoogle


	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._storage_image_service = None
		self._storage_service = None
		self._request_data = dict()
		self._user_id = kwargs.get('user_id')
		self._channel_type = kwargs.get('channel_type')
		self._state = None
		self._server_name = None
		self._model_state = State()
		self._model_catalog = None
		self._model_category = None
		self._model_attribute = None
		self._model_template = None
		self._model_order = None
		self._model_process = None
		self._model_deleted_product = None
		self._sync_id = None
		self._channel_id = None
		self._product_id = None
		self._is_test = False
		self._channel_url = ''
		self._response = Response()
		self._error = Errors()
		self._model_sync_mode = None
		self._identifier = ''
		self._name = ''
		self._type = ''
		self._id = ''
		self._last_header = None
		self._last_status = None
		self._db = None
		self._state_id = None
		self._pid = os.getpid()
		self._action_stop = False
		self._warehouse_location_default = None
		self._warehouse_location_fba = None
		self._date_requested = None
		self._is_update = False
		self._process_type = ''
		self._user_plan = None
		self._user_info = None
		self._is_inventory_process = False
		self._publish_action = None
		self._src_channel_id = None
		self._channel_action = None
		self._channel_default_id = None
		self._product_available_import = None
		self._order_available_import = None
		self._user_info = None
		self._limit_process = None
		self._all_channel = dict()
		self._all_channel_by_id = dict()
		self._product_max_last_modified = ''
		self._order_max_last_modified = ''
		self._template_update = False
		self._custom_data = None
		self._extend_product_map = {}
		self._total_product = 0
		self._total_product_batch_import = 0
		self._product_need_refresh = []
		self._order_product_need_refresh = []
		self._live_process_id = False
		self._categories_path_by_id = {}
		self._new_sync_product_id = False
		self.is_sync_product_process = False


	def get_new_sync_product_id(self):
		return self._new_sync_product_id


	def set_new_sync_product_id(self, product_id):
		self._new_sync_product_id = product_id

	def set_sync_product_process(self, is_update):
		self.is_sync_product_process = is_update

	def get_pid(self):
		return self._pid


	def add_product_to_need_refresh(self, product_id):
		if product_id not in self._product_need_refresh:
			self._product_need_refresh.append(product_id)


	def add_order_product_need_refresh(self, product):
		for row in self._order_product_need_refresh:
			if product['_id'] == row['_id']:
				return
		self._order_product_need_refresh.append(product)


	def get_list_product_need_refresh(self):
		return self._product_need_refresh


	def get_list_order_product_need_refresh(self):
		return self._order_product_need_refresh


	def set_data(self, data):
		if not data:
			data = {}
		self._request_data = data


	def set_channel_action(self, channel_action):
		self._channel_action = channel_action


	def set_template_update(self, template_update):
		self._template_update = template_update


	def is_template_update(self):
		return self._template_update


	def is_channel_action(self):
		return True if self._channel_action else False


	def set_src_channel_id(self, channel_id):
		self._src_channel_id = channel_id


	def get_src_channel_id(self):
		if self._src_channel_id:
			return self._src_channel_id
		return self._state.channel.id


	def set_publish_action(self, publish_action):
		self._publish_action = publish_action


	def get_publish_action(self):
		return self._publish_action


	def get_process_type(self):
		return self._process_type


	def set_process_type(self, _process_type):
		self._process_type = _process_type


	def set_channel_id(self, channel_id):
		self._channel_id = to_int(channel_id)


	def set_limit_process(self, limit):
		self._limit_process = limit


	def get_channel_id(self):
		if self._channel_id:
			return self._channel_id
		self._channel_id = to_int(self._state.channel.id)
		return self._channel_id


	def get_channel_url(self):
		if self._channel_url:
			return self._channel_url.strip('/')
		return self._state.channel.url.strip('/')


	def get_user_plan(self):
		if self._user_plan:
			return self._user_plan
		self._user_plan = self.get_model_sync_mode().get_user_plan()
		return self._user_plan


	def get_user_info(self):
		if self._user_info:
			return self._user_info
		if self._request_data.get('user_data'):
			self._user_info = self._request_data.get('user_data')
			return self._user_info
		self._user_info = self.get_model_sync_mode().get_user_info()
		return self._user_info


	def get_category_path(self, channel_type, type_search, params):
		category_id = False
		try:
			if params and params.get('category_id'):
				category_id = params['category_id']
			if category_id and self._categories_path_by_id.get(to_str(category_id)):
				return self._categories_path_by_id.get(to_str(category_id))
		except:
			self.log_traceback()
		category_path = self.get_model_sync_mode().get_category_path(channel_type, type_search, params)
		if category_id:
			self._categories_path_by_id[to_str(category_id)] = category_path
		return category_path


	def is_center_inventory_sync(self):
		user_info = self.get_user_info()
		return user_info and user_info.get('app_type') == 'cis'


	def is_multi_store_sync(self):
		user_info = self.get_user_info()
		return user_info and user_info.get('app_type') == 'mss'


	def get_model_catalog(self):
		if self._model_catalog:
			return self._model_catalog
		self._model_catalog = Catalog()
		self._model_catalog.set_user_id(self._user_id)
		self._model_catalog.set_db(self.get_db())
		return self._model_catalog


	def get_model_deleted_product(self):
		if self._model_deleted_product:
			return self._model_deleted_product
		self._model_deleted_product = CollectionDeletedProduct()
		self._model_deleted_product.set_user_id(self._user_id)
		self._model_deleted_product.set_db(self.get_db())
		return self._model_deleted_product


	def get_model_category(self):
		if self._model_category:
			return self._model_category
		self._model_category = Category()
		self._model_category.set_user_id(self._user_id)
		self._model_category.set_db(self.get_db())
		return self._model_category


	def get_model_attributes(self):
		if self._model_attribute:
			return self._model_attribute
		self._model_attribute = Attributes()
		self._model_attribute.set_user_id(self._user_id)
		self._model_attribute.set_db(self.get_db())
		return self._model_attribute


	def get_model_template(self):
		if self._model_template:
			return self._model_template
		self._model_template = Template()
		self._model_template.set_user_id(self._user_id)
		self._model_template.set_db(self.get_db())
		return self._model_template


	def get_model_order(self):
		"""

		:rtype: CollectionOrder
		"""
		if self._model_order:
			return self._model_order
		self._model_order = CollectionOrder()
		self._model_order.set_user_id(self._user_id)
		self._model_order.set_db(self.get_db())
		return self._model_order


	def get_model_process(self):
		"""

		:rtype: CollectionOrder
		"""
		if self._model_process:
			return self._model_process
		self._model_process = CollectionProcess()
		self._model_process.set_user_id(self._user_id)
		self._model_process.set_db(self.get_db())
		return self._model_process


	def set_state_id(self, state_id):
		self._state_id = state_id
		self.get_model_state().set_document_id(state_id)


	def set_is_inventory_process(self, value):
		self._is_inventory_process = value


	def get_action_stop(self):
		return self._action_stop


	def set_action_stop(self, action_stop):
		self._action_stop = action_stop


	def get_state_id(self):
		return self._state_id


	def get_sync_id(self):
		return self._sync_id


	def get_db(self):
		if self._db:
			return self._db
		self._db = self.get_model_state().get_db()
		return self._db


	def set_db(self, db):
		if self._db:
			return
		self._db = db
		self.get_model_state().set_db(db)


	def set_sync_id(self, sync_id):
		self._sync_id = sync_id
		if self._state:
			self._state.sync_id = sync_id


	def set_product_id(self, product_id):
		self._product_id = product_id
		self.get_model_catalog().set_document_id(product_id)


	def set_name(self, name):
		self._name = name


	def set_channel_url(self, url):
		self._channel_url = url


	def set_channel_type(self, channel_type):
		self._type = channel_type


	def set_identifier(self, identifier):
		"""

		:type identifier: unique for each channel
		"""
		self._identifier = identifier
		self._state.channel.identifier = identifier


	def get_identifier(self):
		return self._identifier


	def set_id(self, _id):
		self._id = _id


	def set_user_id(self, user_id):
		self._user_id = user_id
		self._model_state.set_user_id(user_id)
		self.get_model_sync_mode().set_user_id(user_id)


	def set_date_requested(self, date_requested):
		self._date_requested = date_requested


	def set_is_update(self, _is_update):
		self._is_update = _is_update


	def get_model_state(self):
		return self._model_state


	def set_is_test(self, is_test = False):
		self._is_test = is_test


	def set_state(self, state):
		self._state = state
		self.get_model_sync_mode().set_state(state)


	def get_state(self):
		return self._state


	def get_state_by_id(self, state_id, sync_info = False):
		if state_id == 'litcommerce':
			state = SyncState()
			state.channel.id = self.get_channel_default_id()
			state.channel.channel_type = 'litcommerce'
			state.channel.default = True
			state.user_id = self._user_id
			return state
		state = self.get_model_state().get(state_id)
		if state:
			state = SyncState(**state)
			if not sync_info and state.sync_id:
				sync_info = self.get_sync_info(state.sync_id)

			if sync_info and sync_info.get('config') and json_decode(sync_info['config']):
				state.channel.config.api = json_decode(sync_info['config'])
				return state
			channel = self.get_channel_by_id(state.channel.id)
			if channel:
				if json_decode(channel.api):
					state.channel.config.api = json_decode(channel.api)
				if json_decode(channel.settings):
					state.channel.config.setting = json_decode(channel.settings)
				if channel.identifier:
					state.channel.identifier = channel.identifier
				if channel.url:
					state.channel.url = channel.url
			return state
		return False


	def save_state(self, unset = None):
		new_state = copy.deepcopy(self._state)
		default_unset = ['sync', 'mode', 'version', 'user_id', 'server_id', 'sync_id']
		if unset:
			if not isinstance(unset, list):
				unset = [unset]
			default_unset.extend(unset)
			for row in default_unset:
				if row in new_state:
					del new_state[row]
		self.get_model_state().set_data(new_state)
		return self.get_model_state().save()


	def save_pull_process(self, data = None):
		if self.is_product_process() and data and isinstance(data, dict) and data.get('condition'):
			return Response().success()
		return self.get_model_state().update(self._state_id, {
			"pull": self._state.pull,
			"pulling": self._state.pulling
		})


	def save_push_process(self, data = None):
		if self.is_product_process() and data and isinstance(data, dict) and data.get('condition'):
			return Response().success()
		return self.get_model_state().update_field(self._state_id, "push", self._state.push)


	def save_sync(self, **kwargs):
		# process = self.get_process_by_id(self._sync_id)
		# state_id = self.get_state_id() or process['state_id']
		# self.get_model_state().update_field(state_id,'process', kwargs)
		# return self.get_model_sync_mode().save_sync(self._sync_id, **kwargs)
		return True


	def init_state(self):
		if self._sync_id:
			info = False
			if not self._state and not self._state_id:
				info = self.get_sync_info()
				if info:
					self.set_process_type(info.type)
					self.set_channel_id(info.channel_id)
					self.set_limit_process(info.limit)
				if info and info.state_id:
					if not self._user_id:
						self.set_user_id(info.user_id)
					self.set_state_id(info.state_id)
			if self._state_id:
				state = self.get_state_by_id(self._state_id, info)
				if state:
					self._state = state
					self.set_state_id(self._state_id)

		if not self._state:
			self._state = SyncState()
		return self._state


	def list_to_dict(self, list_data):
		if isinstance(list_data, dict):
			return list_data
		dict_data = dict()
		if not isinstance(list_data, list) or not list_data:
			return dict_data
		for index, value in enumerate(list_data):
			dict_data[str(index)] = value
		return dict_data


	def set_migration_id(self, migration_id):
		self._sync_id = migration_id


	def validate_data_setup(self, data):
		return Response().success()


	def get_channel(self, channel_type, channel_version):
		channel_file = None
		channel_class = None
		if not channel_type:
			return channel_file, channel_class
		if channel_type in self.all_cart():
			channel_file = 'channels.cart'
		elif channel_type == 'woocommerce':
			channel_file = 'channels.woo'
		else:
			channel_file = 'channels.{}'.format(channel_type)
		if channel_type == 'file':
			if self._is_inventory_process:
				channel_file = 'channels.files.inventory'
				channel_class = 'ModelChannelsInventoryFile'
			else:
				if self._state and self._state.channel.config.api.feed_type == 'update':
					channel_class = 'ModelChannelsProductFileUpdate'
					channel_file = 'channels.files.file_update'

				else:
					channel_class = 'ModelChannelsProductFile'
		if channel_type == 'bulk_edit':
			channel_file = 'channels.files.bulk_edit'
			channel_class = 'ProductBulkEdit'
		if channel_type == 'etsy':
			channel_file = 'channels.etsyv3'
			channel_class = 'ModelChannelsEtsyV3'
		if channel_type == 'tiktok':
			channel_file = 'channels.tiktokv2'
			channel_class = 'ModelChannelsTiktokV2'
		return channel_file, channel_class


	def all_cart(self):
		return ('3dcart',)


	def get_all_channels(self):
		if self._all_channel:
			return self._all_channel
		if self._request_data and self._request_data.get('channels'):
			for channel_id, channel in self._request_data['channels'].items():
				self._all_channel[to_int(channel_id)] = Prodict.from_dict(channel)
			return self._all_channel
		all_channels = self.get_model_sync_mode().get_all_channels()
		for channel in all_channels:
			self._all_channel[channel.id] = channel
		return self._all_channel


	def format_url(self, url, **kwargs):
		if not url:
			return ""
		if self.CONNECTOR_SUFFIX in url:
			url = url.replace(self.CONNECTOR_SUFFIX, '')
		filter_url = ['index.php', '?']
		for char in filter_url:
			find_char = url.find(char)
			if find_char >= 0:
				url = url[:find_char]
		url = url.rstrip('/')
		return url


	def channel_setup_type(self, channel_type):
		setup_type = {
			# api
			'shopify': 'api',
			'amazone': 'api',
			'ebay': 'api',

			'bigcommerce': 'cart',
			'magento': 'cart',
		}
		return setup_type[channel_type] if channel_type in setup_type else 'api'


	def get_msg_error(self, error_code):
		return self._error.get_msg_error(error_code)


	def get_url_suffix(self, suffix):
		url = self._channel_url.rstrip('/') + '/' + to_str(suffix).lstrip('/')
		return url


	def validate_channel_url(self):
		return Response().success()


	def channel_is_local_host(self):
		url = self._channel_url
		if not python_validators.url(url):
			return Response().error(Errors.URL_INVALID)
		localhost = ['localhost', 'localhost.com', '127.0.0.1', '192.168.100.222', '192.168.100.222:8888']
		import urllib.parse
		scheme, netloc, path, qs, anchor = urllib.parse.urlsplit(url)
		netloc = to_str(netloc).split(':')[0]
		if netloc in localhost or to_str(netloc).startswith('192.168'):
			return Response().error(Errors.URL_IS_LOCALHOST)
		return Response().success()


	def validate_setup_data(self, data):
		if not data.get('channel_name'):
			return Response().error(code = Errors.CHANNEL_NAME_REQUIRED)
		validate_channel_url = self.validate_channel_url()
		if validate_channel_url.result != Response.SUCCESS:
			return validate_channel_url
		return Response().success()


	def prepare_display_setup_channel(self, data = None):
		channel_type = self._state.channel.channel_type
		setup_type = self.channel_setup_type(channel_type)
		self._state.channel.setup_type = setup_type
		validate_setup_data = self.validate_setup_data(data)
		if validate_setup_data.result != Response().SUCCESS:
			code = Errors.SETUP_DATA_INVALID
			if validate_setup_data.code:
				code = validate_setup_data.code
			response = Response().error(code = code)
			return response
		if setup_type == 'connector':
			pass
		return Response().success()


	def display_setup_channel(self, data = None):
		configs = ('api', 'database')
		for config in configs:
			value = data.get(config, dict())
			if not value:
				value = dict()
			if value and isinstance(value, dict):
				value = Prodict(**value)
			if value:
				self._state.channel.config.set_attribute(config, value)
			method = 'validate_{}_info'.format(config)
			if hasattr(self, method):
				validate = getattr(self, method)()
				if validate.result != Response().SUCCESS:
					return validate

		return Response().success()


	def update_custom_data(self, custom_data):
		self._custom_data = custom_data
		return Response().success()


	def set_channel_identifier(self):
		return Response().success()


	def get_api_info(self):
		return {}


	def validate_api_info(self):
		api_info = self.get_api_info()
		if api_info:
			for api_key, api_label in api_info.items():
				if not self._state.channel.config.api.get(api_key):
					return Response().error(msg = Messages.API_FIELD_REQUIRED.format(api_label))
		return Response().success()


	def validate_database_info(self):
		return Response().success()


	def get_model_sync_mode(self):
		if self._model_sync_mode:
			self._model_sync_mode.set_state(self._state)
			return self._model_sync_mode
		server_mode = get_config_ini('local', 'mode')
		if not server_mode or self._is_test or (self._state and self._state.config.test):
			server_mode = 'test'

		model_name = 'modes.{}'.format(server_mode)
		model = get_model(model_name)
		if model:
			self._model_sync_mode = model
			self._model_sync_mode.set_state(self._state)
			self._model_sync_mode.set_sync_id(self._sync_id)
			self._model_sync_mode.set_user_id(self._user_id)
		return self._model_sync_mode


	def update_channel(self, **kwargs):
		return self.get_model_sync_mode().update_channel(self.get_channel_id(), **kwargs)


	def create_channel(self):
		channel_id = None
		sync_id = None
		state_id = None
		if self._sync_id:
			sync_id = self._sync_id
			sync_info = self.get_sync_info(sync_id)
			channel_id = sync_info.channel_id
			state_id = sync_info.state_id
		channel_id_exist = None
		if not channel_id:
			check = self.get_model_sync_mode().is_channel_exist(self._type, self._identifier)
			if check is True:
				return Response().error(code = Errors.CHANNEL_EXIST)
			if check:
				channel_id_exist = check['id']
			channel = self.get_model_sync_mode().create_channel(channel_id_exist)
			if channel.result != Response().SUCCESS:
				channel.code = Errors.CHANNEL_NOT_CREATE
				return channel
			channel_id = channel.data['id']
			self._state.channel.position = channel.data['position']
			if channel.data.get('default') == 1:
				self._state.channel.default = True
		self._state.channel.id = channel_id
		if not state_id:
			self._state.channel.created_at = get_current_time()
			state_id = self._model_state.create(self._state)
		if not state_id:
			return Response().error(code = Errors.STATE_NOT_CREATE)
		if not sync_id:
			process_data = {
				'state_id': state_id,
				'channel_id_exist': channel_id_exist
			}
			if self.is_file_channel():
				process_data['config'] = json_encode(self._state.channel.config.api)
				process_data['feed_type'] = 'add'
			sync = self.get_model_sync_mode().create_product_sync_process(**process_data)
			if sync.result != Response().SUCCESS:
				self.delete_channel(channel_id)
				sync.code = Errors.PROCESS_NOT_CREATE
				return sync
			sync_id = sync.data
		else:
			self.get_model_sync_mode().set_state_id_for_sync(sync_id, state_id)
		inventories = self.get_model_sync_mode().get_warehouse_locations()
		location_ids = duplicate_field_value_from_list(inventories, 'id')
		self._state.sync_id = sync_id
		self._state.channel.config.setting.inventory = {'active': location_ids, 'disable': []}
		try:
			self.init_index(channel_id)
			self._state.sync_index = True
			self._state.updated_time_index = True
		except Exception:
			pass
		data = {
			'channel_id': channel_id,
			'process_id': sync_id,
			'state_id': state_id
		}
		# if self._state.channel.default and self.is_shopping_cart():
		# 	self.create_refresh_process_scheduler()
		return Response().success(data)


	def extend_callback_data(self):
		return {}


	def create_callback_data(self, data):
		extend_data = self.extend_callback_data()
		if extend_data:
			data.update(extend_data)
		return self.get_model_sync_mode().create_callback_data(data)


	def is_shopping_cart(self):
		return self.get_channel_type() in ['woocommerce', 'shopify', 'wix', 'bigcommerce', 'magento', 'squarespaces', 'square']


	def create_sync_index(self):
		try:
			self.get_model_catalog().create_index(f"channel.channel_{self.get_channel_id()}.sync_error")
		except Exception:
			pass


	def create_attribute_index(self):
		if not self._state.attributes_index:
			try:
				self.get_model_attributes().create_compound_index(['channel_id', 'name'], unique = True)

			except Exception:
				pass
			self._state.attributes_index = True
			self.get_model_state().update_field(self.get_state_id(), 'attributes_index', True)


	def create_updated_time_index(self):
		try:
			self.get_model_catalog().create_index(f"updated_time")
		except Exception:
			pass


	def init_index(self, channel_id):
		field_channel_index = ['status']
		if self.INIT_INDEX_FIELDS:
			field_channel_index.extend(self.INIT_INDEX_FIELDS)
		field_index = ['parent_id']
		for row in field_channel_index:
			field_index.append(f"channel.channel_{channel_id}.{row}")
		# for field in field_index:
		# 	self.get_model_catalog().create_index(f"channel.channel_{channel_id}.{field}")
		# self.get_model_catalog().create_compound_index(field_index)
		field_index.append('name')
		self.get_model_catalog().create_compound_index(field_index)
		self.get_model_catalog().create_compound_index([f"channel.channel_{channel_id}.status", 'is_variant', 'parent_id'])
		# self.get_model_catalog().create_compound_index([f"channel.channel_{channel_id}.status", 'name', 'parent_id'])
		self.get_model_catalog().create_index(f"channel.channel_{channel_id}.product_id")
		self.get_model_catalog().create_index(f"channel.channel_{channel_id}.sync_error")
		if self.get_channel_type() == 'etsy':
			self.get_model_catalog().create_index(f'channel.channel_{channel_id}.template_data.category.advance.section')
		if self.is_channel_default():
			self.get_model_catalog().create_compound_index([f"channel.channel_{channel_id}.status", 'parent_id', 'is_in_stock'], fields_desc = [f'channel.channel_{channel_id}.product_id'])
			self.get_model_catalog().create_compound_index([f"channel.channel_{channel_id}.status", 'parent_id', 'is_in_stock'])
			self.get_model_catalog().create_index('position')
			self.get_model_catalog().create_index('invisible')
			self.get_model_catalog().create_index('updated_time')
			self.get_model_catalog().create_index('name')
			self.get_model_catalog().create_index('sku')
			self.get_model_order().create_index('channel_id')
			self.get_model_template().create_index('channel_id')
			self.get_model_state().create_index('channel_id')
			self.get_model_deleted_product().create_index('channel_id')
			self.get_model_deleted_product().create_index('product_id')
			self.get_model_order().create_index("status")
		else:
			self.get_model_order().create_index(f"channel.channel_{channel_id}.order_id", unique = True, sparse = True)


	# self.get_model_attributes().create_compound_index(['channel_id', 'name'], unique = True)
	# field_index = ['is_variant', 'name', 'sku', 'is_in_stock', 'parent_id']
	# for field in field_index:
	# 	self.get_model_catalog().create_index(field)

	def init_catalog_text_index(self, channel_id):
		index_key = 'catalog_text_index'
		channel_field = [f'channel.channel_{channel_id}.sku', f'channel.channel_{channel_id}.name']
		default_field = ['name', 'sku']
		if self.is_channel_default():
			self.get_model_catalog().create_text_index(['name', 'sku'], index_key)
		else:
			text_index = self.get_model_catalog().get_index(index_key)
			fields = default_field + channel_field

			if text_index:
				fields += list(dict(text_index['weights']).keys())
			fields = list(set(fields))
			self.get_model_catalog().drop_index(index_key)
			self.get_model_catalog().create_text_index(fields, index_key)


	# def init_catalog_text_index(self, channel_id):
	# 	index_key = 'catalog_text_index'
	# 	channel_field = [f'channel.channel_{channel_id}.sku', f'channel.channel_{channel_id}.name']
	# 	default_field = ['name', 'sku']
	# 	if self.is_channel_default():
	# 		self.get_model_catalog().create_text_index(['name', 'sku'], index_key)
	# 	else:
	# 		text_index = self.get_model_catalog().get_index(index_key)
	# 		fields = default_field + channel_field
	#
	# 		if text_index:
	# 			fields += list(dict(text_index['weights']).keys())
	# 		fields = list(set(fields))
	# 		self.get_model_catalog().drop_index(index_key)
	# 		self.get_model_catalog().create_text_index(fields, index_key)

	def delete_channel(self, channel_id):
		return self.get_model_sync_mode().delete_channel(channel_id)


	def get_channel_default(self):
		if self._request_data.get('channels'):
			for channel_id, channel_data in self._request_data['channels'].items():
				if channel_data['default']:
					return Prodict.from_dict(channel_data)
		return self.get_model_sync_mode().get_channel_default()


	def get_channel_default_id(self):
		if self._channel_default_id:
			return self._channel_default_id
		channel_default = self.get_channel_default()
		self._channel_default_id = channel_default['id']
		return self._channel_default_id


	def delete_sync_process(self, sync_id):
		return self.get_model_sync_mode().delete_sync_process(sync_id)


	def after_create_channel(self, data):
		return Response().success()


	def combine_request_options(self, custom_options = None):
		options = {
			'verify': False,
			'allow_redirects': True,
			'timeout': 30
		}
		if not custom_options:
			return options
		for option_key, option_value in custom_options.items():
			options[option_key] = option_value
		return options


	def no_clear(self):
		return Response().success()


	def log(self, msg, log_type = 'exceptions'):
		prefix = "user/" + to_str(self._user_id)
		if self._channel_id:
			prefix = os.path.join('channel', to_str(self._channel_id))
			if self._process_type:
				prefix += '/' + self._process_type
		elif self._sync_id:
			prefix = os.path.join('processes', to_str(self._sync_id))
		elif self._product_id:
			prefix = os.path.join(prefix, 'product', to_str(self._product_id))

		log(msg, prefix, log_type)


	def log_request_error(self, url, log_type = 'request', **kwargs):
		msg_log = 'Url: ' + to_str(url)
		for log_key, log_value in kwargs.items():
			msg_log += '\n{}: {}'.format(to_str(log_key).capitalize(), to_str(log_value))
		self.log(msg_log, log_type)


	def log_traceback(self, type_error = 'exceptions', msg = ''):
		error = traceback.format_exc()
		if msg:
			error += "\n" + to_str(msg)
		self.log(error, type_error)


	def notify(self, code, data = None):
		pass


	def get_entity_limit(self):
		return {
			'products': self._limit_process,
			'orders': self._limit_process,
		}


	def get_sync_info(self, sync_id = None):
		if not sync_id:
			sync_id = self._sync_id
		if self._request_data.get('processes') and self._request_data['processes'].get(to_str(sync_id)):
			return Prodict.from_dict(self._request_data['processes'].get(to_str(sync_id)))
		return self.get_model_sync_mode().get_sync_info(sync_id)


	# Todo: display pull
	def prepare_display_pull(self, data = None):
		self._state.pull.process.products.auto_build = True
		self._state.pull.process.products.auto_import_category = False
		if isinstance(data, dict):
			if data.get('include_deleted'):
				self._state.pull.process.products = EntityProcess()
			# self.get_model_deleted_product().delete_many_document(self.get_model_deleted_product().create_where_condition('channel_id', self.get_channel_id()))
			if 'auto_build' in data:
				self._state.pull.process.products.auto_build = to_bool(data.get('auto_build'))
			self._state.pull.process.products.auto_import_category = to_bool(data.get('auto_import_category'))
			self._state.pull.process.products.include_inactive = to_bool(data.get('include_inactive'))
		entities = ('taxes', 'categories', 'products', 'orders')
		if get_config_ini('local', 'mode') != 'live':
			limits = dict()
			for entity in entities:
				limits[entity] = get_config_ini('limit', entity, '-1', file = 'local.ini')
				self._state.config[entity] = to_bool(get_config_ini('config', entity, False, file = 'local.ini'))
		else:
			limits = self.get_entity_limit()
			if self.is_order_process():
				self._state.config.orders = self._state.channel.support.orders
				self._state.config.taxes = False
				self._state.config.categories = False
				self._state.config.products = False
			elif self.is_category_process():
				self._state.config.orders = False
				self._state.config.taxes = False
				self._state.config.categories = True
				self._state.config.products = False
			else:
				self._state.config.orders = False
				self._state.config.taxes = False
				self._state.config.categories = False
				self._state.config.products = True
		for entity in entities:
			if limits.get(entity):
				self._state.pull.process[entity].limit = limits[entity]
		return Response().success()


	def before_display_pull(self, data = None):
		return Response().success()

	def is_auto_build(self):
		return self._state.pull.process.products.auto_build


	def is_auto_import_category(self):
		# return self._state.pull.process.products.auto_build
		return True


	def display_pull_channel(self):
		return Response().success()


	def display_pull_warehouse(self):
		return Response().success()


	def display_pull(self):
		return Response().success()


	# Todo: Prepare pull
	def prepare_pull_channel(self, data = None):
		return Response().success()


	def prepare_pull(self):
		return Response().success()


	# TODO taxes
	def prepare_taxes_import(self):
		return self


	def prepare_taxes_export(self):
		return self


	def get_taxes_main_export(self):
		return Response().success()


	def get_taxes_ext_export(self, taxes):
		return Response().success()


	def convert_tax_export(self, tax, taxes_ext):
		return Response().success()


	def get_tax_id_import(self, convert, tax, taxes_ext):
		return convert['id']


	def check_tax_import(self, tax_id, convert: Product):
		return False


	def before_tax_import(self, convert, tax, taxes_ext):
		return Response().success()


	def tax_import(self, convert, tax, taxes_ext):
		return response_success(0)


	def tax_channel_import(self, convert, tax, taxes_ext):
		return self.tax_import(convert, tax, taxes_ext)


	def after_tax_import(self, tax_id, convert, tax, taxes_ext):
		return Response().success()


	def after_tax_pull(self, tax_id, convert, tax, taxes_ext):
		return Response().success()


	def addition_tax_import(self, convert, tax, taxes_ext):
		return Response().success()


	def finish_tax_import(self):
		return Response().success()


	# TODO: categories
	def prepare_categories_import(self):
		return self


	def prepare_categories_export(self):
		return self


	def get_categories_main_export(self):
		return Response().success()


	def get_categories_ext_export(self, categories):
		return Response().success()


	def convert_category_export(self, category, categories_ext):
		return Response().success()


	def add_channel_to_convert_tax_data(self, tax, category_channel_id):
		# channel = Tax()
		# channel.category_id = category_channel_id
		# channel.channel_id = self._state.channel.id
		# category.channel.set_attribute("channel_{}".format(self._state.channel.id), channel.to_dict())
		return tax


	def add_channel_to_convert_category_data(self, category: CatalogCategory, category_channel_id):
		channel = CategoryChannel()
		channel.category_id = to_str(category_channel_id)
		channel.channel_id = self._state.channel.id
		if not category.channel:
			category.channel = dict()
		category['channel'][f'channel_{self.get_channel_id()}'] = channel
		return category


	def get_category_total_import(self):
		return 0


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return False


	def check_category_import(self, category_id, convert: CatalogCategory):
		return False


	def before_category_import(self, convert: Product, category, categories_ext):
		return Response().success()


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		return Response().success()


	def category_channel_import(self, convert: CatalogCategory, category, categories_ext):
		return self.category_import(convert, category, categories_ext)


	def edit_category_channel(self, category: Product, data):
		return Response().success()


	def update_category(self, data):
		channel_id = self._state.channel.id
		update_data = dict()
		for data_key, data_value in data.items():
			update_data['channel.channel_{}.{}'.format(channel_id, data_key)] = data_value
		return Response().success(update_data)


	def get_category_channel_data(self, category, category_channel_id):
		category_channel = CategoryChannel()
		category_channel.channel_id = self._state.channel.id
		category_channel.category_id = category_channel_id
		category_channel.category_code = category.code
		return category_channel


	def insert_map_category(self, category, category_id, category_channel_id):
		map_field = "channel_{}".format(self._state.channel.id)
		category_channel_data = self.get_category_channel_data(category, category_channel_id)
		category.channel.set_attribute(map_field, category_channel_data)
		update_field = "channel.{}".format(map_field)
		self.get_model_catalog().update_field(category_id, update_field, category_channel_data)
		return Response().success()


	def after_category_import(self, category_id, convert: CatalogCategory, category, categories_ext):
		return Response().success()


	def after_category_pull(self, category_id, convert: CatalogCategory, category, categories_ext):
		return Response().success()


	def addition_category_import(self):
		return Response().success()


	def finish_category_import(self):
		return Response().success()


	def filter_field_category(self, data):
		filter_data = dict()
		fields = Catalog.FILTER
		for data_key, data_value in data.items():
			if data_key in fields:
				filter_data[data_key] = data_value
		if filter_data.get('price') and self._state.channel.config.price_sync.status == StateChannelConfigPriceSync.DISABLE:
			del filter_data['price']
		if filter_data.get('qty') and self._state.channel.config.qty_sync.status == StateChannelConfigQtySync.DISABLE:
			del filter_data['qty']
		return filter_data


	# TODO products
	def prepare_products_import(self, data = None):
		return self


	def prepare_products_export(self):
		return self


	def get_product_main_export(self, product_id, main_product = None):
		product_channel_id = product_id
		product = main_product or self.get_model_catalog().get(product_id, ['channel'])
		field_check = 'channel_{}'.format(self._state.channel.id)
		if not product or not product['channel'].get(field_check):
			return Response().finish()
		product_channel_id = product['channel'][field_check].get('product_id')

		product_channel = self.get_product_by_id(product_channel_id)
		# if product_channel.result != Response.SUCCESS:
		# 	return product_channel
		return product_channel


	def get_product_by_id(self, product_id):
		return Response().success()


	def get_products_main_export(self):
		return Response().success()


	def get_product_by_updated_at(self):
		return Response().success()


	def get_products_ext_export(self, products):
		return Response().success()


	def convert_product_export(self, product, products_ext):
		# if self.is_refresh_process():
		# 	self.set_product_max_last_modified(product)
		return self._convert_product_export(product, products_ext)


	def _convert_product_export(self, product, products_ext):
		return Response().success()


	def get_product_updated_at(self, product):
		return product.updated_at


	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(updated_at, time_format)


	def set_product_max_last_modified(self, product):
		updated_at = self.get_product_updated_at(product)
		if not self._product_max_last_modified:
			self._product_max_last_modified = updated_at
			return
		old_timestamp = self.updated_at_to_timestamp(self._product_max_last_modified)
		new_timestamp = self.updated_at_to_timestamp(updated_at)
		if new_timestamp > old_timestamp:
			self._product_max_last_modified = updated_at


	def extend_convert_product_data(self, product):
		return {}


	def add_channel_to_convert_product_data(self, product, product_channel_id):
		channel = ProductChannel()
		channel.product_id = to_str(product_channel_id)
		unescape = ['name', 'sku', 'description', 'short_description', 'meta_title', 'meta_keyword']
		for row in unescape:
			product[row] = html_unescape(product.get(row)).strip(' ')
		channel.sku = product.sku
		channel.name = product.name
		channel.channel_id = self._state.channel.id
		channel.qty = to_int(product.qty)
		channel.price = product.price
		extend_channel_data = self.extend_convert_product_data(product)
		if extend_channel_data:
			channel.update(extend_channel_data)
		if self.is_channel_default():
			channel.link_status = ProductChannel.LINKED
		else:
			if self.is_center_inventory_sync() and self.is_auto_build():
				channel_default = ProductChannel()
				channel_default.channel_id = self.get_channel_default_id()
				channel_default.product_id = product.get('id')
				channel_default.link_status = ProductChannel.LINKED
				product.channel.set_attribute("channel_{}".format(self.get_channel_default_id()), channel_default.to_dict())
				channel.link_status = ProductChannel.LINKED

		if product.template_data:
			channel.template_data = copy.deepcopy(product.template_data)
			del product['template_data']
		if product.channel_data:
			channel.update(product.channel_data)
		# del product['channel_data']
		# product.channel.append(channel)
		product.channel.set_attribute("channel_{}".format(self._state.channel.id), channel.to_dict())
		product.src.channel_type = self._state.channel.channel_type
		product.src.channel_id = to_int(self._state.channel.id)
		if product.variants:
			for variant in product.variants:
				variant_channel = ProductChannel()
				for row in unescape:
					variant[row] = html_unescape(variant.get(row))
				variant_channel.qty = variant.qty
				variant_channel.price = variant.price
				variant_channel.name = variant.name
				variant_channel.sku = variant.sku
				variant_channel.product_id = to_str(variant.id)
				variant_channel.code = variant.code
				extend_variant_channel_data = self.extend_convert_product_data(variant)
				if extend_variant_channel_data:
					variant_channel.update(extend_variant_channel_data)
				if variant.template_data:
					variant_channel.template_data = copy.deepcopy(variant.template_data)
					del variant['template_data']
				if variant.channel_data:
					variant_channel.update(variant.channel_data)
					del variant['channel_data']
				if self.is_channel_default():
					variant_channel.link_status = ProductChannel.LINKED
				else:
					if self.is_center_inventory_sync() and self.is_auto_build():
						variant_channel_default = ProductChannel()
						variant_channel_default.channel_id = self.get_channel_default_id()
						variant_channel_default.product_id = variant.get('id')
						variant_channel_default.link_status = ProductChannel.LINKED
						variant.channel.set_attribute("channel_{}".format(self.get_channel_default_id()), variant_channel_default.to_dict())
						variant_channel.link_status = ProductChannel.LINKED
				variant.channel.set_attribute("channel_{}".format(self._state.channel.id), variant_channel.to_dict())

		return product


	def get_product_id_import(self, convert: Product, product, products_ext):
		return convert['id']


	def check_tax_available_import(self, notify = False):
		return True


	def check_category_available_import(self, notify = False):
		return True


	# TODO: product
	def get_product_total_import(self):
		all_channel = self.get_all_channels()
		channel_filter = list()
		for channel_id, channel in all_channel.items():
			if channel.get('default') or channel.get('type') in ['file', 'bulk_edit']:
				continue
			channel_filter.append(channel)
		total = 0
		for channel in channel_filter:
			where = self.get_model_catalog().create_where_condition("is_variant", False)
			where.update(self.get_model_catalog().create_where_condition(f"channel.channel_{channel['id']}.status", '', '>'))
			total += self.get_model_catalog().count(where)
		return total


	def check_product_available_import(self, notify = False, push = False):
		if self._product_available_import is False:
			return False
		if get_config_ini('local', 'mode') != 'live' or self.is_staff_user():
			return True
		if not self.check_product_rate_limit(push):
			user_plan = self.get_user_plan()
			if not user_plan or to_int(user_plan['monthly_fee']) == 0:
				# email
				self.count_number_products()

				self._product_available_import = False
				self.notify_limit_product(notify)
				return False
			upgrade = self.try_upgrade_plan()
			if not upgrade or to_int(upgrade['code']) != 200:
				self._product_available_import = False
				self.notify_limit_product(notify)
				self.count_number_products()

				return False
			self._user_plan = upgrade['data']
		return True


	def try_upgrade_plan(self):
		return self.get_model_sync_mode().try_upgrade_plan()


	def check_product_rate_limit(self, push = False):
		if get_config_ini('local', 'mode') != 'live':
			return True
		user_plan = self.get_user_plan()
		if not user_plan:
			return False
		if to_int(user_plan['products_limit']) == 0:
			return True
		products_limit = to_int(user_plan['products_limit']) if not user_plan.get('expired') else 20
		if not self._total_product or self._total_product_batch_import >= 25:
			# 	self._total_product += 1
			# 	self._total_product_batch_import += 1
			# else:
			total_import = self.get_product_total_import()
			self._total_product = total_import
			self._total_product_batch_import = 0
		return to_int(self._total_product) < products_limit


	def notify_limit_product(self, notify = False):
		if not notify:
			return
		notification_data = {
			'code': '',
			'content': Messages.PRODUCT_RATE_LIMIT_TITLE,
			'activity_type': 'product_rate_limit',
			'description': Messages.PRODUCT_RATE_LIMIT_DESCRIPTION,
			'date_requested': self._date_requested,
			'result': Activity.FAILURE
		}
		notification = self.create_activity_notification(**notification_data)


	def notify_limit_order(self, notify = False):
		if not notify:
			return
		notification_data = {
			'code': '',
			'content': Messages.ORDER_RATE_LIMIT_TITLE,
			'activity_type': 'order_rate_limit',
			'description': Messages.PRODUCT_RATE_LIMIT_DESCRIPTION,
			'date_requested': self._date_requested,
			'result': Activity.FAILURE
		}
		notification = self.create_activity_notification(**notification_data)


	def check_product_import(self, product_id, convert: Product):
		if self._state.channel.default:
			field_check = 'channel_{}'.format(self.get_src_channel_id())
			if not convert['channel'].get(field_check) or convert['channel'][field_check].get('link_status') != ProductChannel.LINKED:
				return False
		field_check = 'channel_{}'.format(self.get_channel_id())
		if not convert['channel'].get(field_check) or convert['channel'][field_check].get('status') != ProductChannel.ACTIVE:
			return False

		return convert['channel'][field_check].get('product_id')


	def before_product_import(self, convert: Product, product, products_ext):
		return Response().success()


	def product_import(self, convert: Product, product, products_ext):
		return Response().success()


	def product_channel_import(self, convert: Product, product, products_ext):
		# if self.is_channel_default():
		# 	if not self.check_product_available_import(push = True):
		# 		return Response().stop(code = Errors.PRODUCT_RATE_LIMIT)
		return self.product_import(convert, product, products_ext)


	def product_update(self, product_id, convert: Product, product, products_ext):
		return self.product_channel_update(product_id, convert, products_ext)


	def product_channel_update(self, product_id, product: Product, products_ext):
		return Response().success()


	def edit_product_channel(self, product: Product, data):
		return Response().success()


	def update_product(self, data):
		channel_id = self._state.channel.id
		update_data = dict()
		for data_key, data_value in data.items():
			update_data['channel.channel_{}.{}'.format(channel_id, data_key)] = data_value
		return Response().success(update_data)


	def get_product_channel_data(self, product: Product, product_channel_id, channel_id = None):
		if not channel_id:
			channel_id = self._state.channel.id
		map_field = f"channel_{channel_id}"
		if product.channel.get(map_field):
			product_channel = product.channel.get(map_field)
		else:
			product_channel = ProductChannel()
		if not product_channel.channel_id:
			product_channel.channel_id = channel_id
		if product_channel_id and not product_channel.product_id:
			product_channel.product_id = to_str(product_channel_id)
		product_channel.sku = product.sku
		product_channel.name = product.name
		return product_channel


	def extend_data_insert_map_product(self):
		if not self._extend_product_map:
			return {}
		extend = copy.deepcopy(self._extend_product_map)
		self._extend_product_map = {}
		return extend


	def insert_map_product(self, product, product_id, product_channel_id, **kwargs):
		map_field = "channel_{}".format(self.get_channel_id())
		extend_data = self.extend_data_insert_map_product()
		if kwargs:
			extend_data.update(kwargs)
		if self.is_channel_default() and product.channel.get(map_field) and product.channel.get(map_field).status == ProductChannel.ACTIVE and product.channel.get(map_field).product_id:
			product_clone = copy.deepcopy(product)
			product_clone.channel[map_field]['product_id'] = to_str(product_channel_id)
			product_clone.channel[f"channel_{self.get_src_channel_id()}"]['link_status'] = ProductChannel.LINKED
			if extend_data:
				product_clone.channel[map_field].update(extend_data)
			del product_clone['_id']
			if product.is_variant:
				product_clone.clone_parent_id = product_clone.parent_id
				product_clone.hidden = True
			product_clone_id = self.get_model_catalog().create(product_clone)
			self.get_model_catalog().update(product_id, {f'channel.channel_{self.get_src_channel_id()}': {}})
			if not product.is_variant and product.variants:
				where_update = self.get_model_catalog().create_where_condition('clone_parent_id', product['_id'])
				self.get_model_catalog().update_many(where_update, {'parent_id': product_clone_id, 'hidden': False})
			return Response().success()
		product_channel_data = self.get_product_channel_data(product, product_channel_id)
		if product_channel_id:
			product_channel_data.status = ProductChannel.ACTIVE
			product_channel_data.link_status = ProductChannel.LINKED
		else:
			product_channel_data.publish_status = ProductChannel.PUSHING
			product_channel_data.status = ProductChannel.DRAFT
		product.channel.set_attribute(map_field, product_channel_data)
		if extend_data:
			product_channel_data.update(extend_data)
		update_field = "channel.{}".format(map_field)
		update_data = {
			update_field: product_channel_data
		}
		if not self.is_channel_default() and not product.is_variant:
			update_data['updated_time'] = time.time()
		if self.is_channel_default() and self.get_src_channel_id() != self.get_channel_id():
			update_data[f"channel.channel_{self.get_src_channel_id()}.link_status"] = ProductChannel.LINKED
			if extend_data.get('sku') and not product.sku:
				update_data[f"channel.channel_{self.get_src_channel_id()}.sku"] = self.FIELD_EMPTY

		self.get_model_catalog().update(product_id, update_data)
		return Response().success()


	def update_map_product(self, product, product_id, product_channel_id):
		self.get_model_catalog().update_field(product_id, f"channel.channel_{self.get_channel_id()}.product_id", to_str(product_channel_id))


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		return Response().success()


	def delete_product_import(self, product_id):
		return Response().success()


	def after_product_pull(self, product_id, convert: Product, product, products_ext):
		return Response().success()


	def addition_product_import(self):
		return Response().success()


	def finish_product_import(self):
		return Response().success()


	def finish_product_export(self):
		self._state.pull.process.products.finished = True
		if self.is_refresh_process() and self._product_max_last_modified:
			self._state.pull.process.products.last_modified = self._product_max_last_modified


	def after_product_update(self, product_id, product: Product):
		return Response().success()


	def filter_field_product(self, data):
		filter_data = dict()
		fields = Catalog.FILTER
		for data_key, data_value in data.items():
			if data_key in fields:
				filter_data[data_key] = data_value
		if filter_data.get('price') and self._state.channel.config.price_sync.status == StateChannelConfigPriceSync.DISABLE:
			del filter_data['price']
		if filter_data.get('qty') and self._state.channel.config.qty_sync.status == StateChannelConfigQtySync.DISABLE:
			del filter_data['qty']
		return filter_data


	# TODO: orders
	def get_order_total_import(self):
		if get_config_ini('local', 'mode') != 'live':
			return 0
		user_plan = self.get_user_plan()
		current_time = datetime.now()
		started_at = datetime.strptime(user_plan['started_at'], get_default_format_date())
		difference_month = diff_month(current_time, started_at)
		if difference_month > 0:
			started_at += relativedelta.relativedelta(months = difference_month)
			if started_at.day > current_time.day:
				started_at -= relativedelta.relativedelta(months = 1)

		where = self.get_model_catalog().create_where_condition("imported_at", started_at.strftime(get_default_format_date()), ">=")
		return self.get_model_catalog().count(where)


	def prepare_orders_import(self):
		return self


	def prepare_orders_export(self):
		return self


	def get_order_main_export(self, order_id):
		order = self.get_model_order().get(order_id, ['channel'])
		field_check = 'channel_{}'.format(self.get_channel_id())
		if not order or not order['channel'].get(field_check):
			return Response().finish()
		order_channel_id = order['channel'][field_check].get('order_id')

		order_channel = self.get_order_by_id(order_channel_id)
		if order_channel.result != Response.SUCCESS:
			return Response().finish()
		return order_channel


	def get_orders_main_export(self):
		return Response().success()


	def get_order_by_id(self, order_id):
		return Response().success()


	def get_orders_ext_export(self, orders):
		return Response().success()


	def convert_order_export(self, order, orders_ext, channel_id = None):
		return Response().success(order)


	def add_channel_to_convert_order_data(self, order: Order, order_channel_id):
		channel = OrderChannel()
		channel.order_id = to_str(order_channel_id)
		channel.order_number = to_str(order.channel_order_number)
		if order.channel_data:
			channel.update(order.channel_data)
			del order['channel_data']
		channel.channel_id = self.get_channel_id()
		channel.channel_type = self.get_channel_type()

		order.channel.set_attribute("channel_{}".format(self._state.channel.id), channel.to_dict())
		return order


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return False


	def check_order_import(self, order_id, convert: Order):
		return False


	def before_order_import(self, convert: Product, order, orders_ext):
		return Response().success()


	def order_import(self, convert: Order, order, orders_ext):
		return Response().success()


	def order_channel_import(self, convert: Order, order, orders_ext):
		# if not self.check_order_available_import():
		# 	return Response().stop(code = Errors.ORDER_RATE_LIMIT)
		return self.order_import(convert, order, orders_ext)


	def edit_order_channel(self, order: Product, data):
		return Response().success()


	def update_order(self, data):
		channel_id = self._state.channel.id
		update_data = dict()
		for data_key, data_value in data.items():
			update_data['channel.channel_{}.{}'.format(channel_id, data_key)] = data_value
		return Response().success(update_data)


	def get_order_channel_data(self, order, order_channel_id):
		order_channel = OrderChannel()
		order_channel.channel_id = self._state.channel.id
		order_channel.order_id = order_channel_id
		order_channel.order_code = order.code
		return order_channel


	def insert_map_order(self, order, order_id, order_channel_id):
		map_field = "channel_{}".format(self._state.channel.id)
		order_channel_data = self.get_order_channel_data(order, order_channel_id)
		order.channel.set_attribute(map_field, order_channel_data)
		update_field = "channel.{}".format(map_field)
		self.get_model_catalog().update_field(order_id, update_field, order_channel_data)
		return Response().success()


	def after_order_import(self, order_id, convert: Order, order, orders_ext):
		return Response().success()


	def order_sync_inventory(self, order: Order, setting_order):
		return Response().success()


	def channel_order_sync_inventory(self, order: Order, setting_order):
		if order.sync_inventory:
			return Response().success()
		sync = self.order_sync_inventory(order, setting_order)
		update_data = {
			'setting_order': setting_order
		}
		if sync.result == Response.SUCCESS and not setting_order:
			update_data['sync_inventory'] = True
		if not setting_order:
			if sync.data:
				sync_inventory = True
				convert = sync.data
				for index, product in enumerate(convert.products):
					if product.get('sync_inventory'):
						update_data[f'products.{index}.sync_inventory'] = True
					else:
						update_data[f'products.{index}.sync_msg_error'] = product.get('sync_msg_error')

						sync_inventory = False
				update_data['sync_inventory'] = sync_inventory

			self.convert_order(order, order, None, is_import = True)
		self.get_model_order().update(order['_id'], update_data)
		return sync


	def get_product_channel_default_map(self, product_id, channel_id = None, return_product = False):
		if not channel_id:
			channel_id = self._state.channel.id
		warehouse_map = self.get_product_warehouse_map(product_id, channel_id, return_product = True)
		if not warehouse_map:
			return False, False
		channel_product = warehouse_map.channel.get(f'channel_{channel_id}')
		channel_default_id = self.get_channel_default_id()
		channel_product_default = warehouse_map.channel.get(f'channel_{channel_default_id}')
		if not channel_product or channel_product.get('link_status') != ProductChannel.LINKED or not channel_product_default or not channel_product_default.get('product_id'):
			return False, warehouse_map.get('_id') if not return_product else warehouse_map
		return True, warehouse_map.get('_id') if not return_product else warehouse_map


	def convert_order(self, convert: Order, order, orders_ext, is_import = False):
		order_products = list()
		product_ids = dict()
		link_status = Order.LINKED
		convert.subtotal = to_decimal(convert.subtotal, 2)
		convert.total = to_decimal(convert.total, 2)
		convert.tax.amount = to_decimal(convert.tax.amount, 2)
		convert.discount.amount = to_decimal(convert.discount.amount, 2)
		if convert.tax.amount and self.is_import_order_without_tax():
			convert.total = to_decimal(to_decimal(convert.total) - to_decimal(convert.tax.amount), 2)
			convert.tax.amount = 0
			for product in convert.products:
				if product.tax_amount:
					product.total = to_decimal(product.total) - to_decimal(product.tax_amount)
					product.tax_amount = 0
		if convert.shipments:
			if isinstance(convert.shipments, list):
				convert.shipments = convert.shipments[0]
			if convert.shipments.tracking_company_code or convert.shipments.tracking_company:
				tracking_company = TrackingCompany(convert.shipments.tracking_company_code, convert.shipments.tracking_company, channel_type = self.get_channel_type())
				if tracking_company.get_code():
					convert.shipments.tracking_company_code = tracking_company.get_code()
					convert.shipments.tracking_company = tracking_company.get_name()
		if convert.line_shipments:
			for line_shipment in convert.line_shipments:
				if line_shipment.tracking_company_code or line_shipment.tracking_company:
					tracking_company = TrackingCompany(line_shipment.tracking_company_code, line_shipment.tracking_company, channel_type = self.get_channel_type())
					if tracking_company.get_code():
						line_shipment.tracking_company_code = tracking_company.get_code()
						line_shipment.tracking_company = tracking_company.get_name()
		fields_address = ['customer_address', 'shipping_address', 'billing_address']
		for address in fields_address:
			if self.country_is_us(convert[address].country.country_code):
				convert[address].state.state_code = convert[address].country.country_code
				convert[address].state.state_name = self.country_is_us(convert[address].country.country_code)
				convert[address].country.country_code = 'US'
				convert[address].country.country_name = 'United States'
		if not convert.products:
			return False
		for product in convert.products:
			product.subtotal = to_decimal(to_decimal(product.qty) * to_decimal(product.price), 2)
			if not product.total:
				product.total = product.subtotal
			product.total = to_decimal(product.total, 2)
			product.tax_amount = to_decimal(product.tax_amount, 2)
			product.discount_amount = to_decimal(product.discount_amount, 2)
			product.qty = to_int(product.qty)
			product.price = to_decimal(product.price, 2)
			# product_data = copy.deepcopy(product)

			if product.product_id:
				product.product_id = to_str(product.product_id)
				default_map, product_map = self.get_product_channel_default_map(product.product_id, return_product = True)
				if not product_map and product.is_variant and product.listing_id and product.options:
					parent_default_map, parent_product_map = self.get_product_channel_default_map(product.listing_id, return_product = True)
					if parent_product_map:
						product.parent_id = parent_product_map['_id']
						if parent_default_map:
							product.parent_link_status = 'linked'
						where_channel = list()
						where_option = list()
						where_variant_map = self.get_model_catalog().create_where_condition('parent_id', parent_product_map['_id'])
						where_variant_map.update(self.get_model_catalog().create_where_condition('is_variant', True))
						where_variant_map.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.product_id', '', '>'))
						where_option_retry = []
						for option in product['options']:
							if not option or not option.get('option_name') or not option.get('option_value_name') or to_str(option.get('option_name')).lower().startswith('personali'):
								continue
							where_option.append({
								'attribute_name': option['option_name'],
								'attribute_value_name': option['option_value_name'],
							})
							where_option_retry.append({
								'attribute_value_name': option['option_value_name'],
							})
						if where_option:
							where_channel.append(self.get_model_catalog().create_where_condition('attributes', where_option, 'allElemMatch'))
							where_channel.append(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.attributes', where_option, 'allElemMatch'))
							where_attributes = self.get_model_catalog().create_where_condition(None, where_channel, 'or')
							where_variant_map = self.get_model_catalog().create_where_condition(None, [where_variant_map, where_attributes], 'and')
							variants = self.get_model_catalog().find_all(where_variant_map, limit = 1)
							if not variants:
								where_channel = list()
								where_channel.append(self.get_model_catalog().create_where_condition('attributes', where_option_retry, 'allElemMatch'))
								where_channel.append(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.attributes', where_option_retry, 'allElemMatch'))
								where_attributes = self.get_model_catalog().create_where_condition(None, where_channel, 'or')
								where_variant_map = self.get_model_catalog().create_where_condition(None, [where_variant_map, where_attributes], 'and')
								variants = self.get_model_catalog().find_all(where_variant_map, limit = 1)
							if variants:
								product_map = variants[0]
								channel_default_id = self.get_channel_default_id()
								channel_product_map = product_map.channel.get(f'channel_{self.get_channel_id()}')
								channel_product_default = product_map.channel.get(f'channel_{channel_default_id}')
								if channel_product_default and channel_product_map.get('link_status') == ProductChannel.LINKED and channel_product_default.get('product_id'):
									default_map = True

				# custom link order item by sku
				if not product_map and self._state.channel.config.api.order_map_by_sku and product.product_sku:
					where_mapping_sku = self.get_model_catalog().create_where_condition('sku', product.product_sku)
					where_mapping_sku.update(self.get_model_catalog().create_where_condition('is_variant', product.is_variant))
					where_mapping_sku.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_default_id()}.product_id', '', '>'))
					where_mapping_sku.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.product_id', '', '>'))
					where_mapping_sku.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.link_status', 'linked'))
					product_skus = self.get_model_catalog().find_all(where_mapping_sku)
					if product_skus and to_len(product_skus) == 1:
						product_map = product_skus[0]
						default_map = True
				# EBAY LINK SKU
				if not product_map and product.product_sku and self.get_channel_type() in ['ebay']:
					where_mapping_sku = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.sku', product.product_sku)
					where_mapping_sku.update(self.get_model_catalog().create_where_condition('is_variant', product.is_variant))
					where_mapping_sku.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.product_id', '', '>'))
					product_skus = self.get_model_catalog().find_all(where_mapping_sku)
					if product_skus and to_len(product_skus) == 1:
						product_map = product_skus[0]
						channel_default_id = self.get_channel_default_id()
						channel_product_map = product_map.channel.get(f'channel_{self.get_channel_id()}')
						channel_product_default = product_map.channel.get(f'channel_{channel_default_id}')
						if channel_product_default and channel_product_map.get('link_status') == ProductChannel.LINKED and channel_product_default.get('product_id'):
							default_map = True
				if product_map:
					product.id = product_map.get('_id')
					# product.product_name = product_map.name
					# product.product_sku = product_map.sku
					product_ids[to_str(product_map.get('_id'))] = True
					product.parent_id = product_map.parent_id
					product.product_bpn = product_map.bpn
					if is_import and convert.status not in [Order.CANCELED]:
						new_qty = to_int(product_map.get('qty')) - to_int(product.qty)
						if new_qty < 0:
							product.status = 'outofstock'
							new_qty = 0

						time.sleep(0.01)
						update_data = {
							'qty': new_qty,
							"updated_time": time.time()
						}
						try:
							if product_map.get('locations') and to_len(product_map['locations']) > 1:
								locations = product_map['locations']
								if self._state.channel.config.setting.get('qty', {}).get('locations'):
									location_setting = list(map(lambda x: to_int(x['location_id']), self._state.channel.config.setting.get('qty', {}).get('locations')))
									for location in locations:
										if to_int(location['location_id']) in location_setting:
											location['qty'] -= to_int(product.qty)
											break
									update_data['locations'] = locations
						except Exception:
							self.log_traceback()
						self.get_model_catalog().update(product_map.get('_id'), update_data)
						if product_map.parent_id:
							self.update_qty_for_parent(product_map.parent_id, channel_id = self.get_channel_default_id())
				# product_data = self.sync_product_quantity(product_data, product, convert.status)
				if not default_map:
					link_status = Order.UNLINK
				else:
					product.link_status = Order.LINKED
					if not product_map.is_variant:
						self.add_order_product_need_refresh(product_map)
					else:
						self.add_product_to_need_refresh(product_map.parent_id)
				product.product_name = html_unescape(product.product_name)
				product.product_sku = html_unescape(product.product_sku)
			else:
				link_status = Order.UNLINK
		# if product_data.get('warehouse_inventories'):
		# 	convert.is_assigned = True
		# order_products.append(product_data)
		convert.link_status = link_status
		# convert.products = order_products
		convert.product_ids = product_ids
		return convert


	def country_is_us(self, country_code):
		state = {
			'PR': 'Puerto Rico'
		}
		return state.get(country_code)


	def update_order_to_channel(self, order: Order, current_order):
		channel_id = self.get_channel_id()
		if not order.channel.get(f'channel_{channel_id}', dict()).get('order_id'):
			return Response().success()
		channel_update = self.order_channel_update(order.channel[f'channel_{channel_id}']['order_id'], order, current_order)
		if channel_update.result != Response.SUCCESS:
			return channel_update
		if channel_update.data and channel_update.data.status:
			self.get_model_order().update_field(order['_id'], f'channel.channel_{channel_id}.order_status', channel_update.data.status)
		return channel_update


	def order_channel_update(self, order_id, order: Order, current_order):
		if current_order.status != order.status or (order.status == Order.COMPLETED and not self.channel_order_is_completed(order_id)) or (order.fulfillment_status == 'fulfilled' and not self.channel_order_is_completed(order_id)):

			order_status = order.status
			if order.fulfillment_status == 'fulfilled' and self.get_channel_type() == 'reverb':
				order_status = Order.COMPLETED
			if order.line_shipments:
				for shipment in order.line_shipments:
					for item in shipment.line_items:
						product = self.get_product_warehouse_map(item['product_id'], return_product = True, channel_id = self.get_channel_default_id())
						if product:
							item['product'] = product
			if hasattr(self, f"channel_order_{order_status}"):
				try:
					response = getattr(self, f"channel_order_{order_status}")(order_id, order, current_order)
				except Exception:
					self.log_traceback()
					response = Response().error()
				return response
		return Response().success()


	def channel_order_is_completed(self, order_id):
		return True


	def check_order_available_import(self, notify = False):
		return True
		if self._order_available_import is False:
			return False
		if get_config_ini('local', 'mode') != 'live' or self.is_staff_user():
			return True
		if not self.check_order_rate_limit():
			user_plan = self.get_user_plan()
			if not user_plan or to_int(user_plan['monthly_fee']) == 0:
				# email
				return Response().create_response('stop')
			upgrade = self.try_upgrade_plan()
			if not upgrade or to_int(upgrade['code']) != 200:
				self._order_available_import = False
				self.notify_limit_order(notify)
				return Response().create_response('stop')
			self._user_plan = upgrade['data']
		return True


	def check_order_rate_limit(self):
		if get_config_ini('local', 'mode') != 'live':
			return True
		user_plan = self.get_user_plan()
		if not user_plan:
			return False
		if to_int(user_plan['orders_limit']) == 0:
			return True
		total_import = self.get_order_total_import()
		return to_int(total_import) < to_int(user_plan['products_limit'])


	def delete_order_import(self, order_id):
		return Response().success()


	def after_order_pull(self, order_id, convert: Order, order, orders_ext):
		return Response().success()


	def addition_order_import(self):
		return Response().success()


	def finish_order_import(self):
		return Response().success()


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def after_order_update(self, channel_order_id, order_id, order: Order, current_order = None, setting_order = True, channel_id_update = None):
		if not current_order:
			current_order = self.get_model_order().get(order_id)
		if not current_order or not current_order.channel.get(f'channel_{self.get_channel_id()}', {}).get('order_id'):
			return Response().success()
		channel_order_id = current_order.channel.get(f'channel_{self.get_channel_id()}', {}).get('order_id')
		if current_order.status != order.status:
			order_status = order.status
			if order_status == Order.COMPLETED and channel_id_update == self.get_channel_id():
				return Response().success()

			if hasattr(self, f"order_{order_status}"):
				order_update = getattr(self, f"order_{order_status}")(channel_order_id, order_id, order, current_order, setting_order)
				if order_update.result == Response.SUCCESS:
					order_update_data = order_update.data if isinstance(order_update.data, dict) else {}
					update_data = {
						f"channel.channel_{self.get_channel_id()}.order_status": order_update_data.get('status') or order_status,
					}
					if order_update_data:
						if 'tracking_company' in order_update_data:
							update_data[f"channel.channel_{self.get_channel_id()}.shipments.tracking_company"] = order_update_data['tracking_company']
						if 'tracking_number' in order_update_data:
							update_data[f"channel.channel_{self.get_channel_id()}.shipments.tracking_number"] = order_update_data['tracking_number']
					self.get_model_order().update(order_id, update_data)
		# return self.order_canceled(channel_order_id, order_id, order, current_order)
		return Response().success()


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return Response().success()


	def filter_field_order(self, data):
		filter_data = dict()
		fields = Catalog.FILTER
		for data_key, data_value in data.items():
			if data_key in fields:
				filter_data[data_key] = data_value
		if filter_data.get('price') and self._state.channel.config.price_sync.status == StateChannelConfigPriceSync.DISABLE:
			del filter_data['price']
		if filter_data.get('qty') and self._state.channel.config.qty_sync.status == StateChannelConfigQtySync.DISABLE:
			del filter_data['qty']
		return filter_data


	# TODO: PUSH
	def prepare_display_push(self):
		entities = ('taxes', 'categories', 'products', 'orders')
		if get_config_ini('local', 'mode') != 'live':
			limits = dict()
			for entity in entities:
				limits[entity] = get_config_ini('limit', entity, '-1', file = 'local.ini')
				self._state.config[entity] = get_config_ini('config', entity, False, file = 'local.ini')
		else:
			limits = self.get_entity_limit()
			if self.is_order_process():
				self._state.config.orders = self._state.channel.support.orders
				self._state.config.taxes = False
				self._state.config.categories = False
				self._state.config.products = False
			elif self.is_inventory_process():
				self._state.config.orders = False
				self._state.config.taxes = False
				self._state.config.categories = False
				self._state.config.products = True

			else:
				self._state.config.orders = False
				self._state.config.taxes = False
				self._state.config.categories = False
				self._state.config.products = self._state.channel.support.products
		for entity in entities:
			if limits.get(entity):
				self._state.push.process[entity].limit = limits[entity]
		# entity_config = get_config_ini('config', entity, -1, file = 'local.ini')
		# if entity_config != -1:
		# 	self._state.config.set_attribute(entity, to_bool(entity_config))
		return Response().success()


	def display_push_channel(self, data = None):
		return Response().success()


	def display_push(self):
		return Response().success()


	def prepare_push_channel(self):
		return Response().success()


	def prepare_push(self):
		return Response().success()


	def get_server_name(self):
		if self._server_name:
			return self._server_name
		self._server_name = get_config_ini('server', 'name', 'Default')
		return self._server_name


	def after_push_product(self, product_id, import_data, product: Product):
		if self.is_inventory_process() or self._template_update:
			return Response().success(product)
		server_error = ''
		if self._state.channel.channel_type not in self.channel_no_after_push():
			update_field = dict()
			if import_data.result in (Response.ERROR, Response.WARNING):
				publish_status = ProductChannel.ERRORS
				if import_data.code and import_data.msg:
					msg = Errors().get_msg_error(import_data.code) + ": " + f"{self.replace_msg(import_data.msg)}"
				elif import_data.code:
					msg = Errors().get_msg_error(import_data.code)
				elif import_data.msg:
					msg = import_data.msg
				else:
					msg = Errors().get_msg_error(Errors.EXCEPTION_IMPORT)

				status = ProductChannel.ERRORS
				server_error = self.get_server_name()
			else:
				msg = ''
				publish_status = ProductChannel.COMPLETED
				status = ProductChannel.ACTIVE
				update_field[f'channel.channel_{self.get_channel_id()}.price'] = product.price
				qty = product.qty
				if product.variants:
					qty = 0
					for variant in product.variants:
						variant_update = dict()
						qty += to_int(variant.qty)
						for row in ['qty', 'price']:
							if variant[row] != variant['channel'][f'channel_{self.get_channel_id()}'].get(row):
								variant_update[f"channel.channel_{self.get_channel_id()}.{row}"] = variant.get(row)
						if variant_update:
							self.get_model_catalog().update(variant['_id'], variant_update)
				update_field[f'channel.channel_{self.get_channel_id()}.qty'] = qty
				if not self.is_channel_default():
					update_field['updated_time'] = time.time()
			src_channel_key = f"channel_{self.get_src_channel_id()}"
			channel_key = f"channel_{self._state.channel.id}"
			update_field[f"channel.{src_channel_key}.server_error"] = server_error
			update_field[f"channel.{src_channel_key}.publish_status"] = publish_status
			update_field[f"channel.{src_channel_key}.publish_action"] = None
			update_field[f"channel.{src_channel_key}.error_message"] = msg
			product['channel'][src_channel_key] = self.get_product_channel_data(product, '', channel_id = self.get_src_channel_id())
			product['channel'][src_channel_key]['publish_status'] = publish_status
			product['channel'][src_channel_key]['error_message'] = msg
			product['channel'][src_channel_key]['publish_action'] = None
			if self.is_channel_default():
				product_channel = self.get_product_channel_data(product, '')
				if product_channel.get('status') != 'active':
					update_field[f"channel.{channel_key}.status"] = status
					update_field[f"channel.{channel_key}.publish_status"] = publish_status
					update_field[f"channel.{channel_key}.publish_action"] = None
					update_field[f"channel.{channel_key}.error_message"] = msg
					product['channel'][channel_key] = self.get_product_channel_data(product, '')
					product['channel'][channel_key]['publish_status'] = publish_status
					product['channel'][channel_key]['error_message'] = msg
					product['channel'][channel_key]['publish_action'] = None
					product['channel'][channel_key]['status'] = status

			else:
				update_field[f"channel.{src_channel_key}.status"] = status
				product['channel'][src_channel_key]['status'] = status

			self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)


	# TODO: CLEAR TARGET DATA
	def clear_channel(self):
		if not self._state.config.clear_shop and not self._state.config.reset_clear:
			return Response().success()
		if not hasattr(self, self._state.channel.clear_process.function):
			return Response().success()
		fn_clear = getattr(self, self._state.channel.clear_process.function)
		clear = fn_clear()
		if clear.result == Response().SUCCESS:
			entities = ['taxes', 'manufacturers', 'categories', 'products', 'customers', 'orders', 'reviews', 'pages', 'blogs', 'coupons', 'cartrules']
			entity_select = list()
			for entity in entities:
				if self._state.config[entity]:
					entity_select.append(entity)
			if entity_select:
				msg = "Current " + ', '.join(entity_select) + ' cleared'
				if not clear.msg:
					clear.msg = ''
				clear['msg'] += msg
		# clear['msg'] += self.get_msg_start_import('taxes')
		return clear


	# process image
	def process_image_before_import(self, url, path):
		if not path:
			full_url = url
			path = strip_domain_from_url(url)
		else:
			full_url = join_url_path(url, path)
		path = re.sub(r"[^a-zA-Z0-9.\-_/]", '', path)
		full_url = self.parse_url(full_url)
		return Prodict(**{
			'url': full_url,
			'path': path
		})


	def parse_url(self, url):
		if not url:
			return url
		url = self.remove_duplicate_ds(url)
		scheme, netloc, path, qs, anchor = urllib.parse.urlsplit(url)
		path = urllib.parse.quote(path, '/%=$')
		qs = urllib.parse.quote_plus(qs, ':&=')
		new_url = to_str(urllib.parse.urlunsplit((scheme, netloc, path, qs, anchor)))
		if anchor and anchor.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
			new_url = to_str(new_url).replace('#', '%23')
		return new_url


	def join_url_auth(self, url, auth: StateChannelAuth):
		if not url:
			return url
		auth_user = urllib.parse.quote(auth.username)
		auth_pass = urllib.parse.quote(auth.password)
		scheme, netloc, path, qs, anchor = urllib.parse.urlsplit(url)
		netloc = to_str(auth_user) + ':' + to_str(auth_pass) + '@' + to_str(netloc)
		return to_str(urllib.parse.urlunsplit((scheme, netloc, path, qs, anchor)))


	def name_to_code(self, name):
		if not to_str(name).strip(' / - _'):
			return ''
		str_convert = html.unescape(name)
		if isinstance(str_convert, bool):
			if str_convert:
				str_convert = 'yes'
			else:
				str_convert = 'no'
		result = self.generate_url(str_convert)
		if not result:
			return self.parse_url(str_convert).lower()
		try:
			check_encode = chardet.detect(result.encode())
			if check_encode['encoding'] != 'ascii' or not result:
				return self.parse_url(result).lower()
		except Exception:
			pass
		return result.strip('- ')


	def generate_url(self, title):
		if not title:
			return ''
		title = self.remove_special_char(title).lower()
		title = title.strip(' -')
		special = {
			'Æ': 'AE',
			'Đ': 'd',
			'Ø': 'O',
			'Þ': 'TH',
			'ß': 'ss',
			'æ': 'ae',
			'ð': 'd',
			'ø': 'o',
			'þ': 'th',
			'Œ': 'OE',
			'œ': 'oe',
			'ƒ': 'f',
		}
		for index, val in special.items():
			title = title.replace(index, val)
		chars = list(title)
		res = list()
		for char in chars:
			text = unicodedata.normalize('NFD', char).encode('ascii', 'ignore')
			res.append(text.decode() if text.decode() else char)
		res = ''.join(res)
		res = self.replace_url(res)
		return res


	def remove_special_char(self, name):
		if not to_str(name).strip(' / - _'):
			return ''
		name = html.unescape(name)
		result = name.replace(' ', '-').replace('_', '-').replace('.', '-')
		result = result.replace('/', '')
		result = ''.join(e for e in result if e.isalnum() or e == '-')
		result = result.strip(' -')
		while result.find('--') != -1:
			result = result.replace('--', '-')
		return result.strip(' -')


	def replace_url(self, url):
		result = url.strip(' -')
		result = result.replace(' ', '-').replace('_', '-')
		while result.find('--') != -1:
			result = result.replace('--', '-')
		result = result.replace(' ', '-').replace('_', '-')
		return result.strip(' -')


	def reset_process(self, process_id):
		process_info = self.get_sync_info(process_id)
		state = False
		if process_info and process_info.state_id:
			state = self.get_state_by_id(process_info.state_id)
		if not state:
			return False
		action = self._state.resume.action
		for key, value in state.get(action).process.items():
			value = self.reset_entity_process(value)
		state.config.reset = True
		state[action].resume.action = 'display_{}'.format(action)
		state[action].resume.type = ''
		if action == 'pull':
			state.channel.clear.function = 'clear_channel_taxes'
			state.channel.clear.result = 'process'

		res = self.get_model_state().update(process_info.state_id, {action: state.get(action)})
		return res


	def reset_entity_process(self, process):
		new_process = EntityProcess()
		new_process.total = process.total
		new_process.limit = process.limit
		for key, value in process.items():
			if key not in new_process:
				# reset smart collection shopify
				if key == 'id_src_smart':
					new_process[key] = 0
				else:
					new_process[key] = value
		return new_process


	def prepare_display_finish_pull(self):
		return Response().success()


	def prepare_display_finish_push(self):
		return Response().success()


	def display_finish_channel_pull(self):
		return Response().success()


	def display_finish_channel_push(self):
		return Response().success()


	def display_finish_push(self):
		if self.is_inventory_process():
			try:
				activities_id = self._state.channel.config.activity_id

				_content = 'Sync '
				entity_sync = []
				if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable':
					entity_sync.append('Inventory')
				if self._state.channel.config.setting.get('price', {}).get('status') != 'disable':
					entity_sync.append('Price')
				if self._state.channel.config.setting.get('qty', {}).get('sync_sku') != 'disable':
					entity_sync.append('SKU')
				_content += ', '.join(entity_sync)
				notification_data = {
					'group': Activity.GROUP_CHANNEL_SYNC,
					'date_requested': self._date_requested,
					'updated_at': get_current_time(),
					'total': self._state.push.process.products.imported,
					'error': self._state.push.process.products.error,
					'result': Activity.SUCCESS if not self._state.push.process.products.error else Activity.FAILURE,
					'action': _content
				}
				if not activities_id:
					activities_id = self.create_activity(**notification_data)
					self._state.channel.config.activity_id = activities_id
				else:
					self.update_activiti(activities_id, notification_data)
			except:
				self.log_traceback()
		# if self.is_inventory_process() and self._state.push.process.products.total:
		# 	notification_data = {
		# 		'code': '',
		# 		'content': '',
		# 		'activity_type': 'inventory_sync',
		# 		'description': Messages.INVENTORY_SYNC_IMPORT.format(self._state.channel.channel_type),
		# 		'date_requested': self._date_requested,
		# 		'result': Activity.SUCCESS
		# 	}
		# 	_content = 'Sync '
		# 	entity_sync = []
		# 	if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable':
		# 		entity_sync.append('Inventory')
		# 	if self._state.channel.config.setting.get('price', {}).get('status') != 'disable':
		# 		entity_sync.append('Price')
		# 	if self._state.channel.config.setting.get('qty', {}).get('sync_sku') != 'disable':
		# 		entity_sync.append('SKU')
		# 	_content += ','.join(entity_sync)
		# 	notification_data['content'] = _content
		# 	if self._state.push.process.products.error > 0 or self._state.push.process.orders.error > 0 \
		# 			or self._state.push.process.orders.error > 0 or self._state.push.process.categories.error > 0 \
		# 			or self._state.push.process.taxes.error > 0:
		# 		notification_data['result'] = Activity.FAILURE
		# 	self.create_activity_recent(**notification_data)
		if self.is_product_process() and not self.is_refresh_process():
			self.count_number_products(True)
		if not self.is_inventory_process() and not self._template_update:
			where = self.get_model_catalog().create_where_condition(f"channel.channel_{self.get_src_channel_id()}.lock_by", self.get_pid())
			where.update(self.get_model_catalog().create_where_condition(f"channel.channel_{self.get_src_channel_id()}.lock_by_server", self.get_server_name()))
			where.update(self.get_model_catalog().create_where_condition(f"channel.channel_{self.get_src_channel_id()}.publish_status", ProductChannel.PUSHING))
			self.get_model_catalog().update_many(where, {f"channel.channel_{self.get_src_channel_id()}.publish_status": "new"})
		return Response().success()


	def count_number_products(self, push = False):
		where_product = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.status', 'active')
		where_product.update(self.get_model_catalog().create_where_condition('is_variant', False))
		number_products = self.get_model_catalog().count(where_product)
		number_products_linked = number_products
		if not self.is_channel_default():
			where_product.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.link_status', 'linked'))
			number_products_linked = self.get_model_catalog().count(where_product)
		update = dict(number_products = number_products, number_products_linked = number_products_linked)
		if not push:
			update['last_imported'] = get_current_time()
		self.update_channel(**update)


	def display_finish_pull(self):
		if self.is_refresh_process():
			try:
				activities_id = self._state.channel.config.activity_id
				notification_data = {
					'group': Activity.GROUP_MAIN_SYNC,
					'date_requested': self._date_requested,
					'updated_at': get_current_time(),
					'total': self._state.pull.process.products.imported,
					'error': self._state.pull.process.products.error,
					'result': Activity.SUCCESS if not self._state.pull.process.products.error else Activity.FAILURE
				}
				if not activities_id:
					activities_id = self.create_activity(**notification_data)
					self._state.channel.config.activity_id = activities_id
				else:
					self.update_activiti(activities_id, notification_data)
			except:
				self.log_traceback()
		# self.get_model_sync_mode().after_import(self.get_channel_id(), self.get_sync_id())
		return Response().success()


	# TODO: MAP
	def get_category_map(self, category_id):
		catalog = self.get_model_category().get(to_str(category_id))
		return catalog.channel.get("channel_{}".format(self._state.channel.id)).category_id if catalog else False


	def get_product_map(self, product_id):
		catalog = self.get_model_catalog().get(product_id)
		if not catalog:
			return False

		if self._state.channel.default:
			field_check = 'channel_{}'.format(self.get_src_channel_id())
			if not catalog['channel'].get(field_check) or catalog['channel'][field_check].get('link_status') != ProductChannel.LINKED:
				return False
		field_check = 'channel_{}'.format(self.get_channel_id())
		if not catalog['channel'].get(field_check) or catalog['channel'][field_check].get('status') != ProductChannel.ACTIVE:
			return False

		return catalog['channel'][field_check].get('product_id')


	def get_product_warehouse_map(self, product_id, channel_id = None, return_product = False):
		if not product_id:
			return False
		if not channel_id:
			channel_id = self._state.channel.id
		field_check = "channel.channel_{}.product_id".format(channel_id)
		where_find = self.get_model_catalog().create_where_condition(field_check, to_str(product_id))
		where_find.update(self.get_model_catalog().create_where_condition(f'channel.channel_{channel_id}.status', 'active'))
		products = self.get_model_catalog().find_all(where_find, limit = 10)
		product = False
		if products:
			for row in products:
				if row.get('is_variant'):
					product = row
					break
			if not product:
				product = products[0]
		if not product:
			if self.is_order_process() and self.get_channel_type() == 'ebay':
				where = self.get_model_catalog().create_where_condition(f"channel.channel_{channel_id}.old_item_id", {'$elemMatch': {"$eq": to_str(product_id)}})
				products = self.get_model_catalog().find_all(where, limit = 1)
				if products:
					product = products[0]
		if not product:
			return False
		product = Prodict(**product)
		return product.get('_id') if not return_product else product


	# ================================
	def get_warehouse_location_default(self):
		if self._warehouse_location_default is not None:
			return to_int(self._warehouse_location_default)
		self._warehouse_location_default = self.get_model_sync_mode().get_warehouse_location_default()
		return to_int(self._warehouse_location_default)


	def get_warehouse_location_fba(self):
		if self._warehouse_location_fba is not None:
			return to_int(self._warehouse_location_fba)
		self._warehouse_location_fba = self.get_model_sync_mode().get_warehouse_location_fba()
		return to_int(self._warehouse_location_fba)


	def create_activity_feed(self, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		return model.create_feed(channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def create_activity_notification(self, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		return model.create_notification(channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def create_activity_changed(self, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		return model.create_product_changed(channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def create_activity_process(self, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		model.create_process(channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def create_activity_recent(self, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		model.create_recent(channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def create_activity_order_sync(self, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		model.create_order_sync(channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def create_activity(self, group, **kwargs):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		return model.create_activity(group, channel_id = self._state.channel.id, channel_type = self._state.channel.channel_type, **kwargs)


	def update_activiti(self, activity_id, data):
		model = CollectionActivity()
		model.set_user_id(self._user_id)
		model.update(activity_id, data)


	def update_state(self, data):
		if self._state_id == 'litcommerce':
			return True
		return self.get_model_state().update(self._state_id, data)


	def update_field_state(self, field, value):
		return self.get_model_state().update_field(self._state_id, field, value)


	def get_process_by_type(self, process_type, channel_id = None):
		if not channel_id:
			channel_id = self._channel_id
		if self._request_data.get('processes'):
			for process_id, process_data in self._request_data['processes'].items():
				if to_int(process_data['channel_id']) == to_int(channel_id) and process_data['type'] == process_type:
					return Prodict.from_dict(process_data)
		return self.get_model_sync_mode().get_process_by_type(channel_id, process_type)


	def get_process_by_id(self, process_id):
		if self._request_data.get('processes') and self._request_data['processes'].get(to_str(process_id)):
			return Prodict.from_dict(self._request_data['processes'].get(to_str(process_id)))

		return self.get_model_sync_mode().get_process_by_id(process_id)


	def create_order_process(self, state):
		order_state = SyncState()
		order_state.channel = state.channel
		order_state.user_id = self._user_id
		state_id = self.get_model_state().create(order_state)
		if not state_id:
			return False
		process_id = self.get_model_sync_mode().create_order_sync_process(state_id, self._channel_id)
		if not process_id:
			return False
		self.get_model_state().update_field(state_id, 'sync_id', process_id)
		order_state.sync_id = process_id
		return {
			'process_id': process_id,
			'state_id': state_id,
			'state': order_state
		}


	def create_inventory_process(self, state):
		inventory_state = SyncState()
		inventory_state.channel = state.channel
		inventory_state.user_id = self._user_id
		inventory_state.push.process.products['condition'] = [
			Prodict.from_dict({
				'field': f"channel.channel_{state.channel.id}.status",
				'value': ProductChannel.ACTIVE,
				'condition': '='
			}),
			Prodict.from_dict({
				'field': f"channel.channel_{state.channel.id}.link_status",
				'value': ProductChannel.LINKED,
				'condition': '='
			})
		]
		state_id = self.get_model_state().create(inventory_state)
		if not state_id:
			return False
		process_id = self.get_model_sync_mode().create_inventory_sync_process(state_id, self._channel_id)
		if not process_id:
			return False
		self.get_model_state().update_field(state_id, 'sync_id', process_id)
		inventory_state.sync_id = process_id
		return {
			'process_id': process_id,
			'state_id': state_id,
			'state': inventory_state
		}


	def create_refresh_process_scheduler(self):
		return self.get_model_sync_mode().create_refresh_process_scheduler(self.get_channel_id())


	def after_create_order_process(self, process):
		return Response().success()


	def after_create_inventory_process(self, process):
		return Response().success()


	def get_scheduler_info(self, scheduler_id):
		return self.get_model_sync_mode().get_scheduler_info(scheduler_id)


	def create_scheduler_process(self, process_id):
		return self.get_model_sync_mode().create_scheduler_process(process_id)


	def set_last_time_scheduler(self, scheduler_id):
		return self.get_model_sync_mode().set_last_time_scheduler(scheduler_id)


	def _adjustment_price(self, adjustment, price):
		price = to_decimal(price)
		value = to_decimal(adjustment['value'])
		if adjustment['modifier'] == 'percent':
			value = round((price * value) / 100, 2)
		return round(price + value if adjustment['direction'] == 'increment' else price - value, 2)


	def adjustment_price(self, price_template, price, product = None):
		if price_template.get('custom_price') and price_template['custom_price'].get('status') == 'enable':
			value = to_decimal(price_template['custom_price']['value'], 2)
			if price_template['custom_price'].get('override') or price_template['custom_price'].get('mapping'):
				value = price_template['custom_price'].get('override') or price_template['custom_price'].get('mapping')
				value = to_decimal(self.assign_attribute_to_field(value, product), 2)
			if not value:
				return price
			return value
		adjustment = price_template.get('adjustment') or price_template
		price = self._adjustment_price(adjustment, price)
		if price_template.get('extend_adjustment'):
			for row in price_template['extend_adjustment']:
				if not row.get('value'):
					continue
				price = self._adjustment_price(row, price)
		if adjustment.get('rounding'):
			price = rounding_price(adjustment.get('rounding'), price)
		return price


	def allow_attribute_title_template(self):
		return ['sku', 'name', 'description', 'short_description', 'brand', 'price', 'condition', 'condition_notes', 'category', 'manufacturer', 'model', 'ean', 'asin', 'espn', 'upc', 'gtin', 'gcid', 'epid', 'weight', 'width', 'length', 'height', 'mpn', 'product_type', 'cost', 'tags', 'meta_title', 'meta_description', 'msrp']


	def assign_title_template_channel(self, channel_type, title_template, product, **kwargs):
		try:
			module_class = importlib.import_module("merchant.{}.utils".format(channel_type))
			model_class = getattr(module_class, 'Merchant{}Utils'.format(channel_type.capitalize()))
			utils = model_class()
			if hasattr(utils, 'assign_title_template'):
				getattr(utils, 'assign_title_template')(title_template, product, **kwargs)
		except:
			pass
		return True


	def assign_title_template(self, title_template, product, **kwargs):
		if not title_template:
			return True
		allow_field = self.allow_attribute_title_template()
		title = title_template['title']
		changed = False
		for field in allow_field:
			value = to_str(product.get(field))
			if not value:
				continue
			title = to_str(title).replace("{" + field + "}", value)
			changed = True
		if not changed:
			return True
		model_product = self.get_model_catalog()
		field = f"channel.channel_{self._channel_id}.name"
		model_product.update_field(product['_id'], field, title)
		self.assign_title_template_channel(self._channel_type, title_template, product, **kwargs)
		return True


	def assign_template(self, product: Product, templates_data = None, update = True, pickup_template_type = False):
		# if self.is_inventory_process():
		# 	return product
		if not product.channel.get(f'channel_{self.get_channel_id()}') or not product.channel[f'channel_{self.get_channel_id()}'].get('templates'):
			return product
		product = self._assign_template(product, templates_data, update, pickup_template_type = pickup_template_type)
		if product.variants:
			for variant in product.variants:
				if not variant.channel.get(f'channel_{self.get_channel_id()}'):
					variant.channel[f'channel_{self.get_channel_id()}'] = Prodict()
				variant.channel[f'channel_{self.get_channel_id()}']['templates'] = copy.deepcopy(product.channel[f'channel_{self.get_channel_id()}']['templates'])
				if not variant.channel[f'channel_{self.get_channel_id()}'].get('template_data'):
					variant.channel[f'channel_{self.get_channel_id()}']['template_data'] = {}
				if product.channel[f'channel_{self.get_channel_id()}']['template_data']:
					for parent_template_type, parent_template_data in product.channel[f'channel_{self.get_channel_id()}']['template_data'].items():
						if product.channel[f'channel_{self.get_channel_id()}']['templates'].get(parent_template_type):
							variant.channel[f'channel_{self.get_channel_id()}']['template_data'][parent_template_type] = copy.deepcopy(parent_template_data)
				variant = self._assign_template(variant, templates_data, update, pickup_template_type = pickup_template_type, parent = product)
		return product


	def variants_to_option(self, variants):
		max_attribute = 0
		option_src = list()
		for variant in variants:
			attributes = list(filter(lambda x: x.use_variant, variant.attributes))
			if max_attribute <= to_len(attributes):
				max_attribute = to_len(attributes)
				option_src = attributes
		all_option_name = list()
		for option in option_src:
			if option.attribute_name in all_option_name:
				continue
			all_option_name.append(option.attribute_name)
		options = dict()
		for variant in variants:
			if variant and 'visible' in variant:
				if not to_bool(variant.visible):
					continue
			for attribute in variant.attributes:
				if attribute.attribute_name not in all_option_name:
					continue
				if attribute.attribute_name not in options:
					options[attribute.attribute_name] = list()
				if not attribute.attribute_value_name or attribute.attribute_value_name in options[attribute.attribute_name]:
					continue
				options[attribute.attribute_name].append(attribute.attribute_value_name)
		return options


	def _assign_template(self, product: Product, templates_data = None, update = True, pickup_template_type = False, parent = False):
		channel_data = product.channel[f"channel_{self.get_channel_id()}"]
		template_data = channel_data.get('templates')
		if not template_data:
			return product
		attributes_names = [row.attribute_name for row in product.attributes]
		product['extend_attribute'] = list()
		if parent:
			for attribute in parent.attributes:
				if attribute.attribute_name not in attributes_names:
					product['extend_attribute'].append(attribute)
		edited = False
		required_template = self.TEMPLATE_REQUIRED_ASSIGN
		if self.is_inventory_process():
			required_template = ['price', 'title']
		for template_type in required_template:
			if pickup_template_type and template_type != pickup_template_type:
				continue
			template_id = template_data.get(template_type)
			if not template_id:
				continue
			if not self.is_inventory_process():
				if template_type == 'price':
					price_setting = self._state.channel.config.setting.get('price')
					if price_setting and price_setting.get('use_sale_price') == 'enable' and self.is_special_price(product):
						product.price = product.special_price.price
			if templates_data and templates_data.get(template_type):
				template_type_data = templates_data[template_type]
			else:
				template_type_data = self.get_model_template().get(template_id)
			if not hasattr(self, f'channel_assign_{template_type}_template') or not template_type_data:
				continue
			edited = True
			template_type_data = Prodict.from_dict(template_type_data)
			current_title = channel_data.get('name') or product.name
			current_description = channel_data.get('description') or channel_data.get('description')
			product = getattr(self, f'channel_assign_{template_type}_template')(product, template_type_data)
			if self.is_inventory_process() and template_type == 'title':
				new_title = product['channel'][f'channel_{self.get_channel_id()}'].get('name') or product.name
				new_description = product['channel'][f'channel_{self.get_channel_id()}'].get('description') or product.description
				if new_title != current_title:
					product.changed_title = True
				if new_description != current_description:
					product.changed_description = True
		if edited and update:
			self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}', product.channel.get(f'channel_{self.get_channel_id()}'))
		return product


	def channel_assign_template(self, product: Product, templates_data = None, update = True):
		return product


	def channel_assign_price_template(self, product, templates_data):
		price_setting = self._state.channel.config.setting.get('price')
		if price_setting and price_setting.get('use_sale_price') == 'enable' and self.is_special_price(product):
			product['price'] = product.special_price.price
			product['special_price'] = ProductSpecialPrice()
			product.channel[f'channel_{self.get_channel_id()}']['special_price'] = ProductSpecialPrice()
		price = round(self.adjustment_price(templates_data, product.price, product), 2)
		product.price = price
		product.channel[f'channel_{self.get_channel_id()}']['price'] = price
		if product.special_price and product.special_price.price:
			special_price = round(self.adjustment_price(templates_data, product.special_price.price, product), 2)
			special_price_obj = product.special_price
			special_price_obj.price = special_price
			product.channel[f'channel_{self.get_channel_id()}']['special_price'] = special_price_obj
			product.special_price = special_price_obj
		return product


	def is_channel_strip_html_in_description(self):
		return self.get_channel_type() in ['etsy', 'facebook', 'google']


	def escape_description(self, description):
		try:
			soup = BeautifulSoup(description, 'html.parser')
			description = soup.prettify(formatter = lambda s: s.replace(u'\xa0', ' '))
		except Exception:
			self.log_traceback(msg = description)
		return to_str(description).replace('’', "'").replace("”", '"').replace('“', '"').replace('–', '-')


	def channel_assign_title_template(self, product, templates_data):
		description_format = False
		if self.is_channel_strip_html_in_description():
			if self.get_channel_type() != 'ebay':
				description_format = 'nl2br'

			else:
				description_format = 'br2nl'
		elif self.get_channel_type() == 'ebay':
			description_format = 'nl2br'
		draft_data = self.get_draft_extend_channel_data(product)
		if draft_data.get('description'):
			product.description = draft_data['description']
		if draft_data.get('short_description'):
			product.short_description = draft_data['short_description']
		description = templates_data['description']
		description = self.assign_attribute_to_field(description, product, description_format = description_format)
		product.description = description
		product.channel[f'channel_{self.get_channel_id()}']['description'] = description
		if draft_data.get('name'):
			product.name = draft_data['name']
		title = templates_data['title']
		title = self.assign_attribute_to_field(title, product)
		product.name = title
		product.channel[f'channel_{self.get_channel_id()}']['name'] = title
		return product


	def format_attribute_value(self, attribute_name, value, description_format = False):
		if json_decode(value) and isinstance(json_decode(value), list):
			value = ', '.join(list(map(lambda x: to_str(x), json_decode(value))))

		if not description_format or attribute_name in ['description', 'short_description']:
			return value
		if description_format == 'nl2br':
			value = nl2br(value)
		elif description_format == 'br2nl':
			value = self.strip_html_from_description(value)
		return value


	def old_assign_attribute_to_field(self, field, product, lower = False, description_format = False):
		field = to_str(field)
		for attribute in product.attributes:
			value = attribute.attribute_value_name
			value = self.format_attribute_value(attribute.attribute_name, value, description_format)
			if field.find("{{" + attribute.attribute_name + "}}") == -1:
				continue
			field = to_str(field).replace("{{" + attribute.attribute_name + "}}", value)
		if field.find("{{custom_attributes}}") != -1:
			custom_attributes = []
			for attribute in product['attributes']:
				value = self.format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)
				custom_attributes.append(f"<p>{attribute['attribute_name']}: {value}</p>")
			if custom_attributes:
				field = to_str(field).replace("<p>{{custom_attributes}}</p>", "\n".join(custom_attributes)).replace("{{custom_attributes}}", "\n".join(custom_attributes))
		allow_field = self.allow_attribute_title_template()
		for attribute in allow_field:
			value = product.get(attribute)
			if isinstance(value, (dict, Prodict)):
				if 'name' in value:
					value = value.get('name')
				else:
					value = ''
			else:
				value = to_str(value)
			value = self.format_attribute_value(attribute, value, description_format)
			if field.find("{{" + attribute + "}}") == -1:
				continue
			if not value:
				value = ''
			field = field.replace("{{" + attribute + "}}", value)
		images = []
		if product['thumb_image']['url']:
			images.append(product['thumb_image']['url'])
		for image in product['images']:
			images.append(image['url'])
		for index in range(1, 13):
			attribute_name = f"product_image_{index}"
			if index > len(images):
				continue
			if field.find("{{" + attribute_name + "}}") == -1:
				continue
			field = field.replace("{{" + attribute_name + "}}", images[index - 1])
		fields = re.findall("{{.*?}}", field)
		for row in fields:
			text_replace = row
			row = row.replace('{{', '').replace('}}', '')
			if row.find('.') == -1:
				continue
			obj = row.split('.')
			attribute_name = obj[0]
			attribute = dict()
			for attribute_row in product['attributes']:
				if attribute_row['attribute_name'] == attribute_name:
					attribute = attribute_row
					break
			if not attribute:
				continue
			value = json_decode(attribute['attribute_value_name'])
			if not value:
				continue
			del obj[0]
			for attribute_field in obj:
				try:
					value = value.get(attribute_field, {})
				except:
					value = ''
					break
			field = field.replace(text_replace, to_str(value))
		field = re.sub("{{.*?}}", '', field)
		field = field.replace('<p><img src=""></p>', "").replace('<img src="">', "")
		return field


	def assign_attribute_to_field(self, field, product, lower = False, description_format = False):
		field = to_str(field)
		# match_images = re.findall('(<img(.*?)src="{{(product_image_[1-9])}}"(.*?)>)', field)
		# for image in match_images:
		# 	field = field.replace(image[0], '''{% if ''' + image[2] + ''' %}''' + image[0] + '''{% endif %}''')
		real_field = field.replace('{{vendor}}', '{{brand}}')

		allow_field = self.allow_attribute_title_template()
		changed = True
		if field.find("{{custom_attributes}}") != -1:
			custom_attributes = []
			for attribute in product['attributes']:
				value = self.format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)
				custom_attributes.append(f"<p>{attribute['attribute_name']}: {value}</p>")
			if custom_attributes:
				field = to_str(field).replace("<p>{{custom_attributes}}</p>", "\n".join(custom_attributes)).replace("{{custom_attributes}}", "\n".join(custom_attributes))
		fields = re.findall("{{.*?}}", field)

		for row in fields:
			text_replace = row
			split_replace = text_replace.split(' or ')
			all_field_replace = []
			for field_replace in split_replace:
				field_row = attribute_name_to_code(field_replace)
				all_field_replace.append(field_row)

			field = field.replace(text_replace, '{{' + ' or '.join(all_field_replace) + '}}')

		extend_data = {
			'product': product
		}
		if product.get('variant_options'):
			variant_options = dict()
			for option in product['variant_options']:
				variant_options[to_str(option['option_name']).lower()] = ', '.join(option['option_values'])
			extend_data['variant_options'] = variant_options

		if product.get('is_variant'):
			attribute_variants = list(filter(lambda x: x.get('use_variant'), product['attributes']))
			attribute_no_variants = list(filter(lambda x: not x.get('use_variant'), product['attributes']))
			attributes_extend = attribute_variants
			attributes_extend.extend(attribute_no_variants)
		else:
			attributes_extend = product['attributes']
		if product.extend_attributes:
			attributes_extend.extend(product.extend_attributes)
		for attribute in attributes_extend:
			value = self.format_attribute_value(attribute['attribute_name'], attribute['attribute_value_name'], description_format)

			attribute_name = attribute_name_to_code(to_str(attribute['attribute_name']))
			if attribute_name in extend_data and not product.get('is_variant'):
				continue
			if lower:
				attribute_name = attribute_name.lower()
			if json_decode(value):
				value = json_decode(value)
			extend_data[attribute_name] = value
		for attribute in allow_field:
			if attribute in extend_data:
				continue
			value = product.get(attribute)
			if isinstance(value, dict):
				if 'name' in value:
					value = value.get('name')
				else:
					value = ''
			else:
				value = to_str(value)
			value = self.format_attribute_value(attribute, value, description_format)
			extend_data[attribute] = value
		images = []
		if product['thumb_image']['url']:
			images.append(product['thumb_image']['url'])
		for image in product['images']:
			images.append(image['url'])
		extend_data['product_images'] = images
		for index, row in enumerate(images):
			attribute_name = f"product_image_{index + 1}"
			extend_data[attribute_name] = row
		try:
			template = JinjaTemplate(field)
			new_value = template.render(extend_data).strip()
			if not new_value:
				template = JinjaTemplate(real_field)
				new_value1 = template.render(extend_data).strip()
				if new_value1:
					new_value = new_value1.split('|||')
					if to_len(new_value) == 1:
						new_value = new_value[0]
			return new_value
		except Exception:
			return self.old_assign_attribute_to_field(real_field, product, lower, description_format)


	def apply_channel_setting(self, product: Product):
		if not self.is_inventory_process():
			return product
		product = self._apply_channel_setting(product, None)
		if product.variants:
			for variant in product.variants:
				variant = self._apply_channel_setting(variant, product)
		return product


	def get_setting_max_qty(self):
		qty_setting = self._state.channel.config.setting.get('qty')
		if isinstance(qty_setting, dict) and to_decimal(qty_setting.get('adjust')):
			if qty_setting['max_qty']:
				return to_int(qty_setting['max_qty'])
		return False


	def is_qty_setting_rule(self):
		qty_setting = self._state.channel.config.setting.get('qty')
		if isinstance(qty_setting, dict) and (to_decimal(qty_setting.get('adjust')) != 100 or to_int(qty_setting['min_qty']) or to_int(qty_setting['max_qty'])):
			return True
		return False


	def is_price_setting_rule(self):
		price_setting = self._state.channel.config.setting.get('price')
		if isinstance(price_setting, dict) and to_decimal(price_setting.get('value')):
			return True
		return False


	def setting_price_rule(self, price_setting, product_price):
		if to_decimal(price_setting.get('value')) and price_setting.get('modifier') and price_setting.get('direction'):
			adjust_value = to_decimal(price_setting['value']) if price_setting['modifier'] == 'fixed' else product_price * to_decimal(price_setting['value']) / 100
			product_price = product_price + adjust_value if price_setting['direction'] == 'increase' else product_price - adjust_value
		product_price = to_decimal(product_price, 2)
		if price_setting.get('rounding'):
			product_price = rounding_price(price_setting.get('rounding'), product_price)
		return product_price


	def is_apply_price_rule_only_sale_price(self):
		return self._state.channel.config.api.price_rule_price_only


	def _apply_channel_setting(self, product: Product, parent = None):
		channel_data = product.channel.get(f"channel_{self.get_channel_id()}", {})
		template_data = channel_data.get('templates')
		if parent:
			channel_data = parent.channel[f"channel_{self.get_channel_id()}"]
			template_data = channel_data.get('templates')
		price_template = template_data.get('price') if template_data else False
		price_setting = self._state.channel.config.setting.get('price')
		qty_setting = self._state.channel.config.setting.get('qty')
		reverb_mapping = self._state.channel.config.setting.get('reverb_mapping')
		category_template = template_data.get('category') if template_data else False
		product_price = to_decimal(product['price'])
		product['real_price'] = copy.deepcopy(to_decimal(product['price']))
		real_product_price = to_decimal(product['price'])
		if not price_template and price_setting and price_setting.get('use_sale_price') == 'enable' and self.is_special_price(product):
			product_price = product.special_price.price
		if not price_template and price_setting and isinstance(price_setting, dict):
			if price_setting.get('filter_condition') and price_setting['filter_condition'] != []:
				if channel_data.get('template_data') and channel_data.template_data.get('category'):
					try:
						for condition in price_setting['filter_condition']:
							if channel_data.template_data['category']['info']['reverb_condition'].get('value') == condition['value']:
								product_price = self.setting_price_rule(price_setting, product_price)
								if self.is_special_price(product):
									sale_price = self.setting_price_rule(price_setting, product.special_price.price)
									product.special_price.price = sale_price
									if self.is_apply_price_rule_only_sale_price() and sale_price < real_product_price:
										product_price = real_product_price
					except Exception:
						log_traceback()
			else:
				product_price = self.setting_price_rule(price_setting, product_price)
				if self.is_special_price(product):
					sale_price = self.setting_price_rule(price_setting, product.special_price.price)
					product.special_price.price = sale_price
					if self.is_apply_price_rule_only_sale_price() and sale_price < real_product_price:
						product_price = real_product_price
		product['price'] = to_decimal(product_price, 2)
		if not category_template and reverb_mapping and isinstance(reverb_mapping, dict) and product.get('product_type'):
			product_type = str(product.get('product_type')).lower()
			product_category = None
			product_category_name = None
			# if reverb_mapping.get('auto_mapping'):
			# 	reverb_category = requests.request(method="get", url="https://api.reverb.com/api/categories/flat")
			# 	if reverb_category.status_code == 200:
			# 		for category in reverb_category.json().get('categories'):
			# 			if product_type == str(category.get('name')).lower():
			# 				product_category = category.get('uuid')
			# 				product_category_name = category.get('full_name')
			# if reverb_mapping.get('custom_rules'):
			# 	for rule in reverb_mapping.get('mapping_value'):
			# 		if product_type == str(rule.get('label')).lower():
			# 			product_category = rule['value'].get('uuid')
			# 			product_category_name = rule['value'].get('full_name')
			for rule in reverb_mapping.get('mapping_value'):
				if product_type == str(rule.get('label')).lower():
					product_category = rule['value'].get('uuid')
					product_category_name = rule['value'].get('full_name')
			if product_category:
				template_data = {
					"category": {
						"category": [
							{
								"uuid": product_category,
								"full_name": product_category_name
							}
						]
					}
				}
				product['template_data'] = template_data
		if isinstance(qty_setting, dict) and to_decimal(qty_setting.get('adjust')):
			qty = to_int(product['qty'])
			if qty_setting.get('locations') and product.locations:
				location_filter = [to_int(location['location_id']) for location in qty_setting['locations']]
				qty = 0
				for location in product.locations:
					if to_int(location.location_id) in location_filter:
						qty += location.qty
			location_qty = qty

			qty = qty * to_decimal(qty_setting['adjust']) / 100
			if qty_setting.get('rounding') == 'round_down':
				qty = math.floor(qty)
			elif qty_setting.get('rounding') == 'round_up':
				qty = math.ceil(qty)
			else:
				qty = round(qty)
			# if 1 > qty > 0:
			# 	qty = 1
			# else:
			# 	qty = round(product['qty'] * to_decimal(qty_setting['adjust']) / 100)
			if not product.is_in_stock:
				qty = 0
			elif not product.manage_stock:
				qty = 999
				if 'no_manage_stock_qty' in qty_setting:
					qty = to_int(qty_setting.get('no_manage_stock_qty'))
			if qty <= 0:
				qty = 0
			# if product.is_in_stock and not qty:
			# 	qty = 1
			if qty_setting['max_qty'] and qty >= qty_setting['max_qty']:
				qty = qty_setting['max_qty']
			if qty_setting['min_qty'] and qty <= qty_setting['min_qty']:
				qty = qty_setting['min_qty']
			if to_int(qty_setting.get('outofstock_threshold')) and location_qty < to_int(qty_setting.get('outofstock_threshold')) and product.manage_stock:
				qty = 0
			product['qty'] = qty
		return product


	# todo: listing
	def _listing_product(self, product, channel_id, template_data, product_channel_default):
		product_channel = copy.deepcopy(product_channel_default)
		special_field = ['sku', 'name']
		product_channel_data_extend = self.get_draft_extend_channel_data(product)
		product_setting = self._apply_channel_setting(copy.deepcopy(product))
		if product_setting['qty'] != product.qty:
			product_channel_data_extend['qty'] = product_setting['qty']
		if product_setting['price'] != product.price:
			product_channel_data_extend['price'] = product_setting['price']
		if product_setting.get('template_data'):
			product_channel_data_extend['template_data']['category']['category'] = product_setting['template_data']['category']['category']
		if product_channel_data_extend:
			product_channel.update(product_channel_data_extend)
		product['channel'][f'channel_{channel_id}'] = copy.deepcopy(product_channel)
		if product.get('variants'):
			for variant in product['variants']:
				variant['channel'][f'channel_{channel_id}'] = copy.deepcopy(product_channel_default)

		product = self.assign_template(product, template_data, False)
		product_channel_product = product.channel[f'channel_{self.get_channel_id()}']
		for field in special_field:
			if not product_channel_product.get(field) and product.get(field):
				product_channel_product[field] = product[field]
		if product.variants:
			parent = copy.deepcopy(product)
			product_qty = 0
			for variant in product.variants:
				variant_channel_data_extend = self.get_draft_extend_channel_data(variant)
				variant_setting = self._apply_channel_setting(copy.deepcopy(variant), parent)
				if variant_setting['qty'] != variant.qty:
					variant_channel_data_extend['qty'] = variant_setting['qty']
				if variant_setting['price'] != variant.price:
					variant_channel_data_extend['price'] = variant_setting['price']
				if not variant.seo_url:
					variant.seo_url = product.seo_url
				variant_channel_product = variant.channel[f'channel_{self.get_channel_id()}']
				for field in special_field:
					if not variant_channel_product.get(field) and variant.get(field):
						variant_channel_product[field] = variant[field]
				if variant_channel_data_extend:
					for row, value in variant_channel_data_extend.items():
						if to_str(value).strip(' /-_'):
							variant_channel_product[row] = value
				variant_qty = variant_channel_product.get('qty') or variant.qty
				product_qty += to_int(variant_qty)
				if product.tracking_inventory == 'variant':
					product_channel_product['qty'] = product_qty
				self.get_model_catalog().update_field(variant['_id'], f"channel.channel_{channel_id}", variant_channel_product)
		self.get_model_catalog().update_field(product['_id'], f"channel.channel_{channel_id}", product_channel_product)


	def _where_title(self, model, title):
		where = [
			model.create_where_condition('name', title, 'like'),
			model.create_where_condition('lower_name', self.product_lower_name(title), 'like'),
		]
		return where


	def where_title(self, model, title_raw):
		split_title_raw = title_raw.split('&&')
		split_title = [re.escape(ele).strip()
		               for ele in split_title_raw if re.escape(ele).strip()]
		title = split_title[0] if split_title else ''

		if to_len(split_title) == 1:
			where = self._where_title(model, title)
			return model.create_where_condition(None, where, 'or')
		where_title_list = []
		for row in split_title:
			where = self._where_title(model, row.strip())
			where_title_list.append(model.create_where_condition(None, where, 'or'))
		return model.create_where_condition(None, where_title_list, 'and')


	def split_sku(self, sku, keep_space = False):
		sku = to_str(sku)
		if not keep_space:
			sku = sku.replace(' ', ',')
		while sku.find(',,') != -1:
			sku = sku.replace(',,', ',')
		return sku.split(',')


	def _where_sku(self, model, sku):
		where = []
		space_in_sku = False
		sku_split = self.split_sku(sku, space_in_sku)
		if to_len(sku_split) > 1:
			where.extend([
				model.create_where_condition(f'sku', sku_split, 'in'),
				model.create_where_condition(f'product_skus', sku_split, 'in'),
				model.create_where_condition(f'sku', sku)
			])
		else:
			sku_contains = model.create_where_condition('sku', sku, 'like1')
			where.extend([
				model.create_where_condition(f'sku', sku, 'like'),
				model.create_where_condition(f'product_skus', [sku_contains['sku']], 'in')
			])
		return where


	def where_sku(self, model, sku):
		where = self._where_sku(model, sku)
		return model.create_where_condition(None, where, 'or')


	def where_tag(self, model_catalog, tags_raw):
		tags = re.escape(tags_raw)
		query = [
			{"tags": tags},  # the product have only one tag
			{"tags": {"$regex": f'{tags},'}},
			{"tags": {"$regex": f'{tags}$'}}  # a tag at the end of line
		]
		return model_catalog.create_where_condition('tags', query, 'or')


	def fields_filter(self):
		return ['mpn', 'bpn', 'ean', 'upc']


	def get_qty_field(self):
		return 'qty'


	def get_price_field(self):
		return 'price'


	def where_instock(self, model_catalog):
		return model_catalog.create_where_condition('is_in_stock', True)


	def where_out_stock(self, model_catalog):
		return model_catalog.create_where_condition('is_in_stock', False)


	def filter_conditions(self, conditions):
		model_catalog = self.get_model_catalog()
		where = dict()
		where[f'channel.channel_{self.get_channel_default_id()}.status'] = 'active'

		min_price = conditions.get('min_price')
		max_price = conditions.get('max_price')
		if min_price and max_price:
			where.update(model_catalog.create_where_condition(self.get_price_field(), (to_decimal(min_price), to_decimal(max_price)), 'range'))
		elif min_price:
			where.update(model_catalog.create_where_condition(self.get_price_field(), to_decimal(min_price), '>='))
		elif max_price:
			where.update(model_catalog.create_where_condition(self.get_price_field(), to_decimal(max_price), '<='))
		min_qty = conditions.get('minQty') or conditions.get('min_qty')
		max_qty = conditions.get('maxQty') or conditions.get('max_qty')
		if to_str(min_qty) and to_str(max_qty):
			where.update(model_catalog.create_where_condition(self.get_qty_field(), (to_int(min_qty), to_int(max_qty)), 'erange'))
		elif to_str(min_qty):
			where.update(model_catalog.create_where_condition(self.get_qty_field(), to_int(min_qty), '>='))
		elif to_str(max_qty):
			where.update(model_catalog.create_where_condition(self.get_qty_field(), to_int(max_qty), '<='))
		if conditions.get('status'):
			invisible = False if conditions.get('status') == 'active' else True
			where.update(model_catalog.create_where_condition('invisible', invisible))
		if conditions.get('product_type'):
			product_type = html_unquote(to_str(conditions.get('product_type')).strip())
			where.update(model_catalog.create_where_condition('product_type', product_type))
		if conditions.get('brands'):
			product_brand = html_unquote(to_str(conditions.get('brands')).strip())
			where.update(model_catalog.create_where_condition('brand', product_brand))
		if conditions.get('tags'):
			tags = html_unquote(to_str(conditions.get('tags')).strip())
			where.update(self.where_tag(model_catalog, tags))
		if conditions.get('product_format'):
			product_format = html_unquote(to_str(conditions.get('product_format')).strip())
			if product_format == 'simple':
				where.update(model_catalog.create_where_condition('variant_count', 0))
			else:
				where.update(model_catalog.create_where_condition('variant_count', 0, '>'))

		if conditions.get('tab') == 'outstock':
			where = model_catalog.create_where_condition(None, [where, self.where_out_stock(model_catalog)], 'and')

		elif conditions.get('tab') == 'instock':
			where = model_catalog.create_where_condition(None, [where, self.where_instock(model_catalog)], 'and')
		where_title_sku = []
		if conditions.get('sku'):
			sku = html_unquote(to_str(conditions.get('sku')).strip())
			where_sku = self.where_sku(model_catalog, sku)
			where_title_sku.append(where_sku)
		if conditions.get('title'):
			name = html_unquote(to_str(conditions.get('title')).strip())
			where_title = self.where_title(model_catalog, name)
			where_title_sku.append(where_title)
		if len(where_title_sku) == 2:
			where_title_sku = model_catalog.create_where_condition(None, where_title_sku, 'and')
		elif len(where_title_sku) == 1:
			where_title_sku = where_title_sku[0]
		if where_title_sku:
			where = model_catalog.create_where_condition(None, [where, where_title_sku], 'and')
		for field in self.fields_filter():
			if conditions.get(field):
				value = html_unquote(to_str(conditions.get(field)).strip())
				where.update(model_catalog.create_where_condition(field, value))

		where.update(model_catalog.create_where_condition('parent_id', False, '='))
		if to_int(conditions.get("in_channel")):
			where.update(model_catalog.create_where_condition(f'channel.channel_{to_int(conditions.get("in_channel"))}.status', ['active', 'draft', 'error'], 'in'))
		if to_int(conditions.get("nin_channel")):
			where.update(model_catalog.create_where_condition(f'channel.channel_{to_int(conditions.get("nin_channel"))}.status', ['active', 'draft', 'error'], 'nin'))
		if conditions.get('category'):
			categories = conditions.get('category').split(',')
			categories = list(set(categories))
			where_categories = model_catalog.create_where_condition(f'category_ids', categories, 'elmMulTiEq')
			where = model_catalog.create_where_condition(None, [where, where_categories], 'and')

		return where


	def pickup_recipes_template(self, templates, product: Product):
		pickup_template_default = False
		for template in templates:
			if template.get('default'):
				pickup_template_default = template
				break

		pickup_template = False
		for template in templates:
			if template.condition and template.condition.conditions:
				all_condition_valid = []

				for condition in template.condition.conditions:
					try:
						all_condition_valid.append(TemplateCondition(condition, product).valid())
					except:
						self.log_traceback()
						all_condition_valid.append(False)
				if template.condition.row_condition == 'and' and all(flag for flag in all_condition_valid):
					return template
				if template.condition.row_condition == 'or' and any(flag for flag in all_condition_valid):
					return template

		if not pickup_template and pickup_template_default:
			return pickup_template_default

		return False


	def listing(self, channel_id, data, wait_process = True):
		product_ids = data.get('product_ids')
		if data.get('select_all'):
			where = self.filter_conditions(data['conditions'])
			total_listing = self.get_model_catalog().count(where)

		else:
			total_listing = to_len(product_ids)

			where = self.get_model_catalog().create_where_condition('_id', product_ids, 'in')

		product_channel_default = ProductChannel()
		product_channel_default.status = ProductChannel.DRAFT
		product_channel_default.channel_id = channel_id
		if not wait_process:
			self.init_process(total_listing, 'listing')
		tem = dict()
		tem.update(self.get_model_template().create_where_condition("channel_id", channel_id, '='))
		list_tem = self.get_model_template().find_all(tem)
		all_template_types = {}
		all_templates_ids = {}
		for template in list_tem:
			all_templates_ids[template['_id']] = template
			if not all_template_types.get(template['type']):
				all_template_types[template['type']] = []
			all_template_types[template['type']].append(template)


		imported = 0
		since_id = ''
		while True:
			if since_id:
				where.update(self.get_model_catalog().create_where_condition('_id', since_id, '>'))
			products = self.get_model_catalog().find_all(where, limit = 100, sort = '_id')
			for index, product in enumerate(products):
				since_id = product['_id']
				channel_data = product['channel'].get(f'channel_{channel_id}')
				if channel_data and channel_data.get('status') in ['draft', 'error', 'active']:
					imported += 1
					self.update_process(imported, total_listing)
					continue
				try:
					product_channel = copy.deepcopy(product_channel_default)
					template_data = {}
					if all_template_types:
						recipes_templates = []
						for template_type, templates in all_template_types.items():
							if template_type == 'recipes':
								recipes_templates = templates
								continue
							# pickup_template_default = False
							# for template in templates:
							# 	if template.get('default'):
							# 		pickup_template_default = template
							# 		break

							pickup_template = False
							# mapping template by conditions
							for template in templates:
								if template.product_types and product.product_type and product.product_type in template.product_types:
									pickup_template = template
									break

								is_template_has_weight_mapping = (template.get(self.SHIPPING_WEIGHT_RANGE)
								                                  and template[self.SHIPPING_WEIGHT_RANGE].get('weight_unit'))
								if is_template_has_weight_mapping:
									if self.mapping_template_width_range(product, template):
										pickup_template = template
										break

							# if not pickup_template and pickup_template_default:
							# 	pickup_template = pickup_template_default

							if not pickup_template:
								continue

							template_data[pickup_template['type']] = pickup_template
						# product_channel.templates[pickup_template.get('type')] = pickup_template.get('_id')
						# product_channel.template_data[pickup_template.get('type')] = self.unset_data_template(pickup_template)
						if recipes_templates:
							pickup_recipes_template = self.pickup_recipes_template(recipes_templates, product)
							if pickup_recipes_template:
								for template_type, template_id in pickup_recipes_template['template'].items():
									template_pick = all_templates_ids.get(template_id)
									if template_data.get(template_type) or not template_pick:
										continue
									template_data[template_type] = template_pick
						for template_type, templates in all_template_types.items():
							for template in templates:
								if template.get('default') and not template_data.get(template_type):
									template_data[template_type] = template
									break
						if template_data:
							for template_type, template in template_data.items():
								product_channel.templates[template_type] = template.get('_id')
								product_channel.template_data[template_type] = self.unset_data_template(template)

					variants = self.get_variants(product, channel_id)
					if variants:
						product['variants'] = variants
					self._listing_product(product, channel_id, template_data, product_channel)
				except Exception:
					self.log_traceback()
				imported += 1
				self.update_process(imported, total_listing)
			if not data.get('select_all') or to_len(products) < 100 or imported >= total_listing:
				break
		self.delete_process()
		# where_update_variant = self.get_model_catalog().create_where_condition('parent_id', product_ids, 'in')
		# self.get_model_catalog().update_many(where_update_variant, {"channel.channel_{}".format(channel_id): product_channel_default.to_dict()})

		return Response().success()


	def mapping_template_width_range(self, product, template) -> bool:
		weight_minimum = to_decimal(template[self.SHIPPING_WEIGHT_RANGE].get('weight_minimum'))
		weight_maximum = to_decimal(template[self.SHIPPING_WEIGHT_RANGE].get('weight_maximum'))
		weight_unit_template = template[self.SHIPPING_WEIGHT_RANGE].get('weight_unit')

		weight_product = self.convert_weight_unit(product.weight, product.weight_units, weight_unit_template)

		if weight_minimum <= weight_product <= weight_maximum:
			return True

		return False


	def listing_product_unlink(self, products, channel_id):
		if not products:
			return []
		product_ids = []
		for product in products:
			product_id = self.clone_product_for_channel(product, channel_id)
			if product_id:
				product_ids.append(product_id)
		return product_ids


	def clone_product_for_channel(self, product, channel_id):
		product_clone = copy.deepcopy(product)
		product_channel_data = product_clone['channel'][f'channel_{channel_id}']
		del product_clone['_id']
		del product_clone['id']
		product_clone['channel'] = {
			f'channel_{channel_id}': product_channel_data
		}
		product_clone_id = self.get_model_catalog().create(product_clone)
		if not product_clone_id:
			return product_clone_id
		variants = self.get_variants(product, channel_id)
		for variant in variants:
			self.clone_variant_for_channel(variant, product_clone_id, channel_id)
		return product_clone_id


	def clone_variant_for_channel(self, variant, product_id, channel_id):
		variant_clone = copy.deepcopy(variant)
		variant_channel_data = variant_clone['channel'][f'channel_{channel_id}']
		del variant_clone['_id']
		del variant_clone['id']
		variant['channel'] = {
			f'channel_{channel_id}': variant_channel_data
		}
		variant['parent_id'] = product_id
		variant_clone_id = self.get_model_catalog().create(variant)
		return variant_clone_id


	def unset_data_template(self, data, unset = ('id', '_id', 'type', 'channel_id')):
		new_data = copy.deepcopy(data)
		for field in unset:
			if field in new_data:
				del new_data[field]
		return new_data


	def is_channel_changed_field(self, product, field):
		return True
		return product[field] == product['channel'][f'channel_{self.get_channel_id()}'].get(field)


	def sync_inventory(self, check_import, data, product: Product, products_ext):
		self.set_new_sync_product_id(False)
		field_check = 'channel_{}'.format(self._state.channel.id)
		if not product or not product['channel'].get(field_check):
			return Response().error(Errors.PRODUCT_DATA_INVALID)
		product_id = product['channel'][field_check].get('product_id')
		if not product_id:
			return Response().error(Errors.PRODUCT_DATA_INVALID)
		msg_error = []
		sync_error = False
		update_channel = {}

		if self.is_setting_sync_qty() or self.is_setting_sync_price():
			channel_sync = self.channel_sync_inventory(product_id, product, products_ext)
			if channel_sync.result != Response.SUCCESS:
				msg = channel_sync.msg or channel_sync.code
				sync_error = True

				if msg and self.get_channel_type() != 'amazon':
					msg_error.append(msg)
			# 	update_data = {
			# 		f'channel.channel_{self.get_channel_id()}.error_message': f"Error while syncing: {msg}",
			# 		f'channel.channel_{self.get_channel_id()}.sync_error': True,
			# 		f'channel.channel_{self.get_channel_id()}.server_error': self.get_server_name(),
			#
			# 	}
			# 	self.get_model_catalog().update(product['_id'], update_data)
			#
			# return channel_sync
			else:
				product = channel_sync.data or product
				qty = product.qty
				price = product.price
				sku = product.sku
				setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
				setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
				setting_sku = True if self._state.channel.config.setting.get('qty', {}).get('sync_sku') == 'enable' else False

				if setting_price:
					if self.is_channel_changed_field(product, 'price'):
						update_channel[f'channel.channel_{self._state.channel.id}.price'] = price
					if product['channel'][f'channel_{self.get_channel_id()}'].get('special_price'):
						update_channel[f'channel.channel_{self._state.channel.id}.special_price'] = product.special_price
				if setting_qty and self.is_channel_changed_field(product, 'qty'):
					update_channel[f'channel.channel_{self._state.channel.id}.qty'] = to_int(qty)
				inventory_api = product['channel'][f'channel_{self.get_channel_id()}'].get('inventory_api')
				if setting_sku and not inventory_api and self.is_channel_changed_field(product, 'sku'):
					update_channel[f'channel.channel_{self._state.channel.id}.sku'] = sku
				if product.variants:
					product_qty = 0
					min_price = 0
					for variant in product.variants:
						variant_update_channel = dict()
						if not variant.sync_error:
							variant_qty = to_int(variant.qty)
						else:
							variant_qty = to_int(variant.channel.get(f'channel_{self.get_channel_id()}', {}).get('qty'))
						product_qty += variant_qty
						variant_price = to_decimal(variant.price, 2)
						if not min_price or min_price > variant_price:
							min_price = variant_price
						if setting_price:
							if variant['channel'][f'channel_{self.get_channel_id()}'].get('special_price'):
								variant_update_channel[f'channel.channel_{self._state.channel.id}.special_price'] = variant.special_price

							if self.is_channel_changed_field(variant, 'price'):
								variant_update_channel[f'channel.channel_{self._state.channel.id}.price'] = variant.price
						if setting_qty and self.is_channel_changed_field(variant, 'qty'):
							variant_update_channel[f'channel.channel_{self._state.channel.id}.qty'] = variant_qty
						if setting_sku and not inventory_api and self.is_channel_changed_field(variant, 'sku'):
							variant_update_channel[f'channel.channel_{self._state.channel.id}.sku'] = variant.sku
						if variant_update_channel:
							self.get_model_catalog().update(variant['_id'], variant_update_channel)
					product['qty'] = product_qty
					product['price'] = min_price

					if setting_qty and product.tracking_inventory != 'product' and self.is_channel_changed_field(product, 'qty'):
						update_channel[f'channel.channel_{self._state.channel.id}.qty'] = product_qty
					if setting_price and self.is_channel_changed_field(product, 'price'):
						update_channel[f'channel.channel_{self._state.channel.id}.price'] = min_price
		new_product_id = self.get_new_sync_product_id()
		if new_product_id:
			product_id = new_product_id
		if self.is_setting_sync_title() or self.is_setting_sync_description():
			sync_title = self.channel_sync_title(product_id, product, products_ext)
			if sync_title.result != Response.SUCCESS:
				msg = sync_title.msg or sync_title.code
				if msg:
					msg_error.append(msg)
				sync_error = True
			else:
				new_product = sync_title.data or product
				if (product.changed_title or new_product.name != product['channel'][f'channel_{self.get_channel_id()}'].get('name')) and self.is_setting_sync_title():
					update_channel[f'channel.channel_{self.get_channel_id()}.name'] = new_product.name
					if not product['channel'][f'channel_{self.get_channel_id()}'].get('bk_name'):
						update_channel[f'channel.channel_{self.get_channel_id()}.bk_name'] = product['channel'][f'channel_{self.get_channel_id()}'].get('name')

				if (product.changed_description or new_product.description != product['channel'][f'channel_{self.get_channel_id()}'].get('description')) and self.is_setting_sync_description():
					update_channel[f'channel.channel_{self.get_channel_id()}.description'] = new_product.description
					if not product['channel'][f'channel_{self.get_channel_id()}'].get('bk_description'):
						update_channel[f'channel.channel_{self.get_channel_id()}.bk_description'] = product['channel'][f'channel_{self.get_channel_id()}'].get('description')
		if not sync_error:
			update_channel[f'channel.channel_{self.get_channel_id()}.server_error'] = ''
			update_channel[f'channel.channel_{self.get_channel_id()}.error_message'] = ''
			update_channel[f'channel.channel_{self.get_channel_id()}.sync_error'] = False
			update_channel[f'channel.channel_{self.get_channel_id()}.publish_status'] = 'completed'
		else:
			update_channel[f'channel.channel_{self.get_channel_id()}.server_error'] = self.get_server_name()
			update_channel[f'channel.channel_{self.get_channel_id()}.error_message'] = f'Error while syncing: \n' + '\n'.join(msg_error)
			update_channel[f'channel.channel_{self.get_channel_id()}.sync_error'] = True
			update_channel[f'channel.channel_{self.get_channel_id()}.publish_status'] = 'completed'
		self.get_model_catalog().update(product['_id'], update_channel)
		if sync_error:
			response = Response().error(msg = '\n'.join(msg_error))
		else:
			response = Response().success()
		return response


	def channel_sync_inventory(self, product_id, product, products_ext):
		return Response().success()


	def channel_sync_title(self, product_id, product, products_ext):
		return Response().success()


	def is_inventory_process(self):
		return self._process_type == self.PROCESS_TYPE_INVENTORY


	def is_refresh_process(self):
		return self._process_type == self.PROCESS_TYPE_REFRESH


	def is_order_process(self):
		return self._process_type == self.PROCESS_TYPE_ORDER


	def is_product_process(self):
		return self._process_type in [self.PROCESS_TYPE_PRODUCT, self.PROCESS_TYPE_REFRESH]


	def is_category_process(self):
		return self._process_type in [self.PROCESS_TYPE_CATEGORY]


	def set_imported_product(self, imported):
		self._state.pull.process.products.imported += imported


	def set_imported_order(self, imported):
		self._state.pull.process.orders.imported += imported


	def set_imported_category(self, imported):
		self._state.pull.process.categories.imported += imported


	def set_imported_tax(self, imported):
		self._state.pull.process.taxes.imported += imported


	def allow_scheduler_pull_order(self):
		return not self._state.channel.default


	def allow_scheduler_pull_product(self):
		return self._state.channel.default and self._state.channel.channel_type in ['magento']


	def is_channel_default(self):
		return self._state.channel.default


	def is_setting_import_order_unlink(self, channel_id):
		settings = self.get_channel_setting(channel_id)
		return settings and settings.get('order') and settings['order'].get('import_order_unlink') == 'enable'


	def get_channel_setting(self, channel_id):
		channel = self.get_channel_by_id(channel_id)
		if channel:
			return json_decode(channel.settings)
		return False


	def get_channel_api(self, channel_id):
		channel = self.get_channel_by_id(channel_id)
		if channel:
			return json_decode(channel.api)
		return False


	def get_channel_by_id(self, channel_id):
		if self._request_data.get('channels') and self._request_data['channels'].get(to_str(channel_id)):
			return Prodict.from_dict(self._request_data['channels'].get(to_str(channel_id)))
		if self._all_channel_by_id.get(channel_id):
			return self._all_channel_by_id[channel_id]
		channel = self.get_model_sync_mode().get_channel_by_id(channel_id)
		if channel:
			self._all_channel_by_id[channel_id] = channel
		return channel


	def is_special_price(self, product: Product):
		special_price = product.special_price
		if not special_price:
			return False
		if not to_decimal(special_price.price, 2) or to_decimal(special_price.price) >= to_decimal(product.price):
			return False
		if not to_timestamp_or_false(special_price.end_date) or not to_timestamp_or_false(special_price.start_date):
			return True
		if to_timestamp_or_false(special_price.start_date) <= time.time() <= to_timestamp_or_false(special_price.end_date):
			return True
		return False


	def channel_url_to_identifier(self, channel_url = None):
		if not channel_url:
			channel_url = self._channel_url
		from urllib.parse import urlparse
		url = urlparse(channel_url)
		identifier = url.netloc.replace('www.', '')
		if url.path:
			identifier += '/' + url.path.strip('/')
		return identifier


	def is_draft(self, product, channel_id):
		if not product['channel'].get(f'channel_{channel_id}'):
			return True
		return product['channel'][f'channel_{channel_id}'].get('status') in ('draft', 'error')


	def get_variants(self, product, channel_id, get_unlink = 0):
		product_id = product['_id']
		src_channel_id = channel_id
		is_remove_variant = product['channel'].get(f'channel_{channel_id}', {}).get('is_remove_variant')

		if self.is_draft(product, channel_id):
			channel_id = self.get_channel_default_id()
			if not product.channel.get(f'channel_{channel_id}', dict()).get('product_id'):
				channel_id = product.src.channel_id
		where = dict()

		where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{channel_id}.status', 'active'))
		if get_unlink:
			where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{get_unlink}.link_status', 'linked', '!='))

		channel = self.get_channel_by_id(channel_id)
		if channel.get('custom_linked_product'):
			where_variant_list = [
				self.get_model_catalog().create_where_condition('is_variant', True),
				self.get_model_catalog().create_where_condition(f'channel.channel_{channel_id}.is_variant', True),
			]
			where_variant = self.get_model_catalog().create_where_condition(None, where_variant_list, 'or')
			where_parent_list = [
				self.get_model_catalog().create_where_condition('parent_id', to_str(product_id)),
				self.get_model_catalog().create_where_condition(f'channel.channel_{channel_id}.parent_id', to_str(product_id)),
			]
			where_parent = self.get_model_catalog().create_where_condition(None, where_parent_list, 'or')
			where_variant_parent = self.get_model_catalog().create_where_condition(None, [where_parent, where_variant], 'and')
			where = self.get_model_catalog().create_where_condition(None, [where, where_variant_parent], 'and')
		else:
			where.update(self.get_model_catalog().create_where_condition('parent_id', product_id))
			where.update(self.get_model_catalog().create_where_condition('is_variant', True))
		if is_remove_variant:
			where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{src_channel_id}.removed', True, '!='))

		variants = self.get_model_catalog().find_all(where)
		if variants:
			variants = list(map(lambda x: Prodict(**x), variants))
		return variants


	def is_valid_variant(self, variant, attributes):
		if not attributes:
			return False
		if not variant.attributes:
			return False
		variant_attribute = dict()
		for attribute in variant.attributes:
			if not attribute.use_variant:
				continue
			variant_attribute[attribute.attribute_name] = attribute.attribute_value_name
		for attribute in attributes:
			if not variant_attribute.get(attribute):
				return False
		return True


	def unset_template_data(self, template_data, unset = ('_id', 'id', 'type', 'name', 'channel_id')):
		result = copy.deepcopy(template_data)
		for field in unset:
			if field in result:
				del result[field]
		return result


	def get_draft_extend_channel_data(self, product):
		return {}


	def add_product_to_draft(self, product_id, product: Product, assign_template = True):
		product_channel_data = ProductChannel()
		product_channel_data.channel_id = self.get_channel_id()
		product_channel_data.status = ProductChannel.DRAFT
		product_channel_data.sku = product.sku
		product_channel_data.name = product.name
		product_channel_data.description = product.description
		product_channel_data_extend = self.get_draft_extend_channel_data(product)
		if product_channel_data_extend:
			product_channel_data.update(product_channel_data_extend)
		where = self.get_model_template().create_where_condition('channel_id', to_int(self.get_channel_id()))
		where.update(self.get_model_template().create_where_condition('default', True))
		templates = self.get_model_template().find_all(where)
		template_data = dict()
		if templates:
			for template in templates:
				template_data[template['type']] = template
				product_channel_data.templates[template['type']] = template['_id']
				product_channel_data.template_data[template['type']] = self.unset_template_data(template)
		product.channel[f'channel_{self.get_channel_id()}'] = product_channel_data
		if assign_template:
			product = self.assign_template(product, template_data, False)
		product_channel_data = product.channel[f'channel_{self.get_channel_id()}']
		self.get_model_catalog().update_field(product_id, f'channel.channel_{self.get_channel_id()}', product_channel_data)
		product = self.apply_channel_setting(product)
		return product


	def get_channel_type(self):
		return self._state.channel.channel_type


	def product_deleted(self, product_id, product: Product = None, channel_id = None):
		if not product:
			product = self.get_model_catalog().get(product_id)
		if not product:
			return True
		product = Prodict(**product)
		if not channel_id:
			channel_id = self.get_channel_id()
		# channel_default_id = self.get_channel_default_id()
		if not product['channel'].get(f'channel_{channel_id}'):
			return
		channel_data = product.get('channel')
		is_delete = True
		update_data = {
			f'channel.channel_{channel_id}': {}
		}

		if channel_data:
			for channel, channel_data in channel_data.items():
				if not channel_data or not channel_data.get('product_id'):
					continue
				key_channel_id = to_str(channel).replace('channel_', '')
				if to_int(key_channel_id) != to_int(channel_id):

					is_delete = False
					if self.is_channel_default():
						if product.is_variant and channel_data.get('link_status') == ProductChannel.LINKED:
							update_data[f'channel.{channel}.qty'] = 0
							update_data[f'channel.{channel}.bk_qty'] = channel_data.get('qty') or product['qty']
						update_data[f'channel.{channel}.link_status'] = ProductChannel.UNLINK
		if is_delete:
			self.get_model_catalog().delete(product_id)
			if product.variant_count > 0:
				self.get_model_catalog().delete_many_document(self.get_model_catalog().create_where_condition('parent_id', product_id))
		else:
			data_log = product['channel'][f'channel_{channel_id}']
			data_log['channel_id'] = channel_id
			data_log['mongo_id'] = product['_id']
			self.log(data_log, 'product_deleted')
			if not product.is_variant:
				variants = self.get_model_catalog().find_all(self.get_model_catalog().create_where_condition('parent_id', product_id))
				for variant in variants:
					self.product_deleted(variant['_id'], variant)

			self.get_model_catalog().update(product_id, update_data)
		return True


	def get_order_start_time(self, time_format = '%Y-%m-%d %H:%M:%S'):
		start_time = to_timestamp(self._state.channel.created_at) if self._state.channel.created_at else time.time()
		start_time = datetime.fromtimestamp(start_time)
		if self._state.channel.config.start_time:
			start_time = self._state.channel.config.start_time
			if to_str(start_time).isnumeric():
				start_time = datetime.fromtimestamp(start_time)
			else:
				start_time = isoformat_to_datetime(start_time)
		if time_format:
			if time_format == 'iso':
				start_time = start_time.astimezone(pytz.UTC)
				iso_format = start_time.isoformat()
				if iso_format.endswith("+00:00"):
					iso_format = iso_format.replace("+00:00", 'Z')
				return iso_format
			return start_time.strftime(time_format)
		return start_time.timestamp()


	def send_email(self, email_to = None, content_mail = None, subject = None, email_from = None):
		content_mail = to_str(content_mail).replace('https://', 'ht_tps://').replace('http://', 'ht_tp://')
		api_key = get_config_ini('sendgrid', 'api_key')
		if not email_from:
			email_from = get_config_ini('sendgrid', 'email_from', 'admin@litcommerce.com')
		if not email_to:
			email_to = get_config_ini('sendgrid', 'email_to', 'admin@litcommerce.com')
		sg = sendgrid.SendGridAPIClient(api_key)
		email_from = Email(email_from)
		email_to = Email(email_to)
		subject = subject if subject else "Title"
		mail_content = Content("text/plain", content_mail)
		send_mail = Mail(email_from, email_to, subject, mail_content)
		try:
			sg.client.mail.send.post(request_body = send_mail.get())
		except Exception:
			self.log_traceback('sendgrid')


	def replace_msg(self, msg):
		if msg:
			msg = msg[0].upper() + msg[1:]
		return msg


	def channel_no_parent(self):
		return []
		return ['google', 'amazon']


	def channel_no_after_push(self):
		return ['amazon', 'walmart', 'walmartcanada']


	def after_update_product(self, product_id, import_data, product: Product):
		if self.is_inventory_process():
			return Response().success(product)

		if self._state.channel.channel_type not in self.channel_no_after_push():
			update_field = dict()
			channel_key = f"channel.channel_{self.get_src_channel_id()}"

			if import_data.result in (Response.ERROR, Response.WARNING):
				if import_data.code and import_data.msg:
					msg = Errors().get_msg_error(import_data.code) + ": " + f"{self.replace_msg(import_data.msg)}"
				elif import_data.code:
					msg = Errors().get_msg_error(import_data.code)
				elif import_data.msg:
					msg = import_data.msg
				else:
					msg = Errors().get_msg_error(Errors.EXCEPTION_IMPORT)
				publish_status = ProductChannel.ERRORS
			else:
				msg = ""
				publish_status = ProductChannel.COMPLETED
				update_field[f"{channel_key}.edited"] = False
				if not self.is_channel_default():
					update_field['updated_time'] = time.time()
			update_field[f"{channel_key}.publish_status"] = publish_status
			update_field[f"{channel_key}.publish_action"] = None
			update_field[f"{channel_key}.error_message"] = msg

			product.channel[channel_key] = self.get_product_channel_data(product, '')
			product.channel[channel_key]['publish_status'] = publish_status
			product.channel[channel_key]['publish_action'] = None
			product.channel[channel_key]['error_message'] = msg
			self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)


	def image_exist(self, url):
		image_process = self.process_image_before_import(url, None)
		return self.url_exist(image_process['url'])


	def url_exist(self, url):
		try:
			exist = requests.get(url, headers = {"User-Agent": get_random_useragent()}, timeout = 5, verify = False)
		except requests.exceptions.Timeout as errt:
			return False
		except Exception as e:
			return False
		return exist.status_code == requests.codes.ok


	def get_current_product(self, product_id):
		return self.get_model_catalog().get(product_id)


	def get_current_order(self, order_id):
		return self.get_model_order().get(order_id)


	def is_run_refresh(self):
		if self._state.run_scheduler:
			return True
		where = self.get_model_catalog().create_where_condition(f"channel.channel_{self.get_channel_default_id()}.product_id", '', '>')
		if self.get_model_catalog().count(where) > 0:
			self.get_model_state().update_field(self.get_state_id(), 'run_scheduler', True)

			if self.is_channel_default() and not self._state.invisible_index:
				self.get_model_catalog().create_index('invisible')
				self._state.invisible_index = True
				self.get_model_state().update_field(self.get_state_id(), 'invisible_index', True)
			return True
		return False


	def is_run_scheduler(self):
		# if time.time() < 1658312100.0 and self._state and self.get_channel_type() == 'etsy':
		# 	return False
		if self._state.run_scheduler:
			return True
		if self.is_order_process() and self.is_setting_import_order_unlink(self.get_channel_id()):
			return True
		where = self.get_model_catalog().create_where_condition(f"channel.channel_{self.get_channel_id()}.product_id", '', '>')
		if self.get_model_catalog().count(where) > 0:
			self.get_model_state().update_field(self.get_state_id(), 'run_scheduler', True)
			return True
		return False


	def product_lower_name(self, product_name):
		product_name = to_str(product_name)
		import string
		chars = re.escape(string.punctuation)
		name = re.sub(r'[' + chars + ']', ' ', product_name)
		while name.find('  ') != -1:
			name = name.replace('  ', ' ')
		return name.lower().strip()


	def variant_key_generate_by_attributes(self, attributes):
		key_generate = list()
		for attribute in attributes:
			if not attribute.use_variant:
				continue

			key_generate.append({"id": html_unescape(to_str(attribute.attribute_name).lower().strip()), 'value': html_unescape(to_str(attribute.attribute_value_name).lower().strip())})
		key_generate = sorted(key_generate, key = lambda d: d['id'])
		base64_generate = list()
		for row in key_generate:
			base64_generate.append(f"{row['id']}:{row['value']}")
		str_generate = string_to_base64('|'.join(base64_generate))
		return str_generate


	def variant_options_to_str(self, attributes):
		key_generate = list()
		for attribute in attributes:
			if not attribute.use_variant:
				continue

			key_generate.append(to_str(attribute.attribute_value_name).lower().strip())
		key_generate = sorted(key_generate)
		str_generate = string_to_base64('|'.join(key_generate))
		return str_generate


	def variant_key_generate(self, variant):

		return self.variant_key_generate_by_attributes(variant.attributes)


	def get_full_name(self, customer):
		first_name = customer.first_name
		last_name = customer.first_name
		full_name = []
		if first_name:
			full_name.append(first_name)
		if last_name:
			full_name.append(last_name)
		return " ".join(full_name)


	def image_content_type_to_mime_type(self, content_type):
		if not content_type:
			return 'PNG'
		mime_types = {
			'image/bmp': 'BMP',
			'image/webp': 'webp',
			'image/tiff': 'tiff',
			'image/svg+xml': 'SVG',
			'image/png': 'PNG',
			'image/jpeg': 'JPEG',
			'image/vnd.microsoft.icon': 'ICO',
			'image/gif': 'GIF',
		}
		return mime_types.get(content_type, 'PNG')


	def strip_html_from_description(self, text):
		if not text:
			return ''
		text = to_str(text).replace('<br>', '\n').replace('</br>', '\n')
		from bs4 import BeautifulSoup
		soup = BeautifulSoup(text, 'lxml')
		return soup.getText().strip()


	def detect_firewall(self, html):
		html = to_str(html)
		if not html:
			return 0
		if (html.find('Performance') >= 0 and html.find('security by') >= 0 and html.find('Cloudflare') >= 0) or (html.find('cloudflare-static/rocket-loader.min.js') >= 0):
			return 'CloudFlare'
		if html.find('wsidchk-form') >= 0:
			return 'Imunify360'

		if html.find('This website is using a security service to protect itself from online attacks') >= 0 and html.find('StackPath') >= 0:
			return 'StackPath'
		if html.find('Sorry, this is not allowed') >= 0 and html.find('getastra.com') >= 0:
			return 'Astra'
		if html.find(
				'R0lGODlhlgAoALMAAPHw8Dw8PNLS06mqqpSVlvRvJvqaZfu2j3V1doSEhuHh4rm6uv3Uv8TFxWVmaP///yH5BAAAAAAALAAAAACWACgAAAT/8MlJKSAuo1XnRdoAdMLQSYojTAlxKgToIIQiLbNbJeBINbkfgnZ68BLFGMI3GSwGuqLUk1k0FhhkBecgDAaJzIoicHA6qcbEoaUMMolv2PxIZZj1DJ0iO0vmDngTIAhFc4ICV1FTUkMVCiZuDiIUCmFqE3ZjlQ6YDwhtEhiUFBh/VZJwFnqcepEVIKGldx2CjEWdjGWvO4GZejacnqAUOH6PI1yhgL43GYtveoUdYbITGM232hSTjI5SXb8NYXhpg6FstwB6PnZ6fnObn2zY8hKxSbTb+w8Y9sJTTKFwYCMDwHttyvw7ge0Mlxjp8swgg+oZtYgdsNniF/BZA0FA/4IVCTmQQ4o25u5FebOxA5CIhzQ+4MJL5iFYGCvI5LhPADY2InG0lEAyD6YyOlJ+avNmH6sHFrlwmCMSasSXx4zknJWN5z4AC0AEK1pE6EBPQEwoJeZsqE4xZXLZIbBu4gSsAADYkYWPoT6vPL+t43VRnKQVuRD+yiolboKbWmlkiATgQIHLmDMbMMDg3tZrfwHzw8HCQeM9Rt/iGLYIxD4ZFp3p8WUgs+3aRAZ9FmVQ9BTGWqlMe5RTaWkV5zgtKoYnmhgqepBYtl2As4SnpxAo0KtAJLbu27f75oZ8wupWHyUAeLPkIM5NbO/OkCfAdavex3NRP1Ah2rDZemDy0/9shIlmCRx91MJMbJwAt44fdpEhwxAaVOVZOMWw80BtmNlS13AAvnNKiMuNBwkBXlhYCRZObATJQg8IsIkTRZSA4gAwljCAhevR+AADmHV2whOkEEnkF2N94YSSMI7n5JNQdsChW1FWaeWV49VmAJZcduklT5bx9+WYZJb5YwFimqnmmlEeICSbcMYp55x01mnnnXjmqeeefPbp55+ABirooGvmReg2VHq1wDENNDleGEWAlaKTF6jIyAKWMhJHP45+hUAAwxQIZQy4EFDCcL516lIA1tyyqQCJarNOAgH4gICoDzQQgG88nKArlxto81itHG1apQq9fhKJTzjm+mn/DZE0esMIzGLSKI6mQCKSAAHsWAkUaHmxwgIjrFdHAw2IsCN7OGKiQFYK7IqhAuh6Ue6OKAbjxUw2nEhurunWoB4U/56oxjqw0nHrA28kEgCsAwTQHbEBLJECwyoAwQEIH/EQL2ERB+BLCgvs0g9BAywx8q661gCAxLvQ64uxa7igazLdllBrvAkk0s2mCn+EolU+53WrAAlgasYuCOcqMdAffeD0dYveAcYDD0vArbKiiJzjHQQkkBcQ64hUdh21/iqBxJ9wgPDZmUg8QrczNcPGyz6UYYQJdJQRQMWfuFA2adeIDQDZ5c0hwgw8DK32ArQymwvbaLfdNWon1EoA4augJJACE59X3sA0L9sQbD8EjL4DKJ2bFhYL2u2qtWn7ghrvCkBYDtWppXD+2O6D0J1sAmqo/bJp3MqeLDEICLgE3fKNgAEAZYzwBVSFQAKVGpuDNRzbe8SLOdwPlK4rB9wKEK8OxEAdb0GFnK5CvGqUXD3DfG/yciSbB6DDOqDiGlT+1z8tEE8UhdifB2jFqmAs4G/NYKALkre5XLWBbbqSnQOI1QTTUKAFXPjbCtb3Nx3sKxchS5kRMIGAEUKwfhCM1aFcVaKyoKpyM/wT3rahukrILod82hyufCWLeI0pAgA7') >= 0 and html.find(
			'Web Site Blocked') >= 0:
			return 'Sonicwall'
		if html.find('_Incapsula_Resource') >= 0:
			return 'Sitelock'
		if html.find('BPS Plugin 403 Error Page') >= 0:
			return 'BPS'
		return 0


	def construct_products_csv_file(self):
		title = "product_id,sku,parent_sku,name,qty,price,description,brand,condition,condition_note,price,msrp,seo_url,manufacturer,mpn,upc,ean,isbn,gtin,gcid,asin,epid,height,length,width,dimension_units,weight,weight_units,variation_1,variation_2,variation_3,variation_4,variation_5,product_image_1,product_image_2,product_image_3,product_image_4,product_image_5,product_image_6,product_image_7,product_image_8,product_image_9,product_image_10"
		return title.split(',')


	def construct_products_csv_bulk_edit(self):
		title = "product_id,sku,parent_sku,name,qty,price,description,brand,height,length,width,dimension_units,weight,weight_units,product_image_1,product_image_2,product_image_3,product_image_4,product_image_5,product_image_6,product_image_7,product_image_8,product_image_9,product_image_10"
		return title.split(',')


	def get_image_limit(self):
		return to_int(self._state.channel.config.limit_image)


	def remove_duplicate_ds(self, url):
		url = url.replace("http://", "http:__")
		url = url.replace("https://", "https:__")
		url = url.replace('//', '/')
		url = url.replace('http:__', 'http://')
		url = url.replace('https:__', 'https://')
		return url


	def is_file_channel(self):
		return self.get_channel_type() == 'file'


	def is_csv_update(self):
		return self.is_file_channel() and self._state.channel.config.api.feed_type == 'update'


	def is_csv_add_new(self):
		return self.is_file_channel() and (self._state.channel.config.api.feed_type == 'add' or self._state.channel.config.api.type == 'add')


	def is_staff_user(self):
		user_info = self.get_user_info()
		return user_info and to_int(user_info.get('group')) == 1


	def update_qty_for_parent(self, parent_id, channel_id = None):
		if not channel_id:
			channel_id = self.get_channel_id()
		parent = self.get_model_catalog().get(parent_id)
		if not parent or parent.tracking_inventory == 'product':
			return
		variants = self.get_variants(parent, channel_id)
		qty = 0
		min_price = 0
		for variant in variants:
			variant_qty = to_int(variant.qty if self.is_channel_default() else variant.channel.get(f'channel_{channel_id}', {}).get('qty', variant.qty))
			variant_price = to_decimal(variant.price if self.is_channel_default() else variant.channel.get(f'channel_{channel_id}', {}).get('price', variant.price))
			qty += variant_qty
			if not min_price or min_price > to_decimal(variant_price):
				min_price = to_decimal(variant_price)
		if channel_id == self.get_channel_default_id():
			update_data = {
				'qty': qty,
				"price": min_price,
				"updated_time": time.time()
			}
		else:
			update_data = {
				f'channel.channel_{self.get_channel_id()}.qty': qty,
				f"channel.channel_{self.get_channel_id()}.price": min_price,
			}
		self.get_model_catalog().update(parent_id, update_data)


	def is_import_inactive(self):
		return self.is_import_product_by_status('inactive')


	def is_import_product_by_status(self, status):
		if self._is_update or self.is_refresh_process():
			return True
		return self._request_data.get('import_all') or self._request_data.get(f'include_{status}') or self._state.pull.process.products.get(f'include_{status}')
		if check:
			return check
		if f'include_{status}' in self._request_data:
			return self._request_data.get(f'include_{status}')
		return True


	def is_difference_image(self, images_1, images_2):
		'''

		@param images_1: List[ProductImage]
		@param images_2: List[ProductImage]
		@return: boolean
		'''
		images_1_list = sorted([row.url for row in images_1])
		images_2_list = sorted([row.url for row in images_2])
		return images_1_list != images_2_list


	def get_order_number_prefix(self):
		number_prefix = self._state.channel.config.api.order_number_prefix or ''
		if not number_prefix and self._state.channel.config.setting.get('order', {}).get('order_number_prefix', ''):
			number_prefix = self._state.channel.config.setting.get('order', {}).get('order_number_prefix', '')
		return number_prefix


	def get_order_number_suffix(self):
		return self._state.channel.config.api.order_number_suffix or ''


	def is_custom_manage_stock(self):
		if not self._state.channel.config.api.manage_stock:
			return None
		return self._state.channel.config.api.manage_stock == 'yes'


	def split_customer_fullname(self, fullname):
		first_name = ''
		last_name = ''
		fullname = to_str(fullname)
		customer_name = fullname.split(" ", 1)
		if len(customer_name) >= 2:
			first_name = customer_name[0]
			last_name = customer_name[1]
		else:
			customer_name = re.sub(r"([A-Z])", r" \1", fullname).split()
			if len(customer_name) >= 2:
				first_name = customer_name[0]
				del customer_name[0]
				last_name = ''.join(customer_name)
		if not first_name:
			first_name = fullname
		if not last_name:
			last_name = fullname
		return first_name, last_name


	def is_setting_sync_qty(self):
		return self._state.channel.config.setting.get('qty', {}).get('status') == 'enable' and not self._state.channel.config.api.skip_sync_inventory


	def is_setting_sync_price(self):
		return self._state.channel.config.setting.get('price', {}).get('status') == 'enable' and not self._state.channel.config.api.skip_sync_price


	def is_setting_use_sale_price(self):
		price_setting = self._state.channel.config.setting.get('price')
		return price_setting and price_setting.get('use_sale_price') == 'enable'


	def is_setting_sync_sku(self):
		return self._state.channel.config.setting.get('qty', {}).get('sync_sku') == 'enable'


	def is_setting_sync_title(self):
		return self._state.channel.config.api.sync_title == 'enable' or (self._state.channel.config.setting.get('other_setting', {}) and self._state.channel.config.setting.get('other_setting', {}).get('sync_title') == 'enable')


	def is_setting_sync_description(self):
		return self._state.channel.config.api.sync_description == 'enable' or (self._state.channel.config.setting.get('other_setting', {}) and self._state.channel.config.setting.get('other_setting', {}).get('sync_description') == 'enable')


	def is_clean_description(self):
		return self._state.channel.config.api.clean_description or (self._state.channel.config.setting.get('other_setting', {}) and self._state.channel.config.setting.get('other_setting', {}).get('clean_description') == 'enable')


	def combination_from_multi_dict(self, data = None):
		if data is None:
			data = dict()
		data = list(data.values())
		result = list(product(*data))
		return result


	def copy_data_from_parent_product(self, parent):
		children_data = ProductVariant()
		no_copy = [
			'languages',
			'options',
			'group_parent_ids',
			'attributes',
			'variants',
			'group_child_ids',
			'relate',
			'seo', 'images', 'image', 'thumb_image', 'status',
			'description',
			'variant_count',
			'is_variant'

		]
		for code, value in parent.items():
			if code not in no_copy:
				children_data[code] = value
		return children_data


	def get_price_children(self, price, addition_price, price_prefix = '+'):
		if price_prefix == '-':
			new_price = to_decimal(price) - to_decimal(addition_price)
			return new_price if new_price > 0 else 0
		else:
			return to_decimal(price) + to_decimal(addition_price)


	def log_for_channel(self, url, method, status_code, file_name = 'request'):
		now_time = datetime.now()
		prefix = f"merchant/{self.get_channel_type()}/{now_time.year}/{now_time.month}/{now_time.day}"
		msg_elm = [
			now_time.strftime('%H:%M:%S'),
			self.get_channel_id(),
			url,
			method,
			status_code
		]

		log_no_date("\t".join(list(map(lambda x: to_str(x), msg_elm))), prefix, file_name)


	def identifier_fields(self):
		return ['ean', 'upc', 'gtin', 'isbn', 'gcid', 'mpn', 'brand', 'asin']


	def get_image_size(self, url):
		try:
			r = requests.get(url, timeout = 60, verify = False)
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			height = img.height
			width = img.width
			return height, width
		except:
			log_traceback(type_error = 'image')
		return 0, 0


	def channel_disconnected(self):
		if not self.get_channel_id():
			return
		channel_data = self.get_channel_by_id(self.get_channel_id())
		if not channel_data.get('email_disconnected'):
			self.get_model_sync_mode().channel_disconnected(self.get_channel_id())


	def is_import_order_without_tax(self):
		return True if self._state.channel.config.setting.get('order', {}).get('without_tax') == 'enable' else False


	def is_notify_order_unlink(self):
		return True if self._state.channel.config.setting.get('order', {}).get('notify_order_unlink') == 'enable' else False


	def notify_order_unlink(self, order_ids):
		api_key = get_config_ini('sendgrid', 'api_key')
		email_from = get_config_ini('sendgrid', 'email_from')
		sg = sendgrid.SendGridAPIClient(api_key)
		email_from = Email(email_from)
		mail_subject = "You have new unlinked orders in LitCommerce"
		file_path = os.path.join(get_root_path(), 'templates', 'email', 'order_unlink.html')
		with open(file_path, 'r') as f:
			content = f.read()
		template = JinjaTemplate(content)
		user_info = self.get_user_info()
		email_to = user_info.get('contact_email') or user_info.get('email')
		email_to = To(email_to)

		extend_data = {
			'user_name': user_info.get('name'),
			'order_ids': order_ids,
			'channel_name': self._state.channel.name,
			'number_order': len(order_ids)
		}
		content_mail = template.render(extend_data).strip()
		mail_content = Content("text/html", content_mail)
		send_mail = Mail(email_from, email_to, mail_subject, mail_content)
		try:
			response = sg.client.mail.send.post(request_body = send_mail.get())
		except Exception:
			self.log_traceback('sendgrid')


	def is_log(self):
		return self._state.channel.config.api.is_log


	def sync_all_order(self):
		date_check = get_current_time('%Y-%m-%d')
		if not self._state.channel.config.api.sync_all_order and self._state.channel.config.date_sync_order == date_check:
			return []
		where = self.get_model_order().create_where_condition('status', [Order.SHIPPING, Order.READY_TO_SHIP, Order.OPEN], 'in')
		where.update(self.get_model_order().create_where_condition(f'channel.channel_{self.get_channel_id()}.order_id', '', '>'))
		orders = self.get_model_order().find_all(where, select_fields = '_id', limit = 200)
		order_ids = [row['_id'] for row in orders]
		if not self._state.channel.config.api.sync_all_order:
			self.get_model_state().update_field(self.get_state_id(), 'channel.config.date_sync_order', date_check)
			self._state.channel.config.date_sync_order = date_check
		return order_ids


	def init_process(self, total = None, process_type = None):
		if self._live_process_id:
			return self._live_process_id
		if self._request_data.get('live_process_id'):
			self._live_process_id = self._request_data.get('live_process_id')
			update = {
				'status': 'running',
			}
			if total:
				update['total'] = total
			self.get_model_process().update(self._live_process_id, update)
			return self._live_process_id
		self._live_process_id = self.get_model_process().create({
			'total': total,
			'status': 'running',
			'channel_id': self.get_channel_id(),
			'imported': 0,
			'error': 0,
			'process_type': process_type,
			'created_at': get_current_time()
		})
		return self._live_process_id


	def update_process(self, imported, total):
		if not self._live_process_id:
			return False
		if total < 0:
			point_update = 10
		elif total <= 20:
			point_update = 5
		elif total <= 40:
			point_update = 10
		else:
			point_update = 15
		if not imported % point_update:
			self.get_model_process().update_field(self._live_process_id, 'imported', imported)
		return self._live_process_id


	def delete_process(self):
		if not self._live_process_id and not self._request_data.get('live_process_id'):
			return False
		process_id = self._live_process_id or self._request_data.get('live_process_id')
		self.get_model_process().delete(process_id)


	def weight_to_kg(self, weight, unit):
		if unit in ['lb', 'lbs']:
			return weight * 0.45359237
		if unit in ['oz']:
			return weight * 0.0283495231
		if unit in ['g', 'gr', 'gram', 'grams']:
			return weight * 0.001
		if unit in ['tonnes', 't']:
			return weight * 1000
		return weight


	def weight_kg_to_unit(self, weight, unit):
		unit = unit.lower()
		if unit in ['lb', 'lbs']:
			return weight * 2.20462262
		if unit in ['oz']:
			return weight * 35.2739619
		if unit in ['g', 'gr', 'gram', 'grams']:
			return weight * 1000
		if unit in ['tonnes', 't']:
			return weight * 0.001
		return weight


	def convert_weight_unit(self, weight, unit, new_unit = 'lb'):
		weight = to_decimal(weight, 4)
		if not weight:
			return 0
		weight_kg = self.weight_to_kg(weight, unit)
		weight_to_unit = self.weight_kg_to_unit(weight_kg, new_unit)
		return to_decimal(weight_to_unit, 4)


	def dimension_to_inch(self, dimension, unit):
		if unit in ['m', 'met', 'meter']:
			return dimension * 39.3700787
		if unit in ['cm']:
			return dimension * 0.393700787
		if unit in ['mm']:
			return dimension * 0.0393700787
		if unit in ['foot', 'feet', 'ft']:
			return dimension * 12
		if unit in ['foot', 'feet', 'ft']:
			return dimension * 12
		if unit in ['yards', 'yard', 'yd']:
			return dimension * 36
		return dimension


	def dimension_inch_to_unit(self, dimension, unit):
		if unit in ['m', 'met', 'meter']:
			return dimension * 0.0254
		if unit in ['cm']:
			return dimension * 2.54
		if unit in ['mm']:
			return dimension * 25.4
		if unit in ['foot', 'feet', 'ft']:
			return dimension * 0.0833333333
		if unit in ['yards', 'yard', 'yd']:
			return dimension * 0.0277777778
		return dimension


	def convert_dimension_unit(self, dimension, unit, new_unit = 'in'):
		dimension = to_decimal(dimension, 4)
		if not dimension:
			return 0
		dimension_inch = self.dimension_to_inch(dimension, unit)
		dimension_to_unit = self.dimension_inch_to_unit(dimension_inch, new_unit)
		return to_decimal(dimension_to_unit, 4)


	def is_keep_product_active(self):
		return self._state.channel.config.setting.get('qty', {}).get('keep_active') == 'enable'


	def is_sync_product_invisible(self, product):
		return product.invisible and self.is_setting_sync_qty() and not self.is_keep_product_active()


	def iso_format_datetime_to_format(self, timedata, new_format = "%Y-%m-%d %H:%M:%S"):
		time_obj = isoformat_to_datetime(timedata)
		return time_obj.strftime(new_format)


	def is_auto_import_new_product(self):
		return self.get_channel_type() == 'file' or self._state.channel.config.setting.auto_import_product


	def skip_import_inactive_product(self):
		return self.is_refresh_process() and (self._state.channel.config.api.skip_inactive_product or self._state.channel.config.setting.skip_inactive_product)


	def action_assign_template(self, data):
		channel_id = data['channel_id']
		template_type = data['template_type']
		template_id = data['template_id']
		listing_ids = data['listing_ids']
		template_type_ids = dict()
		template_update = dict()
		is_update_variant = False
		self.init_process()
		if template_type == 'recipes':
			template_recipes = self.get_model_template().get(template_id)
			if not template_recipes:
				return False
			for recipe_type, recipe_value in template_recipes['template'].items():
				if self.need_apply_template_for_variants(recipe_type):
					is_update_variant = True
				if recipe_value:
					template_type_ids[recipe_type] = recipe_value
			template_type_ids["recipes"] = template_id
			template_update[f"channel.channel_{channel_id}.templates"] = template_type_ids
		# self._model_product.update_many(self._model_product.create_where_condition('_id', listing_ids, 'in'), {f"channel.channel_{kwargs['channel_id']}.templates": template_recipes['template']})
		else:
			if self.need_apply_template_for_variants(template_type):
				is_update_variant = True
			template_type_ids[template_type] = template_id
			template_update[f"channel.channel_{channel_id}.templates.{template_type}"] = template_id
		self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', listing_ids, 'in'), template_update)
		products = self.get_model_catalog().find_all(self.get_model_catalog().create_where_condition('_id', listing_ids, 'in'))
		total = len(products)
		template_ids = list(template_type_ids.values())
		templates = self.get_model_template().find_all(self.get_model_template().create_where_condition('_id', template_ids, 'in'))
		template_data = dict()
		if templates:
			for template in templates:
				template_data[template['type']] = template
		current_product_channel_data = dict()
		current_variant_channel_data = dict()
		imported = 0
		for product in products:
			current_product_channel_data[product['_id']] = copy.deepcopy(product["channel"][f"channel_{channel_id}"])
			if not product["channel"][f"channel_{channel_id}"].get('template_data'):
				product["channel"][f"channel_{channel_id}"]['template_data'] = dict()
			try:
				for template in templates:
					template_type = template['type']
					update_template = self.unset_template_data(template)
					update_template_ids = list()
					product["channel"][f"channel_{channel_id}"]['template_data'][template_type] = update_template
					variants = self.get_variants(product, channel_id)
					if variants:
						for variant in variants:
							current_variant_channel_data[variant['_id']] = copy.deepcopy(variant["channel"][f"channel_{channel_id}"])

						product['variants'] = variants
					product = self.assign_template(product, template_data, update = False, pickup_template_type = template_type)
				channel_data = product["channel"][f"channel_{channel_id}"]
				current_channel_data = current_product_channel_data[product['_id']]
				update_product_data = {}
				for update_key, update_value in channel_data.items():
					if update_value != current_channel_data.get(update_key):
						update_product_data[f'channel.channel_{channel_id}.{update_key}'] = update_value
				if update_product_data:
					self.get_model_catalog().update(product['_id'], update_product_data)
				if product.get('variants') and is_update_variant:
					for variant in product['variants']:
						variant_channel_data = variant["channel"][f"channel_{channel_id}"]
						old_variant_channel_data = current_variant_channel_data[variant['_id']]
						update_variant_data = {}
						for update_key, update_value in variant_channel_data.items():
							if update_value != old_variant_channel_data.get(update_key):
								update_variant_data[f'channel.channel_{channel_id}.{update_key}'] = update_value
						if update_variant_data:
							self.get_model_catalog().update(variant['_id'], update_variant_data)

			except:
				self.log_traceback()
			imported += 1
			self.update_process(imported, total)
		self.delete_process()


	def need_apply_template_for_variants(self, template_type):
		return template_type in ['price', 'amz_product_type', 'amz_details', 'recipes'] or (template_type in ['title', 'category'] and self.get_channel_type() in ['reverb', 'facebook', 'google'])


	def delete_price_template(self, data):
		where = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.templates.price', data['template_id'])
		where.update(self.get_model_catalog().create_where_condition('is_variant', False))
		where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.product_id', '', '>'))
		products = self.get_model_catalog().find_all(where, select_fields = '_id')
		for product in products:
			self.get_model_catalog().update_field(product['_id'], 'updated_time', time.time())
			time.sleep(0.1)
		where_update = dict()
		where_update.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.templates.price', data['template_id']))
		self.get_model_catalog().update_many(where_update, {
			f'channel.channel_{self.get_channel_id()}.templates.price': '',
		})


	def title_cutting(self, title, max_char):
		product_name_cut = title.split(' ')
		new_product_name = ''
		for name in product_name_cut:
			if to_len(new_product_name) + to_len(name) > max_char:
				break
			new_product_name += f' {name}'
		new_product_name = new_product_name.strip(', ')
		return new_product_name


	def finish_refresh_process(self):
		return Response().success()


	def user_is_europe(self):
		user_info = self.get_user_info()
		country = user_info.get('country')
		if not country:
			country = 'US'
		from countryinfo import CountryInfo
		country_info = CountryInfo(country)
		return country_info.region() == 'Europe'


	def upload_image(self, url, destination_image, force = False):
		if not force:
			return self.get_storage_image_service().upload_file_from_url(url, destination_image)
		return self.get_storage_image_service().force_upload_file_from_url(url, destination_image)

	def get_storage_service(self):
		if self._storage_service:
			return self._storage_service
		self._storage_service = FileStorageGoogle()
		return self._storage_service


	def get_storage_image_service(self):
		if self._storage_image_service:
			return self._storage_image_service
		self._storage_image_service = ImageStorageGoogle()
		return self._storage_image_service


	def get_prefix_storage(self):
		prefix = to_str(self._user_id) if self._user_id else 'undefined'
		mode = get_config_ini('local', 'mode')
		if mode == 'live':
			prefix = 'production/' + prefix
		else:
			prefix = 'test/' + prefix
		return prefix


	def create_destination_product_image(self, product_id, image_url):
		image_url_parse = urllib.parse.urlparse(image_url)
		image_name = image_url_parse.path
		if not product_id:
			product_id = to_str(to_int(time.time()))
		random_id = to_str(uuid.uuid4())
		mimetype_image = to_str(image_name).split('.')[-1]
		prefix = self.get_prefix_storage()
		return prefix + "/" + to_str(product_id) + "/" + random_id + "." + mimetype_image
