import io
from urllib.request import Request, urlopen

import requests
from PIL import Image
from PIL import ImageFile

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.product import Product


class ModelChannelsSample(ModelChannel):
	def __init__(self):
		super().__init__()


	def get_api_info(self):
		"""

		:rtype: dict
		"""
		return {
			'password': "API Password",
			'shop': 'Shop'
		}


	def display_setup_channel(self, data = None):
		"""
		Check api information
		:param data:
		:return: _response

		"""
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		shop = self.api('shop.json')
		if not shop:
			return Response().error(Errors.SHOPIFY_API_INVALID)
		try:
			if shop.errors:
				return Response().error(Errors.SHOPIFY_API_INVALID)

		except Exception as e:
			return Response().error(Errors.SHOPIFY_API_INVALID)
		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()


	def set_channel_identifier(self):
		"""
		in api info there will be 1 information that is unique to a channel.
		
		:return:
		"""
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self._state.channel.config.api.shop)
		return Response().success()


	def display_pull_channel(self):
		"""
		Count all entity in channel
		:return: 
		"""
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		return Response().success()


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		return next_clear


	def get_products_main_export(self):
		"""

		:rtype: object
		"""
		return Response().success()


	def get_products_ext_export(self, products):
		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def _convert_product_export(self, product, products_ext: Prodict):
		return Response().success()


	def product_import(self, convert: Product, product, products_ext):
		images = list()
		main_image = None
		if not product.name:
			return response_error('import product ' + to_str(convert['id']) + ' false.')
		# main_image = None
		# if convert['thumb_image']['url']:
		# 	main_image = self.process_image_before_import(convert['thumb_image']['url'], convert['thumb_image']['path'])
		# 	images.append({'src': main_image['url']})
		# for img_src in convert['images']:
		# 	image_process = self.process_image_before_import(img_src['url'], img_src['path'])
		# 	images.append({'src': image_process['url']})
		# Resize Image
		if product.thumb_image.url:
			main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			image_data = self.resize_image(main_image['url'])
			if image_data:
				images.append(image_data)
			else:
				images.append({'src': main_image['url']})
		for img_src in product.images:
			if 'status' in img_src and not img_src['status']:
				continue
			image_process = self.process_image_before_import(img_src['url'], img_src['path'])
			image_data = self.resize_image(image_process['url'])
			if image_data:
				images.append(image_data)
			else:
				images.append({'src': image_process['url']})
		name = to_str(product.name).replace('/', '-')
		post_data = {
			'product': {
				'title': name[0:255],
				'body_html': product.description if product.description else product.short_description,
				'vendor': product.manufacturer.name,
				'product_type': '',
				'images': images,
				'created_at': product.created_at,
				'updated_at': product.updated_at
			}
		}

		if not product.status:
			post_data['product']["published"] = False
			post_data['product']['published_at'] = None

		if product.meta_description or product.meta_title:
			post_data['product']['metafields_global_title_tag'] = product.meta_title
			post_data['product']['metafields_global_description_tag'] = product.meta_description
		metafields_keys = list()
		post_data['product']['metafields'] = list()
		special_attribute = ('description', 'short description')
		if product.attributes:
			for attribute in product.attributes:
				if to_str(attribute.option_name) == special_attribute or not attribute.option_name:
					continue
				option_name = self.name_to_code(attribute.option_name)
				index = 2
				while option_name in metafields_keys:
					option_name = attribute.option_name + ' ' + to_str(index) + 'nd'
					index += 1
				metafields_keys.append(option_name)
				if (hasattr(attribute, 'is_visible') and not attribute.is_visible) or to_len(option_name) < 3:
					continue
				metafield = {
					'key': option_name[:30],
					'value': attribute.option_value_name,
					'value_type': 'string',
					'namespace': 'global'
				}
				post_data['product']['metafields'].append(metafield)
		# add metafield Dimensions
		dimensions = ('length', 'width', 'height', 'weight')
		for dimension in dimensions:
			if to_decimal(product.get_attribute(dimension)):
				metafield = {
					'key': dimension,
					'value': to_str(to_decimal(product.get_attribute(dimension))),
					'value_type': 'string',
					'namespace': 'global'
				}
				post_data['product']['metafields'].append(metafield)
		if not product.description and product.short_description:
			option_name = 'short_description'
			index = 2
			while option_name in metafields_keys:
				option_name = 'short_description' + ' ' + to_str(index) + 'nd'
				index += 1
			metafields_keys.append(option_name)
			metafield = {
				'key': option_name[:30],
				'value': product.short_description,
				'value_type': 'string',
				'namespace': 'global'
			}
			post_data['product']['metafields'].append(metafield)
		tags = to_str(product['tags']).split(',')
		# if self._state['config'].get('smart_collection'):
		# 	for category in convert['categories']:
		# 		category_name = self.get_map_field_by_src(self.TYPE_CATEGORY, category['id'], category['code'], 'code_desc')
		# 		if not category_name:
		# 			continue
		# 		tags.append(category_name)
		if tags:
			tags = ','.join(tags)
			post_data['product']['tags'] = tags
		response = self.api('products.json', post_data, 'Post')
		check_response = self.check_response_import(response, product, 'product')
		if check_response.result != Response.SUCCESS:
			if 'Image' in check_response['msg']:
				del post_data['product']['images']
				response = self.api('products.json', post_data, 'Post')
				response = json_decode(response)
				check_response = self.check_response_import(response, convert, 'product')
				if check_response['result'] != 'success':
					return check_response
			else:
				return check_response

		product_id = response['product']['id']
		handle = response['product'].get('handle')
		return Response().success(product_id)


	# if self._state['config']['img_des'] and post_data['product']['body_html']:
	# 	theme_data = self.get_theme_data()
	# 	if theme_data:
	# 		check = False
	# 		description = post_data['product']['body_html']
	# 		match = re.findall(r"<img[^>]+>", to_str(description))
	# 		links = list()
	# 		if match:
	# 			for img in match:
	# 				img_src = re.findall(r"(src=[\"'](.*?)[\"'])", to_str(img))
	# 				if not img_src:
	# 					continue
	# 				img_src = img_src[0]
	# 				if img_src[1] in links:
	# 					continue
	# 				links.append(img_src[1])
	# 		for link in links:
	# 			# download and replace
	# 			if self._state['src']['config'].get('auth'):
	# 				link = self.join_url_auth(link)
	# 			if to_int(theme_data['count']) >= 1500:
	# 				theme_data = self.get_theme_data(True)
	# 			if not theme_data:
	# 				break
	# 			if not self.image_exist(link):
	# 				continue
	# 			asset_post = self.process_assets_before_import(url_image = link, path = '', id_theme = theme_data['id'], name_image = convert['code'])
	# 			asset_post = json_decode(asset_post)
	# 			if asset_post and asset_post.get('asset'):
	# 				self.update_theme_data(theme_data['count'])
	# 				check = True
	# 				description = to_str(description).replace(link, asset_post['asset']['public_url'])
	# 		if check:
	# 			product_update = {
	# 				'product': {
	# 					'body_html': description
	# 				}
	# 			}
	# 			res = self.api('products/' + to_str(product_id) + '.json', product_update, 'PUT')

	def get_sizes(self, url):
		req = Request(url, headers = {'User-Agent': get_random_useragent()})
		try:
			file = urlopen(req)
		except:
			self.log('image: ' + to_str(url) + ' 404', 'image_error')
			return False, False
		size = file.headers.get("content-length")
		# date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
		# type = file.headers.get('content-type')
		if size: size = to_int(size)
		p = ImageFile.Parser()
		while 1:
			data = file.read(1024)
			if not data:
				break
			p.feed(data)
			if p.image:
				return size, p.image.size
				break
		file.close()
		return size, False


	def resize_image(self, url):
		url_resize_image = url
		name = os.path.basename(url)
		result = dict()
		result['filename'] = name
		result['attachment'] = ''
		try:
			image_size, wh = self.get_sizes(url)
			w = 4000
			h = 4000
			if wh:
				w = wh[0]
				h = wh[1]
				if to_decimal(to_decimal(w) * to_decimal(h), 2) > to_decimal(4000 * 4000, 2):
					if to_decimal(w) > to_decimal(h):
						h = 4000 * h / w
						w = 4000
					else:
						w = 4000 * w / h
						h = 4000
				else:
					return None
			time.sleep(0.4)
			r = requests.get(url)
			if r.status_code != 200:
				return result
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			new_width = to_int(w)
			new_height = to_int(h)
			img = img.resize((new_width, new_height), Image.ANTIALIAS)
			output = io.BytesIO()
			if img.mode != 'RGB':
				img = img.convert('RGB')
			img.save(output, format = 'JPEG')
			im_data = output.getvalue()
			image_data = base64.b64encode(im_data)
			if not isinstance(image_data, str):
				# Python 3, decode from bytes to string
				image_data = image_data.decode()
				result['attachment'] = image_data
				return result
		except:
			self.log(url, 'url_fail')
			self.log_traceback("url_fail")
		return None


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors, "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()
