import copy
import io
import time
import uuid
from urllib.request import Request, urlopen

import requests
from PIL import Image
from PIL import ImageFile

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.tracking_company import TrackingCompany
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory, OrderAddress
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute
from datasync.models.constructs.state import EntityProcess


class ModelChannelsSquarespace(ModelChannel):
	FORMAT_DATE = "%Y-%m-%dT%H:%M:%S.000Z"
	ORDER_STATUS = {
		"pending": Order.OPEN,
		"partially_refunded": Order.OPEN,
		"authorized": Order.AWAITING_PAYMENT,
		"partially_paid": Order.SHIPPING,
		"paid": Order.COMPLETED,
		"voided": Order.CANCELED,
		"refunded": Order.REFUNDED,
	}


	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = "1.0"
		self._product_next_cursor = ""
		self._flag_finish_product = False
		self._flag_finish_order = False
		self._store_page_id = False
		self._last_product = False
		self._all_store_page = dict()


	def get_api_info(self):
		return {
			'site_id': "Site Id",
			'account_id': 'Account Id',
			'refresh_token': 'Refresh Token',
			'access_token': 'Access Token',
		}


	# api code

	def get_version_api(self):
		return self._version_api


	def get_access_token(self):
		return self._state.channel.config.api.access_token


	def post(self, path, data = None):
		return self.api(path, data, 'post')


	def delete(self, path):
		return self.api(path, method = 'delete')


	def commerce_api(self, path, data = None, method = 'get', **kwargs):
		path = f"commerce/{to_str(path).strip('/')}"
		return self.api(path, data, method, **kwargs)


	def post_commerce(self, path, data = None, **kwargs):
		return self.commerce_api(path, data, 'post', **kwargs)


	def delete_commerce(self, path):
		return self.commerce_api(path, method = 'delete')


	def api(self, path, data = None, method = "get", **kwargs):
		url = f"https://api.squarespace.com/{self._version_api}/{to_str(path).strip('/')}"
		header = {
			"Content-Type": "application/json",
			"User-Agent": get_random_useragent(),
			"Authorization": f"Bearer {self.get_access_token()}"
		}
		if kwargs.get('idempotency_key'):

			header['Idempotency-Key'] = to_str(uuid.uuid4())
		res = self.requests(url, data, method = method, headers = header, **kwargs)
		res_json = json_decode(res)
		if res_json:
			res_json = Prodict.from_dict(res_json)
		return res_json


	def get_client_id(self):
		client_id = self._state.channel.config.api.client_id
		if not client_id:
			return get_config_ini('squarespace', 'client_id')
		return client_id


	def get_client_secret(self):
		client_id = self._state.channel.config.api.client_secret
		if not client_id:
			return get_config_ini('squarespace', 'client_secret')
		return client_id


	def display_push_channel(self, data = None):
		if data.get('store_page_id'):
			self._store_page_id = data['store_page_id']
		return Response().success()


	def refresh_access_token(self):
		data = {
			"grant_type": "refresh_token",
			"refresh_token": self._state.channel.config.api.refresh_token
		}
		headers = {
			'Content-Type': 'application/json',
			'User-Agent': get_random_useragent(),
			'Authorization': f"Basic {string_to_base64(f'{self.get_client_id()}:{self.get_client_secret()}')}"
		}
		refresh = requests.post("https://login.squarespace.com/api/1/login/oauth/provider/tokens", json = data, headers = headers)
		if refresh.status_code != 200:
			self.channel_disconnected()
			return False
		token = refresh.json()
		self._state.channel.config.api.access_token = token['access_token']
		self._state.channel.config.api.refresh_token = token['refresh_token']
		self._state.channel.config.api.access_token_expires_at = token['access_token_expires_at']
		self._state.channel.config.api.refresh_token_expires_at = token['refresh_token_expires_at']
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return token['access_token']


	def requests(self, url, data = None, headers = None, method = 'get', retry = 0, **kwargs):
		real_header = copy.deepcopy(headers)
		access_token_expires_at = self._state.channel.config.api.access_token_expires_at
		if access_token_expires_at - time.time() < 10:
			token = self.refresh_access_token()
			if not token:
				return False
			headers['Authorization'] = f"Bearer {self.get_access_token()}"

		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if kwargs.get('files'):
			request_options['files'] = kwargs['files']
			del request_options['headers']['Content-Type']
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)

		try:
			time.sleep(0.1)
			response = requests.request(method, url, **request_options)


			def log_request_error():
				error = {
					'method': method,
					'status': response.status_code,
					'data': to_str(data),
					'header': to_str(response.headers),
					'response': response.text,
				}
				self.log_request_error(url, **error)


			if response.status_code > 204 or self.is_log():
				log_request_error()
			response_data = response.text

			self._last_header = response.headers
			self._last_status = response.status_code
			if response.status_code in [401, 403]:
				refresh = False
				if response.status_code == 401:
					refresh = True
				if response.status_code == 403 and not retry:
					response_json = response.json()
					if response_json.get('type') == 'AUTHORIZATION_ERROR':
						refresh = True
				if not refresh:
					return response_data
				token = self.refresh_access_token()
				if not token:
					self.channel_disconnected()
					self.set_action_stop(True)
					return response
				headers['Authorization'] = f"Bearer {self.get_access_token()}"
				retry += 1
				return self.requests(url, data, headers, method, retry = retry)
			if response.status_code == 429 and retry <= 20:
				retry += 1
				time.sleep(retry * 1)
				self.log(f'sleep {retry}')
				return self.requests(url, data, headers, method, retry = retry)
		except Exception as e:
			self.log_traceback()
			response_data = False
		return response_data


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		shop = self.get_shop_info()
		if not shop:
			return Response().error(Errors.SQUARESPACE_API_INVALID)
		self._state.channel.config.currency = shop.currency
		return Response().success()


	def get_shop_info(self):
		shop = self.api('authorization/website')
		return shop


	def get_currency(self):
		if self._state.channel.config.currency:
			return self._state.channel.config.currency
		shop = self.get_shop_info()
		if not shop:
			self._state.channel.config.currency = 'USD'
		else:
			self._state.channel.config.currency = shop.currency
		return self._state.channel.config.currency


	def get_measurement_standard(self):
		shop_info = self.get_shop_info()
		if not shop_info:
			return 'IMPERIAL'
		return shop_info.measurementStandard


	def get_weight_unit(self):
		if self.get_measurement_standard() == 'IMPERIAL':
			return 'POUND'
		return 'KILOGRAM'


	def get_dimension_unit(self):
		if self.get_measurement_standard() == 'IMPERIAL':
			return 'INCH'
		return 'CENTIMETER'


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self._state.channel.config.api.site_id)
		return Response().success()


	def after_create_channel(self, data):
		if is_local() or not self.is_channel_default():
			return Response().success()

		# webhook_data = {
		# 	"topics": ['order.update'],
		# 	"endpointUrl": get_api_server_url(f'merchant/squarespace/webhook/{data.channel_id}/order/update'),
		# }
		# webhook = self.post('webhook_subscriptions', webhook_data)
		# if self._last_status == 201:
		# 	self._state.channel.config.api[f"secret_webhook"] = webhook['secret']
		# 	self.update_channel(api = json_encode(self._state.channel.config.api))
		return Response().success()


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			params = {}
			if self.is_refresh_process():
				self.refresh_access_token()
				last_modified = self.get_max_last_modified_product()
				if last_modified:
					params['modifiedAfter'] = last_modified
					params['modifiedBefore'] = get_current_time(self.FORMAT_DATE)
			products = self.commerce_api('products', params)
			self._state.pull.process.products = EntityProcess()
			if products and products.products:
				self._state.pull.process.products.total = -1

		if self.is_order_process():
			self._state.pull.process.orders = EntityProcess()
			start_time = self.get_order_start_time(self.FORMAT_DATE)
			last_modifier = self._state.pull.process.orders.max_last_modified
			if not last_modifier:
				last_modifier = start_time
			params = {
			}
			if last_modifier:
				params['modifiedAfter'] = last_modifier
				params['modifiedBefore'] = get_current_time(self.FORMAT_DATE)
				self.set_order_max_last_modifier(last_modifier)
			orders_api = self.commerce_api('orders', data = params)
			if orders_api and orders_api.result:
				self._state.pull.process.orders.total = -1
		return Response().success()


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, self.FORMAT_DATE) > to_timestamp(self._order_max_last_modified, self.FORMAT_DATE)):
			self._order_max_last_modified = last_modifier


	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		try:
			all_collections = self.api('custom_collections.json?limit=100')
			while all_collections:
				if not all_collections.custom_collections:
					break
				for collect in all_collections.custom_collections:
					id_collect = collect.id
					res = self.api('custom_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('custom_collections.json?limit=100')
				time.sleep(0.1)
			all_collections = self.api('smart_collections.json?limit=100')

			while all_collections:
				if not all_collections:
					return next_clear
				if not all_collections.smart_collections:
					return next_clear
				for collect in all_collections.smart_collections:
					id_collect = collect.id
					res = self.api('smart_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('smart_collections.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			all_products = self.api('products.json?limit=100')
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.products:
					return next_clear
				for product in all_products.products:
					id_product = product.id
					res = self.api('products/{}.json'.format(id_product), None, 'Delete')
				all_products = self.api('products.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_collection_type(self):
		if self._collection_type:
			return self._collection_type
		self._collection_type = self.CUSTOM_COLLECTION
		return self._collection_type


	def set_collection_type(self, collection_type):
		self._collection_type = collection_type


	def get_categories_main_export(self):
		collection_type = self.get_collection_type()
		limit_data = self._state.pull.setting.categories
		categories_data = list()
		if collection_type == self.CUSTOM_COLLECTION:
			id_src = self._state.pull.process.categories.id_src
			collections = self.api('custom_collections.json', data = {'since_id': id_src, 'limit': limit_data})
			if not collections:
				return Response().error()
			# if 'custom_collections' in categories_page and not categories_page['custom_collections']:
			# 	return create_response('pass')
			categories_data = collections.get('custom_collections')
			if not categories_data:
				collection_type = self.CUSTOM_COLLECTION
		if collection_type == self.SMART_COLLECTION:
			id_src = self._state.pull.process.categories.id_src_smart
			if not id_src:
				id_src = 0
			collections = self.api('smart_collections.json', data = {'since_id': id_src, 'limit': limit_data})
			if not collections:
				return Response().error()

			if not collections.get('smart_collections'):
				return Response().skip()
			categories_data = collections['smart_collections']
		return Response().success(categories_data)


	def get_categories_ext_export(self, categories):
		extend = dict()
		for category in categories:
			category_id = to_str(category.id)
			extend[category_id] = dict()
			meta = False
			if 'rules' in category:
				meta = self.api('smart_collections/{}/metafields.json'.format(category_id))
			else:
				meta = self.api('custom_collections/{}/metafields.json'.format(category_id))
			if meta:
				extend[category_id]['meta'] = meta.get('metafields')
		return Response().success(extend)


	def convert_category_export(self, category, categories_ext):
		category_data = CatalogCategory()
		category_id = to_str(category['id'])
		parent = CatalogCategory()
		category_data.parent = parent
		category_data.id = category.id
		category_data.active = True if category.published_at else False
		if category.image and category.image.src:
			real_path = re.sub("/\?.+/", "", category.image.src)
			real_path = real_path[:real_path.find('?')]
			category_data['thumb_image']['url'] = real_path
			category_data['thumb_image']['path'] = ''
		category_data.name = category.title
		category_data.description = category.body_html
		category_data['created_at'] = convert_format_time(category.published_at, self.FORMAT_DATETIME)
		category_data['updated_at'] = convert_format_time(category.updated_at, self.FORMAT_DATETIME)
		category_data.seo_url = "https://{}.mysquarespace.com/collections/{}".format(self._state.channel.config.api.shop,
		                                                                             category.handle)
		if 'meta' in categories_ext[category_id] and categories_ext[category_id]['meta']:
			for metafields in categories_ext[category_id]['meta']:
				if metafields['key'] == 'description_tag':
					category_data.meta_description = metafields['value']
				elif metafields['key'] == 'title_tag':
					category_data.meta_title = metafields['value']
		return Response().success(category_data)


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		if not category.name:
			return response_error('import category ' + to_str(category.id) + ' false.')
		post_data = {
			'smart_collection': {
				'title': category.name,
				'body_html': category.description,
				'published_scope': 'web',
				'disjunctive': 'false',
				'sort_order': 'best-selling',
				'rules': []
			}
		}

		# Add Thumbnail image
		if category.thumb_image.url:
			main_image = self.process_image_before_import(category.thumb_image.url, category.thumb_image.path)
			image_data = self.resize_image(main_image['url'])
			if image_data:
				post_data['smart_collection']['image'] = image_data

		# Status
		if not category.active:
			post_data['smart_collection']['published_at'] = None

		# Add rules: the list of rules that define what products go into the smart collections.
		tag_rule = {
			'column': 'tag',
			'relation': 'equals',
			'condition': category.name
		}
		post_data['smart_collection']['rules'].append(tag_rule)

		# Post data
		response = self.api('smart_collections.json', post_data, 'Post')
		check_response = self.check_response_import(response, category, 'category')
		if check_response.result != Response.SUCCESS:
			if 'Image' in check_response.msg:
				del post_data['smart_collection']['image']
				response = self.api('smart_collections.json', post_data, 'Post')
				check_response = self.check_response_import(response, category, 'category')
				if check_response.result != Response.SUCCESS:
					return check_response
			else:
				return check_response

		category_id = response['smart_collection']['id']
		handle = response['smart_collection'].get('handle')
		return Response().success(category_id)


	def get_product_by_id(self, product_id):
		product = self.commerce_api(f'products/{product_id}')
		if self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		if self._last_status != 200:
			return Response().error()
		return Response().success(product['products'][0])


	def get_products_main_export(self):
		if self._flag_finish_product:
			return Response().finish()
		next_cursor = self._state.pull.process.products.next_cursor
		params = {}
		if next_cursor:
			params['cursor'] = next_cursor
		products = self.commerce_api('products', params)
		if not products or not products.products:
			return Response().finish()
		if not products.pagination.hasNextPage:
			self._flag_finish_product = True
		else:
			self._state.pull.process.products.next_cursor = products.pagination.nextPageCursor
		return Response().success(data = products.products)


	def get_max_last_modified_product(self):
		if self._state.pull.process.products.last_modified:
			if to_str(self._state.pull.process.products.last_modified).isnumeric():
				return convert_format_time(self._state.pull.process.products.last_modified, new_format = self.FORMAT_DATE)
			max_last_modified = self._state.pull.process.products.last_modified
			if max_last_modified.find(' ') != -1:
				max_last_modified = max_last_modified.replace(' ', 'T')
				max_last_modified += '.000Z'
			return max_last_modified
		return False


	def get_product_by_updated_at(self):
		if self._flag_finish_product:
			return Response().finish()
		params = {}
		next_cursor = self._state.pull.process.products.next_cursor
		if next_cursor:
			params['cursor'] = next_cursor
		else:
			last_modified = self.get_max_last_modified_product()
			if last_modified:
				params['modifiedAfter'] = last_modified
				params['modifiedBefore'] = get_current_time(self.FORMAT_DATE)
		products = self.commerce_api('products', params)
		if not products or not products.products:
			return Response().finish()
		if not products.pagination.hasNextPage:
			self._flag_finish_product = True
		else:
			self._state.pull.process.products.next_cursor = products.pagination.nextPageCursor
		return Response().success(data = products.products)


	def get_product_updated_at(self, product):
		return product.modifiedOn

	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return isoformat_to_datetime(updated_at).timestamp()
	def get_products_ext_export(self, products):
		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def _convert_product_export(self, product, products_ext: Prodict):
		product_id = to_str(product.id)
		product_data = Product()
		product_data.id = product_id
		product_data.name = product.name
		product_data.description = product.description
		product_data.seo_url = product.url
		product_data.tags = ",".join(product.tags) if product.tags else ''
		product_data.status = product.isVisible
		product_data.invisible = not product.isVisible
		if product.seoOptions:
			product_data.meta_title = product.seoOptions.title
			product_data.meta_description = product.description
		images = []
		if product.images:
			for image in product.images:
				if image.url in images:
					continue
				images.append(image.url)
				if image.orderIndex == 0:
					product_data.thumb_image.url = image.url
					continue
				product_image_data = ProductImage()
				product_image_data.url = image.url
				product_image_data.label = image.altText
				product_image_data.position = image.orderIndex
				product_data.images.append(product_image_data)
		variant = product.variants[0]
		channel_data = {
			'variant_default_id': variant['id'],
			'store_page_id': product.storePageId
		}
		all_store_page = self.get_all_store_page()
		if all_store_page and all_store_page.get(product.storePageId):
			product_data.category_name_list.append(all_store_page.get(product.storePageId).get('name'))
		product_data.channel_data = channel_data
		template_data = {
			'store': {
				'store_page_id': product.shipping_profile_id,
			}
		}
		product_data.template_data = template_data
		product_data.sku = variant.sku
		product_data.price = variant.pricing.basePrice.value
		if variant.pricing.salePrice and variant.pricing.salePrice.value:
			product_data.special_price.price = variant.pricing.salePrice.value
		product_data.qty = variant.stock.quantity
		product_data.created_at = product.createdOn.replace('T', " ")
		product_data.updated_at = product.modifiedOn.replace('T', " ")
		if variant.shippingMeasurements:
			if variant.shippingMeasurements.weight and variant.shippingMeasurements.weight.value:
				product_data.weight = variant.shippingMeasurements.weight.value
				product_data.weight_units = 'lb' if variant.shippingMeasurements.weight.unit == 'POUND' else 'kg'
			if variant.shippingMeasurements.dimensions:
				dimensions = ['length', 'width', 'height']
				product_data.dimension_units = 'in' if variant.shippingMeasurements.weight.unit == 'INCH' else 'cm'
				for row in dimensions:
					if variant.shippingMeasurements.dimensions.get(row):
						product_data[row] = variant.shippingMeasurements.dimensions.get(row)
		if not product.variantAttributes:

			if variant.stock.unlimited:
				product_data.manage_stock = False
				product_data.is_in_stock = True
			if variant.image:
				if product_data.thumb_image.url != variant.image.url:
					product_image_data = ProductImage()
					product_image_data.url = product_data.thumb_image.url
					product_data.images.append(product_image_data)
					product_data.thumb_image.url = variant.image.url
		else:
			min_price = 0
			manage_stock = False
			is_in_stock = False
			qty = 0
			# product_data.sku = product.id
			for variant in product.variants:
				variant_data = ProductVariant()
				variant_data.name = product.name
				variant_data.invisible = not product.isVisible
				variant_data.sku = variant.sku
				variant_data.id = variant.id
				variant_data.price = variant.pricing.basePrice.value
				if variant.pricing.salePrice and variant.pricing.salePrice.value:
					variant_data.special_price.price = variant.pricing.salePrice.value
				if not min_price or to_decimal(variant_data.price) < min_price:
					min_price = to_decimal(variant_data.price)
				variant_data.qty = variant.stock.quantity
				if variant.stock.unlimited:
					is_in_stock = True
					variant_data.manage_stock = False
					variant_data.is_in_stock = True
				else:
					manage_stock = True
					qty += to_int(variant.stock.quantity)
				if variant.image:
					variant_data.thumb_image.url = variant.image.url
				for attribute_name, attribute_value in variant.attributes.items():
					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_name = attribute_name
					attribute_data.attribute_value_name = attribute_value
					variant_data.attributes.append(attribute_data)
				product_data.variants.append(variant_data)
			product_data.manage_stock = manage_stock
			product_data.is_in_stock = is_in_stock
			if manage_stock:
				product_data.qty = qty
				product_data.is_in_stock = qty > 0
			product_data.price = min_price
		return Response().success(product_data)


	def extend_images(self, product):
		images = list()
		if product.thumb_image.url:
			main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			images.append(main_image['url'])
		for img_src in product.images:
			if 'status' in img_src and not img_src['status']:
				continue
			image_process = self.process_image_before_import(img_src.url, img_src.path)
			if image_process['url'] not in images:
				images.append(image_process['url'])
		return images


	def get_all_store_page(self):
		store_pages = self.commerce_api('store_pages')
		if not store_pages or not store_pages.storePages:
			return False
		self._all_store_page = {row['id']: {'name': row['title']} for row in store_pages.storePages}
		return self._all_store_page


	def get_store_page_id(self, product = None):
		if product and not self.is_channel_default():
			template_store = product.get('template_data', {}).get('store', {})

			if not template_store:
				return False
			return template_store.get('store_page_id')
		if self._store_page_id:
			return self._store_page_id
		if self._request_data.get('store_page_id'):
			self._store_page_id = self._request_data.get('store_page_id')
			return self._store_page_id
		store_pages = self.commerce_api('store_pages')
		if not store_pages or not store_pages.storePages:
			return False
		store_pages_enable = list(filter(lambda x: x.isEnabled, store_pages.storePages))
		if not store_pages_enable:
			return False
		self._store_page_id = store_pages_enable[0]['id']
		return self._store_page_id


	def to_sync_product_data(self, product: Product, setting_price):
		variant_data = {
			'pricing': {
				'basePrice': {
					'currency': self.get_currency(),
					'value': to_str(product.price)
				},
			},
			# 'stock': {
			# 	'quantity': product.qty,
			# 	'unlimited': not product.manage_stock
			# },
		}
		if not setting_price:
			del variant_data['pricing']
		elif self.is_special_price(product):
			variant_data['pricing']['salePrice'] = {
					'currency': self.get_currency(),
					'value': to_str(product.special_price.price)
				}
		# if not setting_qty:
		# 	del variant_data['stock']
		return variant_data


	def product_to_squarespace_variant_data(self, product: Product, parent = None, insert = False):
		if not parent:
			parent = product
		variant_data = {
			'sku': product.sku or random_string(16, True),
			'pricing': {
				'basePrice': {
					'currency': self.get_currency(),
					'value': to_str(product.price)
				},
			},
			'stock': {
				'quantity': product.qty,
				'unlimited': not product.manage_stock
			},
			'shippingMeasurements': {
				'weight': {
					'unit': self.get_weight_unit(),
					'value': product.weight or parent.weight
				},
				'dimensions': {
					'unit': self.get_dimension_unit(),
					'length': product.length or parent.length,
					'width': product.width or parent.width,
					'height': product.height or parent.height,
				},
			}
		}
		if not insert:
			del variant_data['stock']
		if product.is_variant:
			attributes = {}
			for attribute in product.attributes:
				if not attribute.use_variant:
					continue
				attributes[attribute.attribute_name] = attribute.attribute_value_name
			variant_data['attributes'] = attributes
		return variant_data


	def to_product_simple_data(self, product, page_id = None, insert = False):
		product_data = {
			'name': product.name,
			'description': self.custom_attribute_to_description(product),
			'tags': product.tags.split(',') if product.tags else [],
			'isVisible': product.status,
		}
		if insert:
			product_data['type'] = 'PHYSICAL'
			product_data['variants'] = []
		if page_id:
			product_data['storePageId'] = page_id
		return product_data


	def product_import(self, convert: Product, product, products_ext):
		if not product.name:
			return Response.error(Errors.PRODUCT_DATA_INVALID)
		page_id = self.get_store_page_id(product)
		if not page_id:
			return Response().error(Errors.SQUARESPACE_NOT_STORE_PAGE)
		self._last_product = None
		product_data = self.to_product_simple_data(product, page_id, insert = True)
		if not product.variants:
			variant_data = self.product_to_squarespace_variant_data(product, insert = True)
			product_data['variants'] = [variant_data]
		if product.variants:
			if product.variant_attributes:
				product_data['variantAttributes'] = product.variant_attributes
			for variant in product.variants:
				product_data['variants'].append(self.product_to_squarespace_variant_data(variant, product, insert = True))
		product_import = self.commerce_api('products', product_data, method = 'post')
		if self._last_status != 201:
			return Response().error(msg = product_import.message if product_import else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
		# Initiate Post data
		if product.variants:
			for index, variant in enumerate(product_import.variants):
				variant_index = product.variants[index]
				self.insert_map_product(variant_index, variant_index['_id'], variant.id)
		else:
			self._extend_product_map = {
				'variant_default_id': product_import.variants[0]['id'],
				'store_page_id': page_id
			}
		self._last_product = product_import

		return Response().success(product_import.id)


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		squarespace_product = self._last_product
		self._last_product = None
		images = self.extend_images(product)
		square_space_images = dict()
		thumb_image = None
		for index, image in enumerate(images):
			image_resize = self.resize(image)
			if not image_resize:
				continue
			files = [
				('file', image_resize)
			]
			body = {
				'name': 'file'
			}
			upload_image = self.post_commerce(f"/products/{product_id}/images", body, files = files)
			if upload_image and upload_image.imageId:
				square_space_images[image] = upload_image.imageId
				if not thumb_image:
					thumb_image = upload_image.imageId
		if not thumb_image:
			return Response().success()
		if not product.variants:
			variant_default = squarespace_product['variants'][0]
			image_data = {
				"imageId": thumb_image
			}
			self.post_commerce(f'products/{product_id}/variants/{variant_default["id"]}/image', image_data)
			return Response().success()
		for index, variant in enumerate(squarespace_product.variants):
			variant_index = product.variants[index]
			image = variant_index.thumb_image.url
			if image and square_space_images.get(image):
				image_id = square_space_images[image]
			else:
				image_id = thumb_image
			self.post_commerce(f'products/{product_id}/variants/{variant["id"]}/image', {
				"imageId": image_id
			})

		return Response().success()


	def extend_data_insert_map_product(self):
		return {}


	def product_channel_update(self, product_id, product: Product, products_ext):
		product_data = self.to_product_simple_data(product)
		update = self.post_commerce(f'products/{product_id}', product_data)
		if self._last_status > 204:
			return Response().error(msg = update.message if update else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
		variants = update.variants
		update_stock = {}

		if not product.variants:
			variant_data = self.product_to_squarespace_variant_data(product, product)
			update_variant = self.post_commerce(f'products/{product_id}/variants/{variants[0]["id"]}', variant_data)
			update_stock[variants[0]["id"]] = product.qty
			if self._last_status > 204:
				return Response().error(msg = update_variant.message if update_variant else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
		else:
			for variant in product.variants:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				variant_post_data = self.product_to_squarespace_variant_data(variant, product, insert = True if not variant_id else False)
				if not variant_id:
					create_variant = self.post_commerce(f'products/{product_id}/variants', variant_post_data)
					if create_variant and create_variant.id:
						self.insert_map_product(variant, variant['_id'], create_variant.id)
					continue
				update_variant = self.post_commerce(f'products/{product_id}/variants/{variant_id}', variant_post_data)
				if self._last_status > 204:
					return Response().error(msg = update_variant.message if update_variant else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
				update_stock[variant_id] = variant.qty
		if update_stock:
			finite_operations = []
			for variant_id, qty in update_stock.items():
				finite_operations.append({
					'variantId': variant_id,
					"quantity": qty
				})
			update_qty = self.post_commerce(f'inventory/adjustments', {"setFiniteOperations":finite_operations}, idempotency_key = True)
			if self._last_status > 204:
				return Response().error(msg = update_qty.message if update_qty else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))

		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		get_product = self.get_product_by_id(product_id)
		if get_product.result != Response.SUCCESS:
			return Response().success()
		product_data = get_product.data
		update_stock = {}
		if not product.variants:
			variant_data = self.to_sync_product_data(product, setting_price)
			update_variant = self.post_commerce(f'products/{product_id}/variants/{product_data.variants[0]["id"]}', variant_data)

			if self._last_status > 204:
				return Response().error(msg = update_variant.message if update_variant else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
			update_stock[product_data.variants[0]["id"]] = product.qty
		else:
			for variant in product.variants:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				if not variant_id:
					continue
				variant_post_data = self.to_sync_product_data(variant, setting_price)
				update_variant = self.post_commerce(f'products/{product_id}/variants/{variant_id}', variant_post_data)
				if self._last_status > 204:
					return Response().error(msg = update_variant.message if update_variant else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
				update_stock[variant_id] = variant.qty
		if update_stock:
			finite_operations = []
			for variant_id, qty in update_stock.items():
				finite_operations.append({
					'variantId': variant_id,
					"quantity": qty
				})
			update_qty = self.post_commerce(f'inventory/adjustments', {"setFiniteOperations":finite_operations},idempotency_key = True)
			if self._last_status > 204:
				return Response().error(msg = update_qty.message if update_qty else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))
		return Response().success()


	def delete_product_import(self, product_id):
		remove = self.commerce_api(f'products/{product_id}', None, 'delete')
		return Response().success()


	def get_options_from_variants(self, variants):
		options = {}
		position = 1
		for variant in variants:
			for attribute in variant.attributes:
				if not attribute.use_variant:
					continue
				attribute_name = to_str(attribute.attribute_name).replace('/', '-')
				if attribute_name not in options.keys():
					options[attribute_name] = {
						'values': [attribute.attribute_value_name],
						'position': position
					}
					position += 1
				elif attribute.attribute_value_name not in options[attribute_name]['values']:
					options[attribute_name]['values'].append(attribute.attribute_value_name)

		return options


	# orders
	def get_order_by_id(self, order_id):
		order = self.commerce_api(f'orders/{order_id}')
		if self._last_status != 200:
			return Response().error()
		return Response().success(order)


	def get_orders_main_export(self):
		if self._flag_finish_order:
			return Response().finish()
		params = {}
		next_cursor = self._state.pull.process.orders.next_cursor
		if next_cursor:
			params['cursor'] = next_cursor
		else:
			start_time = self.get_order_start_time(self.FORMAT_DATE)
			last_modifier = self._state.pull.process.orders.max_last_modified
			if not last_modifier:
				last_modifier = start_time
			if last_modifier:
				params['modifiedAfter'] = last_modifier
				params['modifiedBefore'] = get_current_time(self.FORMAT_DATE)
		orders = self.commerce_api('orders', params)
		if not orders or not orders.result:
			return Response().finish()
		if not orders.pagination.hasNextPage:
			self._flag_finish_order = True
		else:
			self._state.pull.process.orders.next_cursor = orders.pagination.nextPageCursor
		return Response().success(data = orders.result)


	def get_orders_ext_export(self, orders):
		return Response().success()


	def order_import(self, order: Order, convert: Order, orders_ext):
		channel_name = convert.channel_name
		if not channel_name or len(channel_name) > 30:
			channel_name = self.get_channel_type()
		order_data = {
			"channelName": channel_name,
			"externalOrderReference": convert.channel_order_number or convert.order_number,
			"customerEmail": convert.customer.email,
			"billingAddress": {
				"firstName": convert.billing_address.first_name,
				"lastName": convert.billing_address.last_name,
				"address1": convert.billing_address.address_1 or convert.billing_address.address_2 or convert.billing_address.country or 'address1',
				"city": convert.billing_address.city,
				"state": convert.billing_address.state.state_code,
				"countryCode": convert.billing_address.country.country_code,
				"postalCode": convert.billing_address.postcode,
			},
			"shippingAddress": {
				"firstName": convert.shipping_address.first_name,
				"lastName": convert.shipping_address.last_name,
				"address1": convert.shipping_address.address_1 or convert.shipping_address.address_2 or convert.shipping_address.country or 'address1',
				"city": convert.shipping_address.city,
				"state": convert.shipping_address.state.state_code,
				"countryCode": convert.shipping_address.country.country_code,
				"postalCode": convert.shipping_address.postcode,
			},
			"inventoryBehavior": "DEDUCT" if convert.status != Order.CANCELED else "SKIP",
			"priceTaxInterpretation": "EXCLUSIVE",
			"subtotal": {
				"currency": self.get_currency(),
				"value": to_str(convert.subtotal)
			},
			"grandTotal": {
				"currency": self.get_currency(),
				"value": to_str(convert.total)
			},
			"fulfillmentStatus": "FULFILLED" if convert.status == Order.COMPLETED else "PENDING",
			"shopperFulfillmentNotificationBehavior": "SKIP",
			"createdOn": convert_format_time(convert.created_at, new_format = self.FORMAT_DATE),
			"lineItems": list()
		}
		if convert.billing_address.telephone:
			order_data['billingAddress']['phone'] = convert.billing_address.telephone
		if convert.shipping_address.telephone:
			order_data['shippingAddress']['phone'] = convert.shipping_address.telephone
		fullfilled_date = get_current_time(self.FORMAT_DATE)
		if convert.status == Order.COMPLETED:
			order_data['fulfilledOn'] = fullfilled_date
		order_data['shippingLines'] = [
			{
				"method": convert.shipping.method or convert.shipping.title or 'shipping',
				"amount": {
					"currency": self.get_currency(),
					"value": to_str(convert.shipping.amount or 0)
				}
			}
		]
		if convert.shipping.amount:
			order_data['shippingTotal'] = {
				"currency": self.get_currency(),
				"value": to_str(convert.shipping.amount)
			}
		if convert.discount.amount:
			order_data['discountLines'] = [
				{
					"promoCode": convert.discount.code or 'discount',
					"name": convert.discount.title or 'discount',
					"amount": {
						"currency": self.get_currency(),
						"value": to_str(convert.discount.amount)
					}
				}
			]
			order_data['discountTotal'] = {
				"currency": self.get_currency(),
				"value": to_str(convert.discount.amount)
			}
		if convert.tax.amount:
			order_data['taxTotal'] = {
				"currency": self.get_currency(),
				"value": to_str(convert.tax.amount)
			}
		if convert.status == Order.COMPLETED:
			order_data['fulfillments'] = [
				{
					"shipDate": fullfilled_date,
					"carrierName": convert.shipments.tracking_company_code or 'other',
					"service": convert.shipments.tracking_company or 'other',
					"trackingNumber": convert.shipments.tracking_number or convert.channel_order_number,
					"trackingUrl": convert.shipments.tracking_url or "https://app.litcommerce.com",

				}
			]
		for product in convert.products:
			product_id = None
			variant_id = None
			if product['product_id'] and product['parent_id']:
				variant_id = product['product_id']
				product_id = product['parent_id']
			else:
				product_id = product['product_id']
			product_data = {
				"lineItemType": "PHYSICAL_PRODUCT",
				"variantId": variant_id or product.product.channel[f"channel_{self.get_channel_id()}"]['variant_default_id'],
				"quantity": product.qty,
				"unitPricePaid": {
					"currency": self.get_currency(),
					"value": to_str(product.price)
				}
			}
			order_data['lineItems'].append(product_data)
		idempotency_key = to_str(uuid.uuid4())
		response = self.post_commerce("orders", order_data, idempotency_key = idempotency_key)
		if self._last_status != 201:
			return Response().error(msg = response.message if response else Errors().get_msg_error(Errors.SQUARESPACE_API_INVALID))

		order_return = {
			'order_id': response['id'],
			'order_status': response['fulfillmentStatus'],
			'order_number': response['orderNumber'],
			'created_at': response['createdOn'][0:19],
		}
		return Response().success([response['id'], order_return])


	def channel_order_completed(self, order_id, order: Order, current_order):
		financial_status = self.FINANCIAL_ORDER_STATUS.get(order.status, 'pending')
		update = {
			"order": {
				"financial_status": financial_status
			}
		}
		res = self.api(path = f"/orders/{order_id}.json", data = update, api_type = 'put')
		if res and res.get('order'):
			return_order = {
				'status': res['order']['financial_status']
			}
			return Response().success(return_order)
		return Response().error(Errors.EXCEPTION, msg = res.get('msg'))


	def convert_order_status(self, status):
		order_status = {
			"pending": Order.OPEN,
			"partially_refunded": Order.OPEN,
			"authorized": Order.AWAITING_PAYMENT,
			"partially_paid": Order.SHIPPING,
			"paid": Order.COMPLETED,
			"voided": Order.CANCELED,
			"refunded": Order.CANCELED,

		}
		return order_status.get(status, 'open') if status else 'open'


	def convert_time(self, time_data):
		return convert_format_time(time_data, "%Y-%m-%dT%H:%M:%S")


	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_create = to_timestamp(self.convert_time(order.createdOn))
		start_time = to_timestamp(self.get_order_start_time())

		if order_create < start_time:
			return Response().skip()
		order_data = Order()
		order_data.id = order.id
		order_data.order_number = order.orderNumber
		order_data.created_at = self.convert_time(order.createdOn)
		order_data.updated_at = self.convert_time(order.modifiedOn)
		order_data.customer.email = order.customerEmail
		order_data.customer.first_name = order.billingAddress.firstName if order.billingAddress else "GUEST"
		order_data.customer.last_name = order.billingAddress.firstName if order.billingAddress else ""
		if order.billingAddress:
			billing_info = order.billingAddress
			customer_address = OrderAddress()
			customer_address.country.country_code = billing_info.countryCode
			customer_address.state.state_name = billing_info.state
			customer_address.first_name = billing_info.firstName
			customer_address.last_name = billing_info.lastName
			customer_address.city = billing_info.city
			customer_address.postcode = billing_info.postalCode
			customer_address.telephone = billing_info.phone
			customer_address.address_1 = billing_info.address1
			customer_address.address_2 = billing_info.address2
			order_data.customer_address.update(customer_address)
			order_data.billing_address.update(customer_address)
		if order.shippingAddress:
			shipping_info = order.shippingAddress
			customer_address = OrderAddress()
			customer_address.country.country_code = shipping_info.countryCode
			customer_address.state.state_name = shipping_info.state
			customer_address.first_name = shipping_info.firstName
			customer_address.last_name = shipping_info.lastName
			customer_address.city = shipping_info.city
			customer_address.postcode = shipping_info.postalCode
			customer_address.telephone = shipping_info.phone
			customer_address.address_1 = shipping_info.address1
			customer_address.address_2 = shipping_info.address2
			order_data.shipping_address.update(customer_address)
		if order.shippingTotal:
			order_data.shipping.amount = to_decimal(order.shippingTotal.value)
			if order.shippingLines:
				order_data.shipping.title = order.shippingLines[0].method
				order_data.shipping.method = order.shippingLines[0].method
		if order.discountTotal and to_decimal(order.discountTotal.value):
			order_data.discount.amount = to_decimal(order.discountTotal.value)
			if order.discountLines:
				order_data.discount.code = order.discountLines[0].promoCode
				order_data.discount.title = order.discountLines[0].name
		if order.taxTotal:
			order_data.tax.amount = to_decimal(order.taxTotal.value)
		if order.subtotal:
			order_data.subtotal = to_decimal(order.subtotal.value)
		else:
			order_data.subtotal = to_decimal(order.grandTotal.value)
		order_data.total = to_decimal(order.grandTotal.value)
		if order.fulfillmentStatus == 'FULFILLED':
			order_status = Order.COMPLETED
			order_data.shipments.tracking_number = order.fulfillments[0].trackingNumber
			order_data.shipments.tracking_url = order.fulfillments[0].trackingUrl
			order_data.shipments.tracking_company_code = order.fulfillments[0].carrierName
			order_data.shipments.tracking_company = f"{order.fulfillments[0].carrierName} {order.fulfillments[0].service}"
			order_data.shipments.shipped_at = self.convert_time(order.fulfillments[0].shipDate)
		elif order.fulfillmentStatus == 'CANCELED':
			order_status = Order.CANCELED
		else:
			if order.refundedTotal and to_decimal(order.refundedTotal.value):
				order_status = Order.CANCELED
			else:
				order_status = Order.SHIPPING
		order_data.status = order_status
		order_data.channel_data = {
			'order_status': order.fulfillmentStatus,
			'created_at': order_data.created_at,
			'order_number': order_data.order_number,
			'shipped_date': order_data.shipments.shipped_at,
		}
		for product in order.lineItems:
			order_product = OrderProducts()
			order_product.product_id = product.productId
			if product.variantId and product.variantOptions:
				order_product.product_id = product.variantId
			order_product.product_name = product.productName
			order_product.product_sku = product.sku
			order_product.qty = to_int(product.quantity)
			order_product.price = to_decimal(product.unitPricePaid.value)
			order_product.subtotal = to_decimal(order_product.qty * order_product.price)
			order_product.total = to_decimal(order_product.qty * order_product.price)
			if product.variantOptions:
				for option in product.variantOptions:
					product_option = OrderItemOption()
					product_option.option_name = option.optionName
					product_option.option_value_name = option.value
					order_product.options.append(product_option)
			if product.customizations:
				for option in product.customizations:
					product_option = OrderItemOption()
					product_option.option_name = option.label
					product_option.option_value_name = option.value
					order_product.options.append(product_option)
			order_data.products.append(order_product)
		if order.internalNotes:
			for history in order.internalNotes:
				order_history = OrderHistory()
				order_history.comment = history.content
				order_data.history.append(order_history)
		return Response().success(order_data)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	def order_completed(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		try:
			# https://developers.squarespace.com/commerce-apis/fulfill-order
			tracking_company = TrackingCompany(order.shipments.tracking_company_code, order.shipments.tracking_company, channel_type = 'squarespace')
			payload = {
				'shouldSendNotification': False,
				'shipments': [
					{
						'shipDate':  get_current_time(self.FORMAT_DATE),
						'carrierName': tracking_company.get_name() or 'other',
						'service': tracking_company.get_name() or 'other', # TODO: update service info: standard, priorty, slow,..
						'trackingNumber': order.shipments.tracking_number,
						'trackingUrl': order.shipments.tracking_url or "https://app.litcommerce.com",
					}
				]
			}
			res = self.commerce_api(path = f"/orders/{order_id}/fulfillments", data = payload, api_type = 'post')
			if self._last_status >= 300:
				return Response().error()
		except:
			self.log_traceback()
			return Response().error()

		return Response().success()

	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(order, '+')


	def order_sync_inventory(self, convert: Order, setting_order):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		if prefix == '-':
			method = 'decrement'
		else:
			method = 'increment'
		data = list()
		for item in convert.products:
			if item['product_id'] and item['parent_id']:
				variant_id = item['product_id']
				product_id = item['parent_id']
			else:
				variant_id = False
				product_id = item['product_id']
			row_qty = to_int(item['qty']) if to_int(item.qty) > 0 else 1

			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				data.append({
					"variantId": variant_id or item.product.channel[f"channel_{self.get_channel_id()}"]['variant_default_id'],
					"quantity": row_qty
				})
		idempotency_key = to_str(uuid.uuid4())

		update_qty = self.post_commerce(f"inventory/adjustments", {f"{method}Operations": data}, idempotency_key = True)
		return Response().success()


	# if self._state['config']['img_des'] and post_data['product']['body_html']:
	# 	theme_data = self.get_theme_data()
	# 	if theme_data:
	# 		check = False
	# 		description = post_data['product']['body_html']
	# 		match = re.findall(r"<img[^>]+>", to_str(description))
	# 		links = list()
	# 		if match:
	# 			for img in match:
	# 				img_src = re.findall(r"(src=[\"'](.*?)[\"'])", to_str(img))
	# 				if not img_src:
	# 					continue
	# 				img_src = img_src[0]
	# 				if img_src[1] in links:
	# 					continue
	# 				links.append(img_src[1])
	# 		for link in links:
	# 			# download and replace
	# 			if self._state['src']['config'].get('auth'):
	# 				link = self.join_url_auth(link)
	# 			if to_int(theme_data['count']) >= 1500:
	# 				theme_data = self.get_theme_data(True)
	# 			if not theme_data:
	# 				break
	# 			if not self.image_exist(link):
	# 				continue
	# 			asset_post = self.process_assets_before_import(url_image = link, path = '', id_theme = theme_data['id'], name_image = convert['code'])
	# 			asset_post = json_decode(asset_post)
	# 			if asset_post and asset_post.get('asset'):
	# 				self.update_theme_data(theme_data['count'])
	# 				check = True
	# 				description = to_str(description).replace(link, asset_post['asset']['public_url'])
	# 		if check:
	# 			product_update = {
	# 				'product': {
	# 					'body_html': description
	# 				}
	# 			}
	# 			res = self.api('products/' + to_str(product_id) + '.json', product_update, 'PUT')

	def get_sizes(self, url):
		req = Request(url, headers = {'User-Agent': get_random_useragent()})
		try:
			file = urlopen(req)
		except:
			self.log('image: ' + to_str(url) + ' 404', 'image_error')
			return False, False
		size = file.headers.get("content-length")
		# date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
		# type = file.headers.get('content-type')
		if size: size = to_int(size)
		p = ImageFile.Parser()
		while 1:
			data = file.read(1024)
			if not data:
				break
			p.feed(data)
			if p.image:
				return size, p.image.size
		file.close()
		return size, False


	def resize(self, url):
		try:
			r = False
			retry = 0
			while r is False and retry < 5:
				try:
					r = requests.get(url, headers = {'User-Agent': get_random_useragent()}, verify = False, timeout = 10)
				except Exception as e:
					time.sleep(2)
					retry += 1
					r = False
			if not r or r.status_code != 200:
				return False
			return r.content
		except Exception as e:
			self.log_traceback('images', f"image error: {url}")

			return False


	def check_response_import(self, response, convert, entity_type = ''):
		entity_id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(entity_id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()


	def custom_attribute_to_description(self, product: Product):
		product_description = product.description or product.description
		product_description = nl2br(product_description)
		return product_description
		if not product.attributes:
			return product_description
		section_title = 'Custom Attributes'
		if product.src.channel_type == 'ebay':
			section_title = 'Item Specifics'
		if product.src.channel_type == 'shopify':
			section_title = 'Metafields'
		custom_attributes = list()
		for attribute in product.attributes:
			custom_attributes.append(f'<li>{to_str(attribute.attribute_name).capitalize()}: {attribute.attribute_value_name}</li>')
		custom_attributes = "\n".join(custom_attributes)
		description = f'''
		<div style="border: 1px solid #ccc;padding: 0px 10px">
    <h3 style="align-items: center;
    display: flex; padding: 0px 10px"><span style="font-weight: bold">{section_title}</span></h3>
    <div>
        <ul style="list-style: None;padding: 0px 10px">
            {custom_attributes}
        </ul>
    </div>
</div>
		'''
		if product_description:
			description = f'{description}</br>{product_description}'
		return description

	def display_finish_channel_pull(self):
		super().display_finish_channel_pull()
		if is_local():
			return Response().success()
		if self.is_refresh_process():
			webhook = self.api('webhook_subscriptions')
			verify = {
				'order': False,
				'product': False
			}
			if webhook and webhook.get('webhookSubscriptions'):
				for hook in webhook['webhookSubscriptions']:
					if hook['endpointUrl'].find('https://api.litcommerce.com/merchant/squarespace/webhook') != -1:
						self.api(f'webhook_subscriptions/{hook["id"]}', method = 'delete')
						continue
					if hook['endpointUrl'].find(f'api/v1/merchant/squarespace/webhook/{self.get_channel_id()}/order/update') != -1 and hook['topic'][0] == 'order.update':
						verify['order'] = True
			events = dict()

			if not verify['order']:
				events[f"orders/updated"] = f'order.update'
			if not events:
				return Response().success()
			for event, url in events.items():
				address = get_server_callback(f'merchant/squarespace/webhook/{self.get_channel_id()}/{url}')
				webhook_data = {
					"topics": [event],
					"endpointUrl": address,
				}
				webhook = self.post('webhook_subscriptions', webhook_data)
				if self._last_status == 201:
					self._state.channel.config.api[f"secret_webhook"] = webhook['secret']
					self.update_channel(api = json_encode(self._state.channel.config.api))
		return Response().success()


	def finish_refresh_process(self):
		time.sleep(5*60)
		self.refresh_access_token()
		time.sleep(5*60)
		self.refresh_access_token()
		return Response().success()
	

	def get_draft_extend_channel_data(self, product):
		extend = {}
		if not product.sku:
			extend['sku'] = random_string(16)
		return extend