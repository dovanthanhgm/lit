import copy
import re
from datetime import timedelta
from typing import Dict
from countryinfo import CountryInfo
from urllib.parse import quote as parse_quote
import uuid
import requests
import barcodenumber
from copy import deepcopy
from ast import literal_eval
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from base64 import b64decode, b64encode
from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderAdditionalDetails
from datasync.models.constructs.product import *
from datasync.models.constructs.walmartca import *


class ModelChannelsWalmartca(ModelChannel):
	ORDER_STATUS = {
		Order.OPEN: 'Created',
		Order.AWAITING_PAYMENT: 'Acknowledged',
		Order.READY_TO_SHIP: 'Acknowledged',
		Order.SHIPPING: 'Shipped',
		Order.COMPLETED: 'Shipped',
		Order.CANCELED: 'Cancelled',
		Order.REFUNDED: 'Refund'
	}

	INGESTION = {
		'data': 'DATA_ERROR',
		'system': 'SYSTEM_ERROR',
		'timeout': 'TIMEOUT_ERROR',
		'success': 'SUCCESS',
		'inprogress': 'INPROGRESS',
	}

	_FEED_TYPE = {
		'create': 'CREATE',  # use when create the new item
		'replace_all': 'REPLACE_ALL',  # use when update product or price
		'partial': 'PARTIAL_UPDATE'  # update product only
	}

	SELLING_CHANNEL = 'marketplace'

	""" Log enable by level
	1: all (data send, dat received, warning, except)
	2: warning
	3: exception
	"""
	LOG_LEVEL = 1

	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'shipping', 'category']
	_TIME_SLEEP_FEED = 30
	_LIST_PRODUCT_ID_TYPE = ['gtin', 'upc', 'ean', 'isbn']
	_API_VERSION_NEW = '3.15'
	_API_VERSION = '3.2'
	_NOT_FOUND_CATEGORY = 'LITCOMMERCE_NOT_FOUND_CATEGORY'
	_FEED_FORMAT_TIME = '%Y-%m-%dT%H:%M:%S'
	_ORDER_FORMAT_TIME = '%Y-%m-%dT%H:%M:%SZ'  # UTC format
	_ORDER_FORMAT_TIME_MILLISECOND = '%Y-%m-%dT%H:%M:%S.%fZ'  # UTC format in millisecond
	_DISABLE_PULLING = False

	# Import feed items

	def __init__(self):
		super().__init__()
		self._categories = dict()
		self._brands = dict()
		self._flag_finish_get = False
		self._cursor_next_link = False
		self._weight_units = False
		self._dimension_units = False
		self._store_information = False
		self._url_base: str or None = None
		self._update_product_flow: bool = False
		self._update_qty: bool = True
		self._update_price: bool = True
		self._update_shipping: bool = True
		self._offset: int = 0
		self._total_items: int = 0
		self._total_parent_product: int = 0
		self._convert_product = None
		self._order_start_create: str = ''
		self.cache_products: List[Product] = list()
		self.cache_products_imported: List[Product] = list()
		self.cache_warnings: dict = dict()
		self.cache_errors: Dict[str, list] = dict()
		self.cache_products_sku_index = dict()
		self.cache_products_insert = dict()
		self.cache_variant_id = list()
		self.parent_products = dict()
		self.parent_variants = dict()
		self._update_product_code: bool = False # value to change the feed mode to create
		# variable update channel data of a product in function `insert_map_product`
		self._extend_product_map = dict()
		self._feed_has_error: bool = False
		self._republish_feed: bool = False
		self._category_template: Dict = dict()
		self._all_products: List[Dict] = list()

	def get_channel_type_key(self) -> str or None:
		channel_key = get_config_ini('walmart_canada', 'channel_type_key')
		return channel_key

	@staticmethod
	def get_timestamp_now() -> str:
		time_stamp = str(int(time.time() * 1000))
		return time_stamp

	@staticmethod
	def is_production_mode() -> bool:
		return get_config_ini('walmart_canada', 'mode') == 'production'

	def get_consumer_id(self) -> str or None:
		# if ModelChannelsWalmartca.is_production_mode() is False:
		# 	return get_config_ini('walmart_canada', 'consumer_id')

		return self._state.channel.config.api.get('consumer_id')

	def get_private_key(self) -> str or None:
		# if ModelChannelsWalmartca.is_production_mode() is False:
		# 	return get_config_ini('walmart_canada', 'private_key')

		return self._state.channel.config.api.get('private_key')

	def log_by_level(self, log_data: dict or str, log_file: str = 'Exception', current_level: int = 1) -> dict:
		"""Log data by level
		if in test mode -> log all data
		if we in the product mode: compare current log and level log = 'Exception'
		level: 1. debug -> 3. exception
		"""
		if current_level >= self.LOG_LEVEL or ModelChannelsWalmartca.is_production_mode() is False:
			self.log(log_data, log_file)

		return {'log level': self.LOG_LEVEL, 'log data': log_data}

	def get_api_info(self) -> dict:
		return {
			'consumer_id': to_str(self._state.channel.config.api.consumer_id),
			'private_key': to_str(self._state.channel.config.api.private_key)
		}

	def get_app_mode(self) -> str:
		app_mode = self._state.channel.config.api.app_mode
		if not app_mode:
			return get_config_ini('walmart_canada', 'mode')  # test or production
		return app_mode

	def get_url_base(self) -> str:
		if not self._url_base:
			self._url_base = "https://marketplace.walmartapis.com"
		return self._url_base

	def generate_digital_signature(self, url: str, req_method: str = 'GET') -> (str, str):
		"""
		Ref:
		https://stackoverflow.com/questions/57383902/how-to-generate-wm-sec-auth-signature
		https://developer.walmart.com/documentation/digital-signature/
		"""

		try:
			# url = self.get_url_base() + '/' + url.strip('/')
			consumer_id = self.get_consumer_id()
			private_key = self.get_private_key()
			req_method = req_method.upper()
			epoch_time = ModelChannelsWalmartca.get_timestamp_now()

			sorted_hash_string = consumer_id + '\n' + url + '\n' + req_method + '\n' + epoch_time + '\n'
			encoded_hash_string = sorted_hash_string.encode()

			# generate RSA key
			key = RSA.importKey(b64decode(private_key))
			signer = PKCS1_v1_5.new(key)
			# encode the private_key RSA using PKCS#8
			hasher = SHA256.new(encoded_hash_string)
			signature = signer.sign(hasher)
			# encode the generated digital signature
			signature_enc = str(b64encode(signature), 'utf-8')
		except Exception as e:
			return '', ''

		return signature_enc, epoch_time

	def log_response_data(self, method, url, response, centrailize = False, **request_options) -> None:
		"""
		Daily run not required
		Log request data from Walmart to check partner configuration
		centrailize: log to each channel folder or log to log/walmart_ca
		"""
		status_code = response.status_code
		name_log = 'response_data_' + to_str(url).split('v3/ca/')[-1].split('/')[0].split('?')[0]
		params_r = literal_eval(json_encode(request_options.get('params', '')))
		json_r = request_options.get('json')
		xml_bytes_r = request_options['data'].decode() if isinstance(request_options.get('data'), bytes) else to_str(request_options.get('data'))
		payload = xml_bytes_r.replace('\n', '') or json.dumps(params_r or json_r)
		response_dump = json.dumps(xml_to_dict(response.text)) if status_code == 200 else response.text
		try:
			endpoint_msg = """
*** Endpoint ***
		{} {}
		""".format(to_str(method).upper(), to_str(url))

			header_payload_msg = """
*** Headers ***
		{}
		
*** Payload ***
		{}
		""".format(to_str(request_options['headers']).replace('", "', '"\n\t\t "')[1:-1], payload)

			response_msg = """
*** Response ***
		{} {}
		XML:
		{}
		JSON:
		{}
		
		""".format(status_code, to_str(response.reason),
			       to_str(response.text),
			       response_dump)
			msg = endpoint_msg + header_payload_msg + response_msg

		except Exception as e:
			msg = f'Error when log response data: {e}'

		if not centrailize:
			self.log(msg, name_log)
		else:
			log(
				msg,
				'walmart_ca',
				f'channel {self.get_channel_id()}_{status_code}_{name_log}'
			)

	def get_channel_type(self) -> str or None:
		channel_type = get_config_ini('walmart_canada', 'channel_type_key')
		return channel_type

	@staticmethod
	def xml_to_dict(data: str) -> Prodict:
		"""Convert a response with format XML to Prodict"""
		data_convert = data
		return Prodict()

	@staticmethod
	def dict_to_xml(data: Prodict or dict) -> str:
		"""Convert Prodict/dict data to XML format"""
		data_convert = data
		return ''

	@staticmethod
	def random_sku(length = 20) -> str:
		chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
		return ''.join(random.choice(chars) for _ in range(length))

	def requests(self, url, data = None, headers = None, method = 'get', content_type = 'xml', retry = 0) -> Response:
		time.sleep(1)

		def remove_key_namespaces(data_):
			"""remove the namespaces when convert from xml to json"""
			if isinstance(data_, dict) or isinstance(data_, Prodict):
				remove_list = [f'ns{num}' for num in range(2, 7)]
				data_new = Prodict()
				for key_, val_ in data_.items():

					key_new = key_
					for ns in remove_list:
						key_new = key_new.replace(f'{ns}:', '')

					data_new[key_new] = remove_key_namespaces(val_)
				return data_new

			elif isinstance(data_, list):
				list_new = list()
				for item_ in data_:
					item_new = remove_key_namespaces(item_)
					list_new.append(item_new)

				return list_new

			else:
				return data_

		def log_request_error(_res):
			try:
				error = {
					'method': method,
					'status': _res.status_code,
					'data': to_str(data),
					'header': to_str(_res.headers),
					'response': _res.text,
				}

			except:
				error = {'status': 'ERROR', 'data': _res}
			# name_log = f'request_errors_{_res.status_code if _res else ""}'
			name_log = 'request_errors'
			self.log_request_error(url = url, log_type = name_log, **error)

			return True

		def prepare_request_options():
			nonlocal headers
			if not headers:
				headers = dict()
				headers['User-Agent'] = get_random_useragent()

			elif isinstance(headers, dict) and not headers.get('User-Agent'):
				headers['User-Agent'] = get_random_useragent()

			request_options_ = {
				'headers': headers,
				'verify': True
			}

			if method in ['post', 'put'] and data:
				if content_type == 'json':
					headers['Content-Type'] = 'application/json'
					request_options_['json'] = data

				else:
					headers['Content-Type'] = 'application/xml'
					request_options_['data'] = xmltodict.unparse(data).encode('utf-8')

			return request_options_

		def check_response_not_success() -> str:
			nonlocal response
			if response.status_code <= 204:
				return ''

			if response.status_code == 401:
				return Errors().get_msg_error(Errors.WALMART_CA_API_INVALID)

			if response.status_code == 429:
				return Errors().get_msg_error(Errors.WALMART_RATE_LIMIT)

			elif response.status_code == 444:
				self.log_response_data(method, url, response, True, **request_options)
				return Errors().get_msg_error(Errors.WALMART_FIREWALL_BLOCKED)

			elif response.status_code == 500:
				return Errors().get_msg_error(Errors.WALMART_INTERNAL_ERROR)

			elif response.status_code > 300:
				return Errors().get_msg_error(Errors.WALMART_INTERNAL_ERROR)

		def decode_response() -> Prodict:
			"""currently, walmartca uses xml and json simultaneously in the system"""
			nonlocal response_data
			response_data = response.text
			if 'xml' in response.headers['Content-Type']:
				response_data_decode = xml_to_dict(response_data)

			else:
				# some endpoint use json, like the end point get identifier
				response_data_decode = json_decode(response_data)

			if not response_data_decode:
				log_request_error(response)
				return Prodict()

			response_prodict = Prodict(**response_data_decode)
			response_prodict = remove_key_namespaces(response_prodict)
			self.log_response_data(method, url, response, False, **request_options)
			self.log_by_level(response_prodict, response_log_file, 1)

			return response_prodict


		response_log_file = 'response_data_log'
		response = dict()
		method = to_str(method).lower()
		request_options = self.combine_request_options(
			prepare_request_options())
		response_data = False

		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code
			if response.status_code > 204:
				log_request_error(response)
				error_msg = check_response_not_success()
				if error_msg:
					return Response(msg = error_msg)

			response_data = decode_response()

		except requests.exceptions.SSLError as e:
			if retry < 5:
				retry += 1
				time.sleep(retry * 2)
				return self.requests(url, data, headers, method, content_type, retry = 0)

		except Exception as e:
			self.log_traceback()
			log_request_error(response)
			err = Errors.EXCEPTION
			return Response().error(code = err, msg = Errors().get_msg_error(err))

		return Response().success(response_data)

	def set_channel_partner_id(self, partner_id: str) -> None:
		self._state.channel.config.api.partner_id = partner_id

	def get_channel_partner_id(self) -> str:
		return self._state.channel.config.api.partner_id

	def display_setup_channel(self, data = None) -> Response:
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent

		try:
			response = self.api('feeds')
			if response.msg in [Errors().get_msg_error(Errors.WALMART_CA_API_INVALID), Errors().get_msg_error(Errors.EXCEPTION)]:
				return Response().error(Errors.WALMART_CA_API_INVALID)

			try:
				partner_id = to_str(response.data['list']['results']['feed'][0]['partnerId'])
			except:
				partner_id = self.get_partner_id_from_feed()
				if not partner_id:
					return Response().error(Errors.EXCEPTION)

			self.set_channel_partner_id(partner_id)

		except Exception as e:
			return Response().error(code = Errors.WALMART_CA_API_INVALID)

		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()

	def get_store_information(self):
		if self._store_information:
			return self._store_information

		store_information = self.api('feeds')
		if self._last_status != 200 or not store_information:
			return False

		self._store_information = store_information

		return self._store_information.data

	def set_channel_identifier(self) -> Response:
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent

		self.set_identifier(self.get_channel_partner_id())
		return Response().success()

	def get_partner_id_from_feed(self) -> str:
		""" create an empty feed to retrieve the partner_id from it.
		this situation rarely occurs; it happens when a seller uses
		walmart for the first time and doesn't have any feeds yet,
		preventing us from obtaining the partner id."
		"""
		empty_feed = {
			"MPItemFeedHeader": {
				"sellingChannel": "marketplace",
				"processMode": "REPLACE",
				"mart": "WALMART_CA",
				"locale": [
					"en",
					"fr"
				],
				"version": "3.15",
				"subset": "EXTERNAL"
			},
			"MPItem": [
				{
					"Orderable": {
						"productName": {
							"en": ""
						},
						"shortDescription": {
							"en": ""
						},
						"mainImageUrl": "",
						"sku": "TEST_SANDBOX",
						"productIdentifiers": {
							"productIdType": "UPC",
							"productId": ""
						},
						"price": 999999,
						"ShippingWeight": {
							"measure": 100000,
							"unit": "lb"
						},
						"endDate": "2050-05-05",
						"productTaxCode": 2038710,
						"brand": {
							"en": ""
						}
					},
					"Visible": {
						"color": [{}]
					}
				}
			]
		}

		self.api(
			'feeds?feedType=MP_ITEM_INTL',
			data = empty_feed,
			api_type = 'post',
			content_type = 'json'
		)
		# the timeout for the request is currently set to 30s after going through cloudflare
		# reduce the number of checks to prevent encountering this limit
		time.sleep(10)
		partner_id = ''
		for try_ in range(0, 2):
			time.sleep(5 * try_)
			try:
				feed_res = self.api('feeds?includeDetails=true')
				feed_list = ModelChannelsWalmartca.dict_to_list(feed_res.data['list']['results']['feed'])
				partner_id = to_str(feed_list[0]['partnerId'])
				if partner_id:
					break

			except Exception as e:
				self.log_traceback()

		return partner_id

	def after_create_channel(self, data):
		return Response().success()

	def validate_api_info(self) -> Response:
		validate = super(ModelChannelsWalmartca, self).validate_api_info()
		if validate.result != Response.SUCCESS:
			return validate

		consumer_id = to_str(self._state.channel.config.api.consumer_id)
		private_key = to_str(self._state.channel.config.api.private_key)
		self._url_base = self.get_url_base()

		if not (consumer_id and private_key) or (len(consumer_id) > 5000 or len(private_key) > 5000):
			return Response().error(code = Errors.WALMART_API_INVALID)

		return Response().success()

	def set_product_update(self) -> bool:
		"""set mode update product"""
		self._update_product_flow = True
		return self._update_product_flow

	def is_update_product_process(self):
		return bool(
			self._process_type == self.PROCESS_TYPE_PRODUCT
			and self._publish_action == 'update'
		)
	def is_product_pull_from_walmart_ca(self, product) -> bool:
		"""check if the product pull from WALMART_CA or publish from LitCommerce"""

		check_src = True if product.src.channel_id == self.get_channel_id() else False
		channel_data = product['channel'].get(f'channel_{self.get_channel_id()}', {})

		# if a product has auto_link or user_linked mean product pull from WALMART_CA
		# the product linked with a product in the main channel
		check_link = True if channel_data.get('auto_link') or channel_data.get('user_linked') else False

		return check_src or check_link

	@staticmethod
	def set_lowest_price_variant_is_primary(product) -> int or float:
		"""make the first lowest items is primary variant"""
		price_variant = dict()
		for variant in product.variants:
			price_variant.update(
				{variant.sku: variant.price}
			)

		min_sku, min_price = min(price_variant.items(), key = lambda x: x[0])
		update_price_ = [var.update({'is_primary_variant': False}) for var in product.variants]
		update_sku_ = [var.update({'is_primary_variant': True}) for var in product.variants if var.sku == min_sku]

		return min_price

	def get_max_last_modified_product(self):
		pass

	def get_product_updated_at(self, product):
		return product.date_modified

	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(updated_at[0:10], '%Y-%m-%d')

	def display_pull_channel(self) -> Response:
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent

		# product
		if self.is_product_process():
			id_src_prd = self._state.pull.process.products.id_src
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.total = 0
			if not self._state.pull.process.products.id_src:
				self._state.pull.process.products.id_src = 0

			if self.is_refresh_process():
				self._state.pull.process.products.total_view = 0

			product_filter_condition = {
				'limit': 1,
			}

			products_api = self.api('items', data = product_filter_condition)
			# if ModelChannelsWalmartca.is_production_mode() is False:
			# 	products_api = self.api('items/418971')

			if products_api.result != Response.SUCCESS and products_api.get('data') is None:
				return Response().error(code = Errors.WALMART_GET_PRODUCT_FAIL)

			products_api = products_api.data.get('ItemResponses', {})
			self._total_items = self._state.pull.process.products.total_view = to_int(products_api.get('totalItems', 0))
			self._state.pull.process.products.total = -1 if self.is_refresh_process() else self._total_items

			if self._DISABLE_PULLING:
				self._total_items = self._state.pull.process.products.total_view = 0
				self._state.pull.process.products.total = 0

		if self.is_order_process():
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			start_time = self.get_order_start_time(self._ORDER_FORMAT_TIME)
			last_modifier = self._state.pull.process.orders.max_last_modified
			self._order_start_create = self.get_create_start_date_walmartca(start_time)

			order_filter_condition = {
				"createdStartDate": self._order_start_create,
				'limit': 1
			}

			if last_modifier:
				# order_filter_condition['lastModifiedStartDate'] = last_modifier
				self.set_order_max_last_modifier(last_modifier)

			order_api = self.api('orders', data = order_filter_condition)

			# if not self.is_production_mode():
			# 	order_api = self.test_data('order_list')

			if order_api.result != Response.SUCCESS or order_api.data.get('errors'):
				return Response().stop(msg = 'Error when try to get the orders')

			total_count = to_int(order_api.get('data', {}).get('list', {}).get('meta', {}).get('totalCount', 0))
			self._state.pull.process.orders.total = total_count
		return Response().success()

	def get_create_start_date_walmartca(self, start_time_process: str) -> str:
		"""walmart_ca does not have a `max_last_modified` field,
		every order since the customers turned on the sync feature will be pulled
		`start_time` -> this function will compare if `start_time` exceeds
		30 days and will return the time 30 days ago compared to the present"""
		try:
			previous_month_days = datetime.now() - timedelta(days = 30)
			datetime_start_time = datetime.strptime(start_time_process, self._ORDER_FORMAT_TIME)
			return (
				datetime_start_time if datetime_start_time > previous_month_days
				else previous_month_days
			).strftime(self._ORDER_FORMAT_TIME)

		except Exception as e:
			log_traceback(e)
			return start_time_process

	def set_order_max_last_modifier(self, last_modifier) -> bool:
		if not last_modifier:
			return False

		last_modifier = last_modifier.replace('.000Z', 'Z')
		last_modifier_timestamp = to_timestamp(last_modifier, self._ORDER_FORMAT_TIME, False)
		order_max_last_timestamp = to_timestamp(self._order_max_last_modified, self._ORDER_FORMAT_TIME, False)
		if not self._order_max_last_modified or last_modifier_timestamp > order_max_last_timestamp:
			self._order_max_last_modified = last_modifier

		return True

	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear

	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		# try:
		# 	api_delete_categories = self.api('/categories', None, 'Delete', version = 2)
		# except Exception:
		# 	self.log_traceback()
		# 	return next_clear
		return next_clear

	def get_category_by_id(self, category_id):
		return Response().success()

	def get_categories_main_export(self):
		return Response().success()

	def get_categories_ext_export(self, categories):
		return Response().success()

	def convert_category_export(self, category, categories_ext):
		return Response().success()

	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']

	def product_export_is_finish(self) -> bool:
		return True if self._offset >= self._total_items else False

	def get_products_main_export(self) -> Response:

		def increase_offset_product() -> int:
			"""increase next offset each `get the products` turn"""
			self._offset += limit_data
			return self._offset

		if self._flag_finish_get:
			return Response().finish()

		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0

		limit_data = self._state.pull.setting.products
		limit_data = 5
		product_filter_condition = {
			'limit': limit_data,
			'offset': self._offset
		}

		products = self.api('items', data = product_filter_condition)
		# if ModelChannelsWalmartca.is_production_mode() is False:
		# 	products = self.api('items/418971')
		# 	products.data.ItemResponses.ItemResponse = [products.data.ItemResponses.ItemResponse]

		products_data = products.data.get('ItemResponses', {}).get('ItemResponse')

		if products.result != Response.SUCCESS or not products_data:
			if isinstance(products.data.get('ItemResponses', {}).get('totalItems', ''), int):
				self._flag_finish_get = True

			return Response().error(msg = 'Could not get the product data from Walmart')

		self.log_by_level(products, 'get_products_main_export', 1)

		new_offset = increase_offset_product()

		if products.data.get('errors', {}).get('error', {}).get('code') == 'CONTENT_NOT_FOUND.GMP_ITEM_QUERY_API':
			self._state.pull.process.products.imported = self._total_items
			self._flag_finish_get = True

			return Response().finish()

		if self.product_export_is_finish():
			self._flag_finish_get = True

		return Response().success(data = ModelChannelsWalmartca.dict_to_list(products_data))

	def get_product_main_export(self, product_id: str, main_product = False) -> Response:
		"""sync_product_from_channel"""
		if self._DISABLE_PULLING:
			return Response().finish()

		# product_raw = self.get_model_catalog().get(product_id)
		product = self.get_model_catalog().get(product_id, ['channel'])
		field_check = f'channel_{self._state.channel.id}'
		if not product or not product.get('channel', {}).get(field_check):
			return Response().finish()

		product_channel_id = product['channel'][field_check].get('sku')
		product_channel = self.get_product_by_id(product_channel_id)

		return product_channel

	def get_product_by_updated_at(self):
		# log warningpass
		return Response().success()

	def _clean_url_image(self, image_url: str) -> str:
		return image_url.split('?')[0]

	def _get_category_template(self, category_name: str = '', language: str = 'en') -> Prodict:
		category_path_api = dict()
		try:
			params = {
				'name': category_name
			}
			category_list: bool or dict = self.get_category_path(channel_type = 'walmartca', type_search = 'category/search', params = params)
			if not category_list or not category_list.get('data'):
				return Prodict()
			try:
				category_id = category_list['data'][0]['category_id']
			except (KeyError, IndexError):
				# TODO: get category from django
				log_traceback()
				return Prodict()

			category_path_api = self.get_category_path(channel_type = 'walmartca', type_search = f'category/{category_id}/attributes', params = '')
		except Exception as e:
			err = f'Error category name: `{category_name}` not found in category list or {e} exception.'
			self.log(err, 'exception_get_category_template')
			log_traceback()

		# func `get_category_path` return False if not found category
		result = Prodict.from_dict(category_path_api) if category_path_api else Prodict()
		return result

	def get_products_ext_export(self, products: Prodict) -> Prodict:
		"""get inventory product
		TODO: update after sync the product from the mainstore
		"""
		extend = Prodict()
		for product in products:
			extend.set_attribute(product.sku, Prodict())
			if to_str(product.publishedStatus).upper() != 'PUBLISHED':
				# walmartca does not allow qty to be taken if product status
				# is not `published`
				extend[to_str(product.sku)].inventory = 0
				continue

			inventory_res = self.api('inventory', data = {'sku': product.sku})
			if inventory_res.result != Response.SUCCESS or inventory_res.get('error'):
				extend[to_str(product.sku)].inventory = 0
				continue

			try:
				extend[to_str(product.sku)].inventory = inventory_res.data.get('inventory', {}).get('quantity', {}).get('amount', 0)

			except Exception:
				extend[to_str(product.sku)].inventory = 0
				self.log_traceback(msg = json.dumps(inventory_res))

		return Response().success(extend)

	def channel_sync_inventory(self, product_id, product: Product, products_ext):
		if self._state.channel.config.setting.get('price', {}).get('status') == 'disable':
			self._update_price = False
		if self._state.channel.config.setting.get('qty', {}).get('status') == 'disable':
			self._update_qty = False

		if not product.variants:
			self.cache_products.append(product)
		else:
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			for variant in product.variants:
				self.parent_variants[product['_id']].append(variant['_id'])
				self.cache_products.append(variant)

		return Response().success(product)

	def channel_sync_inventory_simple_product(self, product_sku, product: Product):
		# setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		# setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		# if not (setting_price and setting_qty):
		# 	return Response().success()
		#
		pass

	def get_product_id_import(self, convert: Product, product, products_ext) -> str:
		self._convert_product = False
		convert_product = self._convert_product_export(product, products_ext)
		if convert_product.result == Response.SUCCESS:
			self._convert_product = convert_product.data
			return convert_product.data.id
		elif convert_product.result == Response.SKIP:
			self._convert_product = Response.SKIP
			return product.get('variantGroupId')
		return product.wpid

	def get_product_by_id(self, product_id) -> Response:
		"""
		get the product update from walmart ca
		"""
		product_request = self.api(f'items/{product_id}')
		if product_request.result != Response.SUCCESS:
			if product_request.code:
				return Response().error(code = product_request.code)
			return Response().error(code = Errors.WALMART_GET_PRODUCT_FAIL)

		data = product_request.data.get('ItemResponses', {}).get('ItemResponse', {})

		return Response().success(data = data)

	def _get_variants_by_variant_group_id(self, product, variant_group_id) -> Response:
		"""
		get the variants from the variant_group_id
		"""
		pass

	def convert_product_export(self, product: Prodict, products_ext: Prodict) -> Response:
		try:
			convert_: Response = self._convert_product_export(product, products_ext)
		except Exception as e:
			err = product.get('sku', 'sku None') + ': ' + to_str(e)
			self.log_by_level(err, 'exception_convert_product_export', 3)
			return Response().error()

		return convert_

	@staticmethod
	def get_allow_update() -> str:
		update_fields = [
			'name',
			'lower_name',
			'price',
			'qty',
			'sku',
			'upc', 'gtin', 'isbn', 'ean',
			'product_type',
			'status',
			'is_in_stock',
			'category_name_list',
			'category_lower_name',
			'walmartca_status',
		]
		return ','.join(update_fields)

	def _convert_product_export(self, product: Prodict, products_ext: Prodict) -> Response:
		"""convert product data from walmart
		the products from walmart have three types: simple products, parent products, variant products
		get simple and parent products. variant products get followed by parent products
		"""

		def check_product_export() -> bool:
			"""check condition to convert a product or skip"""
			if self._convert_product:
				if self._convert_product == Response.SKIP:
					return Response().skip()
				return Response().success(self._convert_product)

			if not self._update_product_flow:
				# check if the product is already in the warehouse, get the variants by variantGroupId
				if product.get('variantGroupId') and self.get_product_warehouse_map(product.get('variantGroupId')):
					return Response().skip()

			return True

		def convert_basic_product_data() -> bool:
			"""convert basic product data"""
			nonlocal product_data
			product_data.name = product.get('productName', '')
			product_data.lower_name = product_data.name.lower()
			product_data.id = product.get('wpid', '')
			product_data.sku = product.get('sku', '')
			product_data.upc = product.get('upc', '')
			product_data.gtin = product.get('gtin', '')
			product_data.type = product.get('productType', '')

			# The status can be one of the following:
			# PUBLISHED, READY_TO_PUBLISH, IN_PROGRESS, UNPUBLISHED, STAGE, or SYSTEM_PROBLEM.

			product_data.status = True if product.get('publishedStatus') == 'PUBLISHED' else False
			product_data.price = product.get('price', {}).get('amount', 0)
			product_data.currency = product.get('price', {}).get('currency', 'CAD')
			product_data.weight_units = 'lb'

			shelf = list(set(literal_eval(product.get('shelf', '[]'))))
			for department in shelf:
				if department in ['Home Page', 'UNNAV']:
					continue
				product_data.category_name_list.append(to_str(department))

			product_data.category_lower_name = [cat.lower() for cat in product_data.category_name_list]
			product_data.qty = to_int(products_ext.get(product.sku, {}).get('inventory', 0))
			product_data.is_in_stock = product_data.qty > 0
			product_data.allow_update = ModelChannelsWalmartca.get_allow_update()
			# TODO: brand, description, images (main images + second images..) - webscrapes

			return True

		def convert_variant() -> bool:
			"""convert variant data if product have variants"""
			# TODO: walmart ca not response with variant group id
			nonlocal product_data
			variant_group_id = product.get('variantGroupId')
			variant_group = product.get('variantGroupInfo')
			if variant_group:
				for atr_wal in variant_group.get('groupingAttributes', []):
					atr = ProductAttribute()
					atr.attribute_type = 'select'
					# TODO: convert walmart attribute name when get it
					atr.attribute_name = atr_wal.get('name')
					atr.attribute_value_name = atr_wal.value
					# TODO: detect when use E or P
					atr.attribute_languages = 'English' or 'French'
					atr.attribute_value_languages = 'English' or 'French'
					product_data.attributes.append(atr)

			if variant_group_id:
				# TODO: followed when created new generate algro sku
				product_data.id = variant_group_id
				# TODO: get variant by sku
				variant_request = Response().success(data = {})
				if variant_request.result == Response.SUCCESS:
					product_data.qty = 12345678
					product_data.variants = [{}, {}]

			return True

		def convert_channel_data_product() -> bool:
			"""convert + assign channel data product"""
			nonlocal product_data, channel_data
			channel_data.wpid = product.get('wpid', '')
			channel_data['walmartca_status'] = to_str(product.lifecycleStatus).lower() or WalmartcaStatus.ACTIVE
			# TODO: get the variant_group_id
			# channel_data.variant_group_id = product.get('variant_group_id')
			# channel_data.primary_variant_on_walmart = product.get('variantGroupInfo', {}).get('isPrimary', '')

			# assign data to the product_data
			product_data.channel_data = channel_data
			# TODO: recheck when have django, current use the walmart flow make exception
			# in func `add_channel_to_convert_product`

			a = product_data.get('channel')
			# if not product_data.get('channel'):
			# 	product_data.channel = Prodict()
			return True

		check_product_export()
		product_data = Product()
		channel_data = Prodict()
		convert_basic_product_data()
		# convert_variant()  # currently, can not get the variants
		convert_channel_data_product()

		return Response().success(data = product_data)

	def get_category_id_by_name(self, category_name):
		pass

	def get_brand_id_by_name(self, brand_name):
		pass

	# https://stackoverflow.com/questions/28425705/python-round-a-float-to-nearest-0-05-or-to-multiple-of-another-float
	def round_to_multiple(self, x: float, a: float = 1) -> float:
		max_frac_digits = 100
		frac_digits = 0
		for i in range(max_frac_digits):
			if round(a, -int(math.floor(math.log10(a))) + i) == a:
				frac_digits = -int(math.floor(math.log10(a))) + i
				break
		return round(round(x / a) * a, frac_digits)

	def convert_weight_to_lbs(self, weight, unit) -> float:
		POUND = 2.2046226218488
		result = 0
		if unit in ['lbs', 'lb']:
			result = weight
		elif unit == 'oz':
			result = weight / 16
		elif unit == 'kg':
			result = weight * POUND
		elif unit == 'g':
			result = weight / 1000 * POUND
		else:
			pass
		# Shipping Weight need multipleOf 0.001
		return self.round_to_multiple(result, 0.001)

	def variants_to_walmart_data(self, convert, product, product_ext):
		pass

	def combine_object_attributes_template(self, item_specific: List[Prodict]) -> List[Prodict]:
		"""Because we need mapping object attributes.
		We divide the object's properties into parts:
		object -> `object_measure` + `object_unit`
		Func combines parts into the object
		If we missed one of the parts -> skip that object
		"""
		w_check = ['_Measure', '_Unit']
		atr_obj_list = list(filter(lambda atr: any(w in atr['name'] for w in w_check), item_specific))
		default_list = list(filter(lambda atr: (atr not in atr_obj_list), item_specific))
		convert_list = copy.deepcopy(default_list)

		for atr_m in atr_obj_list:
			if atr_m['name'].find('_Measure') != -1:
				atr_name = atr_m['name'].split('_Measure')[0]
				filter_unit = list(filter(lambda atr: (atr['name'] == atr_name + '_Unit'), atr_obj_list))
				if not filter_unit:
					continue
				atr_u = filter_unit[0]
				if atr_u['name'] == atr_name + '_Unit':
					convert_list.append(Prodict.from_dict({
						'mapping': '',
						'name': atr_name,
						'override': {
							'measure': atr_m['value'],
							'unit': atr_u['value']
						},
						'type': 'object',
						'value': {
							'measure': atr_m['value'],
							'unit': atr_u['value']
						}
					}))

		return convert_list

	def convert_string(self, name, value, category_required = None):
		"""convert value by convert_template_attributes"""
		return to_str(value)

	def convert_number(self, name, value, category_required = None):
		"""convert value by convert_template_attributes"""
		return to_decimal(value, 2)

	def convert_integer(self, name, value, category_required = None):
		"""convert value by convert_template_attributes"""
		return to_int(value)

	def convert_object(self, name, value, category_required: None or Prodict = None) -> dict:
		"""convert value by convert_template_attributes
		get category properties and validate each inner-object
		attribute_type can be: ['integer', 'number', 'string', 'object', 'array']
		"""

		bypass = False
		if bypass and not isinstance(value, dict):
			return {}

		validate_items = category_required.get(name, {}).get('items', {}).get('properties')
		validate_properties = category_required.get(name, {}).get('properties')
		validate_types = validate_items or validate_properties

		# object have english and french required
		# get one of them because they are same
		if validate_types.get('en') and validate_types.get('fr'):
			validate_types = validate_types['en']['type']
			validate_value = getattr(ModelChannelsWalmartca, f'convert_{validate_types}')(self, name, value, category_required)

		else:
			validate_value = {}

			if not isinstance(value, dict):
				return {}

			for name_, value_ in value.items():
				type_ = to_str(validate_types.get(name_, {}).get('type'))
				validate_value[name_] = getattr(ModelChannelsWalmartca, f'convert_{type_}')(self, name, value_, category_required)

		return validate_value

	def convert_array(self, name, value: Prodict, category_required: None or Prodict = None):
		"""convert value by convert_template_attributes"""
		validate_types = category_required.get(name, {}).get('items', {}).get('type')
		value_list = []
		for value_ in value:
			validate_value_ = getattr(ModelChannelsWalmartca, f'convert_{validate_types}')(self, name, value_, category_required)
			value_list.append(validate_value_)

		return value_list

	def convert_template_attributes(self, name_category_template: str, template_attribute_raw: Dict[str, any], product_id) -> Prodict:
		"""Template attribute save in string
		attribute value have different types: string, list, object(json)
		Walmart have 5 attributes type: string, array[string - object], number, integer, object
		product_short_description - shortDescription
		product_long_description - longDescription
		"""

		# TODO: mapping latter
		# template_attribute: List[Prodict] = self.combine_object_attributes_template(template_attribute_raw)
		# TODO: mapping french latter

		# template_combine [0] -> english , [1] -> french
		template_combine = []
		template_attribute_en_uncombine: List[Prodict] = template_attribute_raw.get('english', [Prodict])
		template_attribute_fr_uncombine: List[Prodict] = template_attribute_raw.get('french', [Prodict])

		template_attribute_en = self.combine_object_attributes_template(template_attribute_en_uncombine)
		template_attribute_fr = self.combine_object_attributes_template(template_attribute_fr_uncombine)

		if not self._category_template.get(name_category_template):
			self._category_template[name_category_template] = self._get_category_template(name_category_template)

		category_required = self._category_template[name_category_template].get('properties', {})

		for template_attribute in [template_attribute_en, template_attribute_fr]:
			template_convert = []
			for attribute in template_attribute:
				try:

					atr_type = attribute.get('type') or category_required.get(attribute.name).get('type')
					atr_value = getattr(ModelChannelsWalmartca, f'convert_{atr_type}')(self, attribute.name, attribute.value, category_required)
					add = Prodict(**{'name': attribute.name, 'value': atr_value})
					template_convert.append(add)

				except Exception as e:
					msg_error = f"Category Template Error: The {attribute.name}'s value is invalid"
					self.cache_errors[product_id].append(msg_error)
					data = {'Error': e, 'attribute': attribute}
					self.log_by_level(data, 'exception_convert_template_attributes', 3)
					continue

			template_clean: List = self.clean_template_convert(template_convert)
			template_combine.append(template_clean)
		template_result = self.combine_template(template_combine, category_required)

		return Response().success(data = template_result)

	def combine_template(self, template_combine: list, category_required: dict) -> list:
		"""combine english template, french template
		parameters
		----------
		template_combine: List - [0], [1] = english attributes, french attributes
		template_combine value: - List[Dict('name': '', 'value': '')])

		return
		------
		result : list of value

		object and array can be required or not
		check object and array. if an attribute has required mapping value from english, french template
		walmart required an english attribute. if the attribute from french template but not has english -> skip
		TODO: special case: variant attributes - get a list from variantAttributeNames
		"""
		final_template, result = {}, []
		variants = []

		# english attributes
		for atr in template_combine[0]:
			if atr['name'] == 'variantAttributeNames':
				variants = atr['value']

			# if feed is
			final_template[atr['name']] = {}
			if category_required[atr['name']].get('required') and category_required[atr['name']].get('type') == 'object':
				final_template[atr['name']] = {'en': atr['value']}

			elif category_required[atr['name']].get('type') == 'array' and category_required[atr['name']]['items'].get('required'):
				if 'en' in category_required[atr['name']]['items']['required']:
					final_template[atr['name']] = [{'en': ele} for ele in atr['value']]

				else:
					final_template[atr['name']] = atr['value']

			else:
				final_template[atr['name']] = atr['value']

		if template_combine[1]:
			# french attributes
			for atr in template_combine[1]:
				if not final_template.get(atr['name']):
					continue

				if category_required[atr['name']].get('required') and category_required[atr['name']].get('type') == 'object':
					final_template[atr['name']].update({'fr': atr['value']})
				elif category_required[atr['name']].get('type') == 'array' and category_required[atr['name']]['items'].get('required'):

					if 'en' in category_required[atr['name']]['items']['required']:
						for obj in final_template[atr['name']]:
							obj.update({'fr': atr['value'].pop(0) if atr['value'] else ''})

				else:
					# not override english attributes
					if not isinstance(final_template[atr['name']], dict):
						continue

					final_template[atr['name']] = atr['value']

		for name, value in final_template.items():
			if name in variants:
				if isinstance(value, dict) and value.get('en'):
					value = {
						'en': value['en'],
						'fr': value.get('fr', '') or value['en']
					}

				elif isinstance(value, list):
					value_new = []
					for val_ in value:

						if val_.get('en'):
							value_new.append(
								{
									'en': val_['en'],
									'fr': val_.get('fr', '') or val_['en']
								}
							)
					value = value_new

			result.append({'name': name, 'value': value})

		return result

	def clean_template_convert(self, template_convert: List) -> List:
		"""
		Remove empty, null attributes
		Remove empty object dict in list
		TODO: assembled unit, measure missed one
		If the attribute have (unit, measure) but missed one
		"""

		template_convert_copy = copy.deepcopy(template_convert)
		template_clean = []
		for atr in template_convert_copy:
			check = True
			atr_val = atr['value']

			if not atr_val or atr_val == 'null':
				continue

			elif isinstance(atr_val, list) and not atr_val[0]:
				continue

			elif isinstance(atr_val, list) and isinstance(atr_val[0], dict):
				# add atr have both name and value
				try:
					atr_clean = []
					for atr_item in atr_val:
						atr_item_clean = dict()
						for k, v in atr_item.items():
							if k and v:
								atr_item_clean[k] = v
						atr_clean.append(atr_item_clean)
					atr['value'] = atr_clean
				except:
					continue

			elif isinstance(atr_val, list):
				atr['value'] = [atr_ for atr_ in atr_val if atr_.strip()]

			elif isinstance(atr_val, dict):
				for k, v in atr_val.items():
					if not (k and v):
						check = False
						break

			if check:
				template_clean.append(atr)

		return template_clean

	def create_mp_product(self, product: Product) -> Response:
		def remove_variant_field() -> bool:
			for field_del in cat_data.get('variantAttributeNames', []):
				try:
					del cat_data[field_del]
				except (KeyError, IndexError):
					continue

			variant_field_list = ['variantGroupId', 'isPrimaryVariant', 'variantAttributeNames']
			for field_del in variant_field_list:
				try:
					del cat_data[field_del]
				except (KeyError, IndexError):
					continue

			return True

		product_data = Prodict()
		template_attributes = []
		category_1, category_2 = '', ''
		# product_data.SkuUpdate = 'No'  # check when change mode, optional
		# product_data.ProductIdUpdate = 'Yes'  # optional

		# MAP CATEGORY TEMPLATE
		# walmart_ca have two level category - get from template
		try:
			category_path = product.template_data.get('category', {}).get('category', {}).get('path')
			category_1, category_2 = category_path.replace(' ', '').split('>')

			template_attributes: List[Dict] = product.template_data.get('category', {}).get('category', {}).get('specifics', [])

		except (IndexError, KeyError, AttributeError):
			if self.is_production_mode() is False:
				template_attributes = [{'name': 'brand', 'value': 'Test LitCommerce'}]
				category_1 = 'Electronics'
				category_2 = 'ElectronicsAccessories'
			else:
				self.cache_errors[product['_id']].append(Errors().get_msg_error(Errors.WALMART_MISSING_CATEGORY_TEMPLATE))
				return Response().error(code = Errors.WALMART_MISSING_CATEGORY_TEMPLATE)
		except Exception as e:
			a = e

		# TODO: clean data from the category template

		product_data.productName = strip_html_tag(product.name)
		product_data.msrp = to_decimal((product.msrp or product.price), 2)
		parent_group_id = to_str(product.parent_group_id) if product.get('parent_group_id') else ''
		variant_id = product.get('variant_group_id') or parent_group_id

		cat_data = Prodict()  # category data
		# cat_data.shortDescription = nl2br(html.escape(product.description), False)[:4000].replace('<br>\n', '')
		# cat_data.shortDescription = self.strip_html_from_description(product.description)[:4000].replace('\n', '&#xD;')
		cat_data.shortDescription = self.strip_html_from_description(product.description)[:4000].replace('\n', '')
		cat_data.mainImageUrl = product.thumb_image.url
		cat_data.brand = product.get('brand')
		cat_data.variantGroupId = variant_id
		cat_data.isPrimaryVariant = 'Yes' if product.get('is_primary_variant') else 'No'

		if template_attributes:
			for atr in template_attributes:
				if not atr.get('value'):
					continue

				cat_data[atr['name']] = atr['value']

		if not variant_id:
			remove_variant_field()

		if product.images:
			second_images = [img['url'] for img in product.images]
			cat_data.update({
				'productSecondaryImageURL': {
					'productSecondaryImageURLValue': second_images
				}
			})

		# product_data.category_1 = Prodict()
		# product_data.category_1.category_2 = cat_data
		product_data['category'] = dict()
		product_data['category'].update({
			category_1: {
				category_2: cat_data
			}
		})

		if not cat_data['shortDescription']:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_DESCRIPTION_IMAGES))
			return Response().error(code = Errors.WALMART_MISSING_DESCRIPTION_IMAGES)

		if not cat_data['mainImageUrl']:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_DESCRIPTION_IMAGES))
			return Response().error(code = Errors.WALMART_MISSING_DESCRIPTION_IMAGES)

		# if not name_category or name_category == self._NOT_FOUND_CATEGORY:
		# 	self.cache_errors[product['_id']].append(Errors().get_msg_error(Errors.WALMART_MISSING_CATEGORY_TEMPLATE))
		# 	return Response().error(code = Errors.WALMART_MISSING_CATEGORY_TEMPLATE)

		return Response().success(data = product_data)

	def create_mp_price(self, product: Product) -> Response:
		"""legacy code
		 schema from mp_item / mp_offer xml """

		price = to_decimal(product.price, 2)
		start_date = datetime.now().strftime('%Y-%m-%d')
		end_date = (datetime.now() + timedelta(weeks = 260)).strftime('%Y-%m-%d')
		product_tax_code = '2038710'
		shipping_weight = {
			'measure': self.convert_weight_to_lbs(product.weight, product.weight_units),
			'unit': 'lb'
		}

		offer = {
			'price': price,
			'StartDate': start_date,
			'EndDate': end_date,
			'ShippingWeight': shipping_weight,
			'ProductTaxCode': product_tax_code
		}

		return Response().success(data = offer)

	def validate_product_sku(self, original_sku: str) -> str:
		"""allow character, number, underscore, dash
		remove space, special character"""
		validate_sku = ''.join(c_ for c_ in original_sku
		                       if c_.isalnum() or c_ in ['-', '_'])
		return validate_sku

	def remove_attributes_except_some_tag(self, text: str) -> str:
		"""remove html tag attributes, keep
		tag `a` and `img`"""
		# keep_tags = ['a', 'img']
		keep_tags = []  # walamrtca not allow urls in the product description
		text_bs = BeautifulSoup(text)
		for tag in text_bs.find_all(True):
			if tag.name not in keep_tags:
				tag.attrs = {}

			else:
				attrs = dict(tag.attrs)
				for attr in attrs:
					if attr not in ['src', 'href']:
						del tag.attrs[attr]

		return str(text_bs)
	def url_escape(self, url_raw: str):
		"""URL escape character
		url_raw = 'http(s)://www.google.com'
		"""
		split_char = '://'
		url_base, url_link = url_raw.split(split_char, 1)
		return url_base + split_char + parse_quote(url_link)


	def description_cut(self, description: str) -> str:
		if not self.is_clean_description():
			return description

		CHARACTER_LIMIT = 4000
		return self.strip_html_from_description(description[:CHARACTER_LIMIT])

	def product_to_walmart_data_ver4(self, product: Product) -> Response:
		"""
		Walmart CA use the same feed format for a new item, maintenance, price
		"""
		"""
		orderable: 
			required: sku, mainImageUrl, brand, productName, ShippingWeight (convert to lb), productTaxCode,
					productIdentifiers, shortDescription, price, 
					startDate, endDate, productTaxCode, 
			other - not have in categories, update to template when fetch from django	
				SkuUpdate, keyFeatures, features,
				msrp, countryOfOriginAssembly,  manufacturer, warrantyText, warrantyURL,
				shipsInOriginalPackaging, MinimumAdvertisedPrice, MustShipAlone, manufacturerPartNumber
				keywords, electronicsIndicator, isChemical, isPesticide, isAerosol, batteryTechnologyType,
				isTemperatureSensitive,	additionalProductAttributes, smallPartsWarnings
		"""

		def remove_variant_field() -> bool:
			"""If not have variant_id, remove the variant fields relevant
			1. variant product have only one variant: remove in func `product_import`,
			func `channel_product_update`
			2. a simple product use a variant template
			"""
			nonlocal visible
			for field_del in visible[name_category].get('variantAttributesNames', []):
				try:
					del visible[name_category][field_del]
				except (KeyError, IndexError):
					continue

			variant_field_list = ['variantGroupId', 'isPrimaryVariant', 'variantAttributeNames']
			for field_del in variant_field_list:
				try:
					del visible[name_category][field_del]
				except (KeyError, IndexError):
					continue

			return True

		def remove_empty_variant_attributes() -> bool:
			"""clear product variant
			get only field can get from visible"""
			nonlocal visible
			list_variant = []
			for field_remove in visible[name_category].get('variantAttributeNames', []):
				if visible[name_category].get(field_remove):
					list_variant.append(field_remove)

			if list_variant or visible[name_category].get('variantAttributeNames'):
				visible[name_category]['variantAttributeNames'] = list_variant

				if not list_variant:
					del visible[name_category]['variantAttributeNames']

			return True

		def format_product_id(product_id_, product_id_type_) -> str:
			"""Walmart required Product ID digit lengths and verify that the format
			https://sellerhelp.walmart.com/seller/s/guide?language=en_US&article=000007156
			UPC: 12 digit-number
			GTIN: 14 digit-number
			ISBN: 10 or 13 digit-number
			EAN: 13 digit-number
			"""

			len_required = {
				'UPC': 12,
				'GTIN': 14,
				'EAN': 13
			}
			# if product_id is custom -> return product_id;
			# case: the product without product id
			if product_id_.upper().find('CUSTOM') != -1:
				return product_id_

			len_id = to_len(product_id_)
			len_missed = len_required.get(product_id_type_, 0) - len_id

			if len_missed <= 0 or product_id_type_ == 'ISBN':
				return product_id_

			right_format = '0' * len_missed + product_id_

			return right_format

		def set_product_id() -> (str, str):
			"""get product id from the mainstore.
			# TODO: recheck canada allow or not use CUSTOM
			if can't find product id use CUSTOM field
			and override response error when get the response
			"""

			product_id_, product_id_type_ = '', ''
			for field_ in self._LIST_PRODUCT_ID_TYPE:
				product_id_ = product.get(field_)
				if product_id_:
					product_id_type_ = field_.upper()
					break

			product_id_ = 'CUSTOM' if not product_id_ else to_str(product_id_)
			product_id_ = format_product_id(product_id_, product_id_type_)

			if product_id_ == 'CUSTOM':
				product_id_type_ = 'GTIN'

			return product_id_type_, product_id_

		def get_en_and_fr() -> dict:
			pass

		def convert_validate_product_id():
			"""validate before convert"""
			nonlocal product
			id_check = {
				'gtin': product.gtin,
				'upc': product.upc,
				'ean': product.ean,
			}
			id_validate = self.validate_product_id(id_check)
			for type_, id_ in id_validate.items():
				product[type_] = id_

		# TODO: check when flow maintain the product not create the new items
		orderable_list = ['keyFeatures', 'features', 'brand', 'MinimumAdvertisedPrice', 'shipsInOriginalPackaging',
		                  'MustShipAlone', 'hsCode', 'countryOfOriginAssembly', 'productTaxCode', 'manufacturer',
		                  'warrantyText', 'warrantyURL', 'keywords', 'electronicsIndicator', 'isChemical', 'isPesticide',
		                  'isAerosol', 'batteryTechnologyType', 'isTemperatureSensitive', 'manufacturerPartNumber',
		                  'additionalProductAttributes', 'smallPartsWarnings']
		NAME_CHARACTER_LIMIT = 200
		# 'productName': self.title_cutting(strip_html_tag(product.name), NAME_CHARACTER_LIMIT),
		product_data, orderable, visible = Prodict(), Prodict(), Prodict()
		convert_validate_product_id()
		product_id_type, product_id = set_product_id()
		product_name = {'en': self.title_cutting(strip_html_tag(product.name), NAME_CHARACTER_LIMIT)}
		product_sku = to_str(product.sku)

		template_attributes_category = list()

		if product.variants and product.src.channel_type == 'shopify':
			product_sku += '-parent'
			self._extend_product_map['sku'] = product_sku

		try:
			template_attributes_raw = product.template_data.category
			name_category_template = product.template_data.category.category.name.split(' > ')[0]

		except:
			template_attributes_raw = Prodict()
			name_category_template = ''

		if template_attributes_raw:
			convert_template = self.convert_template_attributes(name_category_template, template_attributes_raw, product['_id'])

			if convert_template.result != Response.SUCCESS:
				msg_error = convert_template.get('msg')
				return Response().error(msg = msg_error)

			template_attributes_category = convert_template.data

		name_category = to_str(name_category_template or self._NOT_FOUND_CATEGORY)
		template_attributes = template_attributes_category or []

		try:
			fr_title = product.template_data.fr_title.fr_title
			fr_description = product.template_data.fr_title.fr_description

		except:
			fr_title = ''
			fr_description = ''

		if fr_title:
			product_name['fr'] = self.title_cutting(strip_html_tag(fr_title), NAME_CHARACTER_LIMIT)

		orderable = {
			'productName': product_name,
			'shortDescription': {
				# "en": self.remove_attributes_except_some_tag(product.description),
				# CDATA tags is blocked by Walmart's firewall
				'en': self.description_cut(
					self.remove_attributes_except_some_tag(product.description)
				).replace('<![CDATA[', '').replace(']]>', '')
			},
			'mainImageUrl': self.url_escape(product.thumb_image.url),
			'sku': product_sku,
			'productIdentifiers': {
				'productIdType': product_id_type,
				'productId': product_id
			},
			'price': to_decimal(product.price, 2),
			'ShippingWeight': {
				'measure': self.convert_weight_to_lbs(product.weight, product.weight_units),
				'unit': 'lb'
			}
		}
		if fr_description:
			# orderable['shortDescription']['fr'] = self.remove_attributes_except_some_tag(fr_description)
			orderable['shortDescription']['fr'] = self.replace_description(fr_description)

		# default, override product sku because walmart_ca can't pull product -> linked by push the products
		# if client change sku or product_id need change feed to feed create new product
		if not self._update_product_flow and (product.get('sku_update') or product.get('is_sku_override')):
			orderable['SkuUpdate'] = 'Yes'

		if not self._update_product_flow and product.get('product_id_update'):
			# currently, the productIdUpdate field is in the visible section but only in 4 category
			# visible[name_category]['ProductIdUpdate'] = 'Yes'
			orderable['SkuUpdate'] = 'No'  # override
		#
		# if not self._update_product and product.get('sku_update'):
		# 	orderable['SkuUpdate'] = 'Yes'

		orderable['endDate'] = (datetime.now() + timedelta(weeks = 260)).strftime('%Y-%m-%d')
		# Test mode only
		if ModelChannelsWalmartca.is_production_mode() is False:
			orderable['endDate'] = (datetime.now() + timedelta(days = 1)).strftime('%Y-%m-%d')

		# the brand gets twice, one from the product attributes
		# and one from the category template
		if product.brand:
			orderable.update({
				'brand':
					{'en': to_str(product.get('brand'))}
			})

		# product tax code
		orderable['productTaxCode'] = to_int(product.get('template_data', {}).get('category', {}).get('tax', {}).get('tax_code', 0)) or 2038710
		# tax_category = to_int(product.get('template_data', {}).get('category', {}).get('tax', {}).get('tax_code', 0))

		# the parent_group_id is the id is generated when transfer from
		# the mainstore to the channel walmart - function get_draft_extend_channel_data
		# TODO: check variant_group_id when pull from walmart canada
		parent_group_id = to_str(product.parent_group_id) if product.parent_group_id else ''
		variant_id = parent_group_id or product.get('variant_group_id')
		visible = {
			name_category: {
				'variantGroupId': variant_id,
				'isPrimaryVariant': 'Yes' if product.get('is_primary_variant') else 'No'
			}
		}

		if product.images:
			orderable['productSecondaryImageURL'] = [
				self.url_escape(img['url']) for img in product.images
			]

		if product.msrp:
			orderable['msrp'] = self.round_to_multiple(product.msrp, 0.01)

		if template_attributes:
			for atr in template_attributes:
				if not atr['value']:
					continue

				if atr['name'] in orderable_list:
					orderable[atr['name']] = atr['value']
					continue

				visible[name_category][atr['name']] = atr['value']

		if not variant_id:
			remove_variant_field()

		remove_empty_variant_attributes()

		if not orderable['shortDescription']['en']:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_DESCRIPTION_IMAGES))
			return Response().error(code = Errors.WALMART_MISSING_DESCRIPTION_IMAGES)

		if not orderable['mainImageUrl']:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_DESCRIPTION_IMAGES))
			return Response().error(code = Errors.WALMART_MISSING_DESCRIPTION_IMAGES)

		# if not product_id:
		# 	self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_PRODUCT_ID))
		# 	return Response().error(code = Errors.WALMART_MISSING_PRODUCT_ID)

		if not product_sku:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_PRODUCT_SKU))
			return Response().error(code = Errors.WALMART_MISSING_PRODUCT_SKU)

		if not name_category or name_category == self._NOT_FOUND_CATEGORY:
			self.cache_errors[product['_id']].append(Errors().get_msg_error(Errors.WALMART_MISSING_CATEGORY_TEMPLATE))
			return Response().error(code = Errors.WALMART_MISSING_CATEGORY_TEMPLATE)

		product_data = {
			"Orderable": orderable,
			"Visible": visible
		}

		return Response().success(product_data)

	def product_to_walmart_data(self, product: Product) -> Response:
		"""
		Legacy code - version 3, currently using version 4
		Walmart CA use the same feed format for a new item, maintenance, price
		If the seller wants to create the new items: need mp_item + mp_offer feed
		-> processMode = `CREATE`
		If the seller wants to maintain the price or the product use `REPLACE_ALL`
		`PARTIAL_UPDATE`: update parts of the product, product feed only

		---MP_ITEM---
		processMode
		feedDate
		sku
		productId
		`MPProduct`
		`MPOffer` (This field is must include when create the new items)
		------------
		"""
		# TODO: check when flow maintain the product not create the new items
		if not self._update_product_flow:
			process_mode = self._FEED_TYPE['create']
		else:
			process_mode = self._FEED_TYPE['replace_all']

		mp_product = self.create_mp_product(product)
		if mp_product.result != Response.SUCCESS:
			return mp_product

		mp_offer = self.create_mp_price(product)

		product_id_list = dict()  # TODO: recheck list of id or only one id
		product_id_list['productIdentifier'] = list()

		# check product id, if have add to list
		for id_type in self._LIST_PRODUCT_ID_TYPE:
			if product.get(id_type):
				product_id_list['productIdentifier'].append(
					{
						'productIdType': id_type.upper(),
						'productId': product[id_type]
					}
				)

		product_data = {
			'processMode': process_mode,
			'feedDate': ModelChannelsWalmartca.get_current_time_feed(),
			'sku': product.get('sku'),
			'productIdentifiers': product_id_list,  # list of product id code
			'MPProduct': mp_product.data,
			'MPOffer': mp_offer.data
		}

		if not product_id_list:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_PRODUCT_ID))
			return Response().error(code = Errors.WALMART_MISSING_PRODUCT_ID)

		if not product.sku:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_PRODUCT_SKU))
			return Response().error(code = Errors.WALMART_MISSING_PRODUCT_SKU)

		return Response().success(product_data)

	def product_import(self, convert, product, products_ext) -> Response:
		try:
			result_ = self.product_import_(convert, product, products_ext)
		except Exception as e:
			err = product.get('sku', 'sku None') + ': ' + to_str(e)
			self.log_by_level(err, 'exception_product_import', 3)
			return Response().error()

		return Response().success()

	def product_import_(self, convert, product, products_ext) -> Response:
		"""get product to add to cache_products
		link product[_id] to two lists: products don't have variant and products have variants
		if product have variants - link between the parent product and variants

		Publish the new product to walmart
		"""
		product.pull_from_walmart_ca = self.is_product_pull_from_walmart_ca(product)
		if not product.variants:
			self.cache_products.append(product)
			product.sku = self.validate_product_sku(product.sku)
			if product.get('is_sku_override'):
				self._update_product_code = True

		else:
			product = self.mapping_missing_field_variant(product)
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			parent_id = ModelChannelsWalmartca.random_sku(length = 20)
			min_price_variant = min([variant['price'] for variant in product.variants])
			have_primary = False  # TODO: set the first variants has lowest price is the primary
			for index, variant in enumerate(product.variants):
				# Check if the product `mapping` have data in channel walmart
				# or product get status
				# check = self.get_product_map(variant['_id'])
				# if the product is check means the products are already in walmart
				# if check:
				# 	continue

				if product.get('is_sku_override'):
					self._update_product_code = True

				variant.pull_from_walmart = product.pull_from_walmart
				variant.sku = self.validate_product_sku(variant.sku)
				# assign the variants with same parent id
				variant.parent_group_id = product.get('group_id') or parent_id

				if not variant.thumb_image.url:
					variant.thumb_image.url = product.thumb_image.url

				if not have_primary and variant.price == min_price_variant:
					have_primary = True
					variant['is_primary_variant'] = True

				if product.variant_count == 1:
					variant.parent_group_id = ''

				# Update the variant to cache_product. Prepare for the feed product
				# WALMART treats a product variant as a product
				self.parent_variants[product['_id']].append(variant['_id'])
				self.cache_products.append(variant)

		return Response().success()

	def create_error_message(self, ingestion_err: dict, product_id: str) -> str:
		self._feed_has_error = True
		if isinstance(ingestion_err, dict):
			msg = ingestion_err.get('description', '')

		else:
			# TIMEOUT ERROR return text
			msg = to_str(ingestion_err)

		# Log the product error:
		product = list(filter(lambda product_: product_['_id'] == product_id, self.cache_products))[0]
		self.log_by_level(
			{
				'error_description': msg,
				'product_data': product
			},
			'products_have_error', 3)

		if msg.find(' The Product ID already exists in your seller catalog') != -1:
			id_type = ''
			product = list(filter(lambda product_: product_['_id'] == product_id, self.cache_products))
			if not product:
				return msg

			product = product[0]
			for type_ in self._LIST_PRODUCT_ID_TYPE:
				if product.get(type_):
					id_type = type_
					break
					
			msg = Errors().get_msg_error(Errors.WALMART_PRODUCT_ID_DUPLICATE).format(id_type.upper(), id_type.upper())

		if msg.find('Main image URL setup failed') != -1 or msg.find("We couldn't download the image from your URL") != -1:
			self._republish_feed = True

		# expected maxLength: 4000, actual: 4354 for shortDescription
		if msg.find('expected maxLength: 4000') != -1 and msg.find('shortDescription') != -1:
			msg = Errors().get_msg_error(Errors.WALMART_DESCRIPTION_LIMIT)
		if msg.lower().find('maxlength') != -1 and msg.lower().find('actual') != -1:
			nums = re.findall(r'\d+', msg)
			if len(nums) == 2:
				err_field = str(msg.split()[-1]).title()
				msg = Errors().get_msg_error(Errors.WALMART_CHAR_LIMIT).format(err_field, nums[0], nums[1])
				
		return msg

	def get_feed_item_report(self, feed_response: Prodict) -> bool:
		"""
		get a list of product successes and fail when pushing the feed
		create error msg
		with a system error, the status of the products did not have sku and id
		-> we can't map the product `sku` and the product `_id`

		# TODO: update error response `system_error`, `timeout_error`
		"""

		def get_success_product_data():
			"""get product id from walmart"""
			if not isinstance(item.get('productIdentifiers'), dict):
				return False  # feed price, inventory not response product_id

			if not item.get('productIdentifiers', {}).get('productIdentifier'):
				return False

			product_sku = item.get('sku')
			for product in self.cache_products_insert.values():
				if product['sku'] != product_sku:
					continue

				product['wpid'] = item.get('wpid', '')
				product['wm_itemid'] = item.get('itemid', '')
				product['mart_id'] = item.get('martId')

				identifier_list = ModelChannelsWalmartca.dict_to_list(item.get('productIdentifiers', {}).get('productIdentifier', []))
				for id_ in identifier_list:
					id_name = id_.get('productIdType').lower()
					if id_name not in ['gtin', 'upc', 'ean', 'isbn']:
						continue
					product[id_name] = id_.get('productId', '')

				break

			return True

		try:
			item_list = feed_response["PartnerFeedResponse"]["itemDetails"]["itemIngestionStatus"]
		except (KeyError, IndexError):
			return False

		if not item_list:
			return False

		# Convert from xml to json when having one item not go to list type
		if not isinstance(item_list, list):
			item_list = [item_list]

		for item in item_list:
			ingestion_status = item.get('ingestionStatus')
			product_id = ''

			if ingestion_status == self.INGESTION['success']:
				get_success_product_data()
				continue

			elif ingestion_status == self.INGESTION['data']:
				product_id = self.cache_products_sku_index.get(item['sku'], {}).get('_id')

			elif ingestion_status == self.INGESTION['system']:
				index_item = item.get('index', '-1')
				for val in self.cache_products_sku_index.values():

					if val.get('index') == index_item:
						product_id = val.get('_id')
						break

			elif ingestion_status == self.INGESTION['timeout']:
				product_id = self.cache_products_sku_index.get(item['sku'], {}).get('_id')
				item.update({
					'ingestionErrors': {
						'ingestionError': Errors().get_msg_error(error_code = Errors.WALMART_FEED_TIMEOUT)
					}
				})

			if not product_id:
				continue

			ingestion_errors = item.get('ingestionErrors', {}).get('ingestionError', list())
			msg_error = ''

			if not isinstance(ingestion_errors, list):
				ingestion_errors = [ingestion_errors]

			for ingestion_err in ingestion_errors:
				if msg_error:
					msg_error += '_lic_nl_' + self.create_error_message(ingestion_err, product_id).replace('\n', '')
				else:
					msg_error += self.create_error_message(ingestion_err, product_id).replace('\n', '')

			try:
				self.cache_errors[product_id].append(to_str(msg_error))
			except (AttributeError, KeyError, IndexError):
				# TODO: fix cache_product_sku share mutable
				continue

		return True

	def create_image_url_proxy(self, img_url: str) -> str:
		if not img_url:
			return ''

		return f'{self.URL_IMAGE_PROXY}{img_url}'

	def check_cache_error_republish(self):
		"""func for republish feed - check error in cache_error
		and update the product attributes to republish
		"""

		def convert_image_proxy() -> str:
			"""convert url image to proxy url image"""
			nonlocal product

			product['thumb_image']['url'] = self.create_image_url_proxy(product['thumb_image']['url'])

			if not product.get('images') or not isinstance(product['images'], list):
				return 'Convert done.'

			for idx, img in enumerate(product['images']):
				product['images'][idx]['url'] = self.create_image_url_proxy(product['images'][idx]['url'])

			return 'Convert done.'

		for _id, err_list in self.cache_errors.items():
			if err_list:
				product_filter = list(filter(lambda p: p['_id'] == _id, self.cache_products))

				if not product_filter:
					continue

				product = product_filter[0]

				if any([err.find('Main image URL setup failed') != -1 or err.find("We couldn't download the image from your URL") != -1 for err in err_list]):
					convert = convert_image_proxy()

		return True

	def get_sleep_time(self, recall: int) -> int:
		"""wait time to get a result from walmart
		return the seconds to wait the feed
		"""
		# if get_config_ini('walmart', 'mode') in self._TEST_MODE:
		# 	return 10

		if self.is_production_mode() is False:
			return 60

		recall_threshold = 30
		recall += 1
		second_ = 60
		return recall * second_ if recall < recall_threshold else 30 * second_

	def check_feed_status(self, response, time_sleep = 5, feed_type = 'item'):
		"""
		Check feed result and update response from walmart
		Flow:
		1. Check feed process and item processing. Feed can be PROCESSED
		but item still processing
		2. Get result for each item
		3. Because the feed limit is 50 products.
		We will need to use `offset` to get all products response
		4. Send data to func `get_product_feed` or response error
		"""

		process_status_list = ['RECEIVED', 'INPROGRESS']
		# walmart can take 24 - 48 hours before the feed processed
		recall, max_check_round = 0, 100
		offset, limit = 0, 50
		check_item_processing = True
		feed_params = {
			'includeDetails': 'true',
			'offset': offset,
			'limit': limit,
		}

		if response.result != Response.SUCCESS:
			if response.code:
				return Response().error(code = response.code)
			return Response().error(code = Errors.WALMART_PUSH_PRODUCT_ERROR)

		feed_id = response.data.get('FeedAcknowledgement', {}).get('feedId', '')
		if not feed_id:
			return Response().error(code = Errors.WALMART_PUSH_PRODUCT_ERROR)

		response_feed = self.api(f'feeds/{feed_id}', data = feed_params, api_type = 'get')
		feed_status = response_feed.data.get('PartnerFeedResponse', {}).get('feedStatus')

		while (feed_status in process_status_list or check_item_processing) and recall < max_check_round:
			recall += 1
			time.sleep(self.get_sleep_time(recall))
			response_feed = self.api(f'feeds/{feed_id}', data = feed_params, api_type = 'get')

			if response_feed.result != Response.SUCCESS:
				feed_status = 'ERROR'
				continue

			check_item_processing = True if to_int(response_feed.data.get('PartnerFeedResponse', {}).get('itemsProcessing', 0)) != 0 else False

			feed_status = response_feed.data.get('PartnerFeedResponse', {}).get('feedStatus', 'ERROR')

		# get all the items when the feed have > 50 items
		total_items = to_int(response_feed.data.get('PartnerFeedResponse', {}).get('itemsReceived', 0))
		offset += limit

		while total_items > offset:
			feed_params.update({
				'offset': offset
			})
			res_get = self.api(f'feeds/{feed_id}', data = feed_params, api_type = 'get')

			if res_get.result != Response.SUCCESS:
				break

			try:
				data = res_get.data['PartnerFeedResponse']['itemDetails']['itemIngestionStatus']
			except(KeyError, IndexError):
				data = []

			response_feed.data['PartnerFeedResponse']['itemDetails']['itemIngestionStatus'] += data
			offset += limit

		if feed_status == 'PROCESSED':
			try:
				feed_item_detail = self.get_feed_item_report(response_feed.data)
				return Response().success()
			except Exception as e:
				self.log_by_level(e, log_file = 'exception_get_feed_report', current_level = 3)

		elif feed_status == 'ERROR':
			self.log('The feed submit id {} has problems: {}'.format(response_feed.data.get('feedId'), response_feed.data.get('feedStatus')), 'submit_feed_errors')

		elif feed_status == 'RECEIVED' or feed_status == 'INPROGRESS':
			self.log('The feed submit id {} has been received and processing.'.format(response_feed.get('feedId')), 'submit_feed_received')

		return Response().error(code = Errors.WALMART_PUSH_PRODUCT_ERROR)

	@staticmethod
	def get_current_time_feed(format_time = '%Y-%m-%dT%H:%M:%S') -> str:
		"""convert current time to the walmart date time feed format"""
		date_ = datetime.now().strftime(format_time)
		return date_

	def create_feed_item_product_ver4(self) -> list:
		"""Feed create from cache_product - create version 4
		Create feed header
		get the template and assign to the product
		"""
		try:
			list_feed_product = list()
			for product in self.cache_products:
				product_convert: Response = self.product_to_walmart_data_ver4(product)
				if product_convert.result == Response.SUCCESS:
					list_feed_product.append(product_convert.data)
		except:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()
			list_feed_product = []

		return list_feed_product

	def create_feed_item_product(self) -> list:
		"""Feed create from cache_product
		Create feed header
		get the template and assign to the product

		MODE:
		CREATE: Use this mode for creating a new item.
		If requester sends PRODUCT_ONLY with PROCESS_MODE 'CREATE', then error will be returned.
		For create, requested needs to send Product and Offer.
		REPLACE_ALL: Use this mode to update product and offer information.
		NOTE: This is a wipe and replace command. Requester can send this for PRODUCT_ONLY or OFFER_ONLY.
		PARTIAL_UPDATE: Use PROCESS_MODE 'PARTIAL_UPDATE' for PRODUCT_ONLY.
		Note: 'PARTIAL_UPDATE' is not supported for offer updates.
		"""
		try:
			list_feed_product = list()
			for product in self.cache_products:
				product_convert: Response = self.product_to_walmart_data(product)
				if product_convert.result == Response.SUCCESS:
					list_feed_product.append(product_convert.data)
		except:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()
			list_feed_product = []

		return list_feed_product

	def insert_map_product_succeed(self) -> bool:
		for product in self.cache_products:
			pro_id = product['_id']

			if not self.cache_errors[pro_id]:
				wpid = self.cache_products_insert[pro_id].get('wpid')
				self._extend_product_map = {
					'id': self.cache_products_insert[pro_id].get('wpid'),
					'sku': self.cache_products_insert[pro_id].get('sku'),
					'wpid': self.cache_products_insert[pro_id].get('wpid'),
					'wm_itemid': self.cache_products_insert[pro_id].get('wm_itemid'),
					'mart_id': self.cache_products_insert[pro_id].get('mart_id'),
					'walmartca_status': WalmartcaStatus.ACTIVE
				}
				# Extend product code from walmart
				for id_code in self._LIST_PRODUCT_ID_TYPE:
					self._extend_product_map.update({
						id_code: self.cache_products_insert[pro_id].get(id_code) or ''
					})

				self.insert_map_product(product, pro_id, wpid)

		return True

	def feed_items_ver4(self, republished: bool = False):
		"""Feed items: publish the new products or maintenance
		Ref: Item spec v4.x  https://developer.walmart.com/doc/ca/ca-mp/ca-mp-items/
		1. get the type of feed (publish or maintenance)
		2. create feed and post the feed
		3. get the result from walmart need time to process the feed
		4. From the feed status, get the product status and `insert_map_product`
		"""

		feed_type = 'MP_ITEM_INTL'
		# create mp_product and mp_offer
		try:
			mp_item_product = self.create_feed_item_product_ver4()
		except:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()
			return False

		if not mp_item_product:
			return False

		mp_item_feed_header = {
			# 'requestId': to_str(uuid.uuid4()),  # partner's id of the feed
			# 'requestBatchId': to_str(uuid.uuid4()),  # external generated batchId
			# 'feedDate': ModelChannelsWalmartca.get_current_time_feed('%Y-%m-%d'),
			"sellingChannel": "marketplace",
			"processMode": "REPLACE",
			"mart": "WALMART_CA",
			"locale": [
				"en",
				"fr"
			],
			"version": self._API_VERSION_NEW,  # version item spec 4.4 but this version still 3.15 LOL
			"subset": "EXTERNAL"
		}

		post_data = {
			"MPItemFeedHeader": mp_item_feed_header,
			"MPItem": mp_item_product
		}

		if ModelChannelsWalmartca.is_production_mode() is False:
			self.log_by_level(post_data, 'post_data_feed_product')
			self.insert_map_product_succeed()
			return True

		response = self.api(endpoint = f'feeds?feedType={feed_type}', data = post_data, api_type = 'post', content_type = 'json')

		if response.result != Response.SUCCESS:
			self.cache_errors = {product["_id"]: [to_str(response.get('msg', ''))] for product in self.cache_products}
			return False

		check_feed = self.check_feed_status(response)
		if check_feed.result != Response.SUCCESS:
			return False

		# republished only one times
		if self._republish_feed and not republished:
			self.check_cache_error_republish()
			self.cache_errors = {product['_id']: [] for product in self.cache_products}
			self.feed_items_ver4(republished = True)
		else:
			if not self.is_update_product_process():
				# insert new product when publish new product only
				self.insert_map_product_succeed()

		return True

	def feed_items(self, republished: bool = False):
		"""Feed items: publish the new products or maintenance
		1. get the type of feed (publish or maintenance)
		2. create feed and post the feed
		3. get the result from walmart walmart need time to process the feed
		4. From the feed status, get the product status and `insert_map_product`

		the structure of the feed items:
		MP_ITEM_FEED
			MP_ITEM_HEADER
				...
			MP_ITEM
			(list of the products)
			every the product has:
				product identifier (sku, product id)
				date, time, process_mode
				MP_PRODUCT
				MP_OFFER
		"""

		feed_type = 'item'
		# create mp_product and mp_offer
		try:
			mp_item_product = self.create_feed_item_product()
		except:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()
			return False

		if not mp_item_product:
			return False

		mp_item_feed_header = {
			'version': to_str(self._API_VERSION),
			'requestId': to_str(uuid.uuid4()),  # partner's id of the feed
			'requestBatchId': to_str(uuid.uuid4()),  # external generated batchId
			'feedDate': ModelChannelsWalmartca.get_current_time_feed(self._FEED_FORMAT_TIME),
			'mart': 'WALMART_CA',
			'locale': 'en_CA'
		}

		post_data = {
			"MPItemFeed": {
				"MPItemFeedHeader": mp_item_feed_header,
				"MPItem": mp_item_product
			}
		}

		if ModelChannelsWalmartca.is_production_mode() is False:
			self.log_by_level(post_data, 'post_data_feed_product')
			self.insert_map_product_succeed()
			return True

		# TODO: request to api
		response = self.api(endpoint = f'feeds?feedType={feed_type}', data = post_data, api_type = 'post')

		if response.result != Response.SUCCESS:
			self.cache_errors = {product["_id"]: [to_str(response.get('msg', ''))] for product in self.cache_products}
			return False

		check_feed = self.check_feed_status(response)
		if check_feed.result != Response.SUCCESS:
			return False

		# republished only one times
		if self._republish_feed and not republished:
			self.check_cache_error_republish()
			self.cache_errors = {product['_id']: [] for product in self.cache_products}
			self.feed_items(republished = True)
		else:
			if not self.is_update_product_process():
				# insert new product when publish new product only
				self.insert_map_product_succeed()

		return True

	def feed_update_shipping(self, cache_product):
		return Response().success()

	def feed_promo(self):

		def get_end_time() -> (str, str):
			"""Because end_time promo maximum one year, check product_end_date"""
			product_end_date_timestamp = to_timestamp(product.special_price.end_date, '%Y-%m-%dT%H:%M:%S', False)

			next_year = datetime.now() + timedelta(days = 365)
			next_year_timestamp = datetime.timestamp(next_year)

			end_date_timestamp = min(next_year_timestamp, product_end_date_timestamp)
			end_time_product = datetime.fromtimestamp(end_date_timestamp).strftime(self._ORDER_FORMAT_TIME)

			return end_time_product, to_decimal(end_date_timestamp, 2)

		def get_start_time() -> (str, str):
			product_start_date_timestamp = to_timestamp(product.special_price.start_date, '%Y-%m-%dT%H:%M:%S', False)

			now = datetime.now() + timedelta(minutes = 40)
			now_timestamp = datetime.timestamp(now)

			start_date_timestamp = max(product_start_date_timestamp, now_timestamp)
			start_date_product = datetime.fromtimestamp(start_date_timestamp).strftime(self._ORDER_FORMAT_TIME)

			return start_date_product, to_decimal(start_date_timestamp, 2)

		def insert_map_product_promo() -> None:
			"""Update flag check promo price in the warehouse"""
			nonlocal have_promo_price
			pro_id = product['_id']
			wpid = self.cache_products_insert[pro_id].get('wpid')

			self._extend_product_map.update({
				'have_promo_price': have_promo_price
			})
			self.insert_map_product(product, pro_id, wpid)

		def get_promo_on_walmart() -> (str, str):
			nonlocal promo_id

			check_ = self.api(f'promo/sku/{product.sku}')
			check_1 = False if check_.result != Response.SUCCESS or self._last_status > 300 else True
			check_2 = False if to_str(check_.data.get('status')).upper() != 'OK' else True

			if not (check_1 and check_2):
				return '', ''

			try:
				# TODO: recheck when have data, temporary disable
				# end_date_millisecond = to_str(check_.data["ServiceResponse"]["payload"]["pricingList"]["pricing"]["@expirationDate"])
				# end_date_timestamp = to_int(datetime.strptime(end_date_millisecond, self._ORDER_FORMAT_TIME_MILLISECOND).timestamp())
				promo_id = check_.data["ServiceResponse"]["payload"]["pricingList"]["pricing"]["@promoId"]

			except Exception as e:
				# end_date = ''
				promo_id = ''
				self.log({'response': check_, 'exception': e}, log_file_name)

			return '', promo_id

		def put_promo(process_mode = 'new', promo_id_ = '') -> bool:
			"""update promo price to walmart
			function can use to
			1. create a new promo
			2. delete all existing promo
			"""
			mode = {
				'new': 'UPSERT',
				'delete': 'DELETE'
			}

			if process_mode == 'delete':
				data = {
					'Price': {
						'@xmln': 'http://walmart.com/',
						'itemIdentifier': {
							'sku': product.sku
						},
						'pricingList': {
							'@replaceAll': 'true',  # not use boolean
							'pricing': [
								{
									'@processMode': mode['delete'],
									'promoId': promo_id_
								}
							]
						}
					}
				}
			else:
				data = {
					'Price': {
						'@xmlns': 'http://walmart.com/',
						'itemIdentifier': {
							'sku': product.sku
						},
						'pricingList': {
							'@replaceAll': 'true',  # not use boolean
							'pricing': [
								{
									'@effectiveDate': start_time,
									'@expirationDate': end_time,
									'@processMode': mode['new'],
									'currentPrice': {
										'value': {
											'@currency': 'CAD',
											'@amount': product.special_price.price
										}
									},
									'currentPriceType': 'REDUCED',
									'comparisonPrice': {
										'value': {
											'@currency': 'CAD',
											'@amount': product.price
										}
									}
								}
							]
						}
					}
				}

			promo_update = self.api('price?promo=true', data = data, api_type = 'put')

			if promo_update.result != Response.SUCCESS or self._last_status > 300:
				self.log({'error when put promo': promo_update, 'data': data}, log_file_name)
				return False

			return True

		if not self.cache_products_imported:
			return Response().success()

		log_file_name = 'feed_update_promo'

		for product in self.cache_products_imported:
			try:
				# if self.is_production_mode() is False:
				# 	product.special_price.start_date = '2023-10-10T12:12:12'
				# 	product.special_price.end_date = '2023-10-11T12:12:12'
				# 	product.special_price.price = '12.00'

				have_product_special_price = self.is_special_price(product) and product.special_price.end_date
				have_promo_on_walmart = product.get('have_promo_price')

				if not have_product_special_price and not have_promo_on_walmart:
					continue

				end_date, promo_id = '', ''
				start_time, start_time_timestamp = get_start_time()
				end_time, end_time_timestamp = get_end_time()
				# walmart_canada test need millisecond .420 time, lol
				start_time, end_time = start_time.replace('Z', '.420Z'), end_time.replace('Z', '.420Z')
				have_promo_price: bool = True

				if not have_product_special_price and have_promo_on_walmart:
					_, promo_id = get_promo_on_walmart()
					delete_promo = put_promo('delete', promo_id)
					have_promo_price = False

				elif have_product_special_price and not have_promo_on_walmart:
					if start_time_timestamp > end_time_timestamp:
						continue

					create_promo = put_promo()
					have_promo_price = True if create_promo else False

				elif have_product_special_price and have_promo_on_walmart:
					_, promo_id = get_promo_on_walmart()
					delete_promo = put_promo('delete', promo_id)
					time.sleep(5)
					create_promo = put_promo()
					have_promo_price = True if create_promo else False

				insert_map_product_promo()

			except:
				log_traceback()
				continue

	def put_price_product(self):
		for product in self.cache_products_imported:
			item = {
				'Price': {
					'@xmlns': 'http://walmart.com/',
					'itemIdentifier': {
						'sku': product['sku']
					},
					'pricingList': {
						'pricing': {
							'currentPrice': {
								'value': {
									'@currency': 'CAD',
									'@amount': to_decimal(product.price, 2)
								}
							}
						}
					}
				}
			}

			if self.is_production_mode() is False:
				self.log_by_level(item, 'put_price_product')
			# continue

			response = self.api('price', data = item, api_type = 'put')

		return Response().success()

	def feed_price(self):
		"""feed update price product, likely walmart us"""
		feed_type = 'price'
		price_header = {
			'version': '1.5.1',
			'feedDate': ModelChannelsWalmartca.get_current_time_feed(self._FEED_FORMAT_TIME),
		}

		price_list = []

		for product in self.cache_products_imported:
			item = {
				'itemIdentifier': {
					'sku': product['sku']
				},
				'pricingList': {
					'pricing': {
						'currentPrice': {
							'value': {
								'@amount': to_decimal(product.price)
							}
						}
					}
				}
			}
			price_list.append(item)

		if not price_list:
			return Response().success()

		post_data = {
			'PriceFeed': {
				'PriceHeader': price_header,
				'Price': price_list
			}
		}

		if self.is_production_mode() is False:
			self.log_by_level(post_data, 'feed_price')

		response = self.api(f'feeds/?feedType={feed_type}', data = post_data, api_type = 'post')

		if response.result != Response.SUCCESS:
			return Response().error()

		check_feed = self.check_feed_status(response)

		return Response().success() if check_feed.result == Response.SUCCESS else Response().error()

	def put_inventory_product(self):
		for product in self.cache_products_imported:
			lag_time = to_int(product.template_data.get('shipping', {}).get('fulfillment_lag_time', 0))
			item = {
				'inventory': {
					'@xmlns': 'http://walmart.com/',
					'sku': product['sku'],
					'quantity': {
						'unit': 'EACH',
						'amount': product.get('qty', 0)
					},
					'fulfillmentLagTime': lag_time or 3
				}
			}

			if self.is_production_mode() is False:
				self.log_by_level(item, 'put_inventory_product')
			# continue

			response = self.api(f'inventory', data = item, api_type = 'put')

		return Response().success()

	def feed_inventory(self):
		"""feed update inventory for the products in bulk"""
		feed_type = 'inventory'

		feed_header = {
			'version': 1.4,
			'feedDate': ModelChannelsWalmartca.get_current_time_feed(self._FEED_FORMAT_TIME),
		}

		inventory_list = []

		for product in self.cache_products_imported:
			lag_time = to_int(product.template_data.get('shipping', {}).get('fulfillment_lag_time', 0))
			item = {
				'sku': product['sku'],
				'quantity': {
					'unit': 'EACH',
					'amount': product.get('qty', 0)
				},
				'fulfillmentLagTime': lag_time or 3
			}
			inventory_list.append(item)

		feed_inventory = {
			'InventoryFeed': {
				'InventoryHeader': feed_header,
				'inventory': inventory_list
			}
		}

		if self.is_production_mode() is False:
			self.log_by_level(feed_inventory, 'feed_inventory')

		response = self.api(f'feeds/?feedType={feed_type}', data = feed_inventory, api_type = 'post')

		if response.result != Response.SUCCESS:
			return Response().error()

		check_feed = self.check_feed_status(response)

		return Response().success() if check_feed.result == Response.SUCCESS else Response().error()

	def create_products_sku_index(self, cache_products: List[Product]) -> None:
		"""self.cache_products_sku_index: map feed data error
		the feed new item['data error'] only contains the product sku and the error message
		if the feed has duplicate skus:
			walmart inserts _idx for each duplicate skus
		example:
			the seller send:
			 {'sku': 'abc'}, {'sku': 'abc'}, {'sku': 'abc'}
			walmart will response with:
			{'sku': 'abc'}, {'sku': 'abc_1'}, {'sku': 'abc_2'}
		warning: feed maintance will have same sku
		TODO: update feed maintance
		"""
		self.cache_products_sku_index = dict()
		sku_count = dict()
		index = 0
		for product in cache_products:
			sku_add = product['sku']
			if sku_count.get(product['sku']):
				sku_add += f"_{sku_count[product['sku']]}"

				self.cache_errors[product['_id']].append(
					Errors().get_msg_error(Errors.WALMART_SKU_DUPLICATE))

			self.cache_products_sku_index.update({
				sku_add: {
					'_id': product['_id'],
					'index': index
				}
			})
			sku_count[product['sku']] = sku_count.get(product['sku'], 0) + 1
			index += 1

	def create_products_cache(self) -> bool:
		"""create cache error, cache product to ready for the feed"""
		self.cache_errors = {product['_id']: [] for product in self.cache_products}
		self.cache_warnings = {product['_id']: [] for product in self.cache_products}
		self.create_products_sku_index(self.cache_products)

		mapping_field = ['sku', 'wpid'] + self._LIST_PRODUCT_ID_TYPE
		for product in self.cache_products:
			insert_product = WalmartcaProductInsertMap()
			for field in mapping_field:
				insert_product[field] = product.get(field)
			self.cache_products_insert.update({
				product['_id']: insert_product
			})

		return True

	def get_cache_product_imported(self):
		"""Get the list of the products imported success
		Flow update price, qty not need to check
		"""

		if not self.is_product_process():
			self.cache_products_imported = copy.deepcopy(self.cache_products)
			return True

		self.cache_products_imported = list(
			filter(lambda item: not self.cache_errors[item['_id']], self.cache_products)
		)
		self.create_products_sku_index(self.cache_products_imported)
		return True if self.cache_products_imported else False

	def check_duplicate_sku(self) -> bool:
		"""check self.cache_products has duplicate sku
		if the list has duplicate sku. replace sku duplicate with a new sku
		"""
		try:
			sku_list = [product['sku'] for product in self.cache_products]

			if len(sku_list) == len(set(sku_list)):
				return True

			# get the sku and the index list of duplicate sku
			# but we pass the first sku
			duplicates = {}
			for index_, sku in enumerate(sku_list):
				if sku_list.count(sku) < 2:
					continue

				if isinstance(duplicates.get(sku), list):
					duplicates[sku].append(index_)
				else:
					duplicates[sku] = []

			for sku, index_ in duplicates.items():
				self.cache_products[to_int(index_)]['sku'] = to_str(sku) + '_' + ModelChannelsWalmartca.random_sku(5)
		# TODO:
		# add postfix and check max length of sku condition
		# but the new sku can be same as already sku on walmart -> walmart response error
		# or the cache_products -> check
		except Exception as e:
			self.log_by_level(f'Exception check_duplicate_sku: {e}', 'check_duplicate_sku', 3)

		return True

	def wait_secs_feed_process(self, base_time_secs: int = 30) -> None:
		"""Wait a moment WM processed new product """
		MAX_SECS_WAIT = 2 * 60 * 60
		if not self.is_production_mode():
			return

		if self._update_product_flow:
			# decrease time if the products are already on the Walmart
			base_time_secs = to_int(base_time_secs / 2)

		sleep_time = 0
		if self.is_product_process():
			sleep_time = len(self.cache_products_imported) * base_time_secs

		sleep_time_min = min(sleep_time, MAX_SECS_WAIT)

		time.sleep(sleep_time_min)

	def addition_product_import(self):
		"""
		Walmart use feed to create or maintenance the products, inventory, price,..
		1. Function create the feed to send product to walmart
		2. When publishing new products, only the products are success in the
		item feed needs to be updated in inventory and price feed..
		3. After publish or update the products, function `reset_cache_product`
		will reset the variables `cache_products`, `parent_product` to ready to
		the next round. And update the results of each a product to the warehouse
		"""
		if not self.cache_products:
			return Response().success()

		# self.check_duplicate_sku()
		self.create_products_cache()
		feed_items_succeed = False
		try:
			feed_items_succeed = True
			if self._update_product_code:
				# update `product_code`, `sku` use new item feed
				self._update_product_flow = False

			if self.is_product_process():
				feed_items_succeed = self.feed_items_ver4()

			# get the list have product imported success to walmart
			product_imported = self.get_cache_product_imported()
			self.wait_secs_feed_process(base_time_secs = 30)
			if not self.is_production_mode():
				reset_cache_products = self.after_push_feed(feed_items_succeed)
				return Response().success()

			if self.cache_products_imported and (not self._update_product_flow or self._update_price):
				if self._update_product_flow and len(self.cache_products_imported) < 50:
					self.put_price_product()

				else:
					self.feed_price()

				self.feed_promo()

			if self.cache_products_imported and (not self._update_product_flow or self._update_qty):
				if self._update_product_flow and len(self.cache_products_imported) < 50:
					self.put_inventory_product()

				else:
					self.feed_inventory()

		# if self.cache_products_imported and (self._update_product or self._update_shipping):
		# 	pass

		except:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()

		self.after_push_feed(feed_items_succeed)
		return Response().success()

	def reset_cache_products(self):
		"""Reset the product cache to prepare for the next round."""
		self.cache_products= list()
		self.cache_products_imported = list()
		self.cache_warnings = dict()
		self.cache_errors = dict()
		self.cache_products_sku_index = dict()
		self.cache_products_insert = dict()
		self.cache_variant_id = list()
		self.parent_products = dict()
		self.parent_variants = dict()

	def after_push_feed(self, feed_items_succeed: bool):
		for product in self.cache_products:
			if not feed_items_succeed or self.cache_errors.get(product['_id']):
				if self.cache_errors.get(product['_id']):
					err_list = [to_str(err) for err in self.cache_errors[product['_id']]]
					error = '\n'.join(err_list)

				else:
					error = Errors().get_msg_error(Errors.WALMART_FEED_ERROR)

				self.after_push_product(product['_id'], Response().error(msg = error), product)
				self.log(f'Error product_id {product["_id"]}: {error}', 'products')

			else:
				self.after_push_product(product['_id'], Response().success(), product)

			if self.cache_warnings.get(product['_id']):
				for warning in self.cache_warnings[product['_id']]:
					self.log(f'Warning {product["_id"]}: {warning}', 'products')

		for parent_id, variant_ids in self.parent_variants.items():
			errors = list(filter(lambda x: self.cache_errors.get(x), variant_ids))
			if feed_items_succeed and not errors:
				self.after_push_product(parent_id, Response().success(), self.parent_products[parent_id], is_parent = True)
				if self.is_inventory_process():
					self.update_qty_for_parent(parent_id)

				else:
					product_map = self.parent_products[parent_id]
					self.insert_map_product(product_map, parent_id, parent_id)

			else:
				if not feed_items_succeed:
					try:
						if not errors:
							msg_errors = Errors().get_msg_error(Errors.WALMART_ERROR_PARENT_PRODUCT)

						else:
							msg_errors = '\n'.join(self.cache_errors[errors[0]])

					except (IndexError, Exception) as e:
						msg_errors = Errors().get_msg_error(Errors.WALMART_ERROR_PARENT_PRODUCT)
						self.log_traceback()
				else:
					# msg_errors = 'You have {} variant{} import error'.format(len(errors), "'s" if len(errors) > 1 else '')
					msg_errors = 'Your product variants have errors. Click the "Variations" tab to see the errors.'
					# TODO: update when have response variant walmart_can
					if to_str(self.cache_errors[errors[0]][0]).find('Variant metadata bag') != -1:
						msg_errors += '\n Variant metadata bag is missing or empty'

				self.after_push_product(parent_id, Response().error(msg = msg_errors), self.parent_products[parent_id], is_parent = True)
		self._state.push.process.products.error += len([1 for errors in self.cache_errors.values() if errors])
		self.cache_products = []

		return Response().success()

	def replace_description(self, text):
		return self.strip_html_from_description(text)

	def update_product_attribute(self, product_id, product, delete_image = False):
		pass

	def after_product_import(self, product_id, convert, product, products_ext):
		return Response().success()

	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']

		if mass_action == 'delete':
			self.delete_product_import(product_id)
			self.product_deleted(product['_id'], product)

		return Response().success(product_id)

	def delete_product_import(self, product_id):
		sku_list = self.get_product_sku_list(product_id)

		if not sku_list:
			return Response().error()

		for sku in sku_list:
			response = self.api(endpoint = f'items/{sku}', api_type = 'delete')
			self.log(f'Delete product sku: {sku}', 'retire_product')

		return Response().success()

	def get_product_sku_list(self, product_id) -> list:
		"""get product sku list from `product.id`
		product_id can be `wpid` or `variant_group_id`
		product_id: get from function `get_product_id_import`
		"""
		channel_id = self.get_channel_id()
		where = {
			f'channel.channel_{channel_id}.wpid': product_id,
			'is_variant': False
		}
		limit = 10
		product = self.get_model_catalog().find_all(where = where, limit = limit)

		if not product:
			where = {
				f'channel.channel_{channel_id}.variant_group_id': product_id,
				'is_variant': False
			}

		product = self.get_model_catalog().find_all(where = where, limit = limit)

		if not product:
			error_log = f'Can\'t get product id: {product_id}, channel_id: {channel_id}'
			self.log(error_log, 'get_product_sku_list')
			return []

		product = product[0]

		if product.variant_count:
			where = {
				f'channel.channel_{channel_id}.status': 'active',
				'is_variant': True,
				'parent_id': to_str(product['_id'])
			}
			variant_list = self.get_model_catalog().find_all(where = where, limit = limit)
			sku_list = [variant['channel'][f'channel_{channel_id}']['sku'] for variant in variant_list]
		else:
			sku_list = [product['channel'][f'channel_{channel_id}']['sku']]

		return sku_list

	@staticmethod
	def mapping_missing_field_variant(product: Product) -> Product:
		"""1. Check in the variants. If the variant is not have the required fields.
		update from the product

		2. Mapping the variant attributes from the parent product
		"""
		# always get the description from parent product
		required_field_list = [
			'variant_group_id', 'brand', 'variant_group_id',
			'weight', 'weight_units', 'images',
			'pull_from_walmart_ca', 'description_fr',
			'is_sku_override'
		]
		for variant in product.variants:
			variant['description'] = product['description']
			for field in required_field_list:
				check = variant.get(field)
				if not check:
					variant[field] = deepcopy(product.get(field))

			if not product.get('attributes'):
				continue

			for product_atr in product.attributes:
				variant.attributes.append(product_atr)

		return product

	def check_item_update(self, item: Product) -> Product:
		"""Get product/variant, check is product update code or sku"""
		if item.get('changed_field') and isinstance(item['changed_field'], list):

			if 'sku' in item['changed_field']:
				item['sku_update'] = True
			elif set(self._LIST_PRODUCT_ID_TYPE) & set(item['changed_field']):
				item['product_id_update'] = True

			if item.get('sku_update') or item.get('product_id_update'):
				self._update_product_code = True

		return item

	def product_channel_update(self, product_id, product: Product, products_ext) -> Response:
		"""get product data to cache_products
		add the product (simple product and variant product) to two lists
		if the product has variants - link between the parent product and variants

		Update (maintenance) the products already in walmart
		"""

		self.set_product_update()
		product.pull_from_walmart_ca = self.is_product_pull_from_walmart_ca(product)
		if not product.variants:
			product = self.check_item_update(product)
			previous_sku = product.sku
			product.sku = self.validate_product_sku(product.sku)
			if previous_sku != product.sku:
				self._update_product_code = True

			if product.get('is_sku_override'):
				self._update_product_code = True

			self.cache_products.append(product)

		else:
			product = ModelChannelsWalmartca.mapping_missing_field_variant(product)
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			# create new variant_group_id, max length 20
			parent_id = ModelChannelsWalmartca.random_sku(length = 20)
			min_price_variant = min([variant['price'] for variant in product.variants])
			have_primary = False  # assign the first variants has lowest price

			for index, variant in enumerate(product.variants):
				# Check if the product `mapping` have data in channel walmart
				# or product get status
				# if the product not check means the products not have in walmart
				check = variant['channel'][f'channel_{self.get_channel_id()}'].get('product_id')
				if not check:
					# product add the new variant to Walmart
					self._update_product_flow = False

				if product.get('is_sku_override'):
					self._update_product_code = True

				variant = self.check_item_update(variant)
				previous_sku = variant.sku
				variant.sku = self.validate_product_sku(variant.sku)
				if previous_sku != product.sku:
					self._update_product_code = True

				variant.pull_from_walmart = product.pull_from_walmart
				# generate parent_id for variant
				variant.parent_group_id = product.get('group_id') or parent_id
				if not variant.thumb_image.url:
					variant.thumb_image.url = product.thumb_image.url

				# set the variant has the lowest price is the primary variant
				if not have_primary and variant.price == min_price_variant:
					have_primary = True
					variant['is_primary_variant'] = True

				if product.variant_count == 1:
					variant.parent_group_id = ''

				# Update the variant to cache_product. Prepare for the feed product
				# WALMART treats a product variant as a product
				self.parent_variants[product['_id']].append(variant['_id'])
				self.cache_products.append(variant)

		return Response().success()

	def get_product_id_list(self, product) -> list:
		"""get the product id list of the product"""
		id_list: list = []
		for id_ in self._LIST_PRODUCT_ID_TYPE:
			if product.get(id_):
				id_list.append(product[id_])

		return id_list

	def get_all_product_on_channel(self) -> list:
		"""get all the product on walmart"""
		product_list = []
		next_cursor = '*'
		params = {
			'limit': 200,
			'includeDetails': 'true',
			'nextCursor': next_cursor
		}
		while True:
			response = self.api('items', data = params)
			if self._last_status > 300 or response.data.get('ItemResponses', {}).get('totalItems') == 0:
				break

			next_cursor = response.data.get('ItemResponses', {}).get('nextCursor')
			response_list = response.data.get('ItemResponses', {}).get('ItemResponse')
			if response_list:
				product_list += self.dict_to_list(response_list)

			if not next_cursor:
				break

			params.update({'nextCursor': next_cursor})

		return product_list

	def match_product_by_product_code_id(self, sku_list: list, product_list: list):
		"""sku have mongo_id, product_id_list
		-> matching with product in product_list by product_id_list
		"""
		if not (sku_list and product_list):
			return sku_list

		for product_sku in sku_list:
			if product_sku['walmart_data']:
				continue

			for product_walmart in product_list:
				product_have_id = any([
					id_ in product_walmart.values()
					for id_ in product_sku['product_id_list']
					])

				if product_have_id:
					product_sku['walmart_data'] = product_walmart
					self.log(product_sku, 'match_product_walmart_ca')
					break

		return sku_list  # remember is mutable


	def sync_product_from_mainstore(self, product_id: str) -> Response:
		"""sync/linked the products with published product
		1. get product from mongo (simple/variant)
		2. for each product sku - check on the walmart
		3. get all the products - mapping with product code
		4. if the product already in walmart - linked between them
		"""
		# 1. get product with variant id
		# check product status
		sku_list: List = []
		def get_product_id_list() -> list:
			"""get the product id and the variants id from warehouse"""
			nonlocal sku_list
			where_product = {
				'where': {'is_variant': False,
						  '_id': {'$in': (ObjectId(product_id),)}
						  },
				'limit': 1, 'order_by': '_id', 'sort': '_id'
			}

			product_query = self.get_model_catalog().find_all(**where_product)
			product = product_query[0]
			channel_id = self.get_channel_id()
			variant_list = self.get_variants(product, channel_id)
			sku_list = [
				{
					'product_id': product['_id'],
					'sku': product['channel'][f'channel_{channel_id}']['sku'],
					'product_id_list': self.get_product_id_list(product['channel'][f'channel_{channel_id}']),
					'walmart_data': Prodict(),
					'product_raw': product
				}
			]
			sku_list += [
				{
					'product_id': variant['_id'],
					'sku': variant['channel'][f'channel_{channel_id}']['sku'],
					'product_id_list': self.get_product_id_list(product['channel'][f'channel_{channel_id}']),
					'walmart_data': Prodict(),
					'product_raw': variant
				} for variant in variant_list]

			return sku_list

		def check_product_on_walmart() -> None:
			"""check the product on walmart by the product sku"""
			nonlocal sku_list
			for sku_product in sku_list:
				response = self.api(f'items/{sku_product["sku"]}')
				if self._last_status < 300 and response.data.get('ItemResponses', {}).get('ItemResponse'):
					sku_product['walmart_data']	= response.data.ItemResponses.ItemResponse

		def get_product_list() -> list:
			"""check if sku_list have an empty walmart_data
			if the list have an empty_data means unlinked product
			-> get product, otherwise return empty list
			"""
			have_unlink_product = any([not product['walmart_data'] for product in sku_list])
			if have_unlink_product and not self._all_products:
				self._all_products = self.get_all_product_on_channel()

			return self._all_products

		def insert_map_product() -> None:
			"""insert walmart data to warehouse"""
			nonlocal sku_list
			for product in sku_list:
				if not product['walmart_data']:
					continue

				product_channel_id = product['walmart_data'].get('wpid', '')
				self._extend_product_map = {
					'wpid': product['walmart_data'].get('wpid', ''),
					'name': product['walmart_data'].get('productName', ''),
					'sku': product['walmart_data'].get('sku', ''),
					# 'price': to_decimal(product['walmart_data'].get('price', {}).get('amount'), 2),
					'walmartca_status': to_str(product['walmart_data'].get('lifecycleStatus', '')).lower()
					# 'status': product['walmart_data'].get('lifecycleStatus')
					# TODO: publishedStatus
				}
				for id_ in self._LIST_PRODUCT_ID_TYPE:
					if not product['walmart_data'].get(id_):
						continue

					self._extend_product_map.update(
						{
							id_: product['walmart_data'][id_]
						}
					)

				self.insert_map_product(
					product=product['product_raw'],
					product_id=product['product_id'],
					product_channel_id=product_channel_id
				)

		sku_list = get_product_id_list()
		if not sku_list:
			return Response().success()

		check_product_on_walmart()
		product_list = get_product_list()
		sku_list = self.match_product_by_product_code_id(sku_list, self._all_products)
		insert_map_product()

		return Response().success()
	# orders
	def get_orders_main_export(self) -> Response:
		if self._flag_finish_get:
			return Response().finish()

		limit_data = min(self._state.pull.setting.orders, 100)

		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0

		orders_filter_condition = {
			'limit': limit_data,
			'productInfo': 'true',
			"createdStartDate": self._order_start_create
		}

		if self._cursor_next_link:
			# the cursor next link is a params request
			order_response = self.api(f'orders{self._cursor_next_link}')
		else:
			order_response = self.api('orders', data = orders_filter_condition)

		if order_response.result != Response.SUCCESS or order_response.data.get('error'):
			return Response().error(msg = "Could not get list of orders from Walmart")

		# if not self.is_production_mode():
		# 	order_response = self.test_data('order_list')
		# 	self._flag_finish_get = True

		order_data = order_response.data.get('list', {}).get('elements', {}).get('order', {})
		self._cursor_next_link = to_str(order_response.get('data', {}).get('list', {}).get('meta', {}).get('nextCursor', ''))
		if not self._cursor_next_link or to_str(self._cursor_next_link) == '*':
			self._flag_finish_get = True

		if not order_response or not order_data or to_str(order_data) == '':
			return Response().error(msg = "Could not get list of orders from Walmart")

		return Response().success(data = ModelChannelsWalmartca.dict_to_list(order_data))

	def get_orders_ext_export(self, orders):
		return Response().success()

	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.purchaseOrderId

	@staticmethod
	def dict_to_list(check_list) -> list:
		"""when convert from json. if the list has one element
		the list will become a dictionary
		"""
		return [check_list] if not isinstance(check_list, list) else check_list

	@staticmethod
	def convert_order_status(status: str) -> str:
		order_status = {
			'Created': Order.OPEN,
			'Acknowledged': Order.READY_TO_SHIP,
			# walmart ca not have delivered status
			'Shipped': Order.COMPLETED,
			'Cancelled': Order.CANCELED,
		}
		return order_status.get(status, Order.OPEN)

	def walmart_timestamp_to_time(self, timestamp: int) -> str:
		# Walmart timestamp milliseconds to datetime
		date_time = None
		try:
			timestamp /= 1000
			date_time = datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
		except:
			pass
		return date_time

	def total_amount_orderlines_currency(self, order) -> (float, float, str):
		"""get sum of products, shipping price, and currency
		# chargeType: ['PRODUCT', 'SHIPPING']
		"""

		total_amount, shipping_amount = 0.0, 0.0
		currency = ''
		order_line_list = order.orderLines.orderLine

		order_line_list = ModelChannelsWalmartca.dict_to_list(order_line_list)

		for order_line in order_line_list:
			charge_list = order_line.charges.charge
			charge_list = ModelChannelsWalmartca.dict_to_list(charge_list)

			for charge in charge_list:
				try:
					if charge.get('chargeType') == 'PRODUCT':
						total_amount += to_decimal(charge.get('chargeAmount', {}).get('amount', 0), 2)

						if not currency:
							currency = to_str(charge.get('chargeAmount', {}).get('currency', ''))

					elif charge.get('chargeType') == 'SHIPPING':
						shipping_amount += to_decimal(charge.get('chargeAmount', {}).get('amount', 0), 2)

				except Exception as e:
					self.log_by_level(f'Exception when get total amount: {e}, charge_data: {charge}', 'Exception amount_price', 3)

		return to_decimal(total_amount, 2), to_decimal(shipping_amount, 2), currency

	def total_tax_orderlines(self, order) -> float:
		"""
		orderLines:
			orderLine [] or {} when have only one item
			[] or {} when convert from xml to json
				charges:
					charge[] - [product, shipping] each charge have tax
		"""
		total_tax = 0
		order_line_list = order.orderLines.orderLine

		order_line_list_2 = [order_line_list] if not isinstance(order_line_list, list) else order_line_list
		order_line_list = ModelChannelsWalmartca.dict_to_list(order_line_list)
		check = order_line_list_2 == order_line_list

		for order_line in order_line_list:
			charge_list = order_line.charges.charge

			charge_list = ModelChannelsWalmartca.dict_to_list(charge_list)

			for charge in charge_list:
				try:
					total_tax += to_decimal(charge.get('tax', {}).get('taxAmount', {}).get('amount', 0), 2)

				except Exception as e:
					self.log_by_level(f'Exception when get tax: {e}, charge_data: {charge}',
					                  'Exception total_tax_orderlines', 3)
					continue

		return to_decimal(total_tax, 2)

	def get_order_data_status(self, order: Prodict) -> (str, bool):
		order_lines = order.orderLines.orderLine
		status_list = list()
		is_status_created = False

		order_lines = ModelChannelsWalmartca.dict_to_list(order_lines)

		for order_line in order_lines:
			try:
				order_line_status: str = to_str(order_line.orderLineStatuses.orderLineStatus.status)

			except (KeyError, IndexError):
				continue

			status_list.append(ModelChannelsWalmartca.convert_order_status(order_line_status))

			if order_line_status == 'Created':
				is_status_created = True

		"""order line has four statuses: ready-to-ship, shipping, canceled, and completed.
		the order is completed when all of the order lines completed
		if one of them canceled or is still ready-to-ship set the order status by them
		"""
		if not status_list:
			return '', is_status_created

		# TODO: find a condition to check order is shipping
		if Order.OPEN in status_list:
			status_order = Order.OPEN
		elif Order.CANCELED in status_list:
			status_order = Order.CANCELED
		elif Order.READY_TO_SHIP in status_list:
			status_order = Order.READY_TO_SHIP
		elif all([x_ == Order.COMPLETED for x_ in status_list]):
			status_order = Order.COMPLETED
		else:
			status_order = Order.OPEN

		return status_order, is_status_created

	def convert_order_export(self, order, orders_ext, channel_id = None):
		""" 1. update max last modifier
			2. convert the order to warehouse"""

		self.set_order_max_last_modifier(order.orderDate)
		# log when beta walmart
		self.log_by_level(order, 'data_convert_order_export', 1)
		log_file_name = 'convert_order_export'

		order_data = Order()
		order_data.id = to_str(order.purchaseOrderId)
		order_data.order_number = to_str(order.customerOrderId)
		custom_id = OrderAdditionalDetails(name = 'customer_order_id', value = order.customerOrderId)
		order_data.additional_details.append(custom_id)

		# order status
		order.orderLines.orderLine = ModelChannelsWalmartca.dict_to_list(order.orderLines.orderLine)

		order_data.status, is_status_created = self.get_order_data_status(order)
		order_data.tax.title = 'Tax of products'
		order_data.tax.amount = self.total_tax_orderlines(order)
		order_data.subtotal, order_data.shipping.amount, order_data.currency = self.total_amount_orderlines_currency(order)
		order_data.total = to_decimal((order_data.subtotal + order_data.tax.amount + order_data.shipping.amount), 2)

		order_data.created_at = self.walmart_datetime_to_time(order.get('orderDate', ''))
		order_data.updated_at = self.walmart_datetime_to_time(order.get('orderDate', ''))
		order_data.imported_at = get_current_time()

		shipping_postal = order.get('shippingInfo', Prodict()).get('postalAddress', Prodict())
		full_name = to_str(shipping_postal.get('name'))
		full_name_list = full_name.split(' ')
		first_name = full_name_list[0]
		last_name = ' '.join([ele for ele in full_name_list[1:]]) if len(full_name_list) > 1 else ''

		order_data.customer.id = to_str(order.customerOrderId)
		order_data.customer.email = to_str(order.customerEmailId)
		order_data.customer.username = full_name
		order_data.customer.telephone = order.shippingInfo.phone
		order_data.customer.first_name = first_name
		order_data.customer.last_name = last_name

		address_fields = ['customer_address', 'billing_address', 'shipping_address']
		order_data.shipping.method = shipping_postal.methodCode

		for address_field in address_fields:
			order_data[address_field].first_name = first_name
			order_data[address_field].last_name = last_name
			order_data[address_field].telephone = order.shippingInfo.phone
			order_data[address_field].address_1 = shipping_postal.address1
			order_data[address_field].address_2 = to_str(shipping_postal.get('address2', ''))
			order_data[address_field].city = shipping_postal.city
			order_data[address_field].country.country_name = shipping_postal.country
			order_data[address_field].country.country_code = self.get_country_name_from_code(shipping_postal.country)  # TODO: re-check
			try:
				country_info = CountryInfo(shipping_postal.country)
				country_info.iso(2)
			except:
				country_info = False
			if country_info:
				order_data[address_field].country.country_name = country_info.native_name()
				order_data[address_field].country.country_code = country_info.iso(2)
			order_data[address_field].state.state_code = shipping_postal.state
			order_data[address_field].state.state_name = self.get_state_code_from_name(shipping_postal.state)  # TODO: re-check
			order_data[address_field].postcode = shipping_postal.postalCode

		try:
			order_line_status = order.orderLines.orderLine[0].orderLineStatuses.orderLineStatus
			# TODO: check if have multi order_line_status, checked by order
			order_line_status = ModelChannelsWalmartca.dict_to_list(order_line_status)
			order_line_status = order_line_status[-1]

		except Exception as e:
			self.log_by_level(f'Exception when get order_line_status: {e}', log_file_name, 3)
			order_line_status = Prodict()

		order_data.shipments.shipped_at = self.walmart_datetime_to_time(order.get('shippingInfo', {}).get('estimatedDeliveryDate'))
		order_data.shipments.status = order_line_status.get('status', {})
		order_tracking_info = order_line_status.get('trackingInfo', Prodict())

		if order_tracking_info:
			order_data.shipments.methodCode = order_tracking_info.get('methodCode', '')
			order_data.shipments.tracking_number = order_tracking_info.get('trackingNumber')
			order_data.shipments.tracking_url = order_tracking_info.get('trackingURL')
			if order_tracking_info.get('shipDateTime'):
				order_data.shipments.shipped_at = self.walmart_datetime_to_time(order_tracking_info.get('shipDateTime'))

			if order_tracking_info.get('carrierName'):
				order_data.shipments.tracking_company = (
						order_tracking_info.carrierName.get('carrier') or order_tracking_info.carrierName.get('otherCarrier')
				)

		order_data.shipments.tracking_company_code = order_data.shipments.tracking_company
		# TODO: fulfillment id

		order_data.channel_data = {
			'order_status': order_data.status,
			'created_at': order_data.created_at,
			'order_number': order_data.order_number,
			'shipped_date': self.walmart_datetime_to_time(order_tracking_info.get('shipDateTime')) if order_tracking_info else None
		}

		# TODO payment
		try:
			order_line_list = order.orderLines.orderLine
		except Exception as e:
			self.log_by_level(f'Exception order line: {e}', log_file_name, 3)
			order_line_list = []

		order_line_list = ModelChannelsWalmartca.dict_to_list(order_line_list)
		for order_line in order_line_list:
			try:
				order_item = OrderProducts()
				order_item.product_sku = order_line.item.sku
				order_item.product_name = order_line.item.productName

				order_charges = ModelChannelsWalmartca.dict_to_list(order_line.charges.charge)
				for charge in order_charges:
					if charge.chargeType == 'PRODUCT':
						order_item.total = to_decimal(charge.get('chargeAmount', {}).get('amount'), 2)
						order_item.tax_amount = to_decimal(charge.get('tax', {}).get('taxAmount', {}).get('amount', 0), 2)

				order_item.qty = to_int(order_line.get('orderLineQuantity', {}).get('amount', 0))
				order_item.product_sku = order_item.product_sku
				item_request = self.api(f'items/{order_item.product_sku}')

				if item_request.result != Response.SUCCESS or self._last_status > 300:
					continue

				item_request = item_request.data.get('ItemResponses', {}).get('ItemResponse')
				order_item.product_id = item_request.get('wpid') or item_request.get('upc') or item_request.get('gtin') or item_request.get('ean')
				order_item.price = to_decimal(item_request.get('price', {}).get('amount'), 2)
				order_item.original_price = to_decimal(item_request.get('price', {}).get('amount'), 2)
				# TODO: find method to get variant

				order_data.products.append(order_item)

			except Exception as e:
				self.log_by_level(f'Exception get_order_line: {e}', log_file_name, 3)
				continue
		self.log_by_level(order_data, 'data_convert_order_export', 1)

		if is_status_created:
			acknowledge_order = self.acknowledge_order(order_data.id)

		return Response().success(data = order_data)

	def acknowledge_order(self, order_id: str) -> Response:
		"""function auto acknowledge new order when pull from walmart"""
		if self._state.channel.config.setting.get('order', {}).get('auto_acknowledgement') == 'enable':
			try:
				# item_request = self.api(f'items/{order_item.product_sku}')
				request = self.api(endpoint = f'orders/{order_id}/acknowledge', api_type = 'post')

				msg = f"Order id: {order_id},\n" \
					  f"channel_id: {self.get_channel_id()}"
				log(msg, 'order/order_walmart_ca', 'acknowledge_order')

			except:
				log_traceback(type_error = 'acknowledge_order')

		return Response().success()

	def walmart_datetime_to_time(self, walmart_date: str) -> str:
		"""The walmart date time format in millisecond,
		"2016-06-22T06:00:00.000Z"	
		"2016-05-18T16:53:14.000Z"
		"""
		if not walmart_date:
			return ''

		return walmart_date.split('.')[0].replace('T', ' ')

	def get_state_update(self) -> str:
		"""get update state variable"""
		from datasync.controllers.channel import ControllerChannel
		return ControllerChannel.ACTION_UPDATE

	def after_push_product(self, product_id, import_data, product: Product, is_parent = False):
		if self.is_inventory_process():
			if import_data.result == Response.SUCCESS:
				update_field = dict()
				if self.is_setting_sync_qty():
					update_field[f'channel.channel_{self._state.channel.id}.qty'] = product.qty
				if self.is_setting_sync_price():
					update_field[f'channel.channel_{self._state.channel.id}.price'] = product.price
				if update_field:
					self.get_model_catalog().update(product_id, update_field)
			return Response().success(product)
		update_field = dict()
		product_channel_data = product['channel'][f'channel_{self._state.channel.id}']
		if import_data.result in (Response.ERROR, Response.WARNING):
			publish_status = ProductChannel.ERRORS
			msg = import_data.msg or Errors().get_msg_error(import_data.code)
			# TODO: Product error update more information, update to msg not response
			if not product_channel_data.get('product_id') and self._publish_action != self.get_state_update():
				# if the mainstore has a new variant add to an existing active product on channel walmart
				# the publishing process may encounter an error and status will change to ERROR
				# as a result, the variant may disappear from the UI
				# -> check _publish_action
				update_field[f'channel.channel_{self._state.channel.id}.status'] = ProductChannel.ERRORS
		else:
			msg = ''
			publish_status = ProductChannel.COMPLETED
			update_field[f'channel.channel_{self._state.channel.id}.edited'] = False
			update_field[f'channel.channel_{self._state.channel.id}.status'] = ProductChannel.ACTIVE
			if is_parent:  # don't override product_id wpid - a simple product and variant products
				update_field[f'channel.channel_{self._state.channel.id}.product_id'] = product['_id']
			update_field[f'channel.channel_{self._state.channel.id}.product_sku'] = product.sku
		# TODO: reset changed_field to empty
		# changed_field is the list of updated field from UI
		if product.get('changed_field'):
			update_field[f'channel.channel_{self._state.channel.id}.changed_field'] = []

		update_field[f"channel.channel_{self._state.channel.id}.publish_status"] = publish_status
		update_field[f'channel.channel_{self._state.channel.id}.error_message'] = msg

		product.channel[f"channel_{self._state.channel.id}"] = self.get_product_channel_data(product, '')
		product.channel[f"channel_{self._state.channel.id}"]['publish_status'] = publish_status
		# TODO: Product error authorized to list
		product.channel[f'channel_{self._state.channel.id}']['error_message'] = msg
		self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)

	def channel_assign_category_template(self, product: Product, template_data: Prodict) -> Product:
		"""func choose the mapping and the override data from the category template
		category attributes have english and french attributes so need two cycles mapping
		"""
		if not template_data:
			return product

		for lang in ['english', 'french']:
			item_specifics = template_data.get(lang)

			# TODO: check when have UI, keep or remove
			if not item_specifics:
				continue

			for specific in item_specifics:
				status_changed = False

				if not specific.override and not specific.mapping:
					continue

				if specific.override:
					value = specific.override

				else:
					status_changed = True
					value = specific.mapping

				specific.value = self.assign_attribute_to_field(value, product)
				specific.value = self.convert_catalog_value_type(status_changed, specific)

			if not product.channel[f'channel_{self.get_channel_id()}']['template_data'].get('category'):
				product.channel[f'channel_{self.get_channel_id()}']['template_data']['category'] = Prodict()

			product.channel[f'channel_{self.get_channel_id()}']['template_data']['category'][lang] = item_specifics

		return product

	def channel_assign_shipping_template(self, product, template_data):
		dimension_detail_list = template_data.get('dimensions')
		if not dimension_detail_list:
			return product

		for dimension_name, dimension_detail in dimension_detail_list.items():
			if dimension_name in ['weight_unit']:
				product['channel'][f'channel_{self.get_channel_id()}'][f'{dimension_name}s'] = dimension_detail
				continue

			if not dimension_detail.get('override') and not dimension_detail.get('mapping'):
				continue

			value_template = (
				dimension_detail.override
				if dimension_detail.override
				else dimension_detail.mapping
			)

			new_value = self.assign_attribute_to_field(value_template, product)

			if to_decimal(new_value):
				product['channel'][f'channel_{self.get_channel_id()}'][dimension_name] = to_decimal(new_value, 4)

		return product

	def convert_catalog_value_type(self, status_changed, specific):
		"""The value and the override type are json
		Convert a value from a string (a result of the func `assign_attribute_to_field`
		to right type)
		if status_changed mean the value is got from the mapping's value
		otherwise is got from the override

		Walmart have 5 attributes type: string, array, number, integer, object
		"""

		def convert_string(spec_val):
			return strip_html_tag(to_str(spec_val))

		def convert_number(spec_val):
			return to_decimal(spec_val, 2)

		def convert_integer(spec_val):
			return to_int(spec_val)

		def convert_object(spec_val):
			if isinstance(spec_val, dict):
				return spec_val

			try:
				val = literal_eval(spec_val)
			except:
				val = {}

			return val

		def convert_array(spec_val):
			if isinstance(spec_val, list):
				return spec_val

			try:
				val = to_str(spec_val).split(',')
			except:
				val = ''

			return val

		if not status_changed:
			value = specific.get('override')
		else:
			try:
				spec_type = specific.get('type')
				value = locals()[f'convert_{spec_type}'](specific.get('value'))
			except Exception as e:
				value = ''
				self.log_by_level({'Exception': e, 'specific': specific}, 'convert_catalog_value_type', 3)

		return value

	def get_order_by_id(self, purchase_order_id) -> Response:
		order = self.api(f'orders/{purchase_order_id}')
		self.log_by_level(order, 'get_order_by_id', 1)

		if order.result != Response.SUCCESS or self._last_status > 300:
			return Response().error()

		return Response().success(order.data.order)

	# currently, we do not support cancel, refund from the mainstore to the channel
	# def channel_order_cancel(self, order_id, order: Order, current_order) -> Response:
	# 	"""cancel order and update the inventory
	# 	1. cancel all order lines
	# 	2. get the inventory of the products
	# 	3. update new inventory to walmart
	# 	"""
	#
	# 	def create_order_line() -> dict:
	# 		nonlocal total_product, data
	#
	# 		for product_index in range(1, total_product + 1):
	# 			order_line_add = {
	# 				'lineNumber': product_index,
	# 				'orderLineStatuses': {
	# 					'orderLineStatus': {
	# 						'status': self.ORDER_STATUS[Order.CANCELED],
	# 						'cancellationReason': cancel_seller,
	# 						'statusQuantity': {
	# 							'unitOfMeasurement': 'EACH',
	# 							'amount': '1'
	# 						}
	# 					}
	# 				}
	# 			}
	#
	# 			order_line.append(order_line_add)
	#
	# 			data = {
	# 				'orderCancellation': {
	# 					'orderLines': {
	# 						'orderLine': order_line
	# 					}
	# 				}
	# 			}
	#
	# 		return data

		def get_inventory():
			""" in the walmart order, each order line is one item
			a product can appear in multi-lines. use two loop to get
			current inventory, qty in order
			update the feed inventory later
			"""
			nonlocal product_inventory

			for product in order.products:
				inventory = self.api(f'inventory?sku={product.product_sku}')

				if inventory.result != Response.SUCCESS or self._last_status > 300:
					continue

				current_inventory = to_int(inventory.data.get('inventory', {}).get('quantity', {}).get('amount'))
				lag_time = to_int(inventory.data.get('inventory', {}).get('fulfillmentLagTime'))
				product_inventory[product.product_sku] = {
					'qty': current_inventory,
					'lag_time': lag_time
				}

			for product in order.products:
				sku = product.product_sku
				if product_inventory[sku]:
					product_inventory[sku] = product_inventory[sku]['qty'] + 1

			return product_inventory

		def update_inventory_feed():
			nonlocal feed_inventory

			feed_header = {
				'version': 1.4,
				'feedDate': ModelChannelsWalmartca.get_current_time_feed(self._FEED_FORMAT_TIME),
			}

			for sku, info in product_inventory.items():
				item = {
					'sku': sku,
					'quantity': {
						'unit': 'EACH',
						'amount': info['qty']
					},
					'fulfillmentLagTime': info['lag_time']
				}
				inventory_list.append(item)

			feed_inventory = {
				'InventoryFeed': {
					'InventoryHeader': feed_header,
					'inventory': inventory_list
				}
			}

			return feed_inventory

		cancel_customer = 'CUSTOMER_REQUESTED_SELLER_TO_CANCEL'
		cancel_seller = 'CANCEL_BY_SELLER'
		log_name = 'channel_order_cancel'
		total_product = len(order.products)
		order_line = list()
		data = dict()
		product_inventory, inventory_update = dict(), dict()
		inventory_list = []

		try:
			data = create_order_line()
			order_canceled = self.api(f'orders/{order_id}/cancel', data = data, api_type = 'post')

			if order_canceled.result != Response.SUCCESS or self._last_status > 300:
				return Response().error()

			self.log_by_level({'data_send': data, 'response': order_canceled}, log_name, 3)

			get_inventory_ = get_inventory()
			feed_inventory = update_inventory_feed()
			response = self.api('feeds/?feedType=inventory', data = feed_inventory, api_type = 'post')

			if response.result != Response.SUCCESS or self._last_status > 300:
				return Response().error()

			self.log_by_level({'inventory_data': feed_inventory, 'response': response}, log_name, 3)

		except Exception as e:
			log_traceback('walmart_ca_channel_order_cancel')

		return Response().success()

	def channel_order_completed(self, order_id, order: Order, current_order) -> Response:
		"""update status shipped
		in the walmart_ca, the status of the order is not have completed order
		"""

		def create_order_data() -> dict:
			nonlocal order, current_order

			order_line = list()
			total_product = len(order.products)
			seller_order_id = order.id
			carrier_key = 'carrier' if to_str(order.shipments.tracking_company).upper() in self.TRACKING_COMPANY else 'otherCarrier'
			method_code_value = order.shipments.methodCode if order.shipments.methodCode in self.SHIPPING_METHOD else 'Standard'
			status_order_update = self.ORDER_STATUS[Order.COMPLETED]
			shipped_at = get_current_time(self._ORDER_FORMAT_TIME)
			country_from = self.get_user_info().get('country') or 'CA'

			for product_index in range(1, total_product + 1):
				order_line_add = {
					'lineNumber': product_index,
					'sellerOrderId': seller_order_id,
					'shipFromCountry': country_from,
					'orderLineStatuses': {
						'orderLineStatus': [
							{
								'status': status_order_update,
								'statusQuantity': {
									'unitOfMeasurement': 'EACH',
									'amount': '1'
								},
								'trackingInfo': {
									'shipDateTime': shipped_at,
									'carrierName': {
										carrier_key: order.shipments.tracking_company
									},
									'methodCode': method_code_value,
									'trackingNumber': order.shipments.tracking_number,
									'trackingURL': order.shipments.tracking_url
								}
							}
						]
					}
				}

				order_line.append(order_line_add)

			data = {
				'orderShipment': {
					'orderLines': {
						'orderLine': order_line
					}
				}
			}

			return data

		try:
			# channel_default = self.get_channel_default()
			purchase_id = order.get('id') or order.get('purchaseOrderId')
			params = create_order_data()

			response = self.api(f'orders/{purchase_id}/shipping', data = params, api_type = 'post')

			data_log = {
				'param': to_str(params),
				'order_id': to_str(order_id),
				'purchase_id': to_str(purchase_id),
				'response': to_str(response)
			}

			self.log_by_level(data_log, 'channel_order_completed', 3)

			if response.result != Response.SUCCESS or self._last_status > 300:
				self.log(response.data, 'walmart_ca_channel_order_completed')
				return Response().error()

			return_order = {'status': self.ORDER_STATUS[Order.COMPLETED]}

		except:
			log_traceback('walmart_ca_channel_order_completed')
			return Response().error()

		return Response().success(return_order)

	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(order, '+')

	def order_sync_inventory(self, convert: Order, setting_order):
		# setting_order = True if self._state.channel.config.setting.get('order', {}).get('status') != 'disable' else False
		if setting_order:
			return Response().success()

		return self._order_sync_inventory(convert)

	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		pass

	def order_import(self, convert: Order, order: Order, orders_ext):
		pass

	def api(self, endpoint: str, data: dict = None, api_type: str = "get", headers: dict = None, content_type = 'xml', ver: str = 'v3/ca') -> Response:
		def combine_url() -> str:
			"""Because Walmart auth_signature needs full path URL
			to generate an auth signature
			Combine params to have one sync URL
			(URL when generate and URL when send request)
			"""
			nonlocal data
			nonlocal url
			nonlocal api_type

			if not self._url_base:
				self.get_url_base()

			url = self._url_base + '/' + ver.strip('/') + '/' + endpoint
			if api_type.lower() != 'get' or not data or not isinstance(data, dict):
				return url

			extend_url = ''
			for k, v in data.items():
				if v:
					extend_url += '&' + to_str(k) + '=' + to_str(v)

			extend_url = extend_url.strip('&')

			return url + '?' + extend_url

		if not self._url_base:
			self.get_url_base()

		url = combine_url()
		wm_auth_sign, wm_timestamp = self.generate_digital_signature(url, api_type)
		headers_basic = {
			"WM_QOS.CORRELATION_ID": str(uuid.uuid4()),
			"WM_SVC.NAME": "LitCommerce",
			"WM_CONSUMER.CHANNEL.TYPE": self.get_channel_type(),
			"WM_CONSUMER.ID": self.get_consumer_id(),
			"WM_SEC.AUTH_SIGNATURE": wm_auth_sign,
			"WM_SEC.TIMESTAMP": wm_timestamp
		}
		response = self.requests(url = url, data = data, method = api_type, headers = headers_basic, content_type = content_type)
		if response.get('data') is None:
			response['data'] = Prodict()

		return response

	def get_draft_extend_channel_data(self, product):
		extend_data = dict()
		description = nl2br(product.description)

		if description != product.description:
			extend_data['description'] = description

		if not product.sku and self._state.channel.config.api.auto_gen_sku:
			product.sku = ModelChannelsWalmartca.random_sku(25)

		# flag: map `sku` field to `gtin`
		if product.sku and self._state.channel.config.api.sku_to_gtin:
			extend_data['gtin'] = product.sku

		if product.upc and self._state.channel.config.api.upc_to_gtin:
			extend_data['gtin'] = product.upc

		id_check = {
			'gtin': product.gtin,
			'upc': product.upc,
			'ean': product.ean,
		}
		id_validate = self.validate_product_id(id_check)
		for type_, id_ in id_validate.items():
			extend_data[type_] = id_

		# prepare the group_id as variant_group_id
		if not product.is_variant and product.variant_count:
			extend_data['group_id'] = ModelChannelsWalmartca.random_sku(20)

		return extend_data

	def validate_product_id(self, id_check) -> dict:
		"""validate product_id [gtin, upc, ean]
		return dict - if not have change return original_dict
		"""
		validates = {
			'gtin': 'GTIN14',
			'upc': 'UPC',
			'ean': 'EAN13'

		}
		result = {
			'gtin': '',
			'upc': '',
			'ean': ''
		}
		is_change = False
		for id_ in id_check.values():
			if not id_:
				continue

			for type_, validate_ in validates.items():
				if barcodenumber.check_code(validate_, id_):
					is_change = True
					result[type_] = id_

		return result if is_change else id_check

	def get_state_code_from_name(self, name):
		if name:
			for code, state_name in self.STATES.items():
				if to_str(name).lower() == to_str(code).lower():
					return state_name
		return name

	def get_country_name_from_code(self, country_code):
		country_name = self.COUNTRIES.get(country_code, '')
		return country_name or country_code

	STATES = {'AL': 'Alabama', 'AK': 'Alaska', 'AS': 'American Samoa', 'AZ': 'Arizona', 'AR': 'Arkansas', 'AF': 'Armed Forces Africa', 'AA': 'Armed Forces Americas', 'AC': 'Armed Forces Canada', 'AE': 'Armed Forces Europe', 'AM': 'Armed Forces Middle East', 'AP': 'Armed Forces Pacific', 'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware', 'DC': 'District of Columbia', 'FM': 'Federated States Of Micronesia', 'FL': 'Florida', 'GA': 'Georgia', 'GU': 'Guam', 'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas', 'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MH': 'Marshall Islands', 'MD': 'Maryland', 'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'MP': 'Northern Mariana Islands', 'OH': 'Ohio',
	          'OK': 'Oklahoma', 'OR': 'Oregon', 'PW': 'Palau', 'PA': 'Pennsylvania', 'PR': 'Puerto Rico', 'RI': 'Rhode Island', 'SC': 'South Carolina', 'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont', 'VI': 'Virgin Islands', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming', 'AB': 'Alberta', 'BC': 'British Columbia', 'MB': 'Manitoba', 'NF': 'Newfoundland', 'NB': 'New Brunswick', 'NS': 'Nova Scotia', 'NT': 'Northwest Territories', 'NU': 'Nunavut', 'ON': 'Ontario', 'PE': 'Prince Edward Island', 'QC': 'Quebec', 'SK': 'Saskatchewan', 'YT': 'Yukon Territory', 'NDS': 'Niedersachsen', 'BAW': 'Baden-Württemberg', 'BAY': 'Bayern', 'BER': 'Berlin', 'BRG': 'Brandenburg', 'BRE': 'Bremen', 'HAM': 'Hamburg', 'HES': 'Hessen', 'MEC': 'Mecklenburg-Vorpommern', 'NRW': 'Nordrhein-Westfalen', 'RHE': 'Rheinland-Pfalz', 'SAR': 'Saarland', 'SAS': 'Sachsen', 'SAC': 'Sachsen-Anhalt', 'SCN': 'Schleswig-Holstein',
	          'THE': 'Thüringen', 'NO': 'Niederösterreich', 'OO': 'Oberösterreich', 'SB': 'Salzburg', 'KN': 'Kärnten', 'ST': 'Steiermark', 'TI': 'Tirol', 'BL': 'Burgenland', 'VB': 'Voralberg', 'AG': 'Aargau', 'AI': 'Appenzell Innerrhoden', 'BE': 'Bern', 'BS': 'Basel-Stadt', 'FR': 'Freiburg', 'GE': 'Genf', 'GL': 'Glarus', 'JU': 'Graubünden', 'LU': 'Luzern', 'NW': 'Nidwalden', 'OW': 'Obwalden', 'SG': 'St. Gallen', 'SH': 'Schaffhausen', 'SO': 'Solothurn', 'SZ': 'Schwyz', 'TG': 'Thurgau', 'UR': 'Uri', 'VD': 'Waadt', 'VS': 'Wallis', 'ZG': 'Zug', 'ZH': 'Zürich', 'A Coruña': 'A Coruña', 'Alava': 'Alava', 'Albacete': 'Albacete', 'Alicante': 'Alicante', 'Almeria': 'Almeria', 'Asturias': 'Asturias', 'Avila': 'Avila', 'Badajoz': 'Badajoz', 'Baleares': 'Baleares', 'Barcelona': 'Barcelona', 'Burgos': 'Burgos', 'Caceres': 'Caceres', 'Cadiz': 'Cadiz', 'Cantabria': 'Cantabria', 'Castellon': 'Castellon', 'Ceuta': 'Ceuta', 'Ciudad Real': 'Ciudad Real', 'Cordoba': 'Cordoba', 'Cuenca': 'Cuenca',
	          'Girona': 'Girona', 'Granada': 'Granada', 'Guadalajara': 'Guadalajara', 'Guipuzcoa': 'Guipuzcoa', 'Huelva': 'Huelva', 'Huesca': 'Huesca', 'Jaen': 'Jaen', 'La Rioja': 'La Rioja', 'Las Palmas': 'Las Palmas', 'Leon': 'Leon', 'Lleida': 'Lleida', 'Lugo': 'Lugo', 'Madrid': 'Madrid', 'Malaga': 'Malaga', 'Melilla': 'Melilla', 'Murcia': 'Murcia', 'Navarra': 'Navarra', 'Ourense': 'Ourense', 'Palencia': 'Palencia', 'Pontevedra': 'Pontevedra', 'Salamanca': 'Salamanca', 'Santa Cruz de Tenerife': 'Santa Cruz de Tenerife', 'Segovia': 'Segovia', 'Sevilla': 'Sevilla', 'Soria': 'Soria', 'Tarragona': 'Tarragona', 'Teruel': 'Teruel', 'Toledo': 'Toledo', 'Valencia': 'Valencia', 'Valladolid': 'Valladolid', 'Vizcaya': 'Vizcaya', 'Zamora': 'Zamora', 'Zaragoza': 'Zaragoza', 'ACT': 'Australian Capital Territory', 'JBT': 'Jervis Bay Territory', 'NSW': 'New South Wales', 'QLD': 'Queensland', 'SA': 'South Australia', 'TAS': 'Tasmania', 'VIC': 'Victoria', }

	COUNTRIES = {"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon",
	             "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar",
	             "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China",
	             "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen",
	             "DZ": "Algeria", "US": "United States", "USA": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India",
	             "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}

	TRACKING_COMPANY = ["UPS", "USPS", "FedEx", "CPC", "PCLINT", "DHL", "GLB", "PURINTL_SWWGROUND", "FEDEX_SWWEXPRESS", "17Track", "ASL", "CANPAR", "CEVA", "LOOMIS", "SAMEDAY", "SWYFT", "TFORCE", "UBI", "JIAYOU"]

	SHIPPING_METHOD = ["Standard", "Express", "OneDay", "Freight", "WhiteGlove", "Value"]
