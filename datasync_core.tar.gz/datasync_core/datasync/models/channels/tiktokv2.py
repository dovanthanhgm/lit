import copy
import math
import re
from io import BytesIO

import requests
from PIL import Image

from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderHistory, Shipment, OrderAddress, OrderItemOption
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute, ProductVideo

class ModelChannelsTiktokV2(ModelChannel):
	PRODUCT_IDENTIFIER = ["gtin", "ean", "upc", "isbn"]

	SHIP_BY_SELLER = "SELLER"

	TIKTOK_MIN_IMAGE_SIDE = 300

	ONE_DAY_IN_SECONDS: int = 86400

	TIKTOK_CURRENCY = {
		"US": "USD",
		"GB": "GBP",
		"ID":  "IDR",
		"TH": "THB",
		"MY": "MYR",
		"PH": "PHP",
		"VN": "VND",
		"SG": "SGD"
	}

	TIKTOK_PRODUCT_STATUS = {
		"ACTIVATE": "ACTIVATE",
		"ALL": "ALL",
		"DRAFT": "DRAFT",
		"PENDING": "PENDING",
		"FAILED": "FAILED",
		"PLATFORM_DEACTIVATED": "PLATFORM_DEACTIVATED",
		"SELLER_DEACTIVATED": "SELLER_DEACTIVATED",
		"FREEZE": "FREEZE",
		"DELETED": "DELETED"
	}

	ORDER_STATUS = {
		"UNPAID": Order.AWAITING_PAYMENT,
		"ON_HOLD": Order.READY_TO_SHIP,
		"AWAITING_SHIPMENT": Order.READY_TO_SHIP,
		"AWAITING_COLLECTION": Order.SHIPPING,
		"PARTIALLY_SHIPPING": Order.SHIPPING,
		"IN_TRANSIT": Order.COMPLETED,
		"DELIVERED": Order.COMPLETED,
		"COMPLETED": Order.COMPLETED,
		"CANCELLED": Order.CANCELED
	}

	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category', 'shipping']

	TIKTOK_CATEGORY_RULES = {
		"isSizeChartMandatory": False,
		"supportCod": False,
		"isSizeChartSupport": False
	}

	STATES = {'AL': 'Alabama', 'AK': 'Alaska', 'AS': 'American Samoa', 'AZ': 'Arizona', 'AR': 'Arkansas', 'AF': 'Armed Forces Africa', 'AA': 'Armed Forces Americas', 'AC': 'Armed Forces Canada', 'AE': 'Armed Forces Europe', 'AM': 'Armed Forces Middle East', 'AP': 'Armed Forces Pacific', 'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware', 'DC': 'District of Columbia', 'FM': 'Federated States Of Micronesia', 'FL': 'Florida', 'GA': 'Georgia', 'GU': 'Guam', 'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas', 'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MH': 'Marshall Islands', 'MD': 'Maryland', 'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'MP': 'Northern Mariana Islands', 'OH': 'Ohio',
	          'OK': 'Oklahoma', 'OR': 'Oregon', 'PW': 'Palau', 'PA': 'Pennsylvania', 'PR': 'Puerto Rico', 'RI': 'Rhode Island', 'SC': 'South Carolina', 'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont', 'VI': 'Virgin Islands', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming', 'AB': 'Alberta', 'BC': 'British Columbia', 'MB': 'Manitoba', 'NF': 'Newfoundland', 'NB': 'New Brunswick', 'NS': 'Nova Scotia', 'NT': 'Northwest Territories', 'NU': 'Nunavut', 'ON': 'Ontario', 'PE': 'Prince Edward Island', 'QC': 'Quebec', 'SK': 'Saskatchewan', 'YT': 'Yukon Territory', 'NDS': 'Niedersachsen', 'BAW': 'Baden-Württemberg', 'BAY': 'Bayern', 'BER': 'Berlin', 'BRG': 'Brandenburg', 'BRE': 'Bremen', 'HAM': 'Hamburg', 'HES': 'Hessen', 'MEC': 'Mecklenburg-Vorpommern', 'NRW': 'Nordrhein-Westfalen', 'RHE': 'Rheinland-Pfalz', 'SAR': 'Saarland', 'SAS': 'Sachsen', 'SAC': 'Sachsen-Anhalt', 'SCN': 'Schleswig-Holstein',
	          'THE': 'Thüringen', 'NO': 'Niederösterreich', 'OO': 'Oberösterreich', 'SB': 'Salzburg', 'KN': 'Kärnten', 'ST': 'Steiermark', 'TI': 'Tirol', 'BL': 'Burgenland', 'VB': 'Voralberg', 'AG': 'Aargau', 'AI': 'Appenzell Innerrhoden', 'BE': 'Bern', 'BS': 'Basel-Stadt', 'FR': 'Freiburg', 'GE': 'Genf', 'GL': 'Glarus', 'JU': 'Graubünden', 'LU': 'Luzern', 'NW': 'Nidwalden', 'OW': 'Obwalden', 'SG': 'St. Gallen', 'SH': 'Schaffhausen', 'SO': 'Solothurn', 'SZ': 'Schwyz', 'TG': 'Thurgau', 'UR': 'Uri', 'VD': 'Waadt', 'VS': 'Wallis', 'ZG': 'Zug', 'ZH': 'Zürich', 'A Coruña': 'A Coruña', 'Alava': 'Alava', 'Albacete': 'Albacete', 'Alicante': 'Alicante', 'Almeria': 'Almeria', 'Asturias': 'Asturias', 'Avila': 'Avila', 'Badajoz': 'Badajoz', 'Baleares': 'Baleares', 'Barcelona': 'Barcelona', 'Burgos': 'Burgos', 'Caceres': 'Caceres', 'Cadiz': 'Cadiz', 'Cantabria': 'Cantabria', 'Castellon': 'Castellon', 'Ceuta': 'Ceuta', 'Ciudad Real': 'Ciudad Real', 'Cordoba': 'Cordoba', 'Cuenca': 'Cuenca',
	          'Girona': 'Girona', 'Granada': 'Granada', 'Guadalajara': 'Guadalajara', 'Guipuzcoa': 'Guipuzcoa', 'Huelva': 'Huelva', 'Huesca': 'Huesca', 'Jaen': 'Jaen', 'La Rioja': 'La Rioja', 'Las Palmas': 'Las Palmas', 'Leon': 'Leon', 'Lleida': 'Lleida', 'Lugo': 'Lugo', 'Madrid': 'Madrid', 'Malaga': 'Malaga', 'Melilla': 'Melilla', 'Murcia': 'Murcia', 'Navarra': 'Navarra', 'Ourense': 'Ourense', 'Palencia': 'Palencia', 'Pontevedra': 'Pontevedra', 'Salamanca': 'Salamanca', 'Santa Cruz de Tenerife': 'Santa Cruz de Tenerife', 'Segovia': 'Segovia', 'Sevilla': 'Sevilla', 'Soria': 'Soria', 'Tarragona': 'Tarragona', 'Teruel': 'Teruel', 'Toledo': 'Toledo', 'Valencia': 'Valencia', 'Valladolid': 'Valladolid', 'Vizcaya': 'Vizcaya', 'Zamora': 'Zamora', 'Zaragoza': 'Zaragoza', 'ACT': 'Australian Capital Territory', 'JBT': 'Jervis Bay Territory', 'NSW': 'New South Wales', 'QLD': 'Queensland', 'SA': 'South Australia', 'TAS': 'Tasmania', 'VIC': 'Victoria', }

	MAPPING_CARRIER_US = {"USPS": "7117858858072016686", "UPS": "7117859084333745966", "FedEx": "7129720299146184490", "LaserShip": "7132708441138677550",
	                      "OnTrac": "7132721393761781550", "Better Trucks": "7212608507307099946", "TForce": "7212611208266909483", "DHL eCommerce": "7220301902846625579",
	                      "Amazon Logistics": "7248600717110282027", "AxleHire": "7254084300713232174", "Lone Star Overnight": "7254085043432195882", "Deliver-it": "7260759364112221953",
	                      "GLS US": "7260760118063531777", "Spee-Dee Delivery Service": "7260761851384825602", "Wizmo": "7260762638932510466"}

	MAPPING_CARRIER_UK = {"EVRi": "6599541761693270018", "FedEx UK": "6618402578756190210", "DHL UK": "6639580521074524161", "Yodel UK": "6641219975896514562", "UK Mail": "6649195729745887233",
	                      "Parcel2Go": "6654133961797746689", "DPD UK": "6657598289359323137", "DX Delivery": "6658174162568658945", "UPS UK": "6667705672463351809", "Royal Mail": "6671794738251726849",
	                      "Parcel Force": "6699476450581430274", "Arrow XL": "6723065376080412674", "APC Overnight": "6760565269699084290", "Panther UK": "6760727669580627970", "Amazon Logistics": "7046331959399679746",
	                      "DHLExpress": "7074863218149033730", "Fastway Ireland": "7111573973179041538", "AO Logistics": "7280421693011527425"}

	def __init__(self):
		super().__init__()
		self._all_products = None
		self._shop_info = None
		self._shop_id = None
		self._shop_cipher = None
		self._api_url = None
		self._next_cursor_product = ""
		self._is_finish_pull_product = False
		self._last_product_response = None
		self._default_warehouse_id = None
		self._total_number_orders = None
		self._is_finish_pull_order = False
		self._next_cursor_order = False
		self._product_page_number = 1
		self._product_pull_type = "active"
		self._tiktok_product_status = None
		self._tiktok_warehouses = list()

	def get_api_info(self):
		return {
			"app_key": to_str(self._state.channel.config.api.app_key),
			"app_secret": to_str(self._state.channel.config.api.app_secret),
			"access_token": to_str(self._state.channel.config.api.access_token),
		}

	def get_app_mode(self):
		app_mode = self._state.channel.config.api.mode
		if not app_mode:
			return get_config_ini("tiktok", "mode")
		return app_mode

	def get_api_url(self):
		mode = self.get_app_mode()
		if mode == "sandbox":
			self._api_url = "https://open-api-sandbox.tiktokglobalshop.com"
		else:
			self._api_url = "https://open-api.tiktokglobalshop.com"
		return self._api_url

	def get_url_refresh_token(self):
		mode = self.get_app_mode()
		url = "https://auth{}.tiktok-shops.com/api/token/refreshToken"
		if mode == "sandbox":
			url = url.format("-sandbox")
		else:
			url = url.format("")
		return url

	def set_last_product_response(self, response):
		self._last_product_response = response

	def get_last_product_response(self):
		return self._last_product_response

	def get_seller_base_region(self):
		return self._state.channel.config.api.seller_base_region

	def api(self, path = "", params = None, body = None, headers = None, files = None, method = "get"):
		url = self.get_api_url() + to_str(path)
		secret = self.get_app_secret()
		access_token = self.get_access_token()
		app_key = self.get_app_key()
		shop_cipher = self.get_shop_cipher()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		headers["Content-Type"] = "application/json"
		headers["x-tts-access-token"] = access_token

		default_params = {
			"timestamp": to_int(time.time()),
			"access_token": access_token,
			"app_key": app_key,
			"shop_cipher": shop_cipher
		}
		path_exclude_shop_cipher = ["authorization/202309/shops", "product/202309/images/upload", "product/202309/files/upload"]
		for item in path_exclude_shop_cipher:
			if item in url:
				del default_params["shop_cipher"]
		if params:
			params = {**default_params, **params}
		else:
			params = default_params
		params["sign"] = self.generate_signature(path, params, body, secret, files)
		res = self.requests(url, params, body, headers = headers, files = files, method = method)
		retry = 0
		while (res is False) or ('expected Array to be a Hash' in to_str(res)) or (
				"Exceeded 2 calls per second for api client. Reduce request rates to resume uninterrupted service" in to_str(
			res)) or self._last_status >= 500:
			retry += 1
			time.sleep(2)
			res = self.requests(url, params, body, headers = headers, method = method)
			if retry > 5:
				break
		return res

	@staticmethod
	def generate_signature(path, params, body, secret, files):
		# sort params alphabet
		sorted_params = dict(sorted(params.items()))
		input_str = path
		for key, value in sorted_params.items():
			if key == "access_token" or key == "sign":
				continue
			input_str += to_str(key) + to_str(value)
		if not files:
			input_str += to_str(body)
		input_str = secret + input_str + secret
		signature = hash_hmac(algo = "sha256", data = input_str, key = secret)
		return signature

	def refresh_access_token(self):
		url = self.get_url_refresh_token()
		secret_key = self._state.channel.config.api.app_secret
		refresh_token = self._state.channel.config.api.refresh_token
		app_key = self._state.channel.config.api.app_key
		headers = {
			"Content-Type": "application/json",
			"User-Agent": get_random_useragent()
		}
		body = {
			"app_key": app_key,
			"app_secret": secret_key,
			"refresh_token": refresh_token,
			"grant_type": "refresh_token",
		}
		request_options = {
			"headers": headers,
			"json": body,
			"verify": True
		}
		refresh_data = requests.request(method = "post", url = url, **request_options)
		refresh_error = {
			"method": "POST",
			"header": to_str(refresh_data.headers),
			"status": refresh_data.status_code,
			"body": body,
			"response": refresh_data.text
		}
		try:
			refresh_data = refresh_data.json()
		except:
			log_traceback()
		if refresh_data["message"].lower() != Response().SUCCESS:
			self.log_request_error(url, **refresh_error)
			return False
		new_access_token = refresh_data["data"]["access_token"]
		new_refresh_token = refresh_data["data"]["refresh_token"]
		self._state.channel.config.api.access_token = new_access_token
		self._state.channel.config.api.refresh_token = new_refresh_token
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return new_access_token

	def requests(self, url, params = None, body = None, headers = None, files = None, method = "get", retry = 0):
		response = False
		request_options = {
			"headers": headers,
			"verify": True
		}
		if params:
			request_options["params"] = params
		if method in ["post", "put"] and body:
			if files:
				if isinstance(headers, dict) and headers.get('Content-Type'):
					del headers["Content-Type"]
				request_options["files"] = files
				request_options["data"] = body
			else:
				request_options["json"] = body
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code

			def log_request_error(res):
				error = {
					"method": method,
					"header": to_str(res.headers),
					"status": res.status_code,
					"param": params,
					"body": body,
					"response": response.text
				}
				self.log_request_error(url, **error)

			if response.status_code == 401:
				new_access_token = self.refresh_access_token()
				if not new_access_token:
					self.set_action_stop(True)
					return response
				self._state.channel.config.api.access_token = new_access_token
				params["access_token"] = new_access_token
				# res = self.requests(url, params, body, method = method)
				response = requests.request(method, url, **request_options)
				self._last_status = response.status_code
				if response.status_code == 401:
					self.set_action_stop(True)
					return response
			if response.status_code > 300 or self.is_log():
				log_request_error(response)
			response_data = json_decode(response.text)
			if response_data and response_data["message"].lower() != Response().SUCCESS:
				log_request_error(response)
			if response_data:
				try:
					response_prodict = Prodict(**response_data)
				except Exception:
					response_prodict = response_data
				response_data = response_prodict
		except (requests.exceptions.SSLError, requests.exceptions.ReadTimeout) as e:
			if retry < 5:
				retry += 1
				time.sleep(retry * 2)
				return self.requests(url, params, body, headers, files, method, retry)
		except Exception:
			self.log_traceback()
		return response_data

	def log_response(self, log_data, log_name: str) -> None:
		self.log(log_data, log_name)

	def get_shop_api(self, path = "", params = None, body = None, method = "get", ver = "202309"):
		path = f"/authorization/{ver}/{path.strip('/')}"
		return self.api(path = path, params = params, body = body, method = method)

	def product_api(self, path = "", params = None, body = None, headers = None, files = None, method = "get", ver = "202309"):
		path = f"/product/{ver}/{path.strip('/')}"
		return self.api(path = path, params = params, body = body, headers = headers, files = files, method = method)

	def order_api(self, path = "", params = None, body = None, headers = None, method = "get", ver = "202309"):
		path = f"/order/{ver}/{path.strip('/')}"
		return self.api(path = path, params = params, body = body, headers = headers, method = method)

	def validate_api_info(self):
		validate = super().validate_api_info()
		if validate.result.lower() != Response().SUCCESS:
			return validate
		app_key = to_str(self._state.channel.config.api.app_key)
		app_secret = to_str(self._state.channel.config.api.app_secret)
		access_token = to_str(self._state.channel.config.api.access_token)
		if not (app_key, app_secret, access_token):
			return Response().error(msg = "Tiktok shop API invalid")
		return Response().success()

	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		try:
			shop_info = self.get_shop_api("shops")
			shop_id = shop_info["data"]["shops"][0]["id"]
			shop_cipher = shop_info["data"]["shops"][0]["cipher"]
			self._state.channel.config.api.shop_id = shop_id
			self._state.channel.config.api.shop_cipher = shop_cipher
			default_warehouse_id = self.get_default_warehouse()
			help_url = "https://help.litcommerce.com/en/article/list-products-on-tiktok-shop-xogtmr/#1-prerequisites-setup"
			text_url = "Details..."
			if not default_warehouse_id:
				return Response().error(msg = f"Please setup a warehouse before connecting to TikTok Shop. {url_to_link(help_url, text_url)}")

			self._state.channel.config.api.default_warehouse_id = default_warehouse_id
			if not shop_info:
				return Response().error(msg = "Tiktok shop API invalid")
		except Exception:
			self.log_traceback()
			return Response().error(msg = "Setup channel error")
		return Response().success()

	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent["result"] != Response().SUCCESS:
			return parent
		shop_id = self.get_shop_id()
		self.set_identifier(shop_id)
		return Response().success()

	def after_create_channel(self, data):
		# Create webhook receive product audit event
		if is_local():
			return Response().success()
		event_audit_product = "PRODUCT_STATUS_CHANGE"
		events = dict()
		events["products/updated"] = "product/update"
		for event, url in events.items():
			webhook_address = get_server_callback(f"merchant/tiktok/webhook/{data.channel_id}/{url}")
			webhook_data = {
				"address": webhook_address,
				"event_type": event_audit_product
			}
			webhook = self.api("/event/202309/webhooks", body = webhook_data, method = "put")
			self.log(webhook, "tiktok_webhook_response")
			if webhook and webhook["message"].lower() != Response().SUCCESS:
				self.log_response(webhook, "tiktok_webhook_create_failed")
		return Response().success()

	def get_shop_id(self):
		if self._shop_id:
			return self._shop_id
		shop_id = self._state.channel.config.api.shop_id
		self._shop_id = shop_id
		return self._shop_id

	def get_shop_cipher(self):
		return self._state.channel.config.api.shop_cipher

	def get_access_token(self):
		return self._state.channel.config.api.access_token

	def get_app_key(self):
		return self._state.channel.config.api.app_key

	def get_app_secret(self):
		return self._state.channel.config.api.app_secret

	def delay_last_modidied(self):
		return self._state.channel.config.api.delay_last_modified

	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.total = 0
			if not self._state.pull.process.products.id_src:
				self._state.pull.process.products.id_src = 0
			params = {"page_size": 0}
			body = {"status": "ALL"}
			if not self.is_refresh_process():
				if self._request_data.get('include_filters'):
					for field_filter, value in self._request_data['include_filters'].items():
						if field_filter not in ['status', 'sku']:
							continue
						body[field_filter] = value
			products_api = self.product_api("products/search", params = params, body = body, method = "post")
			if products_api and products_api["message"].lower() == Response().SUCCESS:
				total_product = products_api.data.total_count
			else:
				total_product = 0
			self._state.pull.process.products.total = total_product
		if self.is_order_process():
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.total = 0
			start_time = self.get_order_start_time()
			last_modifier = self._state.pull.process.orders.max_last_modified
			filter_condition = {
				"create_time_ge": to_int(to_timestamp(start_time)),
				"sort_order": "DESC"
			}
			if last_modifier:
				filter_condition["update_time_ge"] = to_int(to_timestamp(last_modifier))
				delay_day = to_int(self.delay_last_modidied())
				if delay_day and isinstance(delay_day, int):
					filter_condition["update_time_ge"] = to_int(to_timestamp(last_modifier)) - (self.ONE_DAY_IN_SECONDS * delay_day)
				self.set_order_max_last_modifier(last_modifier)
			total_number_orders = self.get_total_number_orders(filter_condition)
			if total_number_orders:
				self._state.pull.process.orders.total = total_number_orders
		return Response().success()

	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%d %H:%M:%S") > to_timestamp(self._order_max_last_modified, "%Y-%m-%d %H:%M:%S")):
			self._order_max_last_modified = last_modifier

	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear

	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		return next_clear

	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			body = {
				"page_size": 100,  # limit_data,
				"search_status": 4,
				"page_number": 1
			}
			params = {"shop_id": self.get_shop_id()}
			all_products = self.api("products/search", params = params, body = body, method = "post")
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.data.get("products"):
					return next_clear
				prd_ids = list()
				for product in all_products["data"]["products"]:
					id_product = product.get("id")
					prd_ids.append(id_product)
				delete_payload = {
					"product_ids": prd_ids
				}
				res = self.api("products", params = params, body = delete_payload, method = "delete")
				all_products = self.api("products/search", params = params, body = body, method = "post")
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear

	def get_products_main_export(self):
		if self._is_finish_pull_product:
			return Response().finish()
		params = {"page_size": 100}
		body = {"status": "ALL"}
		if self._request_data.get('include_filters'):
			for field_filter, value in self._request_data['include_filters'].items():
				if field_filter not in ['status', 'sku']:
					continue
				body[field_filter] = value
		if self._next_cursor_product:
			params["page_token"] = self._next_cursor_product
		products = self.product_api("products/search", params = params, body = body, method = "post")
		self._next_cursor_product = products.data.next_page_token
		if not self._next_cursor_product:
			self._is_finish_pull_product = True
		return Response().success(data = products["data"]["products"])

	def get_products_ext_export(self, products):
		extend = Prodict()
		for product in products:
			product_id = product.get("id") or product.get("product_id")
			detail_product = self.product_api(f"products/{product_id}")
			extend.set_attribute(product_id, Prodict())
			extend[to_str(product_id)] = detail_product.data
		return Response().success(extend)

	def get_product_id_import(self, convert: Product, product, products_ext):
		product_id = product.get("id") or product.get("product_id")
		return product_id

	def get_product_by_id(self, product_id):
		product_response = self.product_api(f"products/{product_id}")
		if product_response and product_response["message"].lower() == Response().SUCCESS:
			return Response().success(product_response["data"])
		return Response().error(msg = "Get product from tiktok failed")

	def save_attribute_data(self, attribute):
		cate_attributes_data = dict()
		cate_specific_data = dict()
		cate_attributes_data["attribute_id"] = attribute["id"]
		cate_attributes_data["attribute_name"] = attribute["name"]
		cate_attributes_data["attribute_type"] = 3
		cate_specific_data["name"] = attribute["name"]
		cate_specific_data["value"] = attribute.get("option_values") or attribute.get("value_name")
		return cate_attributes_data, cate_specific_data

	def get_tiktok_cate_rules(self, cate_id):
		rules_response = self.product_api(f"categories/{cate_id}/rules")
		if rules_response and rules_response["message"].lower() == Response().SUCCESS:
			category_rules = Prodict.from_dict(self.TIKTOK_CATEGORY_RULES.copy())
			rules_data = rules_response.data
			category_rules["isSizeChartMandatory"] = rules_data.size_chart.is_required
			category_rules["supportCod"] = rules_data.cod.is_supported
			category_rules["isSizeChartSupport"] = rules_data.size_chart.is_supported
			category_rules["productCertifications"] = rules_data.product_certifications
			return category_rules
		return {}

	def tiktok_data_to_template(self, product):
		template_data = dict()
		# Category template
		category_leaf = self.get_tiktok_leaf_cate(product["category_chains"])
		product_attributes = self.convert_product_attributes(product.get("product_attributes"))
		delivery_service_ids = list()
		if product.get("delivery_options"):
			delivery_service_ids = [to_str(delivery_option["id"]) for delivery_option in product.get("delivery_options")]
		brand = product.get("brand", {})
		size_chart = product.get("size_chart", {})
		# warehouse_id = product.skus[0].inventory[0].warehouse_id
		cate_template_data = dict()
		cate_template_data["category_id"] = category_leaf["id"]
		category_path_api = self.get_category_path(channel_type = 'tiktok', type_search = f'{self.get_channel_id()}/category/search', params = {"category_id": category_leaf["id"]})
		cate_template_data["category_name"] = category_leaf["name"]
		if category_path_api and category_path_api.get('data'):
			cate_template_data["category_name"] = category_path_api['data'][0]['path']
		cate_template_data["is_cod_open"] = product.get("is_cod_allowed")
		cate_rules = self.get_tiktok_cate_rules(category_leaf["id"])
		if cate_rules:
			cate_template_data["category_rules"] = cate_rules
		if brand:
			cate_template_data["brand_id"] = brand["id"]
			cate_template_data["brand_name"] = brand["name"]
		if size_chart:
			size_chart_id = size_chart.get("uri")
			if size_chart_id:
				cate_template_data["size_chart_id"] = size_chart_id
			size_chart_urls = size_chart.get("urls")
			if size_chart_urls:
				cate_template_data["size_chart_url"] = size_chart_urls[0]
		prd_attributes = list()
		specific_attributes = list()
		for attribute in product_attributes:
			cate_attributes_data, cate_specific_data = self.save_attribute_data(attribute)
			prd_attributes.append(cate_attributes_data)
			specific_attributes.append(cate_specific_data)
		cate_template_data["product_attributes"] = prd_attributes
		cate_template_data["specifics"] = specific_attributes
		if product.get("certifications"):
			cate_template_data["product_certifications"] = product.get("certifications")
		# Shipping template
		shipping_template_data = dict()
		package_dimensions = product.package_dimensions
		package_weight = product.package_weight
		weight_units = self.convert_weight_text(package_weight.get("unit"))
		dimension_units = self.convert_dimensions_text(package_dimensions.get("unit"))
		if delivery_service_ids:
			shipping_template_data["delivery_services_ids"] = delivery_service_ids
		# shipping_template_data["warehouse_id"] = warehouse_id
		shipping_template_data["weight_unit"] = weight_units
		shipping_template_data['dimension_unit'] = dimension_units
		template_data["category"] = cate_template_data
		template_data["shipping"] = shipping_template_data
		return template_data

	def convert_weight_text(self, unit):
		convert = {"POUND": "lb", "KILOGRAM": "kg"}
		return convert.get(unit)

	def convert_dimensions_text(self, unit):
		convert = {"INCH": "in", "CENTIMETER": "cm"}
		return convert.get(unit)

	def convert_tiktok_status(self, status):
		if status.lower() in ["seller_deactivated", "platform-deactivated"]:
			return "deactivated"
		if status.lower() in ["draft"]:
			return "tiktok_draft"
		return to_str(status.lower())

	def _convert_product_export(self, product, products_ext: Prodict):
		product_data = Product()
		product_id = to_str(product.get("id")) or to_str(product.get("product_id"))
		current_product_ext = products_ext[product_id]
		# Handle import by ids
		if self._request_data.get('include_filters', {}).get("ids"):
			try:
				ids_import = self._request_data.get("include_filters", {}).get("ids") if self._request_data.get("include_filters", {}) else ""
				list_ids = list(map(lambda x: to_str(x.strip()), ids_import.split(', ')))
				if to_str(product_id) not in list_ids:
					return Response().skip()
			except:
				self.log_traceback()
		failed_msg = ""
		if to_str(current_product_ext.status) == self.TIKTOK_PRODUCT_STATUS.get("FAILED"):
			# product_api = self.product_api(f"products/{product_id}", params = {"return_under_review_version": True})
			audit_failed_reasons = current_product_ext.get("audit_failed_reasons", [])
			for failed_reason in audit_failed_reasons:
				position = failed_reason.get("position")
				reasons = failed_reason.get("reasons", [])
				suggestions = failed_reason.get("suggestions", [])
				failed_msg += """
										<div>
											Position: {}
										</div>
										<div>
											<p>Failed Reasons: </p>
											<div style="margin-left: 30px">
												<ul>
												{}
												</ul>
											</div>
										</div>
										<div>
											<p>Suggestions: <p>
											<div style="margin-left: 30px">
												<ul>
												{}
												</ul>
											</div>
										</div>
									""".format(position, "\n".join("<li>{}</li>".format(reason) for reason in reasons),
				                               "\n".join("<li>{}</li>".format(suggestion) for suggestion in suggestions))
		product_data.name = current_product_ext.title
		product_data.lower_name = product_data.name.lower()
		product_data.status = True if to_str(current_product_ext.status) == self.TIKTOK_PRODUCT_STATUS.get("ACTIVATE") else False
		product_data.invisible = True if to_str(current_product_ext.status) != self.TIKTOK_PRODUCT_STATUS.get("ACTIVATE") else False
		default_sku = []
		if current_product_ext.skus:
			default_sku = current_product_ext.skus[0]
			if not default_sku:
				return Response().skip()
		product_data.sku = default_sku.get("seller_sku")
		inventory = default_sku.inventory
		default_qty = 0
		tiktok_warehouses = list()
		for inventory_item in inventory:
			tiktok_warehouses.append({
				"warehouse_id": inventory_item.warehouse_id,
				"quantity": inventory_item.quantity
			})
			default_qty += inventory_item.quantity
		product_data.qty = to_int(default_qty)
		product_data.is_in_stock = True if product_data.qty > 0 else False
		product_data.price = default_sku.get("price", {}).get("sale_price")
		product_data.description = current_product_ext.description
		package_dimensions = current_product_ext.package_dimensions
		package_weight = current_product_ext.package_weight
		product_data.weight_units = self.convert_weight_text(package_weight.get("unit"))
		product_data.dimension_units = self.convert_dimensions_text(package_dimensions.get("unit"))
		product_data.length = package_dimensions.length
		product_data.width = package_dimensions.width
		product_data.height = package_dimensions.height
		product_data.weight = package_weight.value
		region = self.get_seller_base_region()
		product_data.seo_url = f"https://shop.tiktok.com/view/product/{product_id}?region={to_str(region)}"
		channel_data = dict()
		channel_data["tiktok_warehouses"] = tiktok_warehouses
		channel_data["tiktok_sku_id"] = default_sku.id
		channel_data["tiktok_status"] = self.convert_tiktok_status(current_product_ext.status)
		channel_data["region"] = region
		if failed_msg:
			channel_data["warning_msg"] = failed_msg
		else:
			channel_data["warning_msg"] = ""
		identifier_code = default_sku.identifier_code
		if identifier_code and identifier_code.get("code"):
			code_type = identifier_code.type.lower()
			code_value = identifier_code.code
			product_data[code_type] = code_value
		if current_product_ext.main_images:
			for index, image in enumerate(current_product_ext.main_images):
				product_image_data = ProductImage()
				if index == 0:
					product_data.thumb_image.label = image.uri
					product_data.thumb_image.url = image.thumb_urls[0]
					product_data.thumb_image.position = 0
					product_data.thumb_image.image_id = image.uri
					continue
				product_image_data.label = image.uri
				product_image_data.url = image.urls[0]
				product_image_data.position = index
				product_image_data.image_id = image.uri
				product_data.images.append(product_image_data)
		if current_product_ext.get("video"):
			video = current_product_ext.video
			product_video = ProductVideo()
			product_video.url = video.url
			product_video.format = video.format
			product_video.filesize = video.size
			channel_data["tiktok_video_id"] = video.id
			product_data.videos.append(product_video)
		product_data.channel_data = channel_data
		template_data = self.tiktok_data_to_template(current_product_ext)
		product_data.template_data = template_data
		if current_product_ext.skus:
			qty = 0
			for child in current_product_ext.skus:
				if self.product_has_variants(current_product_ext.skus):
					variant_data = ProductVariant()
					variant_data.channel_data["tiktok_sku_id"] = child.id
					if child.sales_attributes:
						tiktok_attributes = list()
						for attribute in child.sales_attributes:
							if attribute.sku_img:
								variant_data.thumb_image.url = attribute.sku_img.urls[0]
								variant_data.thumb_image.label = attribute.sku_img.urls[0]
								variant_data.thumb_image.id = attribute.sku_img.uri
							variant_attribute = ProductVariantAttribute()
							variant_attribute.id = attribute.id
							variant_attribute.attribute_name = attribute.name
							variant_attribute.attribute_value_id = attribute.value_id
							variant_attribute.attribute_value_name = attribute.value_name
							variant_data.attributes.append(variant_attribute)
							tiktok_attributes.append(variant_attribute)
						# variant_data.channel_data["tiktok_attributes"] = tiktok_attributes
					variant_data.id = to_str(child.id)
					variant_data.price = child.get("price", {}).get("sale_price")
					variant_qty = 0
					tiktok_warehouses = list()
					for item in child.inventory:
						tiktok_warehouses.append({
							"warehouse_id": item.warehouse_id,
							"quantity": item.quantity
						})
						variant_qty += to_int(item.quantity)
						variant_data.channel_data["tiktok_warehouses"] = tiktok_warehouses
					variant_data.qty = variant_qty
					variant_data.is_in_stock = True if variant_qty > 0 else False
					variant_data.sku = child.seller_sku
					identifier_code = child.identifier_code
					if identifier_code and identifier_code.get("code"):
						code_type = identifier_code.type.lower()
						code_value = identifier_code.code
						variant_data[code_type] = code_value
					product_data.variants.append(variant_data)
					qty += variant_qty
					product_data.qty = qty
					product_data.is_in_stock = True if qty else False
		return Response().success(product_data)

	def is_product_pull_from_tiktok(self, product):
		# check product source: if channel source id equal current channel id -> True
		check_src = True if product.src.channel_id == self.get_channel_id() else False
		channel_data = product['channel'].get(f'channel_{self.get_channel_id()}', {})
		# if a product has auto_link or user_linked mean product pull from TikTok
		# the product linked with a product in the main channel
		check_link = True if channel_data.get('auto_link') or channel_data.get('user_linked') else False
		return check_src or check_link

	def get_draft_extend_channel_data(self, product):
		description = product.description or product.short_description or product.title
		extend = {}
		if product.description != description:
			extend['description'] = description
		if product.sku and self._state.channel.config.api.sku_to_gtin:
			extend['gtin'] = product.sku
		if product.upc and self._state.channel.config.api.upc_to_gtin:
			extend['gtin'] = product.upc
		package_weight = product.weight
		package_length = product.length
		package_height = product.height
		package_width = product.width
		weight_units = product.weight_units
		dimension_units = product.dimension_units
		if self.is_us() and self.is_imperial_unit(weight_units):
			extend["weight_units"] = "lb"
			extend["dimension_units"] = "in"
			extend["weight"] = to_decimal(self.convert_weight_unit(package_weight, weight_units), 2)
			extend["length"] = math.ceil(self.dimension_to_inch(to_decimal(package_height), dimension_units))
			extend["width"] = math.ceil(self.dimension_to_inch(to_decimal(package_height), dimension_units))
			extend["height"] = math.ceil(self.dimension_to_inch(to_decimal(package_height), dimension_units))
		else:
			extend["weight_units"] = "kg"
			extend["dimension_units"] = "cm"
			extend["weight"] = self.convert_weight_to_kg(package_weight, weight_units)
			extend["length"] = self.convert_dimensions_to_cm(package_length, dimension_units)
			extend["width"] = self.convert_dimensions_to_cm(package_width, dimension_units)
			extend["height"] = self.convert_dimensions_to_cm(package_height, dimension_units)
		# template_data = {
		# 	"shipping": {
		# 		"weight_unit": extend["weight_units"],
		# 		"dimension_unit": extend["dimension_units"]
		# 	}
		# }
		# extend["template_data"] = template_data
		return extend

	def get_sale_warehouses(self):
		warehouses = list()
		if self._tiktok_warehouses:
			return self._tiktok_warehouses
		warehouse_api = self.api("/logistics/202309/warehouses")
		if warehouse_api and warehouse_api["message"].lower() == Response().SUCCESS:
			warehouse_list = warehouse_api.data.get("warehouses", [])
			for warehouse in warehouse_list:
				if warehouse.type == "SALES_WAREHOUSE":
					warehouses.append({
						"id": warehouse.id,
						"name": warehouse.name,
						"is_default": warehouse.is_default
					})
			self._tiktok_warehouses = warehouses
		return warehouses

	def to_variant_inventory(self, product, warehouse_id):
		channel_default = self.get_channel_default()
		channel_default_type = channel_default.get("type")
		inventories = list()
		warehouse_quantities = dict()
		if self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.warehouse_locations_mapping and self.is_us():
			tiktok_warehouses = self.get_sale_warehouses()
			for mapping in self._state.channel.config.setting.qty.warehouse_locations_mapping:
				mapping_location_id = mapping.main.get("location_id")
				mapping_warehouse_id = mapping.channel.get("warehouse_id")
				locations = product.locations
				if channel_default_type == "shopify" and locations:
					for location in locations:
						main_location_id = location.location_id
						main_location_qty = location.qty
						if to_str(main_location_id) == to_str(mapping_location_id):
							if mapping_warehouse_id in warehouse_quantities:
								warehouse_quantities[mapping_warehouse_id] += main_location_qty
							else:
								warehouse_quantities[mapping_warehouse_id] = main_location_qty
				else:
					_wh_id = mapping.channel.get("warehouse_id")
					for warehouse in tiktok_warehouses:
						if warehouse["id"] != _wh_id:
							inventories.append({
								"quantity": 0,
								"warehouse_id": warehouse["id"]
							})
						else:
							inventories.append({
								"quantity": to_int(product.qty),
								"warehouse_id": _wh_id
							})
					return inventories
			for warehouse in tiktok_warehouses:
				if warehouse["id"] not in warehouse_quantities:
					warehouse_quantities[warehouse["id"]] = 0
			inventories = [{"warehouse_id": warehouse_id, "quantity": to_int(qty)} for warehouse_id, qty in warehouse_quantities.items()]
		else:
			if warehouse_id:
				inventories.append({
					"quantity": to_int(product.qty),
					"warehouse_id": warehouse_id
				})
			else:
				inventories.append({
					"quantity": to_int(product.qty),
					"warehouse_id": self.get_default_warehouse_id()
				})
		return inventories

	def get_currency(self):
		region = self.get_seller_base_region().upper()
		currency = self.TIKTOK_CURRENCY.get(region)
		return currency

	def convert_product_certifications(self, certifications):
		convert = list()
		try:
			for certification in certifications:
				images = certification.get("images", [])
				files = certification.get("files", [])
				if images or files:
					convert.append({
						"id": certification.get("id"),
						"files": [{"format": file.get("type"), "id": file.get("id"), "name": file.get("name")} for file in files],
						"images": [{"uri": image.get("id"), "url": image.get("url")} for image in images]
					})
		except:
			self.log_traceback()
		return convert

	def product_import(self, convert: Product, product, products_ext):
		convert_product = self.product_to_tiktok_data(product, products_ext, insert = True)
		if convert_product.result != Response().SUCCESS:
			return convert_product
		post_data = convert_product.data
		pre_check = self.product_api("prerequisites")
		if pre_check and pre_check["message"].lower() == Response().SUCCESS:
			self.log_response(pre_check, "tiktok_pre_check_listing")
			try:
				quantity_limit = json_decode(pre_check.data.shop.gne.product_quantity_limit)
				check_result = quantity_limit.get("check_result", {})
				if check_result.get("is_failed"):
					fail_reasons = check_result.get("fail_reasons")
					msg = fail_reasons if fail_reasons else f"seller create product over limit"
					return Response().error(msg = msg)
			except:
				self.log_traceback()
		response = self.product_api("products", body = post_data, method = "post")
		check_response = self.check_response_import(response, product, 'product')
		if check_response["result"].lower() != Response().SUCCESS:
			return check_response
		product_id = response["data"]["product_id"]
		self.set_last_product_response(response)
		return Response().success(product_id)

	def is_valid_image_type(self, src):
		# return true if image is png jpg jpeg
		match = re.search(r'\.(\w+)(\?.*)?$', src)
		if match:
			file_type = match.group(1)
			return True if file_type.lower() in ["jpg", "jpeg", "png"] else False
		return False

	def handle_description(self, description):
		# remove all comment
		description = re.sub(r'<!--(.*?)-->', '', description, flags = re.DOTALL)
		description = "<body>" + description + "</body>"
		soup = BeautifulSoup(description, 'html.parser')

		for data in soup(['style', 'script']):
			# Remove stype, script
			data.decompose()
		allowed_tags = ['ul', 'li', 'img', 'p', 'strong', 'ol', 'u', 'i']
		img_tags = soup.find_all("img")
		for img_tag in img_tags:
			src = img_tag.get("src", "")
			is_valid_image_type = self.is_valid_image_type(src)
			if not is_valid_image_type:
				img_tag.extract()
				continue
		img_tags_after_clean = soup.find_all("img")
		image_urls = [image["src"] for image in img_tags_after_clean]
		try:
			tiktok_imgs = self.upload_image(images = image_urls, use_case = "DESCRIPTION_IMAGE")
		except:
			tiktok_imgs = []
			self.log_traceback()

		if img_tags_after_clean and tiktok_imgs:
			for index, image in enumerate(img_tags_after_clean):
				img_attrs = copy.deepcopy(image.attrs)
				img_src = image["src"]
				for attr in img_attrs:
					if attr not in ["src", "width", "height"]:
						del image.attrs[attr]
				for tiktok_img in tiktok_imgs:
					if img_src == tiktok_img["origin"]:
						image.attrs["src"] = tiktok_img["url"]
						image.attrs["width"] = tiktok_img["width"]
						image.attrs["height"] = tiktok_img["height"]

		def is_allowed(tag):
			return tag.name in allowed_tags


		for tag in soup.find_all(lambda tag: not is_allowed(tag)):
			tag.unwrap()  # Remove the tag but keep its contents
		# Remove attribute inside tag if not img tag
		tags_with_attributes = soup.find_all(lambda tag: len(tag.attrs) > 0)
		for tag in tags_with_attributes:
			if tag.name != 'img':
				tag.attrs = {}
		# remove tag if not content
		# for tag in soup.find_all():
		# 	if not tag.get_text(strip = True) and tag.name != 'img':
		# 		tag.extract()

		# Remove li tag if not ul
		li_items = soup.find_all('li')
		for li in li_items:
			if li.find_parent(['ul', 'ol']) is None:
				li.unwrap()  # Remove the <li> tag but keep its content
		if self.is_us():
			imgs_to_remove = soup.find_all('img', src = lambda value: value and 'tiktokcdn-us' not in value)
		else:
			imgs_to_remove = soup.find_all('img', src = lambda value: value and 'ibyteimg' not in value)
		for img_tag in imgs_to_remove:
			img_tag.extract()
		for li_tag in soup.find_all(['li']):
			for p_tag in li_tag.find_all(['p', 'em']):
				p_tag.unwrap()
		# #remove ol, ul if of, ul nested
		# for tag in soup.find_all(['ul', 'li', 'ol']):
		# 	for ul_ol_tag in tag.find_all(['ul', 'ol']):
		# 		ul_ol_tag.unwrap()
		cleaned_html = str(soup).replace("\n", "")
		return cleaned_html

	def is_us(self):
		return self.get_seller_base_region() == "US"

	def is_uk(self):
		return self.get_seller_base_region() == "GB"

	def is_imperial_unit(self, weight_unit):
		if not weight_unit:
			return False
		if weight_unit.lower() in ["lb", "lbs", "oz", "imperial"]:
			return True
		return False

	def check_valid_url(self, url):
		if not url.startswith(('http:', 'https:')):
			url = "https://" + url.lstrip("//")
		return url

	def resize(self, url):
		try:
			url = self.check_valid_url(url)
			r = False
			retry = 0
			while r is False and retry < 3:
				try:
					r = requests.get(url, headers = {"User-Agent": get_random_useragent()}, timeout = 60, verify = False)
				except Exception as e:
					time.sleep(1)
					retry += 1
					r = False
					if retry == 1:
						self.log_traceback('tiktok_image_resize_except')
			if not r or r.status_code != 200:
				self.log(r.status_code, 'tiktok_image_resize_error')
				return False
			is_png = False
			if r.headers.get('content-type') == 'image/png':
				is_png = True
			image_data = BytesIO(r.content)
			image = Image.open(image_data)
			width, height = image.size
			if r.headers.get('content-type') == 'image/webp':
				# auto convert from webp to jpeg
				image = image.convert('RGB')
			if height and width and (height < self.TIKTOK_MIN_IMAGE_SIDE or width < self.TIKTOK_MIN_IMAGE_SIDE):
				new_width = max(width, self.TIKTOK_MIN_IMAGE_SIDE)
				new_height = max(height, self.TIKTOK_MIN_IMAGE_SIDE)
				x_offset = (new_width - image.width) // 2
				y_offset = (new_height - image.height) // 2
				new_image = Image.new("RGB" if not is_png else "RGBA", (new_width, new_height), "WHITE")
				new_image.paste(image, (x_offset, y_offset))
				image = new_image
			image_binary = self.convert_image_file_to_binary(image, is_png)
			return image_binary
		except Exception as e:
			self.log_traceback('tiktok_resize_images', f"image error: {url}")
			return False

	def upload_video(self, product_video: ProductVideo):
		file_url = product_video.url
		file_name = os.path.basename(file_url)
		file_name = file_name.split('?')[0]
		file_name = file_name.replace('+', '_')
		binary_data = self.image_to_binary(file_url)
		post_data = {
			"name": file_name,
		}
		files = [
			("data", binary_data)
		]
		video_api = self.product_api("files/upload", body = post_data, files = files, method = "post")
		if video_api and video_api["message"].lower() != Response().SUCCESS:
			return False
		video_id = video_api.data.get("id")
		return video_id

	def product_to_tiktok_data(self, product: Product, products_ext, insert = False):
		is_pull_from_tiktok = self.is_product_pull_from_tiktok(product)
		images = self.extend_images(product)
		if not images:
			return Response().error(msg = "Product images can not be empty")
		"""
		Chinese characters are not allowed.
		For US and UK shops, the product name must have at least 1 character and no more than 255 characters. 
		For shops in other regions, the product name must have at least 25 character and no more than 255 characters.
		"""
		product_name = product.name[:255]
		if not self.is_us() and not self.is_uk() and len(product_name) < 25:
			return Response().error(msg = "Product name must have at least 25 character and no more than 255 characters.")
		if self.detect_chinese_characters(product_name):
			return Response().error(msg = "Chinese characters are not allowed")
		try:
			tiktok_images = self.upload_image(images)
		except:
			tiktok_images = []
			self.log_traceback()
		if not tiktok_images:
			return Response().error(msg = "The product image did not upload successfully")

		description = self.handle_description(product.description)
		post_data = {
			"title": product_name,
			"description": description or product.name,
			"main_images": [{"uri": img["uri"]} for img in tiktok_images],
		}
		if product.videos:
			try:
				update_field = {

				}
				if product.video_id:
					video_id = product.video_id
				else:
					video_id = self.upload_video(product.videos[0])
					if video_id:
						update_field[f'channel.channel_{self.get_channel_id()}.tiktok_video_id'] = video_id
				if video_id:
					post_data['video'] = {
						'id': video_id
					}
			except:
				self.log_traceback('video')
		shipping_template = product.template_data.get("shipping", Prodict())
		category_template = product.template_data.get("category", Prodict())
		weight_units = shipping_template.get("weight_unit")
		dimension_units = shipping_template.get("dimension_unit")
		is_imperial_unit = self.is_imperial_unit(weight_units)
		package_weight = product.weight
		package_length = product.length
		package_height = product.height
		package_width = product.width
		if not package_weight:
			return Response().error(msg = "Package weight is required. Please enter correct package weight in shipping tab.")
		if self.is_us() or self.is_uk():
			if not package_height:
				return Response().error(msg = "Package dimensions are all required. Please enter correct package height in shipping tab.")
			if not package_width:
				return Response().error(msg = "Package dimensions are all required. Please enter correct package width in shipping tab.")
			if not package_length:
				return Response().error(msg = "Package dimensions are all required. Please enter correct package length in shipping tab.")
		if self.is_us() and is_imperial_unit:
			# convert weight to lb and dimension to inch
			post_data["package_weight"] = {
				"unit": "POUND",
				"value": to_str(to_decimal(self.convert_weight_unit(package_weight, weight_units), 2))
			}
			post_data["package_dimensions"] = {
				"unit": "INCH",
				"length": to_str(math.ceil(self.dimension_to_inch(to_decimal(package_length), dimension_units))),
				"width": to_str(math.ceil(self.dimension_to_inch(to_decimal(package_width), dimension_units))),
				"height": to_str(math.ceil(self.dimension_to_inch(to_decimal(package_height), dimension_units)))
			}
		else:
			# convert weight to kg and dimension to cm
			post_data["package_weight"] = {
				"unit": "KILOGRAM",
				"value": to_str(self.convert_weight_to_kg(package_weight, weight_units))
			}
			post_data["package_dimensions"] = {
				"unit": "CENTIMETER",
				"length": to_str(self.convert_dimensions_to_cm(package_length, dimension_units)),
				"width": to_str(self.convert_dimensions_to_cm(package_width, dimension_units)),
				"height": to_str(self.convert_dimensions_to_cm(package_height, dimension_units))
			}
		if shipping_template.get("delivery_services_ids"):
			post_data["delivery_option_ids"] = shipping_template.delivery_services_ids
		if self.is_us() and post_data.get("delivery_option_ids"):
			del post_data["delivery_option_ids"]
		warehouse_id = shipping_template.get("warehouse_id")
		if category_template:
			specifics = self.mapping_attributes(category_template.specifics, category_template.product_attributes)
			product_attributes = self.to_product_attributes(specifics)
			post_data["category_id"] = to_str(category_template.category_id)
			brand_id = category_template.get("brand_id")
			if brand_id and brand_id != "0":
				post_data["brand_id"] = brand_id
			post_data["product_attributes"] = product_attributes
			if category_template.product_certifications:
				post_data["certifications"] = self.convert_product_certifications(category_template.product_certifications)
			if category_template.size_chart_id:
				post_data["size_chart"] = {
					"image": {
						"uri": category_template.size_chart_id
					}
				}
			post_data["is_cod_allowed"] = True if category_template.get("is_cod_open") else False
		if not product.variants:
			# Currently, TikTok Shop API supports creating simple products "https://partner.tiktokshop.com/doc/page/277928"
			product_identifier = self.detect_tiktok_product_identifier(product)
			inventory = self.to_variant_inventory(product, warehouse_id)
			post_data["skus"] = [
				{
					"price": {
						"amount": to_str(to_decimal(product.price, 2)),
						"currency": self.get_currency()
					},
					"seller_sku": product.sku[:50],
					"inventory": inventory,
					"identifier_code": product_identifier,
				}
			]
			tiktok_sku_id = product.tiktok_sku_id
			if tiktok_sku_id:
				post_data["skus"][0]["id"] = tiktok_sku_id
		else:
			if not category_template or not category_template.get("category_id"):
				return Response().error(msg = "Category template is required to publish products on TikTok Shop. Please add a category template.")
			post_data["skus"] = self.variant_to_tiktok_data(product, is_pull_from_tiktok, warehouse_id, insert)
		return Response().success(post_data)

	def detect_chinese_characters(self, text):
		import re
		chinese_characters = re.findall(r'[\u4e00-\u9fff]+', text)
		if chinese_characters:
			return True
		return False

	def variant_to_tiktok_data(self, product, is_pull_from_tiktok, warehouse_id, insert):
		skus = list()
		channel_data = product.channel.get(f'channel_{self.get_channel_id()}', {})
		variation_options = self.variants_to_option(product.variants)
		len_attributes = to_len(list(variation_options.keys()))
		product_skus = product.product_skus
		product_skus_cutoff = list(map(lambda s: to_str(s[-50:]), product_skus))
		sku_uniques = set()
		sku_duplicates = []
		for x in product_skus_cutoff:
			if x in sku_uniques:
				sku_duplicates.append(x)
			else:
				sku_uniques.add(x)
		for index, variant in enumerate(product.variants):
			tiktok_variant_data = dict()
			sales_attributes = list()
			if variant.get("tiktok_attributes"):
				for attribute in variant["tiktok_attributes"]:
					attribute_data = {
						"id": attribute["id"],
						"name": attribute["attribute_name"],
						"value_name": attribute.get("attribute_value_name")
					}
					sales_attributes.append(attribute_data)
			else:
				for attribute in variant.attributes:
					if attribute.use_variant:
						sales_attributes.append({
							"name": attribute.attribute_name,
							"value_name": attribute.attribute_value_name
						})
			try:
				if sales_attributes:
					if len_attributes == 1:
						variant_image = variant.thumb_image.url
						if variant_image:
							tiktok_variant_image = self.upload_image(variant_image, "ATTRIBUTE_IMAGE")
						else:
							tiktok_variant_image = False
						if tiktok_variant_image:
							sales_attributes[0]["sku_img"] = {"uri": tiktok_variant_image[0].get("uri")}
					if len_attributes > 1:
						for sale_attribute in sales_attributes:
							if channel_data.get("tiktok_variant_images"):
								attribute = channel_data['tiktok_variant_images']['attribute']
								option_images = channel_data['tiktok_variant_images']['options']
								for option_image in option_images:
									if sale_attribute.get("attribute_name") == attribute and option_image["name"] == sale_attribute.get("custom_value"):
										tiktok_variant_image = self.upload_image(option_image.image, "ATTRIBUTE_IMAGE")
										if tiktok_variant_image:
											sale_attribute["sku_img"] = {"uri": tiktok_variant_image[0].get("uri")}
			except:
				self.log_traceback()
			variant_sku = variant.sku
			if len(variant_sku) > 50 and variant_sku[-50:] in sku_duplicates:
				variant_sku_gen = random_string(16)
			else:
				variant_sku_gen = variant_sku[-50:]
			tiktok_sku_id = variant.get("tiktok_sku_id")
			if tiktok_sku_id:
				tiktok_variant_data["id"] = tiktok_sku_id
			tiktok_variant_data["seller_sku"] = variant_sku_gen
			tiktok_variant_data["price"] = {
				"amount": to_str(to_decimal(variant.price, 2)),
				"currency": self.get_currency()
			}
			tiktok_variant_data["inventory"] = self.to_variant_inventory(variant, warehouse_id)
			tiktok_variant_data["identifier_code"] = self.detect_tiktok_product_identifier(variant)
			tiktok_variant_data["sales_attributes"] = sales_attributes
			skus.append(tiktok_variant_data)
		return skus

	def channel_assign_category_template(self, product, template_data):
		"""
		func choose mapping and override data from the category template
		"""
		item_specifics = template_data.get('specifics')
		product_attributes = template_data.get("product_attributes")
		if not item_specifics:
			return product
		for index, specific in enumerate(item_specifics):
			status_changed = False
			product_type = product_attributes[index].get("attribute_type")
			if not specific.override and not specific.mapping:
				continue
			if specific.override:
				value = specific.override
			else:
				status_changed = True
				value = specific.mapping
			if status_changed:
				specific.value = self.assign_attribute_to_field(value, product)
				if specific.value:
					specifics_value = specific.value.split(",")
					if len(specifics_value) > 1:
						specifics_value = [{"value_id": "", "value_name": value} for value in specifics_value]
						specific.value = specifics_value
			else:
				if product_type == 2:
					value = self.assign_attribute_to_field(value, product)
				specific.value = value
		product.channel[f"channel_{self.get_channel_id()}"]["template_data"]["category"]["specifics"] = item_specifics
		return product

	def channel_assign_shipping_template(self, product, template_data):
		dimensions = template_data.get('dimensions')
		weight_unit = template_data.get('weight_unit')
		dimension_unit = template_data.get('dimension_unit')
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['weight_unit'] = weight_unit
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['dimension_unit'] = dimension_unit
		if not dimensions:
			return product
		for dimension in dimensions:
			if dimension['name'] not in ['length', 'weight', 'width', 'height']:
				continue
			if dimension.get('override'):
				value = dimension['override']
			else:
				value = dimension['mapping']
			if not value:
				dimension['value'] = self.FIELD_EMPTY
				product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = self.FIELD_EMPTY
			else:
				value = self.assign_attribute_to_field(value, product)
				if to_decimal(value):
					dimension['value'] = to_decimal(value)
					product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = to_decimal(value)
				else:
					dimension['value'] = self.FIELD_EMPTY
					product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = self.FIELD_EMPTY

		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['dimensions'] = dimensions
		return product

	def convert_specific_value(self, value):
		from ast import literal_eval
		try:
			value = literal_eval(value)
			return value
		except:
			self.log_traceback()
			return value

	def detect_tiktok_product_identifier(self, product):
		product_identifier = dict()
		for identifier in self.PRODUCT_IDENTIFIER:
			if product.get(identifier):
				product_identifier["code"] = product.get(identifier).strip()
				product_identifier["type"] = identifier.upper()
				break
		return product_identifier

	def mapping_attributes(self, specifics, product_attributes):
		"""
			function mapping product_attributes with specifics
		"""
		return_data = list()
		try:
			for specific in specifics:
				if specific.get("name", "").lower() == "colour":
					specific["name"] = "Color"
			for attribute in product_attributes:
				if attribute.get("attribute_name", "").lower() == "colour":
					attribute["attribute_name"] = "Color"
			for specific in specifics:
				for attribute in product_attributes:
					if specific["name"] == attribute["attribute_name"]:
						return_data.append({**specific, **attribute})
			return return_data
		except:
			self.log_traceback()
			return return_data

	def to_product_attributes(self, specifics):
		attributes = list()
		for specific in specifics:
			if specific.get("attribute_type") == 2:
				continue
			try:
				specific_values = specific.get("value", [])
				for value in specific_values:
					# only accept value_id is numeric
					if value.get("value_id") and not value.get("value_id", "").isnumeric():
						del value["value_id"]
			except:
				self.log_traceback()
			if specific.get("value"):
				values = list()
				for value in specific["value"]:
					values.append({
						"id": value.get("value_id"),
						"name": value.get("value_name")
					})
				attributes.append({
					"id": specific["attribute_id"],
					"name": specific["attribute_name"],
					"values": values
				})
		return attributes

	def after_product_import(self, product_id, convert: Product, product, products_ext):
		product_id = to_str(product_id)
		product_api = self.get_product_by_id(product_id)
		product_data = product_api.data
		variants = product_data.skus
		product_status = product_data.get("status")
		self._tiktok_product_status = product_status
		if product.variants:
			for index, variant in enumerate(variants):
				self._extend_product_map["tiktok_sku_id"] = variant.id
				child = product.variants[index]
				self.insert_map_product(child, child["_id"], variant.id)
		else:
			self._extend_product_map["tiktok_sku_id"] = variants[0].id
		return Response().success()

	def extend_data_insert_map_product(self):
		extend = super().extend_data_insert_map_product()
		region = self.get_seller_base_region()
		extend["region"] = region
		tiktok_status = self._tiktok_product_status
		if not tiktok_status:
			extend["tiktok_status"] = "pending"
		if tiktok_status and tiktok_status != self.TIKTOK_PRODUCT_STATUS.get("ACTIVATE"):
			extend["tiktok_status"] = self.convert_tiktok_status(self._tiktok_product_status)
		return extend

	def product_channel_update(self, product_id, product: Product, products_ext):
		# self.channel_sync_inventory(product_id, product, products_ext)
		# self.channel_sync_title(product_id, product, products_ext)
		# return Response().success()
		convert_product = self.product_to_tiktok_data(product, products_ext, insert = False)
		if convert_product.result.lower() != Response().SUCCESS:
			return convert_product
		product_data = convert_product.data
		payload = product_data
		update = self.product_api(f"products/{product_id}", body = payload, method = "put")
		update_response = self.check_response_import(update, product, "product")
		if update_response["result"].lower() != Response().SUCCESS:
			return update_response
		return Response().success()

	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		tiktok_product = self.get_product_by_id(product_id)
		if tiktok_product.result != Response().SUCCESS:
			return Response().error(msg = "Error get product while sync")
		product_tiktok_data = tiktok_product.data
		# Only sync product active
		if product_tiktok_data.get("status") != self.TIKTOK_PRODUCT_STATUS["ACTIVATE"]:
			return Response().success()
		tiktok_variants = {row["id"]: row for row in product_tiktok_data.skus}
		shipping_template = product.template_data.get("shipping")
		warehouse_id = shipping_template.get("warehouse_id")
		if not product.variants:
			default_tiktok_variant = product_tiktok_data.skus[0]
			if setting_qty:
				update_qty = self.set_inventory_qty(product, product_id, default_tiktok_variant.id, warehouse_id)
				if update_qty and update_qty["message"].lower() != Response().SUCCESS:
					return Response().error(msg = update_qty["message"])
			if setting_price:
				update_price = self.set_inventory_price(product_id, default_tiktok_variant.id, product.price)
				if update_price and update_price["message"].lower() != Response().SUCCESS:
					return Response().error(msg = update_price["message"])
		else:
			channel_id = self._state.channel.id
			for variant in product.variants:
				variant_id = variant["channel"].get(f"channel_{channel_id}", {}).get("product_id")
				if not variant_id:
					continue
				if setting_qty and tiktok_variants.get(variant_id):
					update_qty = self.set_inventory_qty(variant, product_id, tiktok_variants[variant_id].id, warehouse_id)
					if update_qty and update_qty["message"].lower() != Response().SUCCESS:
						return Response().error(msg = update_qty["message"])
				if setting_price and tiktok_variants.get(variant_id):
					update_price = self.set_inventory_price(product_id, tiktok_variants[variant_id].id, variant.price)
					if update_price and update_price["message"].lower() != Response().SUCCESS:
						return Response().error(msg = update_price["message"])
		return Response().success()

	def convert_sync_description(self, description):
		soup = BeautifulSoup(description, 'html.parser')
		# Wrap all text with p tags
		for text in soup.find_all(text = True):
			if text.parent.name not in ['p', 'strong', 'li', 'ul', 'i', 'em']:
				new_paragraph = soup.new_tag('p')
				text.wrap(new_paragraph)
		for tag in soup.find_all(['i', 'strong']):
			if tag.parent.name not in ['p', 'li']:
				new_paragraph = soup.new_tag('p')
				tag.wrap(new_paragraph)
		for tag in soup.find_all(['p', 'li', 'strong']):
			if not tag.get_text(strip = True):
				# If no content, remove the tag
				tag.unwrap()
		description = str(soup).replace('\xa0', '')
		description = self.remove_spaces(description)
		# Check desc only string, not contain tags
		tag_pattern = re.compile(r'<.*?>')
		text_content = re.sub(tag_pattern, '', description)
		if text_content.strip() == description.strip():
			return f"<p>{description}</p>"
		return description

	def remove_spaces(self, html_string):
		# Remove leading and trailing spaces around tags
		html_string = re.sub(r">\s+<", '><', html_string)
		# Remove spaces between tags and text content
		html_string = re.sub(r"\s+(?=<)|(?<=>)\s+", '', html_string)
		return html_string

	def channel_sync_title(self, product_id, product, products_ext):
		title = product.name[:255]
		description = product.description or product.short_description or title
		clean_description = self.handle_description(description)
		sync_description = self.convert_sync_description(clean_description)
		post_data = dict()
		if self.is_setting_sync_title():
			post_data["title"] = to_str(title)
			product["name"] = to_str(title)
		if self.is_setting_sync_description():
			post_data['description'] = sync_description
			product["description"] = sync_description
		if post_data:
			update_res = self.product_api(f"products/{product_id}/partial_edit", body = post_data, method = 'post')
			log_data = {
				"response": update_res,
				"payload": post_data
			}
			self.log_response(log_data, "sync_title")
			if update_res and update_res.get("message").lower() != Response().SUCCESS:
				return Response().error(msg = update_res.get("message"))
		return Response().success(product)

	def get_total_number_orders(self, filter_condition = None):
		if self._total_number_orders:
			return self._total_number_orders
		params = {
			"page_size": 10
		}
		body = None
		if filter_condition:
			body = {**filter_condition}
		orders_api = self.order_api("orders/search", params = params, body = body, method = "post")
		if orders_api and orders_api["message"].lower() == Response().SUCCESS:
			self._total_number_orders = orders_api["data"]["total_count"]
		else:
			return Response().error(msg = "Could not get orders from tiktok")
		return self._total_number_orders

	@staticmethod
	def get_tiktok_leaf_cate(cate_list):
		# Category must be leafing
		for cate in cate_list:
			if cate["is_leaf"]:
				return {"id": cate["id"], "name": cate["local_name"]}

	@staticmethod
	def convert_product_attributes(product_attributes):
		if product_attributes:
			for attribute in product_attributes:
				values = attribute.get("values", [])
				for value in values:
					if not ("id" and "name") in value.keys():
						continue
					else:
						value["value_id"] = value["id"]
						value["value_name"] = value["name"]
						try:
							del value["id"]
							del value["name"]
						except:
							continue
				if "values" not in attribute.keys():
					continue
				attribute["option_values"] = attribute["values"]
				try:
					del attribute["values"]
				except:
					continue
			return product_attributes
		return []

	@staticmethod
	def product_has_variants(skus):
		has_variants = True
		if len(skus) > 1:
			return has_variants
		default_variant = skus[0]
		if not default_variant["sales_attributes"]:
			has_variants = False
		return has_variants

	@staticmethod
	def convert_weight_to_kg(weight, unit):
		weight = to_decimal(weight)
		weight_unit_to_kg = {
			"lb": 0.45359237,
			"lbs": 0.45359237,
			"g": 0.001,
			"oz": 0.02834952
		}
		if unit.lower() in ["", "kg", "kgs"]:
			result = weight
		else:
			result = weight * to_decimal(weight_unit_to_kg[unit.lower()])
		return to_str(to_decimal(result, 2))

	@staticmethod
	def convert_dimensions_to_cm(dimension, unit):
		dimension = to_decimal(dimension)
		if unit.lower() in ["inch", "in", "inches"]:
			result = dimension * 2.54
		elif unit.lower() == "m":
			result = dimension * 100
		elif unit.lower() == "mm":
			result = dimension * 0.1
		else:
			result = dimension
		return math.ceil(result)

	def upload_image(self, images, use_case = "MAIN_IMAGE", retry = 0):
		"""
		MAIN_IMAGE: Aspect ratios exceeding 3:4-4:3 will be cropped to fit within the range of 3:4-4:3.
		ATTRIBUTE_IMAGE:Aspect ratios exceeding 3:4-4:3 will be cropped to fit within the range of 3:4-4:3.
		DESCRIPTION_IMAGE：Keep the original image returned after uploading.
		CERTIFICATION_IMAGE：Keep the original image returned after uploading.
		SIZE_CHART_IMAGE：Keep the original image returned after uploading.
		"""
		return_data = list()
		if not isinstance(images, list):
			images = [images]
		for image in images:
			binary_image = self.resize(image)
			post_data = {
				"use_case": use_case,
			}
			files = [
				("data", binary_image)
			]
			if retry:
				time.sleep(1)
			img_api = self.product_api("images/upload", body = post_data, files = files, method = "post")
			if img_api and img_api["message"].lower() == Response().SUCCESS:
				img_data = img_api.data
				return_data.append({"uri": img_data.uri, "url": img_data.url, "width": img_data.width, "height": img_data.height, "origin": image})
		if not return_data and retry <= 3:
			return self.upload_image(images, use_case, retry + 1)
		return return_data

	def upload_file(self, file):
		return Response().success()

	def image_to_binary(self, image_url):
		try:
			response = requests.get(image_url)
			binary_data = response.content
			return binary_data
		except:
			self.log_traceback()
			return image_url


	def convert_image_file_to_binary(self, image, is_png = False):
		def is_image_large(img_bin_raw):
			MAXIMUM_IMAGE_SIZE = 5_000_000
			return len(img_bin_raw) > MAXIMUM_IMAGE_SIZE

		buffered = BytesIO()
		image.save(buffered, format = "JPEG" if not is_png else "PNG")
		image_binary = buffered.getvalue()
		if is_image_large(image_binary):
			buffered = BytesIO()
			try:
				if is_png:
					(
						image.convert('P', palette = Image.ADAPTIVE, colors = 256)
						.save(buffered, optimize = True, format = 'PNG')
					)
				else:
					img_quality = 95
					while img_quality > 0:
						buffered = BytesIO()
						image.save(buffered, quality = img_quality, optimize = True, format = "JPEG")
						img_quality -= 10
						if is_image_large(buffered.getvalue()) is False:
							break
			except:
				self.log_traceback()

			image_binary = buffered.getvalue()

		return image_binary

	def convert_ms_timestamp_to_datetime(self, time_data, format = "%Y-%m-%d %H:%M:%S"):
		"""
		Convert unix timestamp for ms to date time
		TikTok shop return some data as ms unix timestamp
		"""
		time_data = to_int(time_data) / 1000
		try:
			timestamp = datetime.fromtimestamp(time_data)
			res = timestamp.strftime(format)
			return res
		except Exception:
			log_traceback()
			return get_current_time(format)

	def extend_images(self, product):
		images = list()
		if product.thumb_image.url:
			main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			images.append(main_image['url'])
		for index, img_src in enumerate(product.images):
			# TikTok only accepts up to 9 images
			if index > 9:
				break
			image_process = self.process_image_before_import(img_src.url, img_src.path)
			if image_process['url'] not in images:
				images.append(image_process['url'])
		return images

	def get_default_warehouse(self):
		if self._default_warehouse_id:
			return self._default_warehouse_id
		warehouses = self.api("/logistics/202309/warehouses")
		if warehouses and warehouses["message"].lower() == Response().SUCCESS:
			warehouse_list = warehouses.data.get("warehouses")
			if not warehouse_list:
				return None
			for warehouse in warehouse_list:
				if warehouse.is_default:
					self._default_warehouse_id = warehouse.id
					return self._default_warehouse_id
		return None

	def get_default_warehouse_id(self):
		return self._state.channel.config.api.default_warehouse_id

	def check_response_import(self, response, convert, entity_type = ""):
		entity_id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and response.get("message").lower() != Response().SUCCESS:
			console = list()
			if isinstance(response, dict) or isinstance(response, Prodict):
				for key, error in response.items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(to_str(key) + ': ' + to_str(error_messages))
			else:
				console.append(response)
			log_msg_errors = ' '.join(console)
			display_msg_errors = response.get("message")
			self.log(entity_type + ' id ' + to_str(entity_id) + ' import failed. Error: ' + log_msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error(msg = display_msg_errors)
		else:
			return Response().success()

	def set_inventory_price(self, product_id, sku_id, price):
		body = {
			"skus": [
				{
					"id": to_str(sku_id),
					"price": {
						"amount": to_str(price),
						"currency": self.get_currency()
					}
				}
			]
		}
		response = self.product_api(f"products/{product_id}/prices/update", body = body, method = "post")
		return response

	def set_inventory_qty(self, product, product_id, sku_id, warehouse_id):
		body = {
			"skus": [
				{
					"id": to_str(sku_id),
					"inventory": self.to_variant_inventory(product, warehouse_id)
				}
			]
		}
		response = self.product_api(f"products/{product_id}/inventory/update", body = body, method = "post")
		return response

	def get_orders_main_export(self):
		if self._is_finish_pull_order:
			return Response().finish()
		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0
		limit_data = self._state.pull.setting.orders
		start_time = self.get_order_start_time()
		last_modifier = self._state.pull.process.orders.max_last_modified
		orders_filter_condition = {
			"create_time_ge": to_timestamp(start_time),
			"sort_order": "DESC"
		}
		params = {
			"page_size": 50
		}
		if last_modifier:
			orders_filter_condition["update_time_ge"] = to_timestamp(last_modifier)
			delay_day = to_int(self.delay_last_modidied())
			if delay_day:
				orders_filter_condition["update_time_ge"] = to_int(to_timestamp(last_modifier)) - (self.ONE_DAY_IN_SECONDS * delay_day)

		if self._next_cursor_order:
			params["page_token"] = self._next_cursor_order
		orders_api = self.order_api("orders/search", body = orders_filter_condition, params = params, method = "post")
		self._next_cursor_order = orders_api.data.next_page_token
		if not self._next_cursor_order or not orders_api.data.next_page_token:
			self._is_finish_pull_order = True
		if not isinstance(orders_api["data"], dict) or not orders_api["data"].get("orders"):
			return Response().error(msg = "Could not get orders from tiktok")
		return Response().success(data = orders_api["data"]["orders"])

	def get_orders_ext_export(self, orders):
		extend = Prodict()
		ids_list = ""
		for order in orders:
			ids_list += order.id + ","
		ids_list = ids_list.rstrip(",")
		params = {"ids": ids_list}
		orders_detail = self.order_api("orders", params = params, method = "get")
		if orders_detail and orders_detail["message"].lower() == Response().SUCCESS:
			order_detail_list = orders_detail["data"]["orders"]
			for order_detail in order_detail_list:
				order_id = order_detail.id
				extend.set_attribute(to_str(order_id), Prodict())
				extend[to_str(order_id)] = order_detail
			return Response().success(extend)
		return Response().error("Could not get order detail")

	def get_order_by_id(self, order_id):
		body = {
			"ids": order_id
		}
		order_response = self.order_api("orders", params = body, method = "get")
		if order_response and order_response["message"].lower() == Response().SUCCESS:
			return Response().success(order_response["data"]["orders"][0])
		return Response().error(msg = "Get order from tiktok failed")

	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id

	def get_state_code_from_name(self, name):
		if name:
			for code, state_name in self.STATES.items():
				if to_str(name).lower() == to_str(state_name).lower():
					return code
		return name

	def _convert_format_time(self, epoch_seconds):
		return convert_format_time(time_data = to_int(epoch_seconds) - 25200, old_format = 'timestamp')

	def combine_order_items(self, order_line_list):
		combined_order_items = Prodict()
		for item in order_line_list:
			sku_id = item["sku_id"]
			if sku_id in combined_order_items:
				combined_order_items[sku_id]["quantity"] += 1
			else:
				combined_order_items[sku_id] = item
				combined_order_items[sku_id]["quantity"] = 1

		return list(combined_order_items.values())

	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_data = Order()
		order_id = order.id
		order_detail = orders_ext.get(order_id, {})
		# Skip unpaid, on_hold order because the order does not have an address.
		if order_detail.status in ["UNPAID", "ON_HOLD"]:
			return Response().skip()
		update_time = self._convert_format_time(order.update_time)
		self.set_order_max_last_modifier(convert_format_time(order.update_time))
		order_data.id = order_id
		order_data.order_number = order_id
		order_data.status = self.ORDER_STATUS.get(to_str(order.status))
		order_data.tax.amount = order_detail.payment.tax
		order_data.shipping.title = order_detail.shipping_type
		order_data.shipping.amount = to_decimal(order_detail.payment.shipping_fee)
		order_data.total = to_decimal(order_detail.payment.total_amount)
		order_data.currency = order_detail.payment.currency
		order_data.created_at = self._convert_format_time(order_detail.create_time)
		order_data.updated_at = update_time
		order_data.discount.amount = to_decimal(order_detail.payment.get("seller_discount")) + to_decimal(order_detail.payment.get("platform_discount"))
		order_data.channel_data = {
			"order_status": self.ORDER_STATUS.get(to_str(order.status)),
			"created_at": order_data.created_at,
			"order_id": order_id
		}
		# Customer
		order_ship = order_detail.recipient_address
		first_name, last_name = self.split_customer_fullname(order_ship.name)
		order_data.customer.first_name = first_name
		order_data.customer.last_name = last_name
		order_data.customer.email = order_detail.buyer_email
		order_data.customer.telephone = order_ship.phone_number
		order_data.customer.username = order_ship.name
		if not order_data.customer.username:
			self.log_response(order_detail, "order_without_buyer_info")
		# Customer, billing, shipping address
		address = OrderAddress()
		district_info_list = order_ship.get("district_info")
		state = ""
		county = ""
		district = ""
		city = ""
		for item in district_info_list:
			address_level = item.address_level_name.lower()
			if address_level == "state":
				state = item.address_name
			if address_level == "county":
				county = item.address_name
			if address_level == "city":
				city = item.address_name
			if address_level == "district":
				district = item.address_name

		# address_line_list = order_ship.address_line_list
		address_1 = order_ship.address_line1
		address_2 = order_ship.address_line2 + "\n" + order_ship.address_line3 + "\n" + order_ship.address_line4
		address.telephone = order_ship.phone_number
		address.address_1 = address_1
		address.address_2 = address_2
		address.last_name = last_name
		address.first_name = first_name
		address.city = city
		if self.is_uk():
			address.city = city or district or county
		address.postcode = order_ship.postal_code
		address.country.country_name = order_ship.region_code
		address.country.country_code = order_ship.region_code
		if state:
			address.state.state_code = self.get_state_code_from_name(state)
		else:
			address.state.state_code = self.get_state_code_from_name(county)
		address.state.state_name = state
		order_data.shipping_address.update(address)
		order_data.billing_address.update(address)
		order_data.customer_address.update(address)
		# Order product
		order_item_list = order_detail.line_items
		order_combine_item = self.combine_order_items(order_item_list)
		subtotal_order = 0
		if order_item_list:
			for item in order_combine_item:
				product_detail = self.get_product_by_id(item.product_id)
				has_variants = self.product_has_variants(product_detail.data.skus)
				if item.is_gift:
					order_history = OrderHistory()
					gift_msg_note = f"""
						Order includes gift product: {item.product_name} - SKU: {item.seller_sku}					
					"""
					order_history.comment = gift_msg_note
					order_history.staff_note = True
					order_data.history.append(order_history)
					if to_len(order_item_list) > 1:
						continue
				order_item = OrderProducts()
				if not has_variants:
					default_sku = product_detail.data.skus[0]
					order_item.product_id = item.product_id
					order_item.product_sku = default_sku.seller_sku
				else:
					order_item.product_id = item.sku_id
					options = list()
					for variant in product_detail.data.skus:
						if variant.id == item.sku_id:
							for attribute in variant.sales_attributes:
								options.append({
									"id": attribute.id,
									"name": attribute.name,
									"value": attribute.value_name
								})
					for option in options:
						option_data = OrderItemOption()
						option_data.option_id = option.get("id")
						option_data.option_name = option.get("name")
						option_data.option_value_name = option.get("value")
						order_item.options.append(option_data)
				order_item.product_name = item.product_name
				order_item.listing_id = item.product_id
				order_item.product_sku = item.seller_sku
				order_item.qty = item.quantity
				order_item.price = item.original_price
				order_item.discount_amount = to_decimal(item.platform_discount) + to_decimal(item.seller_discount)
				order_item.subtotal = to_decimal(item.original_price) * to_int(order_item.qty)
				order_item.total = to_decimal(item.original_price) * to_int(order_item.qty)
				order_data.products.append(order_item)
				subtotal_order += to_decimal(item.original_price) * to_int(order_item.qty)
		order_data.subtotal = subtotal_order
		# Shipment
		order_shipment = Shipment()
		order_shipment.tracking_number = order_detail.tracking_number
		order_shipment.tracking_company = order_detail.shipping_provider
		order_data.shipments = order_shipment
		# History
		order_history = OrderHistory()
		if order_detail.buyer_message:
			order_history.comment = order_detail.buyer_message
			if self._state.channel.config.api.buyer_message_to_staff_note:
				order_history.staff_note = True
			order_data.history.append(order_history)
		if order_detail.seller_note:
			order_history.comment = order_detail.seller_note
			order_history.staff_note = True
			order_data.history.append(order_history)
		self.log(msg = order_detail, log_type = "convert_order_export")
		return Response().success(order_data)

	def order_sync_inventory(self, order: Order, setting_order):
		return Response().success()

	def get_reverse_reason(self, reverse_action_type = 1, order_status = 100):
		"""
		Available value:
		CANCEL = 1;
		REFUND = 2;
		RETURN_AND_REFUND = 3;
		REQUEST_CANCEL_REFUND = 4;
		"""
		params = {"reverse_action_type": reverse_action_type}
		reasons_api = self.api("reverse/reverse_reason/list", params = params)
		reasons = reasons_api["data"]["reverse_reason_list"]
		result = list()
		for reason in reasons:
			if reason.get("available_order_status_list") and order_status in reason.get("available_order_status_list"):
				result.append(reason)
		return result

	def set_cancel_reason(self):
		reason = "seller_cancel_reason_wrong_price"
		seller_base_region = self.get_seller_base_region()
		if seller_base_region.lower() == "gb":
			reason += "_uk"
		return reason

	# def channel_order_canceled(self, order_id, order: Order, current_order):
	# 	body = {
	# 		"order_id": to_str(order_id),
	# 		"cancel_reason_key": self.set_cancel_reason()
	# 	}
	# 	order_canceled = self.api("reverse/order/cancel", body = body, method = "post")
	# 	if order_canceled and order_canceled["message"].lower() == Response().SUCCESS:
	# 		return Response().success()
	# 	return Response().error(msg = "Cancel order failed")

	def map_tracking_company(self, mapping_company, tiktok_shipping_provider):
		for provider, provider_id in tiktok_shipping_provider.items():
			if self.name_to_code(provider) == self.name_to_code(mapping_company):
				return provider_id
		return ""

	def is_carrier_mapping(self) -> bool:
		other_settings = self._state.channel.config.setting.get('other_setting')
		if isinstance(other_settings, dict) and isinstance(other_settings.get('carrier_mapping'), dict):
			return bool(other_settings.carrier_mapping.get('status') == 'enable')

		return False

	def get_company_mapping(self) -> list:
		if self.is_carrier_mapping():
			carrier_mapping = self._state.channel.config.setting.other_setting.carrier_mapping.get('company_mapping')
			if not isinstance(carrier_mapping, list):
				carrier_mapping = []
			return carrier_mapping

		return []

	def get_shipping_provider_from_company(self, tracking_company, tracking_company_code):
		if not tracking_company or not tracking_company_code:
			return ""
		if self.is_us():
			tiktok_shipping_provider = self.MAPPING_CARRIER_US
		else:
			tiktok_shipping_provider = self.MAPPING_CARRIER_UK
		enable_carrier_mapping = self.is_carrier_mapping()
		if enable_carrier_mapping:
			company_mapping = self.get_company_mapping()
			for carrier in company_mapping:
				if self.name_to_code(carrier["main_company"]) in [self.name_to_code(tracking_company), self.name_to_code(tracking_company_code)]:
					return self.map_tracking_company(carrier["channel_company"], tiktok_shipping_provider)
		if "usps" in tracking_company.lower():
			tracking_company = "USPS"
		if "ups" in tracking_company.lower():
			tracking_company = "UPS"
		for provider, provider_id in tiktok_shipping_provider.items():
			if tracking_company.strip().lower() == provider.strip().lower():
				return provider_id
		return ""

	def channel_order_completed(self, order_id, order: Order, current_order):
		try:
			tiktok_order = self.get_order_by_id(order_id)
			tracking_number = order.shipments.get("tracking_number")
			tracking_company = to_str(order.shipments.get("tracking_company"))
			tracking_company_code = to_str(order.shipments.get("tracking_company_code"))
			self.log_response(tiktok_order, "tiktok_order_ff")
			self.log_response(order, "order_ff")

			if tiktok_order.result == Response().SUCCESS:
				tiktok_order_data = tiktok_order.get("data")
				tiktok_order_status = tiktok_order_data.get('status')
				if to_str(tiktok_order_status) == "COMPLETED":
					return Response().success({'status': Order.COMPLETED})

				# Only submit tracking number with option SHIP_BY_SELLER and status is AWAITING_SHIPMENT
				if tiktok_order_data.get("shipping_type") == self.SHIP_BY_SELLER and tiktok_order_status == "AWAITING_SHIPMENT":
					body = dict()
					shipping_provider_id = self.get_shipping_provider_from_company(tracking_company, tracking_company_code)
					if not shipping_provider_id:
						self.log_response(tracking_company, "not_support_shipping_provider")
						return Response().error(msg = "Your shipping carrier is not supported by TikTok Shop")
					body["tracking_number"] = tracking_number
					body["shipping_provider_id"] = shipping_provider_id
					mark_package_as_shipped = self.api(f"/fulfillment/202309/orders/{order_id}/packages", body = body, method = "post")
					self.log_response({"body": body, "res": mark_package_as_shipped}, "tiktok_fulfill_response")
					if mark_package_as_shipped and mark_package_as_shipped["message"].lower() == Response().SUCCESS:
						return Response().success({'status': Order.SHIPPING})
		except:
			self.log_traceback()
			return Response().error()

	def channel_order_is_completed(self, order_id):
		try:
			order_res = self.get_order_by_id(order_id)
			if order_res.result == Response.SUCCESS:
				tiktok_order = order_res.data
				if tiktok_order and not tiktok_order.get('shipping_provider_id'):
					return False
		except:
			self.log_traceback()
			return True
		return True
