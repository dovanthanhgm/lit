import copy
import io
import time
from urllib.request import Request, urlopen

import pytz
import requests
from PIL import Image
from PIL import ImageFile

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.tracking_company import TrackingCompany
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory, OrderAddress, OrderAddressCountry, Shipment, OrderShipmentItem
from datasync.models.constructs.product import Product, ProductImage, ProductAttribute, ProductVariant, \
	ProductVariantAttribute, ProductVideo, ProductLocation
import dateutil.relativedelta

class ModelChannelsShopify(ModelChannel):
	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	CUSTOM_COLLECTION = 'custom'
	SMART_COLLECTION = 'smart'
	ORDER_STATUS = {
		"pending": Order.OPEN,
		"partially_refunded": Order.OPEN,
		"authorized": Order.AWAITING_PAYMENT,
		"partially_paid": Order.SHIPPING,
		"paid": Order.COMPLETED,
		"voided": Order.CANCELED,
		"refunded": Order.REFUNDED,
	}
	FINANCIAL_ORDER_STATUS = {
		Order.OPEN: "pending",
		Order.AWAITING_PAYMENT: "authorized",
		Order.READY_TO_SHIP: "paid",
		Order.SHIPPING: "paid",
		Order.COMPLETED: "paid",
		Order.CANCELED: "refunded",
		Order.REFUNDED: "refunded",
	}
	FULFILLMENT_STATUS = {
		# Order.SHIPPING: "fulfilled",
		Order.COMPLETED: "fulfilled",
		Order.CANCELED: "restocked",
	}
	CONDITION = {
		'new': Product.CONDITION_NEW,
		'used': Product.CONDITION_USED,
		'reconditioned': Product.CONDITION_RECONDITIONED,
	}
	_metafields_definitions: None or dict
	KEY_REFRESH_ALL = 'refreshed_all_3'
	IMAGE_LIMIT = 30
	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = None
		self._last_status = None
		self._collection_type = None
		self._shopify_countries = None
		self._location_id = None
		self._last_product_response = None
		self._last_images = None
		self._flag_finish_product = False
		self._flag_finish_order = False
		self._product_next_link = False
		self._order_next_link = False
		self._order_max_last_modified = False
		self._metafields_definitions = False
		self._sale_channel_id = None
		self._file_log = None


	def get_api_info(self):
		return {
			'password': "API Password",
			# 'app_secret': 'Shared Secret'
		}


	def set_last_product_response(self, response, images):
		self._last_product_response = response
		self._last_images = images


	def get_last_product_response(self):
		return self._last_product_response, self._last_images


	# api code
	def get_api_path(self, path, add_version = True, api_version = None):
		path = to_str(path).replace('admin/', '')
		prefix = 'admin'
		if add_version:
			prefix += '/api/' + self.get_version_api(api_version)
		path = prefix + '/' + path
		return path


	def get_default_version_api(self):
		year = get_current_time("%Y")
		month = to_int(get_current_time("%m")) - 1
		quarter = (to_int(month) - 1) // 3 + 1
		quarter = 1 if quarter < 1 else quarter
		version_api = (to_int(quarter) - 1) * 3 + 1
		if version_api < 10:
			version_api = "0" + to_str(version_api)
		else:
			version_api = to_str(version_api)

		return to_str(year) + "-" + version_api


	def get_version_api(self, api_version = None):
		if api_version:
			return api_version
		if self._version_api:
			return self._version_api
		version_api = get_config_ini('shopify', 'version_api', self.get_default_version_api())
		self._version_api = version_api
		return self._version_api
		year = get_current_time("%Y")
		month = get_current_time("%m")
		quarter = (to_int(month) - 1) // 3
		version_api = (to_int(quarter) - 1) * 3 + 1
		if version_api < 10:
			version_api = "0" + to_str(version_api)
		else:
			version_api = to_str(version_api)

		self._version_api = to_str(year) + "-" + version_api
		return self._version_api


	def api(self, path, data = None, api_type = "get", add_version = True, api_version = None):
		path = self.get_api_path(path, add_version, api_version)
		header = {"Content-Type": "application/json"}
		url = self.get_api_url() + '/' + to_str(path).strip('/')
		res = self.requests(url, data, method = api_type)
		retry = 0
		while (res is False) or ('expected Array to be a Hash' in to_str(res)) or (
				"Exceeded 2 calls per second for api client. Reduce request rates to resume uninterrupted service" in to_str(
			res)) or self._last_status >= 500:
			retry += 1
			time.sleep(10)
			res = self.requests(url, data, method = api_type)
			if retry > 5:
				break
		return res


	def get_api_url(self):
		if not self._api_url:
			self._api_url = self.create_api_url()
		return self._api_url


	def create_api_url(self):
		api_url = "https://{}.myshopify.com".format(self._state.channel.config.api.shop)
		return api_url


	def requests(self, url, data = None, headers = None, method = 'get'):
		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		headers['X-Shopify-Access-Token'] = self._state.channel.config.api.password
		headers['Content-Type'] = 'application/json'

		response = False
		request_options = {
			'headers': headers,
			'verify': True,
			'timeout': 120
		}
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code
			response_data = json_decode(response.text)
			if response_data:
				try:
					response_prodict = Prodict(**response_data)
				except Exception:
					response_prodict = response_data
				response_data = response_prodict
			if response.headers.get('x-shopify-shop-api-call-limit'):
				res_called_data = response.headers.get('x-shopify-shop-api-call-limit')
				res_called_arr = res_called_data.split('/')
				request_remain = to_int(res_called_arr[1]) - to_int(res_called_arr[0])
				if request_remain < 5:
					time.sleep(1)
			else:
				time.sleep(1)


			def log_request_error(_log_type = 'request'):
				if not _log_type:
					_log_type = 'request'
				error = {
					'method': method,
					'status': response.status_code,
					'data': to_str(data),
					'header': to_str(response.headers),
					'response': response.text,
				}
				self.log_request_error(url, log_type = _log_type ,**error)


			if response.status_code == 403:
				if response_data.errors and 'This action requires merchant approval for ' in to_str(
						response_data.errors):
					log_request_error()
					# self.log('Daily variant creation limit reached, delay 1day', 'delay')
					scope = re.findall(r"This action requires merchant approval for ([a-z_]+) scope",
					                   to_str(response_data.errors))
					msg_scope = ''
					if scope:
						msg_scope = scope[0]
					self.notify(Errors.SHOPIFY_SCOPE)
					return response_data

			if response.status_code == 429:
				if response_data.errors and 'Daily variant creation limit reached. Please try again later' in to_str(
						response_data.errors):
					log_request_error()
					self.notify(Errors.SHOPIFY_VARIANT_LIMIT)
					time.sleep(24 * 60 * 60)
					return self.requests(url, data, headers, method)
			if response.status_code > 201 or self.is_log():
				# try:
				# 	path = url.split(f'api/{self.get_version_api()}')[-1]
				# 	path = path.strip('/')
				# 	file_log = path.split('/')[0]
				# 	log_request_error(file_log)
				#
				# except:
				log_request_error(self._file_log)

		except Exception as e:
			self.log_traceback()
		return response_data


	def display_setup_channel(self, data = None):
		# order = self.get_product_by_id(8838886097208)
		# order_ext = self.get_products_ext_export([order['data']])
		# convert = self.convert_product_export(order['data'], order_ext['data'])
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		url = self._channel_url
		if not self._state.channel.config.api.shop:
			shopify_code = re.findall("https://(.*).myshopify.com", url)
			self._state.channel.config.api.shop = shopify_code[0]
		shop = self.api('shop.json')
		if not shop:
			return Response().error(Errors.SHOPIFY_API_INVALID)
		try:
			if shop.errors:
				return Response().error(Errors.SHOPIFY_API_INVALID)

		except Exception as e:
			return Response().error(Errors.SHOPIFY_API_INVALID)
		try:
			if not self.get_channel_id():
				check_url = requests.get(self._channel_url, allow_redirects = False)
				if check_url.status_code in [301, 302]:
					new_url = check_url.headers.get('location').strip('/')
					if new_url and new_url != check_url and new_url.split('/')[-1] != 'password':
						self._channel_url = new_url
						self._state.channel.url = new_url
		except:
			self.log_traceback()
		# access_scopes = self.get_access_scopes()
		# fail_scope = list()
		# if access_scopes:
		# 	list_scope = 'read_products,write_products,write_inventory,read_locations'
		# 	for scope in list_scope.split(','):
		# 		if scope not in access_scopes:
		# 			fail_scope.append(scope)
		#
		# if fail_scope:
		# 	self.log(','.join(fail_scope), 'scope')
		# 	return Response().error(Errors.SHOPIFY_SCOPE_INVALID)

		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()


	def get_access_scopes(self):
		scope = self.requests(f'{self.get_channel_url()}/admin/oauth/access_scopes.json')
		if not scope or not scope.get('access_scopes'):
			return list()
		list_access_scopes = list()
		for access_scopes in scope['access_scopes']:
			list_access_scopes.append(access_scopes['handle'])
		return list_access_scopes


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self._state.channel.config.api.shop)
		return Response().success()


	def after_create_channel(self, data):
		if is_local():
			return Response().success()
		token = 'ay8PRsxHHHzQL9TG'
		address = get_api_server_url(f'merchant/shopify/webhook/{data.channel_id}/app/uninstalled')
		if not self._state.channel.config.api.app_id:
			address += f"?password={token}"
		webhook_data = {
			"webhook": {
				"topic": "app/uninstalled",
				"address": address,
				"format": "json"
			}
		}
		webhook = self.api('webhooks.json', webhook_data, 'post')
		return Response().success()
		entities = ['order']
		webhook_token_data = {
			'channel_id': data.channel_id,
			'channel_type': 'shopify'
		}
		token = 'ay8PRsxHHHzQL9TG'
		events = dict()
		if self.is_channel_default():
			# events[f"products/update"] = f'product/update'
			events[f"orders/updated"] = f'order/update'
		events["products/delete"] = 'product/delete'
		for event, url in events.items():
			address = get_server_callback(f'merchant/shopify/webhook/{data.channel_id}/{url}')
			if not self._state.channel.config.api.app_id:
				address += f"?password={token}"
			webhook_data = {
				"webhook": {
					"topic": event,
					"address": address,
					"format": "json"
				}
			}
			webhook = self.api('webhooks.json', webhook_data, 'post')
		return Response().success()


	def get_max_last_modified_product(self):
		if self._state.pull.process.products.last_modified:
			if to_str(self._state.pull.process.products.last_modified).isnumeric():
				return convert_format_time(self._state.pull.process.products.last_modified, new_format = "%Y-%m-%dT%H:%M:%S+07:00")
			return self._state.pull.process.products.last_modified
		return False


	def create_webhook_product(self):
		pass


	def is_refresh_all(self):
		return self._state.channel.config.get(self.KEY_REFRESH_ALL)


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			params = {}
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.total = 0
			if self._request_data.get('include_filters') and self._request_data['include_filters'].get('ids'):
				self._state.pull.process.products.total = to_len(self._request_data['include_filters']['ids'].split(','))
			else:
				if self.is_refresh_process():
					self._state.pull.process.products.id_src = 0
					params['since_id'] = 0
					last_modified = self.get_max_last_modified_product()
					if last_modified and self.is_refresh_all():
						params['updated_at_min'] = self.shopify_datetime_to_utc_filter(last_modified)
				else:
					if self._request_data.get('include_filters'):
						for field_filter, value in self._request_data['include_filters'].items():
							if field_filter not in ['product_type', 'collection_id', 'vendor']:
								continue
							params[field_filter] = value
					else:
						if self._request_data.get('include_published'):
							params['status'] = 'active'
						if self._state.pull.process.products.id_src:
							params['since_id'] = self._state.pull.process.products.id_src
						else:
							params['since_id'] = 0

				products_api = self.api('products/count.json', data = params)

				if products_api and products_api.count:
					if self.is_refresh_process():
						self._state.pull.process.products.total = -1
					else:
						self._state.pull.process.products.total = products_api.count

		if self.is_order_process():
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			start_time = self.get_order_start_time('iso')
			last_modifier = self._state.pull.process.orders.max_last_modified
			params = {
				"created_at_min": start_time,
				"status": 'any'
			}
			if last_modifier:
				params['updated_at_min'] = self.shopify_datetime_to_utc_filter(last_modifier)
				self.set_order_max_last_modifier(last_modifier)
			orders_api = self.api('orders/count.json', data = params)
			if orders_api and orders_api.count:
				self._state.pull.process.orders.total = orders_api.count
		if self.is_category_process():
			self._state.pull.process.categories.total = 0
			self._state.pull.process.categories.imported = 0
			# self._state.pull.process.categories.new_entity = 0
			self._state.pull.process.categories.error = 0
			self._state.pull.process.categories.id_src = 0
			self._state.pull.process.categories.id_src_smart = 0
			custom_collections_api = self.api('custom_collections/count.json')
			smart_collection_api = self.api('smart_collections/count.json')
			if custom_collections_api and custom_collections_api.count:
				self._state.pull.process.categories.total += custom_collections_api.count
			if smart_collection_api and smart_collection_api.count:
				self._state.pull.process.categories.total += smart_collection_api.count
		return Response().success()


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S") > to_timestamp(self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
			self._order_max_last_modified = last_modifier


	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		try:
			all_collections = self.api('custom_collections.json?limit=100')
			while all_collections:
				if not all_collections.custom_collections:
					break
				for collect in all_collections.custom_collections:
					id_collect = collect.id
					res = self.api('custom_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('custom_collections.json?limit=100')
				time.sleep(0.1)
			all_collections = self.api('smart_collections.json?limit=100')

			while all_collections:
				if not all_collections:
					return next_clear
				if not all_collections.smart_collections:
					return next_clear
				for collect in all_collections.smart_collections:
					id_collect = collect.id
					res = self.api('smart_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('smart_collections.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			all_products = self.api('products.json?limit=100')
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.products:
					return next_clear
				for product in all_products.products:
					id_product = product.id
					res = self.api('products/{}.json'.format(id_product), None, 'Delete')
				all_products = self.api('products.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_collection_type(self):
		if self._collection_type:
			return self._collection_type
		self._collection_type = self.CUSTOM_COLLECTION
		return self._collection_type


	def set_collection_type(self, collection_type):
		self._collection_type = collection_type


	def get_categories_main_export(self):
		collection_type = self.get_collection_type()
		limit_data = 100
		categories_data = list()
		if collection_type == self.CUSTOM_COLLECTION:
			id_src = self._state.pull.process.categories.id_src
			collections = self.api('custom_collections.json', data = {'since_id': id_src, 'limit': limit_data})
			if not collections:
				return Response().finish()
			categories_data = collections.get('custom_collections')
			if not categories_data:
				collection_type = self.SMART_COLLECTION
				self.set_collection_type(self.SMART_COLLECTION)
		if collection_type == self.SMART_COLLECTION:
			id_src = self._state.pull.process.categories.id_src_smart
			if not id_src:
				id_src = 0
			collections = self.api('smart_collections.json', data = {'since_id': id_src, 'limit': limit_data})
			if not collections:
				return Response().finish()

			if not collections.get('smart_collections'):
				return Response().finish()
			categories_data = collections['smart_collections']
		return Response().success(categories_data)


	def get_categories_ext_export(self, categories):
		return Response().success()


	def convert_category_export(self, category, categories_ext):
		category_data = CatalogCategory()
		category_data.id = category.id
		category_data.name = category.title
		category_data.collection_type = self.get_collection_type()
		return Response().success(category_data)


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']


	def set_category_id_src(self, id_src):
		if self.get_collection_type() == self.SMART_COLLECTION:
			self._state.pull.process.products.id_src_smart = id_src
		else:
			self._state.pull.process.products.id_src = id_src


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		if not category.name:
			return response_error('import category ' + to_str(category.id) + ' false.')
		post_data = {
			'smart_collection': {
				'title': category.name,
				'body_html': category.description,
				'published_scope': 'web',
				'disjunctive': 'false',
				'sort_order': 'best-selling',
				'rules': []
			}
		}

		# Add Thumbnail image
		if category.thumb_image.url:
			main_image = self.process_image_before_import(category.thumb_image.url, category.thumb_image.path)
			image_data = self.resize_image(main_image['url'])
			if image_data:
				post_data['smart_collection']['image'] = image_data

		# Status
		if not category.active:
			post_data['smart_collection']['published_at'] = None

		# Add rules: the list of rules that define what products go into the smart collections.
		tag_rule = {
			'column': 'tag',
			'relation': 'equals',
			'condition': category.name
		}
		post_data['smart_collection']['rules'].append(tag_rule)

		# Post data
		response = self.api('smart_collections.json', post_data, 'Post')
		check_response = self.check_response_import(response, category, 'category')
		if check_response.result != Response.SUCCESS:
			if 'Image' in check_response.msg:
				del post_data['smart_collection']['image']
				response = self.api('smart_collections.json', post_data, 'Post')
				check_response = self.check_response_import(response, category, 'category')
				if check_response.result != Response.SUCCESS:
					return check_response
			else:
				return check_response

		category_id = response['smart_collection']['id']
		handle = response['smart_collection'].get('handle')
		return Response().success(category_id)


	def get_product_by_id(self, product_id):
		product = self.api(f'products/{product_id}.json')
		if self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		if not product or not product.get('product'):
			return Response().error()
		return Response().success(product['product'])


	def get_product_by_updated_at(self):
		if self._flag_finish_product:
			return Response().finish()
		if self._product_next_link:
			products = self.requests(self._product_next_link)
		else:
			limit_data = self._state.pull.setting.products
			params = {'limit': 100}
			last_modified = self.get_max_last_modified_product()
			if last_modified and self.is_refresh_all():
				params['updated_at_min'] = self.shopify_datetime_to_utc_filter(last_modified)

			products = self.api('products.json', data = params)
		links = self._last_header.get('link')
		next_link = ''
		if links and 'next' in links:
			list_link = links.split(',')
			for link_row in list_link:
				if 'next' in link_row:
					next_link = link_row.split(';')[0]
					next_link = next_link.strip('<> ')
		if not next_link:
			self._flag_finish_product = True
		else:
			self._product_next_link = next_link
		if not products or not products.products:
			if self._last_status != 200:
				return Response().error(Errors.SHOPIFY_GET_PRODUCT_FAIL)
			return Response().finish()
		return Response().success(data = products.products)


	def get_products_main_export(self):
		if self._flag_finish_product:
			return Response().finish()
		if self._product_next_link:
			products = self.requests(self._product_next_link)
		else:
			limit_data = self._state.pull.setting.products
			params = {'limit': 100}
			if self._request_data.get('include_filters'):
				for field_filter, value in self._request_data['include_filters'].items():
					if field_filter not in ['product_type', 'collection_id', 'vendor', 'ids']:
						continue
					params[field_filter] = value
			else:
				if self._request_data.get('include_published'):
					params['status'] = 'active'
				if self._state.pull.process.products.id_src:
					params['since_id'] = self._state.pull.process.products.id_src
			products = self.api('products.json', data = params)
		links = self._last_header.get('link')
		next_link = ''
		if links and 'next' in links:
			list_link = links.split(',')
			for link_row in list_link:
				if 'next' in link_row:
					next_link = link_row.split(';')[0]
					next_link = next_link.strip('<> ')
		if not next_link:
			self._flag_finish_product = True
		else:
			self._product_next_link = next_link
		if not products or not products.products:
			# if self._last_status != 200:
			# 	return Response().error(Errors.SHOPIFY_GET_PRODUCT_FAIL)
			return Response().finish()
		return Response().success(data = products.products)


	def _get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._state.pull.process.products.id_src
		params = {'since_id': id_src, 'limit': 100}
		if not self.is_import_inactive():
			params['status'] = 'active'
		products = self.api('products.json', data = params)
		if not products or not products.products:
			if self._last_status != 200:
				return Response().error(Errors.SHOPIFY_GET_PRODUCT_FAIL)
			return Response().finish()
		return Response().success(data = products.products)


	def get_products_ext_export(self, products):
		all_product_ids = [f"gid://shopify/Product/{row['id']}" for row in products]
		split_product_ids = split_list(all_product_ids, 10)
		extend = Prodict()

		for product_ids in split_product_ids:
			query = '''
	  query GetProductByProductIds($ProductIDs:[ID!]!)
	  {
	  nodes(ids: $ProductIDs) {
	    ...on Product {
	        id
	      productCategory {
	      productTaxonomyNode {
	        id
	        fullName
	      }
	      
	    }
	    media(first: 20) {
	      nodes {
	        ... on ExternalVideo {
	          id
	          originUrl
	        }
	        ... on Video {
	          id
	          originalSource {
	            url
	            width
	            height
	            fileSize
	            format
	            mimeType
	          }
	          filename
	        }
	      }
	    }
	    metafields(first: 100) {
	      nodes {
	        type
	        value
	        key
	      }
	    }
	    }
	  }
	}'''
			responses = self.graphql_api(query, variables = {'ProductIDs': product_ids})
			if responses.result == Response.SUCCESS:
				response_data = responses.data
				for product in response_data['data']['nodes']:
					product_id = to_str(product.id.split('/')[-1])
					extend[to_str(product_id)] = {
						"meta": product['metafields']['nodes'],
						"media": product['media']['nodes'],
						"category": product["productCategory"].get("productTaxonomyNode") if product['productCategory'] else None
					}
		return Response().success(extend)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(''.join(updated_at.rsplit(':', 1)), '%Y-%m-%dT%H:%M:%S%z', limit_len = False)


	def get_all_variants_metafields(self, product_id, cursor = None):
		results = {}
		query = 'query:"product_id:' + to_str(product_id) + '"'

		if cursor:
			query += f',after: "{cursor}"'

		query = '''query MyQuery  {
  productVariants('''+query+''', first: 10) {
      pageInfo {
      hasNextPage
    }
    edges {
      cursor
    }
    nodes {
      metafields(first: 50) {
        nodes {
          value
          key
        }
      },
      id
    }
  }
}
'''
		response = self.graphql_api(query)
		if response.result != Response.SUCCESS:
			return results
		metafields = response.data.data.productVariants.nodes
		for metafield in metafields:
			variant_id = to_int(to_str(metafield['id']).split('/')[-1])
			results[variant_id] = metafield['metafields']['nodes']
		if response.data.data.productVariants.pageInfo.hasNextPage:
			current_cursor = response.data.data.productVariants.edges[-1]['cursor']
			extend = self.get_all_variants_metafields(product_id, current_cursor)
			results.update(extend)
		return results

	def get_variant_metafield(self, product_data, variant, variant_metafields):
		"""get the metaobject list of the default variant
		 and combine it with the parent attribute"""
		combine_atr_list = list()
		if variant_metafields and variant_metafields.get(to_int(variant.id)):
			variant_atr_list = list()
			variant_metafield = variant_metafields.get(to_int(variant.id))
			for metafield in variant_metafield:
				variant_attribute = ProductAttribute()
				variant_attribute.attribute_name = metafield['key']
				variant_attribute.attribute_value_name = metafield['value']
				variant_atr_list.append(variant_attribute)

			parent_attribute_list = list()
			variant_atr_name = [atr['attribute_name'] for atr in variant_atr_list]
			for atr in product_data.attributes:
				if atr['attribute_name'] not in variant_atr_name:
					parent_attribute_list.append(atr)

			combine_atr_list = copy.deepcopy(parent_attribute_list) + variant_atr_list

		return combine_atr_list


	def _convert_product_export(self, product, products_ext: Prodict):
		if self._state.channel.config.api.product_filter_sku_start_with:
			sku = product.variants[0].sku
			if not to_str(sku).startswith(self._state.channel.config.api.product_filter_sku_start_with):
				return Response().skip()
		product_id = to_str(product.id)
		product_data = Product()
		channel_id = to_str(self._state.channel.id)
		product_data.tags = product.tags
		count_children = to_len(product.variants) if product.variants else None
		if not count_children:
			return Response().error(Errors.SHOPIFY_API_INVALID)
		# Filter exclude tag from shopify
		try:
			shopify_tags = list(map(lambda x: to_str(x.strip()), product.tags.split(', ')))
			exclude_tag = self._request_data.get("include_filters", {}).get("exclude_tag") if self._request_data.get("include_filters", {}) else None
			if exclude_tag and shopify_tags and exclude_tag in shopify_tags:
				return Response().skip()
		except:
			self.log_traceback()
		all_collection = list()
		custom_collections = self.api('custom_collections.json', data = {'product_id': product_id})
		smart_collections = self.api('smart_collections.json', data = {'product_id': product_id})
		category_template = list()
		if custom_collections and custom_collections.custom_collections:
			all_collection += custom_collections.custom_collections
			for row in custom_collections.custom_collections:
				category_template.append({
					"category_id": row['id'],
					"category_name": row['title'],
					"collection_type": 'custom'
				})
		if smart_collections and smart_collections.smart_collections:
			all_collection += smart_collections.smart_collections
			for row in smart_collections.smart_collections:
				category_template.append({
					"category_id": row['id'],
					"category_name": row['title'],
					"collection_type": 'smart'
				})
		for collection in all_collection:
			product_data.category_name_list.append(collection.title)
		product_data.template_data = {
			'category': {
				'categories': category_template
			}
		}

		product_data.channel_data = {
			'product_type': product.product_type,
		}

		product_data.price = product.variants[0].price
		variant_default = product.variants[0]
		inventory_item_id = variant_default.inventory_item_id
		product_data.inventory_item_id = inventory_item_id
		inventory_policy = variant_default.inventory_policy
		product_data.inventory_policy = inventory_policy

		if variant_default.compare_at_price and to_decimal(variant_default.compare_at_price) > to_decimal(variant_default.price):
			product_data.special_price.price = variant_default.price
			product_data.price = variant_default.compare_at_price

		product_data.weight = product.variants[0].weight  # product['variants'][0]['grams'] if product['variants'][0]['weight_unit'] == 'g' else
		product_data.weight_units = product.variants[0].weight_unit  # product['variants'][0]['grams'] if product['variants'][0]['weight_unit'] == 'g' else
		product_data.status = True if product.status == 'active' else False
		product_data.invisible = not product_data.status
		product_data.manage_stock = True if product.variants[0].inventory_management else False
		if product_data.manage_stock:
			product_data.is_in_stock = True if to_int(product.variants[0].inventory_quantity) > 0 else False
		else:
			product_data.is_in_stock = True
		product_data.created_at = self.iso_format_datetime_to_format(product.created_at)
		product_data.updated_at = self.iso_format_datetime_to_format(product.updated_at)
		product_data.name = product.title
		product_data.description = product.body_html
		if not self._state.channel.config.api.skip_barcode:
			if self.is_barcode_to_gtin():
				product_data.gtin = product.variants[0].barcode
			elif not self.user_is_europe():
				product_data.upc = product.variants[0].barcode
			else:
				product_data.ean = product.variants[0].barcode
		if product.image and product.image.src:
			product_data.thumb_image.url = product.image.src
			product_data.thumb_image.label = product.image.alt

		if product.images:
			for image in product.images:
				if image['id'] == product['image']['id']:
					continue
				product_image_data = ProductImage()
				product_image_data.url = image.src
				product_image_data.label = image.alt
				product_image_data.position = image.position
				product_data.images.append(product_image_data)
		product_data.brand = product.vendor
		product_data.product_type = product.product_type
		product_data.seo_url = f"{self.get_channel_url()}/products/{product.handle.strip('/')}"
		package_fields = ['width', 'height', 'length']
		dimension_fields = ['width_', 'height_', 'length_']
		if products_ext and products_ext.get_attribute(product_id).meta:
			for metafields in products_ext.get_attribute(product_id).meta:
				if metafields.key in package_fields:
					field = metafields.key
					value = metafields.value
					if is_decimal(to_str(value)):
						product_data[field] = to_decimal(value)
						continue
					if json_decode(value):
						value = json_decode(value)
						if isinstance(value, dict) and to_decimal(value.get('value')):
							product_data[field] = to_decimal(value.get('value'))
							product_data.dimension_units = value.get('unit') or value.get('units')
							continue


				if metafields.key in dimension_fields:
					field = f'dimension_{to_str(metafields.key).strip("_")}'
					value = metafields.value
					attribute_data = ProductAttribute()
					attribute_data.id = metafields.id
					attribute_data.attribute_name = field
					attribute_data.attribute_value_name = metafields.value
					attribute_data.attribute_type = 'text'
					product_data.attributes.append(attribute_data)
					continue

				# elif json_decode(value):
				# 	value = json_decode(value)
				# 	if to_str(value.get('value')).isnumeric():
				# 		product_data[field] = to_decimal(to_decimal(value.get('value')))
				# 		continue
				if metafields.key == 'condition':
					product_data.condition = self.CONDITION.get(metafields.value, Product.CONDITION_NEW)
				if metafields.key == 'ebay_condition':
					product_data.ebay_condition = metafields.value
				if metafields.key == 'short_description':
					product_data.short_description = metafields.value
				elif metafields.key == 'description_tag':
					product_data.meta_description = metafields.value
				elif metafields.key == 'title_tag':
					product_data.meta_title = metafields.value
				else:
					attribute_data = ProductAttribute()
					attribute_data.id = metafields.id
					attribute_data.attribute_name = metafields.key
					attribute_data.attribute_value_name = metafields.value
					attribute_data.attribute_type = 'text'
					product_data.attributes.append(attribute_data)
		if products_ext and products_ext.get_attribute(product_id).category:
			product_data.shopify_product_category = products_ext.get_attribute(product_id).category.id
		try:
			if products_ext and products_ext.get_attribute(product_id).media:
				for media in products_ext.get_attribute(product_id).media:
					if not media or (not media.originalSource and not media.originUrl):
						continue
					product_video = ProductVideo()
					if media.originalSource:
						product_video.title = product.title
						product_video.url = media.originalSource.url
						product_video.format = media.originalSource.format
						product_video.filesize = media.originalSource.fileSize
					else:
						product_video.url = media.originUrl
					product_data.videos.append(product_video)
		except:
			self.log_traceback()

		if product.variants:
			qty = 0
			is_in_stock = False
			manage_stock = False
			inventory_item_ids = [to_str(variant.inventory_item_id) for variant in product.variants]
			product_variant_inventory_levels = self.get_all_inventory_levels(inventory_item_ids)
			product_variant_inventory_items = self.get_all_inventory_items(inventory_item_ids)

			try:
				inventory_levels_default = list(filter(lambda x: x['inventory_item_id'] == inventory_item_id, product_variant_inventory_levels))

				if inventory_levels_default:
					for inventory_level in inventory_levels_default:
						product_location = ProductLocation()
						product_location.location_id = inventory_level.location_id
						available = to_int(inventory_level.available)
						if available <= 0 and to_int(variant_default.inventory_quantity) > 0 and to_len(inventory_levels_default) == 1:
							available = variant_default.inventory_quantity
						product_location.qty = to_int(available)
						product_data.locations.append(product_location)
				inventory_item_default = list(filter(lambda x: x['id'] == inventory_item_id, product_variant_inventory_items))

				if inventory_item_default and to_decimal(inventory_item_default[0].cost):
					product_data.cost = to_decimal(inventory_item_default[0].cost)
			except Exception:
				self.log_traceback()
			product_locations = {}
			try:
				variant_metafields = self.get_all_variants_metafields(product_id)
			except:
				variant_metafields = {}
			for variant in product.variants:
				variant_inventory_item_id = variant.inventory_item_id

				qty += to_int(variant.inventory_quantity)

				if variant.inventory_management:
					variant_is_in_stock = True if to_int(variant.inventory_quantity) > 0 else False
				else:
					variant_is_in_stock = True
				if variant_is_in_stock:
					is_in_stock = True
				variant_manage_stock = True if variant.inventory_management else False
				if variant_manage_stock:
					manage_stock = True
				variant_inventory_policy = variant.inventory_policy
				variant_data = ProductVariant()
				variant_data.inventory_policy = variant_inventory_policy
				try:
					variant_inventory_levels = list(filter(lambda x: x['inventory_item_id'] == variant_inventory_item_id, product_variant_inventory_levels))
					if variant_inventory_levels:
						for inventory_level in variant_inventory_levels:
							if not product_locations.get(inventory_level.location_id):
								product_locations[inventory_level.location_id] = 0
							product_location = ProductLocation()
							product_location.location_id = inventory_level.location_id
							available = to_int(inventory_level.available)
							if available <= 0 and to_int(variant.inventory_quantity) >0 and to_len(variant_inventory_levels) == 1 :
								available = variant.inventory_quantity
							product_locations[inventory_level.location_id] += available

							product_location.qty = available
							variant_data.locations.append(product_location)
				except:
					self.log_traceback()
				if variant.title.lower() in ['default title', 'default']:
					product_data.sku = variant.sku
					if self._state.channel.config.api.skip_variant_metafield:
						# seller want to skip variant metafield
						continue

					try:
						combine_variant_attribute = self.get_variant_metafield(product_data, variant, variant_metafields)
						if combine_variant_attribute:
							product_data.attributes = combine_variant_attribute
					except:
						self.log_traceback()

					continue
				try:
					variant_inventory_item = list(filter(lambda x: x['id'] == variant_inventory_item_id, product_variant_inventory_items))
					if variant_inventory_item and to_decimal(variant_inventory_item[0].cost):
						variant_data.cost = to_decimal(variant_inventory_item[0].cost)
				except:
					self.log_traceback()

				variant_data.id = to_str(variant.id)
				if not self._state.channel.config.api.skip_barcode:
					if self.is_barcode_to_gtin():
						variant_data.gtin = variant.barcode
					elif not self.user_is_europe():
						variant_data.upc = variant.barcode
					else:
						variant_data.ean = variant.barcode
				# variant_data.set_attribute('channel_{}'.format(channel_id), variant_id)
				# variant_channel = ProductChannel()
				# variant_channel.product_id = variant_id
				# variant_data.channel.append(variant_channel)
				variant_data.name = product.title + "-" + variant.title
				variant_data.sku = variant.sku
				variant_data.status = product_data.status
				variant_data.invisible = not product_data.status
				variant_data.price = variant.price
				if variant.compare_at_price and to_decimal(variant.compare_at_price) > to_decimal(variant.price):
					variant_data.special_price.price = variant.price
					variant_data.price = variant.compare_at_price
				image = get_row_value_from_list_by_field(product.images, 'id', variant.image_id, 'src')
				if image:
					variant_data.thumb_image.url = image
				variant_data.qty = to_int(variant.inventory_quantity)
				variant_data.manage_stock = variant_manage_stock
				variant_data.is_in_stock = variant_is_in_stock
				variant_data.weight = variant['weight']
				variant_data.weight_units = variant.weight_unit
				variant_data.created_at = convert_format_time(''.join(variant.created_at.rsplit(':', 1)), '%Y-%m-%dT%H:%M:%S%z')
				variant_data.updated_at = convert_format_time(''.join(variant.updated_at.rsplit(':', 1)), '%Y-%m-%dT%H:%M:%S%z')
				variant_sku = to_str(variant.sku)
				for index in range(1, 4):
					if variant.get_attribute('option{}'.format(index)):
						variant_attribute = ProductVariantAttribute()
						variant_attribute.id = "{}_{}".format(product_id, index)
						variant_attribute.attribute_type = 'select'
						variant_attribute.attribute_name = get_row_value_from_list_by_field(product.options, 'position', index, 'name')
						variant_attribute.attribute_value_name = variant.get_attribute('option{}'.format(index))
						variant_sku = variant_sku.replace(variant_attribute.attribute_value_name, '')
						variant_data.attributes.append(variant_attribute)
				if not variant_data.attributes:
					continue
				try:
					if variant_metafields and variant_metafields.get(to_int(variant.id)):
						variant_metafield = variant_metafields.get(to_int(variant.id))
						for metafield in variant_metafield:
							variant_attribute = ProductAttribute()
							variant_attribute.attribute_name = metafield['key']
							variant_attribute.attribute_value_name = metafield['value']
							variant_data.attributes.append(variant_attribute)
				except Exception:
					self.log_traceback()
				if not product_data.sku:
					variant_sku = variant_sku.strip(' -_')
					if to_str(variant.sku).startswith(variant_sku):
						product_data.sku = variant_sku
					else:
						product_data.sku = variant.sku
				variant_data.seo_url = f"{product_data.seo_url}?variant={variant.id}"
				product_data.variants.append(variant_data)
			try:
				product_location_qty = list()
				for location_id, location_qty in product_locations.items():
					product_location = ProductLocation()
					product_location.location_id = location_id
					product_location.qty = location_qty
					product_location_qty.append(product_location)
				product_data.locations = product_location_qty
			except:
				self.log_traceback()
			product_data.qty = qty
			product_data.is_in_stock = is_in_stock
			product_data.manage_stock = manage_stock
		if not self.is_import_outstock() and not product_data.is_in_stock:
			return Response().skip()
		# if product_data.variants:
		# 	real_sku = to_str(product_data.sku)
		# 	product_data.sku = None
		# 	sku = real_sku.split('-')
		# 	if len(sku) > 1:
		# 		suffix = to_str(sku[-1]).strip(' ')
		# 		if suffix.isnumeric():
		# 			del sku[-1]
		# 			sku = "-".join(sku)
		# 			real_sku = sku
		# 	product_data.sku = real_sku
		# if not product_data.sku:
		# 	product_data.sku = product.id
		try:
			if self._state.channel.config.api.concat_upc_to_sku:
				if (product_data.upc or product_data.ean) and product_data.sku:
					product_data.sku = f'{product_data.upc or product_data.ean}-{product_data.sku}'
				for variant in product.variants:
					if (variant.upc or variant.ean) and variant.sku:
						variant.sku = f'{variant.upc or variant.ean}-{variant.sku}'
		except:
			self.log_traceback()
		return Response().success(product_data)


	def get_all_inventory_items(self, all_inventory_item_ids):
		inventory_item_ids_split = split_list(all_inventory_item_ids, 50)
		response = []
		for inventory_item_ids in inventory_item_ids_split:
			next_link = ''
			while True:
				if not next_link:

					product_variant_inventory_levels = self.api(f'inventory_items.json', data = {'ids': ','.join(inventory_item_ids), "limit": 250})
				else:
					product_variant_inventory_levels = self.requests(next_link)

				if self._last_status > 300:
					self.set_action_stop(True)
					return []
				response.extend(product_variant_inventory_levels['inventory_items'])
				links = self._last_header.get('link')
				if links and 'next' in links:
					list_link = links.split(',')
					for link_row in list_link:
						if 'next' in link_row:
							next_link = link_row.split(';')[0]
							next_link = next_link.strip('<> ')
				if not next_link:
					break
		return response


	def get_all_inventory_levels(self, all_inventory_item_ids):
		inventory_item_ids_split = split_list(all_inventory_item_ids, 50)
		response = []
		for inventory_item_ids in inventory_item_ids_split:
			next_link = ''
			while True:
				if not next_link:
					product_variant_inventory_levels = self.api(f'inventory_levels.json', data = {'inventory_item_ids': ','.join(inventory_item_ids),'limit': 250})
				else:
					product_variant_inventory_levels = self.requests(next_link)
				next_link = ''
				if self._last_status > 300:
					self.set_action_stop(True)
					return []
				response.extend(product_variant_inventory_levels['inventory_levels'])
				links = self._last_header.get('link')
				if links and 'next' in links:
					list_link = links.split(',')
					for link_row in list_link:
						if 'next' in link_row:
							next_link = link_row.split(';')[0]
							next_link = next_link.strip('<> ')
				if not next_link:
					break
		return response

	def extend_images(self, product):
		images = list()
		images_url = []
		if product.thumb_image.url:
			main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			images.append({
				'url': main_image['url'],
				'alt': product.thumb_image.label
			})
			images_url.append(main_image['url'])
		# image_data = self.resize_image(main_image['url'])
		# if image_data:
		# 	images.append(image_data)
		# else:
		# 	images.append({'src': html_unquote(main_image['url'])})
		for img_src in product.images:
			if 'status' in img_src and not img_src['status']:
				continue
			image_process = self.process_image_before_import(img_src.url, img_src.path)
			if image_process['url'] not in images_url:
				images_url.append(image_process['url'])
				images.append({
					'url': image_process['url'],
					'alt': img_src.get('label')
				})
		return images


	def product_import(self, convert: Product, product, products_ext):
		convert_product = self.product_to_shopify_data(product, products_ext, insert = True)
		if convert_product.result != Response.SUCCESS:
			return convert_product
		post_data, images = convert_product.data
		response = self.api('products.json', post_data, 'Post')
		if self._last_status < 300 and self._state.channel.config.api.product_retry_image:
			return_images = response.product.images
			retry = 0
			while len(images) != len(return_images) and retry < 5:
				self.delete_product_import(response['product']['id'])
				retry += 1
				time.sleep(1)
				response = self.api('products.json', post_data, 'Post')
				if self._last_status >= 300:
					break
				return_images = response.product.images

		check_response = self.check_response_import(response, product, 'product')
		if check_response.result != Response.SUCCESS:
			if 'Image' in check_response['msg']:
				del post_data['product']['images']
				response = self.api('products.json', post_data, 'Post')
				response = json_decode(response)
				check_response = self.check_response_import(response, convert, 'product')
				if check_response['result'] != 'success':
					return check_response
			else:
				return check_response

		product_id = response['product']['id']
		# Product variants, inventory
		product_images = dict()
		for index, image in enumerate(images):
			try:
				product_images[html_unquote(image['url'])] = response.product.images[index]['id']
			except:
				pass
		self.set_last_product_response(response, product_images)
		if product.variants:
			qty = 0
			for variant in product.variants:
				qty += variant.qty
			if qty > 0 and not product.is_in_stock:
				self._extend_product_map['is_in_stock'] = True
		return Response().success(product_id)


	def is_skip_update_product_type_and_collection(self):
		return self._state.channel.config.api.skip_update_product_type_and_collection

	def is_skip_create_tags(self):
		return self._state.channel.config.api.skip_create_tags


	def get_image_content(self, url):
		if not self._state.channel.config.api.download_image_before:
			return False
		name = os.path.basename(url)
		result = dict()
		result['filename'] = name
		result['attachment'] = ''
		try:
			r = False
			retry = 0
			while r is False and retry < 5:
				try:
					r = requests.get(url, headers = {"User-Agent": get_random_useragent()}, timeout = 60, verify = False)
					image = Image.open(io.BytesIO(r.content))
				except Exception as e:
					time.sleep(2)
					retry += 1
					r = False
					if retry == 1:
						self.log_traceback('image_resize')
			if not r or r.status_code != 200:
				self.log(r.status_code, 'image_resize')
				return False
			return r.content
		except:
			self.log_traceback()
			return False


	def product_to_shopify_data(self, product: Product, product_ext, insert = False):
		if not product.name:
			return Response().error(Errors.PRODUCT_DATA_INVALID)
		# name = to_str(product.name).replace('/', '-')
		# Add thumbnail, images
		images = self.extend_images(product)
		# if product.variants:
		# 	for variant in product.variants:
		# 		images += self.extend_images(variant)
		# images = list(set(images))
		images = images[0:self.IMAGE_LIMIT]
		shopify_images = list()
		for index, image in enumerate(images):
			image_data = self.get_image_content(image['url'])
			if not image_data:
				image_data = {
					'src': html_unquote(image['url']),
				}
			image_data['position'] = index + 1

			if image.get('alt'):
				image_data['alt'] = image['alt']
			shopify_images.append(image_data)

		# Initiate Post data

		post_data = {
			'product': {
				'title': product.name[0:255],
				'body_html': nl2br(self.custom_description_import(product.description if product.description else product.short_description)),
				'vendor': product.brand,
				'product_type': product.product_type or '',
				'images': shopify_images,
				# 'created_at': product.created_at,
				'updated_at': product.updated_at
			}
		}
		if self.is_skip_update_product_type_and_collection() and not insert:
			del post_data['product']['product_type']
		if product.weight:
			post_data['product']['weight'] = to_decimal(product.weight)
			post_data['product']['weight_unit'] = product.weight_units or 'oz'
		# Add product's status
		if not product.status:
			post_data['product']["status"] = "draft"
			post_data['product']["published"] = False
			post_data['product']['published_at'] = None

		if product.meta_description or product.meta_title:
			post_data['product']['metafields_global_title_tag'] = product.meta_title
			post_data['product']['metafields_global_description_tag'] = product.meta_description
		metafields_keys = list()
		post_data['product']['metafields'] = list()
		shopify_metafields = dict()
		special_attribute = ('description', 'short_description')
		if product.attributes:
			for attribute in product.attributes:
				if to_str(attribute.attribute_name) in special_attribute or not attribute.attribute_name:
					continue
				option_name = self.name_to_code(attribute.attribute_name)
				if option_name == 'brand' and not post_data['product']['vendor']:
					post_data['product']['vendor'] = attribute.attribute_value_name
					continue
				while option_name in shopify_metafields:
					option_name = attribute.attribute_name + ' ' + to_str(to_int(time.time()))
				# metafields_keys.append(option_name)
				if to_len(option_name) < 3:
					continue
				shopify_metafields[option_name[:30]] = attribute.attribute_value_name
		# metafield = {
		# 	'key': option_name[:30],
		# 	'value': attribute.attribute_value_name,
		# 	'type': 'single_line_text_field',
		# 	'namespace': 'global'
		# }
		# post_data['product']['metafields'].append(metafield)
		# add metafield Dimensions
		dimensions = ('length', 'width', 'height')
		for dimension in dimensions:
			if dimension in metafields_keys:
				continue
			if to_decimal(product.get(dimension)) and dimension not in shopify_metafields:
				shopify_metafields[dimension] = to_str(to_decimal(product.get_attribute(dimension)))
		# metafield = {
		# 	'key': dimension,
		# 	'value': to_str(to_decimal(product.get_attribute(dimension))),
		# 	'type': 'single_line_text_field',
		# 	'namespace': 'global'
		# }
		# post_data['product']['metafields'].append(metafield)
		if not product.description and product.short_description:
			option_name = 'short_description'
			index = 2
			while option_name in shopify_metafields:
				option_name = 'short_description' + ' ' + to_str(index) + 'nd'
				index += 1
			shopify_metafields[option_name] = product.short_description
		# metafields_keys.append(option_name)
		# metafield = {
		# 	'key': option_name[:30],
		# 	'value': product.short_description,
		# 	'type': 'multi_line_text_field',
		# 	'namespace': 'global'
		# }
		# post_data['product']['metafields'].append(metafield)
		identifier = ['isbn', 'mpn', 'gtin']
		for field in identifier:
			if product.get(field) and field not in shopify_metafields:
				shopify_metafields[field] = product[field]
		for meta_key, meta_value in shopify_metafields.items():
			post_data['product']['metafields'].append({
				'key': meta_key,
				'value': meta_value,
				'type': self.get_metafields_definition(meta_key, meta_value),
				'namespace': 'global'
			})
		try:
			src_channel_id = self.get_src_channel_id()
			if src_channel_id != self.get_channel_id():
				src_channel = self.get_channel_by_id(src_channel_id)
				if src_channel.type == 'ebay':
					category_template_data = product[f'channel'][f'channel_{src_channel_id}']['template_data']['category']
					condition = category_template_data['condition']['value']['condition_name']
					condition_description = category_template_data['condition_note']
					if condition:
						post_data['product']['metafields'].append({
							'key': "ebay_condition",
							'value': condition,
							'type': self.get_metafields_definition('ebay_condition', meta_value),
							'namespace': 'global'
						})
					if condition_description:
						post_data['product']['metafields'].append({
							'key': "ebay_condition_description",
							'value': condition_description,
							'type': self.get_metafields_definition('ebay_condition_description', meta_value),
							'namespace': 'global'
						})
		except:
			self.log_traceback(type_error = 'condition')
		tags = to_str(product['tags']).split(',')
		if not self.is_skip_update_product_type_and_collection() or insert:
			template_category = product.get('template_data', {}).get('category', {})
			if template_category and template_category.get('categories'):
				for category in template_category['categories']:
					if category.get('collection_type') == self.SMART_COLLECTION:
						tags.append(category.category_name)

			elif self.is_auto_import_category():
				category_name_list = product.category_name_list or []
				categories = list()

				if product.category_path:
					category_name_path = product.category_path.split('>')[-1].strip()
					if category_name_path not in category_name_list:
						category_name_list.append(category_name_path)
				for category_name in category_name_list:
					category_id = self.get_smart_collection_by_name(category_name)
					tags.append(category_name.replace(',', ''))
					if category_id:
						categories.append({
							"category_id": category_id,
							"category_name": category_name,
							"collection_type": 'smart'
						})
				if not self.is_channel_default() and categories:
					self._extend_product_map = {
						'template_data': {
							'category': {
								'categories': categories
							}
						}
					}
		if tags and not self.is_skip_create_tags():
			tags = ','.join(list(set(tags)))
			post_data['product']['tags'] = to_str(tags).strip(', ')
		return Response().success((post_data, images))


	def get_metafields_definition(self, meta_key, meta_value):
		metafields_definition = self.get_shopify_metafield_definitions() or self._state.channel.config.api.metafields_definition
		defi = 'multi_line_text_field' if ('description' in meta_key or to_str(meta_value).find('\n') != -1) else 'single_line_text_field'
		if metafields_definition and meta_key in metafields_definition:
			defi = metafields_definition[meta_key]
		return defi


	def variant_to_shopify_data(self, product_id, variant: ProductVariant, options, images, parent: Product):
		compare_price, sale_price = self.to_shopify_price(variant)

		variant_post_data = {
			'title': variant.name,
			'compare_at_price': compare_price,
			'price': sale_price,
			'sku': variant.sku,
			'barcode': variant.barcode or variant.upc or variant.ean or variant.gtin,
			'weight': to_decimal(variant.weight) if to_decimal(variant.weight) > 0 else 0,
			'inventory_management': 'shopify' if variant.manage_stock else None,
			# 'inventory_quantity': to_int(variant.qty),
			'cost': variant.cost,
			'inventory_policy': 'deny' if variant.manage_stock else 'continue',
			'metafields': [],
		}
		if parent.weight_units:
			variant_post_data['weight_unit'] = parent.weight_units
		if not variant_post_data['weight']:
			variant_post_data['weight'] = to_decimal(parent.weight) if to_decimal(parent.weight) > 0 else 0
		if variant.inventory_policy:
			variant_post_data['inventory_policy'] = variant.inventory_policy
		thumb_image = variant.thumb_image.url or parent.thumb_image.url
		if thumb_image:
			main_image = self.process_image_before_import(thumb_image, variant.thumb_image.path)
			image_url = main_image['url']
			if images.get(html_unquote(image_url)):
				variant_post_data['image_id'] = images.get(thumb_image)
		metafields_keys = []
		shopify_metafields = dict()
		for attribute in variant.attributes:
			if attribute.use_variant:
				attribute_name = to_str(attribute.attribute_name).replace('/', '-')

				variant_post_data['option' + to_str(options[attribute_name]['position'])] = attribute.attribute_value_name
			else:
				if not attribute.attribute_name:
					continue
				option_name = self.name_to_code(attribute.attribute_name)
				while option_name in shopify_metafields:
					option_name = attribute.attribute_name + ' ' + to_str(to_int(time.time()))
				if to_len(option_name) < 3:
					continue
				shopify_metafields[option_name[:30]] = attribute.attribute_value_name
		# metafield = {
		# 	'key': option_name[:30],
		# 	'value': attribute.attribute_value_name,
		# 	'type': 'single_line_text_field',
		# 	'namespace': 'global'
		# }
		# variant_post_data['metafields'].append(metafield)
		if variant.description and variant.description != parent.description:
			metafields_key = 'description'
			if 'description' in metafields_keys:
				metafields_key += to_str(to_int(time.time()))
			shopify_metafields[metafields_key] = variant.description

		# variant_post_data['metafields'].append({
		# 	'key': metafields_key,
		# 	'value': variant.description,
		# 	'type': 'multi_line_text_field',
		# 	'namespace': 'global'
		# })
		identifier = ['isbn', 'mpn', 'gtin']
		for field in identifier:
			if variant.get(field) and field not in shopify_metafields:
				shopify_metafields[field] = variant[field]
		for meta_key, meta_value in shopify_metafields.items():
			variant_post_data['metafields'].append({
				'key': meta_key,
				'value': meta_value,
				'type': 'multi_line_text_field' if 'description' in meta_key else 'single_line_text_field',
				'namespace': 'global'
			})
		return variant_post_data


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		# self.assign_product_to_sale_channel(product_id)
		extend_map = copy.deepcopy(self._extend_product_map)
		self._extend_product_map = {}
		template_category = product.get('template_data', {}).get('category', {})
		if template_category and template_category.get('categories'):
			for category in template_category['categories']:
				if category.get('collection_type') == self.SMART_COLLECTION:
					continue
				cat_post_data = {
					'collect': {
						'collection_id': category.category_id,
						'product_id': product_id
					}
				}
				self.api('collects.json', cat_post_data, 'Post')
		response, images = self.get_last_product_response()
		all_images = self.extend_images(product)
		try:
			if to_len(all_images) > self.IMAGE_LIMIT:
				variant_main_images = []
				variant_extend_images = []
				for variant in product.variants:
					if variant.thumb_image.url:
						variant_main_images.append(variant.thumb_image.url)
					if variant.images:
						for image in variant.images:
							variant_extend_images.append(image.url)
				index = self.IMAGE_LIMIT + 1
				for image in all_images[self.IMAGE_LIMIT:]:
					if html_unquote(image['url']) not in variant_main_images:
						continue
					image_data = self.get_image_content(image['url'])
					if not image_data:
						image_data = {
							'src': html_unquote(image['url']),
						}
					image_data.update({
						'position': index + 1,
						'product_id': product_id
					})
					index += 1

					if image.get('alt'):
						image_data['alt'] = image['alt']
					create_image = self.api(f'products/{product_id}/images.json', {'image':image_data}, 'post')
					if self._last_status < 300:
						images[html_unquote(image['url'])] = create_image['image']['id']
		except:
			self.log_traceback()
		if product.variants:
			options = self.get_options_from_variants(product.variants)
			variants_post_data = []
			for variant in product.variants:
				variant_post_data = self.variant_to_shopify_data(product_id, variant, options, images, product)
				variants_post_data.append(variant_post_data)
			# Add options post data
			options_post_data = []
			for option_key, option_value in options.items():
				options_post_data.append(
					{
						'name': option_key,
						'values': option_value['values']
					}
				)
			post_data = {
				'product': {
					'id': product_id,
					'variants': variants_post_data,
					'options': options_post_data
				}
			}
			var_response = self.api('products/' + to_str(product_id) + '.json', post_data, 'Put')
			check_response = self.check_response_import(var_response, product, 'product')
			if check_response.result != Response.SUCCESS:
				return check_response
			for index, variant_res in enumerate(var_response['product']['variants']):
				child = product.variants[index]
				self.insert_map_product(child, child['_id'], variant_res.id)
		# Import inventory for simple product
		else:
			default_variant = response['product']['variants'][0]
			compare_price, sale_price = self.to_shopify_price(product)
			sku = product.sku
			if self._state.channel.config.api.listing_id_to_sku:
				listing_channel_id = self._state.channel.config.api.listing_id_to_sku
				if product.channel.get(f'channel_{listing_channel_id}', {}).get('product_id'):
					sku = product.channel.get(f'channel_{listing_channel_id}', {}).get('product_id')
			variants_post_data = {
				'id': default_variant['id'],
				'title': 'Default Title',
				'compare_at_price': compare_price,
				'price': sale_price,
				'sku': sku,
				'barcode': product.barcode or product.upc or product.ean or product.gtin,
				'weight': to_decimal(product.weight) if to_decimal(product.weight) > 0 else 0,
				'inventory_management': 'shopify' if product.manage_stock else None,
				'inventory_quantity': to_int(product.qty) if product.is_in_stock else 0,
				'cost': product.cost,
				'inventory_policy': 'deny' if product.manage_stock else 'continue',
			}
			if product.weight_units:
				variants_post_data['weight_unit'] = product.weight_units
			if product.inventory_policy:
				variants_post_data['inventory_policy'] = product.inventory_policy
			post_data = {
				'product': {
					'id': product_id,
					'variants': [variants_post_data],
				}
			}
			var_response = self.api('products/' + to_str(product_id) + '.json', post_data, 'Put')
			check_response = self.check_response_import(product, var_response)
			if check_response.result != Response().SUCCESS:
				return check_response
		if var_response.get('product', dict()).get('variants'):
			location_id = self.get_location_id()
			if location_id:
				variants = var_response.get('product', dict()).get('variants')
				if variants:
					if not product.variants:
						inventory = self.set_inventory_level(variants[0]['inventory_item_id'], product.qty, location_id = self.get_create_location(self.get_src_channel_id()))
					else:
						for index, row in enumerate(variants):
							variant = product.variants[index]
							# for variant in product.variants:
							self.set_inventory_level(row['inventory_item_id'], variant.qty, location_id = self.get_create_location(self.get_src_channel_id()))
		if product.shopify_product_category:
			self.update_product_category(product_id, product.shopify_product_category)
		self._extend_product_map = copy.deepcopy(extend_map)
		return Response().success()


	def update_product_category(self, product_id, category_id):
		query = '''mutation MyMutation ($ProductID: ID!, $CategoryID: ID!){
		  productUpdate(input: {id: $ProductID, productCategory: {productTaxonomyNodeId: $CategoryID}}) {
		    product {
		      id
		    }
		  }
		}
		'''
		self.graphql_api(query, {"ProductID": f"gid://shopify/Product/{product_id}", "CategoryID": category_id})


	def keep_page_title(self):
		return self._state.channel.config.api.keep_page_title


	def product_channel_update(self, product_id, product: Product, products_ext):
		# Get product shopify data

		convert_product = self.product_to_shopify_data(product, products_ext)
		if convert_product.result != Response.SUCCESS:
			return convert_product
		product_data, images = convert_product.data
		custom_fields = self.api(f"metafields.json?metafield[owner_id]={product_id}&metafield[owner_resource]=product")
		if self._last_status < 300:
			title_tag = ''
			description_tag = ''
			for field in custom_fields['metafields']:
				if self.keep_page_title():
					if field['key'] == 'title_tag':
						title_tag = field['value']
					if field['key'] == 'description_tag':
						description_tag = field['value']
				delete_field = self.api(f"metafields/{field['id']}.json", api_type = 'delete')
			if title_tag:
				product_data['product']['metafields_global_title_tag'] = title_tag
			if description_tag:
				product_data['product']['metafields_global_description_tag'] = description_tag
		update = self.api(f'products/{product_id}.json', product_data, 'Put')
		update_response = self.check_response_import(update, product)
		if update_response.result != Response.SUCCESS:
			return update_response
		if product.shopify_product_category:
			self.update_product_category(product_id, product.shopify_product_category)
		product_images = dict()
		for index, image in enumerate(images):
			try:
				product_images[html_unquote(image['url'])] = update.product.images[index]['id']
			except:
				pass
		if not self.is_skip_update_product_type_and_collection():
			template_category = product.get('template_data', {}).get('category', {})
			if template_category and template_category.get('categories'):
				collects = self.api('collects.json', data = {'product_id': product_id})
				old_collection_id = dict()
				new_collection_id = list()
				if collects and collects.get('collects'):
					old_collection_id = {to_int(collect.collection_id): collect.id for collect in collects.collects}

				for category in template_category['categories']:
					if category.get('collection_type') == self.SMART_COLLECTION:
						continue
					new_collection_id.append(to_int(category.category_id))
				delete_ids = list(set(list(old_collection_id.keys())) - set(new_collection_id))
				create_ids = list(set(list(new_collection_id)) - set(old_collection_id.keys()))
				for collection_id in delete_ids:
					self.api(f'collects/{old_collection_id[collection_id]}.json', api_type = 'delete')
				for collection_id in create_ids:
					cat_post_data = {
						'collect': {
							'collection_id': collection_id,
							'product_id': product_id
						}
					}
					self.api('collects.json', cat_post_data, 'Post')

		shopify_product = update.product
		# Update product price, sku, inventory, barcode etc..
		location_id = self.get_location_id()

		if not product.variants:
			default_variant_id = shopify_product.variants[0]['id']
			compare_price, sale_price = self.to_shopify_price(product)

			variants_post_data = {
				'id': default_variant_id,
				'title': product.name,
				'compare_at_price': compare_price,
				'price': sale_price,
				'sku': product.sku,
				'barcode': product.barcode or product.upc or product.ean or product.gtin,
				'weight': to_decimal(product.weight) if to_decimal(product.weight) > 0 else 0,
				'inventory_management': 'shopify' if product.manage_stock else None,
				'inventory_quantity': to_int(product.qty),
				'cost': to_decimal(product.cost),
				'inventory_policy': 'deny' if product.manage_stock else 'continue',
			}
			response = self.api(f'products/{product_id}.json', {
				'product': {
					'variants': [variants_post_data]
				}
			}, 'Put')
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
			inventory = self.set_inventory_level(shopify_product.variants[0]['inventory_item_id'], product.qty)
			return Response().success()
		options = self.get_options_from_variants(product.variants)
		variant_update = list()
		shopify_variants = dict()
		for variant in product.variants:
			variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
			variant_post_data = self.variant_to_shopify_data(product_id, variant, options, product_images, product)
			if not variant_id:
				create_variant = self.api(f"products/{product_id}/variants.json", {'variant': variant_post_data}, 'post')
				if create_variant and create_variant.variant:
					self.insert_map_product(variant, variant['_id'], create_variant.variant.id)
					variant_id = create_variant.variant.id
				else:
					continue
			if variant_id:
				variant_post_data['id'] = variant_id
				variant_update.append(variant_post_data)
				shopify_variants[to_int(variant_id)] = variant
		response = self.api(f'products/{product_id}.json', {'product': {'variants': variant_update}}, 'Put')
		check_response = self.check_response_import(response, product)
		if check_response.result != Response.SUCCESS:
			return check_response
		for variant in response.product.variants:
			shopify_variant = shopify_variants.get(variant.id)
			if not shopify_variant:
				continue
			inventory = self.set_inventory_level(variant['inventory_item_id'], shopify_variant.qty)
			pass

		return Response().success()


	def set_inventory_level(self, inventory_item_id, qty, location_id = None):
		if not location_id:
			location_id = self.get_location_id()
		ivt_data = {
			'location_id': location_id,
			'inventory_item_id': inventory_item_id,
			'available': to_int(qty)
		}
		inventory = self.api('inventory_levels/set.json', ivt_data, 'Post')
		return inventory


	def get_create_location(self, channel_id):
		if not self.is_channel_default():
			return False
		setting = self.get_channel_setting(channel_id)
		if not setting or not setting.get('qty') or not setting['qty'].get('create_location'):
			return False
		return setting['qty']['create_location'].get('location_id')


	def adjust_inventory_level(self, inventory_item_id, qty, prefix = '+', channel_id = None):
		inventory_levels_res = self.api(f'inventory_levels.json', data = {'inventory_item_ids': inventory_item_id})
		if self._last_status != 200 and not inventory_levels_res.get('inventory_levels'):
			return False
		inventory_levels = inventory_levels_res.get('inventory_levels')
		qty = to_int(qty)
		location_default = inventory_levels[0]['location_id']
		settings = self.get_channel_setting(channel_id)
		location_setting = []
		if settings and settings.get('qty') and settings['qty'].get('locations'):
			location_setting = list(map(lambda x: to_int(x['location_id']), settings['qty'].get('locations')))
			if location_setting:
				location_default = location_setting[0]
		if prefix == '+':
			ivt_data = {
				'location_id': location_default,
				'inventory_item_id': inventory_item_id,
				'available_adjustment': qty
			}
			inventory = self.api('inventory_levels/adjust.json', ivt_data, 'Post')
			return inventory
		remain_qty = qty
		location_adjust = {}
		for inventory_level in inventory_levels:
			if location_setting and to_int(inventory_level['location_id']) not in location_setting:
				continue
			available_qty = to_int(inventory_level['available'])
			if available_qty >= remain_qty:
				adjust_qty = remain_qty
			else:
				adjust_qty = available_qty
			location_adjust[inventory_level['location_id']] = adjust_qty
			remain_qty = remain_qty - adjust_qty
			if remain_qty <= 0:
				break
		if remain_qty > 0:
			if not location_adjust.get(location_default):
				location_adjust[location_default] = 0
			location_adjust[location_default] += remain_qty
		for location_id, adjust_qty in location_adjust.items():
			qty = 0 - adjust_qty
			ivt_data = {
				'location_id': location_id,
				'inventory_item_id': inventory_item_id,
				'available_adjustment': qty
			}
			inventory = self.api('inventory_levels/adjust.json', ivt_data, 'Post')
		return True


	def channel_sync_inventory_level(self, variant, shopify_variant):
		update_data = dict()
		if variant.manage_stock and not shopify_variant.get('inventory_management'):
			update_data['inventory_management'] = 'shopify'
		if not variant.manage_stock and shopify_variant.get('inventory_management'):
			update_data['inventory_management'] = None
		if (to_int(variant.qty) == 0) and not variant.get('inventory_policy'):
			update_data['inventory_policy'] = 'deny'
		if update_data:
			self.api(f'variants/{shopify_variant["id"]}.json', {'variant': update_data}, 'put')
		if variant.manage_stock:
			self.set_inventory_level(shopify_variant['inventory_item_id'], variant.qty)


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		product_shopify_data = self.api(f'products/{product_id}.json')
		if not product_shopify_data.product:
			return Response().error()
		shopify_variants = {row['id']: row for row in product_shopify_data.product.variants}
		# Update product price, sku, inventory, barcode etc..
		update_data = {
			'product': {
				'id': product_id,
			}
		}
		if self.is_sync_product_invisible(product):
			update_data['product']['status'] = "draft"
			response = self.api('products/' + to_str(product_id) + '.json', update_data, 'Put')
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
			return Response().success()
		# Update product price, sku, inventory, barcode etc..
		if not product.variants:
			default_variant_id = product_shopify_data['product']['variants'][0]['id']
			inventory_item_id = product_shopify_data['product']['variants'][0]['inventory_item_id']
			if setting_qty:
				self.channel_sync_inventory_level(product, product_shopify_data['product']['variants'][0])

			variants_post_data = {
				'id': default_variant_id,
			}
			if setting_price:
				compare_price, sale_price = self.to_shopify_price(product)
				# price = product.price
				# compare_price = None
				# if self.is_special_price(product):
				# 	sale_price = special_price.price
				# 	compare_price = price if price and to_decimal(price) > to_decimal(sale_price) else None
				# else:
				# 	if product.msrp:
				# 		compare_price = product.msrp
				# 		sale_price = price
				# 	else:
				# 		sale_price = price
				variants_post_data['compare_at_price'] = compare_price
				variants_post_data['price'] = sale_price
				variants_post_data['cost'] = to_decimal(product.cost)

			update_data['product']['variants'] = [variants_post_data]
			response = self.api('products/' + to_str(product_id) + '.json', update_data, 'Put')
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
		else:
			variants_post_data = []
			channel_id = self._state.channel.id
			for variant in product.variants:
				variant_id = to_int(variant['channel'].get(f'channel_{channel_id}', {}).get('product_id'))
				if not variant_id:
					continue
				if setting_qty and shopify_variants.get(variant_id):
					self.channel_sync_inventory_level(variant, shopify_variants[variant_id])

				# self.set_inventory_level(shopify_variants[variant_id]['inventory_item_id'], variant.qty)
				# special_price = variant.special_price
				# price = variant.price
				# compare_price = None
				# if special_price.price and to_timestamp(special_price.start_date) < time.time() and (to_timestamp(special_price.end_date > time.time() or special_price.end_date == '0000-00-00' or special_price.end_date == '0000-00-00 00:00:00') or special_price.end_date == '' or not special_price.end_date):
				# 	sale_price = special_price.price
				# 	compare_price = price if price and to_decimal(price) > to_decimal(sale_price) else None
				# else:
				# 	sale_price = price
				manage_stock = variant.manage_stock
				variant_post_data = {
					'id': variant_id,
				}
				if setting_price:
					compare_price, sale_price = self.to_shopify_price(variant)

					variant_post_data['compare_at_price'] = compare_price
					variant_post_data['price'] = sale_price
					variant_post_data['cost'] = to_decimal(product.cost)
				# if setting_qty:
				# 	variant_post_data['inventory_management'] = 'shopify' if product.manage_stock else None
				# 	variant_post_data['inventory_quantity'] = to_int(product.qty)
				# 	variant_post_data['inventory_policy'] = 'deny' if manage_stock else 'continue'
				variants_post_data.append(variant_post_data)
			update_data['product']['variants'] = variants_post_data
			response = self.api('products/' + to_str(product_id) + '.json', update_data, 'Put')
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
		return Response().success()


	def delete_product_import(self, product_id):
		remove = self.api(f'products/{product_id}.json', None, 'delete')
		return Response().success()


	def get_options_from_variants(self, variants):
		options = {}
		position = 1
		for variant in variants:
			for attribute in variant.attributes:
				if not attribute.use_variant:
					continue
				attribute_name = to_str(attribute.attribute_name).replace('/', '-')
				if attribute_name not in options.keys():
					options[attribute_name] = {
						'values': [attribute.attribute_value_name],
						'position': position
					}
					position += 1
				elif attribute.attribute_value_name not in options[attribute_name]['values']:
					options[attribute_name]['values'].append(attribute.attribute_value_name)

		return options


	# orders
	def get_order_by_id(self, order_id):
		order = self.api(f'orders/{order_id}.json')
		if not order or not order.get('order'):
			return Response().error()
		return Response().success(order['order'])


	def get_orders_main_export(self):
		if self._flag_finish_order:
			return Response().finish()
		if self._order_next_link:
			orders = self.requests(self._order_next_link)
		else:
			limit_data = self._state.pull.setting.orders
			id_src = self._state.pull.process.orders.id_src
			start_time = self.get_order_start_time('iso')
			last_modifier = self._state.pull.process.orders.max_last_modified
			params = {
				"created_at_min": start_time,
				"status": 'any',
				'limit': limit_data,
			}
			if last_modifier:
				params['updated_at_min'] = self.shopify_datetime_to_utc_filter(last_modifier)
			orders = self.api('orders.json', data = params)
		if not orders or not orders.orders:
			if self._last_status != 200:
				return Response().error(Errors.SHOPIFY_GET_PRODUCT_FAIL)
			return Response().finish()
		links = self._last_header.get('link')
		next_link = ''
		if links and 'next' in links:
			list_link = links.split(',')
			for link_row in list_link:
				if 'next' in link_row:
					next_link = link_row.split(';')[0]
					next_link = next_link.strip('<> ')
		if not next_link:
			self._flag_finish_order = True
		else:
			self._order_next_link = next_link
		return Response().success(data = orders.orders)


	def get_orders_ext_export(self, orders):
		return Response().success()


	def order_refunded(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.order_canceled(channel_order_id, order_id, order, current_order, setting_order)


	def order_partially_refunded(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if order.refunds:
			transactions = self.api(f'orders/{channel_order_id}/transactions.json')
			if self._last_status != 200:
				return Response().error()
			parent_transaction_id = False
			amount_refund = []
			for transaction in transactions['transactions']:
				if transaction['kind'] != 'refund':
					if not not parent_transaction_id:
						parent_transaction_id = transaction['id']
				else:
					amount_refund.append(to_decimal(transaction['amount']))
			if parent_transaction_id:
				transaction_refunds = []
				for refund in order.refunds:
					if to_decimal(refund.amount) in amount_refund:
						index = amount_refund.index(to_decimal(refund.amount))
						del amount_refund[index]
						continue
					transaction_refund = {
						"parent_id": parent_transaction_id,
						"amount": refund.amount,
						"kind": "refund",
						"gateway": "manual"
					}
					transaction_refunds.append(transaction_refund)
				if transaction_refunds:
					refund_data = {
						"refund": {
							"notify": False,
							"note": f"Refund Form {current_order.channel_type} {current_order.channel_name}",
							"shipping": {
								"full_refund": False
							},

							"transactions": transaction_refunds
						}
					}
					refund_req = self.api(f'orders/{channel_order_id}/refunds.json', refund_data, api_type = 'post')
					if self._last_status < 300:
						return_order = {
							"status": 'PARTIALLY REFUNDED',
						}
						return Response().success(return_order)

		return Response().success()


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.channel_order_canceled(channel_order_id, order, current_order)
		cancel_order = self.api(f"orders/{channel_order_id}/cancel", {"reason": "other"}, api_type = 'post')
		if self._last_status == 200:
			update_data = {
				f"channel.channel_{self.get_channel_id()}.order_status": Order.CANCELED,
				f"channel.channel_{self.get_channel_id()}.cancelled_at": cancel_order.cancelled_at
			}
			self.get_model_order().update(order_id, update_data)

		return Response().success()


	def order_completed(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.channel_order_completed(channel_order_id, order, current_order)


	def order_sync_inventory(self, convert: Order, setting_order):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		channel_id = convert.channel_id
		for row in convert.products:
			product_id = None
			variant_id = None
			if row.get('sync_inventory') or row['link_status'] != 'linked' or not row.get('product'):
				continue
			if row['product_id'] and row['parent_id']:
				variant_id = row['product_id']
				product_id = row['parent_id']
			else:
				product_id = row['product_id']
				if product_id:
					product_info = self.api('products/' + to_str(product_id) + '.json')
					if product_info:
						if isinstance(product_info, dict) and product_info.get('product'):
							variant_id = product_info['product']['variants'][0]['id']
							if row['product'].get('sku'):
								for variant in product_info['product']['variants']:
									if row['product'].get('sku') == variant['sku']:
										variant_id = variant['id']
										break
			row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				variant = self.api(f'variants/{variant_id}.json')
				variant_data = variant.get('variant')
				if not variant_data:
					row['sync_msg_error'] = 'Variant Not Found'
					continue
				if not variant_data.inventory_management:
					row['sync_inventory'] = True
					continue
				inventory = self.adjust_inventory_level(variant['variant']['inventory_item_id'], row_qty, prefix, channel_id)
				if self._last_status < 300:
					row['sync_inventory'] = True
				else:
					check_response = self.check_response_import(inventory, row['product'], 'product')

					row['sync_msg_error'] = check_response.msg
		return Response().success(convert)

	def custom_order_status(self, order_status, order: Order):
		if not self._state.channel.config.api.custom_order_status:
			return order_status
		return self._state.channel.config.api.custom_order_status
		# custom_order_status = self._state.channel.config.api.custom_order_status.get(order_status, order_status)
		# if custom_order_status == '_channel_type_':
		# 	return order.channel_type or order_status
		# return custom_order_status


	def order_import(self, order: Order, convert: Order, orders_ext):
		order_status = self.custom_order_status(convert['status'], convert)
		if convert.get('financial_status'):
			financial_status = convert['financial_status']
		else:
			financial_status = self.FINANCIAL_ORDER_STATUS.get(order_status, 'pending')
		if convert.get('fulfillment_status'):
			fulfillment_status = convert['fulfillment_status']
		else:
			fulfillment_status = self.FULFILLMENT_STATUS.get(order_status, None)
		if fulfillment_status == 'unfulfilled':
			fulfillment_status = None
		keep_order = convert.keep_order_number
		channel_type = convert.channel_type
		if convert.channel_type == 'walmartca':
			channel_type = 'walmart'
		post_data = {
			'order': {
				'financial_status': financial_status,
				'fulfillment_status': fulfillment_status,
				'confirmed': True,
				'total_price': round(to_decimal(convert.total), 2),
				'subtotal_price': round(to_decimal(convert.subtotal), 2),
				'currency': convert.currency or 'USD',
				# 'processed_at': convert.created_at,
				# 'updated_at': convert.updated_at,
				'send_receipt': False,
				'send_fulfillment_receipt': False,
				'suppress_notifications': True,
				'inventory_behaviour': 'decrement_ignoring_policy',
				"source_name": channel_type,
				"source_identifier": convert.channel_order_number,
			}
		}

		# if self._state.channel.config.api.order_skip_process_at:
		# 	del post_data['order']['processed_at']
		# 	del post_data['order']['updated_at']
		order_number = f"{to_str(convert.order_number_prefix)}{to_str(convert.channel_order_number)}"
		if keep_order:
			post_data['order']['name'] = order_number
		tags = list()
		tags.append(to_str(convert.channel_name)[:40])
		order_config_fields = ['buyer_accepts_marketing', 'send_receipt', 'send_fulfillment_receipt']
		for field in order_config_fields:
			if convert.get(field):
				post_data['order']['buyer_accepts_marketing'] = True
		if not keep_order and order_number and not self._state.channel.config.api.order_remove_tags:
			tags.append(to_str(order_number)[:40])
		if convert.tags:
			order_tags = to_str(convert.tags).split(',')
			tags.extend(order_tags)
		if not self._state.channel.config.api.skip_order_tags:
			post_data['order']['tags'] = ','.join(tags)
		if post_data['order']['financial_status'] == 'paid' and post_data['order']['total_price'] > 0:
			post_data['order']['transactions'] = [
				{
					'amount': round(to_decimal(post_data['order']['total_price']), 2),
					'kind': 'sale',
					'test': False,
					'status': 'success'
				}
			]

		if convert.discount.amount and (abs(to_decimal(convert.discount.amount)) > 0):
			post_data['order']['discount_codes'] = list()
			discount_code = dict()
			post_data['order']['total_discounts'] = round(abs(to_decimal(convert.discount.amount)), 2)
			discount_code_title = 'dc'
			if convert.discount.code:
				discount_code_title = convert.discount.code
			elif convert.discount.title:
				discount_code_title = convert.discount.title
			discount_code['code'] = discount_code_title
			discount_code['amount'] = round(abs(to_decimal(convert.discount.amount)), 2)
			discount_code['type'] = ''
			post_data['order']['discount_codes'].append(discount_code)

		if convert.tax.amount and to_decimal(convert.tax.amount) > 0:
			post_data['order']['total_tax'] = round(to_decimal(convert.tax.amount), 2)
			total_ex_tax = to_decimal(convert.total) - to_decimal(convert.tax.amount)
			rate = 0
			if total_ex_tax > 0:
				rate = round(to_decimal(convert.tax.amount) / total_ex_tax, 2)
			elif to_decimal(convert.total) > 0:
				rate = round(to_decimal(convert.tax.amount) / to_decimal(convert.total), 2)
			post_data['order']['tax_lines'] = [{
				'rate': rate,
				'title': 'VAT' if self.import_order_vat_title() else 'TAX',
				'price': round(to_decimal(convert.tax.amount), 2)
			}]
			if to_decimal((
				to_decimal(convert.subtotal) + to_decimal(convert.tax.amount)
				+ to_decimal(convert.shipping.amount) - to_decimal(convert.discount.amount)
			), 2) > to_decimal(convert.total, 2):
				post_data['order']['taxes_included'] = True
		shipping_method = convert.shipping.title or convert.shipping.method
		if self._state.channel.config.api.custom_shipping_method:
			shipping_method = self._state.channel.config.api.custom_shipping_method
		shipping_method = shipping_method or 'Standard'
		shipping_amount = to_decimal(convert.shipping.amount)
		if convert.handling_cost:
			shipping_amount += to_decimal(convert.handling_cost)
		if shipping_amount > 0:
			post_data['order']['shipping_lines'] = list()
			ship_lines = dict()
			ship_lines['price'] = shipping_amount
			ship_lines['title'] = shipping_method
			ship_lines['code'] = shipping_method
			post_data['order']['shipping_lines'].append(ship_lines)
		else:
			post_data['order']['shipping_lines'] = list()
			ship_lines = dict()
			ship_lines['price'] = 0
			ship_lines['title'] = shipping_method
			ship_lines['code'] = shipping_method
			post_data['order']['shipping_lines'].append(ship_lines)
		customer_email = convert.customer.email
		first_name = remove_emojis(convert.customer.first_name or convert.billing_address.first_name or convert.shipping_address.first_name, convert.remove_emoji)
		last_name = remove_emojis(convert.customer.last_name or convert.billing_address.last_name or convert.shipping_address.last_name, convert.remove_emoji)
		if not customer_email:
			customer_email = f'{first_name}_{last_name}@shopify.com'
		if convert.custom_order_email:
			customer_email = convert.custom_order_email
		customer_data = {
			'first_name': remove_emojis(convert.customer.first_name or convert.billing_address.first_name or convert.shipping_address.first_name, convert.remove_emoji),
			'last_name': remove_emojis(convert.customer.last_name or convert.billing_address.last_name or convert.shipping_address.last_name, convert.remove_emoji),
			'email': re.sub("gmail.com.+", 'gmail.com', customer_email),
			# 'total_spent': round(to_decimal(convert.total), 2),
		}
		try:
			channel_setting_api = self.get_channel_api(convert.channel_id)
			if channel_setting_api and channel_setting_api.get('skip_order_email'):
				del customer_data['email']
		except:
			self.log_traceback()
		if self._state.channel.config.api.add_tags_to_customer:
			customer_data['tags'] = convert.channel_type
		if convert.custom_customer_id:
			customer_data = {
				'id': convert.custom_customer_id
			}
		post_data['order']['customer'] = customer_data
		billstate_code = {
			'name': None,
			'code': None,
		}
		billing_address = convert.custom_billing_address or convert.billing_address
		if billing_address.state.state_name or billing_address.state.state_code:
			billstate_code = self.get_province_from_country(billing_address.country.country_code, billing_address.state.state_name, billing_address.state.state_code)
		billing_address_2 = []
		if billing_address.address_2:
			billing_address_2.append(billing_address.address_2)
		if self.country_is_no_state(billing_address.country) and (billing_address.state.state_name or billing_address.state.state_code):
			billing_address_2.append(billing_address.state.state_name or billing_address.state.state_code)
		billing_data = {
			'first_name': remove_emojis(billing_address.first_name or '', convert.remove_emoji),
			'last_name': remove_emojis(billing_address.last_name or '', convert.remove_emoji),
			'address1': billing_address.address_1 or '',
			'address2': '\n'.join(billing_address_2),
			'city': billing_address.city or 'City',
			'province': billing_address.state.state_name or billstate_code['name'],
			'country': billing_address.country.country_name or '',
			'province_code': billing_address.state.state_code or billstate_code['code'],
			'country_code': billing_address.country.country_code or '',
			'zip': billing_address.postcode or '',
			'phone': billing_address.telephone or '',
			'name': remove_emojis(' '.join([billing_address.first_name or '', billing_address.last_name or '']), convert.remove_emoji),
			'latitude': None,
			'longitude': None,
			'company': billing_address.company or '',
		}

		shipstate_code = {
			'name': None,
			'code': None,
		}
		if convert.shipping_address.state.state_name or convert.shipping_address.state.state_code:
			shipstate_code = self.get_province_from_country(convert.shipping_address.country.country_code, convert.shipping_address.state.state_name, convert.shipping_address.state.state_code)
		first_name = remove_emojis(convert.shipping_address.first_name or '', convert.remove_emoji)
		last_name = remove_emojis(convert.shipping_address.last_name or '', convert.remove_emoji)
		names = []
		if first_name:
			names.append(first_name)
		if last_name:
			names.append(last_name)

		shipping_address_2 = []
		if convert.shipping_address.address_2:
			shipping_address_2.append(convert.shipping_address.address_2)
		try:
			if self.country_is_no_state(convert.shipping_address.country) and (convert.shipping_address.state.state_name or convert.shipping_address.state.state_code):
				shipping_address_2.append(convert.shipping_address.state.state_name or convert.shipping_address.state.state_code)
			if convert.additional_details:
				for row in convert.additional_details:
					if row.name == 'ShipToReferenceId':
						shipping_address_2.append(f'RefId: #{row.value}')

		except:
			self.log_traceback()
		shipping_data = {
			'first_name': first_name,
			'last_name': last_name,
			'address1': convert.shipping_address.address_1 or '',
			'address2': '\n'.join(shipping_address_2),
			'city': convert.shipping_address.city or 'City',
			'province': convert.shipping_address.state.state_name or shipstate_code['name'],
			'country': convert.shipping_address.country.country_name or '',
			'province_code': convert.shipping_address.state.state_code or billstate_code['code'],
			'country_code': convert.shipping_address.country.country_code or '',
			'zip': convert.shipping_address.postcode or '',
			'phone': convert.shipping_address.telephone or '',
			'name': ' '.join(names),
			'latitude': None,
			'longitude': None,
			'company': convert.shipping_address.company or '',
		}
		post_data['order']['billing_address'] = billing_data
		post_data['order']['shipping_address'] = shipping_data
		comment = ''
		for history in convert.history:
			if history.staff_note:
				continue
			if history['comment']:
				comment += self.clear_tags(to_str(history['comment']).replace('<br />', '\n'))
		post_data['order']['note'] = comment[:5000]

		order_items = list()
		for index, row in enumerate(convert.products):
			product_id = None
			variant_id = None
			if row['product_id'] and row['parent_id']:
				variant_id = row['product_id']
				product_id = row['parent_id']
			else:
				product_id = row['product_id']
				if product_id:
					product_info = self.api('products/' + to_str(product_id) + '.json')
					if product_info:
						if isinstance(product_info, dict) and product_info.get('product'):
							if to_len(product_info['product']['variants']) > 1 and not self._state.channel.config.api.order_variant_default:
								msg = Errors().get_msg_error(Errors.SHOPIFY_NOT_FOUND_VARIANT_DEFAULT)
								identifier = row.get('product_sku') or row.get('product_name')
								error = f"Item {identifier}: {msg}"
								return Response().error(msg = error)

							variant_id = product_info['product']['variants'][0]['id']
							if row['product'].get('sku'):
								for variant in product_info['product']['variants']:
									if row['product'].get('sku') == variant['sku']:
										variant_id = variant['id']
										break
			row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1
			# if convert.status != Order.CANCELED:
			# 	variant = self.api(f'variants/{variant_id}.json')
			# 	if variant.get('variant'):
			# 		inventory_quantity = to_int(variant['variant']['inventory_quantity'])
			# 		if inventory_quantity < to_int(row_qty):
			# 			return Response().error(msg = f"Product {row.product_sku} out of stock")
			# 		ivt_data = {
			# 			'location_id': self.get_location_id(),
			# 			'inventory_item_id': variant['variant']['inventory_item_id'],
			# 			'available': to_int(inventory_quantity) - to_int(row_qty)
			# 		}
			# 		inventory = self.api('inventory_levels/set.json', ivt_data, 'Post')
			if (not variant_id or not product_id) and not self.is_setting_import_order_unlink(convert.channel_id):
				return Response().error(code = Errors.SHOPIFY_ORDER_ITEM_NOT_LINK)

			item = {
				'variant_id': variant_id or None,
				'title': to_str(row.product_name)[0:255],
				'price': to_decimal(row.price, 2),
				'quantity': row_qty,
				'sku': to_str(row.product_sku),
				'product_id': product_id or None,
				'total_discount': round(to_decimal(row.discount_amount), 2),
				'variant_title': None,
				'name': to_str(row.product_name)[0:255],
				'properties': [],
				# 'grams': to_int(row['product']['weight'] if row['product'] else 0)
			}
			if not index and convert.gift_wrap_price:
				item['price'] += to_decimal(convert.gift_wrap_price, 2)
			if row.options:
				for option in row.options:
					item['properties'].append({
						'name': option.option_name,
						'value': option.option_value_name
					})
			order_items.append(item)
		if not order_items or len(order_items) == 0:
			return Response().error(code = Errors.SHOPIFY_ORDER_NO_ITEM)
		post_data['order']['line_items'] = order_items
		note_attributes = [
			{'name': 'Channel', 'value': convert.channel_name},
			{'name': 'Order Number', 'value': convert.channel_order_number},
		]
		if convert.additional_details:
			for row in convert.additional_details:
				note_attributes.append({'name': row.name, 'value': row.value})
		if convert.payment.method:
			note_attributes.append({'name': 'Payment Method', 'value': f"Paid via {channel_type.capitalize()} with {convert.payment.method}"})
		if convert.customer.username:
			note_attributes.append({'name': 'Buyer Username', 'value': convert.customer.username})

		post_data['order']['note_attributes'] = note_attributes
		response = self.api('orders.json', post_data, 'Post')
		# response = json_decode(response)
		if response and response.errors and response.errors.get('line_items'):
			for error in response.errors.get('line_items'):
				if 'Unable to reserve inventory' in error:
					return Response().error(Errors.SHOPIFY_ORDER_ITEM_OUT_STOCK)
		retry = 5
		while retry > 0 and response and response.get('errors'):
			retry -= 1
			is_retry = False
			if response['errors'].get('order'):
				# retry if error Phone is invalid
				if response['errors']['order'] and 'Phone is invalid' in response['errors']['order']:
					del post_data['order']['phone']
					del post_data['order']['billing_address']['phone']
					del post_data['order']['shipping_address']['phone']
					is_retry = True
			if (response['errors'].get('customer') and response['errors']['customer'][0] in ['Email contains an invalid domain name', 'Email is invalid']) or response['errors'].get('customer.email_address'):
				# retry if error Email contains an invalid domain name
				cust_email = post_data['order']['customer'].get('email')
				# replace special characters
				cust_email = re.sub('[^A-Za-z0-9]+', '', to_str(cust_email))
				# convert into @gmail.com
				cust_email = cust_email + "@shopify.com"
				is_retry = True

				self.log("Retry with " + post_data['order']['customer'].get('email') + " = " + cust_email, "orders_errors")
				post_data['order']['customer']["email"] = cust_email

			if 'Exceeded  API rate limit, please try again in a minute.' in response['errors']:
				is_retry = True

				time.sleep(60)
			# call api again
			if is_retry:
				response = self.api('orders.json', post_data, 'Post')
			else:
				break
		check_response = self.check_response_import(response, convert, 'order')
		if check_response.result != Response.SUCCESS:
			if 'cannot contain emojis' in to_str(response) and not convert.remove_emoji:
				convert['remove_emoji'] = True
				return self.order_import(order, convert, orders_ext)
			return check_response
		order_id = response['order']['id']

		order_return = {
			'order_id': response['order']['id'],
			'order_status': response['order']['financial_status'],
			'order_number': response['order']['order_number'],
			'created_at': response['order']['created_at'],
		}
		try:
			self.move_order_to_location(response['order'], convert)
		except Exception as e:
			self.log_traceback()
		return Response().success([order_id, order_return])


	def move_order_to_location(self, shopify_order, order: Order):
		order_id = shopify_order['id']
		settings = self.get_channel_setting(order.channel_id)
		if not settings or not settings.get('qty') or not settings['qty'].get('locations'):
			return False
		location_setting = list(map(lambda x: to_int(x['location_id']), settings['qty'].get('locations')))
		# warehouse_locations_mapping = settings['qty'].get("warehouse_locations_mapping")
		# if warehouse_locations_mapping:
		# 	location_ids = [mapping["main"]["location_id"] for mapping in warehouse_locations_mapping]
		# 	location_setting = [to_int(location_id) for location_id in location_ids]
		fulfillment_orders = self.api(f"orders/{order_id}/fulfillment_orders.json")
		move_locations = {}
		for fulfillment_order in fulfillment_orders['fulfillment_orders']:
			if to_int(fulfillment_order['assigned_location_id']) in location_setting:
				continue
			for product in fulfillment_order['line_items']:
				inventory_item_id = product['inventory_item_id']
				inventory_levels = self.api(f'inventory_levels.json', data = {'inventory_item_ids': inventory_item_id})
				location_inventory_levels = list(filter(lambda x: to_int(x['inventory_item_id']) == to_int(inventory_item_id) and x['location_id'] in location_setting, inventory_levels['inventory_levels']))
				location_inventory_levels.sort(key = lambda x: x['available'], reverse = True)
				available_qty = product['fulfillable_quantity']
				for inventory_level in location_inventory_levels:
					if not available_qty:
						break
					move_qty = available_qty if available_qty <= inventory_level['available'] else inventory_level['available']
					available_qty -= move_qty
					move_data = {
						"fulfillment_order": {
							"new_location_id": inventory_level['location_id'],
							"fulfillment_order_line_items": [
								{
									"id": product["id"],
									"quantity": move_qty
								}
							]
						}
					}
					move = self.api(f'fulfillment_orders/{fulfillment_order["id"]}/move.json', move_data, api_type = 'post')


	def country_is_no_state(self, country: OrderAddressCountry):
		return country.country_code and country.country_code in ['UK', 'GB']


	def is_buyer_accepts_marketing(self, order: Order):
		return self._state.channel.config.buyer_accepts_marketing or order.buyer_accepts_marketing


	def channel_order_canceled(self, order_id, order: Order, current_order):
		shopify_order_req = self.get_order_by_id(order_id)
		if shopify_order_req.result != Response.SUCCESS:
			return Response().success()
		shopify_order = shopify_order_req.data
		if shopify_order.cancelled_at:
			return Response().success()

		if shopify_order.fulfillment_status == 'fulfilled':
			fulfillments = self.api(f"orders/{order_id}/fulfillments.json")
			if self._last_status < 300:
				for fulfillment in fulfillments['fulfillments']:
					self.api(f"fulfillments/{fulfillment['id']}/cancel.json", api_type = 'post')
		data = {"reason": "other", "email": False}
		if shopify_order.financial_status == 'paid':
			data['amount'] = shopify_order.total_price
		order_canceled = self.api(f"orders/{order_id}/cancel.json", data, api_type = 'post')
		if self._last_status < 300:
			return_order = {
				"status": 'CANCELLED',
			}

			return Response().success(return_order)
		return Response().success()


	def is_notify_customer(self):
		return to_bool(self._state.channel.config.api.fulfillment_notify_customer)


	def channel_order_completed(self, order_id, order: Order, current_order):
		try:
			self._file_log = 'order_completed'
			shopify_order_req = self.get_order_by_id(order_id)
			if shopify_order_req.result != Response.SUCCESS:
				return Response().success()
			shopify_order = shopify_order_req.data
			if shopify_order.fulfillment_status != 'fulfilled':
				fulfillment_orders = self.api(f"orders/{order_id}/fulfillment_orders.json")
				if self._last_status != 200 or not fulfillment_orders['fulfillment_orders']:
					return Response().success()
				fulfillment_order = fulfillment_orders['fulfillment_orders'][0]
				tracking_company = TrackingCompany(order.shipments.tracking_company_code, order.shipments.tracking_company, channel_type = 'shopify')
				fulfillment_order_line_items = list()
				for item in fulfillment_order['line_items']:
					fulfillment_order_line_items.append({
						"id": item.id,
						"quantity": item.quantity
					})
				fulfillment_order_data = {
					"fulfillment": {
						"notify_customer": self.is_notify_customer(),
						"tracking_info": {
							"number": order.shipments.tracking_number,
							"url": order.shipments.tracking_url,
							"company": tracking_company.get_name()
						},
						"line_items_by_fulfillment_order": [
							{
								"fulfillment_order_id": fulfillment_order.id,
								"fulfillment_order_line_items": fulfillment_order_line_items
							}
						]
					}
				}

				fulffiments = self.api(f'fulfillments.json', fulfillment_order_data, api_type = 'post')
			if shopify_order.financial_status != 'paid':
				transaction_data = {
					"transaction": {
						"amount": order.total,
						"kind": "capture",
						"source": "external"
					}
				}
				transactions = self.api(f'orders/{order_id}/transactions.json', transaction_data, api_type = 'post')
		except:
			self.log_traceback()
			return Response().error()
		return_order = {
			"status": 'FULFILLED',
		}
		self._file_log = None
		return Response().success(return_order)


	def convert_order_status(self, status):
		order_status = {
			"pending": Order.OPEN,
			"partially_refunded": Order.OPEN,
			"authorized": Order.AWAITING_PAYMENT,
			"partially_paid": Order.SHIPPING,
			"paid": Order.COMPLETED,
			"voided": Order.CANCELED,
			"refunded": Order.CANCELED,
			Order.CANCELED: Order.CANCELED,

		}
		return order_status.get(status, 'open') if status else 'open'


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.updated_at)
		order_data = Order()
		order_data.id = order.id
		order_data.order_number = order.name
		order_data.fulfillment_status = order.fulfillment_status
		if order.cancelled_at:
			order.financial_status = Order.CANCELED
		if order.fulfillment_status == 'fulfilled' and order.fulfillments:
			order_data.status = Order.COMPLETED
		else:
			if order.financial_status == 'paid':
				order_data.status = Order.SHIPPING
			else:
				order_data.status = self.convert_order_status(order.financial_status)

		order_data.tax.amount = to_decimal(order.total_tax)
		order_data.discount.amount = to_decimal(order.total_discounts)
		if order.discount_codes:
			order_data.discount.code = order['discount_codes'][0]['code']
			order_data.discount.title = order['discount_codes'][0]['code']
		if order.shipping_lines:
			order_data.shipping.title = order['shipping_lines'][0]['title']
			order_data.shipping.amount = order['shipping_lines'][0]['price']
		order_data.subtotal = order.subtotal_price
		order_data.total = order.total_price
		order_data.currency = order.currency
		order_data.tags = order.tags
		order_data.created_at = self.iso_format_datetime_to_format(order.created_at)
		order_data.updated_at = self.iso_format_datetime_to_format(order.updated_at)
		order_data.channel_data = {
			'order_status': order.financial_status if order_data.status != Order.COMPLETED else 'fulfilled',
			'created_at': order_data.created_at,
			'order_number': order.name,
		}
		if order.fulfillments:
			for index, fulfillment in enumerate(order.fulfillments):
				shipment_data = Shipment()
				shipment_data.tracking_number = fulfillment.tracking_number
				shipment_data.tracking_url = to_str(fulfillment.tracking_url).replace('[{track}]', to_str(fulfillment.tracking_number))
				shipment_data.tracking_company = fulfillment.tracking_company
				shipment_data.tracking_company_code = fulfillment.tracking_company
				shipment_data.shipped_at = convert_format_time(fulfillment.created_at, '%Y-%m-%dT%H:%M:%S')
				for item in fulfillment['line_items']:
					order_shipment_item = OrderShipmentItem()
					order_shipment_item.product_id = item['product_id']
					order_shipment_item.qty = item['quantity']
					shipment_data.line_items.append(order_shipment_item)
				if not index:
					order_data.shipments.update(shipment_data)

				if to_len(order.fulfillments) > 1:
					order_data.line_shipments.append(shipment_data)

		email = order.email or order.contact_email
		address = OrderAddress()
		if order.shipping_address:
			# order_data.shipping_address.id = order.customer.shipping_address.id
			address.first_name = order.shipping_address.first_name
			address.last_name = order.shipping_address.last_name
			address.address_1 = order.shipping_address.address1
			address.address_2 = order.shipping_address.address2
			address.city = order.shipping_address.city
			address.country.country_name = order.shipping_address.country
			address.country.country_code = order.shipping_address.country_code
			address.state.state_name = order.shipping_address.province
			address.state.state_code = order.shipping_address.province_code
			address.postcode = order.shipping_address.zip
			address.telephone = order.shipping_address.phone
			address.company = order.shipping_address.company
			order_data.shipping_address.update(address)
		if order.customer:
			order_data.customer.id = order.customer.id
			order_data.customer.email = order.customer.email or email
			order_data.customer.first_name = order.customer.first_name
			order_data.customer.last_name = order.customer.last_name
			if order.customer.default_address:
				order_data.customer_address.id = order.customer.default_address.id
				order_data.customer_address.first_name = order.customer.default_address.first_name
				order_data.customer_address.last_name = order.customer.default_address.last_name
				order_data.customer_address.address_1 = order.customer.default_address.address1
				order_data.customer_address.address_2 = order.customer.default_address.address2
				order_data.customer_address.city = order.customer.default_address.city
				order_data.customer_address.country.country_name = order.customer.default_address.country
				order_data.customer_address.country.country_code = order.customer.default_address.country_code
				order_data.customer_address.state.state_name = order.customer.default_address.province
				order_data.customer_address.state.state_code = order.customer.default_address.province_code
				order_data.customer_address.postcode = order.customer.default_address.zip
				order_data.customer_address.telephone = order.customer.default_address.phone
				order_data.customer_address.company = order.customer.default_address.company
			if order.customer.note:
				order_history = OrderHistory()
				order_history.comment = order.customer.note
		else:
			order_data.customer.email = email
			order_data.customer.first_name = address.first_name
			order_data.customer.last_name = address.last_name
			order_data.customer_address.update(address)
		if order.billing_address:
			# order_data.billing_address.id = order.customer.billing_address.id
			order_data.billing_address.first_name = order.billing_address.first_name
			order_data.billing_address.last_name = order.billing_address.last_name
			order_data.billing_address.address_1 = order.billing_address.address1
			order_data.billing_address.address_2 = order.billing_address.address2
			order_data.billing_address.city = order.billing_address.city
			order_data.billing_address.country.country_name = order.billing_address.country
			order_data.billing_address.country.country_code = order.billing_address.country_code
			order_data.billing_address.state.state_name = order.billing_address.province
			order_data.billing_address.state.state_code = order.billing_address.province_code
			order_data.billing_address.postcode = order.billing_address.zip
			order_data.billing_address.telephone = order.billing_address.phone
			order_data.billing_address.company = order.billing_address.company
		else:
			order_data.billing_address.update(address)
		if not order.shipping_address:
			order_data.shipping_address.update(order_data.billing_address)
		if order.payment_gateway_names:
			order_data.payment.title = order['payment_gateway_names'][0]
			order_data.payment.method = order['payment_gateway_names'][0]
		for item in order.line_items:
			order_item = OrderProducts()
			order_item.id = item.id
			sub_total = 0
			product_id = None
			if item.product_id:
				count_variant = self.api(f'products/{item.product_id}/variants/count.json')
				if count_variant and to_int(count_variant.get('count')) > 1:
					product_id = item.variant_id
					order_item.is_variant = True

				else:
					product_id = item.product_id
			order_item.product_id = product_id
			order_item.listing_id = item.product_id
			order_item.product_name = item.title
			order_item.sku = item.sku
			order_item.qty = item.quantity
			order_item.price = item.price
			order_item.total = to_decimal(to_decimal(item.price, 2) * to_int(item.quantity), 2)
			order_item.original_price = to_decimal(item.price, 2)
			if item.tax_lines:
				tax_amount = tax_percent = 0
				for row in item.tax_lines:
					tax_amount += to_decimal(row.price)
					tax_percent += to_decimal(row.rate)

				order_item.tax_amount = tax_amount
			order_item.discount_amount = item.total_discount
			order_item.subtotal = to_decimal(order_item.total + to_decimal(item.total_discount, 2) - order_item.tax_amount, 2)
			if item.properties:
				for custom_option in item['properties']:
					order_item_option = OrderItemOption()
					order_item_option.option_name = custom_option.name
					order_item_option.option_value_name = custom_option.value
					order_item.options.append(order_item_option)
			order_data.products.append(order_item)
		if order.get('note'):
			history = OrderHistory()
			history.comment = order['note']
			order_data.history.append(history)
		return Response().success(order_data)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	# if self._state['config']['img_des'] and post_data['product']['body_html']:
	# 	theme_data = self.get_theme_data()
	# 	if theme_data:
	# 		check = False
	# 		description = post_data['product']['body_html']
	# 		match = re.findall(r"<img[^>]+>", to_str(description))
	# 		links = list()
	# 		if match:
	# 			for img in match:
	# 				img_src = re.findall(r"(src=[\"'](.*?)[\"'])", to_str(img))
	# 				if not img_src:
	# 					continue
	# 				img_src = img_src[0]
	# 				if img_src[1] in links:
	# 					continue
	# 				links.append(img_src[1])
	# 		for link in links:
	# 			# download and replace
	# 			if self._state['src']['config'].get('auth'):
	# 				link = self.join_url_auth(link)
	# 			if to_int(theme_data['count']) >= 1500:
	# 				theme_data = self.get_theme_data(True)
	# 			if not theme_data:
	# 				break
	# 			if not self.image_exist(link):
	# 				continue
	# 			asset_post = self.process_assets_before_import(url_image = link, path = '', id_theme = theme_data['id'], name_image = convert['code'])
	# 			asset_post = json_decode(asset_post)
	# 			if asset_post and asset_post.get('asset'):
	# 				self.update_theme_data(theme_data['count'])
	# 				check = True
	# 				description = to_str(description).replace(link, asset_post['asset']['public_url'])
	# 		if check:
	# 			product_update = {
	# 				'product': {
	# 					'body_html': description
	# 				}
	# 			}
	# 			res = self.api('products/' + to_str(product_id) + '.json', product_update, 'PUT')

	def get_sizes(self, url):
		req = Request(url, headers = {'User-Agent': get_random_useragent()})
		try:
			file = urlopen(req)
		except:
			self.log('image: ' + to_str(url) + ' 404', 'image_error')
			return False, False
		size = file.headers.get("content-length")
		# date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
		# type = file.headers.get('content-type')
		if size: size = to_int(size)
		p = ImageFile.Parser()
		while 1:
			data = file.read(1024)
			if not data:
				break
			p.feed(data)
			if p.image:
				return size, p.image.size
		file.close()
		return size, False


	def resize_image(self, url):
		name = os.path.basename(url)
		result = dict()
		result['filename'] = name
		result['attachment'] = ''
		try:
			image_size, wh = self.get_sizes(url)
			w = 4000
			h = 4000
			if wh:
				w = wh[0]
				h = wh[1]
				if to_decimal(to_decimal(w) * to_decimal(h), 2) > to_decimal(4000 * 4000, 2):
					if to_decimal(w) > to_decimal(h):
						h = 4000 * h / w
						w = 4000
					else:
						w = 4000 * w / h
						h = 4000
				else:
					return None
			time.sleep(0.4)
			r = requests.get(url)
			if r.status_code != 200:
				return result
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			new_width = to_int(w)
			new_height = to_int(h)
			img = img.resize((new_width, new_height), Image.ANTIALIAS)
			output = io.BytesIO()
			if img.mode != 'RGB':
				img = img.convert('RGB')
			img.save(output, format = 'JPEG')
			im_data = output.getvalue()
			image_data = base64.b64encode(im_data)
			if not isinstance(image_data, str):
				# Python 3, decode from bytes to string
				image_data = image_data.decode()
				result['attachment'] = image_data
				return result
		except Exception as e:
			self.log(url, 'url_fail')
			self.log_traceback("url_fail")
		return None


	def check_response_import(self, response, convert, entity_type = ''):
		entity_id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '_lic_nl_'.join(console)
			self.log(entity_type + ' id ' + to_str(entity_id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error(msg = msg_errors)

		else:
			return Response().success()


	def validate_channel_url(self):
		parent = super().validate_channel_url()
		if parent.result != Response.SUCCESS:
			return parent
		return self.validate_shopify_url(self._channel_url)


	def validate_shopify_url(self, cart_url):
		shopify_code = re.findall("https://(.*).myshopify.com", cart_url)
		if not shopify_code:
			return Response().error(Errors.SHOPIFY_URL_INVALID)
		return Response().success()


	def format_url(self, url, **kwargs):
		url = super().format_url(url, **kwargs)
		url.strip('[]')
		url_parse = urllib.parse.urlparse(url)
		url = "https://" + url_parse.hostname
		validate = self.validate_shopify_url(url)
		if validate['result'] != 'success':
			detect = self.detect_shopify_url(url)
			if detect['result'] == 'success':
				url = detect['data']
		return url


	def detect_shopify_url(self, url):
		shopify_code = re.findall("https://admin.shopify.com/store/(.*)", url)
		if shopify_code:
			shopify_code = shopify_code[0].split('/')[0]
			return Response().success(f"https://{shopify_code}.myshopify.com")

		url_admin = url + "/admin"
		try:
			response = requests.get(url_admin, allow_redirects = False)
			if response.status_code == 302:
				redirect_url = response.headers.get('location')
				redirect_url = redirect_url.replace('/admin', '')
				validate = self.validate_shopify_url(redirect_url)
				if validate.result == Response.SUCCESS:
					return Response().success(redirect_url)
		except Exception as e:
			pass
		return Response().error()


	def get_shopify_countries(self):
		if self._shopify_countries:
			return self._shopify_countries
		countries_js = self.requests('https://www.shopify.com/services/countries.json', None, {"Content-Type": "application/json"})
		if not countries_js:
			return dict()
		self._shopify_countries = json_decode(countries_js)
		return self._shopify_countries


	def get_province_from_country(self, country_code, province_name = None, province_code = None):
		result = {
			'name': '',
			'code': ''
		}
		countries_data = self.get_shopify_countries()
		if countries_data:
			for country in countries_data:
				if country['code'] != country_code:
					continue
				country_provinces = list()
				if 'provinces' in country:
					country_provinces = country['provinces']
				if province_name or province_code:
					for p in country_provinces:
						if (to_str(province_name) and (to_str(province_name).lower() in to_str(p['name']).lower() or to_str(p['name']).lower() in to_str(province_name).lower())) or (to_str(province_code) and to_str(province_code).lower() == to_str(p['code']).lower()):
							result = p
							break
				if not result['code'] and country_provinces:
					result = {
			'name': province_name,
			'code': province_code
		}
				break
		return result


	def check_country_code(self, country_code):
		result = False
		countries_data = self.get_shopify_countries()
		if countries_data:
			for country in countries_data:
				if country['code'] == country_code:
					return True
		return result


	def py_reset(self, tmp):
		return tmp[0]


	def clear_tags(self, text_src):
		tag_re = re.compile(r'<[^>]+>')
		return tag_re.sub('', to_str(text_src))


	def get_location_id(self):
		if self._state.channel.config.api.location_id:
			return self._state.channel.config.api.location_id
		if self._location_id:
			return self._location_id
		location = self.api('locations.json')
		try:
			for location_data in location['locations']:
				if location_data['active'] and not location_data.get('legacy'):
					self._location_id = location_data['id']
			if not self._location_id:
				self._location_id = location['locations'][0]['id']
		except Exception as e:
			self.log_traceback()
			self._location_id = None
		return self._location_id


	def get_smart_collection_by_name(self, category_name):
		smart_exist = self.api('smart_collections.json', {'title': category_name, 'limit': 1})
		if smart_exist and smart_exist.smart_collections:
			return smart_exist.smart_collections[0].id
		post_data = {
			'smart_collection': {
				'title': category_name,
				'published': True,
				'disjunctive': True,
				'rules': [
					{
						'column': 'tag',
						'relation': 'equals',
						'condition': category_name.replace(',', '')
					}
				]
			}
		}
		response = self.api('smart_collections.json', post_data, 'Post')
		response = json_decode(response)
		if response and response.smart_collection:
			return smart_exist.smart_collection.id
		return False


	def to_shopify_price(self, product: Product):
		special_price = product.special_price
		price = product.price
		compare_price = None
		if self.is_special_price(product):
			sale_price = special_price.price
			compare_price = price if price and to_decimal(price) > to_decimal(sale_price) else None
		else:
			if product.msrp and to_decimal(product.msrp) > to_decimal(price):
				compare_price = product.msrp
				sale_price = price
			else:
				sale_price = price
		return round(to_decimal(compare_price), 2), round(to_decimal(sale_price), 2)


	def get_draft_extend_channel_data(self, product):
		extend_data = dict()
		description = nl2br(product.description)
		if description != product.description:
			extend_data['description'] = description
		return extend_data


	def is_import_outstock(self):
		return self.is_refresh_process() or not self._state.channel.config.api.skip_out_of_stock


	def get_shopify_metafield_definitions(self):
		if isinstance(self._metafields_definitions, dict):
			return self._metafields_definitions
		self._metafields_definitions = dict()
		query = '''query MyQuery {
  metafieldDefinitions(ownerType: PRODUCT, first: 100, namespace: "global") {
    nodes {
      key
      type {
        valueType
        name
      }
    }
  }
}
'''
		definitions_response = self.graphql_api(query)
		if definitions_response.result == Response.SUCCESS:
			try:
				metafield_definitions = definitions_response.data.data.metafieldDefinitions.nodes
			except:
				metafield_definitions = []
			for metafield_definition in metafield_definitions:
				self._metafields_definitions[metafield_definition['key']] = metafield_definition.type.name
		return self._metafields_definitions


	def graphql_api(self, query, variables = None, retry = 0):
		data = {
			'query': query
		}
		if variables:
			data['variables'] = variables
		url = f"https://{self._state.channel.config.api.shop}.myshopify.com/admin/api/{self.get_version_api()}/graphql.json"
		headers = {
			'X-Shopify-Access-Token': self._state.channel.config.api.password,
		}
		response = requests.request('POST', url, json = data, headers = headers)
		if response.status_code == 404:
			return Response().error()
		try:
			response_data = response.json()
			response_data = Prodict.from_dict(response_data)

		except:
			self.log_traceback()
			response_data = False
		if response_data and (response_data.get('errors') or self.is_log()):
			self.log_request_error(url, log_type = 'graphql', data = data, response = response.text)
		if not response_data or response_data.get('errors'):
			self.log_request_error(url, log_type = 'graphql', data = data, response = response.text)
			is_retry = False
			if not response_data:
				is_retry = True
			else:
				errors = response_data['errors']
				for row in errors:
					if row.message == 'Throttled':
						is_retry = True
			if is_retry and retry <= 10:
				retry += 1
				time.sleep(retry * 1)
				return self.graphql_api(query, variables, retry)
			return Response().error()
		return Response().success(response_data)


	def display_finish_channel_pull(self):
		super(ModelChannelsShopify, self).display_finish_channel_pull()
		if is_local():
			return Response().success()
		if self.is_refresh_process():
			webhook = self.api('webhooks.json')
			verify = {
				'order': False,
				'product': False,
				'app': False
			}
			if webhook and webhook.get('webhooks'):
				for hook in webhook['webhooks']:
					if hook['address'].find(f'api/v1/merchant/shopify/webhook/{self.get_channel_id()}/order/update') != -1 and hook['topic'] == 'orders/updated':
						verify['order'] = True
					if hook['address'].find(f'api/v1/merchant/shopify/webhook/{self.get_channel_id()}/product/delete') != -1 and hook['topic'] == 'products/delete':
						verify['product'] = True
					if hook['address'].find(f'merchant/shopify/webhook/{self.get_channel_id()}/app/uninstalled') != -1 and hook['topic'] == 'app/uninstalled':
						verify['app'] = True
			events = dict()

			if not verify['order']:
				events[f"orders/updated"] = f'order/update'
			if not verify['product']:
				events["products/delete"] = 'product/delete'
			if not verify['app']:
				events["app/uninstalled"] = 'app/uninstalled'
			if not events:
				return Response().success()
			for event, url in events.items():
				address = get_server_callback(f'merchant/shopify/webhook/{self.get_channel_id()}/{url}')
				if event == 'app/uninstalled':
					address = get_api_server_url(f'merchant/shopify/webhook/{self.get_channel_id()}/{url}')
				if not self._state.channel.config.api.app_id:
					address += f"?password=ay8PRsxHHHzQL9TG"
				webhook_data = {
					"webhook": {
						"topic": event,
						"address": address,
						"format": "json"
					}
				}
				webhook = self.api('webhooks.json', webhook_data, 'post')
		return Response().success()


	def get_sale_channel(self):
		if self._sale_channel_id is not None:
			return self._sale_channel_id
		if self._state.channel.config.api.sale_channel:
			self._sale_channel_id = self._state.channel.config.api.sale_channel
			return self._state.channel.config.api.sale_channel
		query = '''query MyQuery {
  channels(first: 100) {
    nodes {
      handle
      id
      name
    }
  }
}
		'''
		sale_channels_response = self.graphql_api(query)
		if sale_channels_response.result == Response.SUCCESS:
			try:
				sale_channels = sale_channels_response.data.data.channels.nodes
			except:
				sale_channels = []
			sale_channels = list(filter(lambda x: x['handle'] == 'marketplaces-integration', sale_channels))
			sale_channel_id = list(map(lambda x: to_str(x['id']).split('/')[-1], sale_channels))[0]
			self._state.channel.config.api.sale_channel = sale_channel_id
			self.update_channel(api = json_encode(self._state.channel.config.api))
			return sale_channel_id
		return False


	def assign_product_to_sale_channel(self, product_id):
		try:
			sale_channel = self.get_sale_channel()
			if not sale_channel:
				return
			mutation = '''mutation publishablePublish($id: ID!, $input: [PublicationInput!]!) {
	  publishablePublish(id: $id, input: $input) {
	    publishable {
	      availablePublicationCount
	      publicationCount
	    }
	    shop {
	      publicationCount
	    }
	    userErrors {
	      field
	      message
	    }
	  }
	}'''
			responses = self.graphql_api(mutation, variables = {
				"id": f"gid://shopify/Product/{product_id}",
				"input": {
					"publicationId": f"gid://shopify/Publication/{sale_channel}"
				}
			})
		except Exception:
			self.log_traceback()


	def shopify_datetime_to_utc_filter(self, time_str):
		start_time = isoformat_to_datetime(time_str) + dateutil.relativedelta.relativedelta(seconds = 1)

		start_time = start_time.astimezone(pytz.UTC)
		iso_format = start_time.isoformat()
		if iso_format.endswith("+00:00"):
			iso_format = iso_format.replace("+00:00", 'Z')
		return iso_format


	def finish_product_export(self):
		super(ModelChannelsShopify, self).finish_product_export()
		if self.is_refresh_process() and not self.is_refresh_all():
			self.get_model_state().update_field(self.get_state_id(), f'channel.config.{self.KEY_REFRESH_ALL}', True)
			self._state.channel.config[self.KEY_REFRESH_ALL] = True


	def clean_description(self, description):
		"""escape character and remove specifics tags"""
		try:
			soup = BeautifulSoup(description, 'html.parser')
			if self.is_clean_description():
				tags_remove = ['script', 'iframe']
				for tag in tags_remove:
					[x.decompose() for x in soup.find_all(tag)]

			description = soup.prettify(formatter = lambda s: s.replace(u'\xa0', ' '))
		except Exception:
			self.log_traceback(msg = description)
		if self._state.channel.config.api.strip_html_in_description:
			description = self.strip_html_from_description(description)
		return to_str(description).replace('’', "'").replace("”", '"').replace('“', '"').replace('–', '-')


	def is_barcode_to_gtin(self):
		return bool(self._state.channel.config.api.barcode_to_gtin)

	def import_order_vat_title(self):
		"""order import 'VAT' title instead of 'TAX'"""
		return bool(self._state.channel.config.api.import_order_vat_title)

	def custom_description_import(self, description):
		description = self.clean_description(description)
		try:
			channel_id = self.get_channel_id()
			if not hasattr(self, f'custom_description_{channel_id}'):
				return description
			return getattr(self, f'custom_description_{channel_id}')(description)
		except:
			self.log_traceback()
			return description


	def custom_description_19952(self, description):
		description = to_str(description).replace('''The price of the item does not include shipping. W</span></span><span style="line-height: 20.8px; background-color: rgb(255, 255, 255);">e are able to obtain hassle free shipping quotes from various shippers. In order to obtain a shipping quote, please message us with your delivery zip code. Unless otherwise stated, all shipping is handled by third party companies which are in no way affiliates of our company. In most cases, shipping fees are paid directly to the shipper of your choice.&nbsp;</span>Standard delivery time for freight items is&nbsp;approximately&nbsp;3-6 weeks but can be much sooner at times. Please message us with your delivery zip code for a quote.''', ''' $250 - Base rate shipping for 100 mile radius from zip code 19124.

	Delivery zip codes outside the 100 mile radius = variable rates. Feel free to contact us with the delivery zip code prior to purchasing, as it may affect the shipping cost cost.''').replace('''The price of the item does not include shipping. W</span></span><span style="line-height: 20.8px; background-color: rgb(255, 255, 255);">e are able to obtain hassle free shipping quotes from various shippers. In order to obtain a shipping quote, please message us with your delivery zip code. Unless otherwise stated, all shipping is handled by third party companies which are in no way affiliates of our company. In most cases, shipping fees are paid directly to the shipper of your choice. </span>Standard delivery time for freight items is approximately 3-6 weeks but can be much sooner at times. Please message us with your delivery zip code for a quote.''', '''$250 - Base rate shipping for 100 mile radius from zip code 19124.

	Delivery zip codes outside the 100 mile radius = variable rates. Feel free to contact us with the delivery zip code prior to purchasing, as it may affect the shipping cost cost.''')
		description = description.replace('''<p style="font-weight: normal; line-height: 20.8px; text-align: center;"><span style="line-height: 20.8px;"><b>***For shipping quotes, please feel free to message us at any time with your delivery zip code***</b></span></p>''', '')
		description = description.replace('''<p style="font-family: Arial; font-size: large; font-weight: normal; line-height: 20.8px; text-align: center;"><span style="color: #000000;"><span style="line-height: 20.8px;"><b>*** We would love for you to visit our showroom by appointment which is located in Philadelphia, PA 19124. Please message us to arrange a visit***</b></span></span></p>''', '')
		description = description.replace('''$250 - Base rate shipping for 100 mile radius from zip code 19124.\n\n\tDelivery zip codes outside the 100 mile radius = variable rates. Feel free to contact us with the delivery zip code prior to purchasing, as it may affect the shipping cost cost''', '''For larger furniture and fragile items, a shipping base rate of $299 per item applies within a 1000 mile radius of zip code 19124. Additional fees may apply for delivery zip codes outside this radius. Standard delivery time for freight items is approximately 3-6 weeks but can be much sooner at times. Please contact us for quotes beyond stated radius''')
		description = description.replace('font-family: Arial;',"font-family: 'times new roman';")
		description = description.replace('The price of the item does not include shipping. We are able to obtain hassle free shipping quotes from various shippers. In order to obtain a shipping quote, please message us with your delivery zip code. Unless otherwise stated, all shipping is handled by third party companies which are in no way affiliates of our company. In most cases, shipping fees are paid directly to the shipper of your choice. Standard delivery time for freight items is approximately 3-6 weeks but can be much sooner at times. Please message us with your delivery zip code for a quote','For larger furniture and fragile items, a shipping base rate of $299 per item applies within a 1000 mile radius of zip code 19124. Additional fees may apply for delivery zip codes outside this radius. Standard delivery time for freight items is approximately 3-6 weeks but can be much sooner at times. Please contact us for quotes beyond stated radius')
		return description