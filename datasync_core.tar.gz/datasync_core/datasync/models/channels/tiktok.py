import copy
from io import BytesIO

import requests
from PIL import Image
from bs4 import BeautifulSoup, Comment

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderHistory, Shipment, OrderAddress, OrderItemOption
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute

class ModelChannelsTiktok(ModelChannel):
	PRODUCT_IDENTIFIER_CHOICES = {1: "gtin", 2: "ean", 3: "upc", 4: "isbn"}
	SELF_SHIPPING = "SEND_BY_SELLER"
	SEND_BY_SELLER = 2
	TIKTOK_PRODUCT_STATUS = {"draft": 1, "pending": 2, "failed": 3, "active": 4, "inactive": 5, "freeze": 7}
	TIKTOK_ORDER_STATUS = {
		100: "UNPAID",
		111: "AWAITING_SHIPMENT",
		112: "AWAITING_COLLECTION",
		114: "PARTIALLY_SHIPPING",
		121: "IN_TRANSIT",
		122: "DELIVERED",
		130: "COMPLETED",
		140: "CANCELLED"
	}

	ORDER_STATUS = {
		"UNPAID": Order.AWAITING_PAYMENT,
		"AWAITING_SHIPMENT": Order.READY_TO_SHIP,
		"AWAITING_COLLECTION": Order.SHIPPING,
		"PARTIALLY_SHIPPING": Order.SHIPPING,
		"IN_TRANSIT": Order.COMPLETED,
		"DELIVERED": Order.COMPLETED,
		"COMPLETED": Order.COMPLETED,
		"CANCELLED": Order.CANCELED
	}

	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category', 'shipping']

	TIKTOK_CATEGORY_RULES = {
		"isSupportExemption": False,
		"isSizeChartMandatory": False,
		"supportCod": False,
		"isSizeChartSupport": False
	}

	STATES = {'AL': 'Alabama', 'AK': 'Alaska', 'AS': 'American Samoa', 'AZ': 'Arizona', 'AR': 'Arkansas', 'AF': 'Armed Forces Africa', 'AA': 'Armed Forces Americas', 'AC': 'Armed Forces Canada', 'AE': 'Armed Forces Europe', 'AM': 'Armed Forces Middle East', 'AP': 'Armed Forces Pacific', 'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware', 'DC': 'District of Columbia', 'FM': 'Federated States Of Micronesia', 'FL': 'Florida', 'GA': 'Georgia', 'GU': 'Guam', 'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas', 'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MH': 'Marshall Islands', 'MD': 'Maryland', 'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'MP': 'Northern Mariana Islands', 'OH': 'Ohio',
	          'OK': 'Oklahoma', 'OR': 'Oregon', 'PW': 'Palau', 'PA': 'Pennsylvania', 'PR': 'Puerto Rico', 'RI': 'Rhode Island', 'SC': 'South Carolina', 'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont', 'VI': 'Virgin Islands', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming', 'AB': 'Alberta', 'BC': 'British Columbia', 'MB': 'Manitoba', 'NF': 'Newfoundland', 'NB': 'New Brunswick', 'NS': 'Nova Scotia', 'NT': 'Northwest Territories', 'NU': 'Nunavut', 'ON': 'Ontario', 'PE': 'Prince Edward Island', 'QC': 'Quebec', 'SK': 'Saskatchewan', 'YT': 'Yukon Territory', 'NDS': 'Niedersachsen', 'BAW': 'Baden-Württemberg', 'BAY': 'Bayern', 'BER': 'Berlin', 'BRG': 'Brandenburg', 'BRE': 'Bremen', 'HAM': 'Hamburg', 'HES': 'Hessen', 'MEC': 'Mecklenburg-Vorpommern', 'NRW': 'Nordrhein-Westfalen', 'RHE': 'Rheinland-Pfalz', 'SAR': 'Saarland', 'SAS': 'Sachsen', 'SAC': 'Sachsen-Anhalt', 'SCN': 'Schleswig-Holstein',
	          'THE': 'Thüringen', 'NO': 'Niederösterreich', 'OO': 'Oberösterreich', 'SB': 'Salzburg', 'KN': 'Kärnten', 'ST': 'Steiermark', 'TI': 'Tirol', 'BL': 'Burgenland', 'VB': 'Voralberg', 'AG': 'Aargau', 'AI': 'Appenzell Innerrhoden', 'BE': 'Bern', 'BS': 'Basel-Stadt', 'FR': 'Freiburg', 'GE': 'Genf', 'GL': 'Glarus', 'JU': 'Graubünden', 'LU': 'Luzern', 'NW': 'Nidwalden', 'OW': 'Obwalden', 'SG': 'St. Gallen', 'SH': 'Schaffhausen', 'SO': 'Solothurn', 'SZ': 'Schwyz', 'TG': 'Thurgau', 'UR': 'Uri', 'VD': 'Waadt', 'VS': 'Wallis', 'ZG': 'Zug', 'ZH': 'Zürich', 'A Coruña': 'A Coruña', 'Alava': 'Alava', 'Albacete': 'Albacete', 'Alicante': 'Alicante', 'Almeria': 'Almeria', 'Asturias': 'Asturias', 'Avila': 'Avila', 'Badajoz': 'Badajoz', 'Baleares': 'Baleares', 'Barcelona': 'Barcelona', 'Burgos': 'Burgos', 'Caceres': 'Caceres', 'Cadiz': 'Cadiz', 'Cantabria': 'Cantabria', 'Castellon': 'Castellon', 'Ceuta': 'Ceuta', 'Ciudad Real': 'Ciudad Real', 'Cordoba': 'Cordoba', 'Cuenca': 'Cuenca',
	          'Girona': 'Girona', 'Granada': 'Granada', 'Guadalajara': 'Guadalajara', 'Guipuzcoa': 'Guipuzcoa', 'Huelva': 'Huelva', 'Huesca': 'Huesca', 'Jaen': 'Jaen', 'La Rioja': 'La Rioja', 'Las Palmas': 'Las Palmas', 'Leon': 'Leon', 'Lleida': 'Lleida', 'Lugo': 'Lugo', 'Madrid': 'Madrid', 'Malaga': 'Malaga', 'Melilla': 'Melilla', 'Murcia': 'Murcia', 'Navarra': 'Navarra', 'Ourense': 'Ourense', 'Palencia': 'Palencia', 'Pontevedra': 'Pontevedra', 'Salamanca': 'Salamanca', 'Santa Cruz de Tenerife': 'Santa Cruz de Tenerife', 'Segovia': 'Segovia', 'Sevilla': 'Sevilla', 'Soria': 'Soria', 'Tarragona': 'Tarragona', 'Teruel': 'Teruel', 'Toledo': 'Toledo', 'Valencia': 'Valencia', 'Valladolid': 'Valladolid', 'Vizcaya': 'Vizcaya', 'Zamora': 'Zamora', 'Zaragoza': 'Zaragoza', 'ACT': 'Australian Capital Territory', 'JBT': 'Jervis Bay Territory', 'NSW': 'New South Wales', 'QLD': 'Queensland', 'SA': 'South Australia', 'TAS': 'Tasmania', 'VIC': 'Victoria', }

	MAPPING_CARRIER_US = {"USPS": "7117858858072016686", "UPS": "7117859084333745966", "FedEx": "7129720299146184490", "LaserShip": "7132708441138677550",
	                        "OnTrac": "7132721393761781550", "Better Trucks": "7212608507307099946", "TForce": "7212611208266909483", "DHL eCommerce": "7220301902846625579",
	                        "Amazon Logistics": "7248600717110282027", "AxleHire": "7254084300713232174", "Lone Star Overnight": "7254085043432195882", "Deliver-it": "7260759364112221953",
	                        "GLS US": "7260760118063531777", "Spee-Dee Delivery Service": "7260761851384825602", "Wizmo": "7260762638932510466"}

	MAPPING_CARRIER_UK = {"EVRi": "6599541761693270018", "FedEx UK": "6618402578756190210", "DHL UK": "6639580521074524161", "Yodel UK": "6641219975896514562", "UK Mail": "6649195729745887233",
	                        "Parcel2Go": "6654133961797746689", "DPD UK": "6657598289359323137", "DX Delivery": "6658174162568658945", "UPS UK": "6667705672463351809", "Royal Mail": "6671794738251726849",
	                        "Parcel Force": "6699476450581430274", "Arrow XL": "6723065376080412674", "APC Overnight": "6760565269699084290", "Panther UK": "6760727669580627970", "Amazon Logistics": "7046331959399679746",
	                        "DHLExpress": "7074863218149033730", "Fastway Ireland": "7111573973179041538", "AO Logistics": "7280421693011527425"}
	def __init__(self):
		super().__init__()
		self._total_number_products = None
		self._all_products = None
		self._shop_info = None
		self._shop_id = None
		self._api_url = None
		self._flag_finish_product = False
		self._last_product_response = None
		self._ware_house_id = None
		self._total_number_orders = None
		self._flag_finish_order = False
		self._next_cursor_order = False
		self._product_page_number = 1
		self._product_pull_type = "active"
		self._tiktok_product_status = None

	def get_api_info(self):
		return {
			"app_key": to_str(self._state.channel.config.api.app_key),
			"app_secret": to_str(self._state.channel.config.api.app_secret),
			"access_token": to_str(self._state.channel.config.api.access_token),
		}

	def get_app_mode(self):
		app_mode = self._state.channel.config.api.mode
		if not app_mode:
			return get_config_ini("tiktok", "mode")
		return app_mode

	def get_api_url(self):
		mode = self.get_app_mode()
		if mode == "sandbox":
			self._api_url = "https://open-api-sandbox.tiktokglobalshop.com"
		else:
			self._api_url = "https://open-api.tiktokglobalshop.com"
		return self._api_url

	def get_url_refresh_token(self):
		mode = self.get_app_mode()
		url = "https://auth{}.tiktok-shops.com/api/token/refreshToken"
		if mode == "sandbox":
			url = url.format("-sandbox")
		else:
			url = url.format("")
		return url

	def set_last_product_response(self, response):
		self._last_product_response = response

	def get_last_product_response(self):
		return self._last_product_response

	def get_seller_base_region(self):
		return self._state.channel.config.api.seller_base_region

	def api(self, path = "", params = None, body = None, method = "get"):
		url = self.get_api_url() + "/api/" + to_str(path).strip('/')
		secret = self._state.channel.config.api.app_secret
		access_token = self._state.channel.config.api.access_token
		app_key = self._state.channel.config.api.app_key
		headers = {
			"Content-Type": "application/json"
		}
		default_params = {
			"timestamp": to_int(time.time()),
			"access_token": access_token,
			"app_key": app_key,
		}
		if params:
			params = {**default_params, **params}
		else:
			params = default_params
		params["sign"] = self.generate_signature(to_str(path).strip("/"), params, secret)
		res = self.requests(url, params, body, headers = headers, method = method)
		retry = 0
		while (res is False) or ('expected Array to be a Hash' in to_str(res)) or (
				"Exceeded 2 calls per second for api client. Reduce request rates to resume uninterrupted service" in to_str(
			res)) or self._last_status >= 500:
			retry += 1
			time.sleep(2)
			res = self.requests(url, params, body, headers = headers, method = method)
			if retry > 5:
				break
		return res

	@staticmethod
	def generate_signature(path, params, secret):
		# sort params alphabet
		sorted_params = dict(sorted(params.items()))
		input_str = "/api/" + path
		for key, value in sorted_params.items():
			if key == "access_token" or key == "sign":
				continue
			input_str += to_str(key) + to_str(value)
		input_str = secret + input_str + secret
		signature = hash_hmac(algo = "sha256", data = input_str, key = secret)
		return signature

	def refresh_access_token(self):
		url = self.get_url_refresh_token()
		secret_key = self._state.channel.config.api.app_secret
		refresh_token = self._state.channel.config.api.refresh_token
		app_key = self._state.channel.config.api.app_key
		headers = {
			"Content-Type": "application/json",
			"User-Agent": get_random_useragent()
		}
		body = {
			"app_key": app_key,
			"app_secret": secret_key,
			"refresh_token": refresh_token,
			"grant_type": "refresh_token",
		}
		request_options = {
			"headers": headers,
			"json": body,
			"verify": True
		}
		refresh_data = requests.request(method = "post", url = url, **request_options)
		refresh_error = {
			"method": "POST",
			"header": to_str(refresh_data.headers),
			"status": refresh_data.status_code,
			"body": body,
			"response": refresh_data.text
		}
		try:
			refresh_data = refresh_data.json()
		except:
			log_traceback()
		if refresh_data["message"].lower() != Response().SUCCESS:
			self.log_request_error(url, **refresh_error)
			return False
		new_access_token = refresh_data["data"]["access_token"]
		new_refresh_token = refresh_data["data"]["refresh_token"]
		self._state.channel.config.api.access_token = new_access_token
		self._state.channel.config.api.refresh_token = new_refresh_token
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return new_access_token

	def requests(self, url, params = None, body = None, headers = None, method = "get"):
		if not headers:
			headers = dict()
			headers["User-Agent"] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get("User-Agent"):
			headers["User-Agent"] = get_random_useragent()

		response = False
		request_options = {
			"headers": headers,
			"verify": True
		}
		if params:
			request_options["params"] = params
		if method in ["post", "put"] and body:
			request_options["json"] = body

		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code

			# response_data = json_decode(response.text)

			def log_request_error(res):
				error = {
					"method": method,
					"header": to_str(res.headers),
					"status": res.status_code,
					"param": params,
					"body": body,
					"response": response.text
				}
				self.log_request_error(url, **error)

			if response.status_code == 401:
				new_access_token = self.refresh_access_token()
				if not new_access_token:
					self.set_action_stop(True)
					return response
				self._state.channel.config.api.access_token = new_access_token
				params["access_token"] = new_access_token
				# res = self.requests(url, params, body, method = method)
				response = requests.request(method, url, **request_options)
				self._last_status = response.status_code
				if response.status_code == 401:
					self.set_action_stop(True)
					return response
			if response.status_code > 300 or self.is_log():
				log_request_error(response)
			response_data = json_decode(response.text)
			if response_data and response_data["message"].lower() != Response().SUCCESS:
				log_request_error(response)
			if response_data:
				try:
					response_prodict = Prodict(**response_data)
				except Exception:
					response_prodict = response_data
				response_data = response_prodict
		except Exception:
			self.log_traceback()
		return response_data

	def log_response(self, log_data, log_name: str) -> None:
		self.log(log_data, log_name)

	def validate_api_info(self):
		validate = super(ModelChannelsTiktok, self).validate_api_info()
		if validate.result.lower() != Response().SUCCESS:
			return validate
		app_key = to_str(self._state.channel.config.api.app_key)
		app_secret = to_str(self._state.channel.config.api.app_secret)
		access_token = to_str(self._state.channel.config.api.access_token)
		if not (app_key, app_secret, access_token):
			return Response().error(msg = "Tiktok shop API invalid")
		return Response().success()

	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		try:
			shop_info = self.get_shop_info()
			shop_id = shop_info["data"]["shop_list"][0]["shop_id"]
			# shop_region = shop_info["data"]["shop_list"][0]["region"]
			self._state.channel.config.api.shop_id = shop_id
			# self._state.channel.config.api.shop_region = shop_region
			if not shop_info:
				return Response().error(msg = "Tiktok shop API invalid")
		except Exception:
			return Response().error(msg = "Setup channel error")
		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()

	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent["result"] != Response().SUCCESS:
			return parent
		shop_id = self.get_shop_id()
		self.set_identifier(shop_id)
		return Response().success()

	def after_create_channel(self, data):
		# Create webhook receive product audit event
		if is_local():
			return Response().success()
		event_audit_product = 5
		events = dict()
		events["products/updated"] = "product/update"
		for event, url in events.items():
			address = get_server_callback(f"merchant/tiktok/webhook/{data.channel_id}/{url}")
			webhook_data = {
				"event_type": event_audit_product,
				"webhook_address": address
			}
			webhook = self.api("open/webhook/create", body = webhook_data, method = "post")
			self.log(webhook, "tiktok_webhook_response")
			if webhook and webhook["message"].lower() != Response().SUCCESS:
				self.log_response(webhook, "tiktok_webhook_create_failed")
		return Response().success()

	def get_shop_info(self):
		if self._shop_info:
			return self._shop_info
		shop_info = self.api("shop/get_authorized_shop")
		if shop_info:
			self._shop_info = shop_info
		else:
			return Response().error(msg = "Could not get shop info")
		return self._shop_info

	def get_shop_id(self):
		if self._shop_id:
			return self._shop_id
		shop_id = self._state.channel.config.api.shop_id
		self._shop_id = shop_id
		return self._shop_id

	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.total = 0
			if not self._state.pull.process.products.id_src:
				self._state.pull.process.products.id_src = 0
			total_number_products = self.get_total_product()
			if total_number_products:
				if self.is_refresh_process():
					self._state.pull.process.products.total = -1
				else:
					self._state.pull.process.products.total = total_number_products
			if not self.is_refresh_process():
				for row in ['draft', 'pending', 'failed', 'inactive', 'freeze']:
					if self.is_import_product_by_status(row):
						status = self.TIKTOK_PRODUCT_STATUS.get(row, 4)
						total_number_products = self.get_total_product(status)
						self._state.pull.process.products.total += total_number_products
		if self.is_order_process():
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.total = 0
			start_time = self.get_order_start_time()
			last_modifier = self._state.pull.process.orders.max_last_modified
			filter_condition = {
				"create_time_from": to_timestamp(start_time)
			}
			if last_modifier:
				filter_condition["update_time_from"] = to_timestamp(last_modifier)
				self.set_order_max_last_modifier(last_modifier)
			total_number_orders = self.get_total_number_orders(filter_condition)
			if total_number_orders:
				self._state.pull.process.orders.total = total_number_orders
		return Response().success()

	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%d %H:%M:%S") > to_timestamp(self._order_max_last_modified, "%Y-%m-%d %H:%M:%S")):
			self._order_max_last_modified = last_modifier

	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear

	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		return next_clear

	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			body = {
				"page_size": 100,  # limit_data,
				"search_status": 4,
				"page_number": 1
			}
			params = {"shop_id": self.get_shop_id()}
			all_products = self.api("products/search", params = params, body = body, method = "post")
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.data.get("products"):
					return next_clear
				prd_ids = list()
				for product in all_products["data"]["products"]:
					id_product = product.get("id")
					prd_ids.append(id_product)
				delete_payload = {
					"product_ids": prd_ids
				}
				res = self.api("products", params = params, body = delete_payload, method = "delete")
				all_products = self.api("products/search", params = params, body = body, method = "post")
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear

	def get_products_main_export(self):
		# total_number_products = self._state.pull.process.products.total
		limit_data = self._state.pull.setting.products
		try:
			if not self._product_pull_type:
				return Response().finish()
			if self._product_pull_type == "active":
				search_status = 4
			else:
				if self.is_refresh_process() or not self.is_import_product_by_status(self._product_pull_type):
					self.set_product_pull_type()
					return self.get_products_main_export()
				search_status = self.TIKTOK_PRODUCT_STATUS.get(self._product_pull_type, 4)
			body = {
				"page_size": 100,  # limit_data,
				"search_status": search_status,
				"page_number": self._product_page_number
			}
			products = self.api("products/search", body = body, method = "post")
			self._product_page_number += 1
			if not products.data.products:
				self.set_product_pull_type()
				self._product_page_number = 1
				return self.get_products_main_export()
		except Exception as e:
			self.log_traceback()
			return Response().finish(code = Errors.EXCEPTION, msg = e)
		return Response().success(data = products["data"]["products"])

	def get_products_ext_export(self, products):
		extend = Prodict()
		for product in products:
			product_id = product.get("id") or product.get("product_id")
			params = {
				"product_id": to_str(product_id)
			}
			detail_product = self.api("products/details", params = params)
			extend.set_attribute(product_id, Prodict())
			extend[to_str(product_id)] = detail_product.data
		return Response().success(extend)

	def get_product_id_import(self, convert: Product, product, products_ext):
		product_id = product.get("id") or product.get("product_id")
		return product_id

	def get_product_by_id(self, product_id):
		params = {
			"product_id": product_id
		}
		product_response = self.api("products/details", params = params)
		if product_response and product_response["message"].lower() == Response().SUCCESS:
			return Response().success(product_response["data"])
		return Response().error(msg = "Get product from tiktok failed")

	def save_attribute_data(self, attribute, is_variant = False):
		cate_attributes_data = dict()
		cate_specific_data = dict()
		cate_attributes_data["attribute_id"] = attribute["id"]
		cate_attributes_data["attribute_name"] = attribute["name"]
		cate_attributes_data["attribute_type"] = 2 if is_variant else 3
		cate_specific_data["name"] = attribute["name"]
		cate_specific_data["value"] = attribute.get("option_values") or attribute.get("value_name")
		if not is_variant:
			cate_specific_data["override"] = attribute.get("option_values") or attribute.get("value_name")
		return cate_attributes_data, cate_specific_data

	def get_tiktok_cate_rules(self, cate_id):
		params = {"category_id": cate_id}
		rules_response = self.api("products/categories/rules", params = params)
		if rules_response and rules_response["message"].lower() == Response().SUCCESS:
			category_rules = Prodict.from_dict(self.TIKTOK_CATEGORY_RULES.copy())
			rules_data = rules_response.data.category_rules[0]
			category_rules["isSupportExemption"] = rules_data.exemption_of_identifier_code.support_identifier_code_exemption
			category_rules["isSizeChartMandatory"] = rules_data.is_size_chart_mandatory
			category_rules["supportCod"] = rules_data.support_cod
			category_rules["isSizeChartSupport"] = rules_data.support_size_chart
			category_rules["productCertifications"] = rules_data.product_certifications
			return category_rules
		return {}

	def tiktok_data_to_template(self, product, is_variant = False, sku = None):
		template_data = dict()
		# Category template
		category_leaf = self.get_tiktok_leaf_cate(product["category_list"])
		product_attributes = self.convert_product_attributes(product.get("product_attributes"))
		delivery_service_ids = list()
		if product.get("delivery_services"):
			delivery_service_ids = [to_str(delivery_service["delivery_service_id"]) for delivery_service in product.get("delivery_services")]
		exemption_reason = product.get("exemption_of_identifier_code", {}).get("exemption_reason", [])
		brand = product.get("brand", {})
		size_chart = product.get("size_chart", {})
		warehouse_id = product.skus[0].stock_infos[0].warehouse_id
		cate_template_data = dict()
		cate_template_data["category_id"] = category_leaf["id"]
		category_path_api = self.get_category_path(channel_type = 'tiktok', type_search = f'{self.get_channel_id()}/category/search', params = {"category_id": category_leaf["id"]})
		cate_template_data["category_name"] = category_leaf["name"]
		if category_path_api and category_path_api.get('data'):
			cate_template_data["category_name"] = category_path_api['data'][0]['path']
		cate_template_data["is_cod_open"] = product.get("is_cod_open")
		cate_rules = self.get_tiktok_cate_rules(category_leaf["id"])
		if cate_rules:
			cate_template_data["category_rules"] = cate_rules
		if brand:
			cate_template_data["brand_id"] = brand["id"]
			cate_template_data["brand_name"] = brand["name"]
		if exemption_reason:
			cate_template_data["exemption_of_identifier_code"] = exemption_reason[0]
		if size_chart:
			cate_template_data["size_chart_id"] = size_chart["id"]
			size_chart_urls = size_chart.get("url_list")
			if size_chart_urls:
				cate_template_data["size_chart_url"] = size_chart_urls[0]

		prd_attributes = list()
		specific_attributes = list()
		for attribute in product_attributes:
			cate_attributes_data, cate_specific_data = self.save_attribute_data(attribute)
			prd_attributes.append(cate_attributes_data)
			specific_attributes.append(cate_specific_data)
		if not is_variant:
			default_sales_attributes = product["skus"][0].get("sales_attributes", [])
			for attribute in default_sales_attributes:
				if attribute.name.lower() == "colour":
					attribute.name = "Color"
				prd_attributes.append({
					"attribute_id": attribute["id"],
					"attribute_type": 2,
					"attribute_name": attribute["name"]
				})
				specific_attributes.append({
					"name": attribute["name"],
					"value": "",
					"mapping": "",
					"override": ""
				})
		else:
			sales_attributes = sku.get("sales_attributes", [])
			for attribute in sales_attributes:
				cate_attributes_data, cate_specific_data = self.save_attribute_data(attribute, is_variant)
				prd_attributes.append(cate_attributes_data)
				specific_attributes.append(cate_specific_data)
		cate_template_data["product_attributes"] = prd_attributes
		cate_template_data["specifics"] = specific_attributes
		if product.get("product_certifications"):
			cate_template_data["product_certifications"] = product.get("product_certifications")
		# Shipping template
		shipping_template_data = dict()
		warranty_period = product.get("warranty_period", {})
		if warranty_period:
			shipping_template_data["warranty_period"] = warranty_period["warranty_id"]
		if delivery_service_ids:
			shipping_template_data["delivery_services_ids"] = delivery_service_ids
		if product.get("warranty_policy"):
			shipping_template_data["warranty_policy"] = product["warranty_policy"]
		if self.is_us() and product.get("package_dimension_unit"):
			shipping_template_data["us_unit"] = product["package_dimension_unit"]
		shipping_template_data["warehouse_id"] = warehouse_id
		if self.is_us():
			shipping_template_data["weight_unit"] = 'lb'
			shipping_template_data["dimension_unit"] = 'in'
		else:
			shipping_template_data["weight_unit"] = 'kg'
			shipping_template_data['dimension_unit'] = 'cm'
		template_data["category"] = cate_template_data
		template_data["shipping"] = shipping_template_data
		return template_data

	def convert_product_status(self, tiktok_status):
		if tiktok_status == 1:
			return "tiktok_draft"
		for key, value in self.TIKTOK_PRODUCT_STATUS.items():
			if value == tiktok_status:
				return to_str(key)

	def _convert_product_export(self, product, products_ext: Prodict):
		product_data = Product()
		product_id = to_str(product.get("id")) or to_str(product.get("product_id"))
		current_product_ext = products_ext[product_id]
		product_data.name = current_product_ext.product_name
		product_data.lower_name = product_data.name.lower()
		product_data.status = True if to_int(current_product_ext.product_status) == 4 else False
		product_data.invisible = True if to_int(current_product_ext.product_status) != 4 else False
		default_sku = []
		if current_product_ext.skus:
			default_sku = current_product_ext.skus[0]
		product_data.sku = default_sku.seller_sku
		product_data.is_in_stock = True if default_sku.stock_infos[0].available_stock else False
		product_data.qty = to_int(default_sku.stock_infos[0].available_stock)
		product_data.price = default_sku.price.original_price
		product_data.description = current_product_ext.description
		package_dimension_unit = current_product_ext.get("package_dimension_unit")
		if self.is_us() and self.is_imperial_unit(package_dimension_unit):
			product_data.weight_units = "lb"
			product_data.dimension_units = "in"
		else:
			product_data.weight_units = "kg"
			product_data.dimension_units = "cm"
		product_data.length = current_product_ext.package_length
		product_data.width = current_product_ext.package_width
		product_data.height = current_product_ext.package_height
		product_data.weight = current_product_ext.package_weight
		region = self.get_seller_base_region()
		product_data.seo_url = f"https://shop.tiktok.com/view/product/{product_id}?region={to_str(region)}"
		channel_data = dict()
		channel_data["tiktok_sku_id"] = default_sku.id
		tiktok_dimensions = {
			"length": current_product_ext.package_length,
			"width": current_product_ext.package_width,
			"height": current_product_ext.package_height,
			"weight": current_product_ext.package_weight
		}
		if self.is_us():
			tiktok_dimensions["weight_unit"] = 'lb'
			tiktok_dimensions["dimension_unit"] = 'in'
		else:
			tiktok_dimensions["weight_unit"] = 'kg'
			tiktok_dimensions['dimension_unit'] = 'cm'
		tiktok_product_status = current_product_ext.product_status
		if not tiktok_product_status or tiktok_product_status == "0":
			channel_data["tiktok_status"] = "pending"
		else:
			channel_data["tiktok_status"] = self.convert_product_status(current_product_ext.product_status)
		channel_data["region"] = region
		channel_data["tiktok_dimensions"] = tiktok_dimensions
		product_data.channel_data = channel_data
		if not current_product_ext.exemption_of_identifier_code and current_product_ext.skus[0].product_identifier_code:
			product_identifier = current_product_ext.skus[0].product_identifier_code
			product_identifier_code = self.get_product_identifier(product_identifier.identifier_code_type)
			product_data[product_identifier_code] = product_identifier.identifier_code
		if current_product_ext.images:
			for index, image in enumerate(current_product_ext.images):
				product_image_data = ProductImage()
				if index == 0:
					product_data.thumb_image.label = image.id
					product_data.thumb_image.url = image.thumb_url_list[0]
					product_data.thumb_image.position = 0
					continue
				product_image_data.label = image.id
				product_image_data.url = image.url_list[0]
				product_image_data.position = index
				product_data.images.append(product_image_data)
		template_data = self.tiktok_data_to_template(current_product_ext)
		product_data.template_data = template_data
		if current_product_ext.skus:
			qty = 0
			for child in current_product_ext.skus:
				if self.product_has_variants(current_product_ext.skus):
					variant_data = ProductVariant()
					variant_data.channel_data["tiktok_sku_id"] = child.id
					# variant_template_data = self.tiktok_data_to_template(current_product_ext, is_variant = True, sku = child)
					if child.sales_attributes:
						tiktok_attributes = list()
						for attribute in child.sales_attributes:
							if attribute.sku_img:
								variant_data.images.append({
									"label": attribute.sku_img.id,
									"url": attribute.sku_img.url_list[0]
								})
							variant_attribute = ProductVariantAttribute()
							variant_attribute.id = attribute.id
							variant_attribute.attribute_name = attribute.name
							if attribute.name.lower() == "colour":
								variant_attribute.attribute_name = "Color"
							variant_attribute.attribute_value_id = attribute.value_id
							variant_attribute.attribute_value_name = attribute.value_name
							variant_data.attributes.append(variant_attribute)
							tiktok_attributes.append(variant_attribute)
						variant_data.channel_data["tiktok_attributes"] = tiktok_attributes
					# variant_data.template_data = variant_template_data
					variant_data.id = to_str(child.id)
					variant_data.price = child.price.original_price
					variant_data.qty = child.stock_infos[0].available_stock
					variant_data.is_in_stock = True if child.stock_infos[0].available_stock > 0 else False
					variant_data.sku = child.seller_sku
					if not product.exemption_of_identifier_code and child.product_identifier_code:
						variant_identifier = child.product_identifier_code
						variant_identifier_code = self.get_product_identifier(variant_identifier.identifier_code_type)
						variant_data[variant_identifier_code] = variant_identifier.identifier_code
					product_data.variants.append(variant_data)
					qty += to_int(child.stock_infos[0].available_stock)
					product_data.qty = qty
					product_data.is_in_stock = True if qty else False
		return Response().success(product_data)

	def is_product_pull_from_tiktok(self, product):
		# check product source: if channel source id equal current channel id -> True
		check_src = True if product.src.channel_id == self.get_channel_id() else False
		channel_data = product['channel'].get(f'channel_{self.get_channel_id()}', {})
		# if a product has auto_link or user_linked mean product pull from TikTok
		# the product linked with a product in the main channel
		check_link = True if channel_data.get('auto_link') or channel_data.get('user_linked') else False
		return check_src or check_link

	def get_draft_extend_channel_data(self, product):
		description = product.description or product.short_description or product.title
		extend = {}
		if product.description != description:
			extend['description'] = description
		if product.sku and self._state.channel.config.api.sku_to_gtin:
			extend['gtin'] = product.sku
		if product.upc and self._state.channel.config.api.upc_to_gtin:
			extend['gtin'] = product.upc
		return extend

	def product_import(self, convert: Product, product, products_ext):
		convert_product = self.product_to_tiktok_data(product, products_ext, insert = True)
		if convert_product.result != Response().SUCCESS:
			return convert_product
		post_data = convert_product.data
		category_template = product.template_data.category
		product_attributes = category_template.product_attributes
		variation_options = self.variants_to_option(product.variants)
		len_variant_attributes = to_len(list(variation_options.keys()))
		len_sale_attributes = to_len([item for item in product_attributes if item["attribute_type"] == 2])
		is_equal_attribute = len_variant_attributes == len_sale_attributes
		response = self.api("products", body = post_data, method = "post")
		if response and isinstance(response, dict):
			msg = response.get("message")
			if msg.find("The SKU contains duplicate sales attribute") != -1 and is_equal_attribute:
				return Response().error(msg = "TIKTOK_MISSING_SALE_ATTRIBUTE")
		check_response = self.check_response_import(response, product, 'product')
		if check_response["result"].lower() != Response().SUCCESS:
			return check_response
		product_id = response["data"]["product_id"]
		self.set_last_product_response(response)
		return Response().success(product_id)

	def handle_description(self, description):
		#remove all comment
		description = re.sub(r'<!--(.*?)-->', '', description, flags = re.DOTALL)
		description = "<body>" + description + "</body>"
		soup = BeautifulSoup(description, 'html.parser')
		allowed_tags = ['ul', 'li', 'img', 'p', 'strong', 'em', 'ol', 'u']

		img_tags = soup.find_all("img")
		for img_tag in img_tags:
			src = img_tag.get('src', '')
			if not src.lower().endswith(('.png', '.jpg', '.jpeg')):
				img_tag.extract()  # Remove the image tag from the soup
		img_tags_after_clean = soup.find_all("img")
		image_urls = [image["src"] for image in img_tags_after_clean]
		try:
			tiktok_imgs = self.create_tiktok_image(images = image_urls, img_scene = 2)
		except:
			tiktok_imgs = []
			self.log_traceback()
		for data in soup(['style', 'script']):
			# Remove stype, script
			data.decompose()
		if img_tags_after_clean and tiktok_imgs:
			for index, image in enumerate(img_tags_after_clean):
				img_attrs = copy.deepcopy(image.attrs)
				img_src = image["src"]
				for attr in img_attrs:
					if attr not in ["src", "width", "height"]:
						del image.attrs[attr]
				for tiktok_img in tiktok_imgs:
					if img_src == tiktok_img["origin"]:
						image.attrs["src"] = tiktok_img["url"]
						image.attrs["width"] = tiktok_img["width"]
						image.attrs["height"] = tiktok_img["height"]
		# Create a list to store the extracted img tags
		extracted_img_tags = []

		# Find all img tags and store them in the list
		for img_tag in img_tags_after_clean:
			extracted_img_tags.append(img_tag)
			img_tag.extract()

		def is_allowed(tag):
			return tag.name in allowed_tags

		# Reinsert the img tags in their original positions
		for img_tag in extracted_img_tags:
			if not img_tag.get("src"):
				continue
			soup.body.append(img_tag)

		for tag in soup.find_all(lambda tag: not is_allowed(tag)):
			tag.unwrap()  # Remove the tag but keep its contents
		# Remove attribute inside tag if not img tag
		tags_with_attributes = soup.find_all(lambda tag: len(tag.attrs) > 0)
		for tag in tags_with_attributes:
			if tag.name != 'img':
				tag.attrs = {}
		# remove tag if not content
		for tag in soup.find_all():
			if not tag.get_text(strip = True) and tag.name != 'img':
				tag.extract()

		# Remove li tag if not ul
		li_items = soup.find_all('li')
		for li in li_items:
			if li.find_parent('ul') is None:
				li.unwrap()  # Remove the <li> tag but keep its content
			# if li.find_parent('ol') is None:
			# 	li.unwrap()  # Remove the <li> tag but keep its content
		if self.is_us():
			imgs_to_remove = soup.find_all('img', src = lambda value: value and 'tiktokcdn-us' not in value)
		else:
			imgs_to_remove = soup.find_all('img', src = lambda value: value and 'ibyteimg' not in value)
		for img_tag in imgs_to_remove:
			img_tag.extract()
		cleaned_html = (str(soup)
		                .replace("\n", "")
		                .replace("www.P65Warnings.ca.gov", "P65Warnings ca gov")
		                )
		return cleaned_html

	def is_us(self):
		return self.get_seller_base_region() == "US"

	def is_uk(self):
		return self.get_seller_base_region() == "GB"

	def is_imperial_unit(self, weight_unit):
		if not weight_unit:
			return False
		if weight_unit.lower() in ["lb", "lbs", "oz", "imperial"]:
			return True
		return False

	def resize(self, url, img_scene):
		try:
			r = False
			retry = 0
			while r is False and retry < 3:
				try:
					r = requests.get(url, verify = False)
				except Exception as e:
					time.sleep(1)
					retry += 1
					r = False
					if retry == 1:
						self.log_traceback('tiktok_image_resize_except')
			if not r or r.status_code != 200:
				self.log(r.status_code, 'tiktok_image_resize_error')
				return False
			is_png = False
			if r.headers.get('content-type') == 'image/png':
				is_png = True
			image_data = BytesIO(r.content)
			# Open the image using Pillow
			original_image = Image.open(image_data)
			# auto convert from webp to jpeg
			if r.headers.get('content-type') == 'image/webp':
				original_image = original_image.convert('RGB')
				jpeg_buffer = BytesIO()
				original_image.save(jpeg_buffer, format = "JPEG")
				image_base64 = self.convert_image_file_to_base64(original_image, is_png)
				return image_base64
			case = self._state.channel.config.setting.get("images_resize")
			skip_resize_image = self._state.channel.config.api.skip_resize_image
			if original_image.width < 300 or original_image.height < 300:
				case = "fit"
			can_resize = True if (img_scene == 1 or img_scene == 3) and not skip_resize_image else False
			if case == "crop" and can_resize:
				# Resize the image to an inner square
				min_side = min(original_image.width, original_image.height)
				x1 = (original_image.width - min_side) // 2
				y1 = (original_image.height - min_side) // 2
				x2 = x1 + min_side
				y2 = y1 + min_side
				square_inside_image = original_image.crop((x1, y1, x2, y2))
				image_base64 = self.convert_image_file_to_base64(square_inside_image, is_png)
			elif case == "fit" and can_resize:
				#Resize the image to an outer square
				max_side = max(original_image.width, original_image.height)
				if max_side < 300:
					max_side = 300
				outer_square_image = Image.new("RGBA" if is_png else "RGB", (max_side, max_side), "WHITE")
				x_offset = (max_side - original_image.width) // 2
				y_offset = (max_side - original_image.height) // 2
				outer_square_image.paste(original_image, (x_offset, y_offset))
				image_base64 = self.convert_image_file_to_base64(outer_square_image, is_png)
			elif case == "square" and can_resize:
				desired_size = min(original_image.width, original_image.height)
				# Crop and resize the image
				square_ratio_image = original_image.resize((desired_size, desired_size))
				image_base64 = self.convert_image_file_to_base64(square_ratio_image, is_png)
			else:
				image_base64 = self.convert_image_to_base64(url)
			return image_base64
		except Exception as e:
			self.log_traceback('tiktok_resize_images', f"image error: {url}")
			return False


	def product_to_tiktok_data(self, product: Product, products_ext, insert = False):
		is_pull_from_tiktok = self.is_product_pull_from_tiktok(product)
		images = self.extend_images(product)
		if not images:
			return Response().error(msg = "Product images can not be empty")
		"""
		Chinese characters are not allowed.
		For US and UK shops, the product name must have at least 1 character and no more than 255 characters. 
		For shops in other regions, the product name must have at least 25 character and no more than 255 characters.
		"""
		product_name = product.name[:255]
		if not self.is_us() and not self.is_uk() and len(product_name) < 25:
			return Response().error(msg = "Product name must have at least 25 character and no more than 255 characters.")
		if self.detect_chinese_characters(product_name):
			return Response().error(msg = "Chinese characters are not allowed")
		try:
			tiktok_images = self.create_tiktok_image(images)
		except:
			tiktok_images = []
			self.log_traceback()
		description = self.handle_description(product.description)
		post_data = {
			"product_name": product_name,
			# "description": self.process_description_before_import(product.description),
			"description": description or product.name,
			"images": [{"id": img["id"]} for img in tiktok_images],
			"package_weight": to_str(product.weight),
			"package_height": to_int(product.height),
			"package_length": to_int(product.length),
			"package_width": to_int(product.width)
		}
		shipping_template = product.template_data.get("shipping", {})
		category_template = product.template_data.get("category", {})
		weight_units = shipping_template.get("weight_unit")
		dimension_units = shipping_template.get("dimension_unit")
		is_imperial_unit = self.is_imperial_unit(weight_units)
		if not product.weight:
			return Response().error(msg = "Product package weight is invalid. Please enter correct package weight in shipping tab.")
		package_weight = product.weight
		package_length = product.length
		package_height = product.height
		package_width = product.width
		if self.is_us():
			post_data["package_dimension_unit"] = "imperial" if is_imperial_unit else "metric"
			if is_imperial_unit:
				#convert weight to lb and dimension to inch
				post_data["package_weight"] = to_str(to_decimal(self.convert_weight_unit(package_weight, weight_units), 2))
				post_data["package_length"] = to_int(round(self.dimension_to_inch(to_decimal(package_length), dimension_units)))
				post_data["package_width"] = to_int(round(self.dimension_to_inch(to_decimal(package_width), dimension_units)))
				post_data["package_height"] = to_int(round(self.dimension_to_inch(to_decimal(package_height), dimension_units)))
			else:
				post_data["package_weight"] = self.convert_weight_to_kg(to_decimal(package_weight), weight_units)
				if product.length:
					post_data["package_length"] = self.convert_dimensions_to_cm(to_decimal(package_length), dimension_units)
				if product.width:
					post_data["package_width"] = self.convert_dimensions_to_cm(to_decimal(package_width), dimension_units)
				if product.height:
					post_data["package_height"] = self.convert_dimensions_to_cm(to_decimal(package_height), dimension_units)
		else:
			#convert weight to kg and dimension to cm
			post_data["package_weight"] = self.convert_weight_to_kg(to_decimal(package_weight), weight_units)
			if product.length:
				post_data["package_length"] = self.convert_dimensions_to_cm(to_decimal(package_length), dimension_units)
			if product.width:
				post_data["package_width"] = self.convert_dimensions_to_cm(to_decimal(package_width), dimension_units)
			if product.height:
				post_data["package_height"] = self.convert_dimensions_to_cm(to_decimal(package_height), dimension_units)
		if shipping_template.get("warranty_policy"):
			post_data["warranty_policy"] = shipping_template.warranty_policy
		if shipping_template.get("warranty_period"):
			post_data["warranty_period"] = to_int(shipping_template.warranty_period)
		if shipping_template.get("delivery_services_ids"):
			post_data["delivery_service_ids"] = shipping_template.delivery_services_ids
		if self.is_us() and post_data.get("delivery_service_ids"):
			del post_data["delivery_service_ids"]
		warehouse_id = shipping_template.get("warehouse_id") or self.get_default_warehouse()
		if category_template:
			specifics = self.mapping_attributes(category_template.specifics, category_template.product_attributes)
			product_attributes = self.get_mapping_attributes_by_type(specifics, attr_type = 3)
			post_data["category_id"] = to_str(category_template.category_id)
			brand_id = category_template.get("brand_id")
			if brand_id and brand_id != "0":
				post_data["brand_id"] = brand_id
			post_data["product_attributes"] = product_attributes
			if category_template.exemption_of_identifier_code:
				exemption_data = dict()
				exemption_data["exemption_reason"] = [category_template.exemption_of_identifier_code]
				post_data["exemption_of_identifier_code"] = exemption_data
			if category_template.product_certifications:
				post_data["product_certifications"] = category_template.product_certifications
			if category_template.size_chart_id:
				size_chart_data = dict()
				size_chart_data["img_id"] = category_template.size_chart_id
				post_data["size_chart"] = size_chart_data
			post_data["is_cod_open"] = True if category_template.get("is_cod_open") else False
		if not product.variants:
			# Currently, TikTok Shop API supports creating simple products "https://partner.tiktokshop.com/doc/page/277928"
			product_identifier = self.detect_tiktok_product_identifier(product)
			post_data["skus"] = [
				{
					"original_price": to_str(to_decimal(product.price, 2)),
					"seller_sku": product.sku[:50],
					"stock_infos": [
						{
							"available_stock": to_int(product.qty),
							"warehouse_id": warehouse_id
						}
					],
					"product_identifier_code": product_identifier,
				}
			]
			tiktok_sku_id = product.tiktok_sku_id
			if tiktok_sku_id:
				post_data["skus"][0]["id"] = tiktok_sku_id
			# return Response().error(msg = "TikTok Shop required at least one variant. Please create variants on main store!")
		else:
			if not category_template or not category_template.get("category_id"):
				return Response().error(msg = "Category template is required to publish products on TikTok Shop. Please add a category template.")
			post_data["skus"] = self.variant_to_tiktok_data(product, is_pull_from_tiktok, warehouse_id, insert)
		return Response().success(post_data)

	def detect_chinese_characters(self, text):
		import re
		chinese_characters = re.findall(r'[\u4e00-\u9fff]+', text)
		if chinese_characters:
			return True
		return False

	def variant_to_tiktok_data(self, product, is_pull_from_tiktok, warehouse_id, insert):
		skus = list()
		channel_data = product.channel.get(f'channel_{self.get_channel_id()}', {})
		variation_options = self.variants_to_option(product.variants)
		len_attributes = to_len(list(variation_options.keys()))
		product_skus = product.product_skus
		product_skus_cutoff = list(map(lambda s: to_str(s[-50:]), product_skus))
		sku_uniques = set()
		sku_duplicates = []
		for x in product_skus_cutoff:
			if x in sku_uniques:
				sku_duplicates.append(x)
			else:
				sku_uniques.add(x)
		for index, variant in enumerate(product.variants):
			tiktok_variant_data = dict()
			cate_template_data = variant.get("templates").get("category")
			variant_cate_tmpl_data = variant.template_data.get("category", {})
			cate_specifics = self.mapping_attributes(variant_cate_tmpl_data.get("specifics"), variant_cate_tmpl_data.get("product_attributes"))
			sales_attributes = self.get_mapping_attributes_by_type(cate_specifics, attr_type = 2, index = index)
			if not sales_attributes:
				tiktok_attributes = variant.get("tiktok_attributes", [])
				for attribute in tiktok_attributes:
					attribute_data = {
						"attribute_id": attribute["id"],
						"attribute_name": attribute["attribute_name"],
						"custom_value": attribute.get("attribute_value_name")
					}
					sales_attributes.append(attribute_data)
			# sales_attributes = list()
			# if not cate_template_data and (is_pull_from_tiktok or not insert):
			# 	variant_cate_tmpl_data = variant.template_data.get("category", {})
			# 	cate_specifics = self.mapping_attributes(variant_cate_tmpl_data.get("specifics"), variant_cate_tmpl_data.get("product_attributes"))
			# 	sales_attributes = self.get_mapping_attributes_by_type(cate_specifics, attr_type = 2, index = index)
			# 	if not sales_attributes:
			# 		tiktok_attributes = variant.get("tiktok_attributes", [])
			# 		for attribute in tiktok_attributes:
			# 			attribute_data = {
			# 				"attribute_id": attribute["id"],
			# 				"attribute_name": attribute["attribute_name"],
			# 				"custom_value": attribute.get("attribute_value_name")
			# 			}
			# 			sales_attributes.append(attribute_data)
			# else:
			# 	variant_cate_tmpl_data = variant.template_data.category
			# 	cate_specifics = self.mapping_attributes(variant_cate_tmpl_data.get("specifics"), variant_cate_tmpl_data.get("product_attributes"))
			# 	sales_attributes = self.get_mapping_attributes_by_type(cate_specifics, attr_type = 2, index = index)
			try:
				if sales_attributes:
					if len_attributes == 1:
						variant_image = variant.thumb_image.url
						if variant_image:
							tiktok_variant_image = self.create_tiktok_image(variant_image, 3)
						else:
							tiktok_variant_image = False
						if tiktok_variant_image:
							sales_attributes[0]["sku_img"] = {"id": tiktok_variant_image[0].get("id")}
					if len_attributes > 1:
						for sale_attribute in sales_attributes:
							if channel_data.get("tiktok_variant_images"):
								attribute = channel_data['tiktok_variant_images']['attribute']
								option_images = channel_data['tiktok_variant_images']['options']
								for option_image in option_images:
									if sale_attribute.get("attribute_name") == attribute and option_image["name"] == sale_attribute.get("custom_value"):
										tiktok_variant_image = self.create_tiktok_image(option_image.image, 3)
										if tiktok_variant_image:
											sale_attribute["sku_img"] = {"id": tiktok_variant_image[0].get("id")}
			except:
				self.log_traceback()
			variant_sku = variant.sku
			if len(variant_sku) > 50 and variant_sku[-50:] in sku_duplicates:
				variant_sku_gen = random_string(16)
			else:
				variant_sku_gen = variant_sku[-50:]
			tiktok_sku_id = variant.get("tiktok_sku_id")
			if tiktok_sku_id:
				tiktok_variant_data["id"] = tiktok_sku_id
			tiktok_variant_data["seller_sku"] = variant_sku_gen
			tiktok_variant_data["original_price"] = to_str(to_decimal(variant.price, 2))
			tiktok_variant_data["stock_infos"] = [
				{
					"available_stock": to_int(variant.qty),
					"warehouse_id": warehouse_id
				}
			]
			tiktok_variant_data["product_identifier_code"] = self.detect_tiktok_product_identifier(variant)
			tiktok_variant_data["sales_attributes"] = sales_attributes
			skus.append(tiktok_variant_data)
		return skus

	def channel_assign_category_template(self, product, template_data):
		"""
		func choose mapping and override data from the category template
		"""
		item_specifics = template_data.get('specifics')
		product_attributes = template_data.get("product_attributes")
		if not item_specifics:
			return product
		for index, specific in enumerate(item_specifics):
			status_changed = False
			product_type = product_attributes[index].get("attribute_type")
			if not specific.override and not specific.mapping:
				continue
			if specific.override:
				value = specific.override
			else:
				status_changed = True
				value = specific.mapping
			if status_changed:
				specific.value = self.assign_attribute_to_field(value, product)
				if specific.value:
					specifics_value = specific.value.split(",")
					if len(specifics_value) > 1:
						specifics_value = [{"value_id": "", "value_name": value} for value in specifics_value]
						specific.value = specifics_value
			else:
				if product_type == 2:
					value = self.assign_attribute_to_field(value, product)
				specific.value = value
		product.channel[f"channel_{self.get_channel_id()}"]["template_data"]["category"]["specifics"] = item_specifics
		return product

	def channel_assign_shipping_template(self, product, template_data):
		dimensions = template_data.get('dimensions')
		weight_unit = template_data.get('weight_unit')
		dimension_unit = template_data.get('dimension_unit')
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['weight_unit'] = weight_unit
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['dimension_unit'] = dimension_unit
		if not dimensions:
			return product
		for dimension in dimensions:
			if dimension['name'] not in ['length', 'weight', 'width', 'height']:
				continue
			if dimension.get('override'):
				value = dimension['override']
			else:
				value = dimension['mapping']
			if not value:
				dimension['value'] = self.FIELD_EMPTY
				product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = self.FIELD_EMPTY
			else:
				value = self.assign_attribute_to_field(value, product)
				if to_decimal(value):
					dimension['value'] = to_decimal(value)
					product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = to_decimal(value)
				else:
					dimension['value'] = self.FIELD_EMPTY
					product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = self.FIELD_EMPTY

		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['dimensions'] = dimensions
		return product

	def convert_specific_value(self, value):
		from ast import literal_eval
		try:
			value = literal_eval(value)
			return value
		except:
			self.log_traceback()
			return value

	def detect_tiktok_product_identifier(self, product):
		product_identifier = dict()
		for ident_key, ident_type in self.PRODUCT_IDENTIFIER_CHOICES.items():
			if product.get(ident_type):
				product_identifier["identifier_code"] = product.get(ident_type).strip()
				product_identifier["identifier_code_type"] = ident_key
				break
		# product_identifier["type"] = ident_type
		return product_identifier

	def mapping_attributes(self, specifics, product_attributes):
		"""
			function mapping product_attributes with specifics
		"""
		return_data = list()
		try:
			for specific in specifics:
				if specific.get("name", "").lower() == "colour":
					specific["name"] = "Color"
			for attribute in product_attributes:
				if attribute.get("attribute_name", "").lower() == "colour":
					attribute["attribute_name"] = "Color"
			for specific in specifics:
				for attribute in product_attributes:
					if specific["name"] == attribute["attribute_name"]:
						return_data.append({**specific, **attribute})
			return return_data
		except:
			self.log_traceback()
			return return_data

	def get_mapping_attributes_by_type(self, specifics, attr_type = None, index = 0):
		"""
			attr_type = 2 -> SALES ATTRIBUTES
			attr_type = 3 -> PRODUCT ATTRIBUTES
		"""
		attributes = list()
		for specific in specifics:
			if specific["attribute_type"] == attr_type and attr_type == 2 and specific["value"]:
				attributes.append({
					"attribute_id": specific["attribute_id"],
					"attribute_name": specific["attribute_name"],
					"custom_value": specific["value"]
				})
			if specific["attribute_type"] == attr_type and attr_type == 3:
				try:
					specific_values = specific.get("value", [])
					for value in specific_values:
						# only accept value_id is numeric
						if value.get("value_id") and not value.get("value_id", "").isnumeric():
							del value["value_id"]
				except:
					self.log_traceback()
				attributes.append({
					"attribute_id": specific["attribute_id"],
					"attribute_name": specific["attribute_name"],
					"attribute_values": specific["value"]
				})
			if not attr_type:
				attributes.append({
					"attribute_id": specific["attribute_id"],
					"attribute_name": specific["attribute_name"],
					"attribute_values": specific["value"]
				})
		return attributes

	def after_product_import(self, product_id, convert: Product, product, products_ext):
		product_id = to_str(product_id)
		params = {
			"product_id": product_id
		}
		detail_product_api = self.api("products/details", params = params)
		variants = detail_product_api["data"]["skus"]
		product_status = detail_product_api["data"].get("product_status")
		self._tiktok_product_status = product_status
		if product.variants:
			for index, variant in enumerate(variants):
				self._extend_product_map["tiktok_sku_id"] = variant.id
				child = product.variants[index]
				self.insert_map_product(child, child["_id"], variant.id)
		else:
			self._extend_product_map["tiktok_sku_id"] = variants[0].id
		return Response().success()

	def extend_data_insert_map_product(self):
		extend = super().extend_data_insert_map_product()
		region = self.get_seller_base_region()
		extend["region"] = region
		tiktok_status = self._tiktok_product_status
		if not tiktok_status or tiktok_status == "0":
			extend["tiktok_status"] = "pending"
		if tiktok_status and tiktok_status != self.TIKTOK_PRODUCT_STATUS.get("active"):
			extend["tiktok_status"] = self.convert_product_status(self._tiktok_product_status)
		return extend

	def product_channel_update(self, product_id, product: Product, products_ext):
		# self.channel_sync_inventory(product_id, product, products_ext)
		# return Response().success()
		convert_product = self.product_to_tiktok_data(product, products_ext, insert = False)
		if convert_product.result.lower() != Response().SUCCESS:
			return convert_product
		category_template = product.template_data.category
		product_attributes = category_template.product_attributes
		variation_options = self.variants_to_option(product.variants)
		len_variant_attributes = to_len(list(variation_options.keys()))
		len_sale_attributes = to_len([item for item in product_attributes if item["attribute_type"] == 2])
		is_equal_attribute = len_variant_attributes == len_sale_attributes
		product_data = convert_product.data
		payload = product_data
		payload["product_id"] = product_id
		update = self.api("products", body = payload, method = "put")
		if update and isinstance(update, dict):
			msg = update.get("message")
			if msg.find("The SKU contains duplicate sales attribute") != -1 and is_equal_attribute:
				return Response().error(msg = "TIKTOK_MISSING_SALE_ATTRIBUTE")
		update_response = self.check_response_import(update, product, "product")
		if update_response["result"].lower() != Response().SUCCESS:
			return update_response
		return Response().success()

	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		tiktok_product = self.get_product_by_id(product_id)
		if tiktok_product.result != Response().SUCCESS:
			return Response().error(msg = "Error get product while sync")
		product_tiktok_data = tiktok_product.data
		# Only sync product active
		if product_tiktok_data.get("product_status") != self.TIKTOK_PRODUCT_STATUS["active"]:
			return Response().success()
		tiktok_variants = {row["id"]: row for row in product_tiktok_data.skus}
		shipping_template = product.template_data.get("shipping")
		warehouse_id = shipping_template.get("warehouse_id") or self.get_default_warehouse()
		if not product.variants:
			default_tiktok_variant = product_tiktok_data.skus[0]
			if setting_qty:
				update_qty = self.set_inventory_qty(product_id, default_tiktok_variant.id, product.qty, warehouse_id)
				if update_qty and update_qty["message"].lower() != Response().SUCCESS:
					return Response().error(msg = update_qty["message"])
			if setting_price:
				update_price = self.set_inventory_price(product_id, default_tiktok_variant.id, product.price)
				if update_price and update_price["message"].lower() != Response().SUCCESS:
					return Response().error(msg = update_price["message"])
		else:
			channel_id = self._state.channel.id
			for variant in product.variants:
				variant_id = variant["channel"].get(f"channel_{channel_id}", {}).get("product_id")
				if not variant_id:
					continue
				if setting_qty and tiktok_variants.get(variant_id):
					update_qty = self.set_inventory_qty(product_id, tiktok_variants[variant_id].id, variant.qty, warehouse_id)
					if update_qty and update_qty["message"].lower() != Response().SUCCESS:
						return Response().error(msg = update_qty["message"])
				if setting_price and tiktok_variants.get(variant_id):
					update_price = self.set_inventory_price(product_id, tiktok_variants[variant_id].id, variant.price)
					if update_price and update_price["message"].lower() != Response().SUCCESS:
						return Response().error(msg = update_price["message"])

		return Response().success(product)

	def get_total_product(self, status = 4):
		# For detail status https://partner.tiktokshop.com/doc/page/262788?onlySelectedDir=13589
		body = {
			# required
			"search_status": status,
			"page_size": 0,
			"page_number": 1
		}
		products_api = self.api("products/search", body = body, method = "post")
		if products_api and products_api["message"].lower() == Response().SUCCESS:
			self._total_number_products = products_api.data.total
		else:
			return Response().error(msg = "Could not get products from tiktok")
		return self._total_number_products

	def get_total_number_orders(self, filter_condition = None):
		if self._total_number_orders:
			return self._total_number_orders
		body = {
			"page_size": 10
		}
		if filter_condition:
			body = {**body, **filter_condition}
		orders_api = self.api("orders/search", body = body, method = "post")
		if orders_api and orders_api["message"].lower() == Response().SUCCESS:
			self._total_number_orders = orders_api["data"]["total"]
		else:
			return Response().error(msg = "Could not get orders from tiktok")
		return self._total_number_orders

	def get_product_identifier(self, identifier_code_type):
		"""
		Code type value: 1 - GTIN、2 - EAN、3 - UPC、4 - ISBN(input one of them to this field)
		For detail: https://partner.tiktokshop.com/doc/page/262789#Back%20To%20Top
		"""
		product_identifier_choices = self.PRODUCT_IDENTIFIER_CHOICES
		ident = ""
		if identifier_code_type:
			ident = product_identifier_choices[identifier_code_type]
		return ident

	@staticmethod
	def get_tiktok_leaf_cate(cate_list):
		# Category must be leafing
		for cate in cate_list:
			if cate["is_leaf"]:
				return {"id": cate["id"], "name": cate["local_display_name"]}

	@staticmethod
	def convert_product_attributes(product_attributes):
		if product_attributes:
			for attribute in product_attributes:
				values = attribute.get("values", [])
				for value in values:
					if not ("id" and "name") in value.keys():
						continue
					else:
						value["value_id"] = value["id"]
						value["value_name"] = value["name"]
						try:
							del value["id"]
							del value["name"]
						except:
							continue
				if "values" not in attribute.keys():
					continue
				attribute["option_values"] = attribute["values"]
				try:
					del attribute["values"]
				except:
					continue
			return product_attributes
		return []

	@staticmethod
	def product_has_variants(skus):
		# return True
		has_variants = True
		if len(skus) > 1:
			return has_variants
		default_variant = skus[0]
		if default_variant["sales_attributes"][0]["name"].lower() == "specification" and default_variant["sales_attributes"][0]["value_name"].lower() == "default":
			has_variants = False
		return has_variants

	@staticmethod
	def convert_weight_to_kg(weight, unit):
		weight_unit_to_kg = {
			"lb": 0.45359237,
			"lbs": 0.45359237,
			"g": 0.001,
			"oz": 0.02834952
		}
		if unit.lower() in ["", "kg", "kgs"]:
			result = weight
		else:
			result = weight * to_decimal(weight_unit_to_kg[unit.lower()])
		return to_str(to_decimal(result, 2))

	@staticmethod
	def convert_dimensions_to_cm(dimension, unit):
		if unit.lower() in ["inch", "in", "inches"]:
			result = dimension * 2.54
		elif unit.lower() == "m":
			result = dimension * 100
		elif unit.lower() == "mm":
			result = dimension * 0.1
		else:
			result = dimension
		return to_int(result)

	def create_tiktok_image(self, images, img_scene = 1, retry = 0):
		"""
		1:"PRODUCT_IMAGE" The ratio of horizontal and vertical is recommended to be 1:1
		2:"DESCRIPTION_IMAGE"
		3:"ATTRIBUTE_IMAGE " The ratio of horizontal and vertical is recommended to be 1:1
		4:"CERTIFICATION_IMAGE"
		5:"SIZE_CHART_IMAGE"
		"""
		return_data = list()
		if not isinstance(images, list):
			images = [images]
		for image in images:
			img_data = self.resize(image, img_scene)
			post_data = {
				"img_data": img_data,
				"img_scene": img_scene
			}
			if retry:
				time.sleep(1)
			img_api = self.api("products/upload_imgs", body = post_data, method = "post")
			if img_api and img_api["message"].lower() == Response().SUCCESS:
				img_data = img_api.data
				return_data.append({"id": img_data.img_id, "url": img_data.img_url, "width": img_data.img_width, "height": img_data.img_height, "origin": image})
		if not return_data and retry <= 5:
			return self.create_tiktok_image(images, img_scene, retry + 1)
		return return_data

	def convert_image_to_base64(self, img_url):
		try:
			return base64.b64encode(requests.get(img_url).content).decode("utf8")
		except:
			self.log_traceback()
			return img_url

	def convert_image_file_to_base64(self, image, is_png = False):
		buffered = BytesIO()
		image.save(buffered, format = "JPEG" if not is_png else "PNG")
		img_size = len(buffered.getvalue())
		img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
		return img_str

	def convert_ms_timestamp_to_datetime(self, time_data, format = "%Y-%m-%d %H:%M:%S"):
		"""
		Convert unix timestamp for ms to date time
		TikTok shop return some data as ms unix timestamp
		"""
		time_data = to_int(time_data) / 1000
		try:
			timestamp = datetime.fromtimestamp(time_data)
			res = timestamp.strftime(format)
			return res
		except Exception:
			log_traceback()
			return get_current_time(format)

	def extend_images(self, product):
		images = list()
		if product.thumb_image.url:
			main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			images.append(main_image['url'])
		for index, img_src in enumerate(product.images):
			# TikTok only accepts up to 9 images
			if index >= 9:
				break
			image_process = self.process_image_before_import(img_src.url, img_src.path)
			if image_process['url'] not in images:
				images.append(image_process['url'])
		return images

	def get_product_category_rules(self, category_id):
		params = {
			"shop_id": self.get_shop_id(),
			"category_id": category_id
		}
		cate_rules = self.api("products/categories/rules", params = params)
		if not cate_rules:
			return Response().error(msg = "Could not get category rules")
		return cate_rules["data"]["category_rules"][0]

	def get_default_warehouse_id(self):
		return self._state.channel.config.api.warehouse_id

	def get_default_warehouse(self):
		if self._ware_house_id:
			return self._ware_house_id
		warehouses = self.api("logistics/get_warehouse_list")
		if warehouses and warehouses["message"].lower() == Response().SUCCESS:
			warehouse_list = warehouses.data.warehouse_list
			for warehouse in warehouse_list:
				if warehouse.is_default:
					self._ware_house_id = warehouse.warehouse_id
					return self._ware_house_id
		return Response().error(msg = "Could not get warehouse location")

	def set_product_pull_type(self):
		product_status = self._product_pull_type
		product_next_type = {
			"active": "draft",
			"draft": "pending",
			"pending": "failed",
			"failed": "inactive",
			"inactive": "freeze",
			"freeze": ""
		}
		self._product_pull_type = product_next_type.get(product_status, "")

	def set_imported_product(self, imported):
		if self._product_pull_type == 'active':
			self._state.pull.process.products.imported += imported
		else:
			if not self._state.pull.process.products.get(f'imported_{self._product_pull_type}'):
				self._state.pull.process.products[f'imported_{self._product_pull_type}'] = 0
			self._state.pull.process.products[f'imported_{self._product_pull_type}'] += imported

	def custom_tiktok_response(self, code):
		custom_response = {
			"12019074": "Invalid number of digits of identifier code. Please follow the rules (GTIN: 14 digits, EAN: 8/13/14 digits, UPC: 12 digits, ISBN: 13 digits)",
			# "12019030": "The sale attribute should not be empty.",
			"12019068": "TikTok only allows you to create 200 products per day via api.",
			"12019000": "TikTok system error, try again later.",
			"12019012": "Product package size is invalid. Please enter correct package size.",
			"12019011": "Product package weight is invalid. Please enter correct package weight."
			# "12019030": "Colour attribute is required."
		}
		return custom_response.get(to_str(code), "")

	def check_response_import(self, response, convert, entity_type = ""):
		entity_id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and response.get("message").lower() != Response().SUCCESS:
			console = list()
			if isinstance(response, dict) or isinstance(response, Prodict):
				for key, error in response.items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(to_str(key) + ': ' + to_str(error_messages))
			else:
				console.append(response)
			log_msg_errors = ' '.join(console)
			code = response.get("code")
			display_msg_errors = self.custom_tiktok_response(code) or response.get("message")
			self.log(entity_type + ' id ' + to_str(entity_id) + ' import failed. Error: ' + log_msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error(msg = display_msg_errors)
		else:
			return Response().success()

	def set_inventory_price(self, product_id, sku_id, price):
		body = {
			"product_id": to_str(product_id),
			"skus": [
				{
					"id": to_str(sku_id),
					"original_price": to_str(price)
				}
			]
		}
		response = self.api("products/prices", body = body, method = "put")
		return response

	def set_inventory_qty(self, product_id, sku_id, qty, warehouse_id):
		body = {
			"product_id": to_str(product_id),
			"skus": [
				{
					"id": to_str(sku_id),
					"stock_infos": [
						{
							"available_stock": to_int(qty),
							"warehouse_id": warehouse_id
						}
					]
				}
			]
		}
		response = self.api("products/stocks", body = body, method = "put")
		return response

	def get_orders_main_export(self):
		if self._flag_finish_order:
			return Response().finish()
		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0
		limit_data = self._state.pull.setting.orders
		start_time = self.get_order_start_time()
		last_modifier = self._state.pull.process.orders.max_last_modified
		orders_filter_condition = {
			"create_time_from": to_timestamp(start_time),
			"page_size": limit_data  # limit_data,
		}
		if last_modifier:
			orders_filter_condition["update_time_from"] = to_timestamp(last_modifier)
		if self._next_cursor_order:
			orders_filter_condition["cursor"] = self._next_cursor_order
		orders_api = self.api("orders/search", body = orders_filter_condition, method = "post")
		self._next_cursor_order = orders_api.data.next_cursor
		if not self._next_cursor_order or not orders_api.data.more:
			self._flag_finish_order = True
		if not orders_api["data"]:
			return Response().error(msg = "Could not get orders from tiktok")
		return Response().success(data = orders_api["data"]["order_list"])

	def get_orders_ext_export(self, orders):
		extend = Prodict()
		order_id_list = [order.order_id for order in orders]
		body = {"order_id_list": order_id_list}
		params = {"version": 202305}
		orders_detail = self.api("orders/detail/query", params = params, body = body, method = "post")
		if orders_detail and orders_detail["message"].lower() == Response().SUCCESS:
			order_detail_list = orders_detail["data"]["order_list"]
			for order_detail in order_detail_list:
				order_id = order_detail.order_id
				extend.set_attribute(to_str(order_id), Prodict())
				extend[to_str(order_id)] = order_detail
			return Response().success(extend)
		return Response().error("Could not get order detail")

	def get_order_by_id(self, order_id):
		body = {
			"order_id_list": [order_id]
		}
		params = {"version": 202305}
		order_response = self.api("orders/detail/query", params = params, body = body, method = "post")
		if order_response and order_response["message"].lower() == Response().SUCCESS:
			return Response().success(order_response["data"]["order_list"][0])
		return Response().error(msg = "Get order from tiktok failed")

	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.order_id

	def convert_order_status(self, status):
		tiktok_order_status = self.TIKTOK_ORDER_STATUS.get(status, Order.OPEN)
		warehouse_order_status = self.ORDER_STATUS.get(tiktok_order_status, Order.OPEN)
		return warehouse_order_status

	def get_state_code_from_name(self, name):
		if name:
			for code, state_name in self.STATES.items():
				if to_str(name).lower() == to_str(state_name).lower():
					return code
		return name

	def _convert_format_time(self, epoch_seconds):
		return convert_format_time(time_data = to_int(epoch_seconds) - 25200, old_format = 'timestamp')

	def combine_order_items(self, order_line_list):
		combined_order_items = Prodict()
		for item in order_line_list:
			sku_id = item["sku_id"]
			if sku_id in combined_order_items:
				combined_order_items[sku_id]["quantity"] += 1
			else:
				combined_order_items[sku_id] = item
				combined_order_items[sku_id]["quantity"] = 1

		return list(combined_order_items.values())

	def convert_order_export(self, order, orders_ext, channel_id = None):
		update_time = self._convert_format_time(order.update_time)
		self.set_order_max_last_modifier(convert_format_time(order.update_time))
		order_data = Order()
		order_id = order.order_id
		order_detail = orders_ext.get(order_id, {})
		# Skip unpaid order because the order does not have an address.
		unpaid_status = 100
		if to_int(order_detail.order_status) == to_int(unpaid_status):
			return Response().skip()
		order_data.id = order_id
		order_data.order_number = order_id
		order_data.status = self.convert_order_status(order.order_status)
		order_data.tax.amount = order_detail.payment_info.taxes
		delivery_option_type = order_detail.delivery_option_type
		order_data.shipping.title = "SHIPPED BY SELLER" if to_int(delivery_option_type) == self.SEND_BY_SELLER else "SHIPPED BY TIKTOK"
		order_data.shipping.amount = to_decimal(order_detail.payment_info.original_shipping_fee)
		order_data.total = to_decimal(order_detail.payment_info.total_amount)
		order_data.currency = order_detail.payment_info.currency
		order_data.created_at = self._convert_format_time(to_int(to_int(order_detail.create_time) / 1000))
		order_data.updated_at = update_time
		seller_discount = to_decimal(order_detail.payment_info.get("seller_discount"))
		shipping_fee_seller_discount = to_decimal(order_detail.payment_info.get("shipping_fee_seller_discount"))
		platform_discount = to_decimal(order_detail.payment_info.get("platform_discount"))
		shipping_fee_platform_discount = to_decimal(order_detail.payment_info.get("shipping_fee_platform_discount"))
		order_data.discount.amount = seller_discount + platform_discount + shipping_fee_seller_discount + shipping_fee_platform_discount
		order_data.channel_data = {
			"order_status": self.convert_order_status(order_detail.order_status),
			"created_at": order_data.created_at,
			"order_id": order_id
		}
		# Customer
		order_data.customer.id = order_detail.buyer_uid
		order_ship = order_detail.recipient_address
		first_name, last_name = self.split_customer_fullname(order_ship.name)
		order_data.customer.first_name = first_name
		order_data.customer.last_name = last_name
		order_data.customer.email = order_detail.buyer_email
		order_data.customer.telephone = order_ship.phone
		order_data.customer.username = order_ship.name
		if not order_data.customer.username:
			self.log_response(order_detail, "order_without_buyer_info")
		# Customer, billing, shipping address
		address = OrderAddress()
		district_info_list = order_detail.get("district_info_list")
		state = ""
		county = ""
		district = ""
		city = ""
		for item in district_info_list:
			address_level = item.address_level_name.lower()
			if address_level == "state":
				state = item.address_name
			if address_level == "county":
				county = item.address_name
			if address_level == "city":
				city = item.address_name
			if address_level == "district":
				district = item.address_name

		# address_line_list = order_ship.address_line_list
		address_1 = order_ship.addressline1
		address_2 = order_ship.addressline2 + "\n" + order_ship.addressline3 + "\n" + order_ship.addressline4
		address.telephone = order_ship.phone
		address.address_1 = address_1
		address.address_2 = address_2
		address.last_name = last_name
		address.first_name = first_name
		address.city = city
		if self.is_uk():
			address.city = city or district or county
		address.postcode = order_ship.zipcode
		address.country.country_name = order_ship.region
		address.country.country_code = order_ship.region_code
		if state:
			address.state.state_code = self.get_state_code_from_name(state)
		else:
			address.state.state_code = self.get_state_code_from_name(county)
		address.state.state_name = state
		order_data.shipping_address.update(address)
		order_data.billing_address.update(address)
		order_data.customer_address.update(address)
		# Order product
		order_item_list = order_detail.order_line_list
		order_combine_item = self.combine_order_items(order_item_list)
		subtotal_order = 0
		if order_item_list:
			for item in order_combine_item:
				if item.is_gift:
					order_history = OrderHistory()
					gift_msg_note = f"""
						Order includes gift product: {item.product_name} - SKU: {item.seller_sku}					
					"""
					order_history.comment = gift_msg_note
					order_history.staff_note = True
					order_data.history.append(order_history)
					if to_len(order_item_list) > 1:
						continue
				order_item = OrderProducts()
				if item.sku_name == "Default":
					order_item.product_id = item.product_id
				else:
					order_item.product_id = item.sku_id
				order_item.listing_id = item.product_id
				order_item.product_sku = item.seller_sku
				order_item.product_name = item.product_name + " / " + item.sku_name
				order_item.qty = item.quantity
				order_item.price = item.original_price
				order_item.discount_amount = to_decimal(item.platform_discount) + to_decimal(item.seller_discount)
				order_item.subtotal = to_decimal(item.original_price) * to_int(order_item.qty)
				order_item.total = to_decimal(item.original_price) * to_int(order_item.qty)
				order_data.products.append(order_item)
				subtotal_order += to_decimal(item.original_price) * to_int(order_item.qty)
		order_data.subtotal = subtotal_order
		# Shipment
		order_shipment = Shipment()
		order_shipment.tracking_number = order_detail.tracking_number
		order_shipment.tracking_company = order_detail.shipping_provider
		order_data.shipments = order_shipment
		# History
		order_history = OrderHistory()
		if order_detail.buyer_message:
			order_history.comment = order_detail.buyer_message
			if self._state.channel.config.api.buyer_message_to_staff_note:
				order_history.staff_note = True
			order_data.history.append(order_history)
		if order_detail.seller_note:
			order_history.comment = order_detail.seller_note
			order_history.staff_note = True
			order_data.history.append(order_history)
		self.log(msg = order_detail, log_type = "convert_order_export")
		return Response().success(order_data)

	def order_sync_inventory(self, order: Order, setting_order):
		return Response().success()

	def get_reverse_reason(self, reverse_action_type = 1, order_status = 100):
		"""
		Available value:
		CANCEL = 1;
		REFUND = 2;
		RETURN_AND_REFUND = 3;
		REQUEST_CANCEL_REFUND = 4;
		"""
		params = {"reverse_action_type": reverse_action_type}
		reasons_api = self.api("reverse/reverse_reason/list", params = params)
		reasons = reasons_api["data"]["reverse_reason_list"]
		result = list()
		for reason in reasons:
			if reason.get("available_order_status_list") and order_status in reason.get("available_order_status_list"):
				result.append(reason)
		return result

	def set_cancel_reason(self):
		reason = "seller_cancel_reason_wrong_price"
		seller_base_region = self.get_seller_base_region()
		if seller_base_region.lower() == "gb":
			reason += "_uk"
		return reason

	# def channel_order_canceled(self, order_id, order: Order, current_order):
	# 	body = {
	# 		"order_id": to_str(order_id),
	# 		"cancel_reason_key": self.set_cancel_reason()
	# 	}
	# 	order_canceled = self.api("reverse/order/cancel", body = body, method = "post")
	# 	if order_canceled and order_canceled["message"].lower() == Response().SUCCESS:
	# 		return Response().success()
	# 	return Response().error(msg = "Cancel order failed")

	def map_tracking_company(self, mapping_company, tiktok_shipping_provider):
		for provider, provider_id in tiktok_shipping_provider.items():
			if self.name_to_code(provider) == self.name_to_code(mapping_company):
				return provider_id
		return ""

	def is_carrier_mapping(self) -> bool:
		other_settings = self._state.channel.config.setting.get('other_setting')
		if isinstance(other_settings, dict) and isinstance(other_settings.get('carrier_mapping'), dict):
			return bool(other_settings.carrier_mapping.get('status') == 'enable')

		return False

	def get_company_mapping(self) -> list:
		if self.is_carrier_mapping():
			carrier_mapping = self._state.channel.config.setting.other_setting.carrier_mapping.get('company_mapping')
			if not isinstance(carrier_mapping, list):
				carrier_mapping = []
			return carrier_mapping

		return []

	def get_shipping_provider_from_company(self, tracking_company, tracking_company_code):
		if not tracking_company or not tracking_company_code:
			return ""
		if self.is_us():
			tiktok_shipping_provider = self.MAPPING_CARRIER_US
		else:
			tiktok_shipping_provider = self.MAPPING_CARRIER_UK
		enable_carrier_mapping = self.is_carrier_mapping()
		if enable_carrier_mapping:
			company_mapping = self.get_company_mapping()
			for carrier in company_mapping:
				if self.name_to_code(carrier["main_company"]) in [self.name_to_code(tracking_company), self.name_to_code(tracking_company_code)]:
					return self.map_tracking_company(carrier["channel_company"], tiktok_shipping_provider)
		# if " UK" or "UK " in tracking_company:
		# 	tracking_company = tracking_company.replace("UK", "")
		# if " US" or "US " in tracking_company:
		# 	tracking_company = tracking_company.replace("US", "")
		if "usps" in tracking_company.lower():
			tracking_company = "USPS"
		if "ups" in tracking_company.lower():
			tracking_company = "UPS"
		for provider, provider_id in tiktok_shipping_provider.items():
			if tracking_company.strip().lower() == provider.strip().lower():
				return provider_id
		return ""

	def channel_order_completed(self, order_id, order: Order, current_order):
		try:
			tiktok_order = self.get_order_by_id(order_id)
			tracking_number = order.shipments.get("tracking_number")
			tracking_company = to_str(order.shipments.get("tracking_company"))
			tracking_company_code = to_str(order.shipments.get("tracking_company_code"))
			self.log_response(tiktok_order, "tiktok_order_ff")
			self.log_response(order, "order_ff")


			if tiktok_order.result == Response().SUCCESS:
				tiktok_order_data = tiktok_order.get("data")
				tiktok_order_status = tiktok_order_data.get('order_status')
				if to_int(tiktok_order_status) == 140:
					return Response().success({'status': Order.COMPLETED})

				# Only submit tracking number with option SEND_BY_SELLER and status is 111: AWAITING_SHIPMENT
				if to_int(tiktok_order_data.get("delivery_option_type")) == to_int(self.SEND_BY_SELLER) and tiktok_order_status == 111:
					package_id = tiktok_order_data.package_list[0].get("package_id")
					shipping_provider_id = self.get_shipping_provider_from_company(tracking_company, tracking_company_code)
					if not shipping_provider_id:
						self.log_response(tracking_company, "not_support_shipping_provider")
						return Response().error(msg = "Your shipping carrier is not supported by TikTok Shop")
					body = dict()
					body["package_id"] = package_id
					body["self_shipment"] = {
						"tracking_number": tracking_number,
						"shipping_provider_id": shipping_provider_id
					}
					ship_package = self.api("fulfillment/rts", body = body, method = "post")
					if ship_package and ship_package["message"].lower() == Response().SUCCESS:
						self.log_response(body, "tiktok_fulfill_success")
						return Response().success({'status': Order.COMPLETED})
					self.log_response(body, "tiktok_fulfill_error")
					return Response().error()
		except:
			self.log_traceback()
			return Response().error()


	def channel_order_is_completed(self, order_id):
		try:
			order_res = self.get_order_by_id(order_id)
			if order_res.result == Response.SUCCESS:
				tiktok_order = order_res.data
				if tiktok_order and not tiktok_order.get('shipping_provider_id'):
					return False
		except:
			self.log_traceback()
			return True
		return True