import io
import re

import math

import pandas as pandas
import requests

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel, to_str, Prodict
from datasync.models.constructs.activity import Activity
from datasync.models.constructs.order import Order
from datasync.models.constructs.product import Product, ProductVariant, ProductImage, ProductVariantAttribute, ProductAttribute
from datasync.models.constructs.state import EntityProcess
from datasync.models.modes.test import ModelModesTest


class CsvFile():
	_mapping: dict


	def __init__(self, **kwargs):
		self._csv_data = None
		self._format = kwargs.get('format')
		self._mapping = kwargs.get('mapping')
		self._delimiter = kwargs.get('delimiter', ',')
		self._error = None
		self._encoding = None


	def is_litcommerce_template(self):
		return self._format == 'litc'


	def construct_products_csv_file(self):
		title = "sku,parent_sku,name,description,qty,brand,condition,condition_note,price,msrp,seo_url,manufacturer,mpn,upc,ean,isbn,gtin,gcid,asin,epid,height,length,width,dimension_units,weight,weight_units,variation_1,variation_2,variation_3,variation_4,variation_5,product_image_1,product_image_2,product_image_3,product_image_4,product_image_5,product_image_6,product_image_7,product_image_8,product_image_9,product_image_10,attributes,categories"
		return title.split(',')


	def get_file_title(self):
		file_content = self.get_csv_data()
		return list(file_content[0].keys())


	def validate_file(self, file_content = None, setup = False):
		if not file_content:
			file_content = self.get_csv_data(setup)
		if not file_content:
			if self._error:
				return self._error
			return Response().error(Errors.CSV_FILE_NOT_MATCH)
		if self.is_litcommerce_template():
			first_line = list(file_content[0].keys())
			csv_title_default = self.construct_products_csv_file()
			csv_diff = list(set(csv_title_default) - set(first_line))
			if csv_diff and (len(csv_diff) > 1 or csv_diff[0] != 'product_id'):
				return Response().error(Errors.CSV_FILE_NOT_MATCH)
			return Response().success()
		return self.validate_file_with_mapping(file_content)


	def validate_file_with_mapping(self, file_content = None):
		if not file_content:
			file_content = self.get_csv_data()
		if not file_content:
			return Response().error(Errors.CSV_FILE_NOT_MATCH)
		first_line = list(map(lambda x: to_str(x).lower().strip('"').strip("'"), list(file_content[0].keys())))
		field_missing = []
		for field in self._mapping.values():
			try:
				field_mapping = to_str(field).lower().encode().decode('utf-8-sig')
			except:
				field_mapping = to_str(field).lower()
			field_mapping = field_mapping.strip('"').strip("'")
			if field_mapping not in first_line:
				field_missing.append(field)
		if not field_missing:
			return Response().success()
		return Response().error(msg = Errors().get_msg_error(Errors.CSV_FILE_MISSING_FIELD).format(','.join(field_missing)))


	def to_list(self):
		if self._csv_data:
			return self._csv_data
		file_content = self.get_csv_data()
		validate = self.validate_file(file_content)
		if validate.result != Response.SUCCESS:
			return {}
		return file_content


	def get_csv_data(self, setup = False) -> dict or None:
		if self._csv_data:
			return self._csv_data
		encoding = csv_encodings()
		read_file = self.get_file_content(setup)
		if read_file.result != Response.SUCCESS:
			self._error = read_file
			return None
		file_data = read_file.data
		csv_file_data = read_file.data
		if isinstance(file_data, bytes):
			csv_file_data = file_data.decode('utf-8')
		for encode in encoding:
			try:
				data_csv = pandas.read_csv(io.StringIO(csv_file_data), sep = self._delimiter, encoding = encode, low_memory = False, na_values = None, error_bad_lines = False, dtype={'sku': str, 'parent_sku': str})
				data_csv = data_csv.T.to_dict()
				self._csv_data = list(data_csv.values())
				return self._csv_data
			except:
				continue
		try:
			df = pandas.read_excel(io.BytesIO(csv_file_data.encode(self._encoding or 'utf-8')), engine = 'openpyxl')  # can also index sheet by name or fetch all sheets
			data_csv = df.to_dict('records')
			self._csv_data = data_csv

			return data_csv
		except Exception as e:
			pass
		return None


	def get_file_content(self, setup = False):
		return Response().success('')


class CsvFromUrl(CsvFile):
	def __init__(self, url, **kwargs):
		super().__init__(**kwargs)
		self._url = url


	def get_file_content(self, setup = False):
		try:
			content = requests.get(self._url, verify = False).content
			encoding = csv_encodings()
			data = False
			for row in encoding:
				try:
					data = content.decode(row)
					self._encoding = row
					break
				except Exception:
					continue
			if data:
				return Response().success(data)
		except Exception as e:
			return Response().error()


class CsvFromFtp(CsvFile):
	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._username = kwargs.get('user')
		self._password = kwargs.get('password')
		self._host = kwargs.get('host')
		self._host = to_str(self._host).replace('sftp://', '').replace('ftp://', '')
		self._directory = kwargs.get('directory')
		self._filename = ''
		if self._directory:
			directory = self._directory.split('/')
			self._filename = directory[-1]
			del directory[-1]
			self._directory = '/'.join(directory)


	def get_file_content(self, setup = False):
		if not self._username or not self._password or not self._host or not self._filename:
			return Response().error(msg = 'DataInvalid!')
		import socket
		import ftplib
		from io import BytesIO
		try:
			ftp = ftplib.FTP(host = self._host, user = self._username, passwd = self._password, timeout = 5)
		except socket.gaierror as e:
			return Response().error(msg = 'The host you provided is not valid. Please check again!')


		except ConnectionRefusedError as e:
			return Response().error(msg = 'We are unable to connect to the host you provided. Please check again!')


		except ftplib.error_perm as e:
			return Response().error(msg = 'Incorrect username or password.')


		except Exception as e:
			return Response().error(msg = 'We are unable to connect to the host you provided. Please check again.')

		if self._directory:
			try:
				ftp.cwd(self._directory)
			except Exception:
				return Response().error(msg = 'Directory does not exist.')

		try:
			file_size = ftp.size(self._filename)
		except Exception:
			return Response().error(msg = 'The file does not exist or does not have read permission.')
		if not setup:
			r = BytesIO()
			ftp.retrbinary(f'RETR {self._filename}', r.write)
			return Response().success(r.getvalue().decode())
		ftp.sendcmd('TYPE A')
		conn = ftp.transfercmd(f"RETR {self._filename}")
		fp = conn.makefile('rb')
		count = 0
		file_content = []
		while count < 3:
			line = fp.readline(ftp.maxline + 1)
			if not line:
				break
			file_content.append(line.decode())
			count += 1
		fp.close()
		conn.close()
		return Response().success('\n'.join(file_content))


class BaseModelChannelsFile(ModelChannel):
	TABLE_NAME = 'table_name'
	_model_local: ModelModesTest


	def __init__(self, **kwargs):

		super().__init__(**kwargs)
		self._model_local = None
		self._id_src = 0
		self._field_allow_update = []


	def get_model_local(self):
		if self._model_local:
			return self._model_local
		self._model_local = ModelModesTest()
		self._model_local.set_user_id(self._user_id)
		return self._model_local


	def get_table_name(self):
		suffix = self._sync_id or self._user_id
		return f"{self.TABLE_NAME}_{suffix}"


	def table_construct(self):
		table_product = {
			'table': self.get_table_name(),
			'rows': {
				'user_id': 'int(11)',
			}
		}
		return table_product


	def destroy_table(self):
		table = self.table_construct()
		self.get_model_local().query_raw("DROP TABLE {}".format(table['table']))


	def setup_storage_csv(self):
		self.destroy_table()
		query = self.get_model_local().dict_to_create_table_sql(self.table_construct())
		if query['result'] == 'success':
			self.get_model_local().query_raw(query['query'])
		# channel, process = self.get_model_sync_mode().get_process_file()
		# if not process.state_id:
		# 	state = SyncState()
		# 	state.channel.id = channel.id
		# 	state.channel.channel_type = channel.type
		# 	state.channel.identifier = channel.identifier
		# 	state.channel.name = channel.name
		# 	state_id = self.get_model_state().create(state)
		# 	self.set_state_id(state_id)
		# 	self.set_state(state)
		# 	self.get_model_sync_mode().save_sync(process.id, state_id = state_id)
		# self.set_sync_id(process.id)
		# self.init_state()
		return Response().success()


	def read_csv_from_url(self, csv_url, delimiter = ','):
		encoding = csv_encodings()
		read_file = requests.get(csv_url, verify = False)
		read_file_data = read_file.content
		if read_file.headers.get('content-type') == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
			df = pandas.read_excel(io.BytesIO(read_file_data), engine = 'openpyxl')  # can also index sheet by name or fetch all sheets
			data_csv = df.to_dict('records')
			return data_csv
		if read_file.headers.get('content-type') in ['text/csv', 'text/tsv']:
			for encode in encoding:
				try:
					data_csv = pandas.read_csv(io.StringIO(read_file_data.decode('utf-8')), sep = delimiter, encoding = encode, low_memory = False, na_values = None, error_bad_lines = False, dtype={'sku': str, 'parent_sku': str})
					data_csv = data_csv.T.to_dict()
					return data_csv
				except:
					self.log_traceback('read_file')
					continue

		return None


	def storage_data(self, url_file):
		csv_data = self.read_csv_from_url(url_file)
		if not csv_data:
			return Response().error()
		if isinstance(csv_data, dict):
			csv_data = list(csv_data.values())
		index = 1
		values = list()
		table = self.table_construct()
		csv_title = self.construct_products_csv_file()
		for data in csv_data:
			if not data:
				continue
			for key, value in data.items():
				if isinstance(value, float) and math.isnan(value):
					data[key] = None
			data['user_id'] = self._user_id
			if not data['sku'] and data['parent_sku']:
				data['sku'] = data['parent_sku']
				data['parent_sku'] = ''
			values.append(data)
		array_insert = split_list(values, 300)
		for row in array_insert:
			insert = self.get_model_local().insert_multiple_obj(table['table'], row)
		return Response().success()


class ModelChannelsProductFile(BaseModelChannelsFile):
	TABLE_NAME = 'products'
	PARENT_FIELD = 'parent_sku'
	CHILD_FIELD = 'sku'


	def get_csv_method(self, method):
		return f"CsvFrom{method.capitalize()}"


	def get_model_csv(self) -> CsvFile:
		method = self._state.channel.config.api.method or 'url'
		if method == 'file':
			method = 'url'
		csv_method = self.get_csv_method(method)
		kwargs = self._state.channel.config.api or {}
		if self._request_data.get('url'):
			kwargs['url'] = self._request_data['url']
		module_class = importlib.import_module(BASE_DIR + ".models.channels.file")
		csv_object = getattr(module_class, csv_method)(**kwargs)
		return csv_object


	def is_litcommerce_tamplate(self):
		return self._state.channel.config.api.format == 'litc'


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response.SUCCESS:
			return parent
		csv_object = self.get_model_csv()
		validate = csv_object.validate_file(setup = True)
		if validate.result != Response.SUCCESS:
			return validate
		self._state.channel.config.api.type = 'add'
		return Response().success()


	def del_fields(self):
		return ['active_listings']


	def get_csv_title(self):
		return self.construct_products_csv_file()


	def store_csv_data(self):
		csv_object = self.get_model_csv()
		csv_data = csv_object.to_list()
		index = 1
		values = list()
		table = self.table_construct()
		csv_title = list(filter(lambda x: x not in self.del_fields(), csv_object.construct_products_csv_file()))

		for row in csv_data:
			if not row:
				continue
			data = dict()
			use_fields = []
			for field in csv_title:
				field = field.strip('"').strip("'")
				value = row.get(field)
				use_fields.append(field)
				if self._state.channel.config.api.mapping and self._state.channel.config.api.mapping.get(field):
					mapping_field = to_str(self._state.channel.config.api.mapping.get(field))
					mapping_field = mapping_field.strip('"').strip("'")
					use_fields.append(mapping_field)
					if row.get(mapping_field):
						value = row[mapping_field]
				if isinstance(value, float) and math.isnan(value):
					value = None
				data[field] = value
			attributes = dict()

			if data.get('attributes'):
				data_attributes = to_str(data['attributes']).splitlines()
				for attribute in data_attributes:
					if not attribute:
						continue
					attribute_split = to_str(attribute).split(':', 1)
					if to_len(attribute_split) != 2:
						continue
					attributes[attribute_split[0].strip()] = attribute_split[1].strip()
			for field, value in row.items():
				if field in use_fields or not value or is_float_nan(value) or (is_decimal(value) and not to_decimal(value)):
					continue
				attributes[field] = value
			if attributes:
				data['attributes'] = json_encode(attributes)
			if not data.get('sku') and data.get('parent_sku'):
				data['sku'] = data['parent_sku']
				data['parent_sku'] = ''
			# for key, value in row.items():
			# 	if key in self.del_fields():
			# 		continue
			# 	data[key] = value
			# 	if isinstance(value, float) and math.isnan(value):
			# 		data[key] = None
			data['user_id'] = self._user_id
			values.append(data)
		multiple = self._state.channel.config.api.multiple_limit or 100
		insert_data = split_list(values, to_int(multiple))
		for row in insert_data:
			if to_len(row) > 1:
				insert = self.get_model_local().insert_multiple_obj(table['table'], row)
			else:
				insert = self.get_model_local().insert_obj(table['table'], row[0])

		return Response().success()


	def table_construct(self):
		table_product = super().table_construct()
		table_product['rows'].update({
			'id': "int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT",
			'product_id': "varchar(25) NULL",
			'sku': "varchar(255)",
			'parent_sku': "varchar(125) NULL",
			'name': "varchar(255) NULL",
			'qty': "text",
			'description': "text COLLATE 'utf8mb4_unicode_ci' NULL",
			'brand': "varchar(255) NULL",
			'condition': "varchar(25) NULL",
			'condition_note': "text",
			'price': "text",
			'msrp': "text",
			'seo_url': "text",
			'manufacturer': "varchar(255) NULL",
			'mpn': "varchar(255) NULL",
			'upc': "varchar(255) NULL",
			'tags': "text",
			'ean': "varchar(255) NULL",
			'isbn': "varchar(255) NULL",
			'gtin': "varchar(255) NULL",
			'gcid': "varchar(255) NULL",
			'asin': "varchar(255) NULL",
			'epid': "varchar(255) NULL",
			'height': "text NULL",
			'length': "text NULL",
			'width': "text NULL",
			'dimension_units': "text NULL",
			'weight': "text NULL",
			'weight_units': "text NULL",
			'attributes': "text NULL",
			'categories': "text NULL",
		})
		for i in range(1, 6):
			table_product['rows']['variation_' + to_str(i)] = "varchar(255) NULL"
		for i in range(1, 11):
			table_product['rows']['product_image_' + to_str(i)] = "text NULL"
		return table_product


	def restart_pull(self):
		self._state.resume.action = 'pull'
		self._state.resume.type = 'products'
		self._state.pull.resume.action = 'display_pull'
		self._state.pull.resume.type = 'products'
		self._state.pull.process.products = EntityProcess()
		self.save_state()
		return Response().success()


	def get_query_count_product(self):
		table = self.table_construct()
		query = f"SELECT COUNT(1) as count FROM `{table['table']}` WHERE `sku` IS NOT NULL AND `sku` > '' AND (parent_sku IS NULL OR parent_sku = '' or parent_sku = 'False' or `parent_sku` = `sku`)"
		return query


	def get_fields_allow_update(self):
		if self._field_allow_update:
			return self._field_allow_update
		if self.get_model_csv().is_litcommerce_template():
			self._field_allow_update = "mpn,name,qty,is_in_stock,price,description,brand,condition,condition_note,msrp,seo_url,manufacturer,upc,ean,isbn,gtin,gcid,asin,epid,height,length,width,dimension_units,weight,weight_units,images".split(',')
			return self._field_allow_update
		allow_update = list()
		file_title = self.get_model_csv().get_file_title()
		csv_title = list(filter(lambda x: x not in self.del_fields(), self.construct_products_csv_file()))
		for row in csv_title:
			if row in ['product_id']:
				continue
			if row in file_title:
				allow_update.append(row)
				continue
			if self._state.channel.config.api.mapping and self._state.channel.config.api.mapping.get(row):
				if row == 'product_image_1' and 'thumb_image' not in allow_update:
					allow_update.append('thumb_image')
				elif row.find('image') != -1 and 'images' not in allow_update:
					allow_update.append('images')
					continue
				allow_update.append(row)
		if 'qty' in allow_update:
			allow_update.append('is_in_stock')
		self._field_allow_update = list(set(allow_update))
		return self._field_allow_update

	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		csv_object = self.get_model_csv()
		self._state.pull.process.products.id_src = 0
		self._state.pull.process.products.total = 0
		self._state.pull.process.products.error = 0
		self._state.pull.process.products.imported = 0
		self._state.pull.process.products.new_entity = 0
		validate = csv_object.validate_file()
		if validate.result != Response.SUCCESS:
			msg = Errors().get_msg_error(validate.code) if validate.code else validate.msg
			feed_data = {
				'feed_id': to_int(self.get_sync_id()),
				'message': msg,
				'created_at': get_current_time(),
				'result': Activity.FAILURE
			}
			self.create_activity_feed(**feed_data)
			return Response().success()

		self.setup_storage_csv()
		self.store_csv_data()
		table = self.table_construct()
		query = self.get_query_count_product()
		count = self.get_model_local().select_raw(query)
		if count.result == Response().SUCCESS:
			self._state.pull.process.products.total = count['data'][0]['count']
		return Response().success()


	def set_channel_identifier(self):
		self.set_identifier('file')
		return Response().success()


	# TODO: Products
	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._id_src
		table = self.table_construct()
		query = f'SELECT * FROM `{table["table"]}` WHERE `sku` IS NOT NULL AND `sku` > "" AND (parent_sku is null or parent_sku = "" or parent_sku = "False" or `parent_sku` = `sku`) AND id > "{id_src}" ORDER BY id LIMIT {limit_data}'
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS or not products.data:
			return Response().finish()
		self._id_src = products.data[-1]['id']
		return Response().success(data = products.data)


	def get_products_ext_export(self, products):
		product_ids = duplicate_field_value_from_list(products, self.CHILD_FIELD)
		query = f"SELECT * FROM {self.get_table_name()} WHERE {self.PARENT_FIELD} IN {self.get_model_local().list_to_in_condition(product_ids)} AND `{self.PARENT_FIELD}` != `{self.CHILD_FIELD}`"
		variants = self.get_model_local().select_raw(query)
		if variants.result != Response.SUCCESS:
			return variants
		product_ext = Prodict()
		product_ext['variants'] = variants.data
		return Response().success(product_ext)


	def get_product_id_import(self, convert: Product, product, products_ext):
		convert = self.convert_product_export(product, products_ext)
		convert_data = convert.data
		return product.sku if not convert_data.variants else f'parent-{product.sku}'


	def _convert_product_export(self, product, products_ext: Prodict):
		product_data = self._convert_product(product)
		variants = get_list_from_list_by_field(products_ext['variants'], self.PARENT_FIELD, product.get(self.CHILD_FIELD))
		if variants:
			for variant in variants:
				variant_data = self._convert_product(variant, product)
				if variant_data:
					product_data.variants.append(variant_data)
			if product_data.variants:
				product_data.id = f'parent-{product.sku}'
		return Response().success(product_data)


	def to_price(self, price):
		price = to_str(price).replace(',','.')
		price = re.sub('[^0-9.]','',price)
		return to_decimal(price, 2)


	def _convert_product(self, product: Product, parent = None):
		if parent:
			product_data = ProductVariant()
		else:
			product_data = Product()
		equal_fields = ('name', 'qty', 'description', 'condition', 'condition_note', 'seo_url', 'msrp', 'upc', 'ean', 'isbn', 'gtin', 'gcid', 'asin', 'epid', 'height', 'length', 'width', 'weight', 'brand', 'mpn', 'tags')
		for field in equal_fields:
			if field in product_data:
				product_data[field] = product[field]
		product_data['price'] = self.to_price(product.get('price'))
		product_data.sku = product.sku or product.parent_sku
		product_data.dimension_units = product.dimension_units if product.dimension_units in ['in', 'm', 'cm', 'ft', 'mm'] else 'in'
		product_data.weight_units = product.weight_units if product.weight_units in ['oz', 'lb', 'g', 'kg'] else 'oz'
		product_id = product.sku
		product_data.id = product_id
		product_data.is_in_stock = to_int(product_data.qty) > 0
		# if self.is_csv_update():
		product_data.allow_update = self.get_fields_allow_update()
		all_images = []
		for i in range(1, 11):
			field = 'product_image_{}'.format(to_str(i))
			if not product.get(field):
				continue
			images = to_str(product.get(field)).split(',')
			all_images.extend(images)
			# if not product_data.thumb_image.url:
			# 	product_data.thumb_image.url = product[field]
			# else:
			# 	product_image = ProductImage()
			# 	product_image.url = product[field]
			# 	product_image.position = i
			# 	product_data.images.append(product_image)
		if all_images:
			for index, image in enumerate(all_images):
				if not index:
					product_data.thumb_image.url = image.strip()
					continue
				product_image = ProductImage()
				product_image.url = image.strip()
				product_image.position = index
				product_data.images.append(product_image)

		if parent:
			attribute_name = dict()
			for i in range(1, 6):
				field = 'variation_{}'.format(i)
				if not parent.get(field):
					continue
				attribute_name[field] = parent[field]
			if not attribute_name:
				return False
			for field, name in attribute_name.items():
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = name
				attribute_data.attribute_value_name = product[field]
				product_data.attributes.append(attribute_data)
			variant_key = self.variant_key_generate(product_data)
			product_data.id = product.sku or f"{product.sku}-{variant_key}"
		if product.attributes and json_decode(product.attributes):
			attributes = json_decode(product.attributes)
			if isinstance(attributes, dict):
				for attribute_name, attribute_value in attributes.items():
					if not attribute_value or not attribute_name:
						continue
					attribute_data = ProductAttribute()
					attribute_data.attribute_name = attribute_name
					attribute_data.attribute_value_name = attribute_value
					product_data.attributes.append(attribute_data)
				product_data.allow_update.append('attributes')
		if product.categories:
			categories = to_str(product.categories).splitlines()
			categories = list(map(lambda x: to_str(x).strip(), categories))
			product_data.category_name_list.extend(categories)
		return product_data


	def product_import(self, convert: Product, product, products_ext):
		src_channel_id = self.get_src_channel_id()
		channel_data = product.channel[f'channel_{src_channel_id}']
		file_product_id = product.sku

		if product.variants:
			file_product_id = f'parent-{file_product_id}'
			for variant in product.variants:
				variant_channel_data = variant.channel[f'channel_{src_channel_id}']
				variant_channel_data.channel_id = self.get_channel_id()
				self.insert_map_product(variant, variant['_id'], variant.sku)
		return Response().success(file_product_id)


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self._order_sync_inventory(order, '+')


	def order_sync_inventory(self, convert: Order, setting_order):
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			product = row['product']
			row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				inventory_quantity = to_int(product.qty)
				new_qty = to_int(inventory_quantity) - to_int(row_qty) if prefix == '-' else to_int(inventory_quantity) + to_int(row_qty)
				if new_qty < 0:
					new_qty = 0
				update_data = {
					'qty': new_qty,
					'updated_time': time.time()
				}
				self.get_model_catalog().update(product['_id'], update_data)
				if row['parent']:
					self.update_qty_for_parent(row['parent']['_id'])

		return Response().success()


class CsvBulkEdit:
	def construct_products_csv_file(self):
		title = "product_id,sku,parent_sku,name,qty,price,description,brand,height,length,width,dimension_units,weight,weight_units,product_image_1,product_image_2,product_image_3,product_image_4,product_image_5,product_image_6,product_image_7,product_image_8,product_image_9,product_image_10"
		return title.split(',')


class CsvBulkEditFromUrl(CsvBulkEdit, CsvFromUrl):
	def __init__(self, url, **kwargs):
		super().__init__(url, **kwargs)
		self._format = 'litc'


class CsvUpdateFromUrl(CsvBulkEdit, CsvFromUrl):
	pass
