from datasync.libs.response import Response
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order
from datasync.models.constructs.product import Product


class ModelChannelsLitcommerce(ModelChannel):
	def display_setup_channel(self, data = None):
		parent = super(ModelChannelsLitcommerce, self).display_setup_channel(data)
		return Response().success()


	def product_import(self, convert: Product, product, products_ext):
		return Response().success(product.get('_id'))


	def order_import(self, convert: Order, order, orders_ext):
		return Response().success(order.get('_id'))
