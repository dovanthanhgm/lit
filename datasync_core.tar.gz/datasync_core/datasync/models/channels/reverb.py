import validators
from countryinfo import CountryInfo
import validators as python_validators
from datasync.libs.errors import Errors
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderHistory, OrderAddress, OrderAddressState, OrderRefund
from datasync.models.constructs.product import Product, ProductCategory, ProductImage

from datasync.libs.utils import json_encode, get_config_ini, to_timestamp, get_current_time, \
    to_int, to_decimal, to_str, log_traceback, get_random_useragent, isoformat_to_datetime, to_len, to_bool
from datasync.libs.response import Response
from datasync.libs.tracking_company import TrackingCompany

from PIL import Image, ImageFile
from urllib.request import Request, urlopen

import requests
import time
import os
import io
import base64
import datetime


class ModelChannelsReverb(ModelChannel):
    TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category', 'tag']

    reverb_condition = [
        { "value": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890", "label": "Brand New" },
        { "value": "9225283f-60c2-4413-ad18-1f5eba7a856f", "label": "B-Stock" },
        { "value": "6db7df88-293b-4017-a1c1-cdb5e599fa1a", "label": "Mint (with inventory)"},
        { "value": "ac5b9c1e-dc78-466d-b0b3-7cf712967a48", "label": "Mint" },
        { "value": "df268ad1-c462-4ba6-b6db-e007e23922ea", "label": "Excellent" },
        { "value": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d", "label": "Very Good" },
        { "value": "f7a3f48c-972a-44c6-b01a-0cd27488d3f6", "label": "Good" },
        { "value": "98777886-76d0-44c8-865e-bb40e669e934", "label": "Fair" },
        { "value": "6a9dfcad-600b-46c8-9e08-ce6e5057921e", "label": "Poor" },
        { "value": "fbf35668-96a0-4baa-bcde-ab18d6b1b329", "label": "Non Functioning" },
        { "value": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890", "label": "brand new" },
        { "value": "9225283f-60c2-4413-ad18-1f5eba7a856f", "label": "b-btock" },
        { "value": "6db7df88-293b-4017-a1c1-cdb5e599fa1a", "label": "mint (with inventory)"},
        { "value": "ac5b9c1e-dc78-466d-b0b3-7cf712967a48", "label": "mint" },
        { "value": "df268ad1-c462-4ba6-b6db-e007e23922ea", "label": "excellent" },
        { "value": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d", "label": "very good" },
        { "value": "f7a3f48c-972a-44c6-b01a-0cd27488d3f6", "label": "good" },
        { "value": "98777886-76d0-44c8-865e-bb40e669e934", "label": "fair" },
        { "value": "6a9dfcad-600b-46c8-9e08-ce6e5057921e", "label": "poor" },
        { "value": "fbf35668-96a0-4baa-bcde-ab18d6b1b329", "label": "non functioning" },
        { "value": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890", "label": "Brand new" },
        { "value": "9225283f-60c2-4413-ad18-1f5eba7a856f", "label": "B-btock" },
        { "value": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d", "label": "Very good" },
        { "value": "fbf35668-96a0-4baa-bcde-ab18d6b1b329", "label": "Non functioning" },
        { "value": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890", "label": "brand New" },
        { "value": "9225283f-60c2-4413-ad18-1f5eba7a856f", "label": "b-Stock" },
        { "value": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d", "label": "very Good" },
        { "value": "fbf35668-96a0-4baa-bcde-ab18d6b1b329", "label": "non Functioning" }
    ]

    ORDER_STATUS = {
        'unpaid': Order.AWAITING_PAYMENT,
        'payment_pending': Order.AWAITING_PAYMENT,
        'pending_review': Order.AWAITING_PAYMENT,
        'blocked': Order.AWAITING_PAYMENT,
        'paid': Order.READY_TO_SHIP,
        'shipped': Order.COMPLETED,
        'picked_up': Order.SHIPPING,
        'received': Order.COMPLETED,
        'refunded': Order.REFUNDED,
        'cancelled': Order.CANCELED,
        'REFUNDED': Order.REFUNDED,
        'PARTIALLY_REFUNDED': Order.PARTIALLY_REFUNDED
    }

    REVERB_CONDITION = {
        "Brand New": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890",
        "Brand new": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890",
        "brand New": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890",
        "brand new": "7c3f45de-2ae0-4c81-8400-fdb6b1d74890",
        "B-Stock": "9225283f-60c2-4413-ad18-1f5eba7a856f",
        "b-stock": "9225283f-60c2-4413-ad18-1f5eba7a856f",
        "B-stock": "9225283f-60c2-4413-ad18-1f5eba7a856f",
        "b-Stock": "9225283f-60c2-4413-ad18-1f5eba7a856f",
        "Mint (with inventory)": "6db7df88-293b-4017-a1c1-cdb5e599fa1a",
        "mint (with inventory)": "6db7df88-293b-4017-a1c1-cdb5e599fa1a",
        "Mint": "ac5b9c1e-dc78-466d-b0b3-7cf712967a48",
        "Excellent": "df268ad1-c462-4ba6-b6db-e007e23922ea",
        "Good": "f7a3f48c-972a-44c6-b01a-0cd27488d3f6",
        "Fair": "98777886-76d0-44c8-865e-bb40e669e934",
        "Poor": "6a9dfcad-600b-46c8-9e08-ce6e5057921e",
        "Non Functioning": "fbf35668-96a0-4baa-bcde-ab18d6b1b329",
        "mint": "ac5b9c1e-dc78-466d-b0b3-7cf712967a48",
        "excellent": "df268ad1-c462-4ba6-b6db-e007e23922ea",
        "Very Good": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d",
        "very good": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d",
        "Very good": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d",
        "very Good": "ae4d9114-1bd7-4ec5-a4ba-6653af5ac84d",
        "good": "f7a3f48c-972a-44c6-b01a-0cd27488d3f6",
        "fair": "98777886-76d0-44c8-865e-bb40e669e934",
        "poor": "6a9dfcad-600b-46c8-9e08-ce6e5057921e",
        "Non functioning": "fbf35668-96a0-4baa-bcde-ab18d6b1b329",
        "non Functioning": "fbf35668-96a0-4baa-bcde-ab18d6b1b329",
        "non functioning": "fbf35668-96a0-4baa-bcde-ab18d6b1b329",
    }

    def __init__(self):
        super().__init__()
        self._product_pull_type = 'live'
        self._last_status = None
        self.flag_finish = False

    def get_api_info(self):
        return {
            "token": "API token"
            # "shop": "Shop Name"
        }

    def display_setup_channel(self, data=None):
        parent = super().display_setup_channel(data)
        if parent.result != Response().SUCCESS:
            return parent
        index_api = self.api('shop')
        if index_api.result != Response().SUCCESS:
            return index_api

        return Response().success()

    def set_channel_identifier(self):
        parent = super().set_channel_identifier()
        if parent.result != Response().SUCCESS:
            return parent
        res = self.api('shop')
        if res.result != Response().SUCCESS:
            return res
        user_id = res.data.get('user_id')
        if not user_id:
            return res
        self.set_identifier(str(user_id).strip())
        return Response().success()

    def display_pull_channel(self):
        parent = super().display_pull_channel()
        if parent.result != Response().SUCCESS:
            return parent

        # product
        if self.is_product_process():
            # id_src_prd = self._state.pull.process.products.id_src
            self._state.pull.process.products.imported = 0
            self._state.pull.process.products.imported_ended = 0
            self._state.pull.process.products.imported_ordered = 0
            self._state.pull.process.products.imported_sold_out = 0
            self._state.pull.process.products.imported_draft = 0
            self._state.pull.process.products.new_entity = 0
            self._state.pull.process.products.error = 0
            self._state.pull.process.products.total = 0
            if not self._state.pull.process.products.id_src:
                self._state.pull.process.products.id_src = 0
            offset = self._state.pull.process.products.imported

            if self.is_refresh_process():
                self._state.pull.process.products.total_view = 0
            product_filter_condition = {}
            if self._request_data.get('ids'):
                # log(self._request_data.get('ids'))
                ids = self._request_data.get('ids').split(",")
                total_product = 0
                for id in ids:
                    id = str(id).strip()
                    product_info = self.api("/listings/" + str(id))
                    if product_info.result == Response().SUCCESS:
                        total_product += 1
                self._state.pull.process.products.total = total_product
                return Response().success()
            elif self._request_data.get('sku', {}):
                self._state.pull.process.products.total = to_len(self._request_data.get('sku').split(","))
                return Response().success()

            elif self._state.channel.config.api.import_not_listed:
                channel_default_id = self.get_channel_default_id()
                where = self.get_model_catalog().create_where_condition(f'channel.channel_{channel_default_id}.status', 'active')
                where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.status', ['active', 'draft', 'error'], 'nin'))
                qty = self._state.channel.config.api.import_not_listed_qty or 0
                if to_int(qty):
                    where.update(self.get_model_catalog().create_where_condition(f'qty', to_int(qty), '>='))
                where.update(self.get_model_catalog().create_where_condition(f'sku', '', '>'))
                self._state.pull.process.products.total = self.get_model_catalog().count(where)
                return Response().success()
            else:
                product_filter_condition['state'] = 'live'

            if self._request_data.get('updated_at'):
                product_filter_condition['updated_start_date'] = self._request_data.get('updated_at')

            if self._state.channel.config.api.must_not:
                product_filter_condition['must_not'] = self._state.channel.config.api.must_not
            if offset:
                product_filter_condition['offset'] = offset
            products_api = self.api('/my/listings', data=product_filter_condition)
            if products_api.result == Response().SUCCESS:
                products_data = products_api.data
                if self.is_refresh_process():
                    self._state.pull.process.products.total = -1
                    if not self._state.pull.process.products.total_view:
                        self._state.pull.process.products.total_view = 0
                    self._state.pull.process.products.total_view += to_int(products_data['total'])
                else:
                    if not self._state.pull.process.products.total_view:
                        self._state.pull.process.products.total_view = 0
                    if not self._state.pull.process.products.total:
                        self._state.pull.process.products.total = 0
                    self._state.pull.process.products.total_view += to_int(products_data['total'])
                    self._state.pull.process.products.total += to_int(products_data['total'])

            for row in ['ended', 'sold', 'draft']:
                if self.is_import_product_by_status(row):
                    if row == "sold":
                        for status in ['ordered', 'sold_out']:
                            product_filter_condition['state'] = status
                            imported = self._state.pull.process.products.get(f'imported_{status}')
                            product_filter_condition['offset'] = imported
                            products_api = self.api('/my/listings', data=product_filter_condition)
                            if products_api.result == Response().SUCCESS:
                                products_data = products_api.data
                                if not self._state.pull.process.products.total_view:
                                    self._state.pull.process.products.total_view = 0
                                if not self._state.pull.process.products.total:
                                    self._state.pull.process.products.total = 0
                                self._state.pull.process.products.total_view += to_int(products_data['total'])
                                self._state.pull.process.products.total += to_int(products_data['total'])
                    else:
                        product_filter_condition['state'] = row
                        imported = self._state.pull.process.products.get(f'imported_{row}')
                        product_filter_condition['offset'] = imported
                        products_api = self.api('/my/listings', data=product_filter_condition)
                        if products_api.result == Response().SUCCESS:
                            products_data = products_api.data
                            if self.is_refresh_process():
                                self._state.pull.process.products.total = -1
                                if not self._state.pull.process.products.total_view:
                                    self._state.pull.process.products.total_view = 0
                                self._state.pull.process.products.total_view += to_int(products_data['total'])
                            else:
                                if not self._state.pull.process.products.total_view:
                                    self._state.pull.process.products.total_view = 0
                                if not self._state.pull.process.products.total:
                                    self._state.pull.process.products.total = 0
                                self._state.pull.process.products.total_view += to_int(products_data['total'])
                                self._state.pull.process.products.total += to_int(products_data['total'])

        if self.is_order_process():
            self._state.pull.process.orders.total = 0
            self._state.pull.process.orders.imported = 0
            self._state.pull.process.orders.new_entity = 0
            self._state.pull.process.orders.error = 0
            self._state.pull.process.orders.id_src = 0
            start_time = self.get_order_start_time('iso')
            last_modifier = self._state.pull.process.orders.max_last_modified
            order_filter_condition = {
                "created_start_date": start_time,
            }
            if last_modifier:
                order_filter_condition['updated_start_date'] = last_modifier
                self.set_order_max_last_modifier(last_modifier)

            order_api = self.api('my/orders/selling/all', data=order_filter_condition)

            if order_api.result == Response().SUCCESS and order_api.data['total']:
                self._state.pull.process.orders.total = order_api.data['total']

        return Response().success()

    # products
    def get_products_main_export(self):
        if self.flag_finish:
            return Response().finish()
        # per_page = self._state.pull.setting.products or 50
        params = {
            "per_page": 50,
        }
        if self._state.channel.config.api.must_not:
            params['must_not'] = self._state.channel.config.api.must_not
        data = list()
        try:
            if self._request_data.get('ids'):
                ids = self._request_data.get('ids').split(",")
                for row_id in ids:
                    row_id = str(row_id).strip()
                    product_info = self.api("/listings/"+str(row_id))
                    if product_info.result != Response().SUCCESS:
                        return Response().finish(code = Errors.EXCEPTION, msg = "Could not get products")
                    data.append(product_info.data)
                self.flag_finish = True
                return Response().success(data=data)
            elif self._request_data.get('sku', {}) or self._state.channel.config.api.import_not_listed:
                if self._request_data.get('sku', {}):
                    skus = self._request_data.get('sku').split(",")
                else:
                    channel_default_id = self.get_channel_default_id()
                    where = self.get_model_catalog().create_where_condition(f'channel.channel_{channel_default_id}.status', 'active')
                    where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.status', ['active', 'draft', 'error'], 'nin'))
                    qty = self._state.channel.config.api.import_not_listed_qty or 0
                    if to_int(qty):
                        where.update(self.get_model_catalog().create_where_condition(f'qty', to_int(qty), '>='))
                    where.update(self.get_model_catalog().create_where_condition(f'sku', '', '>'))
                    product_not_listed = self.get_model_catalog().find_all(where, select_fields = ['sku'])
                    skus = [row['sku'] for row in product_not_listed]
                if not skus:
                    return Response().finish()
                for sku in skus:
                    sku = str(sku).strip()
                    product_info = self.get_product_by_sku(sku)
                    if product_info.result == Response().SUCCESS and product_info.data and product_info.data['listings']:
                        data.append(product_info.data['listings'][0])
                self.flag_finish = True

                return Response().success(data = data)
            if not self._product_pull_type:
                return Response().finish()
            if self._product_pull_type == 'live':
                imported = self._state.pull.process.products.imported
            else:
                if self.is_refresh_process() or not self.is_import_product_by_status(self._product_pull_type):
                    self.set_product_pull_type()
                    return self.get_products_main_export()
                imported = self._state.pull.process.products.get(f'imported_{self._product_pull_type}')
                # sold vs sold_out
                # TODO: update state name
                if self._product_pull_type == 'sold':
                    imported = self._state.pull.process.products.get(f'imported_{self._product_pull_type}_out')

            # check if reverb return same product with different params
            if to_int(imported) > self._state.pull.process.products.total:
                self.flag_finish = True

            if self._product_pull_type == "sold":
                if self._request_data.get('updated_at'):
                    params['updated_start_date'] = self._request_data.get('updated_at')
                for status in ['ordered', 'sold_out']:
                    params['state'] = status
                    if to_str(imported):
                        params['offset'] = to_str(imported)
                    sold_products = self.api('/my/listings', data=params)
                    if sold_products.result != Response().SUCCESS:
                        return Response().finish(code = Errors.EXCEPTION, msg = "Could not get products")
                    if not sold_products:
                        continue
                    for listing in sold_products.data['listings']:
                        data.append(listing)
            else:
                if self._request_data.get('updated_at'):
                    params['updated_start_date'] = self._request_data.get('updated_at')
                params['state'] = self._product_pull_type
                if to_str(imported):
                    params['offset'] = to_str(imported)
                products = self.api('/my/listings', data=params)
                if products.result != Response().SUCCESS:
                    return Response().finish(code = Errors.EXCEPTION, msg = "Could not get products")
                if not products:
                    self.set_product_pull_type()
                    return self.get_products_main_export()
                data = products.data['listings']
            if len(data) == 0:
                for state in ["ended", "sold", "draft"]:
                    if self.is_import_product_by_status(state):
                        self.set_product_pull_type()
                        return self.get_products_main_export()
        except Exception as e:
            self.log_traceback()
            return Response().finish(code = Errors.EXCEPTION, msg = str(e))
        return Response().success(data=data)

    def get_products_ext_export(self, products):
        return Response().success()

    def _convert_product_export(self, product, products_ext):
        if self._request_data.get('created_at'):
            start_time = datetime.datetime.strptime(self._request_data.get('created_at'), '%Y-%m-%d').timestamp()
            product_created = isoformat_to_datetime(product.created_at).timestamp()
            if product_created < start_time:
                return Response().skip()

        product_data = Product()
        try:
            product_data.id = product.id
            product_data.sku = product.sku if product.sku else ""
            product_data.brand = product.make if product.make else ""
            product_data.name = product.title
            product_data.created_at = product.created_at
            product_data.updated_at = get_current_time()
            product_data.imported_at = get_current_time()
            product_data.description = product.description if product.description else ""
            product_data.model = product.model if product.model else ""
            product_data.status = True if product.state.slug == "live" else False
            product_data.invisible = True if product.state.slug != "live" else False

            product_data.price = product.price.amount
            if product.get("condition"):
                if not product.condition.get('display_name'):
                    product_data.condition = product.condition
                else:
                    product_data.condition = product.condition['display_name']

            if product.has_inventory:
                if product.inventory:
                    product_data.qty = product.inventory
                else:
                    product_data.qty = 0
            else:
                product_data.qty = 1

            cate = ProductCategory()
            categories = list()
            category_name_list = list()
            for category in product.categories:
                cate.code = category.uuid
                cate.name = category.full_name
                name = category.full_name.split("/")[-1].strip(' ')
                category_name_list.append(name)
                product_data.categories.append(cate)
                categories.append(
                    {
                        "uuid": category.uuid,
                        "full_name": category.full_name
                    }
                )
            product_data.category_name_list = category_name_list

            upc_status = product.get('upc_does_not_apply')
            if upc_status == None:
                has_upc = False
            else:
                has_upc = not upc_status

            sold_as_is = False
            handmade = False
            origin_country = ""
            video = ""
            if product.get('handmade') != None:
                handmade = product.get('handmade', False)
            if product.get('sold_as_is') != None:
                sold_as_is = product.get('sold_as_is', False)
            if product.get('origin_country') != None:
                origin_country = product.get('origin_country', '')

            product_image = product['photos']
            if len(product['photos']) == 1 or not product.get('upc_does_not_apply'):
                product_detail = self.get_product_by_id(product.id).data
                product_image = product_detail['photos']
                has_upc = not product_detail.get('upc_does_not_apply')
                product_data.upc = product_detail.get('upc', "")
                sold_as_is = product_detail.get('sold_as_is', False)
                handmade = product_detail.get('handmade', False)
                origin_country = product_detail.get('origin_country_code', '')
                videos = product_detail.get('videos')
                if videos and len(videos) == 1:
                    video = videos[0]
                    if isinstance(video, dict) and video.get('url'):
                        video = video['url']

            for image in product_image:
                img = ProductImage()
                img.url = image['litc_links']['full']['href']
                product_data.images.append(img)

            rates = list()
            for rate in product.shipping.rates:
                if not rate.get('rate'):
                    rates.append({
                        "region_code": rate.get('region_code'),
                        "rate": 0
                    })
                    self.log(product.shipping.rates)
                else:
                    rates.append({
                        "region_code": rate.region_code,
                        "rate": rate.rate.get('amount')
                    })

            shipping = {
                "local": product.shipping.local,
                "rates": rates,
                "manual_custom": True,
                "shipping_id": ""
            }
            condition_uuid = ""
            if product.get("condition"):
                if product.condition.get('uuid'):
                    condition_uuid = product.condition.get('uuid')
                if product.get('condition_uuid'):
                    condition_uuid = product.get('condition_uuid')
            category = {
                "info": {
                    "brands": {
                        "mapping": "",
                        "override": product.make,
                        "value": product.make
                    },
                    "models": {
                        "mapping": "",
                        "override": product.model,
                        "value": product.model
                    },
                    "reverb_condition": {
                        "mapping": "",
                        "override": condition_uuid,
                        "value": condition_uuid,
                        "tags": False,
                    }
                },
                "category": categories,
                "advance": {
                    "offers": product.offers_enabled,
                    "unique": not product.has_inventory,
                    "years": {
                        "mapping": "",
                        "override": product.year,
                        "value": product.year
                    },
                    "colors": {
                        "mapping": "",
                        "override": product.finish,
                        "value": product.finish
                    },
                    "costs": {
                        "mapping": "",
                        "override": product.seller_price.get('amount') if product.get('seller_price') else 0,
                        "value": product.seller_price.get('amount') if product.get('seller_price') else 0
                    },
                    "has_upc": has_upc,
                    "handmade": handmade,
                    "sold_as_is": sold_as_is,
                    "origin_country": origin_country,
                    "video": {
                        "mapping": "",
                        "override": video,
                        "value": video
                    }
                }
            }
            product_data.template_data['shipping'] = shipping
            product_data.template_data['category'] = category

            channel_data = dict()

            state = product.state.slug
            if state == "draft":
                channel_data['reverb_status'] = "reverb_draft"
            else:
                channel_data['reverb_status'] = state
            product_data.channel_data = channel_data

        except Exception as e:
            error = "Product " + str(product.id) + " get error: " + str(e)
            self.log_traceback()
            return Response().skip()
        return Response().success(data=product_data)

    def get_product_id_import(self, convert: Product, product, products_ext):
        return product.id

    def product_import(self, convert: Product, product, products_ext):
        product_id = None
        if not product.variants:
            convert_product = self.product_to_reverb_data(product, products_ext, insert = True)
            if convert_product.result != Response().SUCCESS:
                return convert_product
            response = None
            try:
                response = self.api('listings', method="post", data=convert_product.data)
            except Exception as e:
                self.log_traceback()
            if response.result != Response().SUCCESS:
                return Response().error(msg=response.msg)
            product_id = response.data['listing']['id']
            return Response().success(data=product_id)
        else:
            error = ""
            for variant in product.variants:
                channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
                if channel_data.get('product_id'):
                    continue
                try:
                    convert_variant = self.variant_to_reverb_data(variant, product, insert = True)
                    if convert_variant.result != Response().SUCCESS:
                        self.log(convert_variant.msg)
                        error = error + str(variant['sku']) + ": " + str(convert_variant.msg) + ". "
                        continue
                    variant_response = self.api('listings', method="post", data=convert_variant.data)
                    if variant_response.result != Response().SUCCESS:
                        error = error + str(variant['sku']) + ": " + str(variant_response.msg) + ". "
                        continue
                    self.insert_map_product(variant, variant['_id'], variant_response.data['listing']['id'])
                    # self.insert_map_product(product, product['_id'], product.sku)
                except Exception as e:
                    self.log_traceback()
            if error:
                return Response().error(msg=error)
            return Response().success(data=product.sku)

    def after_product_import(self, product_id, convert: Product, product, products_ext):
        return super().after_product_import(product_id, convert, product, products_ext)

    def delete_product_import(self, product_id):
        return Response().success()


    def channel_assign_price_template(self, product, templates_data):
        product = super().channel_assign_price_template(product, templates_data)
        if 'tax_exempt' in templates_data:
            product.channel[f'channel_{self.get_channel_id()}']['tax_exempt'] = templates_data['tax_exempt']

        return product


    def product_to_reverb_data(self, product, product_ext, insert = False):
        try:
            shipping = product['channel'][f'channel_{self.get_channel_id()}']['template_data'].get('shipping')
            # if not shipping:
            #     return Response().error(msg = 'SHIPPING_IS_REQUIRED')
            category = product['channel'][f'channel_{self.get_channel_id()}']['template_data'].get('category')
            templates = product['channel'][f'channel_{self.get_channel_id()}'].get('templates')
            if not category:
                return Response().error(msg = 'CATEGORY_IS_REQUIRED')

            if self._state.channel.config.api.get('currency'):
                currency = self._state.channel.config.api.get('currency')
            else:
                currency = self.get_shop_currency()
                if not currency:
                    return Response().error(msg="Could not get currency. Please contact custome service for more information.")

            price = {
                "amount": str(product.price),
                "currency": currency
            }
            unique = category['advance'].get('unique')
            if not unique or unique == "false":
                unique = False
            if unique == "true":
                unique = True
            upc = category['advance'].get('upc') if category['advance'].get('upc') else category['advance'].get('has_upc')
            if not upc or upc == "false":
                upc = False
            if upc == "true":
                upc = True
            # get categories
            categories = list()
            if category.get('category') and len(category['category']) > 0:
                for cate in category['category']:
                    categories.append({
                        "uuid": cate['uuid'],
                        "full_name": cate['full_name']
                    })
            condition = {
                "uuid": ""
            }
            if category.info.get('condition'):
                condition['uuid'] = category.info['condition'].get('value')
            elif category.info.get('reverb_condition'):
                if templates and templates.get('category') and category.info.get('reverb_condition').get('tags') and category.info['reverb_condition'].get('tags') == True:
                    if product.get('tags'):
                        tags = product.tags.split(",")
                        check_condition_tag = False
                        for tag in tags:
                            if 'reverbsync-condition' in tag:
                                check_condition_tag = True
                                value = tag.split(':')[-1].strip()
                                if self.REVERB_CONDITION.get(value):
                                    condition['uuid'] = self.REVERB_CONDITION[value]
                                else:
                                    return Response().error(msg = "Your reverbsync-condition tag value: " +
                                                                  str(value) + """ does not match any of Reverb condition value. 
                                                            Valid value for mapping must be one of these value: 
                                                            Brand New, B-Stock, Mint (with inventory), Mint, Excellent, Very Good, Good, Fair, 
                                                            Poor, Non Functioning.""")
                        if not check_condition_tag:
                            return Response().error(msg = "Missing reverbsync-condition tag for mapping")
                    else:
                        return Response().error(msg = "Listing doesn't have any tags for mapping")
                else:
                    valid_condition = False
                    condition_value = category.info['reverb_condition'].get('value')
                    for item in self.reverb_condition:
                        if condition_value == item['value']:
                            valid_condition = True
                    if not valid_condition:
                        return Response().error(msg = "Your mapping value for condition is not valid")
                    condition['uuid'] = category.info['reverb_condition'].get('value')
            else:
                return Response().error(msg = 'Missing condition for listing')
            # get photos
            photos = list()

            if self.is_reverb_publish_image(product):
                if product.thumb_image.url:
                    photos.append(product.thumb_image.url)
                if product.images:
                    for img in product.images:
                        photos.append(img.url)
            # if product.thumb_image.url:
            #     main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
            #     image_data = self.resize_image(main_image['url'])
            #     if image_data:
            #     photos.append(main_image['url'])
            # for img_src in product.images:
            #     image_process = self.process_image_before_import(img_src['url'], None)
            #     image_data = self.resize_image(image_process['url'])
            #     if image_data:
            #     photos.append(img_src['url'])
            if photos == ['']:
                photos = []
            if not category.info['brands'].get('value'):
                if category.info['brands'].get('override'):
                    category.info['brands']['value'] = category.info['brands']['override']
                # else:
                #     return Response().error(msg="Mapping value for brand is empty.")
            if not category.info['models'].get('value'):
                if category.info['models'].get('override'):
                    category.info['models']['value'] = category.info['models']['override']
                # else:
                #     return Response().error(msg="Mapping value for model is empty.")

            # year
            year = ""
            if category['advance'].get('year'):
                year = category['advance'].get('year')
            elif category['advance'].get('years'):
                year = category['advance']['years'].get('value')
            # finish/color
            color = ""
            if category['advance'].get('color'):
                color = category['advance'].get('color')
            elif category['advance'].get('colors'):
                color = category['advance']['colors'].get('value')
            # cost
            cost = ""
            if category['advance'].get('cost'):
                cost = category['advance'].get('cost')
            elif category['advance'].get('costs'):
                cost = category['advance']['costs'].get('value')

            video = category['advance']['video'].get('value') if  category['advance'].get('video') else ""
            if video and isinstance(video, dict) and video.get('url'):
                video = video['url']
            if video and not python_validators.url(video):
                video = ''
            data = {
                "make": category.info['brands']['value'],
                "model": category.info['models']['value'],
                "description": product.description,
                "categories": categories,
                "condition": condition,
                "photos": photos,
                "title": product.name,
                "sku": product.sku,
                "has_inventory": not unique,
                "price": price,
                "publish": True,
                "offers_enabled": category['advance']['offers'],
                "year": year,
                "finish": color,
                "handmade": category['advance'].get('handmade', False),
                "sold_as_is": category['advance'].get('sold_as_is', False),
                "origin_country_code": category['advance'].get('origin_country', "")
            }
            if video:
                data["videos"] = [
                            {
                                "link": video
                            }
                        ]
            # if category and category.get('advance') and category['advance'].get('tax_exempt'):
            #     data['tax_exempt'] = True
            if product.get('tax_exempt'):
                data['tax_exempt'] = True
            # add shipping method
            if shipping and shipping.get('manual_custom'):
                rates = list()
                for rate in shipping['rates']:
                    rates.append({
                        "rate": {
                            "amount": rate['rate'],
                            "currency" : currency
                        },
                        "region_code": rate['region_code']
                    })
                data['shipping'] = {
                    "local": shipping['local'] if shipping['local'] else False,
                    "rates": rates
                }
            elif shipping and not shipping.get('manual_custom'):
                data['shipping_profile_id'] = shipping['shipping_id']
            # add inventory
            if unique and not insert:
                data['inventory'] = 1
            else:
                data['inventory'] = product.qty
            # add seller_cost
            if cost:
                data['seller_cost'] = cost
            # add UPC
            if not upc:
                data["upc_does_not_apply"] = True
            else:
                data['upc'] = product.upc
                data["upc_does_not_apply"] = False
            # photos
            if not photos:
                del data['photos']
                if 'publish' in data:
                    del data['publish']
            if not product.qty and 'publish' in data:

                del data['publish']

            if self.is_import_draft(product):
                if data.get('publish'):
                    del data['publish']
                data['state'] = "draft"

            check_tags = {
                "brand": False,
                "model": False,
                "shipping": False
            }
            if product.get('tags'):
                tags = product.tags.split(",")
                for tag in tags:
                    if 'reverb-inventory' in tag:
                        data['inventory'] = tag.split(':')[-1].strip()
                        data['has_inventory'] = True
                    if 'reverbsync-price' in tag:
                        if tag.split(':')[-1].strip() == "on":
                            data['price']['amount'] = to_decimal(product.price)
                        elif tag.split(':')[-1].strip() == "off":
                            if not self.is_strict_update_price() and self.is_update_product_process():
                            # tag `reverb_sync-price:off` means the user doesn't want to sync the price
                            # but if we create a new product, we still need `price` field
                                del data['price']
                        else:
                            return Response().error(msg="Tag mapping error. Your reverbsync-price tags is not correct.")
                    if 'reverbsync-upc-does-not-apply' in tag:
                        if tag.split(':')[-1].strip() == "on":
                            data['upc_does_not_apply'] = True
                        elif tag.split(':')[-1].strip() == "off":
                            data['upc'] = product.upc
                            data['upc_does_not_apply'] = False
                        else:
                            return Response().error(msg="Tag mapping error. Your 'reverbsync-upc-does-not-apply' tags is not correct.")
                    if 'reverbsync-offers' in tag:
                        if tag.split(':')[-1].strip() == "on":
                            data['offers_enabled'] = True
                        elif tag.split(':')[-1].strip() == "off":
                            data['offers_enabled'] = False
                        else:
                            return Response().error(msg="Tag mapping error. Your reverbsync-offers tags is not correct.")
                    if 'reverbsync-seller-cost' in tag:
                        data['seller_cost'] = tag.split(':')[-1].strip()
                    if 'reverbsync-make' in tag:
                        check_tags['brand'] = True
                        data['make'] = tag.split(':')[-1].strip()
                    if 'reverbsync-model' in tag:
                        check_tags['model'] = True
                        data['model'] = tag.split(':')[-1].strip()
                    if 'reverbsync-finish' in tag:
                        data['finish'] = tag.split(':')[-1].strip()
                    if 'reverbsync-year' in tag:
                        data['year'] = tag.split(':')[-1].strip()
                    if 'reverbsync-shipping-profile' in tag:
                        check_tags['shipping'] = True
                        shop = self.api('shop')
                        if shop.result != Response().SUCCESS:
                            return Response().error(msg="Could not get shipping profile for tags mapping")
                        shipping_profiles = shop.data['shipping_profiles']
                        check = False
                        for profile in shipping_profiles:
                            if profile['name'] == tag.split(':')[-1].strip():
                                check = True
                                data['shipping_profile_id'] = profile['id']
                                if data.get('shipping'):
                                    del data['shipping']
                        if not check:
                            return Response().error(msg="Tag mapping error. Your reverbsync-shipping-profile tag does not match any shipping profile name.")

            if not check_tags['brand'] and not category.info['brands'].get('value'):
                return Response().error(msg="BRAND_REQUIRED")
            if not check_tags['model'] and not category.info['models'].get('value'):
                return Response().error(msg="MODEL_REQUIRED")
            if not check_tags['shipping'] and not shipping:
                return Response().error(msg="SHIPPING_REQUIRED")
            if not self.is_import_draft() and categories == []:
                return Response().error(msg="CATEGORY_REQUIRED")
            # self.log(check_tags)
            # self.log(data)
        except Exception as e:
            self.log_traceback()
            return Response().error(msg="Convert simple listing error. Please contact support for more information.")
        return Response().success(data=data)

    def variant_to_reverb_data(self, variant, product, insert = False):
        try:
            template_data = product['channel'][f'channel_{self.get_channel_id()}'].get('template_data')
            templates = product['channel'][f'channel_{self.get_channel_id()}'].get('templates')
            if not template_data:
                return Response().error(msg = 'SHIPPING_AND_CATEGORY_ARE_REQUIRED')

            shipping = template_data.get('shipping')
            # if not shipping:
            #     return Response().error(msg = 'SHIPPING_IS_REQUIRED')

            category = template_data.get('category')
            if not category:
                return Response().error(msg = 'CATEGORY_IS_REQUIRED')

            if self._state.channel.config.api.get('currency'):
                currency = self._state.channel.config.api.get('currency')
            else:
                currency = self.get_shop_currency()
                if not currency:
                    return Response().error(msg="Could not get currency. Please contact custome service for more information.")

            price = {
                "amount": str(variant.price),
                "currency": currency
            }
            unique = category['advance'].get('unique')
            if not unique or unique == "false":
                unique = False
            if unique == "true":
                unique = True
            upc = category['advance'].get('upc') if category['advance'].get('upc') else category['advance'].get('has_upc')
            if not upc or upc == "false":
                upc = False
            if upc == "true":
                upc = True
            # get categories
            categories = list()
            if category.get('category') and len(category['category']) > 0:
                for cate in category['category']:
                    categories.append({
                        "uuid": cate['uuid'],
                        "full_name": cate['full_name']
                    })
            condition = {
                "uuid": ""
            }
            if category.info.get('condition'):
                condition['uuid'] = category.info['condition'].get('value')
            elif category.info.get('reverb_condition'):
                if templates and templates.get('category') and category.info.get('reverb_condition').get('tags') and category.info['reverb_condition'].get('tags') == True:
                    if product.get('tags'):
                        tags = product.tags.split(",")
                        check_condition_tag = False
                        for tag in tags:
                            if 'reverbsync-condition' in tag:
                                check_condition_tag = True
                                value = tag.split(':')[-1].strip()
                                if self.REVERB_CONDITION.get(value):
                                    condition['uuid'] = self.REVERB_CONDITION[value]
                                else:
                                    return Response().error(msg = "Your reverbsync-condition tag value: " +
                                                                  str(value) + """ does not match any of Reverb condition value. 
                                                            Valid value for mapping must be one of these value: 
                                                            Brand New, B-Stock, Mint (with inventory), Mint, Excellent, Very Good, Good, Fair, 
                                                            Poor, Non Functioning.""")
                        if not check_condition_tag:
                            return Response().error(msg = "Missing reverbsync-condition tag for mapping")
                    else:
                        return Response().error(msg = "Listing doesn't have any tags for mapping")
                else:
                    valid_condition = False
                    condition_value = category.info['reverb_condition'].get('value')
                    for item in self.reverb_condition:
                        if condition_value == item['value']:
                            valid_condition = True
                    if not valid_condition:
                        return Response().error(msg = "Your mapping value for condition is not valid")
                    condition['uuid'] = category.info['reverb_condition'].get('value')
            else:
                return Response().error(msg = 'Missing condition for listing')
            # get photos
            photos = list()
            if self.is_reverb_publish_image(product):
                if variant.thumb_image.url:
                    photos.append(variant.thumb_image.url)
                elif product.thumb_image.url:
                    photos.append(product.thumb_image.url)
                if variant.images:
                    for img in variant.images:
                        photos.append(img.url)
                elif product.images:
                    for img in product.images:
                        photos.append(img.url)
            if len(photos) == 0 or photos == ['']:
                photos = False
            if not category.info['brands'].get('value'):
                if category.info['brands'].get('override'):
                    category.info['brands']['value'] = category.info['brands']['override']
                # else:
                #     return Response().error(msg="Mapping value for brand is empty.")
            if not category.info['models'].get('value'):
                if category.info['models'].get('override'):
                    category.info['models']['value'] = category.info['models']['override']
                # else:
                #     return Response().error(msg="Mapping value for model is empty.")

            sku = ""
            name = ""
            if product.sku == variant.sku:
                attribute_values = []
                for attribute in product.attributes:
                    if not attribute.use_variant:
                        continue
                    attribute_values.append(attribute.attribute_value_name)
                if attribute_values:
                    sku = f"{variant.sku} - {'/'.join(attribute_values)}"
            else:
                sku = variant.sku

            if product.name == variant.name:
                attribute_values = []
                for attribute in product.attributes:
                    if not attribute.use_variant:
                        continue
                    attribute_values.append(attribute.attribute_value_name)
                if attribute_values:
                    name = f"{variant.name} - {'/'.join(attribute_values)}"
            else:
                name = variant.name

            # year
            year = ""
            if category['advance'].get('year'):
                year = category['advance'].get('year')
            elif category['advance'].get('years'):
                year = category['advance']['years'].get('value')
            # finish/color
            color = ""
            if category['advance'].get('color'):
                color = category['advance'].get('color')
            elif category['advance'].get('colors'):
                color = category['advance']['colors'].get('value')
            # cost
            cost = ""
            if category['advance'].get('cost'):
                cost = category['advance'].get('cost')
            elif category['advance'].get('costs'):
                cost = category['advance']['costs'].get('value')

            video = category['advance']['video'].get('value') if  category['advance'].get('video') else ""
            if video and isinstance(video, dict) and video.get('url'):
                video = video['url']
            if video and not python_validators.url(video):
                video = ''
            data = {
                "make": category.info['brands']['value'],
                "model": category.info['models']['value'],
                "description": product.description,
                "categories": categories,
                "condition": condition,
                "photos": photos,
                "title": name[:150],
                "sku": sku[:150],
                "has_inventory": not unique,
                "price": price,
                "publish": True,
                "offers_enabled": category['advance']['offers'],
                "year": year,
                "finish": color,
                "handmade": category['advance'].get('handmade', False),
                "sold_as_is": category['advance'].get('sold_as_is', False),
                "origin_country_code": category['advance'].get('origin_country', "")
            }
            if video:
                data["videos"] = [{
                                "link": video
                                }]
            # add shipping method
            if shipping and shipping.get('manual_custom'):
                rates = list()
                for rate in shipping['rates']:
                    rates.append({
                        "rate": {
                            "amount": rate['rate'],
                            "currency" : currency
                        },
                        "region_code": rate['region_code']
                    })
                data['shipping'] = {
                    "local": shipping['local'] if shipping['local'] else False,
                    "rates": rates
                }
            elif shipping and not shipping.get('manual_custom'):
                data['shipping_profile_id'] = shipping['shipping_id']
            # add inventory
            if unique and not insert:
                data['inventory'] = 1
            else:
                data['inventory'] = variant.qty
            # add seller_cost
            if cost:
                data['seller_cost'] = cost
            # add UPC
            if not upc:
                data["upc_does_not_apply"] = True
            else:
                data['upc'] = variant.upc
                data["upc_does_not_apply"] = False
            # photos
            if not photos:
                del data['photos']
                del data['publish']

            if self.is_import_draft(variant):
                if data.get('publish'):
                    del data['publish']
                data['state'] = "draft"

            check_tags = {
                "brand": False,
                "model": False,
                "shipping": False
            }
            if product.get('tags'):
                tags = product.tags.split(",")
                for tag in tags:
                    if 'reverb-inventory' in tag:
                        data['inventory'] = tag.split(':')[-1].strip()
                        data['has_inventory'] = True
                    if 'reverbsync-price' in tag:
                        if tag.split(':')[-1].strip() == "on":
                            data['price']['amount'] = to_decimal(variant.price)
                        elif tag.split(':')[-1].strip() == "off":
                            if not self.is_strict_update_price() and self.is_update_product_process():
                                # tag `reverb_sync-price:off` means the user doesn't want to sync the price
                                # but if we create a new product, we still need `price` field
                                del data['price']
                        else:
                            return Response().error(msg="Tag mapping error. Your reverbsync-price tags is not correct.")
                    if 'reverbsync-upc-does-not-apply' in tag:
                        if tag.split(':')[-1].strip() == "on":
                            data['upc_does_not_apply'] = True
                        elif tag.split(':')[-1].strip() == "off":
                            data['upc'] = variant.upc
                            data['upc_does_not_apply'] = False
                        else:
                            return Response().error(msg="Tag mapping error. Your 'reverbsync-upc-does-not-apply' tags is not correct.")
                    if 'reverbsync-offers' in tag:
                        if tag.split(':')[-1].strip() == "on":
                            data['offers_enabled'] = True
                        elif tag.split(':')[-1].strip() == "off":
                            data['offers_enabled'] = False
                        else:
                            return Response().error(msg="Tag mapping error. Your reverbsync-offers tags is not correct.")
                    if 'reverbsync-seller-cost' in tag:
                        data['seller_cost'] = tag.split(':')[-1].strip()
                    if 'reverbsync-make' in tag:
                        check_tags['brand'] = True
                        data['make'] = tag.split(':')[-1].strip()
                    if 'reverbsync-model' in tag:
                        check_tags['model'] = True
                        data['model'] = tag.split(':')[-1].strip()
                    if 'reverbsync-finish' in tag:
                        data['finish'] = tag.split(':')[-1].strip()
                    if 'reverbsync-year' in tag:
                        data['year'] = tag.split(':')[-1].strip()
                    if 'reverbsync-shipping-profile' in tag:
                        check_tags['shipping'] = True
                        shop = self.api('shop')
                        if shop.result != Response().SUCCESS:
                            return Response().error(msg="Could not get shipping profile for tags mapping")
                        shipping_profiles = shop.data['shipping_profiles']
                        check = False
                        for profile in shipping_profiles:
                            if profile['name'] == tag.split(':')[-1].strip():
                                check = True
                                data['shipping_profile_id'] = profile['id']
                                if data.get('shipping'):
                                    del data['shipping']
                        if not check:
                            return Response().error(msg="Tag mapping error. Your reverbsync-shipping-profile tag does not match any shipping profile name.")

            if not check_tags['brand'] and not category.info['brands'].get('value'):
                return Response().error(msg="BRAND_REQUIRED")
            if not check_tags['model'] and not category.info['models'].get('value'):
                return Response().error(msg="MODEL_REQUIRED")
            if not check_tags['shipping'] and not shipping:
                return Response().error(msg="SHIPPING_REQUIRED")
            if not self.is_import_draft() and categories == []:
                return Response().error(msg="CATEGORY_REQUIRED")

        except Exception as e:
            self.log_traceback()
            error = "Product " + str(variant.id) + " get error: " + str(e)
            return Response().error(msg=error)
        return Response().success(data=data)

    def is_product_change_image(self, product) -> bool:
        channel_data = product['channel'][f'channel_{self.get_channel_id()}']
        return (True
                if channel_data and channel_data.get('is_changed_image')
                else False)

    def is_update_product_process(self):
        return bool(
            self._process_type == self.PROCESS_TYPE_PRODUCT
            and self._publish_action == 'update'
        )

    def is_reverb_publish_image(self, product):
        """update images if
         1. first publish product
         2. update to reverb + change image
         3. strict delete
        """
        return (
            not self.is_update_product_process()
            or bool(
                self.is_product_change_image(product)
                and self.is_update_product_process()
            )
        ) or self.is_strict_delete_image()

    def is_order_use_shipping_name(self):
        """the reverb order have a shipping name and a buyer name
        normally, the tool use buyer's name
        this option will use shipping name as the name import to mainstore"""
        return bool(self._state.channel.config.api.order_use_shipping_name)

    def is_strict_update_price(self):
        """check the flag to be set to strict update price
        even when reverb-price turn off"""
        return bool(self._state.channel.config.api.strict_update_price)

    def is_strict_delete_image(self):
        """check the flag to be set to strict delete duplicate
        images already on reverb when update to reverb"""
        return bool(self._state.channel.config.api.strict_delete_image)

    def product_channel_update(self, product_id, product: Product, products_ext):
        def is_images_reverb_same_order_with_litc(reverb_imgs, litc_imgs):
            # reverb response has a position field, but sometimes it is not exact
            # use list indexing to check
            try:
                is_same_order = all([
                    rv_img_idx == litc_imgs.index(rv_img.get('original_url', ''))
                    for rv_img_idx, rv_img in enumerate(reverb_imgs)
                ])
                return is_same_order
            except ValueError:
                return False

        if not product.variants:
            img_info = self.api(f"listings/{product_id}/images")
            if img_info.result != Response().SUCCESS:
                if self._last_status == 404:
                    return Response().error(msg = 'REVERB_PRODUCT_NOT_FOUND')
                else:
                    return Response().error(msg=img_info.msg)

            convert_product = self.product_to_reverb_data(product, products_ext, insert = False)
            if convert_product.result != Response.SUCCESS:
                return convert_product
            product_data = convert_product.data

            litc_img_number = to_len(product_data['photos']) if product_data.get('photos') else 0
            update = self.api(f"listings/{product_id}", data = product_data, method = "put")
            # if update.result != Response().SUCCESS:
            #     return Response().error(msg=update.msg)
            if litc_img_number and self.is_reverb_publish_image(product) and not self.is_template_update():
                if "more than 25 images" in update.msg or self.is_reverb_publish_image(product):
                    if litc_img_number == 1:
                        params = {
                            "sku": product.sku
                        }
                        get_pro = self.api(f"my/listings", data = params, method = "get")
                        if get_pro.result != Response().SUCCESS:
                            return Response().error(msg = get_pro.msg)
                        list_old_photo_ids = [
                            photos.id for photos in get_pro.data.listings[0].cloudinary_photos
                        ]
                        for photo_id in list_old_photo_ids:
                            delete_old = self.api(f"listings/{product_id}/images/{photo_id}", method = "delete")
                    else:
                        max_check_round_1 = self._state.channel.config.api.max_check_round or max(5, litc_img_number)
                        max_check_round_2 = self._state.channel.config.api.max_check_round_2 or 5
                        round_1 = 0
                        check_update = False
                        while round_1 < max_check_round_1:
                            round_1 += 1
                            params = {
                                "sku": product.sku
                            }
                            get_pro = self.api(f"my/listings", data = params, method = "get")
                            if get_pro.result != Response().SUCCESS:
                                return Response().error(msg = get_pro.msg)
                            last_img_old = ""
                            list_old_photo_ids = [
                                photos.id for photos in get_pro.data.listings[0].cloudinary_photos
                            ]
                            # edge case: reverb have many similar images
                            if round_1 == 0 or len(list_old_photo_ids) > litc_img_number:
                                for photo_id in list_old_photo_ids:
                                    delete_old = self.api(f"listings/{product_id}/images/{photo_id}", method = "delete")
                                    if delete_old.result == "error" and "the last" in delete_old.msg:
                                        last_img_old = photo_id
                            product_images_data = {
                                "photos": product_data['photos'],
                                "photo_upload_method": "override_position"
                            }
                            update_images = self.api(f"listings/{product_id}", data = product_images_data, method = "put")
                            if update_images.result != Response().SUCCESS:
                                return Response().error(msg = update_images.msg)
                            time.sleep(10)
                            round_2 = 0
                            while round_2 < max_check_round_2:
                                round_2 += 1
                                img_info_retry = self.api(f"listings/{product_id}/images")
                                if img_info_retry.result != Response().SUCCESS:
                                    return Response().error(msg = get_pro.msg)
                                if (
                                        litc_img_number == len(img_info_retry.data.images)
                                        and is_images_reverb_same_order_with_litc(img_info_retry.data.images, product_data['photos'])
                                ):
                                    round_1 = max_check_round_1
                                    check_update = True
                                    break
                                elif last_img_old:
                                    self.api(f"listings/{product_id}/images/{last_img_old}", method = "delete")
                                    last_img_old = ''
                                product_images_data = {
                                    "photos": product_data['photos'],
                                    "photo_upload_method": "override_position"
                                }
                                update_images = self.api(f"listings/{product_id}", data = product_images_data, method = "put")
                                if update_images.result != Response().SUCCESS:
                                    return Response().error(msg = update_images.msg)
                                time.sleep(10)
                        if not check_update:
                            return Response().error(msg = "Update images failed. Please try update again.")

                else:
                    if update.result != Response().SUCCESS:
                        return Response().error(msg = update.msg)
            else:
                if update.result != Response().SUCCESS:
                    return Response().error(msg = update.msg)
        else:
            error = ""
            for variant in product.variants:
                try:
                    # reverb_variant_listing = self.get_product_by_sku(variant.sku)
                    channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
                    if not channel_data.get('product_id'):
                        continue
                    reverb_variant_listing = self.get_product_by_id(channel_data.product_id)
                    log_product_update = {
                        "id": variant.id,
                        "data": reverb_variant_listing
                    }
                    self.log(log_product_update, "get_product_update")
                    if reverb_variant_listing.result != Response().SUCCESS or not reverb_variant_listing.data.get("id", {}):
                        if reverb_variant_listing.result == Response().DELETED:
                            error = error + str(variant['sku']) + ": Listing does not exist on reverb. "
                            continue
                        else:
                            error = error + str(variant['sku']) + ": " + str(reverb_variant_listing.msg) + ". "
                            continue
                    variant_id = reverb_variant_listing.data['id']
                    img_info = self.api("listings/" + str(variant_id) + "/images")
                    if img_info.result != Response().SUCCESS:
                        return Response().error(msg=img_info.msg)
                    if not self.is_template_update():
                        count = len(img_info.data['images']) - 1
                        is_delete_variant_image = self.is_reverb_publish_image(product)
                        while count > 0 and is_delete_variant_image:
                            img_id = img_info.data['images'][count]['id']
                            img_remove = self.api(path="listings/" + str(variant_id) + "/images/" + str(img_id), method="delete")
                            count = count - 1
                            if img_remove.result != Response().SUCCESS:
                                error = error + str(variant['sku']) + ": " + str(img_remove.msg) + ". "
                                continue
                        convert_variant = self.variant_to_reverb_data(variant, product, insert = False)
                        if convert_variant.result != Response().SUCCESS:
                            error = error + str(variant['sku']) + ": " + str(convert_variant.msg) + ". "
                            continue
                        litc_img_number = to_len(convert_variant.data['photos']) if convert_variant.data.get('photos') else 0
                        variant_update = self.api('listings/' + str(variant_id), method="put", data=convert_variant.data)
                        if variant_update.result != Response().SUCCESS:
                            error = error + str(variant['sku']) + ": " + str(variant_update.msg) + ". "
                            continue
                        update_data = {
                            f'channel.channel_{self.get_channel_id()}.reverb_status': "live"
                        }
                        self.get_model_catalog().update(variant['_id'], update_data)

                        if not litc_img_number:
                            continue
                        time.sleep(10)
                        check_img_info = self.api("listings/" + str(variant_id) + "/images")
                        if check_img_info.result != Response().SUCCESS:
                            error = error + str(variant['sku']) + ": " + str(check_img_info.msg) + ". "
                            continue
                        if len(check_img_info.data['images']) == litc_img_number + 1:
                            img_remove = self.api(path="listings/" + str(variant_id) + "/images/" + str(check_img_info.data['images'][0]['id']), method="delete")
                            if img_remove.result != Response().SUCCESS:
                                error = error + str(variant['sku']) + ": " + str(img_remove.msg) + ". "
                        if error:
                            return Response().error(msg=error)
                except Exception as e:
                    self.log_traceback()
                    return Response().error(msg="Error during update product. Please contact support for more information.")
            if error:
                return Response().error(msg=error)

        self.update_flag_changed_image(product)
        return Response().success()

    def update_flag_changed_image(self, product):
        if self.is_product_change_image(product):
            self.get_model_catalog().update_field(
                product['_id'], f'channel.channel_{self.get_channel_id()}.is_changed_image', False
            )

    def extend_data_insert_map_product(self):
        extend = super().extend_data_insert_map_product()
        if self.is_import_draft():
            extend['reverb_status'] = 'reverb_draft'
        return extend

    def get_draft_extend_channel_data(self, product):
        extend_data = dict()
        extend_data['template_data'] = {
            "category": {
                "info": {
                "brands": {
                    "mapping": "",
                    "override": "",
                    "value": "",
                },
                "models": {
                    "mapping": "",
                    "override": "",
                    "value": "",
                },
                "reverb_condition": {
                    "mapping": "",
                    "override": "",
                    "value": "",
                    "tags": False
                }
                },
                "advance": {
                    "offers": False,
                    "unique": False,
                    "has_upc": False,
                    "years": {
                        "mapping": "",
                        "override": "",
                        "value": "",
                    },
                    "colors": {
                        "mapping": "",
                        "override": "",
                        "value": "",
                    },
                    "costs": {
                        "mapping": "",
                        "override": "",
                        "value": "",
                    },
                    "origin_country": "",
                    "handmade": False,
                    "sold_as_is": False
                }
            },
            "shipping": {
                "manual_custom": False,
                "local": False,
                "rates": [{
                    "rate": "",
                    "region_code": ""
                }],
                "shipping_id": "",
                "default": False
            }
        }
        if product.get('tags'):
            tags = product.tags.split(",")
            for tag in tags:
                if 'reverb-inventory' in tag:
                    extend_data['qty'] = tag.split(':')[-1].strip()
                if 'reverbsync-upc-does-not-apply' in tag:
                    if tag.split(':')[-1].strip() == "on":
                        extend_data['template_data']['category']['advance']['has_upc'] = False
                    elif tag.split(':')[-1].strip() == "off":
                        extend_data['upc'] = product.upc
                        extend_data['template_data']['category']['advance']['has_upc'] = True
                if 'reverbsync-offers' in tag:
                    if tag.split(':')[-1].strip() == "on":
                        extend_data['template_data']['category']['advance']['offers'] = True
                    elif tag.split(':')[-1].strip() == "off":
                        extend_data['template_data']['category']['advance']['offers'] = False
                if 'reverbsync-seller-cost' in tag:
                    extend_data['template_data']['category']['advance']['costs']['value'] = tag.split(':')[-1].strip()
                if 'reverbsync-make' in tag:
                    extend_data['template_data']['category']['info']['brands']['value'] = tag.split(':')[-1].strip()
                if 'reverbsync-model' in tag:
                    extend_data['template_data']['category']['info']['models']['value'] = tag.split(':')[-1].strip()
                if 'reverbsync-finish' in tag:
                    extend_data['template_data']['category']['advance']['colors']['value'] = tag.split(':')[-1].strip()
                if 'reverbsync-year' in tag:
                    extend_data['template_data']['category']['advance']['years']['value'] = tag.split(':')[-1].strip()
                if 'reverbsync-condition' in tag:
                    tag_value = tag.split(':')[-1].strip()
                    if self.REVERB_CONDITION.get(tag_value):
                        extend_data['template_data']['category']['info']['reverb_condition']['value'] = self.REVERB_CONDITION[tag_value]
                if 'reverbsync-shipping-profile' in tag:
                    shop = self.api('shop')
                    if shop.result == Response().SUCCESS:
                        shipping_profiles = shop.data['shipping_profiles']
                        for profile in shipping_profiles:
                            if profile['name'] == tag.split(':')[-1].strip() or profile['id'] == tag.split(':')[-1].strip():
                                extend_data['template_data']['shipping']['shipping_id'] = profile['id']
        return extend_data

    # orders
    def get_orders_main_export(self):
        try:
            # imported = self._state.pull.process.orders.imported
            # limit_data = self._state.pull.setting.orders
            created_channel = self.get_order_start_time('iso')
            last_modifier = self._state.pull.process.orders.max_last_modified
            params = {
                'created_start_date': created_channel,
                'per_page': 50
            }
            if last_modifier:
                params['updated_start_date'] = last_modifier
            page = 0
            total_page = 1
            result = list()
            while page <= total_page:
                page = page + 1
                params['page'] = page
                orders = self.api('my/orders/selling/all', data=params)
                if orders.result != Response().SUCCESS:
                    return Response().finish()
                total_page = orders.data.get('total_pages')
                for order in orders.data.get('orders'):
                    result.append(order)
        except Exception as e:
            self.log_traceback()
            error = "Error: " + str(e)
            return Response().finish()
        return Response().success(data=result)


    def get_order_by_id(self, order_id):
        order = self.api(path = f"my/orders/selling/{order_id}")
        if self.is_log():
            self.log(order.text, 'orders')
        if self._last_status == 200:
            return Response().success(order.data)
        return Response().success()


    def get_orders_ext_export(self, orders):
        return Response().success()

    def convert_order_export(self, order, orders_ext, channel_id=None):
        order_create = isoformat_to_datetime(order.created_at)
        start_time = self.get_order_start_time(False)
        if order_create.timestamp() < start_time:
            return Response().skip()
        self.set_order_max_last_modifier(order.updated_at)
        order_data = Order()
        order_data.id = order.order_number
        order_data.order_number = order.order_number
        if order.status in ['unpaid', 'payment_pending', 'pending_review', 'blocked']:
            return Response().skip()
        order_data.status = self.ORDER_STATUS[order.status]
        param_check = {
            "order_id": order.order_number
        }
        check_refund = self.api('my/payments/selling', data = param_check, method = 'get')
        total_refund = 0
        total_payment = 0
        if check_refund.data and check_refund.data.total != 0 and check_refund.data.payments:
            for payment in check_refund.data.payments:
                if payment.status == 'refunded':
                    total_refund += to_decimal(payment.amount.amount)
                    order_refund = OrderRefund()
                    order_refund.amount = -to_decimal(payment.amount.amount, 2)
                    order_data.refunds.append(order_refund)
                else:
                    total_payment += to_decimal(payment.amount.amount)
            if total_refund < 0 < total_payment:
                after_refund = total_payment + total_refund
                if after_refund > 0:
                    order_data.status = self.ORDER_STATUS['PARTIALLY_REFUNDED']
                    order_refund = OrderRefund()
                    order_refund.amount = to_decimal(0 - total_refund, 2)
                    order_data.refunds.append(order_refund)
                else:
                    order_data.status = self.ORDER_STATUS['REFUNDED']
        order_data.currency = order.total.currency
        order_data.created_at = self.convert_format_time(order.created_at)
        order_data.updated_at = self.convert_format_time(order.updated_at)
        order_data.channel_data = {
            'order_status': order_data.status,
            'created_at': order_data.created_at,
            'shipped_date': self.convert_format_time(order.shipped_date) if order.shipped_date else ''
        }
        order_data.customer.username = order.buyer_name
        order_data.customer.first_name = order.buyer_first_name
        order_data.customer.last_name = order.buyer_last_name
        if self.is_order_use_shipping_name():
            order_data.customer.username = order.shipping_address.name
            shipping_name_split = to_str(order.shipping_address.name).split()
            order_data.customer.first_name = shipping_name_split[0]
            order_data.customer.last_name = (' '.join(shipping_name_split[1:])
                                             if len(shipping_name_split) > 1
                                             else order.shipping_address.name)

        order_data.customer.email = order.buyer_email

        address = OrderAddress()
        if order.shipping_address:
            address.address_1 = order.shipping_address.street_address
            address.address_2 = order.shipping_address.extended_address if order.shipping_address.extended_address else None
            address.country.country_code = order.shipping_address.country_code
            country_info = CountryInfo(order.shipping_address.country_code)
            address.country.country_name = country_info.native_name()
            address.city = order.shipping_address.locality
            address.postcode = order.shipping_address.postal_code
            address.telephone = order.shipping_address.phone or order.shipping_address.unformatted_phone
            address.first_name = order.buyer_first_name
            address.last_name = order.buyer_last_name
            if self.is_order_use_shipping_name():
                shipping_name_split = to_str(order.shipping_address.name).split()
                address.first_name = shipping_name_split[0]
                address.last_name = (' '.join(shipping_name_split[1:])
                                     if len(shipping_name_split) > 1
                                     else order.shipping_address.name)

            address.state = OrderAddressState()
            address.state.state_code = order.shipping_address.region

            order_data.customer_address.update(address)

            order_data.billing_address.update(address)
            order_data.shipping_address.update(address)
        if order.shipping_method == 'local':
            order_data.additional_details.append({
                'name': 'Local Pickup Status',
                'value': order.status,
            })
            order_data.shipping.title = 'Local Pickup'
        order_data.payment.method = order.payment_method

        for note in order.order_notes:
            history = OrderHistory()
            history.comment = note
            order_data.history.append(history)

        product_id = order.product_id
        product_info = self.api("/listings/" + str(product_id))
        if product_info.result != Response().SUCCESS:
            return Response().error(msg=product_info.msg)
        product_info = product_info.data
        order_item = OrderProducts()
        order_item.product_id = product_id
        price = product_info['price']['amount']
        if to_decimal(price) <= to_decimal(order.amount_product.amount):
            price = to_decimal(order.amount_product.amount)
        order_item.price = price
        order_item.total = round(to_decimal(product_info['price']['amount']) * to_decimal(order.quantity), 2)
        order_item.qty = order.quantity
        order_item.product_sku = order.sku
        order_item.product_name = product_info['title']
        order_data.products.append(order_item)

        order_data.subtotal = to_decimal(order.amount_product_subtotal.amount)
        order_data.total = to_decimal(order.total.amount)
        order_data.discount.amount = to_decimal(price) * to_decimal(order.quantity) - to_decimal(order.amount_product_subtotal.amount)
        order_data.shipping.amount = to_decimal(order.shipping.amount)
        order_data.shipping.method = order.shipping_method
        order_data.tax.amount = to_decimal(order.amount_tax.amount)
        order_data.currency = order.total.currency
        return Response().success(order_data)

    def finish_order_export(self):
        if self._order_max_last_modified:
            self._state.pull.process.orders.max_last_modified = self._order_max_last_modified

    def get_order_id_import(self, convert: Order, order, orders_ext):
        return order.order_number

    def simple_sync_inventory(self, product_id, product: Product, parent: Product or None, products_ext, is_variant: False):
        setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
        setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
        setting_title = True if self.is_setting_sync_title() != 'disable' else False
        reverb_product = self.get_product_by_id(product_id)
        if reverb_product.result != Response.SUCCESS:
            return Response().success(product)
        if reverb_product.data.get('state') and reverb_product.data['state'].get('slug') == "draft":
            return Response().success(product)
        if self.is_sync_product_invisible(product):
            update_data = {
                "reason": "not_sold"
            }
            res = self.api("/my/listings/" + str(product_id) + "/state/end", method='put', data=update_data)
            # self.log("Invi: " + str(product.sku))
            if res.result == Response().SUCCESS or (self._last_status == 422 and 'This listing has already ended' in res.msg):
                if not is_variant:
                    update_product = {
                        f"channel.channel_{self.get_channel_id()}.state": "ended",
                        f"channel.channel_{self.get_channel_id()}.reverb_status": "ended"
                        # f"channel.channel_{self.get_channel_id()}.qty": 0,
                        # "state": "draft",
                        # "qty": 0
                    }
                    self.get_model_catalog().update(product['_id'], update_product)
                    return Response().success(product)
                return Response().create_response('end')
            return res
        category = product.get('template_data', {}).get('category') if not parent else parent.get('template_data', {}).get('category')
        if not category or not category.get('advance', {}) or not category.get('advance', {}).get('has_upc', {}):
            upc_does_not_apply = True
        else:
            upc_does_not_apply = False
        reverb_product_data = reverb_product['data']
        convert = self.convert_product_export(reverb_product['data'], None).data
        product_status = product.status
        # if setting_price and self.is_special_price(product):
        #     product.price = product.special_price.price
        qty = product.qty
        if setting_qty:
            if not qty:
                update_data = {
                    "inventory": 0,
                    'upc_does_not_apply': upc_does_not_apply
                }
                if setting_title:
                    update_data['title'] = product.name
                res = self.api("/listings/" + str(product_id), method='put', data=update_data)
                # self.log("Qty: " + str(product.sku))
                if res.result == Response().SUCCESS:
                    if not is_variant:
                        reverb_status = res.data['listing']['state'].get('slug')
                        update_product = {
                            f"channel.channel_{self.get_channel_id()}.state": "ended",
                            f"channel.channel_{self.get_channel_id()}.reverb_status": reverb_status
                            # f"channel.channel_{self.get_channel_id()}.qty": 0,
                            # "state": "draft",
                            # "qty": 0
                        }
                        self.get_model_catalog().update(product['_id'], update_product)
                        return Response().success(product)
                else:
                    return Response().error(msg=res.msg)
            else:
                if reverb_product_data['state'].get('slug') != 'live' and reverb_product_data.get('photos') != []:
                    update_data = {
                        'inventory': qty,
                        'publish': True,
                        'upc_does_not_apply': upc_does_not_apply

                    }
                    if setting_title:
                        update_data['title'] = product.name
                    res = self.api("/listings/" + str(product_id), method='put', data=update_data)
                    if res.result == Response().SUCCESS:
                        reverb_status = 'live'
                    else:
                        return Response().error(msg=res.msg)

        if self._state.channel.config.api.get('currency'):
            currency = self._state.channel.config.api.get('currency')
        else:
            currency = self.get_shop_currency()
            if not currency:
                return Response().error(msg="Could not get currency. Please contact custome service for more information.")

        update_data = {
            "price": {
                "amount": to_decimal(product.price),
                "currency": currency
            },
            "inventory": qty,
            'upc_does_not_apply': upc_does_not_apply

        }
        if not setting_qty:
            update_data['inventory'] = convert.qty
        if not setting_price:
            try:
                update_data['price']['amount'] = convert.price
            except Exception as e:
                self.log_traceback()
                return Response().error(msg="Price sync error. Please contact support for more information.")

        if product.get('tags'):
            tags = product.tags.split(",")
            for tag in tags:
                if 'reverb-inventory' in tag:
                    update_data['inventory'] = tag.split(':')[-1].strip()
                if 'reverbsync-price' in tag:
                    if tag.split(':')[-1].strip() == "on":
                        update_data['price']['amount'] = to_decimal(product.price)
                    elif tag.split(':')[-1].strip() == "off":
                        del update_data['price']
                        # update_data['price']['amount'] = convert.price

        if setting_title:
            update_data['title'] = product.name
        res = self.api("/listings/" + str(product_id), method='put', data=update_data)
        if res.result != Response().SUCCESS:
            return Response().error(msg=res.msg)
        update_product = {
            f"channel.channel_{self.get_channel_id()}.state": product_status,
            f"channel.channel_{self.get_channel_id()}.reverb_status": "live",
            # f"channel.channel_{self.get_channel_id()}.qty": qty,
            # "state": status,
            # "qty": qty
        }
        # self.log(str(status) + ": " + str(product.sku))
        self.get_model_catalog().update(product['_id'], update_product)
        return Response().success(product)

    def channel_sync_title(self, product_id, product, products_ext):
        """channel sync title and description"""
        if not (self.is_setting_sync_title() and self.is_setting_sync_description()):
            return Response().success(product)

        if not product.variants:
            return self.simple_sync_title_description(product_id, product, products_ext)
        for variant in product.variants:
            try:
                variant_id = variant['channel'][f'channel_{self.get_channel_id()}'].get('product_id')
                variant_update = self.simple_sync_title_description(variant_id, product, products_ext)
            except:
                self.log_traceback()
        return Response().success(product)

    def simple_sync_title_description(self, product_id, product, products_ext):
        """channel sync title and description"""
        update_data = {}
        if self.is_setting_sync_title():
            update_data.update({'title': product.name})
        if self.is_setting_sync_description():
            update_data.update({'description': product.description})

        if not update_data:
            return Response().success(product)

        res = self.api("/listings/" + str(product_id), method = 'put', data = update_data)
        if res.result != Response().SUCCESS:
            return Response().error(msg = res.msg)

        return Response().success(product)


    def channel_sync_inventory(self, product_id, product, products_ext):
        setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
        setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
        if not setting_price and not setting_qty:
            return Response().success(product)
        if not product.variants:
            return self.simple_sync_inventory(product_id, product, None, products_ext, is_variant=False)
        else:
            number_error = 0
            number_end = 0
            msg_error = ''
            same_error = True
            variant_no_error = []
            variant_end = []
            check_qty = False
            for variant in product.variants:
                if variant.qty > 0:
                    check_qty = True
                channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
                if not channel_data or not channel_data.get('product_id'):
                    continue
                variant_update = self.simple_sync_inventory(channel_data.get('product_id'), variant, product, products_ext, is_variant=True)
                if variant_update.result != Response.SUCCESS:
                    if variant_update.result == 'end':
                        variant_no_error.append(variant['_id'])
                        variant_end.append(variant['_id'])
                        number_end += 1
                    else:
                        if not msg_error:
                            msg_error = variant_update.msg
                        if variant_update.msg and variant_update.msg != msg_error:
                            same_error = False
                        number_error += 1
                        update_data = {
                            f'channel.channel_{self.get_channel_id()}.error_message': f"Error while syncing: {variant_update.msg}",
                            f'channel.channel_{self.get_channel_id()}.sync_error': True,
                        }
                        self.get_model_catalog().update(variant['_id'], update_data)
                else:
                    variant_no_error.append(variant['_id'])
            # if variant_no_error:
            #     update_data = {
            #         f'channel.channel_{self.get_channel_id()}.error_message': f"",
            #         f'channel.channel_{self.get_channel_id()}.sync_error': False,
            #     }
            #     if number_end == to_len(product.variants):
            #         update_data[f'channel.channel_{self.get_channel_id()}.reverb_status'] = 'ended'
            #     self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', variant_no_error, 'in'), update_data)

            if not number_error:
                if not check_qty:
                    update_parent = {
                        f'channel.channel_{self.get_channel_id()}.reverb_status': "sold"
                    }
                else:
                    update_parent = {
                        f'channel.channel_{self.get_channel_id()}.reverb_status': "active"
                    }
                if number_end == to_len(product.variants):
                    update_parent[f'channel.channel_{self.get_channel_id()}.reverb_status'] = 'ended'
                if update_parent:
                    self.get_model_catalog().update(product['_id'], update_parent)
                return Response().success()
            response_msg = msg_error if same_error else f"Have {number_error} sync error"
            return Response().error(msg = response_msg)

    def order_sync_inventory(self, order: Order, setting_order):
        for item in order.products:
            product_id = item['id']
            reverb_product = self.get_product_by_id(product_id)
            reverb_convert = self.convert_product_export(reverb_product, None)
            convert = reverb_convert.data
            item_qty = to_int(item['qty']) if to_int(item.qty) > 0 else 1
            qty = to_int(convert.qty)
            new_qty = qty - item_qty

            if new_qty <= 0:
                update_data = {
                    'publish': False
                }
                res = self.api("/listings/" + str(product_id), method='put', data=update_data)
                if res.result != Response().SUCCESS:
                    return Response().error(msg=res.msg)
            else:
                update_data = {
                    "price": {
                        "amount": item.price,
                        "currency": item.currency
                    },
                    "inventory": item.qty
                }
                res = self.api("/listings/" + str(product_id), method='put', data=update_data)
                if res.result != Response().SUCCESS:
                    return Response().error(msg=res.msg)
        return Response().success()


    def channel_assign_category_template(self, product, template_data):
        item_list = ['brands', 'models', 'years', 'colors', 'costs']
        for item in item_list:
            if item in ['brands', 'models']:
                if not template_data['info'][item].get('override') and not template_data['info'][item].get('mapping'):
                    continue
                if template_data['info'][item].get('override'):
                    value = template_data['info'][item]['override']
                else:
                    value = template_data['info'][item]['mapping']
                template_data['info'][item]['value'] = self.assign_attribute_to_field(value, product)
            else:
                if not template_data['advance'].get(item):
                    continue
                if not template_data['advance'][item].get('override') and not template_data['advance'][item].get('mapping'):
                    continue
                if template_data['advance'][item].get('override'):
                    value = template_data['advance'][item]['override']
                else:
                    value = template_data['advance'][item]['mapping']
                template_data['advance'][item]['value'] = self.assign_attribute_to_field(value, product)
        if template_data['info'].get('reverb_condition'):
            if template_data['info']['reverb_condition'].get('tags'):
                if product.get('tags'):
                    tags = product['tags'].split(",")
                    check_tag = False
                    for tag in tags:
                        if "reverbsync-condition" in tag:
                            check_tag = True
                            tag_value = str(tag.split(":")[-1]).strip()
                            for condition in self.reverb_condition:
                                if to_str(condition['label']).lower() == to_str(tag_value).lower():
                                    template_data['info']['reverb_condition']['value'] = condition['value']
                    if not check_tag:
                        template_data['info']['reverb_condition']['value'] = ""
                elif template_data['info']['reverb_condition'].get('value', {}):
                    pass
                else:
                    template_data['info']['reverb_condition']['value'] = ""
            elif template_data['info']['reverb_condition'].get('override'):
                template_data['info']['reverb_condition']['value'] = template_data['info']['reverb_condition']['override']
            elif template_data['info']['reverb_condition'].get('mapping'):
                value = template_data['info']['reverb_condition']['mapping']
                condition_value = self.assign_attribute_to_field(value, product)
                check = False
                for condition in self.reverb_condition:
                    if condition['label'] == condition_value:
                        check = True
                        template_data['info']['reverb_condition']['value'] = condition['value']
                if not check:
                    template_data['info']['reverb_condition']['value'] = ""


        if template_data.get('category_mapping'):
            channel_settings = self._state.channel.config.setting
            if channel_settings.get('reverb_mapping') and channel_settings['reverb_mapping'].get('category_mapping'):
                reverb_mapping_rules = channel_settings['reverb_mapping'].get('mapping_value')
                for rule in reverb_mapping_rules:
                    if str(product['product_type']).lower() == str(rule['label']).lower():
                        template_data['category'] = [{
                            "uuid": rule['value']['uuid'],
                            "full_name": rule['value']['full_name']
                        }]

        if template_data['advance'].get('video'):
            if template_data['advance']['video'].get('override'):
                template_data['advance']['video']['value'] = template_data['advance']['video']['override']
            else:
                if "product_video" in template_data['advance']['video']['mapping']:
                    value = template_data['advance']['video']['mapping']
                    index = value.split("_")[-1]
                    if product.get('videos') and len(product['videos']) > int(index):
                        template_data['advance']['video']['value'] = product['videos'][int(index)].get('url')
                    else:
                        template_data['advance']['video']['value'] = ""
                else:
                    value = template_data['advance']['video']['mapping']
                    template_data['advance']['video']['value'] = self.assign_attribute_to_field(value, product)

        product.channel[f'channel_{self.get_channel_id()}']['template_data']['category'] = template_data
        return product

    def channel_assign_shipping_template(self, product, template_data):
        return product


    def solve_api_response(self, data):
        if isinstance(data, list):
            return_data = []
            for row in data:
                return_data.append(self.solve_api_response(row))
            return return_data
        if isinstance(data, dict):
            return_data = {}
            for key, value in data.items():
                if key in ['_link','_links', 'self']:
                    key = f'litc{key}'
                return_data[key] = self.solve_api_response(value)
            return return_data
        return data

    def api(self, path='', method='get', data=None, headers=None, retry=0):
        if not headers:
            headers = {
                "Content-type": "application/hal+json",
                "Accept": "application/hal+json",
                "Accept-version": "3.0",
                # "User-Agent": get_random_useragent(),
                "Authorization": "Bearer " + str(self._state.channel.config.api.token)
            }
        if not self._state.channel.config.api.get('currency'):
            currency = self.get_shop_currency()
            if currency:
                headers['X-Display-Currency'] = currency
            else:
                self.log("Error getting currency")
        else:
            headers['X-Display-Currency'] = self._state.channel.config.api.currency

        url = self.get_api_url() + '/' + path.strip('/')
        response = None
        try:
            if method in ['post', 'put', 'patch']:
                response = requests.request(method=method, url=url, json=data, headers=headers)
            if method == 'get':
                response = requests.request(method=method, url=url, params=data, headers=headers)
            if method == 'delete':
                response = requests.request(method=method, url=url, headers=headers)
            self._last_status = response.status_code
            if response.status_code > 300 or self.is_log():
                self.log_request_error(url, method = method, data = data, status_code = response.status_code, response = response.text)
                if response.status_code >= 500:
                    if retry < 5:
                        retry += 1
                        time.sleep(5 * retry)
                        return self.api(path, method, data, headers, retry)
                    return Response().error(msg="Reverb server error. Please try again later.")
                elif response.status_code >= 400:
                    if response.status_code in [406, 429] and retry < 5:
                        retry += 1
                        time.sleep(5 * retry)

                        return self.api(path, method, data, headers, retry)
                    return Response().error(msg=response.json().get('message'))
                elif response.status_code >= 300:
                    return Response().error(msg=response.text)
                else:
                    return_data = response.json()
                    return_data = self.solve_api_response(return_data)
                    return Response().success(data=return_data)
            else:
                return_data = response.json()
                return_data = self.solve_api_response(return_data)
                return Response().success(data=return_data)
        except Exception as e:
            self.log_traceback()

            return Response().error(msg="API Error. Please contact support for more information.")


    def get_api_url(self):
        return 'https://api.reverb.com/api' if self.get_app_mode() == 'production' else 'https://sandbox.reverb.com/api'
        # if is_local():
        #     return get_config_ini('reverb', 'sandbox')
        # return get_config_ini('reverb', 'api')

    def get_app_mode(self):
        app_mode = self._state.channel.config.api.app_mode
        if not app_mode:
            return get_config_ini('reverb', 'mode', 'production')
        return app_mode

    def get_shop_currency(self):
        url = self.get_api_url() + "/shop"
        headers = {
            "Content-type": "application/hal+json",
            "Accept": "application/hal+json",
            "Accept-version": "3.0",
            "User-Agent": get_random_useragent(),
            "Authorization": "Bearer " + str(self._state.channel.config.api.token)
        }
        shop_info = requests.get(url=url, headers=headers)
        if shop_info.status_code == 200:
            self._state.channel.config.api.currency = shop_info.json().get('currency')
            self.update_channel(api = json_encode(self._state.channel.config.api))
            return shop_info.json().get('currency')
        return False

    def set_order_max_last_modifier(self, last_modifier):
        if last_modifier and (
                not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S") > to_timestamp(
                self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
            self._order_max_last_modified = last_modifier

    def get_product_by_id(self, product_id):
        products = self.api(f"listings/{product_id}/edit")
        if self._last_status == 404:
            return Response().create_response(result = Response.DELETED)
        if products.result != Response().SUCCESS:
            return Response().error(msg=products.msg)
        product = products.data
        return Response().success(data = product)

    def get_product_by_sku(self, product_sku):
        params = {
            "state": "all",
            "sku": product_sku
        }
        products = self.api(f"my/listings", data=params)
        if self._last_status == 404:
            return Response().create_response(result = Response.DELETED)
        if products.result != Response().SUCCESS:
            return Response().error(msg=products.msg)
        product = products.data
        return Response().success(data = product)

    # def check_response_import(self, response, convert, entity_type = ''):
    #     entity_id = convert.id if convert.id else convert.code
    #     if not response:
    #         return Response().error()
    #     elif response and hasattr(response, 'errors') and response.errors:
    #         console = list()
    #         if isinstance(response.errors, list):
    #             for error in response.errors:
    #                 if isinstance(error, list):
    #                     error_messages = ' '.join(error)
    #                 else:
    #                     error_messages = error
    #                 console.append(error_messages)
    #         if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
    #             for key, error in response['errors'].items():
    #                 if isinstance(error, list):
    #                     error_messages = ' '.join(error)
    #                 else:
    #                     error_messages = error
    #                 console.append(key + ': ' + error_messages)
    #         else:
    #             console.append(response['errors'])
    #         msg_errors = '_lic_nl_'.join(console)
    #         self.log(entity_type + ' id ' + to_str(entity_id) + ' import failed. Error: ' + msg_errors,
    # 		         "{}_errors".format(entity_type))
    #         return Response().error(msg = msg_errors)

    #     else:
    #         return Response().success()

    def convert_format_time(self, timedata):
        time_obj = isoformat_to_datetime(timedata)
        return time_obj.strftime("%Y-%m-%d %H:%M:%S")


    def channel_order_is_completed(self, order_id):
        try:
            order = self.api(path = f"my/orders/selling/{order_id}")
            if self._last_status == 200:
                reverb_order = order.data
                if reverb_order and (reverb_order.get('status') != 'shipped' or not reverb_order.get('shipping_provider') or not reverb_order.get('shipping_code')):
                    return False
        except:
            self.log_traceback()
            return True
        return True


    def channel_order_completed(self, order_id, order: Order, current_order):
        reverb_order_req = self.api(path = f"my/orders/selling/{order_id}")
        if self._last_status != 200:
            return Response().error(msg = "No Order")
        reverb_order = reverb_order_req.data
        try:
            tracking_company = TrackingCompany(order.shipments.tracking_company_code, order.shipments.tracking_company, channel_type = 'reverb')
            tracking_company_reverb_code = tracking_company.get_code()
            submit_tracking = {}
            if reverb_order.status != "shipped":
                if not reverb_order.shipping_code:
                    submit_tracking['tracking_number'] = order.shipments.tracking_number or ''
                if not reverb_order.shipping_provider:
                    submit_tracking['provider'] = tracking_company_reverb_code
                if submit_tracking:
                    submit_tracking['send_notification'] = False
                    self.api(f'my/orders/selling/{order_id}/ship', data = submit_tracking, method = 'post')
                    if self._last_status < 300:
                        return_order = {"status": 'Completed'}
                        return Response().success(return_order)

        except:
            log_traceback()
            return Response().error(Errors.EXCEPTION)

        return Response().error(msg="Could not update completed order. Please contact support for more information.")

    def get_sizes(self, url):
        req = Request(url, headers = {'User-Agent': get_random_useragent()})
        try:
            file = urlopen(req)
        except:
            self.log('image: ' + to_str(url) + ' 404', 'image_error')
            return False, False
        size = file.headers.get("content-length")
        # date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
        # type = file.headers.get('content-type')
        if size: size = to_int(size)
        p = ImageFile.Parser()
        while 1:
            data = file.read(1024)
            if not data:
                break
            p.feed(data)
            if p.image:
                return size, p.image.size
        file.close()
        return size, False

    def resize_image(self, url):
        name = os.path.basename(url)
        result = dict()
        result['filename'] = name
        result['attachment'] = ''
        try:
            image_size, wh = self.get_sizes(url)
            w = 4000
            h = 4000
            if wh:
                w = wh[0]
                h = wh[1]
                if to_decimal(to_decimal(w) * to_decimal(h), 2) > to_decimal(4000 * 4000, 2):
                    if to_decimal(w) > to_decimal(h):
                        h = 4000 * h / w
                        w = 4000
                    else:
                        w = 4000 * w / h
                        h = 4000
                else:
                    return None
            time.sleep(0.4)
            r = requests.get(url)
            if r.status_code != 200:
                return result
            img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
            new_width = to_int(w)
            new_height = to_int(h)
            img = img.resize((new_width, new_height), Image.ANTIALIAS)
            output = io.BytesIO()
            if img.mode != 'RGB':
                img = img.convert('RGB')
            img.save(output, format = 'JPEG')
            im_data = output.getvalue()
            image_data = base64.b64encode(im_data)
            if not isinstance(image_data, str):
                # Python 3, decode from bytes to string
                image_data = image_data.decode()
                result['attachment'] = image_data
                return result
        except:
            self.log(url, 'url_fail')
            self.log_traceback("url_fail")
        return None

    def set_product_pull_type(self):
        product_status = self._product_pull_type
        product_next_type = {
            'live': 'ended',
            'ended': 'sold',
            'sold': 'draft',
            'draft': ''
        }
        self._product_pull_type = product_next_type.get(product_status, '')

    def set_imported_product(self, imported):
        if self._product_pull_type == 'live':
            self._state.pull.process.products.imported += imported
        else:
            if not self._state.pull.process.products.get(f'imported_{self._product_pull_type}'):
                self._state.pull.process.products[f'imported_{self._product_pull_type}'] = 0
            self._state.pull.process.products[f'imported_{self._product_pull_type}'] += imported

    def mass_action(self, product_id, data, product, product_ext):
        mass_action = data['mass_action']
        if mass_action == 'delete':
            if product.variants:
                error = ""
                for variant in product.variants:
                    reverb_variant_listing = self.get_product_by_sku(variant.sku)
                    if reverb_variant_listing.result != Response().SUCCESS:
                        if reverb_variant_listing.result == Response().DELETED:
                            continue
                        else:
                            error = error + str(variant['sku']) + ": " + str(reverb_variant_listing.msg) + ". "
                            continue
                    variant_id = reverb_variant_listing.data['listings'][0]['id']
                    delete_listing = self.api(path="listings/" + str(variant_id), method="delete")
                    if delete_listing.result != Response().SUCCESS:
                        error = error + variant.sku + ": " + delete_listing.get('msg') + ". "
                        continue
                    self.product_deleted(variant['_id'], variant)
                if error:
                    return Response().error(msg = error)
                self.product_deleted(product['_id'], product)
            else:
                delete_listing = self.api(path="listings/" + str(product_id), method="delete")
                if delete_listing.result != Response().SUCCESS:
                    return Response().error(msg = delete_listing.get('msg'))
                self.product_deleted(product['_id'], product)
        elif mass_action == "end":
            if product.variants:
                error = ""
                for variant in product.variants:
                    reverb_variant_listing = self.get_product_by_sku(variant.sku)
                    if reverb_variant_listing.result != Response().SUCCESS:
                        if reverb_variant_listing.result == Response().DELETED:
                            continue
                        else:
                            error = error + str(variant['sku']) + ": " + str(reverb_variant_listing.msg) + ". "
                            continue
                    variant_id = reverb_variant_listing.data['listings'][0]['id']
                    update_data = {
                        "reason": "not_sold"
                    }
                    ended_listing = self.api("/my/listings/" + str(variant_id) + "/state/end", method='put', data=update_data)
                    if ended_listing.result != Response().SUCCESS:
                        error = error + variant.sku + ": " + ended_listing.get('msg') + ". "
                        continue
                    self.product_deleted(variant['_id'], variant)
                if error:
                    return Response().error(msg = error)
                self.product_deleted(product['_id'], product)
            else:
                update_data = {
                    "reason": "not_sold"
                }
                ended_listing = self.api("/my/listings/" + str(product_id) + "/state/end", method='put', data=update_data)
                if ended_listing.result != Response().SUCCESS:
                    return Response().error(msg = ended_listing.get('msg'))
                self.product_deleted(product['_id'], product)
        elif mass_action == "active":
            if product.variant:
                error = ''
                for variant in product.variants:
                    reverb_variant_listing = self.get_product_by_sku(variant.sku)
                    if reverb_variant_listing.result != Response().SUCCESS:
                        if reverb_variant_listing.result == Response().DELETED:
                            continue
                        else:
                            error = error + str(variant['sku']) + ": " + str(reverb_variant_listing.msg) + ". "
                            continue
                    variant_id = reverb_variant_listing.data['listings'][0]['id']
                    active_list = self.simple_active_listing(variant_id)
                    if active_list.result != Response().SUCCESS:
                        error = error + variant.sku + ": " + active_list.get('msg') + ". "
                        continue
                if error:
                    return Response().error(msg = error)
            else:
                active_list = self.simple_active_listing(product_id)
                if active_list.result != Response().SUCCESS:
                    return Response().error(msg = active_list.get('msg'))

            self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.reverb_status', 'active')

        return Response().success(product_id)

    def simple_active_listing(self, listing_id):
        update_data = {
            "publish": True
        }
        res = self.api("/listings/" + str(listing_id), method = 'put', data = update_data)
        return res

    def is_import_draft(self, product = None):
        return (self._request_data.get('publish_draft') and self._request_data.get('publish_draft') != 'live') or (product and not product.qty)
