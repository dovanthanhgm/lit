import copy

import pytz
import requests

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderAddress
from datasync.models.constructs.product import Product, ProductVariant, ProductVariantAttribute, ProductImage


# from datasync.models.collections.template import Template


class ModelChannelsWish(ModelChannel):
	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'brand']
	SHIPPING_CARRIER = ['Zinc', 'Zeleris', 'YRC', 'YodelInternational', 'YODEL', 'Yamato', 'XPO', 'XpertDelivery', 'XDP', 'wnDirect', 'WishPost', 'We World Express', 'VietnamPostEMS', 'USPS', 'UPSSurePost', 'UPSMailInnovations', 'UPSFreight', 'UPS', 'UkrPoshta', 'UDS', 'TurkishPost', 'TuffnellsParcelsExpress', 'TransMission', 'TrakPak', 'Total Express', 'TollPriority', 'TollIPEC', 'TNTUK', 'TNTPostItaly', 'TNTItaly', 'TNTFrance', 'TNTClickItaly', 'TNTAustralia', 'TNT', 'Tipsa', 'Test_WishPostUPS', 'Test_WishPostTNT', 'Test_WishPostFedEx', 'Test_WishPostDHL', 'Test_Delhivery', 'TaiwanPost', 'SwissPost', 'SwedenPosten', 'Starlinks Global', 'SprintPack', 'Spring', 'SoutheasternFreightLines', 'Slovenska Posta', 'SingaporeSpeedpost', 'SimplyPost', 'Shipter', 'ShipGate', 'SFExpress', 'Seur', 'SequoiaLog', 'Sendle', 'Sending', 'SekoLogistics US', 'SekoLogistics', 'Samyoung&CelloSquare', 'Saia', 'Sagawa', 'RussianPost', 'RoyalMail', 'RLCarriers', 'Rincos', 'Qxpress', 'Purolator', 'PTTPosta', 'PTSWorldwideExpress', 'ProCarrier', 'PostSerbia', 'PostNord', 'PostNLInternational3S', 'PostNLInternational', 'PostNL', 'PostenNorge/Bring', 'PosteItaliane', 'Post11', 'PortugalCTT', 'PocztaPolska', 'PitneyBowes', 'Pilot', 'ParcelForce', 'Parcel.One', 'PaquetExpress', 'Palletways', 'OnTrac', 'OneWorldExpress', 'Omniva', 'OmniParcel', 'Olistpax', 'NorskGlobal', 'Nexive', 'NewZealandPost', 'Newgistics', 'MyHermesUK', 'MRW', 'MexicoSendaExpress', 'MexicoRedpack', 'MalaysiaPostPosDaftar', 'MalaysiaPost', 'MailAmericas', 'MagyarPosta', 'Lotte Global Logistics', 'LoneStarOvernight', 'LithuaniaPost', 'LegionExpress', 'LatviaPost', 'LaserShip', 'LaPosteColissimo', 'LandmarkGlobal', 'KoreaPostDomestic', 'KoreaPost', 'JapanPost', 'JanioAsia', 'ItalySDA', 'IsraelPost', 'Intelipost', 'Intelcom', 'InPost', 'IndonesiaPost', 'IndiaPostInternational', 'IndiaPost', 'IML', 'HunterExpress', 'HongKongPost', 'HermesGermany', 'Hermes', 'GLSSpain', 'GLSNetherlands', 'GLSItaly', 'GLSCzech', 'GLS', 'GlobegisticsInc', 'FreteRapido', 'Freipost', 'FMX', 'FedExUK', 'FedExCrossBorder', 'FedExApex', 'FedEx', 'FastwayIreland', 'FastwayAustralia', 'Fastbox', 'ETOMARS', 'Estes', 'Estafeta', 'ePostGlobal', 'EPostG', 'Envialia', 'EMS (China)', 'EMPSExpress', 'ELTAHellenicPost', 'EFS', 'ECMS', 'DXDelivery', 'DPEXChina', 'DPDUK', 'DPDPoland', 'DPDIreland', 'DPDGermany', 'DPDFrance', 'DPD Romania', 'DPD', 'DirectLink', 'Direct Freight Express', 'Dicom', 'DHLSpainDomestic', 'DHLPoland', 'DHLParcelUK', 'DHLParcelNL', 'DHLNetherlands', 'DHLLTL', 'DHLGlobalMailAsia', 'DHLGermany', 'DHLFreightSweden', 'DHLeCommerce', 'DHLBenelux', 'DHL2MannHandling', 'DHL', 'DeutschePost', 'DBSchenkerSweden', 'DanmarkPost', 'CyprusPost', 'Cubyn', 'CroatianPost', 'CouriersPlease', 'CorreosExpress', 'CorreosDeMexico', 'CorreosDeEspana', 'CorreosCostaRica', 'CorreosChile', 'Colissimo', 'ColisPrive', 'CJGLS', 'ChronopostFrance', 'ChoirExpress', 'Ceva', 'CeskaPosta', 'Celeritas', 'Caribou', 'CanparCourier', 'CanadaPost', 'Cacesa', 'BRTBartolini', 'BrazilCorreios', 'BPostInternational', 'BPost', 'BlueCareExpress', 'Belpost', 'B2CEurope', 'AustrianPostRegistered', 'AustrianPost', 'AustraliaPost', 'AuPostChina', 'AsendiaUSA', 'AsendiaUK', 'AsendiaHK', 'AsendiaGermany', 'Aramex', 'APCPostalLogistics', 'AnPost', 'AmazonMCFUS', 'AmazonMCFUK', 'AmazonMCF', 'AlliedExpress', 'AirpakExpress', 'ADSOne', 'ABF']

	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = None
		self._created_at_min = None
		self._last_product_id = None
		self._finish_pull = False
		self._last_order_id = None


	def get_api_info(self):

		return {
			'access_token': "access_token",
			'merchant_id': 'merchant_id',
		}


	# api code
	def get_api_path(self, path, add_version = True):
		path = to_str(path).replace('admin/', '')
		prefix = 'admin'
		if add_version:
			prefix += '/api/' + self.get_version_api()
		path = prefix + '/' + path
		return path


	def get_version_api(self):
		if self._version_api:
			return self._version_api
		year = get_current_time("%Y")
		month = get_current_time("%m")
		quarter = (to_int(month) - 1) // 3 + 1
		version_api = (to_int(quarter) - 1) * 3 + 1
		if version_api < 10:
			version_api = "0" + to_str(version_api)
		else:
			version_api = to_str(version_api)

		self._version_api = to_str(year) + "-" + version_api
		return self._version_api


	def get_client_id(self, user_id = None):
		client_id = self._state.channel.config.api.client_id
		if not client_id:
			return get_config_ini('wish', 'client_id')
		return client_id


	def get_client_secret(self, user_id = None):
		client_id = self._state.channel.config.api.client_secret
		if not client_id:
			return get_config_ini('wish', 'client_secret')
		return client_id


	def get_access_token(self, user_id = None):
		return self._state.channel.config.api.access_token


	def get_refresh_token(self, user_id = None):
		return self._state.channel.config.api.refresh_token


	def get_merchant_id(self, user_id = None):
		return self._state.channel.config.api.merchant_id


	def get_info(self):
		info = {
			'access_token': self._state.channel.config.api.access_token,
			'merchant_id': self._state.channel.config.api.merchant_id,
		}
		return info


	def refresh_access_token(self):
		url = f"https://{self.get_wish_host()}/api/v3/oauth/refresh_token"
		data = {
			"grant_type": "refresh_token",
			"client_id": self.get_client_id(),
			"client_secret": self.get_client_secret(),
			"refresh_token": self.get_refresh_token()
		}
		refresh = requests.request('post', url, json = data)
		if refresh.status_code != 200:
			return False
		token = refresh.json()
		self._state.channel.config.api.access_token = token['access_token']
		self._state.channel.config.api.refresh_token = token['refresh_token']
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return token['access_token']


	def post_api(self, path, data = None):
		return self.api(path, data, 'post')


	def api(self, path = '', data = None, method = 'get', retry = 0):
		headers = {
			'authorization': f"Bearer {self.get_access_token()}"
		}
		url = f"https://{self.get_wish_host()}/api/v3/{path.strip('/')}"
		headers['Content-Type'] = 'application/json'

		response_data = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code
			response_data = response.json()
			if response_data:
				try:
					response_prodict = Prodict(**response_data)
				except Exception:
					response_prodict = response_data
				response_data = response_prodict
			# if response.status_code >= 300:
			error = {
				'method': method,
				'headers': headers,
				'data': data,
				'status_code': response.status_code,
				'response': response.text
			}
			if response.status_code >= 300 or self.is_log():
				self.log_request_error(url, **error)

			if response.status_code < 300:
				return response_data
			if response.headers.get('wish-rate-limit-remaining'):
				res_called_data = to_int(response.headers.get('wish-rate-limit-remaining'))
				if res_called_data < 5:
					time.sleep(1)
			else:
				time.sleep(1)

			if response.status_code == 400 and 'access token' in response_data.message and retry < 5:
				token = self.refresh_access_token()
				if not token:
					self.set_action_stop(True)
					return response_data
				return self.api(path, data, method, retry = 5)

			if response.status_code == 429 and retry < 5:
				retry += 1
				time.sleep(retry * 10)
				return self.api(path, data, method, retry)
		except Exception as e:
			error = {
				'method': method,
				'headers': headers,
				'data': data,
				'error': e
			}
			self.log_request_error(url, **error)
		return response_data


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# order = self.get_order_by_id('6527d8d32698e828665e2f71')
		# order_ext = self.get_orders_ext_export([order['data']])
		# convert = self.convert_order_export(order['data'], order_ext['data'])
		try:
			res = self.api("oauth/test")
			if self._last_status != 200:
				return Response().error(Errors.WISH_API_INVALID)
			self.get_currency_code()
		except:
			return Response().error(Errors.WISH_API_INVALID)

		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self.get_info()['merchant_id'])
		return Response().success()


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		imported = self._state.pull.process.products.imported
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			if self._state.pull.process.products.finished:
				self._state.pull.process.products.finished = False
				self._state.pull.process.products.total = 0
				self._state.pull.process.products.imported = 0
				self._state.pull.process.products.created_at_min = ''
				self._state.pull.process.products.new_entity = 0
				self._state.pull.process.products.imported_inactive = 0
				self._state.pull.process.products.imported_expired = 0
				self._state.pull.process.products.error = 0
				self._state.pull.process.products.id_src = 0
			payload = {
				'limit': 1,
				'sort_by': 'created_at.asc'
			}
			if self._state.pull.process.products.created_at_min:
				payload['created_at_min'] = self._state.pull.process.products.created_at_min
			products_api = self.api(path = "/products", data = payload)
			if self._last_status == 200 and products_api.data:
				self._state.pull.process.products.total = -1
		if self.is_order_process():
			start_time = self.get_order_start_time('iso')
			last_modifier = self._state.pull.process.orders.max_last_modified
			# if self._state.channel.config.start_time:
			# 	start_time = self._state.channel.config.start_time
			params = {'limit': '1'}
			if start_time:
				params['released_at_min'] = start_time
			if last_modifier:
				self.set_order_max_last_modifier(last_modifier)
				params['updated_at_min'] = last_modifier
			orders_api = self.api(path = f"orders", data = params)
			self._state.pull.process.orders.total = 0
			if self._last_status == 200 and orders_api:
				self._state.pull.process.orders.total = -1
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
		return Response().success()


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier:
			if not self._order_max_last_modified:
				self._order_max_last_modified = last_modifier
				return
			date_obj = isoformat_to_datetime(last_modifier)
			max_midified_obj = isoformat_to_datetime(self._order_max_last_modified)
			if date_obj.timestamp() > max_midified_obj.timestamp():
				last_modifier = max_midified_obj.astimezone(pytz.UTC)
				iso_format = last_modifier.isoformat()
				if iso_format.endswith("+00:00"):
					iso_format = iso_format.replace("+00:00", 'Z')
				self._order_max_last_modified = iso_format


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_products(self):
		access_token = self.get_info()['access_token']
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			all_collections = self.api(path = "/product/multi-get", data = {'access_token': access_token})
			for collection in all_collections:
				payload = {
					'access_token': access_token,
					'id': collection['Product']['id']
				}
				self.api(path = "/product/remove", method = 'post', data = payload)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	# TODO: Products
	def get_products_main_export(self):
		if self._finish_pull:
			return Response().finish()
		payload = {
			'limit': 200,
			'sort_by': 'created_at.asc'
		}
		if self._state.pull.process.products.created_at_min:
			payload['created_at_min'] = self._state.pull.process.products.created_at_min
		products_api = self.api(path = "/products", data = payload)
		if self._last_status != 200 or not products_api.data:
			return Response().finish()
		if to_len(products_api.data) < 200:
			self._finish_pull = True
		last_product_id = products_api.data[-1]['id']
		if self._last_product_id == last_product_id:
			return Response().finish()
		self._last_product_id = last_product_id
		self._created_at_min = products_api.data[-1]['created_at']
		return Response().success(data = products_api.data)


	def set_product_id_src(self, id_src):
		if self._created_at_min:
			self._state.pull.process.products.created_at_min = self._created_at_min
		self._state.pull.process.products.id_src = id_src


	def get_products_ext_export(self, products):
		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def _convert_product_export(self, product, products_ext: Prodict):
		if not product.get_product_by_id:
			product = self.get_product_by_id(product.id)['data']
		product_id = to_str(product.id)
		product_data = Product()
		tags = []
		if product.tags:
			product_data.tags = ', '.join(product.tags)
		product_data.id = product_id
		product_data.status = True if product.status == 'ENABLE' else False
		product_data.created_at = convert_format_time(time_data = product.created_at, old_format = '%Y-%m-%dT%H:%M:%S')
		product_data.updated_at = convert_format_time(time_data = product.updated_at, old_format = '%Y-%m-%dT%H:%M:%S')

		product_data.name = product.name
		product_data.seo_url = f"https://www.wish.com/product/{product_id}"
		product_data.description = product.description
		product_data.sku = product.parent_sku
		if product.main_image:
			product_data.thumb_image.url = product.main_image.url
		if product.extra_images:
			for image in product.extra_images:
				image_data = ProductImage()
				image_data.url = image.url
				product_data.images.append(image_data)
		variant_default = product.variations[0]
		product_data.price = variant_default.price.amount
		product_data.qty = 0
		for inventory in variant_default.inventories:
			product_data.qty += inventory.inventory
		if variant_default.logistics_details:
			for dimension in ['weight', 'width', 'height', 'length']:
				if variant_default.logistics_details.get(dimension):
					product_data[dimension] = variant_default.logistics_details[dimension]
		product_data.gtin = variant_default.gtin
		product_data.msrp = product.msrp.amount if product.msrp else 0
		product_data.condition = product.condition.lower() if product.condition in ['NEW', 'USED'] else Product.CONDITION_RECONDITIONED
		template_data = {
			"brand": {
				"tags": '',
				"brand_id": '',
				"condition": {
					"new": '',
					"used": '',
					"reconditioned": '',
					"value": product.condition
				}
			},
			'shipping': {
				'shipping': product.default_shipping_prices[0].default_shipping_price.amount,
				'warehouse_id': product.default_shipping_prices[0].warehouse_id,
				'max_quantity': to_int(product.max_quantity)
			}
		}
		channel_data = {
			'wish_status': product.status,
			'variant_default_id': variant_default['id']
		}
		default_shipping_prices = product.default_shipping_prices
		template_shipping = {
			"max_quantity": to_int(product.max_quantity),
			"warehouse_to_shippings": [],
		}
		for warehouse_to_shipping in product.warehouse_to_shippings:
			default_shipping_price = list(filter(lambda x: x.get('warehouse_id') == warehouse_to_shipping.warehouse_id, default_shipping_prices))

			warehouse_to_shippings_data = {
				"warehouse_id": warehouse_to_shipping.warehouse_id,
				"default_shipping_price": 0 if not default_shipping_price else default_shipping_price[0]['default_shipping_price']['amount'],
				"shipping_details": [

				]
			}
			if warehouse_to_shipping.get('shipping_details'):
				for shipping_detail in warehouse_to_shipping['shipping_details']:
					shipping_detail_data = dict(country = shipping_detail.destination,
					                            shipping_price = shipping_detail.price.amount,
					                            additional_shipping_price = shipping_detail.additional_price.amount if shipping_detail.additional_price else None,
					                            max_delivery_days = shipping_detail.max_delivery_days,
					                            status = "enable" if shipping_detail.is_enabled else 'disable',

					                            )
					if shipping_detail.get('overrides'):
						overrides = []
						for override in shipping_detail['overrides']:
							override_data = dict(
								region = override.destination,
								shipping_price = override.price.amount,
								additional_shipping_price = override.additional_price.amount if override.additional_price else None,
								max_delivery_days = override.max_delivery_days,
								status = "enable" if override.is_enabled else 'disable',

							)
							overrides.append(override_data)
						shipping_detail_data['overrides'] = overrides
					warehouse_to_shippings_data['shipping_details'].append(shipping_detail_data)
			template_shipping['warehouse_to_shippings'].append(warehouse_to_shippings_data)
		if variant_default.logistics_details and variant_default.logistics_details.get('origin_country'):
			template_shipping['origin_country'] = variant_default.logistics_details.get('origin_country')
		template_data['shipping'] = template_shipping
		product_data.template_data = template_data
		product_data.channel_data = channel_data
		if variant_default.options:

			for variant in product.variations:
				variant_data = ProductVariant()
				variant_data.seo_url = f"https://www.wish.com/product/{product_id}"
				variant_data.id = variant.id
				variant_data.sku = variant.sku
				variant_data.gtin = variant.gtin
				variant_data.price = variant.price.amount
				variant_data.qty = 0
				for inventory in variant.inventories:
					variant_data.qty += inventory.inventory
				for attribute in variant.options:
					variant_attribute = ProductVariantAttribute()
					variant_attribute.attribute_name = attribute.name
					variant_attribute.attribute_value_name = attribute.value
					variant_data.attributes.append(variant_attribute)
				product_data.variants.append(variant_data)

		return Response().success(product_data)


	def get_product_by_id(self, product_id):
		product = self.api(f'products/{product_id}')
		if not product or not product.get('data'):
			return Response().error()
		product_data = product.data
		if '_deleted_' in product_data.parent_sku:
			split_sku = product_data.parend_sku.split('_deleted_')
			if is_uuid(split_sku[-1]):
				return Response().create_response(result = Response.DELETED)
		product_data.get_product_by_id = True
		return Response().success(product_data)


	def get_currency_code(self):
		if self._state.channel.config.currency:
			return self._state.channel.config.currency
		currency_setting = self.api("merchant/currency_settings")
		if self._last_status != 200:
			self._state.channel.config.currency = 'USD'
		else:
			self._state.channel.config.currency = currency_setting.data.localized_currency
		return self._state.channel.config.currency


	def get_variation_skus_images(self, image, product: Product):
		variants = product.variants
		variant_skus = list()
		if not product.variants:
			variant_skus.append(product.sku)
		else:
			for variant in variants:
				if variant.thumb_image.url == image:
					variant_skus.append(variant.sku)
					continue
				for variant_image in variant.images:
					if variant_image.url == image:
						variant_skus.append(variant.sku)
		return list(set(variant_skus))


	def to_variant_inventory(self, qty, warehouse_id):
		if not self._state.channel.config.setting.qty or not self._state.channel.config.setting.qty.warehouse_settings:
			return [
				{
					"inventory": qty,
					"warehouse_id": warehouse_id
				}
			]
		inventories = []
		for inventory in self._state.channel.config.setting.qty.warehouse_settings:
			warehouse_config = to_decimal(inventory.inventory)
			warehouse_qty = round(qty * warehouse_config / 100)
			inventories.append({
					"inventory": warehouse_qty,
					"warehouse_id": inventory.warehouse_id
				})
		return inventories



	def to_wish_variant(self, variant: ProductVariant or Product, parent = None, warehouse_id = '', is_variant = False, variant_id = None, origin_country = ''):
		if not parent:
			parent = variant
		inventories = self.to_variant_inventory(variant.qty, warehouse_id)
		variant_data = {
			"inventories": inventories,
			"price": self.to_wish_price(variant.price),
			"sku": variant.sku,
			"logistics_details": {
				"height": variant.height or parent.height,
				"length": variant.length or parent.length,
				"weight": variant.weight or parent.weight,
				"width": variant.width or parent.width,
			},
			"quantity_value": sum([row['inventory'] for row in inventories])
		}
		if origin_country:
			variant_data["logistics_details"]["origin_country"] = origin_country
		if variant_id:
			variant_data['id'] = variant_id
		if variant.gtin:
			variant_data['gtin']: variant.gtin
		if is_variant:
			color = ''
			size = ''
			len_attribute = 0
			fail_attribute = []
			for attribute in variant.attributes:
				if not attribute.use_variant:
					continue
				len_attribute += 1
				if self.name_to_code(attribute.attribute_name.lower()) in ['color', 'colour', 'colore', 'couleur']:
					color = attribute.attribute_value_name
					continue
				if self.name_to_code(attribute.attribute_name.lower()) in ['size', 'taille', 'dimensione', 'dimension']:
					size = attribute.attribute_value_name
					continue
				fail_attribute.append(attribute.attribute_name)
			if fail_attribute:
				return Response().error(msg = Errors().get_msg_error(Errors.WISH_OPTION_VARIANT_TOO_MUCH).format(','.join(fail_attribute)))

			if len_attribute > 2:
				return Response().error(Errors.WISH_OPTION_VARIANT_TOO_MUCH)
			if not size and not color:
				return Response().error(Errors.WISH_OPTION_VARIANT)
			variant_data['options'] = list()
			if size:
				variant_data['options'].append({
					'name': 'SIZE',
					'value': size
				})
			if color:
				variant_data['options'].append({
					'name': 'COLOR',
					'value': color
				})
		return Response().success(variant_data)


	def to_wish_product(self, product):
		template_shipping = product.get('template_data', {}).get('shipping', {})
		template_brand = product.get('template_data', {}).get('brand', {})
		if not template_shipping:
			return Response().error(Errors.WISH_SHIPPING_TEMPLATE_REQUIRED, msg = 'Missing required template. Please add a template for the wish channel')
		template_brand_id = product.get('templates', {}).get('brand', {})
		default_shipping_price = []
		warehouse_to_shippings = []
		product_data = {
			"description": product.description,
			"name": product.name,
			"parent_sku": product.sku,
			# "max_quantity": to_int(template_shipping.max_quantity)
		}
		if to_int(template_shipping.max_quantity):
			product_data['max_quantity'] = to_int(template_shipping.max_quantity)
		warehouse_id = None
		if template_shipping.get('warehouse_to_shippings'):
			for warehouse_to_shipping in template_shipping['warehouse_to_shippings']:
				if not warehouse_id:
					warehouse_id = warehouse_to_shipping.warehouse_id
				default_shipping_price.append({
					"default_shipping_price": {
						"amount": warehouse_to_shipping.default_shipping_price,
						"currency_code": self.get_currency_code(),

					},
					"warehouse_id": warehouse_to_shipping.warehouse_id
				})
				warehouse_to_shipping_data = {
					'warehouse_id': warehouse_to_shipping.warehouse_id,
					'shipping_details': []
				}
				if warehouse_to_shipping.get('shipping_details'):
					for shipping_details in warehouse_to_shipping['shipping_details']:
						shipping_details_data = {
							'destination': shipping_details.country,
							'is_enabled': shipping_details.get('status') == 'enable',
							'max_delivery_days': to_int(shipping_details.max_delivery_days) or None,
							'price': self.to_wish_price(shipping_details.shipping_price),
							'additional_price': self.to_wish_price(shipping_details.additional_shipping_price),
						}
						if shipping_details.get('overrides'):
							overrides = []
							for override in shipping_details['overrides']:
								overrides.append({
									'destination': to_str(override.region).split('_')[-1],
									'is_enabled': override.get('status') == 'enable',
									'max_delivery_days': override.max_delivery_days,
									'price': self.to_wish_price(override.shipping_price),
									'additional_price': self.to_wish_price(override.additional_shipping_price),
								})
							shipping_details_data['overrides'] = overrides
						else:
							shipping_details_data_overrides = copy.deepcopy(shipping_details_data)
							shipping_details_data['overrides'] = [shipping_details_data_overrides]
						warehouse_to_shipping_data['shipping_details'].append(shipping_details_data)
				warehouse_to_shippings.append(warehouse_to_shipping_data)
		product_data['default_shipping_prices'] = default_shipping_price
		product_data['warehouse_to_shippings'] = warehouse_to_shippings
		use_main_tag = False
		if not template_brand_id or template_brand.get('use_tags_default'):
			use_main_tag = True
		if use_main_tag:
			tags = product.tags
		else:
			tags = template_brand['tags']

		if tags:
			product_data['tags'] = tags.split(',')[0:10]
		if template_brand:
			if template_brand.brand_id:
				product_data['brand_id'] = template_brand.brand_id
			if template_brand.condition.value:
				product_data['condition'] = template_brand.condition.value
		if product.thumb_image.url:
			product_data['main_image'] = {
				"is_clean_image": True,
				"url": product.thumb_image.url,
				"variation_skus": self.get_variation_skus_images(product.thumb_image.url, product)
			}
		if product.images:
			extra_images = list()
			for image in product.images:
				extra_images.append({
					"is_clean_image": False,
					"url": image.url,
					"variation_skus": self.get_variation_skus_images(image.url, product)
				})
			product_data['extra_images'] = extra_images
		if product.msrp:
			product_data['msrp'] = self.to_wish_price(product.msrp)
		return Response().success(product_data)


	def to_wish_price(self, price):
		return {
			"amount": price,
			"currency_code": self.get_currency_code()
		}


	def product_import(self, convert: Product, product, products_ext):
		wish_product_convert = self.to_wish_product(product)
		if wish_product_convert.result != Response.SUCCESS:
			return wish_product_convert
		product_data = wish_product_convert.data
		template_shipping = product.get('template_data', {}).get('shipping', {})
		template_brand = product.get('template_data', {}).get('brand', {})
		origin_country = template_shipping.get("origin_country")
		product_data['variations'] = list()
		if not product.variants:
			variant_default = self.to_wish_variant(product, warehouse_id = template_shipping.warehouse_to_shippings[0].warehouse_id, origin_country = origin_country)
			if variant_default.result != Response.SUCCESS:
				return variant_default
			product_data['variations'].append(variant_default.data)
		else:
			for variant in product.variants:
				variant_data = self.to_wish_variant(variant, product, template_shipping.warehouse_to_shippings[0].warehouse_id, True, origin_country = origin_country)
				if variant_data.result != Response.SUCCESS:
					return variant_data
				product_data['variations'].append(variant_data.data)
		res = self.api(path = "products", method = 'post', data = product_data)
		if self._last_status == 200:
			wish_product = res.data
			product_id = wish_product.id
			if product.variants:
				for index, variant in enumerate(product.variants):
					wish_variant = wish_product.variations[index]
					self.insert_map_product(variant, variant['_id'], wish_variant.id)
			else:
				self._extend_product_map = {
					'variant_default_id': wish_product.variations[0]['id'],
				}
			return Response().success(product_id)

		msg = to_str(res.message)
		if not msg:
			msg = Errors().get_msg_error(Errors.EXCEPTION)
		if 'too short for ' in msg and 'description' in msg:
			return Response().error(Errors.WISH_DESCRIPTION_REQUIRED)

		return Response().error(msg = msg)

	def put_calculated_shipping(self, product_id):
		"""merchants using this option need to be approved by Wish"""
		res = self.api(
			path = f'products/{product_id}/calculated_shipping',
			data = {'enable': True},
			method = 'put'
		)
		if self._last_status > 204:
			error_msg = res.get('message')
			return Response().error(msg = error_msg)

		return Response().success()

	def after_product_import(self, product_id, convert: Product, product, products_ext):
		shipping_template = product.template_data.get('shipping')
		if isinstance(shipping_template, dict):
			# by default, this option calculated is turn off
			is_calculated_shipping = shipping_template.get('calculated_shipping')
			if is_calculated_shipping:
				put_calculated: Response = self.put_calculated_shipping(product_id)
				if self._last_status > 300:
					product['channel'][f'channel_{self.get_channel_id()}']['warning_msg'] = put_calculated.msg

		return Response().success()


	def delete_product_import(self, product_id):
		self.api(path = f"products/{product_id}", method = 'delete')
		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		template_shipping = product.get('template_data', {}).get('shipping', {})
		convert_wish_product = self.to_wish_product(product)
		if convert_wish_product.result != Response.SUCCESS:
			return convert_wish_product
		product_data = convert_wish_product.data
		product_data['variations'] = list()
		create_variants = list()
		if not product.variants:
			variant_default = self.to_wish_variant(product, variant_id = product.variant_default_id, warehouse_id = template_shipping.warehouse_to_shippings[0].warehouse_id)
			if variant_default.result != Response.SUCCESS:
				return variant_default
			product_data['variations'].append(variant_default.data)
		else:
			for variant in product.variants:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				if not variant_id:
					create_variants.append(variant)
					continue
				variant_post_data = self.to_wish_variant(variant, product, variant_id = variant_id, is_variant = True, warehouse_id = template_shipping.warehouse_to_shippings[0].warehouse_id)
				if variant_post_data.result != Response.SUCCESS:
					return variant_post_data
				product_data['variations'].append(variant_post_data.data)

		update_product = self.api(f'products/{product_id}', product_data, method = 'put')
		if self._last_status != 200:
			msg = to_str(update_product.message)
			if not msg:
				msg = Errors().get_msg_error(Errors.EXCEPTION)
			if 'too short for ' in msg and 'description' in msg:
				return Response().error(Errors.WISH_DESCRIPTION_REQUIRED)

			return Response().error(msg = msg)
		if create_variants:
			for variant in create_variants:
				variant_post_data = self.to_wish_variant(variant, product, is_variant = True, warehouse_id = template_shipping.warehouse_id)
				if variant_post_data.result != Response.SUCCESS:
					return variant_post_data
				wish_variant = self.api(f'products/{product_id}/variations', variant_post_data.data, method = 'post')
				if self._last_status == 200:
					self.insert_map_product(variant, variant['_id'], wish_variant.data.id)
					continue
				msg = to_str(wish_variant.message)
				if not msg:
					msg = Errors().get_msg_error(Errors.EXCEPTION)
				if 'too short for ' in msg and 'description' in msg:
					return Response().error(Errors.WISH_DESCRIPTION_REQUIRED)
		return Response().success(product.id)


	def to_variant_simple_sync_inventory(self, variant_id, variant: Product or ProductVariant, warehouse_id):
		inventories = self.to_variant_inventory(variant.qty, warehouse_id)

		variant_data = {
			"id": variant_id,
			"inventories": inventories,
			"price": {
				"amount": variant.price,
				"currency_code": self.get_currency_code()
			},
			"quantity_value": sum([row['inventory'] for row in inventories])
		}
		if not self.is_setting_sync_qty():
			del variant_data['inventories']
			del variant_data['quantity_value']
		if not self.is_setting_sync_price():
			del variant_data['price']
		return variant_data


	def channel_sync_inventory(self, product_id, product, products_ext):
		if not self.is_setting_sync_price() and not self.is_setting_sync_qty():
			return Response().success(product)
		template_shipping = product.get('template_data', {}).get('shipping', {})
		warehouse_id = template_shipping.warehouse_to_shippings[0].warehouse_id
		update_data = {
			"variations": []
		}
		if not product.variants:
			variant_data = self.to_variant_simple_sync_inventory(product.variant_default_id, product, warehouse_id)
			update_data['variations'].append(variant_data)
		else:
			for variant in product.variants:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				if not variant_id:
					continue
				variant_data = self.to_variant_simple_sync_inventory(variant_id, variant, warehouse_id)
				update_data['variations'].append(variant_data)
		update_product = self.api(f'products/{product_id}', update_data, method = 'put')
		if self._last_status != 200:
			msg = to_str(update_product.message)
			if not msg:
				msg = Errors().get_msg_error(Errors.EXCEPTION)
			if 'too short for ' in msg and 'description' in msg:
				return Response().error(Errors.WISH_DESCRIPTION_REQUIRED)

			return Response().error(msg = msg)
		return Response().success(product)


	def get_options_from_variants(self, variants):
		options = {}
		position = 1
		for variant in variants:
			for attribute in variant.attributes:
				if attribute.attribute_name not in options.keys():
					options[attribute.attribute_name] = {
						'values': [attribute.attribute_value_name],
						'position': position
					}
					position += 1
				elif attribute.attribute_value_name not in options[attribute.attribute_name]:
					options[attribute.attribute_name]['values'].append(attribute.attribute_value_name)
		return options


	# TODO: Order
	def get_orders_main_export(self):
		if self._finish_pull:
			return Response().finish()
		start_time = self.get_order_start_time('iso')
		last_modifier = self._state.pull.process.orders.max_last_modified
		payload = {
			'limit': 200,
			'sort_by': 'updated_at.asc'
		}
		if start_time:
			payload['released_at_min'] = start_time
		if last_modifier:
			payload['updated_at_min'] = last_modifier
		order_api = self.api(path = "orders", data = payload)
		if self._last_status != 200 or not order_api or not order_api.data:
			return Response().finish()
		if to_len(order_api.data) < 200:
			self._finish_pull = True
		last_order_id = order_api.data[-1]['id']
		if self._last_order_id == last_order_id:
			return Response().finish()
		self._last_order_id = last_order_id
		self._created_at_min = order_api.data[-1]['updated_at']

		return Response().success(data = order_api.data)


	def set_order_id_src(self, id_src):
		if self._created_at_min:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified
		self._state.pull.process.orders.id_src = id_src


	# def get_orders_ext_export(self, orders):
	#     extend = dict()
	#     for order in orders:
	#         extend[order['Order']['order_id']] = dict()
	#         meta = False
	#         try:
	#             payload = {
	#                 "id": order['Order']['order_id'],
	#                 "access_token": self.get_info()['access_token']
	#             }
	#             meta = self.api(path="/order", data=payload)
	#             if len(meta) != 0:
	#                 extend[order['Order']['order_id']]['meta'] = meta
	#         except Exception as e:
	#             self.log(f"failed get order have order_id is {order['Order']['order_id']}")
	#     return Response().success(extend)

	def get_orders_ext_export(self, orders):
		return Response().success()


	def get_order_by_id(self, order_id):
		order = self.api(path = f"orders/{order_id}")
		if self._last_status == 200:
			return Response().success(order['data'])
		return Response().success()


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.updated_at)
		order_create = isoformat_to_datetime(order.released_at)
		start_time = isoformat_to_datetime(self.get_order_start_time('iso'))
		if order_create.timestamp() < start_time.timestamp():
			return Response().skip()
		order_data = Order()
		order_data.id = order.id
		order_data.order_number = order.id

		order_data.currency = order.order_payment.general_payment_details.payment_total.currency_code
		order_data.created_at = convert_format_time(time_data = order.released_at, old_format = "%Y-%m-%dT%H:%M:%S")
		address = OrderAddress()
		address.city = order.full_address.shipping_detail.city
		address.country.country_code = order.full_address.shipping_detail.country_code
		address.state.state_code = order.full_address.shipping_detail.state
		address.address_1 = order.full_address.shipping_detail.street_address1
		streets = []
		if order.full_address.shipping_detail.street_address2:
			streets.append(order.full_address.shipping_detail.street_address2)
		if order.full_address.shipping_detail.street_address3:
			streets.append(order.full_address.shipping_detail.street_address3)
		if streets:
			address.address_2 = '\n'.join(streets)
		# address.address_2 = order.full_address.shipping_detail.zipcode
		address.postcode = order.full_address.shipping_detail.zipcode
		address.telephone = order.full_address.shipping_detail.phone_number.number if order.full_address.shipping_detail.phone_number else ''
		name = order.full_address.shipping_detail.name.split(' ')
		address.last_name = name[-1]
		if len(name) > 1:
			del name[-1]
		address.first_name = ' '.join(name)

		order_data.shipping_address.update(address)
		order_data.billing_address.update(address)
		order_data.customer_address.update(address)
		order_data.customer.first_name = address.first_name
		order_data.customer.last_name = address.last_name
		order_data.customer.telephone = address.telephone
		order_data.customer.email = f"{address.first_name}{address.last_name}@wish.com"

		if order.vat_information and order.vat_information.vat_amount and order.vat_information.vat_amount.final_vat and order.vat_information.vat_amount.final_vat.amount:
			order_data.tax.amount = order.vat_information.vat_amount.final_vat.amount
		product_data = OrderProducts()
		product_data.product_id = order.product_information.id

		product_data.product_name = order.product_information.name
		product_data.product_sku = order.product_information.sku
		options = dict()
		if order.product_information.color:
			options['color'] = order.product_information.color
		if order.product_information.color:
			options['size'] = order.product_information.size
		if options:
			product_data.product_id = order.product_information.variation_id
			product_data.listing_id = order.product_information.id
			for option_name, option_value in options.items():
				option_data = OrderItemOption()
				option_data.option_name = option_name
				option_data.option_value_name = option_value
				product_data.options.append(option_data)
		product_data.price = to_decimal(order.order_payment.general_payment_details.discounted_price.amount)
		product_data.qty = to_decimal(order.order_payment.general_payment_details.product_quantity)
		product_data.subtotal = product_data.price * product_data.qty
		product_data.shipping_amount = to_decimal(order.order_payment.general_payment_details.product_shipping_price.amount)
		product_data.discount_amount = (to_decimal(order.order_payment.general_payment_details.original_product_price.amount) - to_decimal(order.order_payment.general_payment_details.discounted_price.amount)) * product_data.qty
		order_data.discount.amount = product_data.discount_amount
		order_data.products.append(product_data)
		order_data.subtotal = product_data.subtotal
		order_data.shipping.amount = to_decimal(order.order_payment.general_payment_details.product_shipping_price.amount)
		order_data.total = to_decimal(order_data.subtotal) + to_decimal(order_data.shipping.amount) + to_decimal(order_data.tax.amount) - order_data.discount.amount

		order_data.channel_data = {
			'order_status': order.state,
			'created_at': order_data.released_at,
			# 'shipped_date': convert_format_time(order.shipped_date) if order.shipped_date else ''
		}
		order_data.status = self.convert_order_status(order.state)
		return Response().success(order_data)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	def convert_order_status(self, status):
		order_status = {
			"APPROVED": Order.READY_TO_SHIP,
			"SHIPPED": Order.COMPLETED,
			"REFUNDED": Order.REFUNDED,
			"REQUIRE_REVIEW": Order.OPEN,
		}
		return order_status.get(status, 'open') if status else 'open'


	def get_shipping_carrier(self, tracking_company, tracking_company_code):
		enable_carrier_mapping = self._state.channel.config.setting.get('other_setting', {}).get('carrier_mapping', {}).get('status') == 'enable' if self._state.channel.config.setting.get('other_setting', {}) else 'disable'
		company_mapping = self._state.channel.config.setting.get('other_setting', {}).get('carrier_mapping', {}).get('company_mapping') if self._state.channel.config.setting.get('other_setting', {}) else []
		if enable_carrier_mapping and company_mapping:
			for carrier in company_mapping:
				if self.name_to_code(carrier["main_company"]) in [self.name_to_code(tracking_company), self.name_to_code(tracking_company_code)]:
					return carrier["channel_company"]

		for company in self.SHIPPING_CARRIER:
			if self.name_to_code(company) in [self.name_to_code(tracking_company), self.name_to_code(tracking_company_code)]:
				return company
		special_company = ['USPS', 'DHL', 'UPS']
		for name in special_company:
			code = self.name_to_code(name)
			if self.name_to_code(tracking_company).find(code) != -1 or self.name_to_code(tracking_company_code).find(code) != -1:
				return name
		return 'WishPost'

	def channel_order_completed(self, order_id, order: Order, current_order):
		channel_default = self.get_channel_default()
		user_info = self.get_user_info()
		try:
			tracking_company = self.get_shipping_carrier(order.shipments.tracking_company, order.shipments.tracking_company_code)
		except:
			self.log_traceback()
			tracking_company = 'WishPost'

		submit_tracking = {
			'origin_country': user_info.get('country') or 'US',
			'shipping_provider': tracking_company,
			'tracking_number': order.shipments.tracking_number or order.order_number,
			# 'ship_note': 'shipped by litcommerce',
		}
		self.api(f"orders/{order_id}/tracking", submit_tracking, method = 'put')
		if self._last_status != 200:
			return Response().error(Errors.EXCEPTION)
		return_order = {"status": Order.COMPLETED}
		return Response().success(return_order)


	def channel_order_canceled(self, order_id, order: Order, current_order):

		submit_order = {
			'refund_reason': 'INCOMPLETE_ORDER',
			# 'refund_reason_note': 'refund by litcommerce',
		}
		self.api(f"orders/{order_id}/refund", submit_order, method = 'put')
		if self._last_status != 200:
			return Response().error(Errors.EXCEPTION)
		return_order = {"status": Order.CANCELED}
		return Response().success(return_order)


	def get_wish_mode(self):
		wish_mode = self._state.channel.config.api.wish_mode
		if not wish_mode:
			return get_config_ini('wish', 'mode')
		return wish_mode


	def get_wish_host(self):
		return 'merchant.wish.com' if self.get_wish_mode() == 'production' else 'sandbox.merchant.wish.com'


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()


	def random_sku(self, length = 16):
		chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
		return "".join(random.choice(chars) for _ in six.moves.xrange(length))


	def dict2obj(self, d):
		if isinstance(d, list):
			d = [self.dict2obj(x) for x in d]
		if not isinstance(d, dict):
			return d


		class C(object):
			pass


		o = C()
		for k in d:
			o.__dict__[k] = self.dict2obj(d[k])
		return o


	def get_draft_extend_channel_data(self, product):
		description = product.description or product.short_description or product.title
		description = self.strip_html_from_description(description)
		extend = {}
		if product.description != description:
			extend['description'] = description
		return extend


	def channel_assign_brand_template(self, product, template_data):
		condition = template_data['condition']
		product_condition = product.get('condition') or 'new'
		if condition.get(product_condition):
			condition['value'] = condition.get(product_condition)
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['brand']['condition'] = condition

		return product
