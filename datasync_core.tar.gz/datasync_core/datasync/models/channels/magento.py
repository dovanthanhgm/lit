﻿import copy
import math

import chardet
import requests

from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory
from datasync.models.constructs.product import Product, ProductImage, ProductAttribute, ProductVariant, \
	ProductVariantAttribute, ProductOption, ProductOptionValue


class ModelChannelsMagento(ModelChannel):
	PRODUCT_PAGE = 0
	ORDER_PAGE = 0
	ATTRIBUTE_SET_ID = 0
	CONFIG_OPTION = {}
	_last_sku = None
	_last_product_update_at = 0


	def __init__(self):
		super().__init__()
		self._product_attributes = dict()
		self._attribute_group_id = None
		self._product_attributes_in_set = dict()
		self._token = ''
		self._order_max_last_modified = ''
		self._base_media_url = None
		self._pull_config_product = True
		self._product_config_max_last_modified = None
		self._all_categories = dict()


	def get_base_media_url(self, url):
		if self._base_media_url:
			return self._base_media_url
		url_image = to_str(self._channel_url).strip('/') + '/pub/media/catalog/product/' + to_str(url).strip('/')
		check = self.image_exist(url_image)
		if check:
			self._base_media_url = to_str(self._channel_url).strip('/') + '/pub/media/catalog/product/'
		else:
			self._base_media_url = to_str(self._channel_url).strip('/') + '/media/catalog/product/'
		return self._base_media_url


	def get_api_info(self):
		"""

		:rtype: dict
		"""
		return {
			# 'shop': "URL Shop",
			'password': "Password",
			'username': 'Username'
		}


	def get_api_path(self, path, version = 1):
		path = '/rest/V{}/'.format(version) + path.strip('/')
		return path


	def get_token(self):
		if self._token:
			return Response().success(self._token)
		data = {
			'username': self._state.channel.config.api.username,
			'password': self._state.channel.config.api.password
		}
		path_api = self.get_api_path('integration/admin/token', 1)
		url = to_str(self._channel_url).strip('/') + path_api
		header = {"Content-Type": "application/json"}
		header['User-Agent'] = get_random_useragent()
		response = self.requests(url, data, method = 'post', headers = header)
		if response and 'message' not in response:
			self._token = response
			return Response().success(response)
		else:
			if response and 'message' in response:
				return Response().error(msg = response['message'])
			return Response().error(msg = "Can not connect to magento url: " + self._channel_url)


	def requests(self, url, data = None, headers = None, method = 'get', log_file = ''):
		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code
			response_data = response.json()
			if response_data:
				try:
					response_prodict = Prodict.from_dict(response_data)
				except Exception:
					response_prodict = response_data
				response_data = response_prodict


			def log_request_error(file_name = 'request'):
				error = {
					'method': method,
					'status': response.status_code,
					'data': to_str(data),
					'header': to_str(response.headers),
					'response': response_data.to_json(),
					'error': response_data.errors
				}
				self.log_request_error(url, log_type = file_name, **error)
			if log_file:
				self.log_request_error(url, log_type = log_file, status = response.status_code, response = response.text, data = data)

			if response.status_code > 201:
				log_request_error()
		except Exception as e:
			self.log_traceback()
		return response_data


	def api(self, path, data = None, api_type = "get", version = 1, customer_token = '', search_criteria = {}, log_file = ''):
		path_api = self.get_api_path(path, version)
		if search_criteria:
			path_api += self.convert_search_criteria_to_params(search_criteria)
		header = {"Content-Type": "application/json"}
		header['User-Agent'] = get_random_useragent()
		if customer_token:
			header['Authorization'] = 'Bearer ' + customer_token
		else:
			token_result = self.get_token()
			if token_result.result != Response().SUCCESS:
				self.set_action_stop(True)
				return Response().error(msg = token_result.msg)
			token = to_str(token_result.data)
			header['Authorization'] = 'Bearer ' + token
		url = to_str(self._channel_url).strip('/') + path_api
		res = self.requests(url, data, method = api_type, headers = header, log_file = log_file)
		retry = 0
		while (res is False) or (self._last_status > 400 and self._last_status != 404):
			if self._last_status == 401:
				self._token = ''
				token = self.get_token()
				header['Authorization'] = 'Bearer ' + token['data']
			retry += 1
			time.sleep(1)
			res = self.requests(url, data, method = api_type, headers = header, log_file = log_file)
			if retry > 5 or 'The product that was requested doesn\'t exist. Verify the product and try again.' in to_str(
					res):
				break
		if res:
			if isinstance(res, dict):
				res = Prodict.from_dict(res)
			if isinstance(res, list):
				res = list(map(lambda x: Prodict.from_dict(x), res))
		return res


	def display_setup_channel(self, data = None):
		"""
		Check api information
		:param data:
		:return: _response

		"""
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# order = self.get_product_by_id(72)
		# order_ext = self.get_products_ext_export([order['data']])
		# convert = self._convert_product_export(order['data'], order_ext['data'])
		token = self.get_token()
		if token.result != Response().SUCCESS:
			return Response().error(msg = token.msg)
		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()


	def set_channel_identifier(self):
		"""
		in api info there will be 1 information that is unique to a channel.

		:return:
		"""
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self.channel_url_to_identifier(self._channel_url))
		return Response().success()


	def get_total_product_import(self):
		total = 0
		id_src = self._state.pull.process.products.id_src
		if not id_src:
			id_src = 0
		filters = list()
		if not self.is_import_inactive():
			filters.append({
				'filters': [
					{
						'conditionType': 'eq',
						'field': 'status',
						'value': 1,
					},
				]
			})
		filter_simple = copy.deepcopy(filters)
		filter_simple.append({
			'filters': [
				{
					'conditionType': 'neq',
					'field': 'type_id',
					'value': 'configurable',
				},
			]
		})
		filter_simple.append({
			'filters': [
				{
					'conditionType': 'gt',
					'field': 'entity_id',
					'value': id_src,
				}
			]
		})
		search_criteria = {
			'currentPage': 1,
			'pageSize': 1,
			'filterGroups': filter_simple
		}
		products_api = self.api('products', search_criteria = search_criteria)

		if products_api and products_api.total_count:
			total += products_api.total_count
		filter_config = copy.deepcopy(filters)
		id_src = self._state.pull.process.products.id_src_config
		if not id_src:
			id_src = 0
		filter_config.append({
			'filters': [
				{
					'conditionType': 'eq',
					'field': 'type_id',
					'value': 'configurable',
				},
			]
		})
		filter_config.append({
			'filters': [
				{
					'conditionType': 'gt',
					'field': 'entity_id',
					'value': id_src,
				}
			]
		})
		search_criteria = {
			'currentPage': 1,
			'pageSize': 1,
			'filterGroups': filter_config
		}
		products_api = self.api('products', search_criteria = search_criteria)
		if products_api and products_api.total_count:
			total += products_api.total_count
		return total


	def get_total_product_refresh(self):
		total = 0
		id_src = self._state.pull.process.products.id_src
		if not id_src:
			id_src = 0
		filter_simple = list()
		max_last_modified = self.get_max_last_modified_product()
		if max_last_modified:
			filter_simple.append({
				'filters': [
					{
						'conditionType': 'gt',
						'field': 'updated_at',
						'value': max_last_modified,
					}
				]
			})
		# filter_simple.append({
		# 	'filters': [
		# 		{
		# 			'conditionType': 'neq',
		# 			'field': 'type_id',
		# 			'value': 'configurable',
		# 		},
		# 	]
		# })
		search_criteria = {
			'currentPage': 1,
			'pageSize': 1,
			'filterGroups': filter_simple,
			'sortOrders': [
				{
					'direction': 'ASC',
					'field': 'updated_at'
				}
			]
		}
		products_api = self.api('products', search_criteria = search_criteria)

		if products_api and products_api.total_count:
			total += products_api.total_count
		# filter_config = list()
		# max_last_modified = self.get_max_last_modified_product(config_product = True)
		# if max_last_modified:
		# 	filter_config.append({
		# 		'filters': [
		# 			{
		# 				'conditionType': 'gt',
		# 				'field': 'updated_at',
		# 				'value': max_last_modified,
		# 			}
		# 		]
		# 	})
		# filter_config.append({
		# 	'filters': [
		# 		{
		# 			'conditionType': 'eq',
		# 			'field': 'type_id',
		# 			'value': 'configurable',
		# 		},
		# 	]
		# })
		# search_criteria = {
		# 	'currentPage': 1,
		# 	'pageSize': 1,
		# 	'filterGroups': filter_config,
		# 	'sortOrders': [
		# 		{
		# 			'direction': 'ASC',
		# 			'field': 'updated_at'
		# 		}
		# 	]
		# }
		# products_api = self.api('products', search_criteria = search_criteria)
		#
		# if products_api and products_api.total_count:
		# 	total += products_api.total_count
		return total


	def display_pull_channel(self):
		"""
		Count all entity in channel
		:return:
		"""
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			if self._state.pull.process.products.finished:
				self._state.pull.process.products.finished = False
				self._state.pull.process.products.imported = 0
				self._state.pull.process.products.imported_config = 0
				self._state.pull.process.products.imported_simple = 0
				self._state.pull.process.products.new_entity = 0
				self._state.pull.process.products.total = 0
				self._state.pull.process.products.error = 0
				if self.is_refresh_process():
					self._state.pull.process.products.id_src = 0
					self._state.pull.process.products.id_src_config = 0
			if self.is_refresh_process():
				self._state.pull.process.products.total = self.get_total_product_refresh()
			else:
				self._state.pull.process.products.total = self.get_total_product_import()
		if self.is_order_process():
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.total = 0
			start_time = self.get_order_start_time()
			search_criteria = {
				'currentPage': 1,
				'pageSize': 1,
				'filterGroups': [
					{
						'filters': self.get_order_filter()
					}
				]
			}
			orders_api = self.api('orders', search_criteria = search_criteria)

			if orders_api and orders_api.total_count:
				self._state.pull.process.orders.total = orders_api.total_count
		category_count = 0
		self._state.pull.process.categories.total = category_count
		return Response().success()


	def get_order_filter(self):
		start_time = self.get_order_start_time('%Y-%m-%d %H:%M:%S')
		last_modifier = self._state.pull.process.orders.max_last_modified
		filter_order = list()
		if not last_modifier:
			filter_order.append({
				'conditionType': 'gt',
				'field': 'created_at',
				'value': start_time,
			})
		else:
			start_obj = to_timestamp(start_time, "%Y-%m-%d %H:%M:%S")
			modified_obj = to_timestamp(last_modifier, "%Y-%m-%d %H:%M:%S")
			date_filter_obj = start_obj if start_obj > modified_obj else modified_obj
			date_filter = convert_format_time(date_filter_obj, new_format = "%Y-%m-%d %H:%M:%S")
			self.set_order_max_last_modifier(date_filter)
			if modified_obj > start_obj:
				filter_order.append({
					'conditionType': 'gt',
					'field': 'updated_at',
					'value': last_modifier,
				})
		return filter_order


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier:
			if not self._order_max_last_modified:
				self._order_max_last_modified = last_modifier
				return
			date_obj = to_timestamp(last_modifier, "%Y-%m-%d %H:%M:%S")
			max_modified_obj = to_timestamp(self._order_max_last_modified, "%Y-%m-%d %H:%M:%S")
			if date_obj > max_modified_obj:
				self._order_max_last_modified = last_modifier


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			search_criteria = {
				'currentPage': 1,
				'pageSize': 100
			}
			all_products = self.api('products', search_criteria = search_criteria)
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.items:
					return next_clear
				for product in all_products['items']:
					sku = product.sku
					res = self.api('products/{}'.format(sku), None, 'Delete')
				search_criteria = {
					'currentPage': 1,
					'pageSize': 100
				}
				all_products = self.api('products', search_criteria = search_criteria)
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		if self._pull_config_product:
			id_src = self._state.pull.process.products.id_src_config
		else:
			id_src = self._state.pull.process.products.id_src
		if not id_src:
			id_src = 0

		filters = [{
			'filters': [
				{
					'conditionType': 'gt',
					'field': 'entity_id',
					'value': id_src,
				}
			]
		}]
		if not self.is_import_inactive():
			filters.append({
				'filters': [
					{
						'conditionType': 'eq',
						'field': 'status',
						'value': 1,
					},
				]
			})
		if self._pull_config_product:
			filters.append({
				'filters': [
					{
						'conditionType': 'eq',
						'field': 'type_id',
						'value': 'configurable',
					},
				]
			})
		else:
			filters.append({
				'filters': [
					{
						'conditionType': 'neq',
						'field': 'type_id',
						'value': 'configurable',
					},
				]
			})
		search_criteria = {
			'pageSize': 25,
			'filterGroups': filters,
			'sortOrders': [
				{
					'direction': 'ASC',
					'field': 'entity_id'
				}
			]
		}
		products = self.api('products', search_criteria = search_criteria)
		if not products or not products.get('items'):
			if self._pull_config_product:
				self._pull_config_product = False
				return self.get_products_main_export()
			if self._last_status != 200:
				return Response().error(msg = "Can not get products")
			return Response().finish()
		return Response().success(data = products['items'])


	def get_product_by_updated_at(self):
		limit_data = 100
		max_last_modified = self.get_max_last_modified_product()
		imported = self._state.pull.process.products.imported
		if not imported:
			imported = 0
		current_page = round(imported / limit_data)
		filters = list()
		if max_last_modified:
			filters = [{
				'filters': [
					{
						'conditionType': 'gt',
						'field': 'updated_at',
						'value': max_last_modified,
					}
				]
			}]
		# if self._pull_config_product:
		# 	filters.append({
		# 		'filters': [
		# 			{
		# 				'conditionType': 'eq',
		# 				'field': 'type_id',
		# 				'value': 'configurable',
		# 			},
		# 		]
		# 	})
		# else:
		# 	filters.append({
		# 		'filters': [
		# 			{
		# 				'conditionType': 'neq',
		# 				'field': 'type_id',
		# 				'value': 'configurable',
		# 			},
		# 		]
		# 	})
		search_criteria = {
			'pageSize': limit_data,
			'currentPage': current_page,
			'filterGroups': filters,
			'sortOrders': [
				{
					'direction': 'ASC',
					'field': 'updated_at'
				}
			]
		}
		products = self.api('products', search_criteria = search_criteria)
		if not products or not products.get('items'):
			if self._pull_config_product:
				self._pull_config_product = False
				return self.get_products_main_export()
			if self._last_status != 200:
				return Response().error(msg = "Can not get products")
			return Response().finish()
		return Response().success(data = products['items'])


	def set_product_id_src(self, id_src):
		if self._pull_config_product:
			self._state.pull.process.products.id_src_config = id_src
		else:
			self._state.pull.process.products.id_src = id_src


	def set_imported_product(self, imported):
		super().set_imported_product(imported)
		if self._pull_config_product:
			if not self._state.pull.process.products.imported_config:
				self._state.pull.process.products.imported_config = 0
			self._state.pull.process.products.imported_config += imported
		else:
			if not self._state.pull.process.products.imported_simple:
				self._state.pull.process.products.imported_simple = 0
			self._state.pull.process.products.imported_simple += imported


	def get_products_ext_export(self, products):
		# extend = Prodict()
		# for product in products:
		# 	product_sku = to_str(product.sku)
		# 	data = self.api("products/{}".format(product_sku))
		# 	children = self.api("configurable-products/{}/children".format(product_sku))
		# 	extend.set_attribute(product_sku, Prodict())
		# 	extend[to_str(product_sku)].data = data
		# 	extend[to_str(product_sku)].children = children
		return Response().success()


	def finish_product_export(self):
		self._state.pull.process.products.finished = True
		if self.is_refresh_process() and self._product_max_last_modified:
			self._state.pull.process.products.last_modified = self._product_max_last_modified


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.entity_id


	def get_product_children(self, sku):
		children = self.api(f"configurable-products/{sku}/children")
		if not children:
			return []
		return children


	def get_product_by_sku(self, sku) -> Prodict:
		product = self.api(f"products/{to_str(sku)}")
		if not product:
			return Prodict()
		return product


	def get_onhold_quantity(self, product_id):
		search_criteria = {
			'currentPage': 1,
			'pageSize': 10,
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': "eq",
							'field': 'product_id',
							'value': product_id,
						}
					]
				},
				{
					'filters': [
						{
							'conditionType': "eq",
							'field': 'qty_shipped',
							'value': 0,
						},
					]
				},
				{
					'filters': [
						{
							'conditionType': "eq",
							'field': 'qty_canceled',
							'value': 0,
						},
					]
				},
				{
					'filters': [
						{
							'conditionType': "eq",
							'field': 'qty_refunded',
							'value': 0,
						},
					]
				},
			],
		}
		items = self.api("orders/items", search_criteria = search_criteria)
		qty_on_hold = 0
		if items and items.get('items'):
			for row in items['items']:
				qty_on_hold += to_int(row['qty_ordered'])
		return qty_on_hold


	def _convert_product_export(self, product, products_ext: Prodict):
		product_id = to_str(product.id)
		product_data = Product()
		product = self.get_product_by_sku(product.sku)
		if not product:
			return Response().error("Not get product")
		product_data.id = product_id
		product_data.sku = product.sku
		product_data.price = product.price
		product_data.weight = product.weight
		product_data.status = True if product.status == 1 else False
		if product.extension_attributes and product.extension_attributes.stock_item:
			product_data.manage_stock = True if product.extension_attributes.stock_item.manage_stock else False
			product_data.is_in_stock = True if to_int(product.extension_attributes.stock_item.qty) > 0 and product.extension_attributes.stock_item.is_in_stock else False
			product_data.qty = product.extension_attributes.stock_item.qty
			if product.type_id != 'configurable':
				salable_qty = self.api(f'inventory/get-product-salable-quantity/{product.sku}/{product.extension_attributes.stock_item.stock_id}')
				if to_str(salable_qty).isnumeric():
					product_data.qty = to_int(salable_qty)
		else:
			product_data.manage_stock = False
			product_data.is_in_stock = True

		product_data.created_at = convert_format_time(product.created_at, '%Y-%m-%d %H:%M:%S')
		product_data.updated_at = convert_format_time(product.updated_at, '%Y-%m-%d %H:%M:%S')
		product_data.name = product.name
		# Image
		if product.media_gallery_entries:
			for image in product.media_gallery_entries:
				url = f"{self.get_base_media_url(to_str(image.file).strip('/'))}/" + to_str(image.file).strip('/')
				if 'thumbnail' in image.types:
					product_data.thumb_image.url = url
					product_data.thumb_image.label = image.label
				else:
					product_image_data = ProductImage()
					product_image_data.url = url
					product_image_data.label = image.label
					product_image_data.position = image.position
					product_data.images.append(product_image_data)
		# Attribute
		attribute_set_id = product.attribute_set_id
		attribute_magento = self.api('products/attribute-sets/{}/attributes'.format(attribute_set_id))
		description = ''
		short_description = ''
		product_data.seo_url = f"{self.get_channel_url()}/catalog/product/view/id/{product.id}"
		is_variant = False
		variant_attributes = []
		if self.is_refresh_process():
			check_map = self.get_product_warehouse_map(product.id, return_product = True)
			if check_map and check_map.is_variant:
				is_variant = True
				variant_attributes1 = list(filter(lambda x: x.use_variant, check_map.attributes))
				variant_attributes = [row['attribute_name'] for row in variant_attributes1]
		category_ids = list()
		for attribute in product.custom_attributes:
			if attribute.attribute_code == 'category_ids':
				category_ids = attribute.value
				continue
			if attribute.attribute_code == 'description':
				description = attribute.value
			elif attribute.attribute_code == 'short_description':
				short_description = attribute.value
			elif attribute.attribute_code == 'meta_title':
				product_data.meta_title = attribute.value
			elif attribute.attribute_code == 'meta_keyword':
				product_data.meta_keyword = attribute.value
			elif attribute.attribute_code == 'meta_description':
				product_data.meta_description = attribute.value
			elif attribute.attribute_code == 'url_key':
				seo_url = f"{self.get_channel_url()}/{attribute.value.strip('/')}.html"
				if self.url_exist(seo_url):
					product_data.seo_url = seo_url
				else:
					seo_url = f"{self.get_channel_url()}/{attribute.value.strip('/')}"
					if self.url_exist(seo_url):
						product_data.seo_url = seo_url
			elif attribute.attribute_code == 'special_price':
				product_data.special_price.price = attribute.value
			elif attribute.attribute_code == 'special_from_date':
				product_data.special_price.start_date = attribute.value
			elif attribute.attribute_code == 'special_to_date':
				product_data.special_price.end_date = attribute.value
			else:
				attribute_in_magento = get_row_from_list_by_field(attribute_magento, 'attribute_code', attribute.attribute_code)
				if not attribute_in_magento or attribute_in_magento.backend_type == 'static':
					continue
				if attribute_in_magento.default_frontend_label in variant_attributes:

					attribute_data = ProductVariantAttribute()
				else:
					attribute_data = ProductAttribute()
				attribute_data.code = attribute.code
				if attribute_in_magento:
					if attribute_in_magento['backend_type'] == 'static' or not attribute_in_magento.get('default_frontend_label'):
						continue
					attribute_data.attribute_name = attribute_in_magento['default_frontend_label']
					value = get_row_value_from_list_by_field(attribute_in_magento['options'], 'value', attribute.value, 'label')
					attribute_data.attribute_value_name = value if value else attribute.value
					product_data.attributes.append(attribute_data)
		if self._state.channel.config.custom_description and short_description:
			description = short_description
			short_description = ''
		product_data.description = description
		product_data.short_description = short_description
		# category
		if category_ids:
			product_data.category_name_list = self.get_category_name_list(category_ids)

		# Option
		if product.options:
			# option_list = []
			for option in product.options:

				option_data = ProductOption()
				option_data.id = to_str(option.id)
				option_data.option_name = option.title
				option_data.option_type = option.type
				option_data.required = option.is_require
				# option_data.values = list()
				for value in option['values']:
					# values = []
					value_data = ProductOptionValue()
					value_data.id = value['option_type_id']
					value_data.option_value_name = value['title']
					value_data.option_value_price = value['price'] if value['price_type'] == 'fixed' else to_decimal(
						product['price']) * to_decimal(value['price'])
					option_data.option_values.append(value_data)

				# option_list.append(option_data)
				product_data.options.append(option_data)
		# Children
		childrens = self.get_product_children(product.sku)
		list_attr_children = []
		if childrens:
			options = product.extension_attributes.configurable_product_options
			for option in options:
				search_criteria = {
					'filterGroups': [
						{
							'filters': [
								{
									'conditionType': 'eq',
									'field': 'attribute_id',
									'value': option.attribute_id,
								},
							]
						}
					]
				}
				data_option = self.api("products/attributes", search_criteria = search_criteria)
				list_attr_children.append(data_option['items'][0])
		for children in childrens:
			variant_data = ProductVariant()
			variant_data.id = children.id
			variant_data.sku = children.sku
			variant_data.name = children.name
			variant_data.weight = children.weight
			variant_data.price = children.price
			variant_data.created_at = convert_format_time(children.created_at, '%Y-%m-%d %H:%M:%S')
			variant_data.updated_at = convert_format_time(children.updated_at, '%Y-%m-%d %H:%M:%S')
			children_data = self.api('products/' + to_str(children.sku))
			if 'message' not in children_data:
				for image in children_data.media_gallery_entries:
					url = f"{self.get_base_media_url(to_str(image.file).strip('/'))}/" + to_str(image.file).strip('/')

					if 'thumbnail' in image.types:
						variant_data.thumb_image.url = url
						variant_data.thumb_image.label = image.label
					else:
						product_image_data = ProductImage()
						product_image_data.url = url
						variant_data.label = image.label
						variant_data.position = image.position
						variant_data.images.append(product_image_data)
				if 'stock_item' in children_data.extension_attributes:
					variant_data.manage_stock = True if product.extension_attributes.stock_item.manage_stock else False
					variant_data.is_in_stock = True if to_int(
						product.extension_attributes.stock_item.qty) > 0 and product.extension_attributes.stock_item.is_in_stock else False
					variant_data.qty = children_data.extension_attributes.stock_item.qty
					salable_qty = self.api(f'inventory/get-product-salable-quantity/{children.sku}/{children_data.extension_attributes.stock_item.stock_id}')
					if to_str(salable_qty).isnumeric():
						variant_data.qty = to_int(salable_qty)

				else:
					variant_data.manage_stock = False
					variant_data.is_in_stock = True

				for attribute in product.custom_attributes:
					if attribute.attribute_code == 'special_price':
						variant_data.special_price.price = attribute.value
					elif attribute.attribute_code == 'special_from_date':
						variant_data.special_price.start_date = attribute.value
					elif attribute.attribute_code == 'special_to_date':
						variant_data.special_price.end_date = attribute.value
			for option_child in list_attr_children:
				variant_attribute = ProductVariantAttribute()
				variant_attribute.id = option_child['attribute_id']
				variant_attribute.attribute_type = 'select'
				variant_attribute.use_variant = True
				variant_attribute.attribute_name = option_child['default_frontend_label']
				attribute_value_id = get_row_value_from_list_by_field(children.custom_attributes, 'attribute_code', option_child['attribute_code'], 'value')
				variant_attribute.attribute_value_id = attribute_value_id
				variant_attribute.attribute_value_name = get_row_value_from_list_by_field(option_child['options'], 'value', to_str(attribute_value_id), 'label')
				variant_data.attributes.append(variant_attribute)
			product_data.variants.append(variant_data)
		return Response().success(product_data)


	def get_attribute_set_id(self):
		if self.ATTRIBUTE_SET_ID:
			return self.ATTRIBUTE_SET_ID
		search_criteria = {
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': 'eq',
							'field': 'entity_type_id',
							'value': 4,
						},
					]
				}
			]
		}
		attribute_sets = self.api('products/attribute-sets/sets/list', search_criteria = search_criteria)
		attribute_set_id = get_row_value_from_list_by_field(attribute_sets['items'], 'attribute_set_name',
		                                                    'Default', 'attribute_set_id')
		if not attribute_set_id:
			attribute_set_id = attribute_sets['items'][0]['attribute_set_id']
		self.ATTRIBUTE_SET_ID = attribute_set_id
		return self.ATTRIBUTE_SET_ID


	def get_product_attribute_in_attribute_set(self):
		if self._product_attributes_in_set:
			return self._product_attributes_in_set
		attribute_magento = self.api('products/attribute-sets/{}/attributes'.format(self.get_attribute_set_id()))
		for attribute in attribute_magento:
			self._product_attributes_in_set[attribute['attribute_code']] = attribute
		return self._product_attributes_in_set


	def get_product_attributes(self):
		if self._product_attributes:
			return self._product_attributes
		search_criteria = {
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': 'neq',
							'field': 'backend_type',
							'value': 'static',
						},
					]
				}
			]
		}
		attribute_magento = self.api('products/attributes', search_criteria = search_criteria)
		for attribute in attribute_magento['items']:
			self._product_attributes[attribute['attribute_code']] = attribute

		return self._product_attributes


	def product_import(self, convert: Product, product, products_ext, parent_data = None):
		if parent_data is None:
			parent_data = {}
		if not product.name:
			product.name = parent_data.get('name')
		attribute_set_id = self.get_attribute_set_id()
		product_attributes = self.get_product_attributes()
		# attribute_magento = self.api('products/attribute-sets/{}/attributes'.format(attribute_set_id))
		sku = product.sku if product.sku else product.id
		if not self.check_sku(sku):
			if product.is_variant:
				sku = f"{sku} - {product.id}"
				# sku = sku + to_str(product.id)
				if not self.check_sku(sku):
					return Response().error(msg = "Product sku: {} is already exists".format(sku))
			else:
				return Response().error(msg = "Product sku: {} is already exists".format(sku))
		attribute_data = []
		if product.special_price.price and product.special_price.price != product.price and product_attributes.get('special_price'):
			attribute_data.append({
				'attribute_code': 'special_price',
				'value': product.special_price.price
			})
			if product.special_price.price and product.special_price.price != product.price and product_attributes.get('special_price'):
				attribute_data.append({
					'attribute_code': 'special_price',
					'value': product.special_price.price
				})
				if product.special_price.start_date and product_attributes.get('special_from_date'):
					attribute_data.append({
						'attribute_code': 'special_from_date',
						'value': product.special_price.start_date
					})
				if product.special_price.end_date and product_attributes.get('special_to_date'):
					attribute_data.append({
						'attribute_code': 'special_to_date',
						'value': product.special_price.end_date
					})
		attribute_special = ['description', 'short_description', 'meta_title', 'meta_keyword', 'meta_description']
		for attribute in attribute_special:
			if product.get(attribute) and product_attributes.get(attribute):
				attribute_data.append({
					'attribute_code': attribute,
					'value': product.get(attribute)
				})
		seo_url = product.seo_url if product.seo_url else self.create_attribute_code(product.name)
		seo_url = self.get_slug(seo_url)
		attribute_data.append({
			'attribute_code': 'url_key',
			'value': seo_url
		})

		for attribute in product.attributes:
			if attribute.use_variant:
				attribute.attribute_type = 'select'
			attribute_code, attribute_id = self.get_attribute_code(attribute)
			if attribute_code:
				option_id = None
				if attribute.attribute_type != 'select':
					attribute_data.append({
						'attribute_code': attribute_code,
						'value': attribute.attribute_value_name
					})
				else:
					option_id = self.get_option_id_by_value(attribute_code, attribute.attribute_value_name)
					if option_id:
						attribute_data.append({
							'attribute_code': attribute_code,
							'value': option_id
						})
				if option_id and product.is_variant and attribute.use_variant:
					option_config = {
						'option': {
							'attribute_id': attribute_id,
							'label': attribute['attribute_name'],
							'position': 0,
							'is_use_default': False,
							'values': [{
								'value_index': option_id
							}]
						}
					}
					res = self.api('configurable-products/{}/options'.format(product.parent_sku), option_config, 'post')
		for attribute_code, attribute in product_attributes.items():
			if attribute.get('is_required') and attribute['frontend_input'] == 'select':
				if not get_row_from_list_by_field(attribute_data, 'attribute_code', attribute['attribute_code']):
					if attribute.get('options'):
						value = attribute['options'][-1]['value']
					else:
						value = ''
					attribute_data.append({
						'attribute_code': attribute.get('attribute_code'),
						'value': value
					})
		product_data = {
			'product': {
				'attribute_set_id': attribute_set_id,
				'created_at': product.created_at,
				'id': 0,
				'name': product.name if product.name else parent_data.get('name'),
				'price': product.price,
				'weight': to_decimal(product.weight),
				'sku': sku,
				'status': 1 if product.status else 2,
				'visibility': 1 if product.is_variant else 4,
				'type_id': 'configurable' if product.variants else 'simple',
				'extension_attributes': {
					'stock_item': {
						'qty': product.qty,
						'is_in_stock': product.is_in_stock
					}
				},
				'custom_attributes': attribute_data,
			}
		}

		product_import = self.api('products', product_data, 'post')
		if product_import.id:
			self._last_sku = product_import.sku
			return Response().success(product_import.id)
		return Response().error(msg = product_import.message)


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		# Image upload
		sku = self._last_sku
		if product.thumb_image.url or product.thumb_image.path:
			self.upload_image(sku, product.thumb_image.url, product.thumb_image.path, product.thumb_image.label,
			                  ['small_image', 'image', 'thumbnail'])
		for image in product.images:
			self.upload_image(sku, image.url, image.path, image.label)

		# Category
		if self.is_auto_import_category() and product.category_path:
			category_id = self.get_category_id_by_path_name(product.category_path)
			if category_id:
				product_category_data = {
					"productLink": {
						"sku": sku,
						"category_id": category_id
					}
				}
				self.api('categories/{}/products'.format(category_id), product_category_data, 'post')

		for option in product.options:
			option_values = []
			for value_opt in option.option_values:
				option_values.append({
					'price': value_opt.option_value_price,
					'price_type': 'fixed',
					'sort_order': 0,
					'title': value_opt.option_value_name
				})
			option_data = {
				'option': {
					'is_require': option.required,
					'product_sku': sku,
					'title': option.option_name,
					'type': 'multiple' if option.option_type == 'multiple' else 'select',
					'values': option_values
				}
			}
			response_option = self.api('products/options', option_data, 'post')
		for variant in product.get('variants', []):
			variant.parent_sku = sku
			variant_import = self.product_import(Product(), variant, None, parent_data = product)
			if variant_import.result == Response().SUCCESS:
				self.after_product_import(variant_import.data, Product(), variant, {})
				# child_data = self.get_product_by_id(variant_import.data)
				# if child_data.result == Response().SUCCESS:
				# child_data = child_data.data
				# child_sku = child_data.sku
				self.insert_map_product(variant, variant['_id'], variant_import['data'])
				children_data = {
					'childSku': self._last_sku
				}
				res_link = self.api('configurable-products/{}/child'.format(sku), children_data, 'post')
				self.log(res_link, 'res_link')
		return Response().success()


	def get_category_id_by_name(self, category_name, parent_id = 0):
		if not parent_id:
			search_criteria = {
				'filterGroups': [
					{
						'filters': [
							{
								'conditionType': 'eq',
								'field': 'name',
								'value': category_name,
							},
						]
					}
				]
			}
		else:
			parent_id = ','.join(parent_id)
			search_criteria = {
				'filterGroups': [
					{
						'filters': [
							{
								'conditionType': 'eq',
								'field': 'name',
								'value': category_name,
							},
						]
					},
					{
						'filters': [
							{
								'conditionType': 'in',
								'field': 'parent_id',
								'value': parent_id,
							},
						]
					}
				]
			}
		categories = self.api('categories/list', search_criteria = search_criteria)
		if 'message' in categories or not categories['items']:
			return []
		return categories['items']


	def get_category_id_by_id(self, category_id):
		categories = self.api('categories/{}'.format(category_id))
		if 'message' in categories or not categories['items']:
			return []
		return categories


	def get_category_id_by_path_name(self, path_name):
		list_name = path_name.split('>')
		parent_ids = []
		check_category_exit = True
		for cate_name in list_name:
			if check_category_exit:
				category_name = cate_name.strip()
				list_cate = self.get_category_id_by_name(category_name, parent_id = parent_ids)
				if not list_cate:
					check_category_exit = False
					category_id = self.create_category_by_name(category_name, parent_ids)
					if category_id:
						parent_ids = [category_id]
					else:
						return 0
				else:
					parent_ids = []
					for cate in list_cate:
						parent_ids.append(cate['id'])
			else:
				category_id = self.create_category_by_name(category_name, parent_ids)
				if category_id:
					parent_ids = [category_id]
				else:
					return 0
		return category_id


	def create_category_by_name(self, category_name, parent_ids):
		if not parent_ids:
			parent_id = 2
		else:
			parent_id = parent_ids[0] if to_int(parent_ids[0]) > 1 else 2
		category_data = {
			"category": {
				"parent_id": parent_id,
				"name": category_name,
				"is_active": True
			}
		}
		category = self.api('categories', category_data, 'post')
		if 'message' in category:
			return None
		return category['id']


	def delete_product_import(self, product_id):
		product_data = self.get_product_by_id(product_id)
		if product_data.result == Response().SUCCESS:
			product_data = product_data.data
			sku = product_data.sku
			res = self.api('products/{}'.format(sku), None, 'Delete')
		return Response().success()


	def get_product_id_by_sku(self, sku):
		if sku:
			product = self.api('products/' + to_str(sku))
			if 'id' in product:
				return product.id
		return 0


	def get_option_id_by_value(self, attribute_code, attribute_value):
		option_attr = self.api('products/attributes/{}/options'.format(attribute_code))
		for option in option_attr:
			if to_str(option['label']) == to_str(attribute_value):
				return option['value']
		option_data = {
			'option': {
				'value': attribute_value,
				'label': attribute_value
			}
		}
		option_import = self.api('products/attributes/{}/options'.format(attribute_code), option_data, 'post')
		if 'message' in option_import:
			return None
		id_option = to_str(option_import).replace('id_', '')
		if not to_int(id_option):
			option_attr = self.api('products/attributes/{}/options'.format(attribute_code))
			for option in option_attr:
				if to_str(option['label']) == to_str(attribute_value):
					return option['value']
		return id_option


	def check_sku(self, sku):
		check_product = self.api('products/' + to_str(sku))
		if 'message' in check_product:
			return True
		return None


	def get_slug(self, slug):
		search_criteria = {
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': 'eq',
							'field': 'url_key',
							'value': slug,
						},
					]
				}
			]
		}
		check_product = self.api('products', search_criteria = search_criteria)
		if 'message' in check_product or not check_product['items']:
			return slug
		index = 0
		while index < 5:
			index += 1
			slug += to_str(to_int(time.time()))
			search_criteria = {
				'filterGroups': [
					{
						'filters': [
							{
								'conditionType': 'eq',
								'field': 'url_key',
								'value': slug,
							},
						]
					}
				]
			}
			check_product = self.api('products', search_criteria = search_criteria)
			if 'message' in check_product or not check_product['items']:
				return slug
		return None


	def check_unique_attribute(self, magento_attribute, attribute):
		global check_select
		if attribute.attribute_type == 'select':
			check_select = True
		for attr in magento_attribute:
			try:
				if not attribute.attribute_code:
					attribute.attribute_code = self.create_attribute_code(attribute.attribute_name)
				if (attr['attribute_code'] == attribute['attribute_code'] or attr['attribute_code'] == attribute[
					'attribute_code'] + '_lit') and ((check_select and attr['frontend_input'] == 'select') or (
						not check_select and attr['frontend_input'] != 'select')):
					return attr
				elif attr.get('default_frontend_label') and attr['default_frontend_label'] == attribute[
					'attribute_name'] and ((check_select and attr['frontend_input'] == 'select') or (
						not check_select and attr['frontend_input'] != 'select')):
					return attr
			except Exception as e:
				return None
		return None


	def check_attribute_sync(self, src_attr, target_attr):
		if src_attr.get('attribute_type') == 'select':
			if target_attr.get('frontend_input') == 'select':
				return True
			return False
		return target_attr.get('frontend_input') == 'text'


	def get_attribute_code_from_attribute(self, attribute):
		attribute_code = ''
		if attribute.attribute_code:
			attribute_code = to_str(attribute.attribute_code)
		else:
			attribute_code = self.create_attribute_code(attribute.attribute_name)
		if attribute_code and (attribute_code[0] == '0' or to_int(attribute_code[0]) > 0):
			attribute_code = f'litc_{attribute_code}'
		return self.remove_special_char(attribute_code.lower()).replace('-', '_')


	def create_new_attribute(self, attribute_code, attribute):
		attribute_data = {
			'attribute': {
				'attribute_code': attribute_code,
				'backend_type': 'int' if attribute.attribute_type == 'select' else 'varchar',
				'entity_type_id': 4,
				'frontend_input': 'select' if attribute.attribute_type == 'select' else 'text',
				'frontend_labels': [
					{
						"label": attribute.attribute_name,
						"store_id": 0
					}
				],
				'is_required': False
			}
		}
		response_attribute = self.api('products/attributes', attribute_data, 'post')
		if "attribute_code" in response_attribute:
			self.add_attribute_to_attribute_set(response_attribute['attribute_code'])
			self._product_attributes[attribute_code] = response_attribute
			return response_attribute.attribute_code, response_attribute.attribute_id
		return None, None


	def get_attribute_group_id(self):
		if self._attribute_group_id:
			return self._attribute_group_id
		search_criteria = {
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': 'eq',
							'field': 'attribute_set_id',
							'value': self.get_attribute_set_id(),
						},
					]
				}
			]
		}
		group_list = self.api('products/attribute-sets/groups/list', search_criteria = search_criteria)
		self._attribute_group_id = get_row_value_from_list_by_field(group_list['items'], 'attribute_group_name', 'Product Details', 'attribute_group_id')
		if not self._attribute_group_id:
			self._attribute_group_id = group_list['items'][0]['attribute_group_id']
		return self._attribute_group_id


	def add_attribute_to_attribute_set(self, attribute_code):
		data_connect_attr = {
			'attributeCode': attribute_code,
			'attributeGroupId': self.get_attribute_group_id(),
			'attributeSetId': self.get_attribute_set_id(),
			'sortOrder': 0
		}
		a = self.api('products/attribute-sets/attributes', data_connect_attr, 'post')
		self._product_attributes_in_set[attribute_code] = {}
		return Response().success()


	def get_attribute_code(self, attribute):
		attribute_code = self.get_attribute_code_from_attribute(attribute)
		attribute_code_clone = attribute_code
		index = 2
		while self.get_product_attributes().get(attribute_code):
			magento_attribute = self.get_product_attributes().get(attribute_code)
			check_sync = self.check_attribute_sync(attribute, magento_attribute)
			if check_sync:
				if attribute_code not in self.get_product_attribute_in_attribute_set():
					self.add_attribute_to_attribute_set(attribute_code)
				return magento_attribute['attribute_code'], magento_attribute['attribute_id']
			attribute_code = f"{attribute_code_clone}_{index}nd"
			index += 1
		return self.create_new_attribute(attribute_code, attribute)


	def get_new_attribute_code(self, attribute_code):
		res = self.api('products/attributes/' + to_str(attribute_code))
		if 'message' in res:
			return attribute_code
		else:
			res = self.api('products/attributes/' + to_str(attribute_code) + '_lit')
			if 'message' in res:
				return attribute_code + '_lit'
		return None


	def upload_image(self, product_sku, url, path, alt = 'image', list_type = ['images']):
		main_image = self.process_image_before_import(url, path)
		image_url = main_image['url']
		file_name = os.path.basename(image_url)
		file_name = file_name.split('?')[0]
		file_name = file_name.replace('+', '_')
		if '.' in file_name:
			type = file_name[file_name.rfind('.') + 1:]
		else:
			type = ''

		response = requests.get(image_url, headers = {'User-Agent': get_random_useragent()})
		content_type = response.headers['content-type']
		if not content_type:
			content_type = 'image/' + type.replace('jpg', 'jpeg')
		if response.status_code not in [200, 201]:
			return Response().error()
		img_data = response.content
		img_data = base64.b64encode(img_data).decode()
		data = {
			"entry": {
				"media_type": "image",
				"label": alt if alt else 'image',
				"types": list_type,
				"file": file_name,
				"disabled": False,
				"content": {
					"base64_encoded_data": img_data,
					"type": content_type,
					"name": file_name
				}
			}
		}
		response = self.api('products/{}/media'.format(product_sku), data, 'post')
		return Response().success()


	def get_process_type(self):
		return super().get_process_type()


	def get_option_data(self, item):
		options = []

		list_attr_children = []
		children_data = self.get_product_by_id(item.product_id)
		if children_data.result == Response().SUCCESS:
			children_data = children_data.data
			parent_data = self.get_product_by_id(item.parent_id)
			if parent_data.result == Response().SUCCESS:
				parent_data = parent_data.data
				options_conf = parent_data.extension_attributes.configurable_product_options
				for option_conf in options_conf:
					search_criteria = {
						'filterGroups': [
							{
								'filters': [
									{
										'conditionType': 'eq',
										'field': 'attribute_id',
										'value': option_conf.attribute_id,
									},
								]
							}
						]
					}
					data_option = self.api("products/attributes", search_criteria = search_criteria)
					list_attr_children.append(data_option['items'][0])
				for option_child in list_attr_children:
					attribute_value_id = get_row_value_from_list_by_field(children_data.custom_attributes, 'attribute_code', option_child['attribute_code'], 'value')
					if attribute_value_id:
						options.append({
							'option_id': option_child['attribute_id'],
							'option_value': attribute_value_id
						})
				product_option = {
					'extension_attributes': {
						'configurable_item_options': options
					}
				}
				return product_option
		return None


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if setting_order:
			cancel_order = self.api(f'{channel_order_id}/cancel.json', api_type = 'post')
			if self._last_status == 200:
				update_data = {
					f"channel.channel_{self.get_channel_id()}.order_status": Order.CANCELED,
					f"channel.channel_{self.get_channel_id()}.cancelled_at": cancel_order.cancelled_at
				}
				self.get_model_order().update(order_id, update_data)
			return Response().success()
		return self._order_sync_inventory(order, '+')


	def order_sync_inventory(self, convert: Order, setting_order):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			product_id = None
			variant_id = None
			if row['product_id'] and row['parent_id']:
				variant_id = row['product_id']
				product_id = row['parent_id']
			else:
				product_id = row['product_id']
			product_magento_data = self.get_product_by_id(row['product_id'])
			if product_magento_data.result != Response().SUCCESS:
				return Response().success()
			product_magento_data = product_magento_data.data
			product_sku = product_magento_data.sku
			row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1

			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				product = self.api("products/{}".format(product_sku))
				if product.extension_attributes and product.extension_attributes.stock_item:
					inventory_quantity = product.extension_attributes.stock_item.qty
					new_qty = to_int(inventory_quantity) - to_int(row_qty) if prefix == '-' else to_int(inventory_quantity) + to_int(row_qty)
					if new_qty < 0:
						new_qty = 0
					update_data = dict()
					update_data['extension_attributes'] = {
						'stock_item': {
							'qty': new_qty,
							"is_in_stock": new_qty > 0
						}
					}
					self.api(f'products/{product_sku}', {'product': update_data}, 'put')

		return Response().success()


	def custom_order_status(self, order_status, order: Order):
		if not self._state.channel.config.api.custom_order_status:
			return order_status
		custom_order_status = self._state.channel.config.api.custom_order_status.get(order_status, order_status)
		if custom_order_status == '_channel_type_':
			return order.channel_type or order_status
		return custom_order_status


	def order_import(self, convert: Order, order, orders_ext):
		customer = order.customer
		map_status = {
			Order.OPEN: "pending",
			Order.AWAITING_PAYMENT: "pending",
			Order.READY_TO_SHIP: "processing",
			Order.SHIPPING: "processing",
			Order.COMPLETED: "complete",
			Order.CANCELED: "canceled",
		}
		status = map_status.get(order.status, 'pending')
		status = self.custom_order_status(status, convert)

		items = []
		for item in order.products:
			product_id = 0
			product_type = 'simple'
			option_data = None
			if item.parent_id and item.parent_id != item.product_id:
				product_id = item.parent_id
				product_type = 'configurable'
				option_data = self.get_option_data(item)
			elif item.product_id:
				product_id = item.product_id
				product_type = 'simple'
			item_data = {
				'name': item.product_name,
				'sku': item.product_sku if item.product_sku else '',
				'qty_ordered': item.qty,
				'price': item.price,
				'base_price': item.price,
				'tax_amount': item.tax_amount,
				'row_total': item.price,
				'original_price': item.price,
				# 'tax_percent': to_decimal(item.tax_amount) / to_decimal(item.price),
				'price_incl_tax': to_decimal(item.price) + to_decimal(item.tax_amount),
				'base_price_incl_tax': to_decimal(item.price) + to_decimal(item.tax_amount),
				'product_id': product_id,
				'product_type': product_type
			}
			if option_data:
				item_data['product_option'] = option_data
			items.append(item_data)

		billing_data = order.billing_address
		billing_street = []
		if billing_data.address_1:
			billing_street.append(billing_data.address_1)
		if billing_data.address_2:
			billing_street.append(billing_data.address_2)
		billing_address = {
			"address_type": "billing",
			"city": billing_data.city,
			"country_id": billing_data.country['country_code'] if billing_data.country['country_code'] else "US",
			"firstname": billing_data.first_name if billing_data.first_name else customer.first_name,
			"lastname": billing_data.last_name if billing_data.last_name else customer.last_name,
			"postcode": billing_data.postcode if billing_data.postcode else 12196,
			"telephone": billing_data.telephone if billing_data.telephone else "0122222222",
			"street": billing_street
		}
		shipping_data = order.shipping_address
		shipping_street = []
		if shipping_data.address_1:
			shipping_street.append(shipping_data.address_1)
		if shipping_data.address_2:
			shipping_street.append(shipping_data.address_2)
		shipping_address = {
			"address": {
				"address_type": "shipping",
				"city": shipping_data.city,
				"country_id": shipping_data.country['country_code'] if shipping_data.country['country_code'] else "US",
				"firstname": shipping_data.first_name if shipping_data.first_name else customer.first_name,
				"lastname": shipping_data.last_name if shipping_data.last_name else customer.last_name,
				"postcode": shipping_data.postcode if shipping_data.postcode else 12196,
				"telephone": shipping_data.telephone if shipping_data.telephone else "0122222222",
				"street": shipping_street
			}
		}

		order_data = {
			"entity": {
				"base_tax_amount": order.tax['amount'],
				"tax_amount": order.tax['amount'],
				"base_subtotal": order.subtotal,
				"subtotal": order.subtotal,
				"base_grand_total": order.total,
				"base_shipping_amount": order.shipping['amount'],
				"shipping_amount": order.shipping['amount'],
				"customer_email": customer.email,
				# "customer_id": self.get_customer_id(order),
				'customer_firstname': customer.first_name,
				'customer_lastname': customer.last_name,
				"grand_total": order.total,
				"base_total_paid": order.total if status == 'complete' else 0,
				"total_paid": order.total if status == 'complete' else 0,
				"status": status,
				"state": status,
				"store_name": "Main Website Store",
				"items": items,
				"payment": {
					"account_status": "active",
					"additional_information": [],
					# "cc_last4": 1201,
					"method": "checkmo"
				},
				"billing_address": billing_address,
				"extension_attributes": {
					"shipping_assignments": [
						{
							"shipping": shipping_address
						}]
				}

			}
		}
		order_number = f"{to_str(order.order_number_prefix)}{to_str(order.channel_order_number)}"

		if order.keep_order_number:
			order_data['entity']['increment_id'] = order_number
		if self._state.channel.config.api.keep_order_number:
			order_data['entity']['increment_id'] = order.order_number

		if order.stores and order.stores.get('store_id'):
			order_data['entity']['store_id'] = order.stores['store_id']
			order_data['entity']['store_name'] = order.stores.get('store_name') or 'Main Website Store'
		order_import = self.api('orders/create', order_data, 'put')

		if self._last_status < 300:
			order_return = {
				'order_id': order_import.entity_id,
				'order_status': order_import.status,
				'order_number': order_import.increment_id,
				'created_at': order_import.created_at,
			}
			return Response().success([order_import.entity_id, order_return])
		return Response().error(msg = order_import.message)


	def channel_order_canceled(self, order_id, order: Order, current_order):
		order_canceled = self.api(f"orders/{order_id}/cancel", api_type = 'post')
		if order_canceled:
			return Response().success({'status': Order.CANCELED})
		return Response().error()


	def _channel_order_shipping(self, order_id, order: Order, current_order):
		magento_order = self.get_order_by_id(order_id)
		if magento_order.result != Response.SUCCESS:
			return Response().success()
		channel_default = self.get_channel_default()
		magento_order = magento_order.data
		order_data = {
			'appendComment': True,
			'notify': False,
			'items': [],
			'tracks': [
				{
					'carrier_code': channel_default.get('type'),
					'title': to_str(channel_default.get('type')).capitalize(),
					'track_number': channel_default.get('type'),
				}
			]
		}
		for item in magento_order['items']:
			if item.get('parent_item_id'):
				continue
			order_data['items'].append({
				'order_item_id': item['item_id'],
				'qty': item['qty_ordered']
			})
		order_shipping = self.api(f"order/{order_id}/ship", order_data, api_type = 'post')
		if order_shipping:
			return Response().success()
		return Response().error()


	def channel_order_completed(self, order_id, order: Order, current_order):
		magento_order = self.get_order_by_id(order_id)
		if magento_order.result != Response.SUCCESS:
			return Response().success()
		magento_order = magento_order.data
		products = dict()
		for item in current_order.products:
			products[to_str(item['product_id'])] = item
		order_data = {
			'appendComment': True,
			'notify': False,
			'items': [],
		}
		for item in magento_order['items']:
			if item.get('parent_item_id'):
				continue
			order_data['items'].append({
				'order_item_id': item['item_id'],
				'qty': item['qty_ordered']
			})
		order_completed = self.api(f"order/{order_id}/invoice", order_data, api_type = 'post')
		channel_default = self.get_channel_default()
		try:
			order_data['tracks'] = [
				{
					'carrier_code': order.shipments.tracking_company_code or channel_default.get('type') or 'custom',
					'title': order.shipments.tracking_company or to_str(channel_default.get('type')).capitalize() or 'custom',
					'track_number': order.shipments.tracking_number or channel_default.get('type') or 'unknown',
				}
			]
			update_qty = {}
			for item in magento_order['items']:
				if item.get('product_type') == 'configurable':
					continue
				product_id = item['product_id']
				product_magento_data = self.get_product_by_id(product_id)
				if product_magento_data.result != Response().SUCCESS:
					return Response().success()
				product_magento_data = product_magento_data.data
				product_sku = product_magento_data.sku
				magento_product = self.get_product_by_sku(product_sku)
				if magento_product:
					magento_qty = magento_product.extension_attributes.stock_item.qty
					inventory_quantity = to_int(magento_qty)
					current_update = {
						"qty": inventory_quantity,
						"is_in_stock": magento_product.extension_attributes.stock_item.is_in_stock
					}
					update_qty[product_sku] = current_update
					update_data = dict()
					update_data['extension_attributes'] = {
						'stock_item': {
							'qty': inventory_quantity + to_int(item['qty_ordered']),
							"is_in_stock": True,
						}
					}
					product = self.api("products/{}".format(product_sku), {"product": update_data}, 'put', log_file = 'order_completed')

			order_shipping = self.api(f"order/{order_id}/ship", order_data, api_type = 'post')
			for sku, update_data_item in update_qty.items():
				update_data = dict()
				update_data['extension_attributes'] = {
					'stock_item': update_data_item
				}
				product = self.api("products/{}".format(sku), {"product": update_data}, 'put', log_file = 'order_completed')
			if order_shipping and self._last_status < 300:
				return Response().success({'status': 'completed'})

		except:
			self.log_traceback('magento')
		return Response().error()


	def get_customer_id(self, order):
		customer = order.customer
		search_criteria = {
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': 'eq',
							'field': 'email',
							'value': customer.email,
						}
					]
				}
			]
		}
		customer_data = self.api('customers/search', search_criteria = search_criteria)
		if customer_data.get('items'):
			return customer_data['items'][0]['id']
		else:
			addresses = []
			billing_address = order.billing_address
			if billing_address:
				street = [billing_address.address_1] if billing_address.address_1 else ['Street']
				if billing_address.address_2:
					street.append(billing_address.address_2)
				addresses.append({
					'defaultShipping': False,
					'defaultBilling': True,
					'firstname': customer.first_name if customer.first_name else '',
					'lastname': customer.last_name if customer.last_name else '',
					'region': {
						'regionCode': billing_address.state.state_code,
						'region': billing_address.state.state_name
					},
					'postcode': billing_address.postcode if billing_address.postcode else 12345,
					'street': street,
					'city': billing_address.city if billing_address.city else 'City',
					'telephone': billing_address.telephone if billing_address.telephone else '0972612621',
					'countryId': billing_address.country.country_code if billing_address.country.country_code else 'US'
				})
			shipping_address = order.shipping_address
			if shipping_address:
				street = [shipping_address.address_1] if shipping_address.address_1 else ['Street']
				if shipping_address.address_2:
					street.append(shipping_address.address_2)
				addresses.append({
					'defaultShipping': True,
					'defaultBilling': False,
					'firstname': customer.first_name,
					'lastname': customer.last_name,
					'region': {
						'regionCode': shipping_address.state.state_code,
						'region': shipping_address.state.state_name
					},
					'postcode': shipping_address.postcode if shipping_address.postcode else 12345,
					'street': street,
					'city': shipping_address.city if shipping_address.city else "City",
					'telephone': shipping_address.telephone if shipping_address.telephone else '0972612621',
					'countryId': shipping_address.country.country_code if shipping_address.country.country_code else 'US'
				})
			customer_import = {
				'customer': {
					'addresses': addresses,
					'created_at': order.created_at,
					'firstname': customer.first_name,
					'lastname': customer.last_name,
					'email': customer.email
				},
				'password': 'LitExtension1234'
			}
			response = self.api('customers', customer_import, 'post')
			if 'id' in response:
				return response.id
		return 0


	def get_product_by_id(self, product_id):
		search_criteria = {
			'filterGroups': [
				{
					'filters': [
						{
							'conditionType': 'eq',
							'field': 'entity_id',
							'value': product_id
						}
					]
				}
			]
		}
		product = self.api('products', search_criteria = search_criteria)
		if 'message' in product:
			return Response().error(msg = product.message)
		if not product['items']:
			return Response().error("Product {} not found".format(product_id))
		return Response().success(data = product['items'][0])


	def product_channel_update(self, product_id, product: Product, products_ext):
		channel_id = self._state.channel.id
		# product_channel = product.get(f'channel_{channel_id}', {})
		variants_channel = {variant.id: variant.get(f'channel_{channel_id}', {}) for variant in product.variants}
		# Get product shopify data
		product_magento_data = self.get_product_by_id(product_id)
		if product_magento_data.result != Response().SUCCESS:
			return Response().error(msg = "Can not find product id: " + to_str(product_id))
		product_magento_data = product_magento_data.data
		old_sku = product_magento_data.sku
		update_data = {
			'product': {
				'sku': product.sku,
				'price': product.price,
				'weight': to_decimal(product.weight)
			}
		}
		# Update title & description
		title = product.name
		update_data['product']['name'] = title[0:255]
		custom_attributes = []
		attribute_set_id = product_magento_data.attribute_set_id
		attribute_magento = self.api('products/attribute-sets/{}/attributes'.format(attribute_set_id))
		description = product.description
		if description and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'description'):
			custom_attributes.append({
				'attribute_code': 'description',
				'value': description
			})
		short_description = product.short_description
		if short_description and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'short_description'):
			custom_attributes.append({
				'attribute_code': 'short_description',
				'value': short_description
			})

		# Update product status
		update_data['product']['status'] = 1 if product.status == 'active' else 2

		# Update product meta title, meta description, url
		meta_title = product.meta_title
		if meta_title and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'meta_title'):
			custom_attributes.append({
				'attribute_code': 'meta_title',
				'value': meta_title
			})
		meta_description = product.meta_keyword
		if meta_description and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'meta_description'):
			custom_attributes.append({
				'attribute_code': 'meta_description',
				'value': meta_description
			})

		if not product.variants:
			if product.special_price.price and product.special_price.price != product.price and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'special_price'):
				custom_attributes.append({
					'attribute_code': 'special_price',
					'value': product.special_price.price
				})
				if product.special_price.start_date and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'special_from_date'):
					custom_attributes.append({
						'attribute_code': 'special_from_date',
						'value': product.special_price.start_date
					})
				if product.special_price.end_date and get_row_from_list_by_field(attribute_magento, 'attribute_code', 'special_to_date'):
					custom_attributes.append({
						'attribute_code': 'special_to_date',
						'value': product.special_price.end_date
					})
			update_data['product']['price'] = product.price
			update_data['product']['custom_attributes'] = custom_attributes
			update_data['product']['extension_attributes'] = {
				'stock_item': {
					'qty': product.qty
				}
			}
			self.api('products/{}'.format(old_sku), update_data, 'put')
		else:
			for variant in product.variants:
				variant_id = variants_channel[variant.id].get('product_id')
				if variant_id:
					self.product_channel_update(variant_id, variant, {})

		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success(product_id)
		product_magento_data = self.get_product_by_id(product_id)
		if product_magento_data.result != Response().SUCCESS:
			return Response().error(msg = "Can not find product id: " + to_str(product_id))
		product_magento_data = product_magento_data.data
		update_data = dict()
		if setting_qty:
			qty = to_int(product.qty)
			real_qty = to_int(product.qty)
			if not product.variants:
				magento_product = self.get_product_by_sku(product_magento_data.sku)
				if not magento_product:
					return Response().error(msg = 'not found')
				magento_qty = magento_product.extension_attributes.stock_item.qty
				salable_qty = self.api(f'inventory/get-product-salable-quantity/{product_magento_data.sku}/{magento_product.extension_attributes.stock_item.stock_id}')
				if self._last_status == 200 and to_str(to_int(salable_qty)) == to_str(salable_qty):
					salable_qty = to_int(salable_qty)
					qty = qty + magento_qty - salable_qty
			update_data['extension_attributes'] = {
				'stock_item': {
					'qty': qty,
					"is_in_stock": real_qty > 0
				}
			}
		if setting_price:
			update_data['price'] = product.price
			custom_attributes = list()
			if self.is_special_price(product):
				special_price = product.special_price.price
				start_date = product.special_price.start_date
				end_date = product.special_price.end_date if to_timestamp_or_false(product.special_price.end_date) else None

			else:
				special_price = None
				start_date = None
				end_date = None
			custom_attributes.append({
				'attribute_code': 'special_price',
				'value': special_price
			})
			custom_attributes.append({
				'attribute_code': 'special_from_date',
				'value': start_date
			})

			custom_attributes.append({
				'attribute_code': 'special_to_date',
				'value': end_date
			})
			update_data['custom_attributes'] = custom_attributes
		update = self.api(f'products/{product_magento_data.sku}', {'product': update_data}, 'put', log_file = 'inventory')
		if self._last_status > 300 or not update:
			msg = update.message if update else "Something error"
			return Response().error(msg = msg)
		if product.variants:
			for variant in product.variants:
				channel_data = variant.channel.get(f"channel_{self.get_channel_id()}")
				if not channel_data or not channel_data.get('product_id'):
					continue
				variant_magento_data = self.get_product_by_id(channel_data.product_id)
				if variant_magento_data.result != Response.SUCCESS:
					continue
				variant_sku = variant_magento_data.data.sku
				variant_update_data = dict()
				if setting_qty:
					variant_qty = variant.qty
					real_variant_qty = variant.qty
					magento_variant = self.get_product_by_sku(variant_sku)
					if not magento_variant:
						return Response().error(msg = 'not found')
					variant_magento_qty = magento_variant.extension_attributes.stock_item.qty
					variant_salable_qty = self.api(f'inventory/get-product-salable-quantity/{variant_sku}/{magento_variant.extension_attributes.stock_item.stock_id}')
					if to_int(variant_salable_qty):
						variant_salable_qty = to_int(variant_salable_qty)
						variant_qty = variant_qty + variant_magento_qty - variant_salable_qty
					variant_update_data['extension_attributes'] = {
						'stock_item': {
							'qty': variant_qty,
							"is_in_stock": real_variant_qty > 0

						}
					}
				if setting_price:
					variant_update_data['price'] = variant.price
					custom_attributes = list()
					if self.is_special_price(variant):
						special_price = variant.special_price.price
						start_date = variant.special_price.start_date
						end_date = variant.special_price.end_date if to_timestamp(variant.special_price.end_date) else None

					else:
						special_price = None
						start_date = None
						end_date = None
					custom_attributes.append({
						'attribute_code': 'special_price',
						'value': special_price
					})
					custom_attributes.append({
						'attribute_code': 'special_from_date',
						'value': start_date
					})

					custom_attributes.append({
						'attribute_code': 'special_to_date',
						'value': end_date
					})
					variant_update_data['custom_attributes'] = custom_attributes
				update = self.api(f'products/{variant_sku.replace(" ", "%20")}', {'product': variant_update_data}, 'put')
				if self._last_status > 300:
					msg = update.message if update else "Something error"
					return Response().error(msg = msg)
		return Response().success()


	def get_orders_main_export(self):
		limit_data = 25
		imported = self._state.pull.process.orders.imported
		current_page = math.floor((to_decimal(imported) / to_decimal(limit_data))) + 1
		search_criteria = {
			'currentPage': current_page,
			'pageSize': limit_data,
			'filterGroups': [
				{
					'filters': self.get_order_filter()
				}
			],
			'sortOrders': [
				{
					'direction': 'ASC',
					'field': 'updated_at'
				}
			]
		}
		orders = self.api('orders', search_criteria = search_criteria)
		if 'message' in orders:
			if self._last_status != 200:
				return Response().error(msg = orders.message)
		if not orders.get('items'):
			return Response().finish()
		return Response().success(data = orders['items'])


	def get_orders_ext_export(self, orders):
		return Response().success()


	def convert_order_status(self, status):
		order_status = {
			"canceled": Order.CANCELED,
			"closed": Order.CANCELED,
			"complete": Order.COMPLETED,
			"holded": Order.OPEN,
			"payment_review": Order.AWAITING_PAYMENT,
			"pending": Order.OPEN,
			"pending_payment": Order.AWAITING_PAYMENT,
			"processing": Order.SHIPPING,
		}
		return order_status.get(status, 'open') if status else 'open'


	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_create = to_timestamp(order.created_at, "%Y-%m-%d %H:%M:%S")
		start_time = to_timestamp(self.get_order_start_time('%Y-%m-%d %H:%M:%S'))

		if order_create < start_time:
			return Response().skip()

		self.set_order_max_last_modifier(order.updated_at)
		order_data = Order()
		if order.payment:
			order_data.payment.title = order.payment.additional_information[0] if order.payment.additional_information else "Payment"
			order_data.payment.method = order.payment.method
			if (to_str(order.payment.method).find('tabby') != -1 or to_str(order.payment.method).find('tamara') != -1) and order.state not in ['processing', 'complete' ,'completed']:
				return Response().skip()

		order_data.order_number = order.increment_id
		order_data.order_id = order.entity_id
		order_data.status = self.convert_order_status(order.state)
		order_data.tax.amount = to_decimal(order.tax_amount)
		if order.discount_amount:
			discount_amount = to_decimal(order.discount_amount)
			if discount_amount < 0:
				discount_amount = 0 - discount_amount
			order_data.discount.amount = discount_amount
		order_data.discount.code = order.coupon_code
		order_data.shipping.title = order.shipping_description
		order_data.shipping.amount = order.shipping_amount
		order_data.subtotal = order.subtotal
		order_data.total = order.grand_total
		order_data.currency = order.order_currency_code
		order_data.created_at = convert_format_time(order.created_at, '%Y-%m-%d %H:%M:%S')
		order_data.updated_at = convert_format_time(order.updated_at, '%Y-%m-%d %H:%M:%S')
		order_data.channel_data = {
			'order_status': order.status,
			'created_at': order_data.created_at
		}
		order_data.customer.id = order.customer_id
		order_data.customer.email = order.customer_email
		order_data.customer.first_name = order.customer_firstname
		order_data.customer.last_name = order.customer_lastname
		if order.billing_address:
			order_data.customer_address.id = order.billing_address.entity_id
			order_data.customer_address.first_name = order.billing_address.firstname
			order_data.customer_address.last_name = order.billing_address.lastname
			order_data.customer_address.address_1 = order.billing_address.street[0]
			order_data.customer_address.city = order.billing_address.city
			order_data.customer_address.country.country_code = order.billing_address.country_id
			order_data.customer_address.state.state_name = order.billing_address.region
			order_data.customer_address.state.state_code = order.billing_address.region_code
			order_data.customer_address.postcode = order.billing_address.postcode
			order_data.customer_address.telephone = order.billing_address.telephone

		if order.billing_address:
			order_data.billing_address.id = order.billing_address.entity_id
			order_data.billing_address.first_name = order.billing_address.firstname
			order_data.billing_address.last_name = order.billing_address.lastname
			order_data.billing_address.address_1 = order.billing_address.street[0]
			order_data.billing_address.city = order.billing_address.city
			order_data.billing_address.country.country_code = order.billing_address.country_id
			order_data.billing_address.state.state_name = order.billing_address.region
			order_data.billing_address.state.state_code = order.billing_address.region_code
			order_data.billing_address.postcode = order.billing_address.postcode
			order_data.billing_address.telephone = order.billing_address.telephone
		shipping_assignments = order.extension_attributes.shipping_assignments
		if shipping_assignments and 'shipping' in shipping_assignments[0] and shipping_assignments[0]['shipping'].get('address'):
			shipping_address = shipping_assignments[0]['shipping']['address']
			order_data.shipping_address.id = shipping_address.entity_id
			order_data.shipping_address.first_name = shipping_address.firstname
			order_data.shipping_address.last_name = shipping_address.lastname
			order_data.shipping_address.address_1 = shipping_address.street[0]
			order_data.shipping_address.city = shipping_address.city
			order_data.shipping_address.country.country_code = shipping_address.country_id
			order_data.shipping_address.state.state_name = shipping_address.region
			order_data.shipping_address.state.state_code = shipping_address.region_code
			order_data.shipping_address.postcode = shipping_address.postcode
			order_data.shipping_address.telephone = shipping_address.telephone
		else:
			order_data.shipping_address = order_data.billing_address

		for item in order['items']:
			if item.get('product_type') == 'configurable':
				continue
			order_item = OrderProducts()
			# order_item.id = item['item_id']
			order_item.product_id = item.get('product_id') if item.get('product_id') else self.get_product_id_by_sku(item['sku'])
			order_item.product_name = item['name']
			item_get_price = item['parent_item'] if item.get('parent_item') else item
			order_item.sku = item['sku']
			order_item.qty = item['qty_ordered']
			order_item.price = item_get_price['price']
			order_item.original_price = item_get_price['original_price']
			order_item.sub_total = to_decimal(item_get_price['price']) * to_decimal(item_get_price['qty_ordered'])
			order_item.total = to_decimal(item_get_price['row_total'])
			order_item.tax_amount = item_get_price['tax_amount']
			order_item.discount_amount = item_get_price['discount_amount']
			if item.get('parent_item', dict()).get('product_option'):
				order_item.listing_id = item['parent_item']['product_id']
				for custom_option in item['parent_item']['product_option']['extension_attributes']['configurable_item_options']:
					order_item_option = OrderItemOption()
					order_item_option.option_id = custom_option['option_id']
					order_item_option.option_value_id = custom_option['option_value']
					search_criteria = {
						'filterGroups': [
							{
								'filters': [
									{
										'conditionType': 'eq',
										'field': 'attribute_id',
										'value': custom_option['option_id'],
									},
								]
							}
						]
					}
					data_option = self.api("products/attributes", search_criteria = search_criteria)
					if 'message' not in data_option and data_option['items']:
						order_item_option.option_name = data_option['items'][0]['default_frontend_label']
						order_item_option.option_value_name = get_row_value_from_list_by_field(data_option['items'][0]['options'], 'value', order_item_option.option_value_id, 'label')
					order_item.options.append(order_item_option)
			order_data['products'].append(order_item)
		if order.status_histories:
			for history in order.status_histories:
				if to_int(history.get('is_visible_on_front')) != 1:
					continue
				history_data = OrderHistory()
				history_data.created_at = history.created_at
				history_data.comment = history.comment
				history_data.status = history.status
				order_data.history.append(history_data)
		if order.state == 'complete':
			c = 3
			search_criteria = {
				'filterGroups': [
					{
						'filters': [
							{
								'conditionType': 'eq',
								'field': 'order_id',
								'value': order.entity_id,
							},
						]
					}
				]
			}
			shipmment = self.api('shipments', search_criteria = search_criteria)
			if shipmment and shipmment.get('items') and shipmment['items'][0].get('tracks'):
				track = shipmment['items'][0].get('tracks')[0]
				order_data.shipments.tracking_company_code = track['carrier_code']
				order_data.shipments.tracking_company = track['title']
				order_data.shipments.tracking_number = track['track_number']
				order_data.shipments.shipped_at = track['created_at']

		return Response().success(order_data)


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def get_order_by_id(self, order_id):
		order = self.api('orders/' + to_str(order_id))
		if 'message' in order:
			return Response().error(msg = order.message)
		return Response().success(data = order)


	def convert_search_criteria_to_params(self, search_criteria, pre_string = ''):
		if not to_str(search_criteria):
			return pre_string
		if not pre_string:
			params = '?'
		else:
			params = ''
		if isinstance(search_criteria, dict):
			for key, value in search_criteria.items():
				if pre_string:
					new_pre_string = pre_string + '[{}]'.format(key)
					params += self.convert_search_criteria_to_params(value, pre_string = new_pre_string)
				else:
					new_pre_string = 'search_criteria[{}]'.format(key)
					params += self.convert_search_criteria_to_params(value, pre_string = new_pre_string)
		elif isinstance(search_criteria, list):
			for i, val in enumerate(search_criteria):
				if pre_string:
					new_pre_string = pre_string + '[{}]'.format(i)
					params += self.convert_search_criteria_to_params(val, pre_string = new_pre_string)
				else:
					new_pre_string = 'search_criteria[{}]'.format(i)
					params += self.convert_search_criteria_to_params(val, pre_string = new_pre_string)
		else:
			params += pre_string + '={}&'.format(search_criteria)
		return params


	def create_attribute_code(self, attribute_name):
		attribute_name = self.convert_attribute_code(attribute_name)
		attribute_name = self.remove_special_char(attribute_name)
		attribute_name = to_str(attribute_name).replace('-', '_')
		return attribute_name


	def convert_attribute_code(self, name):
		if not to_str(name).strip(' / - _'):
			return ''
		str_convert = html.unescape(name)
		if isinstance(str_convert, bool):
			if str_convert:
				str_convert = 'yes'
			else:
				str_convert = 'no'
		result = self.generate_url(str_convert)
		if not result:
			return self.parse_url(str_convert).lower()
		try:
			check_encode = chardet.detect(result.encode())
			if check_encode['encoding'] != 'ascii' or not result:
				return self.parse_url(result).lower()
		except Exception:
			pass
		return result.strip('- ')


	def get_max_last_modified_product(self, config_product = False):
		last_modified = self._state.pull.process.products.last_modified if not config_product else self._state.pull.process.products.last_modified_config_product
		if last_modified:
			if to_str(last_modified).isnumeric():
				return convert_format_time(last_modified, new_format = "%Y-%m-%d %H:%M:%S")
			return last_modified
		return False


	def set_product_max_last_modified(self, product):
		updated_at = self.get_product_updated_at(product)
		current_modified = self._product_max_last_modified
		if not current_modified:
			self._product_max_last_modified = updated_at
			return
		old_timestamp = self.updated_at_to_timestamp(current_modified)
		new_timestamp = self.updated_at_to_timestamp(updated_at)
		if new_timestamp > old_timestamp:
			self._product_max_last_modified = updated_at


	def get_category_name_list(self, category_ids):
		if not category_ids:
			return list()
		category_ids = list(map(lambda x: to_int(x), set(category_ids)))
		name_list = list()
		unknown_category = list()
		for category_id in category_ids:
			if self._all_categories.get(category_id):
				name_list.append(self._all_categories[category_id])
			else:
				unknown_category.append(category_id)
		if unknown_category:
			filters = [{
				'filters': [
					{
						'conditionType': 'in',
						'field': 'entity_id',
						'value': ','.join(list(map(lambda x: to_str(x), unknown_category))),
					}
				]
			}]
			search_criteria = {
				'pageSize': 100,
				'filterGroups': filters,
				'sortOrders': [
					{
						'direction': 'ASC',
						'field': 'entity_id'
					}
				]
			}
			categories = self.api('categories/list', search_criteria = search_criteria)
			if self._last_status == 200:
				for category in categories['items']:
					self._all_categories[category['id']] = category['name']
					name_list.append(category['name'])
		return name_list


	def validate_channel_url(self):
		if not is_local():
			validate = self.channel_is_local_host()
			if validate.result != Response.SUCCESS:
				return validate
		return Response().success()


	def display_push_channel(self, data = None):
		parent = super().display_push_channel(data)
		if parent.result != Response.SUCCESS:
			return parent
		if not self.is_inventory_process():
			return Response().success()
		today = datetime.today()
		day = today.day
		date_format = today.strftime("%Y-%m-%d")
		if day % 7 or (self._state.channel.config.reset_inventory_sync and self._state.channel.config.reset_inventory_sync == date_format):
			return Response().success()
		self._state.channel.config.reset_inventory_sync = date_format
		self.get_model_state().update_field(self.get_state_id(), 'channel.config.reset_inventory_sync', date_format)
		try:
			where = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.link_status', "linked")
			where.update(self.get_model_catalog().create_where_condition('is_variant', False))
			id_src = ''
			while True:
				if id_src:
					where.update(self.get_model_catalog().create_where_condition('_id', id_src, '>'))
				products = self.get_model_catalog().find_all(where, select_fields = ['qty', f'channel.channel_{self.get_channel_id()}', 'sku'], limit = 500, sort = '_id')
				if not products:
					break
				for product in products:
					sku = product['channel'][f'channel_{self.get_channel_id()}'].get('sku') or product['sku']
					magento_qty = self.get_salable_quantity(sku, 1)
					if to_str(magento_qty) == to_str(product['qty']):
						continue
					self.get_model_catalog().update_field(product['_id'], 'updated_time', time.time())
					time.sleep(0.1)
					id_src = product['_id']
				if to_len(products) < 500:
					break
		except:
			self.log_traceback()
		return Response().success()

	def get_salable_quantity(self, sku, stock_id):
		magento_qty_req = self.api(f"inventory/get-product-salable-quantity/{sku}/{stock_id}")
		try:
			qty = magento_qty_req.json()
		except:
			qty = -26120710
		return qty