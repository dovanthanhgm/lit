from urllib.parse import quote

try:
	from lxml.etree import Element, tostring, fromstring
except ImportError:
	from xml.etree.ElementTree import Element, tostring, fromstring
from xmljson import badgerfish as bf
import requests
import csv
from io import StringIO

from datasync.models.modes.test import ModelModesTest
from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.product import *
from datasync.models.constructs.order import *


class ModelChannelsAmazon(ModelChannel):
	# Construct local database
	_model_local = None
	_product_table_name = 'products'
	_order_table_name = 'orders'
	# Order status mapping
	ORDER_STATUS = {
		'PendingAvailability': Order.OPEN,
		'Pending': Order.OPEN,
		'Unshipped': Order.OPEN,
		'PartiallyShipped': Order.SHIPPING,
		'Shipped': Order.COMPLETED,
		'Canceled': Order.CANCELED,
		'Unfulfillable': Order.CANCELED,
	}
	# Offer templete
	offer_template = {
		'condition': {
			'new': 'New',
			'used': 'UsedLikeNew',
			'reconditioned': 'Refurbished',
			'note': {
				'mapping': '',
				'override': '',
			}
		},
		'fulfillment': 'fbm',
		'handling_time': None,
		'tax_code': None,
		'gift_message': None,
		'gift_wrap': None,
		'max_order_qty': None,
	}

	# Handle import process
	cache_products = list()
	cache_warnings = dict()
	cache_errors = dict()
	# Handle update process
	_update_product = False
	_update_qty = True
	_update_price = True

	# MWS API information - Startswith MWS prefix
	FULFILLMENT_CENTER = {
		'ATVPDKIKX0DER': 'AMAZON_NA',
		'A2EUQ1WTGCTBG2': 'AMAZON_NA',
		'A1AM78C64UM0Y8': 'AMAZON_NA',
		'A1F83G8C2ARO7P': 'AMAZON_EU',
		'A1PA6795UKMFR9': 'AMAZON_EU',
		'A1RKKUPIHCS9HS': 'AMAZON_EU',
		'A13V1IB3VIYZZH': 'AMAZON_EU',
		'APJ6JRA9NG5V4': 'AMAZON_EU',
	}
	MWS_CURRENCY = {
		'ATVPDKIKX0DER': 'USD',
		'A2EUQ1WTGCTBG2': 'CAD',
		'A1AM78C64UM0Y8': 'MXN',
		'A1F83G8C2ARO7P': 'EUR',
		'A1PA6795UKMFR9': 'EUR',
		'A1RKKUPIHCS9HS': 'EUR',
		'A13V1IB3VIYZZH': 'EUR',
		'APJ6JRA9NG5V4': 'EUR',
	}
	MWS_MARKETPLACES = {
		'ATVPDKIKX0DER': 'https://mws.amazonservices.com',
		'A2EUQ1WTGCTBG2': 'https://mws.amazonservices.ca',
		'A1AM78C64UM0Y8': 'https://mws.amazonservices.com.mx',
		'A1F83G8C2ARO7P': 'https://mws-eu.amazonservices.com',
		'A1PA6795UKMFR9': 'https://mws-eu.amazonservices.com',
		'A1RKKUPIHCS9HS': 'https://mws-eu.amazonservices.com',
		'A13V1IB3VIYZZH': 'https://mws-eu.amazonservices.com',
		'APJ6JRA9NG5V4': 'https://mws-eu.amazonservices.com',
	}
	MWS_SESSIONS = {
		'Products': ('/Products/2011-10-01', '2011-10-01'),
		'Feeds': ('/', '2009-01-01'),
		'Sellers': ('/Sellers/2011-07-01', '2011-07-01'),
		'Reports': ('/', '2009-01-01'),
		'Orders': ('/Orders/2013-09-01', '2013-09-01'),
		'Fulfillment': ('/FulfillmentInventory/2010-10-01', '2010-10-01')
	}
	MWS_CONDITIONS = {
		1: 'UsedLikeNew',
		2: 'UsedVeryGood',
		3: 'UsedGood',
		4: 'UsedAcceptable',
		5: 'CollectibleLikeNew',
		6: 'CollectibleVeryGood',
		7: 'CollectibleGood',
		8: 'CollectibleAcceptable',
		9: 'Used',
		10: 'Refurbished',
		11: 'New',
	}
	MWS_CONDITIONS_MAPPING = {
		1: 'used',
		2: 'used',
		3: 'used',
		4: 'used',
		5: 'used',
		6: 'used',
		7: 'used',
		8: 'used',
		9: 'used',
		10: 'reconditioned',
		11: 'new',
	}


	def get_api_info(self):
		"""
		Information required to make an API call
		"""
		return {
			'seller_id': 'Seller ID',
			'token': 'Authorization token',
			'marketplace_id': 'Marketplace',
			'fulfillment': 'Fulfillment by',
		}


	# TODO: MWS API utils - Functions support for calling API, converting, parsing data.

	def get_default_params_api(self, session):
		"""
		Get necessary params for all API requests
		Example:
			SellerId,
			MWSAuthToken,
			...
		"""
		params = {
			'SellerId': self._state.channel.config.api.seller_id,
			'MWSAuthToken': self._state.channel.config.api.token,
			'AWSAccessKeyId': get_config_ini('amazon', 'user_access_key'),
			'SignatureVersion': '2',
			'Timestamp': datetime.utcnow().replace(microsecond = 0).isoformat(),
			'SignatureMethod': 'HmacSHA256',
			'Version': self.get_version_session_api(session)
		}
		return params


	def get_marketplace_domain_api(self):
		"""
		Get API domain, depend on marketplace region.
		ref: https://docs.developer.amazonservices.com/en_US/dev_guide/DG_Endpoints.html

		Return:
			'https://mws.amazonservices.com'
		"""
		return self.MWS_MARKETPLACES.get(self._state.channel.config.api.marketplace_id, 'https://mws.amazonservices.com')


	def get_marketplace_id_api(self):
		"""
		Get marketplace Id, depend on market place region.
		ref: https://docs.developer.amazonservices.com/en_US/dev_guide/DG_Endpoints.html

		Return:
			'ATVPDKIKX0DER'
		"""
		return self._state.channel.config.api.marketplace_id


	def get_uri_session_api(self, session):
		"""
		Get URI of API session.
		Example:
			session = 'Products'
		Return:
			'/Products/2011-10-01'
		"""
		return self.MWS_SESSIONS.get(session, '/ ')[0]


	def get_version_session_api(self, session):
		"""
		Get version of API session.
		Example:
			session = 'Products'
		Return:
			'2011-10-01'
		"""
		return self.MWS_SESSIONS.get(session, '/ ')[1]


	@staticmethod
	def clean_params_api(params):
		"""
		Input cleanup and prevent a lot of common input mistake. URL encode content of params.
		"""
		params = {key: value for key, value in params.items()
		          if value is not None and value != ''}

		params_enc = dict()
		for key, value in params.items():
			if isinstance(value, (dict, list, set, tuple)):
				error_msg = 'Expected string or datetime datatype, got {}, ' \
				            'for key {} and value {}'.format(type(value), key, str(value))
				raise Exception(error_msg)
			if isinstance(value, datetime):
				value = value.isoformat()
			if isinstance(value, bool):
				value = str(value).lower()
			value = str(value)
			params_enc[key] = quote(value)
		return params_enc


	@staticmethod
	def calc_request_description(params):
		"""
		Returns a flatted string with the request description, built from the params dict.
		Entries are escaped with urllib quote method, formatted as "key=value", and joined with "&".
		Builds the request description as a single string from the set of params.

		Each key-value pair takes the form "key=value"
		Sets of "key=value" pairs are joined by "&".
		Keys should appear in alphabetical order in the result string.

		Example:
			params = {'foo': 1, 'bar': 4, 'baz': 'potato'}
		Returns:
			"bar=4&baz=potato&foo=1"
		"""
		description_items = []
		for item in sorted(params.keys()):
			encoded_val = params[item]
			description_items.append("{}={}".format(item, encoded_val))
		return "&".join(description_items)


	def calc_signature(self, session, method, request_description):
		"""
		Calculate MWS signature to interface with Amazon

		Args:
			session (str)
			method (str)
			request_description (str)
		"""
		sig_data = "\n".join(
			[
				method,
				self.get_marketplace_domain_api().replace("https://", "").lower(),
				self.get_uri_session_api(session),
				request_description,
			]
		)
		return base64.b64encode(
			hmac.new(
				get_config_ini('amazon', 'secret_key').encode(),
				sig_data.encode(),
				hashlib.sha256
			).digest()
		)


	@staticmethod
	def remove_namespace(xml):
		"""
		Strips the namespace from XML document contained in a string.
		Returns the stripped string.
		"""
		regex = re.compile(' xmlns(:ns2)?="[^"]+"|(ns2:)|(xml:)')
		return regex.sub("", xml)


	def parse_xml_to_dict(self, xml):
		"""
		Parse XML string to a Prodict.
		Args:
			xml (str)
		"""
		result = xml
		try:
			xml = self.remove_namespace(xml)
			data = bf.data(fromstring(xml.encode()))
			result = Prodict.from_dict(data)
		except Exception:
			pass
		return result


	@staticmethod
	def parse_dict_to_xml(obj, declaration = '<?xml version="1.0" encoding="iso-8859-1"?>', item_tag = 'item'):
		xml = ''
		if isinstance(obj, list):
			item_elements = []
			for item in obj:
				item_element = tostring(bf.etree(item, root = Element(item_tag))).decode('utf-8')
				item_elements.append(item_element)
			xml = '\n'.join(item_elements)
		if isinstance(obj, dict):
			item_elements = []
			for key, value in obj.items():
				item_element = tostring(bf.etree(value, root = Element(key))).decode('utf-8')
				item_elements.append(item_element)
			xml = '\n'.join(item_elements)
		if declaration:
			xml = declaration + '\n' + xml
		return xml


	@staticmethod
	def enumerate_param(param, values):
		"""
		Builds a dictionary of an enumerated parameter, using the param string and some values.
		If values is not a list, tuple or set it will be force to be a list
		with a signle item.

		Example:
			self.enumerate_param('MarketpalceIdList.Id', (123, 456, 789))
		Returns:
			{
				'MarketplaceIdList.Id.1': 123,
				'MarketplaceIdList.Id.2': 456,
				'MarketplaceIdList.Id.3': 789,
			}
		"""
		if not isinstance(values, (list, tuple, set)):
			# Force a single value to a list before continuing.
			values = [values]
		if not any(values):
			return {}
		if not param.endswith('.'):
			# Ensure this enumerated param ends in '.'
			param += '.'
		# Return final output: dict comprehension of the enumerated param and values.
		return {'{}{}'.format(param, index): value
		        for index, value in enumerate(values, 1)}


	@staticmethod
	def hash_md5_feed_content(xml):
		"""
		Calculates the MD5 encryption of feed content for SubmitFeed extra_headers.
		Args:
			xml (str)
		"""
		md5_hash = hashlib.md5()
		md5_hash.update(xml.encode())
		return base64.b64encode(md5_hash.digest()).strip(b"\n")


	def get_default_feed_content(self, feed_type):
		"""
		Get default feed data (dict) for each SubmitFeed requests.
		Args:
			feed_type (str)
		Example:
			feed_type = 'Product'
		"""
		return {
			'AmazonEnvelope': {
				# '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
				# '@xsi:noNamespaceSchemaLocation': 'amzn-envelope.xsd',
				'Header': {
					'DocumentVersion': 1.01,
					'MerchantIdentifier': self.get_marketplace_id_api(),
				},
				'MessageType': feed_type,
				'Message': [],
			}
		}


	def api(self, session, action, extra_data = {}, method = 'GET', body = '', extra_headers = {}, **kwargs):
		"""
		Make a request to Amazon MWS API with these parameters:

		Args:
			session (str)
			action (str)
			extra_data (dict)
			method (str)
			body (str)
			extra_headers (dict)
		Returns:
			response (dict)
		"""
		session = session.capitalize()
		params = self.get_default_params_api(session)
		params['Action'] = action
		params.update(extra_data)
		params = self.clean_params_api(params)

		request_description = self.calc_request_description(params)
		signature = self.calc_signature(session, method, request_description)
		url = '{domain}{uri}?{description}&Signature={signature}'.format(
			domain = self.get_marketplace_domain_api(),
			uri = self.get_uri_session_api(session),
			description = request_description,
			signature = quote(signature),
		)

		headers = {
			"User-Agent": get_random_useragent()
		}
		headers.update(extra_headers)

		print(f'Calling {session} - {action}')
		response = requests.request(
			method,
			url,
			data = body,
			headers = headers,
			timeout = kwargs.get('timeout', 300),
		)
		response_content = self.remove_namespace(response.text)
		response = self.parse_xml_to_dict(response_content)
		retry = 5
		while retry > 0:
			if not response or (isinstance(response, dict) and response.get('ErrorResponse') and response['ErrorResponse'].get('Error') and
			                    isinstance(response['ErrorResponse']['Error'], dict) and response['ErrorResponse']['Error'].get('$') == 'RequestThrottled'):
				time.sleep(10 * (6 - retry))
				response = requests.request(
					method,
					url,
					data = body,
					headers = headers,
					timeout = kwargs.get('timeout', 300),
				)
				retry -= 1
			else:
				break
		# Log error response
		error_msg = None
		if not response:
			error_msg = Errors.AMAZON_REQUEST_TIMEOUT
		elif isinstance(response, dict) and response.get('ErrorResponse'):
			error_msg = to_str(response['ErrorResponse'])
		if error_msg:
			self.log_request_error(**{
				'method': method,
				'url': url,
				'headers': headers,
				'data': body,
				'error': error_msg
			})
		return response


	def check_submit_feed_response(self, response):
		"""
		Check response when submit feed to Amazon AMS.
		If submission complete successfully return submission_id, elif return errors message.
		Args:
			response (Prodict): response when submit feed.
		Return:
			_response object
		"""
		if not response:
			return Response().error(Errors.AMAZON_REQUEST_TIMEOUT)
		try:
			if response.ErrorResponse:
				return Response().error(msg = response.ErrorResponse.Error.Message.get('$'))
			submission_id = response.SubmitFeedResponse.SubmitFeedResult.FeedSubmissionInfo.FeedSubmissionId.get('$')
		except Exception:
			self.log('Cannot get FeedSubmissionId when submit Feed.', 'submit_feed_errors')
			return Response().error(Errors.AMAZON_PUSH_PRODUCT_ERROR)
		if not submission_id:
			self.log('Cannot get FeedSubmissionId when submit Feed.', 'submit_feed_errors')
			return Response().error(Errors.AMAZON_PUSH_PRODUCT_ERROR)
		return Response().success(data = submission_id)


	def check_submit_feed_result(self, submission_id, feed_type):
		"""
		Check result of submit feed process and store submission result errors and warning into cache_errors, cache_warnings attributes.
		This function only work inside product_import function.
		Args:
			submission_id (int)
			feed_type (str)
		"""
		start = time.time()
		time.sleep(30)
		response = self.api('Feeds', 'GetFeedSubmissionResult', {'FeedSubmissionId': submission_id})
		count = 0
		total_count = max(len(self.cache_products) * 2, 10)
		while count < total_count:
			if not response or response.ErrorResponse:
				if response.ErrorResponse.Error.Code.get('$') == 'FeedProcessingResultNotReady':
					time.sleep(60)
					response = self.api('Feeds', 'GetFeedSubmissionResult', {'FeedSubmissionId': submission_id}, 'GET')
					count += 1
				else:
					break
			else:
				break
		if not response or response.ErrorResponse:
			for product in self.cache_products:
				self.cache_errors[product['id']].append(f'Time expired when getting {feed_type} submission result.')
			return False
		# print(f'Feed {feed_type} process time:', (end - start) / 60, 'minutes')
		if response.AmazonEnvelope.Message.ProcessingReport.Result:
			if isinstance(response.AmazonEnvelope.Message.ProcessingReport.Result, dict):
				response.AmazonEnvelope.Message.ProcessingReport.Result = [response.AmazonEnvelope.Message.ProcessingReport.Result]
			for message_result in response.AmazonEnvelope.Message.ProcessingReport.Result:
				message_id = message_result.MessageID.get('$')
				result_code = message_result.ResultCode.get('$')
				message_code = message_result.ResultMessageCode.get('$')
				message_description = Errors().get_msg_error(to_int(message_code)) or message_result.ResultDescription.get('$')
				if message_id:
					product = self.cache_products[message_id - 1]
					if result_code == 'Error':
						self.cache_errors[product.id].append(message_description)
					if result_code == 'Warning':
						self.cache_warnings[product.id].append(message_description)
		return True


	def validate_api_info(self):
		for key, value in self._state.channel.config.api.items():
			if isinstance(value, str):
				self._state.channel.config.api[key] = value.strip()
		submission = self.api('Feeds', 'GetFeedSubmissionList')
		if not submission:
			return Response().error(Errors.AMAZON_API_INVALID)
		try:
			if submission.ErrorResponse:
				return Response().error(msg = submission.ErrorResponse.Error.Message.get('$'))
		except Exception:
			return Response().error(Errors.AMAZON_API_INVALID)
		return Response().success()


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# Support
		self._state.channel.support.products = True
		self._state.channel.support.orders = True
		self._state.channel.support.taxes = False
		self._state.channel.support.categories = False
		return Response().success()


	def after_create_channel(self, data):
		if self._state.channel.config.api.fulfillment == 'fba':
			self.get_warehouse_location_fba()
		return Response().success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		identifier = to_str(self._state.channel.config.api.seller_id) + '-' + to_str(self._state.channel.config.api.marketplace_id)
		self.set_identifier(identifier)
		return Response().success()


	def get_model_local(self):
		if self._model_local:
			return self._model_local
		self._model_local = ModelModesTest()
		self._model_local.set_user_id(self._user_id)
		return self._model_local


	def table_construct_default(self, table_name: str):
		table_construct = {
			'table': table_name,
			'rows': {
				'id': 'int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT',
				'user_id': 'int(11)',
			}
		}
		return table_construct


	def upload(self, filename, content):
		folder_path = os.path.join(get_pub_path(), 'media', to_str(self._state.channel.id))
		file_path = os.path.join(folder_path, filename)
		if not os.path.isdir(folder_path):
			os.makedirs(folder_path)
			change_permissions_recursive(folder_path, 0o777)
		with open(file_path, 'wt') as f:
			f.write(content)
		return file_path


	def get_products_count_export(self):
		"""
		Get products, count and save to database
		"""
		extra_data = {
			'ReportType': '_GET_MERCHANT_LISTINGS_ALL_DATA_',
		}
		extra_data.update(self.enumerate_param('MarketplaceIdList.Id', self.get_marketplace_id_api()))
		report_request = self.api(
			session = 'Reports',
			action = 'RequestReport',
			extra_data = extra_data
		)
		if not report_request or \
				not report_request.RequestReportResponse.RequestReportResult.ReportRequestInfo.ReportRequestId:
			return Response().error(Errors.AMAZON_GET_PRODUCT_ERROR)
		report_request_id = report_request.RequestReportResponse.RequestReportResult.ReportRequestInfo.ReportRequestId.get('$')
		extra_data = self.enumerate_param('ReportTypeList.Type.', '_GET_MERCHANT_LISTINGS_ALL_DATA_')
		extra_data.update(self.enumerate_param('ReportRequestIdList.Id.', report_request_id))
		time.sleep(15)
		report_list = self.api(
			session = 'Reports',
			action = 'GetReportList',
			extra_data = extra_data
		)
		retry = 10
		while retry > 0 and not report_list or not report_list.GetReportListResponse or not report_list.GetReportListResponse.GetReportListResult or \
				not report_list.GetReportListResponse.GetReportListResult.ReportInfo:
			time.sleep(60)
			retry -= 1
			report_list = self.api(
				session = 'Reports',
				action = 'GetReportList',
				extra_data = extra_data
			)
		report_id = report_list.GetReportListResponse.GetReportListResult.ReportInfo.ReportId.get('$')
		report_data = self.api(
			session = 'Reports',
			action = 'GetReport',
			extra_data = {'ReportId': report_id}
		)
		if report_data and isinstance(report_data, str):
			try:
				f = StringIO(report_data)
				products = list(csv.DictReader(f, delimiter = '\t'))
				if not products:
					return Response().success(data = 0)
				self.get_model_local().query_raw("DROP TABLE IF EXISTS `{}`".format(self._product_table_name))
				products_table_construct = self.table_construct_default(table_name = self._product_table_name)
				product_fields = [field for field in products[0].keys()]
				for field in product_fields:
					products_table_construct['rows'][field] = 'text'
				query = self.get_model_local().dict_to_create_table_sql(products_table_construct)
				if query['result'] == 'success':
					self.get_model_local().query_raw(query['query'])
				values = []
				for product in products:
					data = {
						'user_id': self._user_id
					}
					for field, value in product.items():
						data[field] = to_str(value)
					values.append(data)
				insert = self.get_model_local().insert_multiple_obj(self._product_table_name, values)
				if insert['result'] != Response().SUCCESS:
					return insert
			except Exception as e:
				self.log_traceback(e)
				return Response().error(Errors.EXCEPTION)
			return Response().success(data = len(products))
		return Response().error(Errors.AMAZON_GET_PRODUCT_ERROR)


	def get_orders_count_export(self):
		result = []
		id_src = self._state.pull.process.orders.id_src
		# created_channel = self._state.channel.created_at
		created_channel = None
		created_after = '2013-09-01T00:00:00Z' if not created_channel else convert_format_time(created_channel, new_format = '%Y-%m-%dT%H:%M:%SZ')
		if id_src:
			id_src = to_str(id_src)
			last_created_after_order = id_src.split('-')[-1]
			if last_created_after_order.isdigit():
				created_after = datetime.fromtimestamp(to_int(last_created_after_order)).strftime('%Y-%m-%dT%H:%M:%SZ')
		extra_data = self.enumerate_param('MarketplaceId.Id', self.get_marketplace_id_api())
		extra_data['CreatedAfter'] = created_after
		response = self.api('Orders', 'ListOrders', extra_data = extra_data)
		try:
			if response.ErrorResponse:
				return Response().error(msg = response.ErrorResponse.Error.Message.get('$'))
			if response.ListOrdersResponse.ListOrdersResult.Orders:
				result.extend(response.ListOrdersResponse.ListOrdersResult.Orders.Order)
			next_token = None
			if response.ListOrdersResponse.ListOrdersResult.NextToken:
				next_token = response.ListOrdersResponse.ListOrdersResult.NextToken.get('$')
		except Exception:
			return Response().error(Errors.AMAZON_GET_ORDER_ERROR)
		while next_token:
			time.sleep(30)
			response = self.api('Orders', 'ListOrdersByNextToken', extra_data = {'NextToken': next_token})
			try:
				if response.ErrorResponse:
					return Response().error(msg = response.ErrorResponse.Error.Message.get('$'))
				result.extend(response.ListOrdersResponse.ListOrdersResult.Orders.Order)
				next_token = None
				if response.ListOrdersResponse.ListOrdersResult.NextToken:
					next_token = response.ListOrdersResponse.ListOrdersResult.NextToken.get('$')
			except Exception:
				break
		if result:
			order = result[0]
			purchase_timestamp = min(to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%SZ'), to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ'))
			order_id = order.AmazonOrderId.get('$') + '-' + to_str(purchase_timestamp)
			if id_src == order_id:
				result.pop(0)
		if not result:
			return Response().success(data = 0)
		self.get_model_local().query_raw('DROP TABLE IF EXISTS `{}`'.format(self._order_table_name))
		orders_table_construct = self.table_construct_default(table_name = self._order_table_name)
		orders_table_construct['rows']['order_id'] = 'varchar(300)'
		orders_table_construct['rows']['order_data'] = 'text'
		query = self.get_model_local().dict_to_create_table_sql(orders_table_construct)
		if query['result'] == 'success':
			self.get_model_local().query_raw(query['query'])
		values = []
		for order in result:
			purchase_timestamp = min(to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%SZ'), to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ'))
			order_id = to_str(order.AmazonOrderId.get('$')) + '-' + to_str(purchase_timestamp)
			data = dict()
			data['user_id'] = self._user_id
			data['order_id'] = order_id
			data['order_data'] = json_encode(order)
			values.append(data)
		insert = self.get_model_local().insert_multiple_obj(table = self._order_table_name, data = values)
		if insert['result'] != Response().SUCCESS:
			return insert
		return Response().success(data = len(result))


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self._state.config.products:
			total_product = self.get_products_count_export()
			if total_product.result != Response().SUCCESS:
				return total_product
			total_product = total_product.data
			self._state.pull.process.products.total = total_product
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.id_src = 0
		if self._state.config.orders:
			self.log('Start order pulling', 'test_cron_orders')
			total_order = self.get_orders_count_export()
			if total_order.result != Response().SUCCESS:
				return total_order
			total_order = total_order.data
			self._state.pull.process.orders.total = total_order
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
		return Response().success()


	# TODO: Product

	def get_product_id_import(self, convert: Product, product, products_ext):
		return product['seller-sku']


	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._state.pull.process.products.id_src
		query = 'SELECT * FROM `{}` WHERE `seller-sku` > "{}" ORDER BY `seller-sku` LIMIT {}'.format(self._product_table_name, id_src, limit_data)
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS or not products.data:
			return Response().finish()
		return Response().success(data = products.data)


	def get_products_ext_export(self, products):
		extends = Prodict()
		for product in products:
			product_sku = product['seller-sku']
			extends[product_sku] = Prodict()
			# Get product ext by asin code
			asins = [product[key] for key in ['asin1', 'asin2', 'asin3'] if product[key]]
			extra_data = {'MarketplaceId': self.get_marketplace_id_api()}
			extra_data.update(self.enumerate_param('ASINList.ASIN.', asins))
			asin_data = self.api(
				session = 'Products',
				action = 'GetMatchingProduct',
				extra_data = extra_data
			)
			if not asin_data:
				self.log('Cannot get ASIN data - ASINs: {}'.format(', '.join(asins)), 'get_asin_ext')
				continue
			if asin_data.ErrorResponse:
				if isinstance(asin_data.ErrorResponse.Error, list):
					asin_data.ErrorResponse.Error = asin_data.ErrorResponse.Error[0]
				self.log('Cannot get ASIN data - ASINs: {}. Error message: {}'.format(', '.join(asins),
				                                                                      asin_data.ErrorResponse.Error.Message.get('$')), 'get_asin_ext')
				continue
			if not asin_data.GetMatchingProductResponse or not asin_data.GetMatchingProductResponse.GetMatchingProductResult.Product:
				self.log('Cannot get ASIN data - ASINs: {}'.format(', '.join(asins)), 'get_asin_ext')
				continue
			extends[product_sku].asin_ext = asin_data.GetMatchingProductResponse.GetMatchingProductResult.Product.AttributeSets.ItemAttributes
		# Get fba inventory by SKU
		if self._state.channel.config.api.get('fulfillment') == 'fba':
			product_skus = duplicate_field_value_from_list(products, 'seller-sku')
			extra_data = {'MarketplaceId': self.get_marketplace_id_api()}
			extra_data.update(self.enumerate_param('SellerSkus.member.', product_skus))
			fba_inventories_response = self.api(
				session = 'Fulfillment',
				action = 'ListInventorySupply',
				extra_data = extra_data
			)
			inventory_supply_list = []
			if not fba_inventories_response:
				self.log('Cannot get fba inventories - SKUs: {}'.format(', '.join(product_skus)), 'get_fba_inventories_ext')
			elif fba_inventories_response.ErrorResponse:
				if isinstance(fba_inventories_response.ErrorResponse.Error, list):
					fba_inventories_response.ErrorResponse.Error = fba_inventories_response.ErrorResponse.Error[0]
				self.log('Cannot get fba inventories - SKUs: {}. Error message: {}'.format(', '.join(product_skus),
				                                                                           fba_inventories_response.ErrorResponse.Error.Message.get('$')), 'get_fba_inventories_ext')
			else:
				try:
					inventory_supply_list = fba_inventories_response.ListInventorySupplyResponse.ListInventorySupplyResult.InventorySupplyList.member
					if inventory_supply_list and not isinstance(inventory_supply_list, list):
						inventory_supply_list = [inventory_supply_list]
				except Exception:
					self.log('Cannot get fba inventories - SKUs: {}'.format(', '.join(product_skus)), 'get_fba_inventories_ext')
			for inventory_supply in inventory_supply_list:
				product_sku = inventory_supply.SellerSKU.get('$')
				extends[product_sku].fba_inventory = inventory_supply
		return Response().success(data = extends)


	def _convert_product_export(self, product, products_ext: Prodict):
		product_extend = products_ext.get(product['seller-sku'], {})
		asin_extend = product_extend.get('asin_ext')
		fba_inventory_extend = product_extend.get('fba_inventory')

		product_data = Product()
		product_data.name = product['item-name']
		product_data.description = product['item-description']
		product_data.id = product['seller-sku']
		product_data.sku = product['seller-sku']
		product_data.price = to_decimal(product['price'])
		product_data.qty = to_int(product['quantity'])
		product_data.is_in_stock = True if to_int(product['quantity']) > 0 else False
		product_data.created_at = convert_format_time(product['open-date'].replace('PDT', '').strip())
		product_data.type = 'simple'
		product_data.status = True if product['status'] == 'Active' else False
		product_data.condition = self.MWS_CONDITIONS_MAPPING.get(product['item-condition'], 'new')
		product_data.asin = product['asin1'] or product['asin2'] or product['asin3']
		product_data.upc = product['product-id']
		product_data.ean = product['product-id']
		if asin_extend:
			product_data.manufacturer.name = asin_extend.Manufacturer.get('$') if asin_extend.Manufacturer else ''
			if asin_extend.ItemDimensions:
				dimensions = asin_extend.ItemDimensions
				product_data.height = to_decimal(dimensions.Height.get('$') if dimensions.Height else 0)
				product_data.length = to_decimal(dimensions.Length.get('$') if dimensions.Length else 0)
				product_data.width = to_decimal(dimensions.Width.get('$') if dimensions.Width else 0)
				product_data.weight = to_decimal(dimensions.Weight.get('$') if dimensions.Weight else 0)
			product_data.code = asin_extend.Model.get('$') if asin_extend.Model else ''
			product_data.thumb_image.url = asin_extend.SmallImage.URL.get('$').replace('._SL75_', '') if asin_extend.SmallImage else ''
			if not product_data.name:
				product_data.name = asin_extend.Title.get('$') if asin_extend.Title else ''
		offer_template_data = Prodict.from_dict(self.offer_template)
		offer_template_data['condition'][product_data.condition] = self.MWS_CONDITIONS.get(int(product['item-condition']), "New")
		offer_template_data.fulfillment = 'fbm' if product['fulfillment-channel'] == 'DEFAULT' else 'fba'
		product_data.template_data['offer'] = offer_template_data
		if self._state.channel.config.api.get('fulfillment') == 'fba' and fba_inventory_extend:
			fba_inventory = ProductInventory()
			fba_inventory.location_id = self.get_warehouse_location_fba()
			fba_inventory.available = fba_inventory_extend.TotalSupplyQuantity.get('$')
			fba_inventory.on_hand = fba_inventory_extend.InStockSupplyQuantity.get('$')
			fba_inventory.reserved = fba_inventory.available - fba_inventory.on_hand
			product_data.fba_inventory = fba_inventory
		return Response().success(data = product_data)


	def product_import(self, convert: Product, product, products_ext):
		self.cache_products.append(product)
		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		self._update_product = True
		self.cache_products.append(product)
		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		self._update_product = True
		if self._state.channel.config.setting.get('price', {}).get('status') == 'disable':
			self._update_price = False
		if self._state.channel.config.setting.get('qty', {}).get('status') == 'disable':
			self._update_qty = False
		self.cache_products.append(product)
		return Response().success()


	def addition_product_import(self):
		if self.cache_products:
			# Update operation type will override all data and PartialUpdate just override only specific fields
			operation_type = 'Update' if not self._update_product else 'PartialUpdate'
			currency = self.MWS_CURRENCY.get(self.get_marketplace_id_api(), 'USD')
			# Re-create new cache errors and warnings for each import round.
			self.cache_errors = {product.id: [] for product in self.cache_products}
			self.cache_warnings = {product.id: [] for product in self.cache_products}
			# Import product
			feed_content = self.get_default_feed_content('Product')
			for index, product in enumerate(self.cache_products, 1):
				# Prepare before import - get necessary template data
				offer_template = product.template_data.offer or Prodict().from_dict(self.offer_template)
				price_template = product.template_data.price or Prodict()
				# Get asin code
				asin = product['asin']
				if not asin and self._state.config.test:
					queries = [getattr(product, field) for field in ['ean', 'upc', 'barcode', 'name'] if getattr(product, field)]
					for query in queries:
						asin_res = self.api(
							session = 'Products',
							action = 'ListMatchingProducts',
							extra_data = {
								'MarketplaceId': self.get_marketplace_id_api(),
								'Query': query
							}
						)
						if asin_res and \
								asin_res.ListMatchingProductsResponse and \
								asin_res.ListMatchingProductsResponse.ListMatchingProductsResult.Products.Product:
							asin_data = asin_res.ListMatchingProductsResponse.ListMatchingProductsResult.Products.Product
							if isinstance(asin_data, list):
								asin_data = asin_data[0]
							asin = asin_data.Identifiers.MarketplaceASIN.ASIN.get('$')
							break
				if not asin:
					self.cache_errors[product.id].append(f'Import product_id {product.id} errors: Cannot get ASIN code')
					continue
				sku = product.sku
				if not sku:
					self.cache_errors[product.id].append(f'Import product_id {product.id} errors: SKU is required')
					continue

				# Assign product post data
				product_data = dict()
				product_data['SKU'] = sku
				product_data['StandardProductID'] = {
					'Type': 'ASIN',
					'Value': asin,
				}
				title = product.name
				description = product.description
				manufacturer = product.manufacturer.name
				# Get and convert condition - get extra field from template
				tax_code = offer_template.tax_code
				condition = offer_template['condition'].get(product.condition, 'New')
				condition_note = offer_template['condition']['note']['override'] or product.get(offer_template['condition']['note']['mapping'], '')
				gift_wrap = 'true' if offer_template.gift_wrap == 'enable' else 'false'
				gift_message = 'true' if offer_template.gift_message == 'enable' else 'false'
				max_order_qty = offer_template.max_order_qty
				msrp = price_template.msrp

				product_data['Condition'] = {'ConditionType': condition}
				if condition_note:
					product_data['Condition']['ConditionNote'] = condition_note
				product_data['DescriptionData'] = dict()
				if title:
					product_data['DescriptionData']['Title'] = strip_html_tag(title)[:500]
				if description:
					product_data['DescriptionData']['Description'] = description[:2000]
				if manufacturer:
					product_data['DescriptionData']['Manufacturer'] = manufacturer[:100]
				if msrp:
					msrp_value = msrp.get('override') or product.get(msrp.get('mapping')) or 0
					product_data['DescriptionData']['MSRP'] = {
						'@currency': currency,
						'$': msrp_value,
					}
				if max_order_qty is not None and max_order_qty > 0:
					product_data['DescriptionData']['MaxOrderQuantity'] = gift_message
				if tax_code:
					product_data['ProductTaxCode'] = tax_code
				# Update product
				if not self._update_product or offer_template.gift_wrap is not None:
					product_data['DescriptionData']['IsGiftWrapAvailable'] = gift_wrap
				if not self._update_product or offer_template.gift_message is not None:
					product_data['DescriptionData']['IsGiftMessageAvailable'] = gift_message
				# Imported product cannot update condition
				if self._update_product:
					del product_data['Condition']['ConditionType']
					if not product_data['Condition']:
						del product_data['Condition']
				message = {
					'MessageID': index,
					'OperationType': operation_type,
					'Product': product_data,
				}
				feed_content['AmazonEnvelope']['Message'].append(message)
			# POST products and check response
			if feed_content['AmazonEnvelope']['Message']:
				xml = self.parse_dict_to_xml(feed_content)
				md5_hash = self.hash_md5_feed_content(xml)
				response = self.api(
					session = 'Feeds',
					action = 'SubmitFeed',
					extra_data = {'FeedType': '_POST_PRODUCT_DATA_', 'MarketplaceIdList.Id.1': self.get_marketplace_id_api()},
					method = 'POST',
					body = xml,
					extra_headers = {'Content-MD5': md5_hash, 'Content-Type': 'text/xml'}
				)
				response = self.check_submit_feed_response(response)
				if response.result != 'success':
					return response
				submission_id = response.data
				self.check_submit_feed_result(submission_id, 'Product')

			# Insert map product
			for product in self.cache_products:
				if not self.cache_errors[product.id]:
					self.insert_map_product(product, product['_id'], product.sku)

			# Import products price
			price_submission_id = None
			if not self._update_product or self._update_price:
				feed_content = self.get_default_feed_content('Price')
				for index, product in enumerate(self.cache_products, 1):
					if self.cache_errors[product.id]:
						continue
					offer_template = product.template_data.offer or Prodict().from_dict(self.offer_template)
					price_template = product.template_data.price or Prodict()
					sku = product.sku
					price = product.price
					special_price = product.special_price
					map_price = price_template.map
					price_data = {
						'SKU': sku,
						'StandardPrice': {
							'@currency': currency,
							'$': price,
						}
					}
					start_time = min(to_timestamp(special_price.start_date), to_timestamp(special_price.start_date, '%Y-%m-%d'))
					end_time = max(to_timestamp(special_price.end_date), to_timestamp(special_price.end_date, '%Y-%m-%d'))
					if special_price and special_price.price > 0 and start_time < time.time() < end_time:
						price_data['Sale'] = {
							'SalePrice': {
								'@currency': currency,
								'$': special_price.price,
							},
							'StartDate': convert_format_time(special_price.start_date, '%Y-%m-%d'),
							'EndDate': convert_format_time(special_price.end_date, '%Y-%m-%d'),
						}
					if map_price:
						map_price_value = map_price.get('override') or product.get(map_price.get('mapping')) or 0
						price_data['MAP'] = {
							'@currency': currency,
							'$': map_price_value
						}
					message = {
						'MessageID': index,
						'OperationType': operation_type,
						'Price': price_data,
					}
					feed_content['AmazonEnvelope']['Message'].append(message)
				if feed_content['AmazonEnvelope']['Message']:
					xml = self.parse_dict_to_xml(feed_content)
					md5_hash = self.hash_md5_feed_content(xml)
					response = self.api(
						session = 'Feeds',
						action = 'SubmitFeed',
						extra_data = {'FeedType': '_POST_PRODUCT_PRICING_DATA_', 'MarketplaceIdList.Id.1': self.get_marketplace_id_api()},
						method = 'POST',
						body = xml,
						extra_headers = {'Content-MD5': md5_hash, 'Content-Type': 'text/xml'}
					)
					response = self.check_submit_feed_response(response)
					price_submission_id = response.data

			# Import Feed type: Inventory
			inventory_submission_id = None
			if not self._update_product or self._update_qty:
				feed_content = self.get_default_feed_content('Inventory')
				for index, product in enumerate(self.cache_products, 1):
					if self.cache_errors[product.id]:
						continue
					offer_template = product.template_data.offer or Prodict().from_dict(self.offer_template)
					price_template = product.template_data.price or Prodict()
					sku = product.sku
					qty = product.qty
					fulfillment = offer_template.fulfillment
					handling_time = offer_template.handling_time
					marketplace_id = self.get_marketplace_id_api()
					fulfillment_center_id = self.FULFILLMENT_CENTER.get(marketplace_id, 'AMAZON_NA')
					if fulfillment == 'fbm':
						inventory_data = {
							'SKU': sku,
							'FulfillmentCenterID': 'DEFAULT',
							'Quantity': int(qty),
						}
						if handling_time:
							inventory_data['FulfillmentLatency'] = handling_time
					else:
						inventory_data = {
							'SKU': sku,
							'FulfillmentCenterID': fulfillment_center_id,
							'Lookup': 'FulfillmentNetwork',
							'SwitchFulfillmentTo': 'FAN',
						}
					message = {
						'MessageID': index,
						'OperationType': operation_type,
						'Inventory': inventory_data,
					}
					feed_content['AmazonEnvelope']['Message'].append(message)
				if feed_content['AmazonEnvelope']['Message']:
					xml = self.parse_dict_to_xml(feed_content)
					md5_hash = self.hash_md5_feed_content(xml)
					response = self.api(
						session = 'Feeds',
						action = 'SubmitFeed',
						extra_data = {'FeedType': '_POST_INVENTORY_AVAILABILITY_DATA_', 'MarketplaceIdList.Id.1': self.get_marketplace_id_api()},
						method = 'POST',
						body = xml,
						extra_headers = {'Content-MD5': md5_hash, 'Content-Type': 'text/xml'}
					)
					response = self.check_submit_feed_response(response)
					inventory_submission_id = response.data

			if price_submission_id:
				self.check_submit_feed_result(price_submission_id, 'Price')
			if inventory_submission_id:
				self.check_submit_feed_result(inventory_submission_id, 'Inventory')

			# Reset cache_products for next import round.
			for product in self.cache_products:
				self.log(f'Import product id: {product.id}', 'products')
				if self.cache_errors[product.id]:
					error = self.cache_errors[product.id][0]
					self.after_push_product(product['_id'], Response().error(msg = error), product)
				else:
					self.after_push_product(product['_id'], Response().success(), product)
				for error in self.cache_errors[product.id]:
					self.log(f'Error product_id {product.id}: {error}', 'products')
				for warning in self.cache_warnings[product.id]:
					self.log(f'Warning {product.id}: {warning}', 'products')
			self._state.push.process.products.error += len([1 for errors in self.cache_errors.values() if errors])
			self.cache_products = []
		return Response().success()


	def after_push_product(self, product_id, import_data, product: Product):
		update_field = dict()
		product_channel_data = product['channel'][f'channel_{self._state.channel.id}']
		if import_data.result in (Response.ERROR, Response.WARNING):
			publish_status = ProductChannel.ERRORS
			msg = import_data.msg or Errors().get_msg_error(import_data.code)
			if not product_channel_data.get('product_id'):
				update_field[f"channel.channel_{self._state.channel.id}.status"] = ProductChannel.ERRORS
		else:
			msg = ''
			publish_status = ProductChannel.COMPLETED
			update_field[f"channel.channel_{self._state.channel.id}.product_id"] = product.sku
			update_field[f"channel.channel_{self._state.channel.id}.product_sku"] = product.sku
		update_field[f"channel.channel_{self._state.channel.id}.publish_status"] = publish_status
		update_field[f"channel.channel_{self._state.channel.id}.error_message"] = msg

		product.channel[f"channel_{self._state.channel.id}"] = self.get_product_channel_data(product, '')
		product.channel[f"channel_{self._state.channel.id}"]['publish_status'] = publish_status
		product.channel[f"channel_{self._state.channel.id}"]['error_message'] = msg
		self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)


	# Export Orders

	def get_order_id_import(self, convert: Order, order, orders_ext):
		purchase_timestamp = min(to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%SZ'), to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ'))
		return to_str(order.AmazonOrderId.get('$')) + '-' + to_str(purchase_timestamp)


	def get_orders_main_export(self):
		limit_data = self._state.pull.setting.orders
		id_src = self._state.pull.process.orders.id_src
		query = 'SELECT * FROM `{}` WHERE `order_id` > "{}" ORDER BY `order_id` LIMIT {}'.format(self._order_table_name, id_src, limit_data)
		orders = self.get_model_local().select_raw(query)
		if orders.result != Response.SUCCESS or not orders.data:
			return Response().finish()
		orders = list(filter(None, [json_decode(row['order_data']) for row in orders.data]))
		if not orders:
			return Response().finish()
		return Response().success(data = orders)


	def get_orders_ext_export(self, orders):
		extends = list()
		for order in orders:
			order_id = order.AmazonOrderId.get('$')
			order_ext_data = Prodict()
			order_ext_data['AmazonOrderId'] = order_id
			order_ext_data['items'] = list()
			response = self.api('Orders', 'ListOrderItems', extra_data = {'AmazonOrderId': order_id})
			if response.ErrorResponse:
				self.log(f'Order Id: {order_id}' + to_str(response.ErrorResponse.Error.Message.get('$')), 'get_exts_order_errors')
				continue
			if isinstance(response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem, dict):
				response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem = [response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem]
			order_ext_data['items'].extend(response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem)
			next_token = None
			if response.ListOrderItemsResponse.ListOrderItemsResult.NextToken:
				next_token = response.ListOrderItemsResponse.ListOrderItemsResult.NextToken.get('$')
			while next_token:
				response = self.api('Orders', 'ListOrderItemsByNextToken', extra_data = {'NextToken': next_token})
				if response.ErrorResponse:
					self.log(f'Order Id: {order_id}' + to_str(response.ErrorResponse.Error.Message.get('$')), 'get_exts_order_errors')
					continue
				if isinstance(response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem, dict):
					response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem = [response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem]
				order_ext_data['items'].extend(response.ListOrderItemsResponse.ListOrderItemsResult.OrderItems.OrderItem)
				next_token = None
				if response.ListOrderItemsResponse.ListOrderItemsResult.NextToken:
					next_token = response.ListOrderItemsResponse.ListOrderItemsResult.NextToken.get('$')
			extends.append(order_ext_data)
		return Response().success(data = extends)


	def convert_order_export(self, order, orders_ext):
		order_id = to_str(order.AmazonOrderId.get('$'))
		order_ext = get_row_from_list_by_field(orders_ext, 'AmazonOrderId', order_id)
		order_data = Order()
		purchase_timestamp = min(to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%SZ'), to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ'))
		order_data.id = order_id + '-' + to_str(purchase_timestamp)
		order_data.order_number = order_id
		status = order.OrderStatus.get('$') if order.OrderStatus else None
		order_data.status = self.ORDER_STATUS.get(status, Order.OPEN)
		# Payment & shipped
		if order_data.status != Order.CANCELED:
			order_data.payment.status = True
		order_data.payment.method = order.PaymentMethod.get('$') if order.PaymentMethod else ''
		if order_data.status in [order.SHIPPING, order.COMPLETED]:
			order_data.shipping.status = True
		order_data.shipping.method = order.ShipmentServiceLevelCategory.get('$') if order.ShipmentServiceLevelCategory else ''
		order_data.created_at = convert_format_time(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ')
		order_data.updated_at = convert_format_time(order.LastUpdateDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ')
		order_data.total = to_decimal(order.OrderTotal.get('$')) if order.OrderTotal else 0.0
		order_data.customer.email = order.BuyerEmail.get('$') if order.BuyerEmail else ''
		order_data.customer.last_name = order.BuyerName.get('$') if order.BuyerName else ''
		order_data.channel_data = {
			'order_status': to_str(status),
			'created_at': order_data.created_at
		}
		if order.ShippingAddress:
			order_data.shipping_address.last_name = order.ShippingAddress.Name.get('$') if order.ShippingAddress.Name else ''
			order_data.shipping_address.address_1 = order.ShippingAddress.AddressLine1.get('$') if order.ShippingAddress.AddressLine1 else ''
			order_data.shipping_address.city = order.ShippingAddress.City.get('$') if order.ShippingAddress.City else ''
			order_data.shipping_address.state.state_code = order.ShippingAddress.StateOrRegion.get('$') if order.ShippingAddress.StateOrRegion else ''
			order_data.shipping_address.state.state_name = order_data.customer_address.state.state_code
			order_data.shipping_address.postcode = order.ShippingAddress.PostalCode.get('$') if order.ShippingAddress.PostalCode else ''
			order_data.shipping_address.country.country_code = order.ShippingAddress.CountryCode.get('$') if order.ShippingAddress.CountryCode else ''
			order_data.shipping_address.country.country_name = order_data.customer_address.country.country_code
			order_data.customer_address = order_data.shipping_address
		if order.TaxClassifications:
			order_data.tax.title = order.TaxClassifications.TaxClassification.get('$')
			order_data.tax.amount = order.TaxClassifications.value.get('$')
		if order_ext:
			shipping_price = 0.0
			subtotal = 0.0
			for item in order_ext['items']:
				item = Prodict(**item)
				product_data = OrderProducts()
				# product_data.asin = item.ASIN.get('$')
				product_data.product_id = item.SellerSKU.get('$')
				product_data.product_sku = item.SellerSKU.get('$')
				product_data.product_name = item.Title.get('$')
				# product_data.condition = item.ConditionId.get('$') if item.ConditionId else 'New'
				product_data.qty = to_int(item.QuantityOrdered.get('$')) if item.QuantityOrdered else 0
				product_data.price = to_decimal(item.ItemPrice.Amount.get('$')) if item.ItemPrice else 0
				product_data.subtotal = product_data.qty * product_data.price
				product_data.total = product_data.subtotal
				subtotal += product_data.subtotal
				shipping_price += item.ShippingPrice.Amount.get('$') if item.ShippingPrice else 0
				shipping_price += item.CODFee.Amount.get('$') if item.CODFee else 0
				shipping_price -= item.CODFeeDiscount.Amount.get('$') if item.CODFeeDiscount else 0
				shipping_price += item.GiftWrapPrice.Amount.get('$') if item.GiftWrapPrice else 0
				order_data.products.append(product_data)
			order_data.subtotal = subtotal
			order_data.shipping.amount = shipping_price
		return Response().success(data = order_data)
