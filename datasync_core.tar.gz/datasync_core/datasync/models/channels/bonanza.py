

import requests

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.bonanza import *
from datasync.models.constructs.order import *
from datasync.models.constructs.product import *

class ModelChannelsBonanza(ModelChannel):
    TIME_FORMAT = '%Y-%m-%dT%H:%M:%S'

    def convert_order_status(self, status):
        ORDER_STATUS = {
            'Cancelled': Order.CANCELED,
            'Completed': Order.SHIPPING,
            'Incomplete': Order.AWAITING_PAYMENT,
            'InProcess': Order.AWAITING_PAYMENT,
            'Invoiced': Order.AWAITING_PAYMENT,
            'Proposed': Order.AWAITING_PAYMENT,
            'Shipped': Order.COMPLETED,
        }
        return ORDER_STATUS.get(status, 'Open') if status else 'Open'

    def __init__(self):
        super().__init__()
        self._last_product_response = None
        self._last_images = None
        self._flag_finish_product = False
        self._flag_finish_order = False
        self._product_next_link = False
        self._order_next_link = False
        self._order_max_last_modified = False
        self._total_product = 0
        self._current_page = 1
        self._total_product_pages = 0
        self._total_order = 0
        self._current_page_order = 1
        self._total_order_pages = 0
        self._api_path = "https://api.bonanza.com/api_requests"
    def get_token(self):
        token = {
                "bonanzleAuthToken": f"{self._state.channel.config.api.api_token}"
        }
        return token
    def get_api_info(self):
        return {
            'shop': 'Shop name',
            'api_dev_name': "API DEVELOPER ID",
            'api_cert_name': "API CERTIFICATE ID",
            'api_token': "API Access Token"
        }

    def requests(self, url, action, data_detail=None, headers=None, method='post', retry=0):
        action_end = ["reviseFixedPriceItem", "updateBooth", "addFixedPriceItem", "endFixedPriceItem"]
        def log_request_error(_res):
            error = {
                'method': method,
                'status': _res.status_code,
                'data': to_str(data),
                'header': to_str(_res.headers),
                'response': _res.text,
            }
            self.log_request_error(url, **error)

        method = to_str(method).lower()
        if not headers:
            headers = dict()
            headers['User-Agent'] = get_random_useragent()
        elif isinstance(headers, dict) and not headers.get('User-Agent'):
            headers['User-Agent'] = get_random_useragent()
        headers['X-BONANZLE-API-DEV-NAME'] = self._state.channel.config.api.api_dev_name
        headers['X-BONANZLE-API-CERT-NAME'] = self._state.channel.config.api.api_cert_name
        headers['Content-Type'] = 'application/json; charset=utf-8'
        response = False
        request_options = {
            'headers': headers,
            'verify': True
        }
        if action not in action_end:
            action = f"{action}Request"
        data = {
            f"{action}": {
                "requesterCredentials": self.get_token(),
            }
        }
        if data_detail:
            for i in data_detail.items():
                data[f"{action}"][f"{i[0]}"] = i[1]
        if method == 'get' and data:
            request_options['params'] = data
        if method in ['post', 'put'] and data:
            request_options['json'] = data
        request_options = self.combine_request_options(request_options)
        response_data = False
        try:
            index = 0
            response = requests.request(method, url, **request_options)
            if response.status_code > 204:
                log_request_error(response)
            while response.status_code == 429 and retry <= 5:
                retry += 1
                time_reset = 1
                self.log(f"sleep {max(time_reset, 1)}s", 'sleep')
                time.sleep(max(time_reset, 1))
                return self.requests(url, action, data_detail, headers, method, retry)
            self._last_header = response.headers
            self._last_status = response.status_code
            response_data = response.text
            response_data_decode = json_decode(response_data)
            if not response_data_decode and method != 'delete':
                log_request_error(response)
                return response_data_decode
            if response_data_decode:
                try:
                    response_prodict = Prodict(**response_data_decode)
                except Exception:
                    response_prodict = response_data_decode
                response_data = response_prodict
        except requests.exceptions.SSLError as e:
            if retry < 5:
                retry += 1
                time.sleep(retry * 2)
                return self.requests(url, action, data_detail, headers, method, retry)
        except Exception as e:
            self.log_traceback()
            log_request_error(response)

        return response_data

    def api(self, action="",  data=None, api_type="post"):
        # api_dev_name = self._state.channel.config.api.api_dev_name
        # api_cert_name = self._state.channel.config.api.api_cert_name
        api_path = self._api_path
        lookup_endpoint = ["findItemsByKeywords", "getBooth", "getBoothItems", "getCategories",
                           "getCategoryTraits", "getCheckoutLink", "getSingleItem",
                           "getMultipleItems", "getUserProfile"]
        path = "standard_request" if action in lookup_endpoint else "secure_request"
        url = api_path.rstrip('/') + '/' + path.strip().lstrip('/')
        res = self.requests(url, action, data, method=api_type)
        retry = 0
        while (res is False) or ('expected Array to be a Hash' in to_str(res)) or (
                "Exceeded 2 calls per second for api client. Reduce request rates to resume uninterrupted service" in to_str(
            res)) or self._last_status >= 500:
            retry += 1
            time.sleep(2)
            res = self.requests(url, action, data, method=api_type)
            if retry > 5:
                break

        return res

    def display_setup_channel(self, data=None):
        parent = super().display_setup_channel(data)
        if parent.result != Response().SUCCESS:
            return parent
        url = self._channel_url
        bonanza_code = re.findall("https://www.bonanza.com/booths/(.*)", url)
        self._state.channel.config.api.shop = bonanza_code[0]
        store = self._state.channel.config.api.shop
        data = {
                "boothId": f"{store}"
        }
        shop = self.api("getBooth", data)
        if not shop:
            return Response().error(Errors.BONANZA_API_INVALID)
        try:
            if shop.errors:
                return Response().error(Errors.BONANZA_API_INVALID)

        except Exception as e:
            return Response().error(Errors.BONANZA_API_INVALID)

        # self._state.channel.clear_process.function = "clear_channel_taxes"
        return Response().success()

    def set_channel_identifier(self):
        parent = super().set_channel_identifier()
        if parent.result != Response().SUCCESS:
            return parent
        self.set_identifier(self._state.channel.config.api.shop)
        return Response().success()

    def after_create_channel(self, data):
        if is_local():
            return Response().success()
        return Response().success()

    def get_max_last_modified_product(self):
        if self._state.pull.process.products.last_modified:
            if to_str(self._state.pull.process.products.last_modified).isnumeric():
                return convert_format_time(self._state.pull.process.products.last_modified,
                                           new_format="%Y-%m-%dT%H:%M:%S+07:00")
            return self._state.pull.process.products.last_modified
        return False

    def create_webhook_product(self):
        pass

    def display_pull_channel(self):
        parent = super().display_pull_channel()
        if parent.result != Response().SUCCESS:
            return parent

        if self.is_product_process():
            self._state.pull.process.products.error = 0
            self._state.pull.process.products.imported = 0
            self._state.pull.process.products.new_entity = 0
            self._state.pull.process.products.total = 0
            if not self._state.pull.process.products.id_src:
                self._state.pull.process.products.id_src = 0

            if not self.is_refresh_process():
                self._state.pull.process.products.total_view = 0
            store = self._state.channel.config.api.shop
            data = {
                    "boothId": f"{store}"
            }
            if self.is_refresh_process():
                self._state.pull.process.products.id_src = 0
                last_modified = self.get_max_last_modified_product()
            else:
                if not self.is_import_inactive():
                    data['itemStatus'] = 'for_sale'

            products_api = self.api("getBoothItems", data)
            if products_api and products_api.getBoothItemsResponse.totalEntries:
                total_items = products_api.getBoothItemsResponse.totalEntries
                self._total_product = total_items
                self._total_product_pages = math.ceil(total_items / 500)

                if self.is_refresh_process():
                    self._state.pull.process.products.total = -1
                    self._state.pull.process.products.total_view = total_items
                else:
                    self._state.pull.process.products.total = total_items
                    self._state.pull.process.products.total_view = total_items

        if self.is_order_process():
            self._state.pull.process.orders.total = 0
            self._state.pull.process.orders.imported = 0
            self._state.pull.process.orders.new_entity = 0
            self._state.pull.process.orders.error = 0
            self._state.pull.process.orders.id_src = 0
            start_time = self.get_order_start_time('iso')
            last_modifier = self._state.pull.process.orders.max_last_modified
            data = {
                "createTimeFrom": start_time
            }
            if last_modifier:
                data["createTimeFrom"] = last_modifier
            orders_api = self.api("getOrders", data)
            if orders_api and orders_api.getOrdersResponse.paginationResult.totalNumberOfEntries:
                self._total_order = orders_api.getOrdersResponse.paginationResult.totalNumberOfEntries
                self._total_order_pages = math.ceil(self._total_order / 100)
                self._state.pull.process.orders.total = orders_api.getOrdersResponse.paginationResult.totalNumberOfEntries
        return Response().success()

    def clear_channel_taxes(self):
        next_clear = Prodict.from_dict({
            'result': 'process',
            'function': 'clear_channel_categories'
        })
        self._state.channel.clear_process = next_clear
        return next_clear

    def clear_channel_products(self):
        next_clear = Prodict.from_dict({
            'result': 'success',
            'function': '',
        })
        self._state.channel.clear_process = next_clear
        if not self._state.config.products:
            return next_clear
        try:
            data = {
                    "boothId": f"{self._state.channel.config.api.shop}",
                    "itemsPerPage": 500,
                    "itemStatus": "for_sale"
            }
            all_products = self.api("getBoothItems", data)
            while all_products:
                if not all_products:
                    return next_clear
                if not all_products.items:
                    return next_clear
                for product in all_products.getBoothItemsResponse.items:
                    id_product = product.itemID
                    _data = {
                            "itemID": f"{id_product}"
                    }
                    res = self.api("endFixedPriceItem", _data)
                all_products = self.api("getBoothItems", data)
                time.sleep(0.1)
        except Exception:
            self.log_traceback()
            return next_clear
        return next_clear

    def get_product_by_id(self, product_id):
        data = {
                "itemID": to_str(product_id)
        }
        product = self.api("getSingleItem", data)
        if self._last_status == 404:
            return Response().create_response(result=Response.DELETED)
        if not product or not product.getSingleItemResponse.get('item'):
            return Response().error(msg="Get product by ID fail")
        product_data = product.getSingleItemResponse.item
        return Response().success(product_data)

    def get_product_by_updated_at(self):
        if self._flag_finish_product:
            return Response().finish()
        else:
            limit_data = self._state.pull.setting.products
            data = {
                    "boothId": f"{self._state.channel.config.api.shop}",
                    "itemsPerPage": 500,
                    "page": self._current_page
            }
            if not self.is_import_inactive():
                data['itemStatus'] = 'for_sale'
            products = self.api("getBoothItems", data)
        self._current_page = products.getBoothItemsResponse.currentPage
        self._flag_finish_product = self.process_products_is_finish()
        self._current_page += 1
        if not products or not products.getBoothItemsResponse.items:
            if self._last_status != 200:
                return Response().error(Errors.BONANZA_GET_PRODUCT_FAIL)
            return Response().finish()
        return Response().success(data=products.getBoothItemsResponse.get("items"))

    def process_products_is_finish(self) -> bool:
        if self._current_page == -1:
            return True
        return False if self._current_page < self._total_product_pages else True

    def get_products_main_export(self):
        if self._flag_finish_product:
            return Response().finish()
        else:
            limit_data = self._state.pull.setting.products
            data = {
                    "boothId": f"{self._state.channel.config.api.shop}",
                    "itemsPerPage": 500,
                    "page": self._current_page
            }
            if not self.is_import_inactive():
                data['itemStatus'] = 'for_sale'
            products = self.api("getBoothItems", data)
        self._current_page = products.getBoothItemsResponse.currentPage
        self._flag_finish_product = self.process_products_is_finish()
        self._current_page += 1
        if not products or not products.getBoothItemsResponse.items:
            if self._last_status != 200:
                return Response().error(Errors.BONANZA_GET_PRODUCT_FAIL)
            return Response().finish()
        return Response().success(data=products.getBoothItemsResponse.get("items"))

    def get_products_ext_export(self, products):
        extend = Prodict()
        for product in products:
            product_id = to_str(product.itemID)
            extend.set_attribute(product_id, Prodict())
        return Response().success(extend)

    def get_product_id_import(self, convert: Product, product, products_ext):
        return product.itemID

    def updated_at_to_timestamp(self, updated_at, time_format='%Y-%m-%d %H:%M:%S'):
        return to_timestamp(''.join(updated_at.rsplit(':', 1)), '%Y-%m-%dT%H:%M:%S%z', limit_len=False)

    def _convert_product_export(self, product, products_ext: Prodict):
        product_id = to_str(product.itemID)
        product_data = Product()
        channel_id = to_str(self._state.channel.id)
        product_data.sku = product.sku
        product_data.price = product.currentPrice if product.currentPrice else product.buyItNowPrice
        product_data.status = True if product.listingStatus == "Active" else False
        product_data.manage_stock = True if product.quantity > 0 else False
        if product_data.manage_stock:
            product_data.is_in_stock = True if to_int(product.quantity) > 0 else False
        else:
            product_data.is_in_stock = True
        if product.startTime:
            product_data.created_at = convert_format_time(''.join(product.startTime.rsplit(':', 1)),
                                                          '%Y-%m-%dT%H:%M:%S%z')
        product_data.updated_at = convert_format_time(''.join(product.lastChangeTime.rsplit(':', 1)),
                                                      '%Y-%m-%dT%H:%M:%S%z')
        product_data.name = product.title
        product_data.description = to_str(product.description)
        if product.productListingDetails:
            product_data.upc = product.productListingDetails[1]
        if product.galleryURL:
            product_data.thumb_image.url = product.galleryURL
        product_data.weight_units = "lbs"
        if product.pictureURL:
            for index, value in enumerate(product.pictureURL):
                if index != 0:
                    product_image_data = ProductImage()
                    product_image_data.url = value
                    # product_image_data.label = image.alt
                    product_image_data.position = index
                    product_data.images.append(product_image_data)
        if product.itemSpecifics:
            for item in product.itemSpecifics:
                if item.nameValueList.name == "Brand":
                    product_data.brand = item.nameValueList.value
        product_data.seo_url = product.viewItemURL
        if product.variations:
            if product.variations.variation:
                qty = 0
                is_in_stock = False
                manage_stock = False
                for variant in product.variations.variation:
                    qty += to_int(variant.quantity)

                    if variant.quantity:
                        variant_is_in_stock = True if to_int(variant.quantity) > 0 else False
                    else:
                        variant_is_in_stock = True
                    if variant_is_in_stock:
                        is_in_stock = True
                    variant_manage_stock = True if variant.quantity > 0 else False
                    if variant_manage_stock:
                        manage_stock = True
                    variant_data = ProductVariant()
                    variant_data.upc = variant.upc
                    variant_title = ''
                    if variant.nameValueList:
                        for val_list in variant.nameValueList:
                            variant_title += " " + val_list.value + " /"
                    variant_data.name = product.title + " -" + variant_title.rstrip('/')
                    variant_data.sku = variant.sku
                    variant_data.price = variant.price
                    if variant.pictureURL:
                        variant_data.thumb_image.url = variant.pictureURL
                        variant_data.thumb_image.position = product.pictureURL.index(variant.pictureURL)
                    variant_data.qty = to_int(variant.quantity)
                    variant_data.manage_stock = variant_manage_stock
                    variant_data.is_in_stock = variant_is_in_stock
                    variant_sku = to_str(variant.sku)
                    index = 0
                    if variant.nameValueList:
                        for variant_val in variant.nameValueList:
                            variant_attribute = ProductVariantAttribute()
                            variant_attribute.id = "{}_{}".format(product_id, index)
                            # variant_attribute.attribute_type = 'select'
                            variant_attribute.attribute_name = variant_val.name
                            variant_attribute.attribute_value_name = variant_val.value
                            variant_sku = variant_sku.replace(variant_attribute.attribute_value_name, '')
                            variant_data.attributes.append(variant_attribute)
                            index += 1
                    if not variant_data.attributes:
                        continue
                    if not product_data.sku:
                        variant_sku = variant_sku.strip(' -_')
                        if to_str(variant.sku).startswith(variant_sku):
                            product_data.sku = variant_sku
                        else:
                            product_data.sku = variant.sku
                    variant_data.seo_url = f"{product_data.seo_url}?variant={variant.id}"
                    product_data.variants.append(variant_data)
                product_data.qty = qty
                product_data.is_in_stock = is_in_stock
                product_data.manage_stock = manage_stock
        if not product.variations:
            if product.quantity:
                product_data.qty = product.quantity
        if not product_data.sku:
            product_data.sku = product.id
        template_data1 = {}
        if product.primaryCategory:
            category_template = BonanzaCategoryTemplate()
            category_template.primary_category.category_id = product.primaryCategory.categoryId
            category_template.primary_category.category_name = product.primaryCategory.categoryName
            if product.itemSpecifics:
                for item in product.itemSpecifics:
                    if isinstance(item.nameValueList.value, list):
                        for _item in item.nameValueList.value:
                            cate_specific = BonanzaCategorySpecifics()
                            cate_specific.name = item.nameValueList.name
                            cate_specific.value = _item
                            category_template.specifics.append(cate_specific)
                    else:
                        cate_specific = BonanzaCategorySpecifics()
                        cate_specific.name = item.nameValueList.name
                        cate_specific.value = item.nameValueList.value
                        category_template.specifics.append(cate_specific)
            template_data1['category'] = category_template
        if product.shippingCostSummary:
            shipping_template = BonanzaShippingTemplate()
            if product.shipToLocations:
                shipping_template.global_shipping = "enable"
                inter_ship = InternationalShipping()
                for location in product.shipToLocations:
                    if location.shippingType == "Flat" and location.region != "United States":
                        inter_flat_ship = InternationalFlatShipment()
                        inter_flat_ship.ship_to_location = location.region
                        inter_flat_ship.shipment_type = "Fixed"
                        inter_flat_ship.shipping_service_cost = location.shippingServiceCost
                        inter_ship.flat_options_attributes.append(inter_flat_ship)
                    elif location.shippingType == "Calculated" and location.region != "United States":
                        inter_cal_ship = InternationalCalculatedShipment()
                        inter_cal_ship.shipment_type = location.shippingType
                        inter_cal_ship.ship_to_location = location.region
                        inter_ship.calculated_options_attributes.append(inter_cal_ship)
                    elif location.shippingType == "Free" and location.region != "United States":
                        inter_free_ship = InternationalFreeShipment()
                        inter_free_ship.shipment_type = location.shippingType
                        inter_free_ship.ship_to_location = location.region
                        inter_ship.free_options_attributes.append(inter_free_ship)
                    elif location.shippingType == "SeeDescription" and location.region != "United States":
                        inter_description_ship = InternationalDescriptiomShipment()
                        inter_description_ship.ship_to_location = location.region
                        inter_description_ship.shipment_type = location.shippingType
                        inter_ship.description_options_attributes.append(inter_description_ship)
                shipping_template.international_shipping = inter_ship
            if product.shippingCostSummary.insuranceType or product.shippingCostSummary.insuranceCost:
                shipping_template.insurance_cost = product.shippingCostSummary.insuranceCost
                if product.shippingCostSummary.insuranceType == "Included":
                    shipping_template.insurance_type = "IncludedInShippingHandling"
                else:
                    shipping_template.insurance_type = product.shippingCostSummary.insuranceType
            else:
                shipping_template.insurance_type = "IncludedInShippingHandling"
            if product.shippingCostSummary.shippingServices:
                domestic_ship = DomesticShipping()
                for service in product.shippingCostSummary.shippingServices:
                    if service.shippingType == "Flat":
                        domestic_ship.shipment_type = "Fixed"
                        domestic_flat_ship = DomesticFlatShipment()
                        domestic_flat_ship.shipping_service_cost = service.shippingServiceCost
                        domestic_ship.flat_options_attributes.append(domestic_flat_ship)
                        domestic_ship.major = 0
                        domestic_ship.minor = 0
                        domestic_ship.height = 0
                        domestic_ship.width = 0
                        domestic_ship.depth = 0
                    elif service.shippingType == "Calculated":
                        domestic_calculated_ship = DomesticCalculatedShipment()
                        domestic_ship.shipment_type = "Calculated"
                        domestic_calculated_ship.shipping_carrier = service.carrier
                        domestic_ship.calculated_options_attributes.append(domestic_calculated_ship)
                        if product.shippingCostSummary.packageSize == "Manually-entered size":
                            domestic_ship.shipping_package = "Unspecified"
                            domestic_ship.major = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                            domestic_ship.minor = product.shippingCostSummary.shippingOz if product.shippingCostSummary.shippingOz else 0
                            domestic_ship.height = product.shippingCostSummary.dimension1 if product.shippingCostSummary.dimension1 else 0
                            domestic_ship.width = product.shippingCostSummary.dimension2 if product.shippingCostSummary.dimension2 else 0
                            domestic_ship.depth = product.shippingCostSummary.dimension3 if product.shippingCostSummary.dimension3 else 0
                            product_data.weight = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                            product_data.height = product.shippingCostSummary.dimension1 if product.shippingCostSummary.dimension1 else 0
                            product_data.length = product.shippingCostSummary.dimension2 if product.shippingCostSummary.dimension2 else 0
                            product_data.width = product.shippingCostSummary.dimension3 if product.shippingCostSummary.dimension3 else 0
                        else:
                            domestic_ship.shipping_package = product.shippingCostSummary.packageSize
                            domestic_ship.major = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                            domestic_ship.minor = product.shippingCostSummary.shippingOz if product.shippingCostSummary.shippingOz else 0
                            product_data.weight = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                shipping_template.domestic_shipping = domestic_ship
            else:
                domestic_ship = DomesticShipping()
                if product.shippingCostSummary.shippingType == "Calculated":
                    domestic_calculated_ship = DomesticCalculatedShipment()
                    domestic_ship.shipment_type = "Calculated"
                    domestic_calculated_ship.shipping_carrier = product.shippingCostSummary.carrier
                    domestic_ship.calculated_options_attributes.append(domestic_calculated_ship)
                    if product.shippingCostSummary.packageSize == "Manually-entered size":
                        domestic_ship.shipping_package = "Unspecified"
                        domestic_ship.major = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                        domestic_ship.minor = product.shippingCostSummary.shippingOz if product.shippingCostSummary.shippingOz else 0
                        domestic_ship.height = product.shippingCostSummary.dimension1 if product.shippingCostSummary.dimension1 else 0
                        domestic_ship.width = product.shippingCostSummary.dimension2 if product.shippingCostSummary.dimension2 else 0
                        domestic_ship.depth = product.shippingCostSummary.dimension3 if product.shippingCostSummary.dimension3 else 0
                        product_data.weight = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                        product_data.height = product.shippingCostSummary.dimension1 if product.shippingCostSummary.dimension1 else 0
                        product_data.length = product.shippingCostSummary.dimension2 if product.shippingCostSummary.dimension2 else 0
                        product_data.width = product.shippingCostSummary.dimension3 if product.shippingCostSummary.dimension3 else 0
                    else:
                        domestic_ship.shipping_package = product.shippingCostSummary.packageSize
                        domestic_ship.major = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                        domestic_ship.minor = product.shippingCostSummary.shippingOz if product.shippingCostSummary.shippingOz else 0
                        product_data.weight = product.shippingCostSummary.shippingLbs if product.shippingCostSummary.shippingLbs else 0
                    shipping_template.domestic_shipping = domestic_ship
            template_data1['shipping'] = shipping_template

        if product.returnPolicy:
            product_return_policy_temp = BonanzaReturnPolicy()
            product_return_policy_temp.description = product.returnPolicy.description
            product_return_policy_temp.returns_accepted = product.returnPolicy.returnsAccepted
            product_return_policy_temp.within = product.returnPolicy.returnsWithin
            product_return_policy_temp.paid_by = product.returnPolicy.shippingCostPaidBy
            template_data1["policy"] = product_return_policy_temp

        product_data.template_data = template_data1
        channel_data = {
            'listing_type': "Active",
            'bonanza_status': "Active"
        }
        product_data.channel_data = channel_data
        return Response().success(product_data)

    def channel_assign_category_template(self, product, template_data) -> Product:
        """func choose mapping and override data from the category template"""

        item_specifics = template_data.get('specifics')
        if not item_specifics:
            return product
        for specific in item_specifics:
            status_changed = False
            if not specific.override and not specific.mapping:
                continue
            if specific.override:
                value = specific.override
            # if specific.override == '[]' and specific.mapping:  # hotfix
            # 	value = specific.mapping
            else:
                status_changed = True
                value = specific.mapping
            specific.value = self.assign_attribute_to_field(value, product)

        product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['specifics'] = item_specifics

        return product

    @staticmethod
    def convert_weight_to_kg(weight, unit):
        weight_unit_to_lbs = {
            "kg": 2.204623,
            "kgs": 2.204623,
            "g": 0.002204623
        }
        if unit.lower() in ["", "lbs", "lb"]:
            result = weight
        else:
            result = weight * to_decimal(weight_unit_to_lbs[unit.lower()])
        return to_str(to_decimal(result, 2))

    @staticmethod
    def convert_dimensions_to_inches(dimension, unit):
        if unit.lower() == "cm":
            result = dimension * 0.393700787
        elif unit.lower() == "m":
            result = dimension * 39.3700787
        else:
            result = dimension
        return to_int(result)
    def channel_assign_shipping_template(self, product, template_data) -> Product:

        template_data = template_data.get("shipping")
        domestic_shipping = template_data["domestic_shipping"]
        if not domestic_shipping.get("major_map") and not domestic_shipping.get("height_map") and not domestic_shipping.get("width_map") \
                and not domestic_shipping.get("depth_map"):
            return product
        if domestic_shipping.get("major_map"):
            value_major = domestic_shipping["major_map"]
            status_changed, domestic_shipping["major"] = self.assign_attribute_to_field(value_major, product)
            domestic_shipping["major"] = self.convert_weight_to_kg(domestic_shipping["major"], product["weight_units"])
        if domestic_shipping.get("height_map"):
            value_height = domestic_shipping["height_map"]
            status_changed, domestic_shipping["height"] = self.assign_attribute_to_field(value_height, product)
            domestic_shipping["height"] = self.convert_dimensions_to_inches(domestic_shipping["height"], product["dimension_units"])
        if domestic_shipping.get("width_map"):
            value_width = domestic_shipping["width_map"]
            status_changed, domestic_shipping["width"] = self.assign_attribute_to_field(value_width, product)
            domestic_shipping["width"] = self.convert_dimensions_to_inches(domestic_shipping["width"], product["dimension_units"])
        if domestic_shipping.get("depth_map"):
            value_depth = domestic_shipping["depth_map"]
            status_changed, domestic_shipping["depth"] = self.assign_attribute_to_field(value_depth, product)
            domestic_shipping["depth"] = self.convert_dimensions_to_inches(domestic_shipping["depth"], product["dimension_units"])
        product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping'][
            'domestic_shipping'] = domestic_shipping

        return product
    def product_import(self, convert: Product, product, products_ext):
        shipping_template = product.get('template_data', {}).get('shipping')
        category_template = product.get('template_data', {}).get('category')
        if not shipping_template or not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing shipping template(required). Please add a template for the bonanza channel')
        if not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing category template(required). Please add a template for the bonanza channel')
        convert_product = self.product_to_bonanza_data(product, products_ext, product.id)
        if convert_product.result != Response().SUCCESS:
            return convert_product
        post_data, list_image_data = convert_product.data
        response = self.api("addFixedPriceItem", post_data)
        check_response = self.check_response_import(response, product, 'product')
        if check_response.result != Response().SUCCESS:
            return check_response

        product_id = response.addFixedPriceItemResponse.itemId
        if len(list_image_data) > 1:
            for list_img in list_image_data[1:len(list_image_data)]:
                data_img = {
                    'discardOld': False,
                    'pictureURL': list_img
                }
                post_data = {
                    "itemID": to_int(product_id),
                    "item": {
                        "pictureDetails": data_img,
                    }
                }
                update_img = self.api("reviseFixedPriceItem", post_data)
                check_response_update = self.check_response_import(update_img, product, 'product')
                if check_response_update.result != Response().SUCCESS:
                    return check_response_update
        return Response().success(product_id)

    def product_to_bonanza_data(self, product: Product, product_ext, product_id, action="addFixedPriceItem"):
        if not product.name:
            return Response().error(Errors.PRODUCT_DATA_INVALID)
        post_data = {
            "item": {
                "title": product.name,
                "description": to_str(product.description),
                "price": product.price,
                "sku": product.sku,
                "quantity": product.qty
            }
        }
        list_image = list()
        if action == "addFixedPriceItem" and product.thumb_image.url:
            total_img = len(product.images) + 1
            page_img = math.ceil(total_img / 4)
            start = 3
            stop = 7
            for page in range(0, page_img):
                list_img = []
                if page == 0:
                    list_img.append(product.thumb_image.url)
                    for img in product.images[0:3]:
                        list_img.append(img.url)
                else:
                    if stop >= total_img:
                        stop = total_img - 1
                    for img in product.images[start:stop]:
                        list_img.append(img.url)
                    start = stop
                    stop += 4
                list_image.append(list_img)
            image_data = {
                'discardOld': True
            }
            if list_image:
                image_data["pictureURL"] = list_image[0]
            post_data["item"]["pictureDetails"] = image_data
        # bonanza_images.append(image_data)
        # Initiate Post data


        if action == "reviseFixedPriceItem":
            post_data["itemID"] = to_int(product_id)
        return Response().success((post_data, list_image))

    def check_response_import(self, response, convert, entity_type=''):
        id = convert.id if convert.id else convert.code
        if not response:
            return Response().error(msg="Import failed")
        elif response and hasattr(response, 'errorMessage') and response.ack == "Failure":
            console = list()
            if isinstance(response.errorMessage, list):
                for error in response.errorMessage:
                    if isinstance(error, list):
                        error_messages = ' '.join(error)
                    else:
                        error_messages = error
                    console.append(error_messages)
            if isinstance(response.errorMessage, dict) or isinstance(response.errorMessage, Prodict):
                for key, error in response['errorMessage'].items():
                    if isinstance(error, list):
                        error_messages = ' '.join(error)
                    else:
                        error_messages = error
                    console.append(key + ': ' + error_messages)
            else:
                console.append(response['errorMessage']['errors'])
            msg_errors = '::'.join(console)
            self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
                     "{}_errors".format(entity_type))
            return Response().error(msg=msg_errors)
        else:
            return Response().success()

    def after_product_import(self, product_id, convert: Product, product, products_ext):
        convert_product = self.product_to_bonanza_data(product, products_ext, product_id, "reviseFixedPriceItem")
        if convert_product.result != Response().SUCCESS:
            return convert_product
        product_data, images = convert_product.data
        shipping_template = product.get('template_data', {}).get('shipping')
        category_template = product.get('template_data', {}).get('category')
        if not shipping_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing shipping template(required). Please add a template for the bonanza channel')
        if not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing category template(required). Please add a template for the bonanza channel')
        update = self.api("reviseFixedPriceItem", product_data)
        update_res = self.check_response_import(update, product, "update_product")
        if update_res.result != Response().SUCCESS:
            return update_res
        post_data = {
            "itemID": to_int(product_id),
            "item": {},
            "discardOldVariations": False
        }
        shipping_template = product.get('template_data', {}).get('shipping')
        if product.get('template_data', {}).get('policy'):
            product_return_policy_temp = product.get('template_data', {}).get('policy')
            if product_return_policy_temp:
                poli_post_data = {
                    "description": product_return_policy_temp.description,
                    "returnsAcceptedOption": product_return_policy_temp.returns_accepted,
                    "returnsWithinOption": product_return_policy_temp.within,
                    "shippingCostPaidByOption": product_return_policy_temp.paid_by
                }
                post_data["item"]["returnPolicy"] = poli_post_data
        category_template = product.get('template_data', {}).get('category')
        if not shipping_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing shipping template(required). Please add a template for the bonanza channel')
        if not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing category template(required). Please add a template for the bonanza channel')
        if category_template and category_template.get('primary_category'):
            cate_post_data = {
                "categoryId": category_template.primary_category.category_id
            }
            post_data["item"]["primaryCategory"] = cate_post_data
            if category_template.custom_category:
                post_data["item"]["customCategoryId"] = category_template.custom_category.category_id
            if category_template.get('specifics'):
                item_spe = []
                for obj_ in category_template.get("specifics"):
                    if obj_.override != "":
                        if isinstance(obj_.override, dict):
                            item_sp = []
                            item_sp.append(obj_.name)
                            item_sp.append(obj_.override.get("name"))
                            item_spe.append(item_sp)
                        elif isinstance(obj_.override, list):
                            for _obj in obj_.override:
                                item_sp = []
                                item_sp.append(obj_.name)
                                item_sp.append(_obj.name)
                                item_spe.append(item_sp)
                        else:
                            item_sp = []
                            item_sp.append(obj_.name)
                            item_sp.append(obj_.override)
                            item_spe.append(item_sp)
                    else:
                        item_sp = []
                        item_sp.append(obj_.name)
                        item_sp.append(obj_.value)
                        item_spe.append(item_sp)
                cate_spe_post_data = {
                    "specifics": item_spe
                }
                post_data["item"]["itemSpecifics"] = cate_spe_post_data
        if shipping_template:
            ship_post_data = {}
            if shipping_template.insurance_type:
                insuranceDetails = {
                    "insuranceOption": shipping_template.insurance_type,
                }
                if shipping_template.insurance_cost:
                    insuranceDetails["insuranceFee"] = shipping_template.insurance_cost
                ship_post_data["insuranceDetails"] = insuranceDetails
                post_data["item"]["insuranceDetails"] = insuranceDetails
            if shipping_template.domestic_shipping:
                if shipping_template.domestic_shipping.shipment_type == "Fixed":
                    flat_ships = []
                    for ship in shipping_template.domestic_shipping.flat_options_attributes:
                        flat_ship = {
                            "shippingServiceCost": ship.shipping_service_cost,
                            "freeShipping": True if ship.free_shipping == 1 else False,
                            "shippingType": shipping_template.domestic_shipping.shipment_type

                        }
                        flat_ships.append(flat_ship)
                    ship_post_data["shippingServiceOptions"] = flat_ships

                if shipping_template.domestic_shipping.shipment_type == "Calculated":
                    cacul_ships = []
                    for ship in shipping_template.domestic_shipping.calculated_options_attributes:
                        cacul_ship = {
                            "shippingCarrier": ship.shipping_carrier,
                            "buyerPaysForLabel": True if ship.free_shipping == 1 else False,
                            "shippingType": shipping_template.domestic_shipping.shipment_type
                        }
                        cacul_ships.append(cacul_ship)

                    cacul_ship_rate = {
                        "packageSize": shipping_template.domestic_shipping.shipping_package,
                        "shippingWeightLbs": shipping_template.domestic_shipping.major if shipping_template.domestic_shipping.major else 0,
                        "shippingWeightOz": shipping_template.domestic_shipping.minor if shipping_template.domestic_shipping.minor else 0
                    }
                    if shipping_template.domestic_shipping.shipping_package == "Unspecified":
                        cacul_ship_rate["packageSize"] = "unspecified"
                        cacul_ship_rate["shippingHeight"] = shipping_template.domestic_shipping.height
                        cacul_ship_rate["shippingWidth"] = shipping_template.domestic_shipping.width
                        cacul_ship_rate["shippingDepth"] = shipping_template.domestic_shipping.depth
                    ship_post_data["calculatedShippingRate"] = cacul_ship_rate
                    ship_post_data["shippingServiceOptions"] = cacul_ships

            if shipping_template.global_shipping == "enable":
                if shipping_template.international_shipping:
                    inter_ship = []
                    if shipping_template.international_shipping.get("calculated_options_attributes"):
                        for obj in shipping_template.international_shipping.calculated_options_attributes:
                            cacul_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location
                            }
                            if obj.shipping_carrier in ["UPS", "USPS", "FedEx"]:
                                cacul_inter_ship["shippingCarrier"] = obj.shipping_carrier
                            inter_ship.append(cacul_inter_ship)
                    if shipping_template.international_shipping.get("flat_options_attributes"):
                        for obj in shipping_template.international_shipping.flat_options_attributes:
                            flat_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location,
                                "shippingServiceCost": obj.shipping_service_cost
                            }
                            inter_ship.append(flat_inter_ship)
                    if shipping_template.international_shipping.get("free_options_attributes"):
                        for obj in shipping_template.international_shipping.free_options_attributes:
                            free_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location
                            }
                            inter_ship.append(free_inter_ship)
                    if shipping_template.international_shipping.get("description_options_attributes"):
                        for obj in shipping_template.international_shipping.description_options_attributes:
                            des_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location
                            }
                            inter_ship.append(des_inter_ship)
                    ship_post_data["internationalShippingServiceOption"] = inter_ship
            post_data["item"]["shippingDetails"] = ship_post_data
        response_template = self.api("reviseFixedPriceItem", post_data)
        check_response_temp = self.check_response_import(response_template, product, 'add_temp_product')
        if check_response_temp.result != Response().SUCCESS:
            return check_response_temp
        if product.variants:
            variants_post_data = []
            for variant in product.variants:
                variant_post_data = self.variant_to_bonanza_data(variant, product)
                variant_id = self.variant_key_generate(variant)
                self.insert_map_product(variant, variant['_id'], f"{response_template.reviseFixedPriceItemResponse.ItemID}-{variant_id}")
                variants_post_data.append(variant_post_data)
            post_variant_data = {
                    'itemID': to_int(product_id),
                    'item': {
                        'variations': variants_post_data
                    },
                    "discardOldVariations": True
            }
            var_response = self.api("reviseFixedPriceItem", post_variant_data)
            check_response = self.check_response_import(var_response, product, 'add_variants_product')
            if check_response.result != Response().SUCCESS:
                return check_response
            update_booth = self.update_booth()
            if update_booth.result != Response.SUCCESS:
                return update_booth
        else:
            update_booth = self.update_booth()
            if update_booth.result != Response.SUCCESS:
                return update_booth
            return Response().success()
        return Response().success()

    def check_for_sale(self, product, product_id, post_data):
        checking = False
        retry = 0
        time_sleep = 5
        while not checking and retry <= 8:
            checking_sale = self.api("getSingleItem", data={"itemID": to_str(product_id)})
            check_response = self.check_response_import(checking_sale, product, 'update for sale')
            if check_response.result == Response().SUCCESS:
                checking = True
            else:
                time.sleep(time_sleep)
                response_template = self.api("reviseFixedPriceItem", post_data)
                check_response_temp = self.check_response_import(response_template, product, 'add_temp_product')
                if check_response_temp.result != Response().SUCCESS:
                    return check_response_temp
                self.update_booth()
            retry += 1
            time_sleep = time_sleep * 2
        if checking:
            return Response().success()
        else:
            return Response().error(msg="Product cannot set for sale, maybe your booth is being approved by bonanza, "
                                        "please wait for 3days if you just registered a booth on bonanza ")

    def variant_to_bonanza_data(self, variant: ProductVariant, parent: Product):
        val_list = []
        for attribute in variant.attributes:
            if attribute.use_variant:
                val = {}
                val['name'] = to_str(attribute.attribute_name).replace('/', '-')
                val['value'] = attribute.attribute_value_name
                val_list.append(val)
            else:
                if not attribute.attribute_name:
                    continue
        variant_post_data = {
            'price': variant.price,
            'sku': variant.sku,
            'quantity': to_int(variant.qty),
            'nameValueList': val_list
        }
        if variant.barcode or variant.upc or variant.ean:
            variant_post_data['upc'] = variant.barcode or variant.upc or variant.ean
        if variant.thumb_image.url:
            image_index = variant.thumb_image.position if variant.thumb_image.position else False
            if image_index:
                variant_post_data["imageIndex"] = to_int(image_index)

        return variant_post_data

    def update_booth(self):
        update_booth = self.api("updateBooth")
        if update_booth.ack != "Success" and "BoothNotActivated" in update_booth.errorMessage.message:
            return Response().error(msg="Booth Not Activated")
        return Response().success()

    def product_channel_update(self, product_id, product: Product, products_ext):
        if product.qty == 0:
            return Response().error(msg="Quantity cannot be 0")
        convert_product = self.product_to_bonanza_data(product, products_ext, product_id, "reviseFixedPriceItem")
        if convert_product.result != Response().SUCCESS:
            return convert_product
        product_data, images = convert_product.data
        shipping_template = product.get('template_data', {}).get('shipping')
        category_template = product.get('template_data', {}).get('category')
        if not shipping_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing shipping template(required). Please add a template for the bonanza channel')
        if not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing category template(required). Please add a template for the bonanza channel')
        update = self.api("reviseFixedPriceItem", product_data)
        update_res = self.check_response_import(update, product, "update_product")
        if update_res.result != Response().SUCCESS:
            return update_res
        post_data = {
            "itemID": product_id,
            "item": {},
            "discardOldVariations": True
        }
        shipping_template = product.get('template_data', {}).get('shipping')
        if product.get('template_data', {}).get('policy'):
            product_return_policy_temp = product.get('template_data', {}).get('policy')
            if product_return_policy_temp:
                poli_post_data = {
                    "description": product_return_policy_temp.description,
                    "returnsAcceptedOption": product_return_policy_temp.returns_accepted,
                    "returnsWithinOption": product_return_policy_temp.within,
                    "shippingCostPaidByOption": product_return_policy_temp.paid_by
                }
                post_data["item"]["returnPolicy"] = poli_post_data
        category_template = product.get('template_data', {}).get('category')
        if not shipping_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing shipping template(required). Please add a template for the bonanza channel')
        if not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing category template(required). Please add a template for the bonanza channel')
        if category_template and category_template.get('primary_category'):
            cate_post_data = {
                "categoryId": category_template.primary_category.category_id
            }
            post_data["item"]["primaryCategory"] = cate_post_data
            if category_template.custom_category:
                post_data["item"]["customCategoryId"] = category_template.custom_category.category_id
            if category_template.get('specifics'):
                item_spe = []
                for obj_ in category_template.get("specifics"):
                    if obj_.override != "":
                        if isinstance(obj_.override, dict):
                            item_sp = []
                            item_sp.append(obj_.name)
                            item_sp.append(obj_.override.get("name"))
                            item_spe.append(item_sp)
                        elif isinstance(obj_.override, list):
                            for _obj in obj_.override:
                                item_sp = []
                                item_sp.append(obj_.name)
                                item_sp.append(_obj.name)
                                item_spe.append(item_sp)
                        else:
                            item_sp = []
                            item_sp.append(obj_.name)
                            item_sp.append(obj_.override)
                            item_spe.append(item_sp)
                    else:
                        item_sp = []
                        item_sp.append(obj_.name)
                        item_sp.append(obj_.value)
                        item_spe.append(item_sp)
                cate_spe_post_data = {
                    "specifics": item_spe
                }
                post_data["item"]["itemSpecifics"] = cate_spe_post_data
        if shipping_template:
            ship_post_data = {}
            if shipping_template.insurance_type:
                insuranceDetails = {
                    "insuranceOption": shipping_template.insurance_type,
                }
                if shipping_template.insurance_cost:
                    insuranceDetails["insuranceFee"] = shipping_template.insurance_cost
                ship_post_data["insuranceDetails"] = insuranceDetails
                post_data["item"]["insuranceDetails"] = insuranceDetails
            if shipping_template.domestic_shipping:
                if shipping_template.domestic_shipping.shipment_type == "Fixed":
                    flat_ships = []
                    for ship in shipping_template.domestic_shipping.flat_options_attributes:
                        flat_ship = {
                            "shippingServiceCost": ship.shipping_service_cost,
                            "freeShipping": True if ship.free_shipping == 1 else False,
                            "shippingType": shipping_template.domestic_shipping.shipment_type

                        }
                        flat_ships.append(flat_ship)
                    ship_post_data["shippingServiceOptions"] = flat_ships

                if shipping_template.domestic_shipping.shipment_type == "Calculated":
                    cacul_ships = []
                    for ship in shipping_template.domestic_shipping.calculated_options_attributes:
                        cacul_ship = {
                            "shippingCarrier": ship.shipping_carrier,
                            "buyerPaysForLabel": True if ship.free_shipping == 1 else False,
                            "shippingType": shipping_template.domestic_shipping.shipment_type
                        }
                        cacul_ships.append(cacul_ship)

                    cacul_ship_rate = {
                        "packageSize": shipping_template.domestic_shipping.shipping_package,
                        "shippingWeightLbs": shipping_template.domestic_shipping.major if shipping_template.domestic_shipping.major else 0,
                        "shippingWeightOz": shipping_template.domestic_shipping.minor if shipping_template.domestic_shipping.minor else 0
                    }
                    if shipping_template.domestic_shipping.shipping_package == "Unspecified":
                        cacul_ship_rate["packageSize"] = "unspecified"
                        cacul_ship_rate["shippingHeight"] = shipping_template.domestic_shipping.height
                        cacul_ship_rate["shippingWidth"] = shipping_template.domestic_shipping.width
                        cacul_ship_rate["shippingDepth"] = shipping_template.domestic_shipping.depth
                    ship_post_data["calculatedShippingRate"] = cacul_ship_rate
                    ship_post_data["shippingServiceOptions"] = cacul_ships

            if shipping_template.global_shipping == "enable":
                if shipping_template.international_shipping:
                    inter_ship = []
                    if shipping_template.international_shipping.get("calculated_options_attributes"):
                        for obj in shipping_template.international_shipping.calculated_options_attributes:
                            cacul_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location
                            }
                            if obj.shipping_carrier in ["UPS", "USPS", "FedEx"]:
                                cacul_inter_ship["shippingCarrier"] = obj.shipping_carrier
                            inter_ship.append(cacul_inter_ship)
                    if shipping_template.international_shipping.get("flat_options_attributes"):
                        for obj in shipping_template.international_shipping.flat_options_attributes:
                            flat_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location,
                                "shippingServiceCost": obj.shipping_service_cost
                            }
                            inter_ship.append(flat_inter_ship)
                    if shipping_template.international_shipping.get("free_options_attributes"):
                        for obj in shipping_template.international_shipping.free_options_attributes:
                            free_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location
                            }
                            inter_ship.append(free_inter_ship)
                    if shipping_template.international_shipping.get("description_options_attributes"):
                        for obj in shipping_template.international_shipping.description_options_attributes:
                            des_inter_ship = {
                                "shippingType": obj.shipment_type,
                                "shipToLocation": obj.ship_to_location
                            }
                            inter_ship.append(des_inter_ship)
                    ship_post_data["internationalShippingServiceOption"] = inter_ship
            post_data["item"]["shippingDetails"] = ship_post_data
        response_template = self.api("reviseFixedPriceItem", post_data)
        check_response_temp = self.check_response_import(response_template, product, 'add_temp_product')
        if check_response_temp.result != Response().SUCCESS:
            return check_response_temp
        if product.variants:
            variants_post_data = []
            for variant in product.variants:
                variant_post_data = self.variant_to_bonanza_data(variant, product)
                variant_id = f'{product_id}-{self.variant_key_generate(variant)}'
                if not variant['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
                    self.insert_map_product(variant, variant['_id'], variant_id)
                else:
                    self.update_map_product(variant, variant['_id'], variant_id)
                variants_post_data.append(variant_post_data)
            post_data = {
                    'itemID': product_id,
                    'item': {
                        'variations': variants_post_data
                    },
                    "discardOldVariations": True
            }
            var_response = self.api("reviseFixedPriceItem", post_data)
            check_response = self.check_response_import(var_response, product, 'add_var_product')
            if check_response.result != Response().SUCCESS:
                return check_response
        update_booth = self.update_booth()
        if update_booth.result != Response.SUCCESS:
            return update_booth
        checking = self.check_for_sale(product, product_id, post_data)
        if checking.result != Response.SUCCESS:
            return checking
        # self.channel_sync_inventory(product_id, product, products_ext)
        return Response().success()

    def channel_sync_inventory(self, product_id, product, products_ext):
        setting_price = True if self._state.channel.config.setting.get('price', {}).get(
            'status') != 'disable' else False
        setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False

        if not setting_price and not setting_qty:
            return Response().success()

        product_data = {
            "item": {},
            'ItemID': to_int(product_id)
        }

        channel_data = product.channel.get(f'channel_{self.get_channel_id()}', {})
        product_qty = product.qty
        if product.variants:
            product_qty = 0
            for variant in product.variants:
                product_qty += to_int(variant.qty)
        if setting_price:
            product_data['item']['price'] = product.price
        if setting_qty:
            if to_int(product_qty) == 0:
                data = {
                    "itemID": to_int(product_id),
                }
                remove = self.api("endFixedPriceItem", data)
                self.get_model_catalog().update_field(product['_id'],
                                                      f'channel.channel_{self.get_channel_id()}.bonanza_status',
                                                      'ended')
                return Response().success()
            else:
                bonanza_status = product.channel[f'channel_{self.get_channel_id()}'].get('bonanza_status')
                if bonanza_status == 'ended':
                    relist_data = {
                        "item": {
                            "quantity": product.qty
                        },
                        'ItemID': to_int(product_id),
                        "discardOldVariations": False
                    }
                    relist_response = self.api("reviseFixedPriceItem", relist_data)
                    if relist_response.ack != "Success":
                        self.get_model_catalog().update_field(product['_id'],
                                                              f'channel.channel_{self.get_channel_id()}.bonanza_status',
                                                              'ended')
                        return Response().success()
                    self.get_model_catalog().update_field(product['_id'],
                                                          f'channel.channel_{self.get_channel_id()}.bonanza_status',
                                                          'active')
                    return Response().success()
            product_data['item']['quantity'] = product.qty
        if not product.variants:
            update_data = {
                "item": {
                    "price": product.price,
                    "quantity": product.qty
                },
                'ItemID': to_int(product_id)
            }

            if not self.is_setting_sync_qty():
                del update_data['item']['quantity']
            if not self.is_setting_sync_price():
                del update_data['item']['price']
            response = self.api("reviseFixedPriceItem", update_data)
            check_response = self.check_response_import(response, product, "sync_product")
            if check_response.result != Response().SUCCESS:
                return check_response
            update_booth = self.update_booth()
            if update_booth.result != Response.SUCCESS:
                return update_booth
        if product.variants:
            variants_post_data = []
            for variant in product.variants:
                variant = self.variant_to_bonanza_data(variant, product)
                variants_post_data.append(variant)
            post_data = {
                    'itemID': to_int(product_id),
                    'item': {
                        'variations': variants_post_data
                    },
                    "discardOldVariations": True
            }
            var_response = self.api("reviseFixedPriceItem", post_data)
            check_response = self.check_response_import(var_response, product, 'sync_product')
            if check_response.result != Response().SUCCESS:
                return check_response
            update_booth = self.update_booth()
            if update_booth.result != Response.SUCCESS:
                return update_booth
        return Response().success()

    def get_order_by_id(self, order_id):
        data = {
                "orderIDArray": order_id
        }
        order = self.api("getOrders", data)
        if not order or not order.get('getOrdersResponse'):
            return Response().error(msg="Get order by id fail!")
        return Response().success(order['getOrdersResponse'])

    def process_orders_is_finish(self) -> bool:
        if self._current_page_order == -1:
            return True
        return False if self._current_page_order < self._total_order_pages else True
    def get_orders_main_export(self):
        if self._flag_finish_order:
            return Response().finish()
        else:
            start_time = self.get_order_start_time('iso')
            last_modifier = self._state.pull.process.orders.max_last_modified
            order_data = {
                "createTimeFrom": start_time,
                "paginationInput": {
                    "entriesPerPage": 100,
                    "pageNumber": self._current_page_order,
                }
            }
            if last_modifier:
                order_data["modTimeFrom"] = last_modifier
            orders = self.api("getOrders", order_data)
        if not orders or not orders.getOrdersResponse:
            if self._last_status != 200:
                return Response().error(msg="Get orders bonanza fail!")
            return Response().finish()
        self._current_page_order = orders.getOrdersResponse.pageNumber
        self._flag_finish_order = self.process_orders_is_finish()
        self._current_page_order += 1
        order_arr = orders.getOrdersResponse.orderArray
        return Response().success(data=order_arr)

    def get_orders_ext_export(self, orders):
        return Response().success()

    def order_sync_inventory(self, order: Order, setting_order):
        return Response().success()

    def set_order_max_last_modifier(self, last_modifier):
        if last_modifier:
            if not self._order_max_last_modified:
                self._order_max_last_modified = last_modifier
                return
            date_obj = to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S")
            max_midified_obj = to_timestamp(self._order_max_last_modified, "%Y-%m-%dT%H:%M:%S")
            if date_obj > max_midified_obj:
                self._order_max_last_modified = last_modifier

    def convert_order_export(self, order, orders_ext, channel_id=None):
        order = order.order
        order_create = to_timestamp(order.createdTime, "%Y-%m-%dT%H:%M:%S")
        start_time = to_timestamp(self.get_order_start_time('iso'), '%Y-%m-%dT%H:%M:%S')
        # start_time = to_timestamp("2023-05-01T07:10:15Z", '%Y-%m-%dT%H:%M:%S')
        self.set_order_max_last_modifier(order.createdTime)
        if order_create < start_time:
            return Response().skip()
        order_data = Order()
        order_data.id = order.orderID
        order_data.order_number = order.orderID
        order_data.subtotal = to_int(order.subtotal)
        order_data.total = to_int(order.total)
        # if order.totalFeeBasisAmount:
        #     order_data.total = order.totalFeeBasisAmount.value
        order_data.currency = order.currencyCode
        order_data.created_at = convert_format_time(order.createdTime, self.TIME_FORMAT)
        # order_data.updated_at = convert_format_time(order.lastModifiedDate, self.TIME_FORMAT)
        order_data.channel_data = {
            'created_at': order_data.created_at,
            'order_number': order.orderId,
        }
        order_status = ""
        if order.orderStatus == 'Active':
            return Response().skip()
        elif order.orderStatus == 'Completed':
            order_status = self.convert_order_status('Completed')
        elif order.orderStatus == 'InProcess':
            order_status = self.convert_order_status('InProcess')
        elif order.orderStatus == 'Incomplete':
            order_status = self.convert_order_status('Incomplete')
        elif order.orderStatus == 'Shipped':
            order_status = self.convert_order_status('Shipped')
            order_data.shipments.shipped_at = convert_format_time(order.shippedTime, self.TIME_FORMAT)
        elif order.orderStatus == 'Cancelled':
            order_status = self.convert_order_status('Cancelled')
        elif order.orderStatus == 'Invoiced':
            order_status = self.convert_order_status('Invoiced')
        elif order.orderStatus == 'Proposed':
            order_status = self.convert_order_status('Proposed')
        else:
            return Response().skip()
        order_data.status = order_status

        order_data.channel_data.order_status = order_status
        # discount
        order_data.discount.amount = to_decimal(order.amountSaved) if order.amountSaved else None
        if order["shippingAddress"]:
            address = OrderAddress()
            first_name, last_name = self.split_customer_fullname(order["shippingAddress"]["name"])
            order_data.customer.first_name = first_name
            order_data.customer.last_name = last_name
            order_data.customer.id = order.buyerUserID
            order_data.customer.username = order.buyerUserName
            address.first_name = first_name
            address.last_name = last_name
            address.address_1 = order["shippingAddress"]["street1"]
            address.address_2 = order["shippingAddress"]["street2"] if order["shippingAddress"]["street2"] else None
            address.city = order["shippingAddress"]["cityName"]
            address.state.state_code = order["shippingAddress"]["stateOrProvince"]
            address.country.country_code = order["shippingAddress"]["country"]
            address.country.country_name = order["shippingAddress"]["countryName"]
            address.telephone = order.telephoneNumber if order.telephoneNumber else None
            address.postcode = order["shippingAddress"]["postalCode"]
            order_data.shipping_address.update(address)
            order_data.billing_address.update(address)
            order_data.customer_address.update(address)

        order_data.imported_at = get_current_time()
        tax_amount = 0
        if order.taxAmount:
            tax_amount = order.taxAmount
        if order["transactionArray"] and order["transactionArray"]["transaction"]["buyer"]["email"] != "Unavailable":
            order_data.customer.email = order["transactionArray"]["transaction"]["buyer"]["email"]
        else:
            order_data.customer.email = f"{order_data.customer.first_name}@api.bonanza.com" if order_data.customer.first_name else "api@bonanza.com"

        if order.itemArray:
            for item in order.itemArray:
                item = item.item
                order_item = OrderProducts()
                order_item.id = item.itemID
                order_item.product_id = item.itemID
                order_item.listing_id = item.product_id
                order_item.product_name = item.title
                order_item.product_sku = item.sku
                # order_item.sku = item.sku
                order_item.qty = item.quantity
                order_item.price = item.price
                index = 0
                if item.variations:
                    variant_attribute_value = list()
                    all_attributes = []
                    for var in item.variations.variation:
                        if var.nameValueList:
                            for variant_val in var.nameValueList:
                                variant_attribute = ProductVariantAttribute()
                                variant_attribute.id = "{}_{}".format(item.itemID, index)
                                # variant_attribute.attribute_type = 'select'
                                variant_attribute.attribute_name = variant_val
                                variant_attribute.attribute_value_name = variant_val.value
                                variant_sku = variant_sku.replace(variant_attribute.attribute_value_name, '')
                                variant_attribute_value.append(variant_attribute)
                                all_attributes.append(variant_val.name)
                                index += 1
                                continue
                        if var.sku:
                            order_item.product_sku = var.sku

                    if variant_attribute_value:
                        for attribute in variant_attribute_value:
                            option_data = OrderItemOption()
                            option_data.option_name = attribute.attribute_name
                            option_data.option_value_name = attribute.attribute_value_name
                            order_item.options.append(option_data)
                        variant_id = f"{item.ItemId}-{self.variant_key_generate_by_attributes(variant_attribute_value)}"
                        order_item.product_id = variant_id
                        order_item.is_variant = True
                order_data.products.append(order_item)
        order_data.shipping.amount = to_decimal(order.shippingDetails.amount) if order.shippingDetails.amount else 0
        order_data.tax.amount = tax_amount
        order_data.tax.amount = to_decimal(order_data.tax.amount, 2)
        if order.transactionArray.transaction.providerName:
            order_data.payment.title = order['transactionArray']['transaction']['providerName'][0]
            order_data.payment.method = order['transactionArray']['transaction']['providerName'][0]
        if order["shippingDetails"]["notes"]:
            history = OrderHistory()
            history.comment = order.shippingDetails.notes
            order_data.history.append(history)
        try:
            item_id_def = to_str(order.itemArray[0].item.itemID)
            ship_tracking = order.shippingDetails.shipmentTrackingNumber
            order_data.shipments.tracking_number = ship_tracking[item_id_def][0]
        except(Exception,):
            pass
        return Response().success(order_data)

    def get_order_id_import(self, convert: Order, order, orders_ext):
        return order.order.orderID

    def delete_product_import(self, product_id):
        data = {
            "itemID": to_int(product_id)
        }
        remove = self.api("endFixedPriceItem", data)
        return Response().success()
