import uuid
import pytz
import requests
from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory, OrderAddress
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute, ProductLocation, ProductAttribute
from datasync.models.constructs.state import EntityProcess
from iso4217 import Currency


class ModelChannelsSquare(ModelChannel):
	FORMAT_DATE = "%Y-%m-%dT%H:%M:%S.000Z"
	ORDER_STATUS = {
		"OPEN": Order.OPEN,
		"COMPLETED": Order.COMPLETED,
		"CANCELED": Order.CANCELED,
	}


	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = "v2"
		self._product_next_cursor = ""
		self._flag_finish_product = False
		self._flag_finish_order = False
		self._store_page_id = False
		self._last_product = False
		self._all_store_page = dict()
		self._options_detail = list()
		self._location_id = ""


	def get_api_info(self):
		return {
			'code': 'Code',
			'refresh_token': 'Refresh Token',
			'access_token': 'Access Token',
		}


	# api code

	def get_version_api(self):
		return self._version_api


	def get_access_token(self):
		return self._state.channel.config.api.access_token


	def post(self, path, data = None):
		return self.api(path, data, 'post')


	def delete(self, path):
		return self.api(path, method = 'delete')


	def api(self, path, data = None, method = "get", **kwargs):
		mode = self._state.channel.config.api.mode
		if mode == "test":
			url = f"https://connect.squareupsandbox.com/v2/{to_str(path).strip('/')}"
		else:
			url = f"https://connect.squareup.com/v2/{to_str(path).strip('/')}"
		header = {
			"Content-Type": "application/json",
			"User-Agent": get_random_useragent(),
			"Authorization": f"Bearer {self.get_access_token()}",
			"Square-Version": "2023-11-15",

		}
		res = self.requests(url, data, method = method, headers = header, **kwargs)
		res_json = json_decode(res)
		if res_json:
			res_json = Prodict.from_dict(res_json)
		return res_json


	def get_client_id(self):
		client_id = self._state.channel.config.api.client_id
		if not client_id:
			return get_config_ini('squarepos', 'client_id')
		return client_id


	def get_client_secret(self):
		client_id = self._state.channel.config.api.client_secret
		if not client_id:
			return get_config_ini('squarepos', 'client_secret')
		return client_id


	def display_push_channel(self, data = None):
		if data.get('store_page_id'):
			self._store_page_id = data['store_page_id']
		return Response().success()


	def get_locations(self):
		locations = self.api('locations')
		return locations.locations


	def refresh_access_token(self):
		data = {
			"client_id": self.get_client_id(),
			"refresh_token": self._state.channel.config.api.refresh_token,
			"client_secret": self.get_client_secret(),
			"code": self._state.channel.config.api.code,
			"grant_type": "refresh_token"
		}
		headers = {
			'Content-Type': 'application/json',
			'User-Agent': get_random_useragent(),
		}
		refresh = requests.post("https://connect.squareup.com/oauth2/token", json = data, headers = headers)
		if refresh.status_code != 200:
			self.channel_disconnected()
			return False
		token = refresh.json()
		self._state.channel.config.api.access_token = token['access_token']
		self._state.channel.config.api.refresh_token = token['refresh_token']
		self._state.channel.config.api.expires_at = int(time.mktime(time.strptime(token['expires_at'], '%Y-%m-%dT%H:%M:%SZ')))
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return token['access_token']


	def requests(self, url, data = None, headers = None, method = 'get', retry = 0, **kwargs):
		access_token_expires_at = self._state.channel.config.api.expires_at
		if isinstance(access_token_expires_at, str):
			access_token_expires_at = int(time.mktime(time.strptime(access_token_expires_at, '%Y-%m-%dT%H:%M:%SZ')))
		time_current = time.time()
		if access_token_expires_at - time.time() < 10:
			token = self.refresh_access_token()
			if not token:
				return False
		headers['Authorization'] = f"Bearer {self.get_access_token()}"

		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if kwargs.get('files'):
			request_options['files'] = kwargs['files']
			del request_options['headers']['Content-Type']
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)

		try:
			response = requests.request(method, url, **request_options)


			def log_request_error():
				error = {
					'method': method,
					'status': response.status_code,
					'data': to_str(data),
					'header': to_str(response.headers),
					'response': response.text,
				}
				self.log_request_error(url, **error)


			if response.status_code > 204 or self.is_log():
				log_request_error()
			response_data = response.text

			self._last_header = response.headers
			self._last_status = response.status_code
			if response.status_code in [401, 403]:
				refresh = False
				if response.status_code == 401:
					refresh = True
				if response.status_code == 403 and not retry:
					response_json = response.json()
					if response_json.get('type') == 'AUTHORIZATION_ERROR':
						refresh = True
				if not refresh:
					return response_data
				token = self.refresh_access_token()
				if not token:
					self.channel_disconnected()
					self.set_action_stop(True)
					return response
				headers['Authorization'] = f"Bearer {self.get_access_token()}"
				retry += 1
				return self.requests(url, data, headers, method, retry = retry)
			retry = 0
			while response.status_code == 429 and retry <= 5:
				retry += 1
				time.sleep(retry * 1)
				return self.requests(url, data, headers, method, retry = retry)
		except Exception as e:
			self.log_traceback()
			response_data = False
		return response_data


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		locations = self.get_locations()
		if not locations:
			return Response().error(msg = "API SQUAREPOS NOT FOUND")
		self._state.channel.config.currency = locations[0].currency
		return Response().success()


	def get_shop_info(self):
		shop = self.api('sites')
		return shop


	def get_currency(self):
		if self._state.channel.config.currency:
			return self._state.channel.config.currency
		shop = self.get_shop_info()
		if not shop:
			self._state.channel.config.currency = 'USD'
		else:
			self._state.channel.config.currency = shop.currency
		return self._state.channel.config.currency


	def get_measurement_standard(self):
		shop_info = self.get_shop_info()
		if not shop_info:
			return 'IMPERIAL'
		return shop_info.measurementStandard


	def get_weight_unit(self):
		if self.get_measurement_standard() == 'IMPERIAL':
			return 'POUND'
		return 'KILOGRAM'


	def get_dimension_unit(self):
		if self.get_measurement_standard() == 'IMPERIAL':
			return 'INCH'
		return 'CENTIMETER'


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self._state.channel.config.api.merchant_id)
		return Response().success()


	def after_create_channel(self, data):
		if is_local() or not self.is_channel_default():
			return Response().success()

		# webhook_data = {
		# 	"topics": ['order.update'],
		# 	"endpointUrl": get_api_server_url(f'merchant/squarespace/webhook/{data.channel_id}/order/update'),
		# }
		# webhook = self.post('webhook_subscriptions', webhook_data)
		# if self._last_status == 201:
		# 	self._state.channel.config.api[f"secret_webhook"] = webhook['secret']
		# 	self.update_channel(api = json_encode(self._state.channel.config.api))
		return Response().success()


	def get_total_products(self):
		total = 0
		params = {
			"types": "ITEM"
		}
		products = self.api('catalog/list', params)
		total += len(products.object)
		if products.cursor:
			self._product_next_cursor = products.cursor
		while self._product_next_cursor:
			params["cursor"] = self._product_next_cursor
			products = self.api('catalog/list', params)
			total += len(products.object)
			if products.cursor:
				self._product_next_cursor = products.cursor
			else:
				self._product_next_cursor = ''
		return total


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.total = 0
			params = {
				"types": "ITEM",
				"limit": 1
			}
			products = self.api('catalog/list', params)
			if products and products.objects:
				self._state.pull.process.products.total = -1
			if self.is_refresh_process():
				body = {
					"object_types": [
						"ITEM"
					]
				}
				last_modified = self.get_max_last_modified_product()
				if last_modified:
					body['begin_time'] = last_modified
				products_refresh = self.api('catalog/search', body, method = "post")
				if products_refresh and products_refresh.objects:
					self._state.pull.process.products.total = -1
		if self.is_order_process():
			self._state.pull.process.orders = EntityProcess()
			body = {"query": {
				"filter": {
					"date_time_filter": {
					}
				}
			},
				"limit": 500
			}
			start_time = self.get_order_start_time(self.FORMAT_DATE)
			last_modifier = self._state.pull.process.orders.max_last_modified
			body["query"]["filter"]["date_time_filter"]["created_at"] = {}
			body["query"]["filter"]["date_time_filter"]["created_at"]["start_at"] = start_time
			body["query"]["filter"]["date_time_filter"]["created_at"]["end_at"] = get_current_time(self.FORMAT_DATE)
			if last_modifier:
				del body["query"]["filter"]["date_time_filter"]["created_at"]
				body["query"]["filter"]["date_time_filter"]["update_at"] = {}
				body["query"]["filter"]["date_time_filter"]["update_at"]["start_at"] = last_modifier
				body["query"]["filter"]["date_time_filter"]["update_at"]["end_at"] = get_current_time(self.FORMAT_DATE)
			list_location = list()
			if self._state.channel.config.setting.qty.locations_mapping:
				locations = self._state.channel.config.setting.qty.locations_mapping
				for location in locations:
					if location["channel"]:
						list_location.append(location["channel"]["location_id"])
			if len(list_location) > 0:
				body["location_ids"] = list(set(list_location))
			else:
				body["location_ids"] = self.get_all_locations()
			orders = self.api('orders/search', data = body, method = "post")
			if orders and orders.orders:
				self._state.pull.process.orders.total = -1
		return Response().success()


	def get_all_locations(self):
		locations = self.api('locations')
		list_id_location = list()
		for location in locations.locations:
			list_id_location.append(location.id)
		return list_id_location


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, self.FORMAT_DATE) > to_timestamp(self._order_max_last_modified, self.FORMAT_DATE)):
			self._order_max_last_modified = last_modifier


	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	# def clear_channel_categories(self):
	# 	next_clear = Prodict.from_dict({
	# 		'result': 'process',
	# 		'function': 'clear_channel_products',
	# 	})
	# 	self._state.channel.clear_process = next_clear
	# 	if not self._state.config.categories:
	# 		return next_clear
	# 	try:
	# 		all_collections = self.api('custom_collections.json?limit=100')
	# 		while all_collections:
	# 			if not all_collections.custom_collections:
	# 				break
	# 			for collect in all_collections.custom_collections:
	# 				id_collect = collect.id
	# 				res = self.api('custom_collections/{}.json'.format(id_collect), None, 'Delete')
	# 			# a = res
	# 			all_collections = self.api('custom_collections.json?limit=100')
	# 			time.sleep(0.1)
	# 		all_collections = self.api('smart_collections.json?limit=100')
	#
	# 		while all_collections:
	# 			if not all_collections:
	# 				return next_clear
	# 			if not all_collections.smart_collections:
	# 				return next_clear
	# 			for collect in all_collections.smart_collections:
	# 				id_collect = collect.id
	# 				res = self.api('smart_collections/{}.json'.format(id_collect), None, 'Delete')
	# 			# a = res
	# 			all_collections = self.api('smart_collections.json?limit=100')
	# 			time.sleep(0.1)
	# 	except Exception:
	# 		self.log_traceback()
	# 		return next_clear
	# 	return next_clear

	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			all_products = self.api('catalog/list')
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.objects:
					return next_clear
				for product in all_products.objects:
					id_product = product.id
					res = self.api(f'catalog/object/{id_product}', None, 'Delete')
				all_products = self.api('catalog/list')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	# def get_collection_type(self):
	# 	if self._collection_type:
	# 		return self._collection_type
	# 	self._collection_type = self.CUSTOM_COLLECTION
	# 	return self._collection_type
	#
	#
	# def set_collection_type(self, collection_type):
	# 	self._collection_type = collection_type

	#
	# def get_categories_main_export(self):
	# 	collection_type = self.get_collection_type()
	# 	limit_data = self._state.pull.setting.categories
	# 	categories_data = list()
	# 	if collection_type == self.CUSTOM_COLLECTION:
	# 		id_src = self._state.pull.process.categories.id_src
	# 		collections = self.api('custom_collections.json', data = {'since_id': id_src, 'limit': limit_data})
	# 		if not collections:
	# 			return Response().error()
	# 		# if 'custom_collections' in categories_page and not categories_page['custom_collections']:
	# 		# 	return create_response('pass')
	# 		categories_data = collections.get('custom_collections')
	# 		if not categories_data:
	# 			collection_type = self.CUSTOM_COLLECTION
	# 	if collection_type == self.SMART_COLLECTION:
	# 		id_src = self._state.pull.process.categories.id_src_smart
	# 		if not id_src:
	# 			id_src = 0
	# 		collections = self.api('smart_collections.json', data = {'since_id': id_src, 'limit': limit_data})
	# 		if not collections:
	# 			return Response().error()
	#
	# 		if not collections.get('smart_collections'):
	# 			return Response().skip()
	# 		categories_data = collections['smart_collections']
	# 	return Response().success(categories_data)
	#
	#
	# def get_categories_ext_export(self, categories):
	# 	extend = dict()
	# 	for category in categories:
	# 		category_id = to_str(category.id)
	# 		extend[category_id] = dict()
	# 		meta = False
	# 		if 'rules' in category:
	# 			meta = self.api('smart_collections/{}/metafields.json'.format(category_id))
	# 		else:
	# 			meta = self.api('custom_collections/{}/metafields.json'.format(category_id))
	# 		if meta:
	# 			extend[category_id]['meta'] = meta.get('metafields')
	# 	return Response().success(extend)
	#
	#
	# def convert_category_export(self, category, categories_ext):
	# 	category_data = CatalogCategory()
	# 	category_id = to_str(category['id'])
	# 	parent = CatalogCategory()
	# 	category_data.parent = parent
	# 	category_data.id = category.id
	# 	category_data.active = True if category.published_at else False
	# 	if category.image and category.image.src:
	# 		real_path = re.sub("/\?.+/", "", category.image.src)
	# 		real_path = real_path[:real_path.find('?')]
	# 		category_data['thumb_image']['url'] = real_path
	# 		category_data['thumb_image']['path'] = ''
	# 	category_data.name = category.title
	# 	category_data.description = category.body_html
	# 	category_data['created_at'] = convert_format_time(category.published_at, self.FORMAT_DATE)
	# 	category_data['updated_at'] = convert_format_time(category.updated_at, self.FORMAT_DATE)
	# 	category_data.seo_url = "https://{}.mysquarespace.com/collections/{}".format(self._state.channel.config.api.shop,
	# 	                                                                             category.handle)
	# 	if 'meta' in categories_ext[category_id] and categories_ext[category_id]['meta']:
	# 		for metafields in categories_ext[category_id]['meta']:
	# 			if metafields['key'] == 'description_tag':
	# 				category_data.meta_description = metafields['value']
	# 			elif metafields['key'] == 'title_tag':
	# 				category_data.meta_title = metafields['value']
	# 	return Response().success(category_data)
	#
	#
	# def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
	# 	return category['id']
	#
	#
	# def category_import(self, convert: CatalogCategory, category, categories_ext):
	# 	if not category.name:
	# 		return response_error('import category ' + to_str(category.id) + ' false.')
	# 	post_data = {
	# 		'smart_collection': {
	# 			'title': category.name,
	# 			'body_html': category.description,
	# 			'published_scope': 'web',
	# 			'disjunctive': 'false',
	# 			'sort_order': 'best-selling',
	# 			'rules': []
	# 		}
	# 	}
	#
	# 	# Add Thumbnail image
	# 	if category.thumb_image.url:
	# 		main_image = self.process_image_before_import(category.thumb_image.url, category.thumb_image.path)
	# 		image_data = self.resize_image(main_image['url'])
	# 		if image_data:
	# 			post_data['smart_collection']['image'] = image_data
	#
	# 	# Status
	# 	if not category.active:
	# 		post_data['smart_collection']['published_at'] = None
	#
	# 	# Add rules: the list of rules that define what products go into the smart collections.
	# 	tag_rule = {
	# 		'column': 'tag',
	# 		'relation': 'equals',
	# 		'condition': category.name
	# 	}
	# 	post_data['smart_collection']['rules'].append(tag_rule)
	#
	# 	# Post data
	# 	response = self.api('smart_collections.json', post_data, 'Post')
	# 	check_response = self.check_response_import(response, category, 'category')
	# 	if check_response.result != Response.SUCCESS:
	# 		if 'Image' in check_response.msg:
	# 			del post_data['smart_collection']['image']
	# 			response = self.api('smart_collections.json', post_data, 'Post')
	# 			check_response = self.check_response_import(response, category, 'category')
	# 			if check_response.result != Response.SUCCESS:
	# 				return check_response
	# 		else:
	# 			return check_response
	#
	# 	category_id = response['smart_collection']['id']
	# 	handle = response['smart_collection'].get('handle')
	# 	return Response().success(category_id)

	def get_product_by_id(self, product_id):
		product = self.api(f'catalog/object/{product_id}')
		if self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		if self._last_status != 200:
			return Response().error()
		return Response().success(product['object'])


	def get_products_main_export(self):
		# self.get_product_by_updated_at()
		# return Response().success()
		next_cursor = self._state.pull.process.products.next_cursor
		if self._flag_finish_product:
			return Response().finish()
		if self._request_data.get("categories_id", {}):
			params = {}
			list_categories_id = self._request_data.get("categories_id", {}).split(",")
			params['category_ids'] = list_categories_id
			products = self.api("catalog/search-catalog-items", params, method = "post")
			if not products or not products.items:
				return Response().finish()
		elif self._request_data.get("status", {}):
			params = {}
			archived_state = self._request_data.get("status", {})
			params['archived_state'] = "ARCHIVED_STATE_ARCHIVED" if archived_state == "ARCHIVED" else "ARCHIVED_STATE_NOT_ARCHIVED"
			products = self.api("catalog/search-catalog-items", params, method = "post")
			if not products or not products.items:
				return Response().finish()
		else:
			params = {
				"types": "ITEM"
			}
			if next_cursor:
				params['cursor'] = next_cursor
			products = self.api('catalog/list', params)
			if not products or not products.objects:
				return Response().finish()
		if not products.cursor:
			self._flag_finish_product = True
		else:
			self._state.pull.process.products.next_cursor = products.cursor
		if products.objects:
			return Response().success(data = products.objects)
		return Response().success(data = products["items"])


	def get_max_last_modified_product(self):
		if self._state.pull.process.products.last_modified:
			if to_str(self._state.pull.process.products.last_modified).isnumeric():
				return convert_format_time(self._state.pull.process.products.last_modified, new_format = self.FORMAT_DATE)
			max_last_modified = self._state.pull.process.products.last_modified
			if max_last_modified.find(' ') != -1:
				max_last_modified = max_last_modified.replace(' ', 'T')
				max_last_modified += '.000Z'
			return max_last_modified
		return False


	def get_product_by_updated_at(self):
		if self._flag_finish_product:
			return Response().finish()
		body = {
			"object_types": [
				"ITEM"
			]
		}
		next_cursor = self._state.pull.process.products.next_cursor
		if next_cursor:
			body['cursor'] = next_cursor
		else:
			last_modified = self.get_max_last_modified_product()
			if last_modified:
				body['begin_time'] = last_modified
		products = self.api('catalog/search', body, method = "post")
		if not products or not products.objects:
			return Response().finish()
		if not products.cursor:
			self._flag_finish_product = True
		else:
			self._state.pull.process.products.next_cursor = products.cursor
		return Response().success(data = products.objects)


	def get_product_updated_at(self, product):
		return product.updated_at


	def updated_at_to_timestamp(self, updated_at, time_format = FORMAT_DATE):
		return isoformat_to_datetime(updated_at).timestamp()


	def get_products_ext_export(self, products):
		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def get_inventory_variant(self, variant_id):
		inventory = self.api(f'inventory/{variant_id}')
		try:
			qty = inventory.counts[0].quantity
			state = inventory.counts[0].state
		except:
			qty = 0
			state = "NUll"
		return qty, state


	def get_product_detail(self, product_id):
		product_detail = self.api(f'catalog/object/{product_id}?include_related_objects=true')
		return product_detail


	def get_options_detail(self):
		options_detail = self.api(f'catalog/list?types=ITEM_OPTION')
		return options_detail.objects


	def set_variant_detail(self, variant):
		options_detail = self._options_detail
		if variant.item_variation_data.item_option_values:
			for attr in variant.item_variation_data.item_option_values:
				for option in options_detail:
					if attr.item_option_id == option.id:
						attr.item_option_id = option.item_option_data.display_name
		else:
			for index, option in enumerate(options_detail):
				for option_value in option.item_option_data["values"]:
					if variant.item_variation_data.name == option_value["item_option_value_data"]["name"]:
						variant.item_variation_data.update({"attribute_name": option.item_option_data.name})
		return variant


	def get_category_name_from_square(self, category_id):
		category = self.api(f"catalog/object/{category_id}")
		return category.object.category_data.name


	def get_inventory_location(self, variant_id):
		inventory = self.api(f'inventory/{variant_id}')
		return inventory.counts if inventory else {}


	def get_exponent_currency(self, currency):
		exponent = Currency[f"{currency.lower()}"].exponent
		return 10 ** (to_int(exponent))


	def _convert_product_export(self, product, products_ext: Prodict):
		list_locations = list()
		product_id = to_str(product.id)
		product_detail = self.get_product_detail(product_id)
		product_data = Product()
		product_data.id = product_id
		product_data.name = product.item_data.name
		product_data.description = product.item_data.description_html
		product_data.type = product.product_type
		product_data.invisible = product.item_data.is_archived
		product_data.seo_url = f'https://squareup.com/dashboard/items/library/{product_id}'
		# product_data.tags = ",".join(product.tags) if product.tags else ''
		product_data.status = product.item_data.visibility
		if product.custom_attribute_values:
			for item in product.custom_attribute_values:
				product_attribute = ProductAttribute()
				if product.custom_attribute_values[item]["type"] == "STRING":
					product_attribute.attribute_value_name = product.custom_attribute_values[item]["string_value"]
				elif product.custom_attribute_values[item]["type"] == "NUMBER":
					product_attribute.attribute_value_name = product.custom_attribute_values[item]["number_value"]
				elif product.custom_attribute_values[item]["type"] == "BOOLEAN":
					product_attribute.attribute_value_name = product.custom_attribute_values[item]["boolean_value"]
				else:
					continue
				product_attribute.attribute_name = product.custom_attribute_values[item]["name"]
				product_attribute.attribute_type = product.custom_attribute_values[item]["type"]
				product_data.attributes.append(product_attribute)
		# product_data.invisible = not product.item_data.isVisible
		if product_detail.related_objects:
			for index, image in enumerate(product_detail.related_objects):
				if image.category_data:
					continue
				elif index == 0:
					product_data.thumb_image.url = image.image_data.url
				else:
					product_image_data = ProductImage()
					product_image_data.url = image.image_data.url
					# product_image_data.label = image.altText
					product_image_data.position = index
					product_data.images.append(product_image_data)
		variants = product_detail.object.item_data.variations
		product_data.sku = variants[0].item_variation_data.sku
		product_data.price = to_decimal(variants[0].item_variation_data.price_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))
		# if variant.pricing.salePrice and variant.pricing.salePrice.value:
		# 	product_data.special_price.price = variant.pricing.salePrice.value
		product_data.qty = 0
		product_data.created_at = self.iso_format_datetime_to_format(product.created_at)
		product_data.updated_at = self.iso_format_datetime_to_format(product.updated_at)
		if product.item_data.category_id:
			category_name = self.get_category_name_from_square(product.item_data.category_id)
			product_data.template_data = {
				"category": {
					'category_id': product.item_data.category_id,
					'category_name': category_name,
				}
			}
			product_data.category_name_list.append(category_name)
		self._options_detail = self.get_options_detail()
		if len(variants) > 1 and variants[0].item_variation_data.name != "Regular":
			is_in_stock = True
			qty = 0
			manage_stock = True
			# product_data.sku = product.id
			for variant in variants:
				qty_variant = 0
				list_inventory_data = list()
				variant_data = ProductVariant()
				variant_info = self.get_product_detail(variant.id)
				if variant_info:
					related = variant_info.related_objects
					for obj in related:
						if obj.type == "IMAGE":
							variant_data.thumb_image.url = obj.image_data.url
				variant_data.name = product.item_data.name + "-" + variant.item_variation_data.name
				# variant_data.invisible = not product.isVisible
				variant_data.sku = variant.item_variation_data.sku
				variant_data.id = variant.id
				variant_data.channel_data["variant_square_id"] = variant.id
				inventory = self.get_inventory_location(variant_data.id)
				if inventory:
					for inv in inventory:
						qty_variant += to_int(inv["quantity"])
						qty += qty_variant
						inventory_variant = {
							"qty": to_int(inv["quantity"]),
							"location_id": inv["location_id"]
						}
						list_inventory_data.append(inventory_variant)
					variant_data.qty = qty_variant

				list_inventory_id = [location["location_id"] for location in list_inventory_data]
				locations = self.get_locations()
				for location_object in locations:
					if location_object.id not in list_inventory_id:
						inventory_variant = {
							"qty": 0,
							"location_id": location_object.id
						}
						list_inventory_data.append(inventory_variant)
				variant_data.channel_data["api_version"] = to_str(variant.version)
				variant_data.channel_data["square_locations"] = list_inventory_data
				variant_data.price = to_decimal(variant.item_variation_data.price_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))
				if variant.image_url:
					variant_data.thumb_image.url = variant.image_url
				variant = self.set_variant_detail(variant)
				attribute_value_list = variant.item_variation_data.name.split(", ")
				if variant.item_variation_data.item_option_values:
					for index, attribute in enumerate(variant.item_variation_data.item_option_values):
						attribute_data = ProductVariantAttribute()
						attribute_data.attribute_name = attribute.item_option_id
						attribute_data.attribute_value_name = attribute_value_list[index]
						variant_data.attributes.append(attribute_data)
				else:
					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_name = variant.item_variation_data.attribute_name
					attribute_data.attribute_value_name = variant.item_variation_data.name
					variant_data.attributes.append(attribute_data)
				product_data.variants.append(variant_data)
				product_data.is_in_stock = is_in_stock
			if qty > 0:
				manage_stock = True
				product_data.qty = qty
				product_data.is_in_stock = qty > 0
		else:
			inventory = self.get_inventory_location(variants[0].id)
			qty = 0
			list_locations = list()
			if inventory:
				for inv in inventory:
					product_location = ProductLocation()
					product_location.location_id = inv["location_id"]
					product_location.qty = to_int(inv["quantity"])
					qty += to_int(inv["quantity"])
					list_locations.append(product_location)
			list_inventory_id = [location["location_id"] for location in list_locations]
			locations = self.get_locations()
			for location_object in locations:
				if location_object.id not in list_inventory_id:
					inventory_variant = {
						"qty": 0,
						"location_id": location_object.id
					}
					list_locations.append(inventory_variant)
			product_data.channel_data['variant_default_id'] = product_detail.object.item_data.variations[0]['id']
			product_data.qty = qty
		product_data.channel_data['square_locations'] = list_locations
		product_data.channel_data['square_status'] = "active" if not product.item_data.is_archived else "archived"
		product_data.channel_data['api_version'] = product_detail.object.version
		return Response().success(product_data)


	def extend_images(self, product):
		images = list()
		if product.thumb_image.url:
			main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			images.append(main_image['url'])
		for img_src in product.images:
			if 'status' in img_src and not img_src['status']:
				continue
			image_process = self.process_image_before_import(img_src.url, img_src.path)
			if image_process['url'] not in images:
				images.append(image_process['url'])
		return images


	# def get_all_store_page(self):
	# 	sites = self.api('sites')
	# 	if not sites or not sites.site:
	# 		return False
	# 	self._all_store_page = {row['id']: {'name': row['title']} for row in sites.site}
	# 	return self._all_store_page
	#
	#
	# def get_store_page_id(self, product = None):
	# 	if product and not self.is_channel_default():
	# 		template_store = product.get('template_data', {}).get('store', {})
	#
	# 		if not template_store:
	# 			return False
	# 		return template_store.get('store_page_id')
	# 	if self._store_page_id:
	# 		return self._store_page_id
	# 	if self._request_data.get('store_page_id'):
	# 		self._store_page_id = self._request_data.get('store_page_id')
	# 		return self._store_page_id
	# 	store_pages = self.commerce_api('store_pages')
	# 	if not store_pages or not store_pages.storePages:
	# 		return False
	# 	store_pages_enable = list(filter(lambda x: x.isEnabled, store_pages.storePages))
	# 	if not store_pages_enable:
	# 		return False
	# 	self._store_page_id = store_pages_enable[0]['id']
	# 	return self._store_page_id

	def upload_options_product(self, option, product):
		body = {
			"idempotency_key": to_str(uuid.uuid4()),
		}
		option_detail = {
			"type": "ITEM_OPTION",
			"id": f"#{random_string(16)}",
			"item_option_data": {
				"name": f"{option.option_name}",
				"display_name": f"{option.option_name}"
			}
		}
		option_list = list()
		option_values = list()
		for option_value in option.option_values:
			option_values.append({
				"id": "#" + random_string(16),
				"type": "ITEM_OPTION_VAL",
				"item_option_value_data": {
					"name": option_value,
					"display_name": option_value
				}
			})
		if len(option_values) > 0:
			option_detail["item_option_data"]["values"] = option_values
		option_list.append(option_detail)
		body["batches"] = [{
			"objects": option_list
		}]
		options_import = self.api('catalog/batch-upsert', data = body, method = "post")
		return options_import.objects[0]


	def upload_new_option_values_update(self, option, option_value):
		body = {
			"idempotency_key": to_str(uuid.uuid4()),
			"batches": [{
				"objects": [{
					"type": "ITEM_OPTION",
					"id": option.id,
					"item_option_data": {
						"name": option.item_option_data.name,
						"display_name": option.item_option_data.display_name,
						"values": {
							"id": "#" + random_string(16),
							"type": "ITEM_OPTION_VAL",
							"item_option_value_data": {
								"name": option_value,
								"display_name": option_value
							}
						}
					}
				}]
			}]
		}
		options_import = self.api('catalog/batch-upsert', data = body, method = "post")
		return options_import


	def attribute_to_id(self, name, value_option, options):
		op_dict = dict()
		for option in options:
			if option.item_option_data.display_name == name:
				op_dict["item_option_id"] = to_str(option.id)
				for value in option.item_option_data["values"]:
					if value["item_option_value_data"]["name"] == value_option:
						op_dict["item_option_value_id"] = to_str(value["id"])
		return op_dict


	def product_to_squarepos_variant_data(self, product: Product, parent = None, option_main = None, product_id = None, update = None, default = None):
		if not parent:
			parent = product
		variant_data = {
			'id': "#" + to_str(random_string(16)) if not update and not default else to_str(default) or product.channel[f'channel_{self.get_channel_id()}'].get('product_id') or product.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id'),
			'type': "ITEM_VARIATION",
			'sku': product.sku,
			'item_variation_data': {
				'name': 'Regular',
				'sku': product.sku,
				"pricing_type": "FIXED_PRICING",
				"price_money": {
					"amount": to_int(product.price * self.get_exponent_currency(self.get_currency_location(self.get_location_default_id()))),
					"currency": self.get_currency_location(self.get_location_default_id())
				},
			}
		}
		get_product = ""
		if default:
			_id = default
			get_product = self.api(f'catalog/object/{_id}')
		elif product.channel[f'channel_{self.get_channel_id()}'].get('product_id'):
			_id = product.channel[f'channel_{self.get_channel_id()}'].get('product_id')
			get_product = self.api(f'catalog/object/{_id}')
		elif product.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id'):
			_id = product.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id')
			get_product = self.api(f'catalog/object/{_id}')
		variant_data['version'] = to_int(get_product.object.version) if not isinstance(get_product, str) and get_product else 12345678
		variant_data['item_variation_data']['item_id'] = to_str(product_id) or variant_data["id"]

		if product.upc:
			variant_data["item_variation_data"]["upc"] = product.upc
		if product.is_variant:
			attributes = {
				"item_id": "#" + to_str(parent.id) if not product_id else to_str(product_id),
				"sku": product.sku,
				"pricing_type": "FIXED_PRICING",
				"price_money": {
					"amount": to_int(product.price * self.get_exponent_currency(self.get_currency_location(self.get_location_default_id()))),
					"currency": self.get_currency_location(self.get_location_default_id())
				}
			}
			attribute_value_name = ""
			list_value_name = list()
			option_id_list = list()
			option_name_list = list()
			for attribute in product.attributes:
				option_name_dict = dict()
				if not attribute.use_variant:
					continue
				attribute_value_name += attribute.attribute_value_name + ", "
				list_value_name.append(attribute.attribute_value_name)
				option_name_dict[f"{attribute.attribute_name}"] = attribute.attribute_value_name.rstrip(", ")
				option_name_list.append(option_name_dict)
			attributes['name'] = attribute_value_name.rstrip(", ")
			if option_main:
				item_option_values = list()
				for option in option_name_list:
					option_id = self.attribute_to_id(list(option.keys())[0], list(option.values())[0], option_main)
					item_option_values.append(option_id)
				attributes["item_option_values"] = item_option_values
			variant_data["item_variation_data"] = attributes
			if update:
				if product.channel[f'channel_{self.get_channel_id()}'].get('product_id') or product.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id'):
					_id = product.channel[f'channel_{self.get_channel_id()}'].get('product_id') or product.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id')
					get_product = self.api(f'catalog/object/{_id}')
					variant_data['version'] = to_int(get_product.object.version) if not isinstance(get_product, str) else 12345678 or to_int(product.channel[f'channel_{self.get_channel_id()}'].get('api_version'))
		return variant_data


	def to_product_simple_data(self, product, product_id = None, custom_attribute = None, attribute_main = None, create = None):
		get_product = ""
		if product_id:
			_id = product_id
			get_product = self.api(f'catalog/object/{_id}')
		product_data = {
			"idempotency_key": to_str(uuid.uuid4()),
			'object': {
				'id': "#" + to_str(product.id) if not product_id else to_str(product_id),
				'type': 'ITEM',
				'version': to_int(get_product.object.version) if not isinstance(get_product, str) else 12345678 or to_int(product.api_version),
				'item_data': {
					'name': product.name[:235],
					'description_html': product.description[:65535],
					'available_online': True,
					"skip_modifier_screen": False,
					"ecom_visibility": "UNINDEXED",
					"is_archived": False if not product.invisible else True
				}
			}
		}
		if custom_attribute:
			product_data["object"]["custom_attribute_values"] = {}
			for index, custom in enumerate(custom_attribute):
				custom_object = {
					"custom_attribute_definition_id": custom.id,
					"type": custom.custom_attribute_definition_data.type,
					"name": custom.custom_attribute_definition_data.name,
				}
				if custom.custom_attribute_definition_data.type == "STRING":
					custom_object["string_value"] = attribute_main[index].attribute_value_name
				elif custom.custom_attribute_definition_data.type == "NUMBER":
					custom_object["number_value"] = attribute_main[index].attribute_value_name
				elif custom.custom_attribute_definition_data.type == "BOOLEAN":
					custom_object["boolean_value"] = attribute_main[index].attribute_value_name
				else:
					continue
				product_data["object"]["custom_attribute_values"][f"{custom.custom_attribute_definition_data.key}"] = custom_object
		category_data = ""
		category_template = product.get('template_data', {}).get('category')
		if category_template and category_template.category_id:
			product_data["object"]["item_data"]["category_id"] = category_template.category_id
		elif product.category_name_list and create:
			category_id = self.check_and_create_category(product)
			if category_id:
				product_data["object"]["item_data"]["category_id"] = category_id
				category_data = {
					"category_id": category_id,
					"category_name": product.category_name_list[0]
				}
		return product_data, category_data


	def check_and_create_category(self, product):
		data_query = {
			"prefix_query": {
				"attribute_name": "name",
				"attribute_prefix": f"{product.category_name_list[0]}"
			}
		}
		search_category = self.search_batches(data_query, "CATEGORY")
		if search_category:
			return search_category["id"]
		else:
			data_create_category = {
				"idempotency_key": to_str(uuid.uuid4()),
				"object": {
					"type": "CATEGORY",
					"category_data": {
						"name": product.category_name_list[0]
					},
					"id": f"#{random_string(16)}"
				}
			}
			create_category = self.api("catalog/object", data_create_category, method = "post")
			if self._last_status != 200:
				return Response().error(msg = create_category.errors[0].detail if create_category else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
			return create_category.catalog_object.id
		return {}


	def upload_images(self, product_id, image, is_primary = False):
		img = requests.get(image)
		if img.status_code != 200:
			return Response().error(msg = f'Image {image} not found.')
		img = img.content
		img_type = requests.get(image).headers["Content-Type"]
		payload = {
			"idempotency_key": to_str(uuid.uuid4()),
			"object_id": product_id,
			"image": {
				"id": f"#{random_string(16)}",
				"type": "IMAGE",
				"image_data": {
					"caption": product_id,
					"name": product_id
				}
			}
		}
		if is_primary:
			payload["image"]["is_primary"] = True
		files = {
			"request": (None, json_encode(payload), 'application/json; charset=utf-8'),
			"image_file": ('images', img, img_type)
		}
		upload_image = self.api('catalog/images', files = files, method = 'post')
		if not upload_image:
			return Response().error(msg = f'Upload image {image} failed.')
		return Response().success(data = upload_image.image.image_data)


	def to_variant_inventory(self, product):
		channel_default = self.get_channel_default()
		channel_default_type = channel_default.get("type")
		inventories = list()
		location_quantities = dict()
		qty_no_manage_stock = self._state.channel.config.setting.qty.no_manage_stock_qty if self._state.channel.config.setting and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.no_manage_stock_qty else 999
		if self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.locations_mapping:
			for mapping in self._state.channel.config.setting.qty.locations_mapping:
				mapping_location_id = mapping.main.get("location_id")
				_mapping_location_id = mapping.channel.get("location_id")
				if channel_default_type != "shopify":
					return [{
						"quantity": to_int(product.qty),
						"location_id": mapping.channel.get("location_id")
					}]
				else:
					locations = product.locations
					for location in locations:
						main_location_id = location.location_id
						main_location_qty = location.qty if product.manage_stock else qty_no_manage_stock
						if to_str(main_location_id) == to_str(mapping_location_id):
							if _mapping_location_id in location_quantities:
								location_quantities[_mapping_location_id] += main_location_qty
							else:
								location_quantities[_mapping_location_id] = main_location_qty
			inventories = [{"location_id": location_id, "quantity": to_int(qty)} for location_id, qty in location_quantities.items()]
		return inventories


	def get_custom_attributes(self, attr):
		query = {
			"prefix_query": {
				"attribute_name": "name",
				"attribute_prefix": f"{attr.attribute_name}"
			}
		}
		custom_attr = self.search_batches(query, "CUSTOM_ATTRIBUTE_DEFINITION")
		return custom_attr if custom_attr else ""


	def get_option(self, attr):
		query = {
			"prefix_query": {
				"attribute_name": "name",
				"attribute_prefix": f"{attr}"
			}
		}
		custom_attr = self.search_batches(query, "ITEM_OPTION")
		return custom_attr if custom_attr else {}


	def create_custom_attributes(self, attr):
		body = {
			"idempotency_key": to_str(uuid.uuid4()),
			"batches": [{
				"objects": []
			}]
		}
		object_list = list()
		object_custom = {
			"id": f"#{random_string(16)}",
			"type": "CUSTOM_ATTRIBUTE_DEFINITION",
			"custom_attribute_definition_data": {
				"allowed_object_types": [
					"ITEM",
					"ITEM_VARIATION"
				]
			}
		}
		if attr.attribute_type == "STRING" or attr.attribute_type == "text":
			object_custom["custom_attribute_definition_data"]["type"] = "STRING"
			object_custom["custom_attribute_definition_data"]["name"] = attr.attribute_name
			object_custom["custom_attribute_definition_data"]["key"] = attr.attribute_name
		elif attr.attribute_type.lower() == "number":
			object_custom["custom_attribute_definition_data"]["type"] = "NUMBER"
			object_custom["custom_attribute_definition_data"]["name"] = attr.attribute_name
			object_custom["custom_attribute_definition_data"]["key"] = attr.attribute_name
		elif attr.attribute_type.lower() == "boolean":
			object_custom["custom_attribute_definition_data"]["type"] = "BOOLEAN"
			object_custom["custom_attribute_definition_data"]["name"] = attr.attribute_name
			object_custom["custom_attribute_definition_data"]["key"] = attr.attribute_name
		object_list.append(object_custom)
		body["batches"][0]["objects"] = object_list
		create_custom = self.api("catalog/batch-upsert", data = body, method = "post")
		if self._last_status != 200:
			return Response().error(msg = create_custom.errors[0].detail if create_custom else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
		return Response().success(data = create_custom.objects[0] if create_custom.objects else "")


	def product_import(self, convert: Product, product, products_ext):
		if not product.name:
			return Response.error(Errors.PRODUCT_DATA_INVALID)
		data_insert_map = {
			'variant_default_id': "",
			'api_version': "",
			'square_locations': list(),
			'template_data': {}
		}
		create_custom = []
		if len(product.attributes) > 0:
			for index, attr in enumerate(product.attributes):
				if index < 10:
					custom_object = self.get_custom_attributes(attr)
					if custom_object:
						create_custom.append(custom_object)
					else:
						create_obj = self.create_custom_attributes(attr)
						if create_obj.result == "success":
							create_custom.append(create_obj)
				else:
					continue
		# page_id = self.get_store_page_id(product)
		# if not page_id:
		# 	return Response().error(Errors.SQUARESPACE_NOT_STORE_PAGE)
		self._last_product = None
		if len(create_custom) > 0:
			product_data, category_data = self.to_product_simple_data(product, custom_attribute = create_custom, attribute_main = product.attributes, create = True)
		else:
			product_data, category_data = self.to_product_simple_data(product, create = True)
		if not product.variants:
			qty_no_manage_stock = self._state.channel.config.setting.qty.no_manage_stock_qty if self._state.channel.config.setting and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.no_manage_stock_qty else 999
			list_inventory_simple = list()
			variant_data = self.product_to_squarepos_variant_data(product, product_id = product_data["object"]["id"])
			product_data['object']['item_data']['variations'] = [variant_data]
			product_import = self.api('catalog/object', product_data, method = 'post')
			if self._last_status != 200:
				return Response().error(msg = product_import.errors[0].detail if product_import else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
			if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify" and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.locations_mapping:
				inventories = self.to_variant_inventory(product)
				if len(inventories) > 0:
					for inventory in inventories:
						ivt = self.set_inventory(product_import.catalog_object.item_data.variations[0]['id'], inventory["quantity"], inventory["location_id"])
						inventory_variant = {
							"qty": inventory["quantity"],
							"location_id": inventory["location_id"]
						}
						list_inventory_simple.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_simple]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_simple.append(inventory_variant)
				else:
					ivt = self.set_inventory(product_import.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": product.qty if product.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_simple.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_simple]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_simple.append(inventory_variant)
			elif not self.is_channel_default():
				ivt = self.set_inventory(product_import.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
				inventory_variant = {
					"qty": product.qty if product.manage_stock else qty_no_manage_stock,
					"location_id": self.get_location_default_id()
				}
				list_inventory_simple.append(inventory_variant)
				list_inventory_id = [location["location_id"] for location in list_inventory_simple]
				locations = self.get_locations()
				for location_object in locations:
					if location_object.id not in list_inventory_id:
						inventory_variant = {
							"qty": 0,
							"location_id": location_object.id
						}
						list_inventory_simple.append(inventory_variant)
			else:
				inventory = self.set_inventory(product_import.catalog_object.item_data.variations[0]['id'], product.qty, location_id = self.get_create_location(self.get_src_channel_id()))
			data_insert_map["variant_default_id"] = product_import.catalog_object.item_data.variations[0]['id']
			data_insert_map["api_version"] = product_import.catalog_object.item_data.variations[0].version
			data_insert_map["square_locations"] = list_inventory_simple
		create_options = ""
		if product.variants:
			if len(product.variant_attributes) > 0:
				product_data['object']['item_data']["item_options"] = list()
				options_list = list()
				create_options = list()
				for option in product.variant_options:
					get_option = self.get_option(option.option_name)
					if get_option:
						check_status_create = self.check_and_create_new_option(get_option, option)
						if check_status_create.result != "success":
							return Response().error(msg = check_status_create.msg)
						create_options.append(self.get_option(option.option_name))
					else:
						create_options.append(self.upload_options_product(option, product))
				for option in create_options:
					value = dict()
					value["item_option_id"] = option["id"]
					options_list.append(value)
				product_data['object']['item_data']["item_options"] = options_list
			product_data['object']['item_data']['variations'] = list()
			for variant in product.variants:
				if create_options:
					product_data['object']['item_data']['variations'].append(self.product_to_squarepos_variant_data(variant, product, create_options))
				else:
					product_data['object']['item_data']['variations'].append(self.product_to_squarepos_variant_data(variant, product))
			product_import = self.api('catalog/object', product_data, method = 'post')
			if self._last_status != 200:
				return Response().error(msg = product_import.errors[0].detail if product_import else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
		self._last_product = product_import
		if category_data:
			data_insert_map["template_data"]["category"] = category_data
		else:
			del data_insert_map["template_data"]
		custom_attributes = product_import.catalog_object.custom_attribute_values
		custom_attribute_list = list()
		if custom_attributes:
			for item in custom_attributes:
				product_attribute = ProductAttribute()
				if custom_attributes[item]["type"] == "STRING":
					product_attribute.attribute_value_name = custom_attributes[item]["string_value"]
				elif custom_attributes[item]["type"] == "NUMBER":
					product_attribute.attribute_value_name = custom_attributes[item]["number_value"]
				elif custom_attributes[item]["type"] == "BOOLEAN":
					product_attribute.attribute_value_name = custom_attributes[item]["boolean_value"]
				else:
					continue
				product_attribute.attribute_name = custom_attributes[item]["name"]
				product_attribute.attribute_type = custom_attributes[item]["type"]
				custom_attribute_list.append(product_attribute)
		if len(custom_attribute_list) > 0:
			data_insert_map["attributes"] = custom_attribute_list
		self._extend_product_map = data_insert_map
		return Response().success(product_import.catalog_object.id)


	def extend_data_insert_map_product(self):
		extend = super().extend_data_insert_map_product()
		return extend


	def check_and_create_new_option(self, option_get, option_main):
		for attribute_value in option_main.option_values:
			option_val = option_get.item_option_data.get("values")
			option_val_list = list()
			for val in option_val:
				option_val_list.append(val["item_option_value_data"]["name"])
			if attribute_value not in option_val_list:
				create_value = self.upsert_option(option_get, attribute_value)
				if not create_value:
					return Response().error(msg = "Create new value failed!")
				continue
			else:
				continue
		return Response().success()


	def upsert_option(self, option_get, option_value):
		data_upsert = {
			"batches": [
				{
					"objects": [
						{
							"type": "ITEM_OPTION_VAL",
							"id": f"#{random_string(16)}",
							"item_option_value_data": {
								"name": option_value,
								"item_option_id": option_get.id
							}
						}
					]
				}
			],
			"idempotency_key": to_str(uuid.uuid4())
		}
		create_option_value = self.api('catalog/batch-upsert', data = data_upsert, method = "post")
		if self._last_status != 200:
			return False
		return True


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		squarepos_product = self._last_product
		squarepos_product = squarepos_product.catalog_object
		self._last_product = None
		images = self.extend_images(product)
		square_pos_images = dict()
		get_product_import = self.api(f'catalog/object/{squarepos_product.id}')
		# Initiate Post data
		if product.variants:
			for index, variant in enumerate(get_product_import.object.item_data.variations):
				qty_no_manage_stock = self._state.channel.config.setting.qty.no_manage_stock_qty if self._state.channel.config.setting and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.no_manage_stock_qty else 999
				list_inventory_variant = list()
				variant_index = product.variants[index]
				if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
					inventories = self.to_variant_inventory(variant_index)
					if len(inventories) > 0:
						for inventory in inventories:
							ivt = self.set_inventory(variant.id, inventory["quantity"], inventory["location_id"])
							inventory_variant = {
								"qty": inventory["quantity"],
								"location_id": inventory["location_id"]
							}
							list_inventory_variant.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_variant]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								list_inventory_variant.append(inventory_variant)
					else:
						ivt = self.set_inventory(variant.id, variant_index.qty if variant_index.manage_stock else qty_no_manage_stock, self.get_location_default_id())
						inventory_variant = {
							"qty": variant_index.qty if variant_index.manage_stock else qty_no_manage_stock,
							"location_id": self.get_location_default_id()
						}
						list_inventory_variant.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_variant]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								list_inventory_variant.append(inventory_variant)
				elif not self.is_channel_default():
					ivt = self.set_inventory(variant.id, variant_index.qty if variant_index.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": variant_index.qty if variant_index.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_variant.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_variant]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_variant.append(inventory_variant)
				else:
					inventory = self.set_inventory(variant.id, variant_index.qty if variant_index.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": variant_index.qty if variant_index.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_variant.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_variant]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_variant.append(inventory_variant)
				self.insert_map_product(variant_index, variant_index['_id'], variant.id, api_version = variant.version, square_locations = list_inventory_variant, variant_square_id = variant.id)
		thumb_image = ""
		if len(images) > 0:
			thumb_image = images[0]
		if not thumb_image:
			return Response().success()
		for index, image in enumerate(images):
			if image.startswith("//i0.wp.com/"):
				image = to_str(image).replace("//i0.wp.com/", "https://")
			elif image.startswith("https://i0.wp.com/"):
				image = to_str(image).replace("https://i0.wp.com/", "https://")
			if index == 0:
				upload_image = self.upload_images(squarepos_product.id, image, True)
			else:
				upload_image = self.upload_images(squarepos_product.id, image)
			if upload_image.result != "success":
				return Response().error(msg = upload_image.msg)
		if not product.variants:
			variant_default = squarepos_product['item_data']['variations'][0]['id']
			for index, image in enumerate(images):
				if index == 0:
					upload_image = self.upload_images(variant_default, image, True)
				else:
					upload_image = self.upload_images(variant_default, image)
				if upload_image.result != "success":
					return Response().error(msg = upload_image.msg)
			return Response().success()
		for index, variant in enumerate(squarepos_product.item_data.variations):
			variant_index = product.variants[index]
			image = variant_index.thumb_image.url
			if image:
				upload_image = self.upload_images(variant["id"], image, True)
			else:
				upload_image = self.upload_images(variant["id"], thumb_image, True)
			if upload_image.result != "success":
				return Response().error(msg = upload_image.msg)
		return Response().success()


	def search_batches(self, query, object_type):
		body = {
			"object_types": [
				f"{object_type}"
			],
			"query": query,
			"limit": 100
		}
		search = self.api('catalog/search', data = body, method = "post")
		return search.objects[0] if search.get("objects", {}) else {}


	def clear_image(self, list_image_id):
		for image_id in list_image_id:
			delete_images = self.api(f"catalog/object/{image_id}", method = "delete")
			if self._last_status != 200:
				return Response().error(msg = delete_images.errors[0].detail if delete_images else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		# self.channel_sync_inventory(product_id, product, products_ext)
		# location_default = self.get_location_default_id()
		# return Response().error(msg = "test")
		product_data, category_data = self.to_product_simple_data(product, product_id)
		if not product.variants:
			qty_no_manage_stock = self._state.channel.config.setting.qty.no_manage_stock_qty if self._state.channel.config.setting and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.no_manage_stock_qty else 999
			list_inventory_simple = list()
			variant_data = self.product_to_squarepos_variant_data(product, product, product_id = product_id, default = product.variant_default_id)
			product_data['object']['item_data']['variations'] = [variant_data]
			update_variant = self.api('catalog/object', product_data, method = "post")
			if self._last_status != 200:
				return Response().error(msg = update_variant.errors[0].detail if update_variant else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
			self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.api_version', update_variant.catalog_object.version)
			if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
				inventories = self.to_variant_inventory(product)
				if len(inventories) > 0:
					for inventory in inventories:
						ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], inventory["quantity"], inventory["location_id"])
						inventory_variant = {
							"qty": inventory["quantity"],
							"location_id": inventory["location_id"]
						}
						list_inventory_simple.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_simple]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_simple.append(inventory_variant)
				else:
					list_invent = product.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
					if list_invent:
						for inventory in list_invent:
							ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], inventory["qty"], inventory["location_id"])
					else:
						ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
						inventory_variant = {
							"qty": product.qty if product.manage_stock else qty_no_manage_stock,
							"location_id": self.get_location_default_id()
						}
						list_inventory_simple.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_simple]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								list_inventory_simple.append(inventory_variant)
			elif not self.is_channel_default():
				list_invent = product.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
				if list_invent:
					for inventory in list_invent:
						ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], inventory["qty"], inventory["location_id"])
				else:
					ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": product.qty if product.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_simple.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_simple]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_simple.append(inventory_variant)
			else:
				list_invent = product.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
				if list_invent:
					for inventory in list_invent:
						ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], inventory["qty"], inventory["location_id"])
				else:
					ivt = self.set_inventory(update_variant.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": product.qty if product.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_simple.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_simple]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_simple.append(inventory_variant)
			self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.square_locations', list_inventory_simple)
			get_product_after_update = self.get_product_detail(product_id)
			if get_product_after_update.object.item_data.image_ids:
				list_image_id = get_product_after_update.object.item_data.image_ids
				clear_images = self.clear_image(list_image_id)
				if clear_images.result != "success":
					return Response().error(msg = "Clear images failed")
			images = self.extend_images(product)
			square_pos_images = dict()
			thumb_image = ""
			if len(images) > 0:
				thumb_image = images[0]
			if not thumb_image:
				return Response().success()
			for index, image in enumerate(images):
				if index == 0:
					upload_image = self.upload_images(get_product_after_update.object.id, image, True)
				else:
					upload_image = self.upload_images(get_product_after_update.object.id, image)
				if upload_image.result != "success":
					return Response().error(msg = upload_image.msg)
			list_image_variant_id = list()
			if get_product_after_update.object.item_data.variations:
				for variant in get_product_after_update.object.item_data.variations:
					if variant.image_ids:
						variant_image = variant.image_ids
						if len(variant_image) > 0:
							for img_id in variant_image:
								list_image_variant_id.append(img_id)
				if len(list_image_variant_id) > 0:
					clear_images = self.clear_image(list_image_variant_id)
					if clear_images.result != "success":
						return Response().error(msg = "Clear images failed")
			return Response().success()
		for index, variant in enumerate(product.variants):
			qty_no_manage_stock = qty_no_manage_stock = self._state.channel.config.setting.qty.no_manage_stock_qty if self._state.channel.config.setting and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.no_manage_stock_qty else 999
			variant_post_data = {
				"idempotency_key": to_str(uuid.uuid4())
			}
			list_inventory_variant = list()
			variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id') or variant.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id')
			list_create_option = list()
			if not variant_id:
				for attr in variant.attributes:
					query = {
						"prefix_query": {
							"attribute_name": "name",
							"attribute_prefix": f"{attr.attribute_name}"
						}
					}
					option_search = self.search_batches(query, "ITEM_OPTION")
					create_value_option = self.upload_new_option_values_update(option_search, attr.attribute_value_name)
					list_create_option.append(create_value_option)
				variant_data = self.product_to_squarepos_variant_data(variant, product, list_create_option, product_id = product_id, update = True)
				variant_post_data["batches"] = [{
					"objects": [variant_data]
				}]
				create_variant = self.api(f'catalog/batch-upsert', variant_post_data)
				if self._last_status != 200:
					return Response().error(msg = create_variant.errors[0].detail if create_variant else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
				if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
					inventories = self.to_variant_inventory(variant)
					if len(inventories) > 0:
						for inventory in inventories:
							ivt = self.set_inventory(create_variant.objects[0].id, inventory["quantity"], inventory["location_id"])
							inventory_variant = {
								"qty": inventory["quantity"],
								"location_id": inventory["location_id"]
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									list_inventory_variant.append(inventory_variant)
					else:
						list_invent = variant.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
						if list_invent:
							for inventory in list_invent:
								ivt = self.set_inventory(create_variant.objects[0].id, inventory["qty"], inventory["location_id"])
						else:
							ivt = self.set_inventory(create_variant.objects[0].id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
							inventory_variant = {
								"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									list_inventory_variant.append(inventory_variant)
				elif not self.is_channel_default():
					list_invent = variant.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
					if list_invent:
						for inventory in list_invent:
							ivt = self.set_inventory(create_variant.objects[0].id, inventory["qty"], inventory["location_id"])
					else:
						ivt = self.set_inventory(create_variant.objects[0].id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
						inventory_variant = {
							"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
							"location_id": self.get_location_default_id()
						}
						list_inventory_variant.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_variant]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								list_inventory_variant.append(inventory_variant)
				else:
					ivt = self.set_inventory(create_variant.objects[0].id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_variant.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_variant]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							list_inventory_variant.append(inventory_variant)
				variant_index = product.variants[index]
				self.insert_map_product(variant_index, variant_index['_id'], variant.item_data.variations[0].id)
				continue
			else:
				for attr in variant.attributes:
					query = {
						"prefix_query": {
							"attribute_name": "name",
							"attribute_prefix": f"{attr.attribute_name}"
						}
					}
					option_search = self.search_batches(query, "ITEM_OPTION")
					list_create_option.append(option_search)
				variant_data = self.product_to_squarepos_variant_data(variant, product, list_create_option, product_id = product_id, update = True)
				variant_post_data["batches"] = [{
					"objects": [variant_data]
				}]
				update_variant = self.api(f'catalog/batch-upsert', variant_post_data, "post")
				if self._last_status != 200:
					return Response().error(msg = update_variant.errors[0].detail if update_variant else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
				self.get_model_catalog().update_field(variant['_id'], f'channel.channel_{self.get_channel_id()}.api_version', update_variant.objects[0].version)
				if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
					inventories = self.to_variant_inventory(variant)
					if len(inventories) > 0:
						for inventory in inventories:
							ivt = self.set_inventory(update_variant.objects[0].id, inventory["quantity"], inventory["location_id"])
							inventory_variant = {
								"qty": inventory["quantity"],
								"location_id": inventory["location_id"]
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									list_inventory_variant.append(inventory_variant)
					else:
						list_invent = variant.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
						if list_invent:
							for inventory in list_invent:
								ivt = self.set_inventory(update_variant.objects[0].id, inventory["qty"], inventory["location_id"])
						else:
							ivt = self.set_inventory(update_variant.objects[0].id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
							inventory_variant = {
								"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									list_inventory_variant.append(inventory_variant)
				elif not self.is_channel_default():
					list_invent = variant.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
					if list_invent:
						for inventory in list_invent:
							ivt = self.set_inventory(update_variant.objects[0].id, inventory["qty"], inventory["location_id"])
					else:
						ivt = self.set_inventory(update_variant.objects[0].id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
						inventory_variant = {
							"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
							"location_id": self.get_location_default_id()
						}
						list_inventory_variant.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_variant]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								list_inventory_variant.append(inventory_variant)
				else:
					inventory = self.set_inventory(update_variant.objects[0].id, variant.qty, location_id = self.get_location_default_id())
					list_invent = variant.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
					if list_invent:
						for inventory in list_invent:
							ivt = self.set_inventory(update_variant.objects[0].id, inventory["qty"], inventory["location_id"])
					else:
						ivt = self.set_inventory(update_variant.objects[0].id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
						inventory_variant = {
							"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
							"location_id": self.get_location_default_id()
						}
						list_inventory_variant.append(inventory_variant)
			self.get_model_catalog().update_field(variant['_id'], f'channel.channel_{self.get_channel_id()}.square_locations', list_inventory_variant)
		after_update = self.get_product_detail(product_id)
		if self._last_status != 200:
			return Response().error(msg = after_update.errors[0].detail if after_update else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
		after_update.object.item_data.description_html = to_str(product.description[:65535])
		after_update.object.item_data.name = to_str(product.name[:235])
		category_template = product.get('template_data', {}).get('category')
		if category_template and category_template.category_id:
			after_update.object.item_data.category_id = category_template.category_id
		after_update = after_update.object
		data_update = {"idempotency_key": to_str(uuid.uuid4()), "batches": [
			{
				"objects": [after_update]
			}
		]}
		update_simple_info = self.api(f'catalog/batch-upsert', data_update, "post")
		if self._last_status != 200:
			return Response().error(msg = update_simple_info.errors[0].detail if update_simple_info else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
		get_product_after_update = self.get_product_detail(product_id)
		if get_product_after_update.object.item_data.image_ids:
			list_image_id = get_product_after_update.object.item_data.image_ids
			clear_images = self.clear_image(list_image_id)
			if clear_images.result != "success":
				return Response().error(msg = "Clear images failed")
		images = self.extend_images(product)
		square_pos_images = dict()
		if len(images) > 0:
			thumb_image = images[0]
		else:
			return Response().success()
		for index, image in enumerate(images):
			if index == 0:
				upload_image = self.upload_images(get_product_after_update.object.id, image, True)
			else:
				upload_image = self.upload_images(get_product_after_update.object.id, image)
			if upload_image.result != "success":
				return Response().error(msg = upload_image.msg)
		list_image_variant_id = list()
		if get_product_after_update.object.item_data.variations:
			for variant in get_product_after_update.object.item_data.variations:
				if variant.image_ids:
					variant_image = variant.image_ids
					if len(variant_image) > 0:
						for img_id in variant_image:
							list_image_variant_id.append(img_id)
			if len(list_image_variant_id) > 0:
				clear_images = self.clear_image(list_image_variant_id)
				if clear_images.result != "success":
					return Response().error(msg = "Clear images failed")
		if product.variants:
			for index, variant in enumerate(get_product_after_update.object.item_data.variations):
				variant_index = product.variants[index]
				image = variant_index.thumb_image.url
				if image:
					upload_image = self.upload_images(variant["id"], image, True)
				else:
					upload_image = self.upload_images(variant["id"], thumb_image, True)
				if upload_image.result != "success":
					return Response().error(msg = upload_image.msg)

		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		qty_no_manage_stock = self._state.channel.config.setting.qty.no_manage_stock_qty if self._state.channel.config.setting and self._state.channel.config.setting.qty and self._state.channel.config.setting.qty.no_manage_stock_qty else 999
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		get_product = self.get_product_by_id(product_id)
		if get_product.result != Response.SUCCESS:
			return Response().success()
		product_data = get_product.data
		if not product.variants:
			list_inventory_simple = list()
			if setting_qty:
				if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
					inventories = self.to_variant_inventory(product)
					if len(inventories) > 0:
						for inventory in inventories:
							ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], inventory["quantity"], inventory["location_id"])
							inventory_variant = {
								"qty": inventory["quantity"],
								"location_id": inventory["location_id"]
							}
							list_inventory_simple.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_simple]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], 0, location_object.id)
								list_inventory_simple.append(inventory_variant)
					else:
						list_invent = product.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
						if list_invent:
							for inventory in list_invent:
								ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], inventory["qty"], inventory["location_id"])
						else:
							ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
							inventory_variant = {
								"qty": product.qty if product.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_simple.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_simple]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], 0, location_object.id)
									list_inventory_simple.append(inventory_variant)
				elif not self.is_channel_default():
					list_invent = product.channel[f'channel_{self.get_channel_id()}'].get('square_locations', {})
					if list_invent:
						for inventory in list_invent:
							ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], inventory["qty"], inventory["location_id"])
					else:
						ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
						inventory_variant = {
							"qty": product.qty if product.manage_stock else qty_no_manage_stock,
							"location_id": self.get_location_default_id()
						}
						list_inventory_simple.append(inventory_variant)
						list_inventory_id = [location["location_id"] for location in list_inventory_simple]
						locations = self.get_locations()
						for location_object in locations:
							if location_object.id not in list_inventory_id:
								inventory_variant = {
									"qty": 0,
									"location_id": location_object.id
								}
								ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], 0, location_object.id)
								list_inventory_simple.append(inventory_variant)
				else:
					ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], product.qty if product.manage_stock else qty_no_manage_stock, self.get_location_default_id())
					inventory_variant = {
						"qty": product.qty if product.manage_stock else qty_no_manage_stock,
						"location_id": self.get_location_default_id()
					}
					list_inventory_simple.append(inventory_variant)
					list_inventory_id = [location["location_id"] for location in list_inventory_simple]
					locations = self.get_locations()
					for location_object in locations:
						if location_object.id not in list_inventory_id:
							inventory_variant = {
								"qty": 0,
								"location_id": location_object.id
							}
							ivt = self.set_inventory(product_data.catalog_object.item_data.variations[0]['id'], 0, location_object.id)
							list_inventory_simple.append(inventory_variant)
				self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.square_locations', list_inventory_simple)
			if setting_price:
				product_data_simple = self.to_product_simple_data(product, product_id)
				variant_data = self.product_to_squarepos_variant_data(product, product, product_id = product_id, default = product.variant_default_id)
				product_data['object']['item_data']['variations'] = [variant_data]
				update_variant = self.api('catalog/object', product_data_simple, method = "post")
				if self._last_status != 200:
					return Response().error(msg = update_variant.errors[0].detail if update_variant else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
			return Response().success()
		for index, variant in enumerate(product.variants):
			variant_post_data = {
				"idempotency_key": to_str(uuid.uuid4())
			}
			list_inventory_variant = list()
			if len(product.variant_attributes) == 1:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id') or variant.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id')
				if not variant_id:
					continue
				else:
					if setting_price:
						variant_data = self.product_to_squarepos_variant_data(variant, product, product_id = product_id, update = True)
						variant_post_data["batches"] = [{
							"objects": [variant_data]
						}]
						update_variant = self.api(f'catalog/batch-upsert', variant_post_data, method = 'post')
						if self._last_status != 200:
							return Response().error(msg = update_variant.errors[0].detail if update_variant else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))

					if setting_qty:
						if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
							inventories = self.to_variant_inventory(variant)
							if len(inventories) > 0:
								for inventory in inventories:
									ivt = self.set_inventory(variant_id, inventory["quantity"], inventory["location_id"])
									inventory_variant = {
										"qty": inventory["quantity"],
										"location_id": inventory["location_id"]
									}
									list_inventory_variant.append(inventory_variant)
								list_inventory_id = [location["location_id"] for location in list_inventory_variant]
								locations = self.get_locations()
								for location_object in locations:
									if location_object.id not in list_inventory_id:
										inventory_variant = {
											"qty": 0,
											"location_id": location_object.id
										}
										ivt = self.set_inventory(variant_id, 0, location_object.id)
										list_inventory_variant.append(inventory_variant)
							else:
								ivt = self.set_inventory(variant_id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
								inventory_variant = {
									"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
									"location_id": self.get_location_default_id()
								}
								list_inventory_variant.append(inventory_variant)
								list_inventory_id = [location["location_id"] for location in list_inventory_variant]
								locations = self.get_locations()
								for location_object in locations:
									if location_object.id not in list_inventory_id:
										inventory_variant = {
											"qty": 0,
											"location_id": location_object.id
										}
										ivt = self.set_inventory(variant_id, 0, location_object.id)
										list_inventory_variant.append(inventory_variant)
						elif not self.is_channel_default():
							ivt = self.set_inventory(variant_id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
							inventory_variant = {
								"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									ivt = self.set_inventory(variant_id, 0, location_object.id)
									list_inventory_variant.append(inventory_variant)
						else:
							inventory = self.set_inventory(variant_id, variant.qty if variant.manage_stock else qty_no_manage_stock, location_id = self.get_location_default_id())
							inventory_variant = {
								"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									ivt = self.set_inventory(variant_id, 0, location_object.id)
									list_inventory_variant.append(inventory_variant)
						continue
			else:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id') or variant.channel[f'channel_{self.get_channel_id()}'].get('variant_square_id')
				list_create_option = list()
				if not variant_id:
					continue
				else:
					if setting_price:
						for attr in variant.attributes:
							query = {
								"prefix_query": {
									"attribute_name": "name",
									"attribute_prefix": f"{attr.attribute_name}"
								}
							}
							option_search = self.search_batches(query, "ITEM_OPTION")
							list_create_option.append(option_search)
						variant_data = self.product_to_squarepos_variant_data(variant, product, list_create_option, product_id = product_id, update = True)
						variant_post_data["batches"] = [{
							"objects": [variant_data]
						}]
						update_variant = self.api(f'catalog/batch-upsert', variant_post_data, "post")
						if self._last_status != 200:
							return Response().error(msg = update_variant.errors[0].detail if update_variant else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))
					if setting_qty:
						if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
							inventories = self.to_variant_inventory(variant)
							if len(inventories) > 0:
								for inventory in inventories:
									ivt = self.set_inventory(variant_id, inventory["quantity"], inventory["location_id"])
									inventory_variant = {
										"qty": inventory["quantity"],
										"location_id": inventory["location_id"]
									}
									list_inventory_variant.append(inventory_variant)
									list_inventory_id = [location["location_id"] for location in list_inventory_variant]
									locations = self.get_locations()
									for location_object in locations:
										if location_object.id not in list_inventory_id:
											inventory_variant = {
												"qty": 0,
												"location_id": location_object.id
											}
											ivt = self.set_inventory(variant_id, 0, location_object.id)
											list_inventory_variant.append(inventory_variant)
							else:
								ivt = self.set_inventory(variant_id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
								inventory_variant = {
									"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
									"location_id": self.get_location_default_id()
								}
								list_inventory_variant.append(inventory_variant)
								list_inventory_id = [location["location_id"] for location in list_inventory_variant]
								locations = self.get_locations()
								for location_object in locations:
									if location_object.id not in list_inventory_id:
										inventory_variant = {
											"qty": 0,
											"location_id": location_object.id
										}
										ivt = self.set_inventory(variant_id, 0, location_object.id)
										list_inventory_variant.append(inventory_variant)
						elif not self.is_channel_default():
							ivt = self.set_inventory(variant_id, variant.qty if variant.manage_stock else qty_no_manage_stock, self.get_location_default_id())
							inventory_variant = {
								"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									ivt = self.set_inventory(variant_id, 0, location_object.id)
									list_inventory_variant.append(inventory_variant)
						else:
							inventory = self.set_inventory(variant_id, variant.qty if variant.manage_stock else qty_no_manage_stock, location_id = self.get_location_default_id())
							inventory_variant = {
								"qty": variant.qty if variant.manage_stock else qty_no_manage_stock,
								"location_id": self.get_location_default_id()
							}
							list_inventory_variant.append(inventory_variant)
							list_inventory_id = [location["location_id"] for location in list_inventory_variant]
							locations = self.get_locations()
							for location_object in locations:
								if location_object.id not in list_inventory_id:
									inventory_variant = {
										"qty": 0,
										"location_id": location_object.id
									}
									ivt = self.set_inventory(variant_id, 0, location_object.id)
									list_inventory_variant.append(inventory_variant)
		return Response().success()


	def delete_product_import(self, product_id):
		remove = self.api(f'catalog/object/{product_id}', None, 'delete')
		return Response().success()


	# 	def get_options_from_variants(self, variants):
	# 		options = {}
	# 		position = 1
	# 		for variant in variants:
	# 			for attribute in variant.attributes:
	# 				if not attribute.use_variant:
	# 					continue
	# 				attribute_name = to_str(attribute.attribute_name).replace('/', '-')
	# 				if attribute_name not in options.keys():
	# 					options[attribute_name] = {
	# 						'values': [attribute.attribute_value_name],
	# 						'position': position
	# 					}
	# 					position += 1
	# 				elif attribute.attribute_value_name not in options[attribute_name]['values']:
	# 					options[attribute_name]['values'].append(attribute.attribute_value_name)
	#
	# 		return options
	#
	#
	# orders
	def get_order_by_id(self, order_id):
		order = self.api(f'orders/{order_id}')
		if self._last_status != 200:
			return Response().error()
		return Response().success(order.order)


	def get_orders_main_export(self):
		if self._flag_finish_order:
			return Response().finish()
		body = {"query": {
			"filter": {
				"date_time_filter": {
				}
			}
		},
			"limit": 500
		}
		next_cursor = self._state.pull.process.orders.next_cursor
		if next_cursor:
			body['cursor'] = next_cursor
		else:
			start_time = self.get_order_start_time(self.FORMAT_DATE)
			last_modifier = self._state.pull.process.orders.max_last_modified
			body["query"]["filter"]["date_time_filter"]["created_at"] = {}
			body["query"]["filter"]["date_time_filter"]["created_at"]["start_at"] = start_time
			body["query"]["filter"]["date_time_filter"]["created_at"]["end_at"] = get_current_time(self.FORMAT_DATE)
			if last_modifier:
				del body["query"]["filter"]["date_time_filter"]["created_at"]
				body["query"]["filter"]["date_time_filter"]["update_at"] = {}
				body["query"]["filter"]["date_time_filter"]["update_at"]["start_at"] = last_modifier
				body["query"]["filter"]["date_time_filter"]["update_at"]["end_at"] = get_current_time(self.FORMAT_DATE)
		list_location = list()
		if self._state.channel.config.setting.qty.locations_mapping:
			locations = self._state.channel.config.setting.qty.locations_mapping
			for location in locations:
				if location["channel"]:
					list_location.append(location["channel"]["location_id"])
		if len(list_location) > 0:
			body["location_ids"] = list_location
		else:
			body["location_ids"] = self.get_all_locations()
		orders = self.api('orders/search', data = body, method = "post")
		if not orders or not orders.orders:
			return Response().finish()
		if not orders.get("cursor", {}):
			self._flag_finish_order = True
		else:
			self._state.pull.process.orders.next_cursor = orders.orders.cursor
		return Response().success(data = orders.orders)


	def get_orders_ext_export(self, orders):
		return Response().success()


	#
	#
	def order_import(self, order: Order, convert: Order, orders_ext):
		order_data = {
			"reference_id": convert.channel_order_number or convert.order_number,
			"location_id": self.get_location_default_id(),
			"line_items": list()
		}
		fulfilled_date = get_current_time(self.FORMAT_DATE)
		# order_data['shippingLines'] = [
		# 	{
		# 		"method": convert.shipping.method or convert.shipping.title or 'shipping',
		# 		"amount": {
		# 			"currency": self.get_currency_location(self.get_location_default_id()),
		# 			"value": to_str(convert.shipping.amount or 0)
		# 		}
		# 	}
		# ]
		if convert.shipping.amount:
			order_data['service_charges'] = [{
				"uid": to_str(uuid.uuid4()),
				"name": 'shipping',
				"amount_money": {
					"currency": self.get_currency_location(self.get_location_default_id()),
					"amount": to_int(convert.shipping.amount)
				},
				"calculation_phase": "TOTAL_PHASE"
			}]
		if convert.discount.amount:
			order_data['discounts'] = [
				{
					"uid": convert.discount.code or to_str(uuid.uuid4()),
					"name": convert.discount.title or 'discount',
					"amount_money": {
						"currency": self.get_currency_location(self.get_location_default_id()),
						"amount": to_int(convert.discount.amount)
					},
					"scope": "ORDER"
				}
			]
		if convert.tax.amount:
			order_data['taxes'] = [
				{
					"uid": to_str(uuid.uuid4()),
					"name": 'taxes',
					"amount_money": {
						"currency": self.get_currency_location(self.get_location_default_id()),
						"amount": to_int(convert.tax.amount)
					},
					"scope": "ORDER"
				}
			]
		order_data['fulfillments'] = [
			{
				"type": "SHIPMENT",
				"shipment_details": {
					"recipient": {
						"display_name": convert.shipping_address.last_name,
						"email_address": convert.customer.email if convert.customer.email else "sly@litcommerce.com",
						"phone_number": convert.billing_address.telephone,
						"address": {
							"first_name": convert.shipping_address.first_name,
							"last_name": convert.shipping_address.last_name,
							"address_line_1": convert.shipping_address.address_1 or convert.shipping_address.address_2 or convert.shipping_address.country or 'address1',
							"locality": convert.shipping_address.city,
							"state": convert.shipping_address.state.state_code,
							"country": convert.shipping_address.country.country_code,
							"postal_code": convert.shipping_address.postcode,
						}
					},
					"carrier": self.get_tracking_company_mapping(convert.shipments.tracking_company),
					"tracking_number": convert.shipments.tracking_number,
					"tracking_url": convert.shipments.tracking_url or "https://app.litcommerce.com",
					"shipping_type": "Priority" if convert.shipments.tracking_number else "",
					"shipped_at": self.get_time_LA()
				}}
		]
		try:
			if convert.status == Order.COMPLETED:
				order_data['fulfillments'][0]['state'] = "COMPLETED"
			elif convert.status == Order.CANCELED:
				order_data['fulfillments'][0]['state'] = "CANCELED"
			else:
				order_data['fulfillments'][0]['state'] = "PROPOSED"
			if convert.billing_address.telephone:
				order_data['fulfillments'][0]['shipment_details']['phone'] = convert.billing_address.telephone
			if convert.customer.email:
				order_data['fulfillments'][0]['shipment_details']['email_address'] = convert.customer.email
		except:
			self.log_traceback()
		for product in convert.products:
			product_id = None
			variant_id = None
			if product['product_id'] and product['parent_id']:
				variant_id = product['product_id']
				product_id = product['parent_id']
			else:
				product_id = product['product_id']
			product_data = {
				"catalog_object_id": variant_id or product.product.channel[f"channel_{self.get_channel_id()}"]['variant_default_id'],
				"quantity": to_str(product.qty),
				"base_price_money": {
					"currency": self.get_currency_location(self.get_location_default_id()),
					"amount": to_int(product.price * self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))
				}
			}
			order_data['line_items'].append(product_data)
		body = {
			"idempotency_key": to_str(uuid.uuid4()),
			"order": order_data
		}
		response = self.api("orders", body, method = "post")
		if self._last_status != 200:
			return Response().error(msg = f"{response.errors[0].detail}: {response.errors[0].field}" if response.errors else Errors().get_msg_error(Errors.SQUAREPOS_API_INVALID))

		order_return = {
			'order_id': response.order.id,
			'order_status': response.order.state,
			'order_number': response.order.id,
			'created_at': self.get_time_LA(),
		}
		return Response().success([response.order.id, order_return])


	def get_create_location(self, channel_id):
		if not self.is_channel_default():
			return False
		setting = self.get_channel_setting(channel_id)
		if not setting or not setting.get('qty') or not setting['qty'].get('create_location_square'):
			return False
		return setting['qty']['create_location_square'].get('location_id')


	def get_location_default_id(self):
		if self._state.channel.config.setting.get('qty') and self._state.channel.config.setting.get('qty').get('square_locations'):
			square_locations = self._state.channel.config.setting.get('qty').get('square_locations')
			for location in square_locations:
				if location["is_default"]:
					return location["location_id"]
		location_default = self.api('locations')
		return location_default.locations[0].id


	def get_time_LA(self):
		utcmoment_naive = datetime.utcnow()
		utcmoment = utcmoment_naive.replace(tzinfo = pytz.utc)
		local_format = "%Y-%m-%dT%H:%M:%S.000Z"
		tz = 'America/Los_Angeles'
		local_datetime = utcmoment.astimezone(pytz.timezone(tz))
		return local_datetime.strftime(local_format)


	def get_currency_location(self, location_id):
		location_info = self.api(f"locations/{location_id}")
		return location_info.location.currency


	def set_inventory(self, item_id, qty, location_id = None):
		if not location_id:
			location_id = self.get_location_id()
		ivt_data = {
			"idempotency_key": to_str(uuid.uuid4()),
			"changes": [
				{
					"type": "PHYSICAL_COUNT",
					"physical_count": {
						"reference_id": to_str(uuid.uuid4()),
						"catalog_object_id": to_str(item_id),
						"state": "IN_STOCK",
						"location_id": to_str(location_id),
						"quantity": to_str(qty),
						"occurred_at": self.get_time_LA()
					}
				}
			],
			"ignore_unchanged_counts": True
		}
		inventory = self.api('inventory/changes/batch-create', ivt_data, 'post')
		return inventory


	def get_location_id(self):
		if self._state.channel.config.api.location_id:
			return self._state.channel.config.api.location_id
		if self._location_id:
			return self._location_id
		location = self.api('locations')
		try:
			# for location_data in location['locations']:
			# 	if location_data['active']:
			# 		self._location_id = location_data['id']
			if not self._location_id:
				self._location_id = location['locations'][0]['id']
		except Exception as e:
			self.log_traceback()
			self._location_id = None
		return self._location_id


	def log_response(self, log_data, log_name: str) -> None:
		self.log(log_data, log_name)


	def channel_order_completed(self, order_id, order: Order, current_order):
		try:
			square_order = self.get_order_by_id(order_id)
			tracking_number = order.shipments.get("tracking_number")
			tracking_company = to_str(order.shipments.get("tracking_company"))
			tracking_url = to_str(order.shipments.get("tracking_url"))
			self.log_response(square_order, "square_order_ff")
			self.log_response(order, "order_ff")

			if square_order.result == Response().SUCCESS:
				square_order_data = square_order.get("data")
				square_order_status = square_order_data.get('state')
				if to_str(square_order_status) == "COMPLETED":
					return Response().success({'status': Order.COMPLETED})
				body_payment = {
					"idempotency_key": to_str(uuid.uuid4()),
					"source_id": "EXTERNAL",
					"external_details": {
						"type": "OTHER",
						"source": "PAID"
					},
					"amount_money": {
						"amount": order.total,
						"currency": self.get_currency_location(self.get_location_default_id())
					},
					"autocomplete": True,
					"location_id": square_order_data.location_id,
					"reference_id": random_string(8),
					"note": "",
					"order_id": order_id
				}
				update_payment_completed = self.api('payments', data = body_payment, method = "post")
				square_order = self.get_order_by_id(order_id)
				square_order_data = square_order.get("data")
				square_order_data["version"] = 4
				square_order_data["state"] = "COMPLETED"
				if square_order_status == "OPEN" and not square_order_data['fulfillments']:
					body = {
						"idempotency_key": to_str(uuid.uuid4()),
						"order": square_order_data
					}
					body["order"]["fulfillments"] = [{
						"type": "SHIPMENT",
						"state": "COMPLETED",
						"shipment_details": {
							"recipient": {
								"display_name": order.customer.last_name,
								"email_address": order.customer.email,
								"phone_number": order.shipping_address.telephone,
								"address": {
									"address_line_1": order.shipping_address.address_1,
									"locality": order.shipping_address.city,
									"postal_code": order.shipping_address.postcode,
									"country": order.shipping_address.country.country_code,
									"first_name": order.customer.first_name,
									"last_name": order.customer.last_name
								}
							},
							"placed_at": get_current_time(self.FORMAT_DATE),
							"packaged_at": get_current_time(self.FORMAT_DATE),
							"shipped_at": get_current_time(self.FORMAT_DATE),
							"in_progress_at": get_current_time(self.FORMAT_DATE),
							"carrier": self.get_tracking_company_mapping(tracking_company),
							"tracking_number": tracking_number,
							"tracking_url": tracking_url if tracking_url else "https://app.litcommerce.com",
							"shipping_type": "Priority" if tracking_number else "",
							"shipping_note": ""
						}
					}]
					update_fulfillment = self.api(f'orders/{order_id}', data = body, method = "put")
					self.log_response({"body": body, "res": update_fulfillment}, "square_fulfill_response")

				else:
					square_order_data["fulfillments"][0]["state"] = "COMPLETED"
					if square_order_data["fulfillments"][0]["shipment_details"]:
						square_order_data["fulfillments"][0]["shipment_details"]["tracking_url"] = tracking_url if tracking_url else "https://app.litcommerce.com"
						square_order_data["fulfillments"][0]["shipment_details"]["tracking_number"] = tracking_number
						square_order_data["fulfillments"][0]["shipment_details"]["shipping_type"] = "Priority" if tracking_number else ""
						square_order_data["fulfillments"][0]["shipment_details"]["carrier"] = self.get_tracking_company_mapping(tracking_company)
						square_order_data["fulfillments"][0]["shipment_details"]["shipped_at"] = order.shipments.shipped_at or self.get_time_LA()
					body = {
						"idempotency_key": to_str(uuid.uuid4()),
						"order": square_order_data
					}
					update_fulfillment = self.api(f'orders/{order_id}', data = body, method = "put")
					self.log_response({"body": body, "res": update_fulfillment}, "square_fulfill_response")
				return Response().success({'status': Order.COMPLETED})
		except:
			self.log_traceback()
			return Response().error()


	def convert_order_status(self, status):
		order_status = {
			"OPEN": Order.OPEN,
			"COMPLETED": Order.COMPLETED,
			"CANCELED": Order.CANCELED,
		}
		return order_status.get(status, 'open') if status else 'open'


	def convert_time(self, time_data):
		return convert_format_time(time_data, "%Y-%m-%dT%H:%M:%S")


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.updated_at)
		order_create = to_timestamp(order.created_at, "%Y-%m-%dT%H:%M:%S.000Z")
		start_time = to_timestamp(self.get_order_start_time())

		if order_create < start_time:
			return Response().skip()
		order_data = Order()
		order_data.id = order.id
		order_data.order_number = order.id
		order_data.created_at = order.created_at
		order_data.updated_at = order.updated_at
		order_data.location_id = order.location_id
		order_status = "open"
		if order.state == 'COMPLETED':
			order_status = Order.COMPLETED
		elif order.state == 'CANCELED':
			order_status = Order.CANCELED
		if order.fulfillments and order.fulfillments[0].shipment_details and order.fulfillments[0].shipment_details.recipient.address:
			address = order.fulfillments[0].shipment_details.recipient.address
			customer_address = OrderAddress()
			order_data.customer.email = order.fulfillments[0].shipment_details.recipient.email_address if order.fulfillments[0].shipment_details.recipient.email_address else "guest@square.com"
			order_data.customer.first_name = address.first_name if address.first_name else "GUEST"
			order_data.customer.last_name = address.last_name if address.last_name else ""
			customer_address.country.country_code = address.country
			customer_address.state.state_name = address.country
			customer_address.first_name = address.first_name
			customer_address.last_name = address.last_name
			customer_address.city = address.locality
			customer_address.postcode = address.postal_code
			customer_address.telephone = order.fulfillments[0].shipment_details.recipient.phone_number
			customer_address.address_1 = address.address_line_1
			customer_address.address_2 = address.address_line_2
			order_data.customer_address.update(customer_address)
			order_data.billing_address.update(customer_address)
			order_data.shipping_address.update(customer_address)
			if order.fulfillments[0].shipping_note:
				order_history = OrderHistory()
				order_history.comment = order.fulfillments[0].shipping_note
				order_data.history.append(order_history)
			order_data.shipments.tracking_number = order.fulfillments[0].shipment_details.tracking_number if order.fulfillments[0].shipment_details.tracking_number else ""
			order_data.shipments.tracking_url = order.fulfillments[0].shipment_details.tracking_url if order.fulfillments[0].shipment_details.tracking_url else ""
			order_data.shipments.tracking_company_code = order.fulfillments[0].shipment_details.carrier if order.fulfillments[0].shipment_details.carrier else ""
			if order_data.shipments.tracking_number:
				order_data.shipments.tracking_company = order.fulfillments[0].shipment_details.carrier if order.fulfillments[0].shipment_details.carrier else ""
			if order.fulfillments[0].shipment_details.shipped_at:
				order_data.shipments.shipped_at = self.convert_time(order.fulfillments[0].shipment_details.shipped_at)
		order_data.status = order_status
		if order.total_service_charge_money:
			order_data.shipping.amount = to_decimal(order.total_service_charge_money.amount / 100)
		# if order.shippingLines:
		# 	order_data.shipping.title = order.shippingLines[0].method
		# 	order_data.shipping.method = order.shippingLines[0].method
		if order.total_discount_money and to_decimal(order.total_discount_money.amount):
			order_data.discount.amount = to_decimal(order.total_discount_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))
		if order.total_tax_money:
			order_data.tax.amount = to_decimal(order.total_tax_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))
		order_data.total = to_decimal(order.net_amount_due_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))

		# else:
		# 	if order.refundedTotal and to_decimal(order.refundedTotal.value):
		# 		order_status = Order.CANCELED
		# 	else:
		# 		order_status = Order.SHIPPING
		order_data.status = order_status
		order_data.channel_data = {
			'order_status': order.state,
			'created_at': order_data.created_at,
			'order_number': order_data.id,
			'shipped_date': self.convert_time(order.fulfillments[0].shipment_details.shipped_at) if order.fulfillments[0].shipment_details.shipped_at else "",
		}
		subtotal_order = 0
		for product in order.line_items:
			order_product = OrderProducts()
			get_detail = self.get_product_detail(product.catalog_object_id)
			if get_detail:
				for related in get_detail.related_objects:
					if related.type == "ITEM":
						order_product.listing_id = related.id
			if product.variation_name == "Regular":
				order_product.product_id = order_product.listing_id
			else:
				order_product.product_id = product.catalog_object_id
			order_product.location_id = order.location_id
			order_product.product_name = product.name + "-"
			order_product.product_sku = self.get_sku_attr(product.catalog_object_id)
			order_product.qty = to_int(product.quantity)
			order_product.tax_amount = (to_decimal(product.total_tax_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id()))))
			order_product.discount_amount = (to_decimal(product.total_discount_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id()))))
			order_product.price = to_decimal(product.base_price_money.amount / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id())))
			order_product.subtotal = to_decimal(order_product.qty * (order_product.price / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id()))))
			order_product.total = to_decimal(order_product.qty * (order_product.price / self.get_exponent_currency(self.get_currency_location(self.get_location_default_id()))))
			subtotal_order += order_product.total
			if product.variation_name and product.variation_name != "Regular":
				variant_values = product.variation_name.split(', ')
				option_list = self.get_value_attr(product.catalog_object_id)
				if len(option_list) > 0:
					for index, option in enumerate(variant_values):
						order_product.product_name += option + " / "
						product_option = OrderItemOption()
						product_option.option_name = option_list[index]
						product_option.option_value_name = option
						order_product.options.append(product_option)
			# if product.customizations:
			# 	for option in product.customizations:
			# 		product_option = OrderItemOption()
			# 		product_option.option_name = option.label
			# 		product_option.option_value_name = option.value
			# 		order_product.options.append(product_option)
			order_product.product_name = order_product.product_name.rstrip("-")
			order_product.product_name = order_product.product_name.rstrip("/")
			order_data.products.append(order_product)
		order_data.subtotal = to_decimal(subtotal_order)
		return Response().success(order_data)


	def get_sku_attr(self, variant_id):
		body = {
			"object_ids": [variant_id]
		}
		attr = self.api("catalog/batch-retrieve", data = body, method = "post")
		return attr.objects[0].item_variation_data.sku if attr.objects[0].item_variation_data.sku else ""


	def get_value_attr(self, variant_id):
		body = {
			"object_ids": [variant_id]
		}
		attr = self.api("catalog/batch-retrieve", data = body, method = "post")
		option_list = []
		if attr.objects[0].item_variation_data.item_option_values:
			for option in attr.objects[0].item_variation_data.item_option_values:
				body["object_ids"] = [option.item_option_id]
				option = self.api("catalog/batch-retrieve", data = body, method = "post")
				option_list.append(option.objects[0].item_option_data.display_name)
			return option_list
		return option_list


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	#
	#
	# 	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
	# 		if setting_order:
	# 			return Response().success()
	# 		return self._order_sync_inventory(order, '+')
	#
	#
	# 	def order_sync_inventory(self, convert: Order, setting_order):
	# 		if setting_order:
	# 			return Response().success()
	# 		return self._order_sync_inventory(convert)
	#
	#
	# 	def _order_sync_inventory(self, convert: Order, prefix = '-'):
	# 		if prefix == '-':
	# 			method = 'decrement'
	# 		else:
	# 			method = 'increment'
	# 		data = list()
	# 		for item in convert.products:
	# 			if item['product_id'] and item['parent_id']:
	# 				variant_id = item['product_id']
	# 				product_id = item['parent_id']
	# 			else:
	# 				variant_id = False
	# 				product_id = item['product_id']
	# 			row_qty = to_int(item['qty']) if to_int(item.qty) > 0 else 1
	#
	# 			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
	# 				data.append({
	# 					"variantId": variant_id or item.product.channel[f"channel_{self.get_channel_id()}"]['variant_default_id'],
	# 					"quantity": row_qty
	# 				})
	# 		idempotency_key = to_str(uuid.uuid4())
	#
	# 		update_qty = self.post_commerce(f"inventory/adjustments", {f"{method}Operations": data}, idempotency_key = idempotency_key)
	# 		return Response().success()
	#
	#
	# 	# if self._state['config']['img_des'] and post_data['product']['body_html']:
	# 	# 	theme_data = self.get_theme_data()
	# 	# 	if theme_data:
	# 	# 		check = False
	# 	# 		description = post_data['product']['body_html']
	# 	# 		match = re.findall(r"<img[^>]+>", to_str(description))
	# 	# 		links = list()
	# 	# 		if match:
	# 	# 			for img in match:
	# 	# 				img_src = re.findall(r"(src=[\"'](.*?)[\"'])", to_str(img))
	# 	# 				if not img_src:
	# 	# 					continue
	# 	# 				img_src = img_src[0]
	# 	# 				if img_src[1] in links:
	# 	# 					continue
	# 	# 				links.append(img_src[1])
	# 	# 		for link in links:
	# 	# 			# download and replace
	# 	# 			if self._state['src']['config'].get('auth'):
	# 	# 				link = self.join_url_auth(link)
	# 	# 			if to_int(theme_data['count']) >= 1500:
	# 	# 				theme_data = self.get_theme_data(True)
	# 	# 			if not theme_data:
	# 	# 				break
	# 	# 			if not self.image_exist(link):
	# 	# 				continue
	# 	# 			asset_post = self.process_assets_before_import(url_image = link, path = '', id_theme = theme_data['id'], name_image = convert['code'])
	# 	# 			asset_post = json_decode(asset_post)
	# 	# 			if asset_post and asset_post.get('asset'):
	# 	# 				self.update_theme_data(theme_data['count'])
	# 	# 				check = True
	# 	# 				description = to_str(description).replace(link, asset_post['asset']['public_url'])
	# 	# 		if check:
	# 	# 			product_update = {
	# 	# 				'product': {
	# 	# 					'body_html': description
	# 	# 				}
	# 	# 			}
	# 	# 			res = self.api('products/' + to_str(product_id) + '.json', product_update, 'PUT')
	#
	# 	def get_sizes(self, url):
	# 		req = Request(url, headers = {'User-Agent': get_random_useragent()})
	# 		try:
	# 			file = urlopen(req)
	# 		except:
	# 			self.log('image: ' + to_str(url) + ' 404', 'image_error')
	# 			return False, False
	# 		size = file.headers.get("content-length")
	# 		# date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
	# 		# type = file.headers.get('content-type')
	# 		if size: size = to_int(size)
	# 		p = ImageFile.Parser()
	# 		while 1:
	# 			data = file.read(1024)
	# 			if not data:
	# 				break
	# 			p.feed(data)
	# 			if p.image:
	# 				return size, p.image.size
	# 		file.close()
	# 		return size, False
	#
	#
	# 	def resize(self, url):
	# 		try:
	# 			r = False
	# 			retry = 0
	# 			while r is False and retry < 5:
	# 				try:
	# 					r = requests.get(url, headers = {'User-Agent': get_random_useragent()}, verify = False, timeout = 10)
	# 				except Exception as e:
	# 					time.sleep(2)
	# 					retry += 1
	# 					r = False
	# 			if not r or r.status_code != 200:
	# 				return False
	# 			return r.content
	# 		except Exception as e:
	# 			self.log_traceback('images', f"image error: {url}")
	#
	# 			return False
	#
	#
	# 	def check_response_import(self, response, convert, entity_type = ''):
	# 		entity_id = convert.id if convert.id else convert.code
	# 		if not response:
	# 			return Response().error()
	# 		elif response and hasattr(response, 'errors') and response.errors:
	# 			console = list()
	# 			if isinstance(response.errors, list):
	# 				for error in response.errors:
	# 					if isinstance(error, list):
	# 						error_messages = ' '.join(error)
	# 					else:
	# 						error_messages = error
	# 					console.append(error_messages)
	# 			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
	# 				for key, error in response['errors'].items():
	# 					if isinstance(error, list):
	# 						error_messages = ' '.join(error)
	# 					else:
	# 						error_messages = error
	# 					console.append(key + ': ' + error_messages)
	# 			else:
	# 				console.append(response['errors'])
	# 			msg_errors = '::'.join(console)
	# 			self.log(entity_type + ' id ' + to_str(entity_id) + ' import failed. Error: ' + msg_errors,
	# 			         "{}_errors".format(entity_type))
	# 			return Response().error()
	#
	# 		else:
	# 			return Response().success()
	#
	#
	# 	def custom_attribute_to_description(self, product: Product):
	# 		product_description = product.description or product.description
	# 		product_description = nl2br(product_description)
	# 		return product_description
	# 		if not product.attributes:
	# 			return product_description
	# 		section_title = 'Custom Attributes'
	# 		if product.src.channel_type == 'ebay':
	# 			section_title = 'Item Specifics'
	# 		if product.src.channel_type == 'shopify':
	# 			section_title = 'Metafields'
	# 		custom_attributes = list()
	# 		for attribute in product.attributes:
	# 			custom_attributes.append(f'<li>{to_str(attribute.attribute_name).capitalize()}: {attribute.attribute_value_name}</li>')
	# 		custom_attributes = "\n".join(custom_attributes)
	# 		description = f'''
	# 		<div style="border: 1px solid #ccc;padding: 0px 10px">
	#     <h3 style="align-items: center;
	#     display: flex; padding: 0px 10px"><span style="font-weight: bold">{section_title}</span></h3>
	#     <div>
	#         <ul style="list-style: None;padding: 0px 10px">
	#             {custom_attributes}
	#         </ul>
	#     </div>
	# </div>
	# 		'''
	# 		if product_description:
	# 			description = f'{description}</br>{product_description}'
	# 		return description
	#
	#
	# 	def display_finish_channel_pull(self):
	# 		super().display_finish_channel_pull()
	# 		if is_local():
	# 			return Response().success()
	# 		if self.is_refresh_process():
	# 			webhook = self.api('webhook_subscriptions')
	# 			verify = {
	# 				'order': False,
	# 				'product': False
	# 			}
	# 			if webhook and webhook.get('webhookSubscriptions'):
	# 				for hook in webhook['webhookSubscriptions']:
	# 					if hook['endpointUrl'].find('https://api.litcommerce.com/merchant/squarespace/webhook') != -1:
	# 						self.api(f'webhook_subscriptions/{hook["id"]}', method = 'delete')
	# 						continue
	# 					if hook['endpointUrl'].find(f'api/v1/merchant/squarespace/webhook/{self.get_channel_id()}/order/update') != -1 and hook['topic'][0] == 'order.update':
	# 						verify['order'] = True
	# 			events = dict()
	#
	# 			if not verify['order']:
	# 				events[f"orders/updated"] = f'order.update'
	# 			if not events:
	# 				return Response().success()
	# 			for event, url in events.items():
	# 				address = get_server_callback(f'merchant/squarespace/webhook/{self.get_channel_id()}/{url}')
	# 				webhook_data = {
	# 					"topics": [event],
	# 					"endpointUrl": address,
	# 				}
	# 				webhook = self.post('webhook_subscriptions', webhook_data)
	# 				if self._last_status == 201:
	# 					self._state.channel.config.api[f"secret_webhook"] = webhook['secret']
	# 					self.update_channel(api = json_encode(self._state.channel.config.api))
	# 		return Response().success()
	#

	def finish_refresh_process(self):
		time.sleep(5 * 60)
		self.refresh_access_token()
		time.sleep(5 * 60)
		self.refresh_access_token()
		return Response().success()


	def get_draft_extend_channel_data(self, product):
		extend = {}
		if not product.sku:
			extend['sku'] = random_string(16)
		# if product.variants:
		# 	for index, variant in enumerate(product.variants):
		# 		list_inventory_variant = list()
		# 		if not self.is_channel_default() and self.get_channel_default().type.lower() == "shopify":
		# 			inventories = self.to_variant_inventory(variant)
		# 			if len(inventories) > 0:
		# 				for inventory in inventories:
		# 					inventory_variant = {
		# 						"qty": inventory["quantity"],
		# 						"location_id": inventory["location_id"]
		# 					}
		# 					list_inventory_variant.append(inventory_variant)
		# 				list_inventory_id = [location["location_id"] for location in list_inventory_variant]
		# 				locations = self.get_locations()
		# 				for location_object in locations:
		# 					if location_object.id not in list_inventory_id:
		# 						inventory_variant = {
		# 							"qty": 0,
		# 							"location_id": location_object.id
		# 						}
		# 						list_inventory_variant.append(inventory_variant)
		# 			else:
		# 				inventory_variant = {
		# 					"qty": variant.qty,
		# 					"location_id": self.get_location_default_id()
		# 				}
		# 				list_inventory_variant.append(inventory_variant)
		# 				list_inventory_id = [location["location_id"] for location in list_inventory_variant]
		# 				locations = self.get_locations()
		# 				for location_object in locations:
		# 					if location_object.id not in list_inventory_id:
		# 						inventory_variant = {
		# 							"qty": 0,
		# 							"location_id": location_object.id
		# 						}
		# 						list_inventory_variant.append(inventory_variant)
		# 		elif not self.is_channel_default():
		# 			inventory_variant = {
		# 				"qty": variant.qty,
		# 				"location_id": self.get_location_default_id()
		# 			}
		# 			list_inventory_variant.append(inventory_variant)
		# 			list_inventory_id = [location["location_id"] for location in list_inventory_variant]
		# 			locations = self.get_locations()
		# 			for location_object in locations:
		# 				if location_object.id not in list_inventory_id:
		# 					inventory_variant = {
		# 						"qty": 0,
		# 						"location_id": location_object.id
		# 					}
		# 					list_inventory_variant.append(inventory_variant)
		# 		else:
		# 			inventory_variant = {
		# 				"qty": variant.qty,
		# 				"location_id": self.get_location_default_id()
		# 			}
		# 			list_inventory_variant.append(inventory_variant)
		# 			list_inventory_id = [location["location_id"] for location in list_inventory_variant]
		# 			locations = self.get_locations()
		# 			for location_object in locations:
		# 				if location_object.id not in list_inventory_id:
		# 					inventory_variant = {
		# 						"qty": 0,
		# 						"location_id": location_object.id
		# 					}
		# 					list_inventory_variant.append(inventory_variant)
		# 		extend["variants"][index]["channel_data"]["square_locations"] = list_inventory_variant
		return extend


	def is_carrier_mapping(self) -> bool:
		other_settings = self._state.channel.config.setting.get('other_setting')
		if isinstance(other_settings, dict) and isinstance(other_settings.get('carrier_mapping'), dict):
			return bool(other_settings.carrier_mapping.get('status') == 'enable')

		return False


	def get_company_mapping(self) -> list:
		if self.is_carrier_mapping():
			carrier_mapping = self._state.channel.config.setting.other_setting.carrier_mapping.get('company_mapping')
			if not isinstance(carrier_mapping, list):
				carrier_mapping = []
			return carrier_mapping
		return []


	def get_tracking_company_mapping(self, tracking_company):
		if not tracking_company:
			return ""
		elif tracking_company.lower() in ['usps', 'fedex', 'ups']:
			return tracking_company
		enable_carrier_mapping = self.is_carrier_mapping()
		if enable_carrier_mapping:
			company_mapping = self.get_company_mapping()
			for carrier in company_mapping:
				if self.name_to_code(carrier["main_company"]) in [self.name_to_code(tracking_company)]:
					return carrier["channel_company"]
		return ""
