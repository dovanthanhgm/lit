import io
import itertools
from copy import deepcopy
from itertools import product as combination

import requests
from PIL import Image
from requests_oauthlib import OAuth1

from datasync.libs.errors import Errors
from datasync.libs.messages import Messages
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.activity import Activity
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory, OrderHistoryStaff
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute, ProductCategory, ProductAttribute


# from datasync.models.collections.template import Template


class ModelChannelsEtsy(ModelChannel):
	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	ORDER_STATUS = {'open': Order.OPEN, 'processing': Order.READY_TO_SHIP, 'completed': Order.COMPLETED, 'unshipped': Order.CANCELED, 'unpaid': Order.AWAITING_PAYMENT}
	INIT_INDEX_FIELDS = ['state']

	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = None
		self._last_status = None
		self.flag_pull_order = False
		self.imported_product_active = 0
		self._pull_active_listing = True
		self._product_pull_type = 'active'
		self._active_imported = 0
		self._draft_imported = 0
		self._api_time = list()
		self._page = 0
		self._order_max_last_modified = 0
		self._last_created_at = 0
		self._all_section = dict()
		self._product_new_qty = None


	def get_api_info(self):

		return {
			'access_token': "access_token",
			'access_token_secret': 'access_token_secret',
			'etsy_user_id': 'etsy_user_id',
			'name': 'name',
		}


	def get_active_imported(self):
		if self._active_imported is not None:
			return self._active_imported
		where = self.get_model_catalog().create_where_condition(f"channel.channel_{self._state.channel.id}.state", 'active')
		where.update(self.get_model_catalog().create_where_condition("is_variant", False))

		self._active_imported = self.get_model_catalog().count(where)
		return self._active_imported


	def get_draft_imported(self):
		if self._draft_imported is not None:
			return self._draft_imported
		where = self.get_model_catalog().create_where_condition(f"channel.channel_{self._state.channel.id}.state", 'draft')
		where.update(self.get_model_catalog().create_where_condition("is_variant", False))

		self._draft_imported = self.get_model_catalog().count(where)
		return self._draft_imported


	# api code
	def info(self):
		info = {
			"access_token": self._state.channel.config.api.access_token,
			"access_token_secret": self._state.channel.config.api.access_token_secret,
			"etsy_user_id": self._state.channel.config.api.etsy_user_id,
			"name": self._state.channel.config.api.name,
			"shipping_template_id": self._state.channel.config.api.shipping_template_id
		}
		return info


	def get_api_path(self, path, add_version = True):
		path = to_str(path).replace('admin/', '')
		prefix = 'admin'
		if add_version:
			prefix += '/api/' + self.get_version_api()
		path = prefix + '/' + path
		return path


	def get_version_api(self):
		if self._version_api:
			return self._version_api
		year = get_current_time("%Y")
		month = get_current_time("%m")
		quarter = (to_int(month) - 1) // 3 + 1
		version_api = (to_int(quarter) - 1) * 3 + 1
		if version_api < 10:
			version_api = "0" + to_str(version_api)
		else:
			version_api = to_str(version_api)

		self._version_api = to_str(year) + "-" + version_api
		return self._version_api


	def auth(self):
		client_key = self.get_client_id(self._user_id)
		client_secret = self.get_client_secret(self._user_id)
		resource_owner_key = self.info()['access_token']
		resource_owner_secret = self.info()['access_token_secret']
		auth = OAuth1(client_key, client_secret, resource_owner_key, resource_owner_secret)
		return auth


	def sleep_time(self):
		time.sleep(0.1)
		return
		if len(self._api_time) < 10:
			self._api_time.append(time.time())
		else:
			sub = time.time() - self._api_time[0]
			if sub <= 1:
				time.sleep(1 - sub)
			del self._api_time[0]
			self._api_time.append((time.time()))


	def get_shop_language(self):
		shop_language = []
		if self._state.channel.config.api.shop_language:
			shop_language = self._state.channel.config.api.shop_language
		else:
			shop_info = self.api(path = f"shops/{self.info()['name']}", auth = self.auth(), shop_language = False)
			if shop_info.result == Response.SUCCESS:
				language = shop_info.data.results[0].languages
				self._state.channel.config.api.shop_language = language
				shop_language = language
				self.update_channel(api = json_encode(self._state.channel.config.api))
		if shop_language:
			return shop_language[0]

		return False


	def api(self, method = 'get', path = '', headers = None, params = None, data = None, files = [], auth = None, retry = 0, shop_language = True):
		if not auth:
			auth = self.auth()
		self.sleep_time()
		url = f"https://openapi.etsy.com/v2/"
		url += path.strip('/')
		if shop_language:
			shop_lang = self.get_shop_language()
			if shop_lang:
				if not params:
					params = dict()
				params['language'] = shop_lang
		try:
			response = requests.request(method, url, headers = headers, params = params, data = data, files = files, auth = auth)
			self._last_status = response.status_code

			if response.status_code in [200, 201]:
				# time.sleep(0.1)
				return Response().success(data = response.json())
			error = {
				'method': method,
				'url': url,
				'headers': headers,
				'data': data,
				'params': params,
				'status_code': response.status_code,
				'content': response.text
			}
			if response.status_code == 409 and 'The resource is being edited by another process' in response.text and retry < 5:
				retry += 1
				time.sleep(5 * retry)
				error['retry'] = retry
				self.log_request_error(**error)

				return self.api(method, path, headers, params, data, files, auth, retry)
			self.log_request_error(**error)

			if response.status_code == 400 and "You have exceeded your quota of" in response.text:
				# error = {
				# 	'method': method,
				# 	'url': url,
				# 	'headers': headers,
				# 	'data': data,
				# 	'params': params,
				# 	'status_code': response.status_code,
				# 	'content': response.content
				# }
				# self.log_request_error(**error)
				notification_data = {
					'code': 'etsy_rate_limit',
					'activity_type': 'etsy_rate_limit',
					'description': 'Etsy rate limit',
					'date_requested': self._date_requested,
					'result': Activity.FAILURE,
					'content': Messages.ETSY_RATE_LIMIT
				}
				self.create_activity_notification(**notification_data)
				return Response().error(code = Errors.ETSY_RATE_LIMIT, msg = "Error returned from Etsy: Has exceeded the limit of calling request to api. Please wait another 30 minutes")
			else:

				return Response().error(code = Errors.ETSY_FAIL_API, msg = response.text)

		except Exception as e:
			error = {
				'method': method,
				'url': url,
				'headers': headers,
				'files': files,
				'data': data,
				'error': e
			}
			self.log_request_error(**error)
			return Response().error(code = Errors.EXCEPTION, msg = e)


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# shop_lange = self.get_shop_language()
		# order = self.get_order_by_id(2528947320)
		# order_ext = self.get_orders_ext_export([order['data']])
		# convert = self.convert_order_export(order['data'], order_ext['data'])
		etsy_user_id = self.info()['etsy_user_id']
		self._state.channel.support.taxes = False
		self._state.channel.support.categories = True
		if not etsy_user_id:
			return Response().error(Errors.ETSY_API_INVALID, msg = "api missing etsy_user_id")
		# call api check info
		try:
			user_info = self.api(path = "/users/__SELF__", auth = self.auth())
			if to_str(etsy_user_id) != to_str(user_info['data']['results'][0]['user_id']):
				return Response().error(Errors.ETSY_API_INVALID, msg = 'conflict etsy_user_id')
		except Exception as e:
			self.log_traceback()
			return Response().error(Errors.ETSY_API_INVALID, msg = "access token invalid")

		# shipping_template_id = self.info()['shipping_template_id']
		# shipping_template = self.etsy_oauth().findAllUserShippingProfiles(user_id=etsy_user_id)
		# flg_shipping_template_id = False
		# for template in shipping_template:
		#     if shipping_template_id == template['shipping_template_id']:
		#         flg_shipping_template_id = True
		#
		# if not flg_shipping_template_id:
		#     return Response().error(Errors.ETSY_API_INVALID)

		# self._state.channel.clear_process.function = "clear_channel_taxes"
		self._state.channel.support.taxes = False
		return Response().success(data)


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		etsy_user_id = self.set_identifier(self.info()['etsy_user_id'])
		return Response().success(etsy_user_id)


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		self._state.pull.process.products.include_expired = to_bool(self._request_data.get('include_expired'))
		if self._request_data.get('import_all'):
			self._state.pull.process.products.include_expired = True
			self._state.pull.process.products.include_inactive = True
		shop_id = self.info()['name']
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			if self._state.pull.process.products.finished:
				self._state.pull.process.products.finished = False
				self._state.pull.process.products.imported = 0
				self._state.pull.process.products.new_entity = 0
				self._state.pull.process.products.imported_inactive = 0
				self._state.pull.process.products.imported_expired = 0
				self._state.pull.process.products.error = 0
				self._state.pull.process.products.id_src = 0
			offset = self._state.pull.process.products.imported
			params = {
				'limit': 1,
				'api_key': self.get_client_id(self._user_id),

			}
			if offset:
				params['offset'] = offset
			products_api = self.api(path = f"/shops/{shop_id}/listings/active", params = params)
			self._state.pull.process.products.total = 0
			if products_api.result == Response.SUCCESS:
				self._state.pull.process.products.total = to_int(products_api['data']['count'])
			for row in ['inactive', 'expired']:
				if self._state.pull.process.products.get(f'include_{row}'):
					params = {'limit': '1'}
					imported = self._state.pull.process.products.get(f'imported_{row}')
					if to_str(imported):
						params['offset'] = to_str(imported)
					products_api = self.api(path = f"/shops/{shop_id}/listings/{row}", params = params, auth = self.auth())
					if products_api.result == Response.SUCCESS:
						self._state.pull.process.products.total += to_int(products_api['data']['count'])

		if self.is_order_process():
			start_time = self.get_order_start_time(False)
			last_modifier = self._state.pull.process.orders.max_last_modified
			# if self._state.channel.config.start_time:
			# 	start_time = self._state.channel.config.start_time
			params = {'limit': '1', 'min_created': start_time}
			if last_modifier:
				params['min_last_modified'] = last_modifier
				self.set_order_max_last_modifier(last_modifier)
			orders_api = self.api(path = f"/shops/{shop_id}/receipts", params = params, auth = self.auth())
			self._state.pull.process.orders.total = 0
			if orders_api.result == Response.SUCCESS:
				self._state.pull.process.orders.total = to_int(orders_api['data']['count'])
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0

		return Response().success(parent)


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_int(last_modifier) > self._order_max_last_modified):
			self._order_max_last_modified = last_modifier


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	# TODO: Categories

	def get_categories_main_export(self):
		shop_id = self.info()['name']
		try:
			categories_data = self.api(path = f"/shops/{shop_id}/sections?api_key={self.get_client_id(self._user_id)}")
			if categories_data['result'] != "success":
				return Response().finish()
		# if isinstance(categories_data, dict):
		# 	return Response().error(Errors.ETSY_API_INVALID, msg = categories_data.get('content'))
		except Exception as e:
			return Response().error(Errors.EXCEPTION, msg = e)
		return Response().success(data = categories_data)


	def get_categories_ext_export(self, categories):
		extend = dict()
		shop_id = self._state.channel.config.api.name
		for category in categories:
			extend[to_str(category['shop_section_id'])] = dict()
			meta = False
			try:
				meta = self.api(path = f"/shops/{shop_id}/sections/{category['shop_section_id']}?api_key={self.get_client_id(self._user_id)}")
				if meta['data']['count'] != 0:
					extend[to_str(category['shop_section_id'])]['meta'] = meta
			except Exception as e:
				self.log(f"failed get section {to_str(category['shop_section_id'])}")
		return Response().success(extend)


	def convert_category_export(self, category, categories_ext):
		shop_id = self._state.channel.config.api.name
		category_data = CatalogCategory()
		category_id = to_str(category['shop_section_id'])
		parent = CatalogCategory()
		category_data.parent = parent
		category_data.id = category.shop_section_id
		api_key = self.get_client_id(self._user_id)
		category_data.seo_url = f"https://www.etsy.com/shop/{shop_id}?section_id={category_id}"
		res = requests.get(f"https://openapi.etsy.com/v2/shops/{shop_id}/sections/{category_id}?api_key={api_key}")
		category_data.active = True if res.status_code == 200 else False
		category_data.name = category.title
		# category_data.description = category.body_html
		category_data['created_at'] = convert_format_time(time_data = datetime.now(), old_format = self.FORMAT_DATETIME)
		category_data['updated_at'] = convert_format_time(time_data = datetime.now(), old_format = self.FORMAT_DATETIME)
		return Response().success(category_data)


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['shop_section_id']


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		shop_id = self.info()['name']
		if category.name:
			headers = {'title': category.name}
			section = self.api(path = f"/shops/{shop_id}/sections", headers = headers)
			if section['data']['count'] == 0:
				self.log(f"failed create section with shop_id {shop_id}, title {category.name}")

		check_response = self.check_response_import(section['data']['results'], category, 'category')
		if check_response.result != Response.SUCCESS:
			return check_response
		category_id = section['data']['results'][0]['shop_section_id']
		return Response().success(category_id)


	# TODO: Products
	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			shop_id = self.info()['name']
			headers = {'offset': '0', 'limit': '10000000'}
			all_products = self.api(path = f"/shops/{shop_id}/listings/active", headers = headers)
			while all_products:
				if all_products['data']['count'] == 0:
					return next_clear
				for product in all_products['data']:
					id_product = product.get('listing_id')
					self.api(path = f"/listings/{id_product}", method = 'delete')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_product_by_updated_at(self):
		return self.get_products_main_export()


	def get_products_main_export(self):
		limit_data = 25
		shop_id = self.info()['name']
		try:
			products_data = list()
			if not self._product_pull_type:
				return Response().finish()
			if self._product_pull_type == 'active':
				imported = self._state.pull.process.products.imported
			else:
				if not self._state.pull.process.products.get(f'include_{self._product_pull_type}'):
					self.set_product_pull_type()
					return self.get_products_main_export()
				imported = self._state.pull.process.products.get(f'imported_{self._product_pull_type}')
			params = {
				'limit': str(limit_data),
				# 'includes': 'Attributes,Images,MainImage,Inventory'
			}
			if to_str(imported):
				params['offset'] = to_str(imported)
			products = self.api(path = f"/shops/{shop_id}/listings/{self._product_pull_type}", params = params, auth = self.auth())
			if self._last_status != 200:
				return Response().finish(code = Errors.ETSY_API_INVALID, msg = products.get('msg'))
			if products['result'] == "success":
				products_data = products['data']['results']
			if not products_data:
				self.set_product_pull_type()
				return self.get_products_main_export()
		except Exception as e:
			self.log_traceback()
			return Response().finish(code = Errors.EXCEPTION, msg = e)
		return Response().success(products_data)


	def set_product_pull_type(self):
		product_status = self._product_pull_type
		if product_status == 'active':
			self._product_pull_type = 'inactive'
		if product_status == 'inactive':
			self._product_pull_type = 'expired'
		if product_status == 'expired':
			self._product_pull_type = ''


	def get_products_ext_export(self, products):
		extend = Prodict()
		for product in products:
			product_id = to_str(product.listing_id)
			extend[to_str(product_id)] = product
		return Response().success(extend)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.listing_id


	def _convert_product_export(self, product, products_ext: Prodict):
		if not product.get_associations:
			product = self.get_product_by_id(product.listing_id)['data']
		product_id = to_str(product.listing_id)
		product_data = Product()
		channel_id = to_str(self._state.channel.id)
		product_data.tags = product.tags
		weight = to_decimal(product.item_weight)
		if not weight % 16:
			product_data.weight = weight/16
			product_data.weight_units = 'lb'
		else:
			product_data.weight = product.item_weight  # product['variants'][0]['grams'] if product['variants'][0]['weight_unit'] == 'g' else
			product_data.weight_units = product.item_weight_unit  # product['variants'][0]['grams'] if product['variants'][0]['weight_unit'] == 'g' else

		product_data.length = product.item_length
		product_data.width = product.item_width
		product_data.height = product.item_height
		product_data.dimension_units = product.item_dimensions_unit  # product['variants'][0]['grams'] if product['variants'][0]['weight_unit'] == 'g' else

		product_data.status = True if product.state == 'active' else False
		product_data.created_at = self.convert_format_time(product.original_creation_tsz)
		product_data.updated_at = self.convert_format_time(product.last_modified_tsz)
		product_data.name = product.title
		product_data.description = product.description
		product_data.price = product.price
		url_key = product.url.split('?')[0] if product.url else None
		product_data.seo_url = url_key or f'https://www.etsy.com/listing/{product.listing_id}'
		variant_sku = ''
		if product.Inventory and product.Inventory[0].get('products'):
			variant_default = product.Inventory[0]['products'][0]
			variant_sku = variant_default.sku
		if variant_sku:
			product_data.sku = variant_sku
		elif not product.sku:
			product_data.sku = product_id
		else:
			product_data.sku = product.sku[0]
		if self._state.channel.config.product_id_to_sku:
			product_data.sku = product_id
		if product.shop_section_id:
			category = ProductCategory()
			category.id = product.shop_section_id
			product_data.categories.append(category)
		image_ids = list()
		etsy_images = dict()
		if product.MainImage:
			etsy_images[product.MainImage.listing_image_id] = product.MainImage.url_fullxfull
			image_ids.append(product.MainImage.listing_image_id)
			product_data.thumb_image.url = product.MainImage.url_fullxfull
		# if product.get('state') == "active":
		# 	images = self.api(path = f"/listings/{product_id}/images?api_key={self.get_client_id(self._user_id)}")
		# else:
		# 	images = self.api(path = f"/listings/{product_id}/images", auth = self.auth())

		if product.Images:
			for image in product.Images:
				if image['listing_image_id'] in image_ids:
					continue
				etsy_images[image['listing_image_id']] = image['url_fullxfull']

				image_ids.append(image['listing_image_id'])
				product_image_data = ProductImage()
				product_image_data.url = image['url_fullxfull']
				product_data.images.append(product_image_data)
		# special_price = soup.find('p', {"class": "wt-text-title-03 wt-mr-xs-2"}).text
		# product_data.special_price.price = float(re.findall(r'[0-9.]+', special_price)[0])
		product_state = product.state
		if product_state == 'edit':
			product_state = 'inactive'
		channel_data = {
			"state": product_state if product_state in ['active', 'inactive', 'expired'] else 'active',
			'category_path': ' > '.join(product.taxonomy_path)
		}
		if self._state.channel.config.section_to_category and product.shop_section_id:
			section_name = self.get_section_name(product.shop_section_id)
			if section_name:
				channel_data['category_path'] = section_name

		product_data.qty = product.quantity
		occasion = ''
		recipient = ''
		etsy_attributes = []
		if product.Attributes:
			for att in product.Attributes:
				if att['property_name'] in ['Weight', 'Height', 'Length', 'Width']:
					if att['property_name'] == 'Weight' and not product_data.weight:
						product_data.weight = to_decimal(att['values'][0])
						product_data.weight_units = 'kg' if att.scale_name.lower() in ['kg', 'kilogram', 'kilograms'] else 'oz'
					else:
						attribute_name = att['property_name'].lower()
						if not product_data.get(attribute_name):
							product_data[attribute_name] = to_decimal(att['values'][0])
						product_data.dimension_units = 'in' if att.scale_name.lower() in ['in', 'inch', 'inches'] else 'cm'
					continue
				if att['property_id'] > 1000:
					etsy_attributes.append({
						'attribute_id': att['property_id'],
						'scale_id': att['scale_id'],
						'attribute_value': att['value_ids'][0]

					})
				attribute_data = ProductAttribute()
				attribute_data.attribute_name = att['property_name']
				attribute_data.attribute_code = att['property_id']
				attribute_data.attribute_value_name = ', '.join(att['values'])
				product_data.attributes.append(attribute_data)
		# cost_to_ship = soup.find("div",
		#                          class_="wt-flex-lg-3 wt-order-xs-1 wt-order-lg-3 wt-max-width-full wt-pl-md-4 wt-pr-md-4 wt-pl-lg-0 wt-pr-lg-5 wt-pl-xs-2 wt-pr-xs-2").find(
		#     "span", class_="currency-value").text
		template_data = {
			'category': {
				'about': {
					'who_made': product.who_made,
					'when_made': product.when_made,
					'is_supply': 1 if product.is_supply else 0
				},
				'category': {
					'id': product.taxonomy_id,
					'name': ' > '.join(product.taxonomy_path)
				},
				'advance': {
					'section': product.shop_section_id,
					'tags': ', '.join(product.tags) if isinstance(product.tags, list) else product.tags,
					'materials': ', '.join(product.materials) if isinstance(product.materials, list) else product.materials,
					'attributes': etsy_attributes,
				}
			},
			'shipping': {
				'shipping_id': product.shipping_template_id
			},
		}

		product_data.template_data = template_data
		product_data.channel_data = channel_data
		if not product.has_variations and product.get('state') == 'active':
			return Response().success(product_data)
		# if product.get('state') == 'active':
		# 	variants = self.api(path = f"/listings/{product.listing_id}/inventory", params = params)
		# else:
		# 	variants = self.api(path = f"/listings/{product.listing_id}/inventory", auth = self.auth())
		if product.has_variations and product.Inventory and product.Inventory[0].get('products'):
			variant_images = self.api(path = f'/listings/{product.listing_id}/variation-images')
			variant_etsy_images = dict()
			if variant_images and variant_images.data and variant_images.data.results:
				for image in variant_images.data.results:
					if image['image_id'] not in etsy_images:
						continue
					key_gen = f"p{image['property_id']}-v{image['value_id']}"
					variant_etsy_images[key_gen] = etsy_images[image['image_id']]
			# if product.Inventory and product.Inventory[0].get('products') and to_len(product.Inventory[0].get('products')) > 1:
			for index, variant in enumerate(product.Inventory[0].get('products')):
				# product_variant = self.api(path = f"/listings/{product_id}/products/{variant['product_id']}", auth = self.auth())
				variant_data = ProductVariant()
				variant_data.id = variant['product_id']
				variant_data.seo_url = product_data.seo_url
				variant_data.qty = variant['offerings'][0]['quantity']
				# price variant
				divisor_price = variant['offerings'][0]['price'].get('divisor')
				divisor_before_conversion = variant['offerings'][0]['price'].get('before_conversion', {}).get('divisor')
				variant_data.price = variant['offerings'][0]['price'].get('before_conversion', {}).get('amount') / divisor_before_conversion if \
					variant['offerings'][0]['price'].get('before_conversion') \
					else variant['offerings'][0]['price']['amount'] / divisor_price
				# sku variant
				if variant.sku:
					variant_data.sku = variant.sku
				elif to_len(product.sku) > index:
					variant_data.sku = product.sku[index]
				else:
					variant_data.sku = variant['product_id']
				if self._state.channel.config.product_id_to_sku:
					variant_data.sku = variant['product_id']
				# property
				for attribute in variant['property_values']:
					variant_attribute = ProductVariantAttribute()
					variant_attribute.id = attribute['property_id']
					variant_attribute.attribute_name = attribute['property_name']
					variant_attribute.attribute_value_name = ', '.join(attribute['values'])
					variant_data.attributes.append(variant_attribute)
					key_gen = f"p{attribute['property_id']}-v{attribute['value_ids'][0]}"
					if key_gen in variant_etsy_images:
						variant_data.thumb_image.url = variant_etsy_images[key_gen]
				if not variant_data.attributes:
					continue
				product_data.variants.append(variant_data)
		return Response().success(product_data)


	def get_product_by_id(self, product_id):
		product = self.api(path = f"/listings/{product_id}", method = 'get', params = {'includes': 'Attributes,Images,MainImage,Inventory'}, auth = self.auth())
		if product['result'] != "success":
			return Response().error(code = Errors.ETSY_GET_PRODUCT_FAIL)
		product = product['data']['results'][0]
		if product.state == 'removed':
			return Response().create_response(result = Response.DELETED)
		product['get_associations'] = True
		return Response().success(data = product)


	def product_import(self, convert: Product, product, products_ext):
		link = []
		if not product.name:
			return Response().error("Product missing name")

		if product.url:
			link_product = self.process_image_before_import(product.url, product.path)
			link.append({'src': link_product['url']})

		# start_date_special = product.special_price.start_date.strip()
		# end_date_special = product.special_price.end_date.strip()
		# price = 0
		# if start_date_special and end_date_special:
		# 	start_date_special = datetime.strptime(start_date_special, '%Y-%m-%d %H:%M:%S')
		# 	end_date_special = datetime.strptime(end_date_special, '%Y-%m-%d %H:%M:%S')
		# now = datetime.strptime(str(datetime.now()).split('.')[0], '%Y-%m-%d %H:%M:%S')
		# if start_date_special < now and now < end_date_special:
		# if not product.get('template_data', {}).get('price', {}):
		# 	price = to_decimal(product.price)
		# 	price = price if product.variant_count == 0 else product.variants[0].price
		# else:
		# 	price = product.get('template_data', {}).get('price', {}).get('custom_price').get('value')
		# 	if price == 0:
		# 		price = product.get('template_data', {}).get('price', {}).get('adjustment').get('value')
		template_category = product.get('template_data', {}).get('category', {})
		template_shipping = product.get('template_data', {}).get('shipping', {})

		if not template_category or not template_shipping:
			return Response().error(Errors.TEMPLATE_NOT_FOUND, msg = 'Missing required template. Please add a template for the etsy channel')
		price = to_decimal(product.price) or product.min_price or product.max_price
		list_tag = []
		if template_category.advance.tags:
			tags = template_category.advance.tags.split(',') if isinstance(template_category.advance.tags, str) else template_category.advance.tags
			for tag in tags:
				list_tag.append(tag.strip()[:20])
		elif product.tags:
			tags = product.tags.split(',') if isinstance(product.tags, str) else product.tags
			for tag in tags:
				list_tag.append(tag.strip()[:20])
		qty = to_int(product.qty)
		if qty > 999 or not product.manage_stock:
			qty = 999
		data_category_template = template_category.get('about')
		when_made = data_category_template.when_made
		if when_made.startswith('2020-202'):
			when_made = f'2020-{get_current_time("%Y")}'
		if when_made.startswith('before_200'):
			when_made = 'before_2003'
		if when_made.startswith('2000-200'):
			when_made = '2000-2002'
		if re.findall("200[0-9]-2009", when_made):
			when_made = '2003-2009'
		data_category_template.when_made = when_made
		data_category_template['is_supply'] = True if data_category_template['is_supply'] else False

		taxonomy_id = template_category.get('category').get('id')
		advance_data = template_category.get('advance')
		if advance_data:
			advance = {
				"tags": ','.join(advance_data['tags'].split(',')[:13]),
				"shop_section_id": int(advance_data['section']) if advance_data['section'] else None,
				# "recipient": advance_data['recipient'],
				# "occasion": advance_data['occasion']
			}
			data_category_template.update(advance)
		data_category_template.update({'taxonomy_id': taxonomy_id})
		data_category_template.update({'shipping_template_id': to_int(template_shipping.get('shipping_id'))})
		title = self.convert_title(product.name)
		description = product.description or product.short_description or title
		post_data = {
			'product': {
				'quantity': qty,
				'title': title[0:140],
				'description': self.replace_description(description),
				'price': price,
				'tags': ', '.join(list_tag[:13]),
				'state': 'active' if product.status else 'draft'
			}
		}
		if self.is_import_draft():
			post_data['product']['state'] = 'draft'
		if not product.variants:
			post_data['product']['sku'] = [product.sku]
		post_data['product'].update(data_category_template)

		responses = self.api(path = "/listings", method = 'post', data = post_data['product'], auth = self.auth())
		if responses['result'] != "success":
			if responses.get('msg') and 'Please enter a valid ZIP Code / Postal Code' in to_str(responses.get('msg')):
				return Response().error(Errors.ETSY_SHIPPING_ZIP_CODE)
			if responses.get('code') in [1303, 1305]:
				return Response().error(Errors.ETSY_FAIL_API, msg = responses.get('msg'))
			elif responses.get('code') == 2201:
				return Response().error(Errors.EXCEPTION, msg = responses.get('msg'))
		# check_response = self.check_response_import(responses, product, 'product')
		# if check_response.result != Response.SUCCESS:
		# 	return check_response
		product_id = responses['data']['results'][0]['listing_id']
		self._product_new_qty = qty
		if price != product.price:
			self._extend_product_map['price'] = price
		return Response().success(product_id)


	def is_import_draft(self):
		return self._request_data.get('publish_draft') or self._state.channel.config.import_draft or to_int(self.info()['etsy_user_id']) == 452073815


	def extend_data_insert_map_product(self):
		extend = super(ModelChannelsEtsy, self).extend_data_insert_map_product()
		if isinstance(self._product_new_qty, int):
			extend['qty'] = self._product_new_qty
			self._product_new_qty = None
		if self._state.channel.config.import_draft:
			extend['state'] = 'draft'
		return extend


	def attribute_name_to_code(self, attribute_name):
		return to_str(attribute_name).lower().strip(' ')


	def convert_title(self, title):
		title = to_str(title).replace('/', '-').replace('´', "'")
		title = strip_html_tag(title).replace('$', '').replace('&', ' and ').strip('#-+ ')
		if title.isupper():
			title = title.title()
		titles = title.split(' ')
		index = 0
		response = list()
		for char in titles:
			if char.isupper():
				index += 1
				if index > 3:
					char = char.capitalize()
			response.append(char)

		title = ' '.join(response)
		return title


	def after_product_import(self, product_id, convert: Product, product, products_ext):

		# add metafield Dimensions
		data_update = {'state': 'active' if product.status else 'draft'}
		if self.is_import_draft():
			data_update['state'] = 'draft'
		dimensions = ('length', 'width', 'height', 'weight')
		for dimension in dimensions:
			if to_decimal(product.get(dimension)):
				data_update[f'item_{dimension}'] = to_decimal(product.get(dimension))
		# update listing
		if product.weight_units:
			data_update['item_weight_unit'] = product.weight_units
		else:
			data_update['item_weight_unit'] = 'oz'

		if product.dimension_units:
			data_update['item_dimensions_unit'] = product.dimension_units
		else:
			data_update['item_dimensions_unit'] = 'in'
		product_update = self.api(path = f"/listings/{product_id}", method = 'put', data = data_update, auth = self.auth())

		# Update attribute
		template_category = product.get('template_data', {}).get('category', {})
		taxonomy_id = template_category.get('category').get('id')
		taxonomy_response = self.api(path = f"/taxonomy/seller/{taxonomy_id}/properties", auth = self.auth())
		taxonomy_attributes = dict()
		taxonomy_support_variants = dict()
		possible_values = dict()
		for attribute in taxonomy_response['data']['results']:
			taxonomy_attributes[attribute['name'].lower()] = attribute['property_id']
			possible_values[attribute['name'].lower()] = attribute.get('possible_values')
			if attribute['supports_variations'] and to_int(attribute['property_id']) <= 514:
				taxonomy_support_variants[attribute['name'].lower()] = attribute['property_id']
		advance_data = template_category.get('advance')
		attributes = advance_data.get('attributes', [])
		product_attribute_ids = list()

		for attribute in attributes:
			if not attribute['attribute_id']:
				continue
			if not attribute['attribute_value']:
				self.api(path = f"/listings/{product_id}/attributes/{attribute['attribute_id']}", method = 'delete', auth = self.auth())
				continue
			attribute_data = {'value_ids': attribute.attribute_value}
			if attribute.scale_id:
				attribute_data['scale_id'] = attribute.scale_id
			product_update = self.api(path = f"/listings/{product_id}/attributes/{attribute['attribute_id']}", data = attribute_data, method = 'put', auth = self.auth())
			product_attribute_ids.append(attribute['attribute_id'])
		if product.attributes:
			for attribute in product.attributes:
				attribute_code = self.attribute_name_to_code(attribute.attribute_name)
				if not taxonomy_attributes.get(attribute_code) or not possible_values.get(attribute_code):
					continue
				attribute_id = taxonomy_attributes[attribute_code]
				attribute_possible_values = {to_str(row['name']).lower(): row['value_id'] for row in possible_values[attribute_code]}
				values = to_str(attribute.attribute_value_name).split(',')
				value_ids = list()
				for value in values:
					if attribute_possible_values.get(to_str(value).lower()):
						value_ids.append(to_str(attribute_possible_values.get(to_str(value).lower())))
				attribute_data = {'value_ids': ','.join(value_ids)}

				self.api(path = f"/listings/{product_id}/attributes/{attribute_id}", data = attribute_data, method = 'put', auth = self.auth())
		# upload image
		images = list()
		if product.thumb_image.url:
			img = product.thumb_image.url
			if img:
				images.append(img)
		for img_src in product.images:
			if 'status' in img_src and not img_src['status']:
				continue
			img = img_src.url
			if img:
				images.append(img)
		etsy_images = dict()
		upload_image = None
		main_image_id = None
		for index, image in enumerate(images[0:10]):
			payload = {
				'listing_id': product_id,
				'overwite': 'true',
				'rank': index + 1
			}
			try:
				# upload_image = False
				image_resize = self.resize(image)
				if image_resize:
					files = [
						('image', image_resize)
					]

					upload_image = self.api(path = f"/listings/{product_id}/images", method = 'post', data = payload,
					                        files = files, auth = self.auth())
					if upload_image.result == Response.SUCCESS and upload_image.data.count >= 1:
						etsy_images[image] = upload_image.data.results[0].listing_image_id
						if not index:
							main_image_id = upload_image.data.results[0].listing_image_id
			except Exception as e:

				self.log_traceback('images', f"image error: {image}")
		# if not upload_image:
		# 	try:
		# 		files = [
		# 			('image', self.resize_image(image))
		# 		]
		# 		self.api(path = f"/listings/{product_id}/images", method = 'post', data = payload, files = files,
		# 		         auth = self.auth())
		# 	except Exception as e:
		# 		self.log_traceback(e)

		# TODO: push variants
		update_variant = self.product_channel_update_variant(product_id, product, taxonomy_support_variants, main_image_id, etsy_images)
		if update_variant.result != Response.SUCCESS:
			return update_variant
		return Response().success(product_id)


	def product_channel_update_variant(self, product_id, product: Product, taxonomy_support_variants, main_image_id, etsy_images):
		if not product.variants:
			qty = to_int(product.qty)
			if qty > 999 or not product.manage_stock:
				qty = 999

			payload = {"products": json.dumps([{"property_values": [], 'sku': product.sku[:32],
			                                    "offerings": [{"price": to_decimal(product.price), "quantity": qty}]}])}
			res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
			               auth = self.auth())
			if res['result'] != 'success':
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			self._product_new_qty = qty

			return Response().success(product_id)
		variants = []
		pro_on_property = []
		len_attributes = 0
		all_variants = {self.variant_key_generate(variant): variant for variant in product.variants}
		options = self.variants_to_option(product.variants)
		combinations = list()
		for option_key, values in options.items():
			combinations.append([{option_key: row} for row in values])
		combinations_variants = list(combination(*combinations))
		all_variant_keys = list()
		variant_max_qty = list()
		variant_update_qty = list()
		new_qty = 0
		for row in combinations_variants:
			attributes = list()
			for attribute in row:
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = list(attribute.keys())[0]
				attribute_data.attribute_value_name = list(attribute.values())[0]
				attributes.append(attribute_data)
			variant_key = self.variant_key_generate_by_attributes(attributes)
			all_variant_keys.append(variant_key)
			variant = all_variants.get(variant_key)
			sku = variant.sku if variant and variant.sku else variant_key
			var_qty = variant.qty if variant else 0
			if var_qty > 999 or (variant and not variant.manage_stock):
				variant_max_qty.append(variant_key)
				var_qty = 999
			new_qty += var_qty
			var_price = variant.price if variant else product.variants[0]['price']
			property_id_custom = None
			is_enabled = variant.visible if variant else False
			if len(attributes) > 2:
				values = []
				names = []
				for attribute in attributes:
					values.append(attribute.attribute_value_name.replace(';', ''))
					names.append(attribute.attribute_name.replace(';', ''))
				pro_on_property = [513]
				property_values = [{"property_id": 513, "property_name": ", ".join(names), "values": [', '.join(values)]}]
				variants.append({"property_values": property_values, "sku": sku[:32],
				                 "offerings": [{"price": to_decimal(var_price), "quantity": var_qty, "is_enabled": is_enabled}]})
			else:

				property_values_dict = {}
				for attribute in attributes:
					attribute_code = self.attribute_name_to_code(attribute.attribute_name)
					values = attribute.attribute_value_name

					if taxonomy_support_variants.get(attribute_code):
						property_id = taxonomy_support_variants[attribute_code]
					else:
						property_id = 514 if property_id_custom else 513
						property_id_custom = property_id
					if str(property_id) not in pro_on_property:
						pro_on_property.append(str(property_id))
					property_values_dict[property_id] = {"property_id": property_id, "property_name": attribute.attribute_name, "values": [values.replace(';', '')]}

				sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
				property_values = [sorted_dict[key] for key in sorted_dict]
				variants.append({"property_values": property_values, "sku": sku[:32],
				                 "offerings": [{"price": to_decimal(var_price), "quantity": var_qty, "is_enabled": is_enabled}]})

		if len(variants) > 0:
			pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), pro_on_property))))
			payload = {
				"products": json.dumps(variants),
				"quantity_on_property": pro_on_properties,
				"price_on_property": pro_on_properties,
				"sku_on_property": pro_on_properties
			}
			res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
			               auth = self.auth())
			if res['result'] != 'success':
				if res.get('msg') and "cannot be more than 70 items" in res.get('msg'):
					return Response().error(code = Errors.ETSY_VARIANT_LIMIT)

				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			variant_images = list()
			for index, variant_res in enumerate(res['data']['results'].get('products')):
				variant_key = all_variant_keys[index]
				if not all_variants.get(variant_key):
					continue
				child = all_variants.get(variant_key)
				if variant_key in variant_max_qty:
					variant_update_qty.append(child['_id'])
				if not child['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
					self.insert_map_product(child, child['_id'], variant_res.get('product_id'))
				else:
					self.update_map_product(child, child['_id'], variant_res.get('product_id'))

				if len_attributes and len_attributes != 2:
					child_image = child.thumb_image.url
					if child_image and etsy_images.get(child.thumb_image.url):
						child_image_id = etsy_images.get(child.thumb_image.url)
					else:
						child_image_id = main_image_id
					if not child_image_id:
						continue
					property = variant_res.property_values[0]
					variant_images.append({
						'property_id': property.property_id,
						'value_id': property.value_ids[0],
						'image_id': child_image_id,
					})
			if variant_images:
				listing_variant_images = {
					'listing_id': to_int(product_id),
					'variation_images': json_encode(variant_images)
				}
				upload = self.api('post', path = f'listings/{product_id}/variation-images', data = listing_variant_images, auth = self.auth())
			if variant_update_qty:
				self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', variant_update_qty, 'in'), {f'channel.channel_{self.get_channel_id()}.qty': 999})
				self._product_new_qty = to_int(new_qty)
		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		state_id = self._state.channel.id
		product_id = to_int(product_id) if product_id else to_int(product.channel.get(f"channel_{state_id}").get("product_id"))
		if not isinstance(product_id, int):
			return Response().error(msg = "don't product_id")
		description = product.description or product.short_description or product.get('name')

		data_update = {
			'title': product.get('name'),
			'description': self.replace_description(description),
			'tags': ",".join(product.get('tags')) if product.get('tags') else "",
			'item_weight': to_decimal(product.get('weight')) if product.get('weight') else 0,
			'item_length': to_decimal(product.get('length')) if product.get('length') else 0,
			'item_width': to_decimal(product.get('width')) if product.get('width') else 0,
			'item_height': to_decimal(product.get('height')) if product.get('height') else 0,
		}
		if product.weight_units:
			data_update['item_weight_unit'] = product.weight_units
		else:
			data_update['item_weight_unit'] = 'oz'

		if product.dimension_units:
			data_update['item_dimensions_unit'] = product.dimension_units
		else:
			data_update['item_dimensions_unit'] = 'in'
		if product.state and product.state in ['inactive', 'draft']:
			data_update['state'] = product.state
		# if self._state.channel.config.import_draft:
		# 	data_update['state'] = 'draft'
		template_shipping = product.channel.get(f"channel_{state_id}").get('template_data', {}).get('shipping', {})

		template_category = product.channel.get(f"channel_{state_id}").get('template_data', {}).get('category', {})
		if not template_category or not template_shipping:
			return Response().error(Errors.TEMPLATE_NOT_FOUND,
			                        msg = 'Missing required template. Please add a template for the etsy channel')

		data_category_template = template_category.get('about')
		if data_category_template.when_made[0:8] == '2020-202':
			data_category_template = f'2020-{get_current_time("%Y")}'
		taxonomy_id = template_category.get('category').get('id')
		advance_data = template_category['advance']
		list_tag = []
		if template_category.advance.tags:
			tags = template_category.advance.tags.split(',') if isinstance(template_category.advance.tags, str) else template_category.advance.tags
			for tag in tags:
				list_tag.append(tag.strip()[:20])
		elif product.tags:
			tags = product.tags.split(',') if isinstance(product.tags, str) else product.tags
			for tag in tags:
				list_tag.append(tag.strip()[:20])
		advance = {
			"tags": list_tag,
			"shop_section_id": to_int(advance_data['section']) if advance_data['section'] else None,
			# "recipient": advance_data['recipient'],
			# "occasion": advance_data['occasion']
		}
		data_category_template.update({'taxonomy_id': taxonomy_id})
		data_category_template.update(advance)

		data_update.update(data_category_template)
		if template_shipping:
			data_update.update({"shipping_template_id": to_int(template_shipping.get('shipping_id'))})

		# template_title = product.channel.get(f"channel_{state_id}").get('template_data', {}).get('title', {})
		# if template_title:
		# 	data_title = {
		# 		"title": strip_html_tag(template_title.get('title')),
		# 		"description": strip_html_tag(template_title.get('description'))
		# 	}
		# 	data_update.update(data_title)

		res = self.api(path = f"/listings/{product_id}", method = 'put', data = data_update, auth = self.auth())
		if res['result'] != "success":
			if res.get('code') in [1303, 1305]:
				return Response().error(Errors.ETSY_FAIL_API, msg = res.get('msg'))
			elif res.get('code') == 2201:
				return Response().error(Errors.EXCEPTION, msg = res.get('msg'))

		# updateInventory to update quantity, price
		property_ids = {"finish": 500, "dimensions": 501, "fabric": 502, "flavor": 503, "diameter": 504,
		                "height": 505, "length": 506, "material": 507, "pattern": 508, "scent": 509, "stype": 510,
		                'weight': 511, 'width': 512, "color": 513, "size": 514, "device": 515}
		quantity = product.qty

		# if not product.variants:
		# 	qty = product.qty
		# 	payload = {"products": json.dumps([{"property_values": [], 'sku': product.sku, "offerings": [{"price": to_decimal(product.price), "quantity": qty}]}])}
		# 	res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
		# 	               auth = self.auth())
		# 	if res['result'] != 'success':
		# 		return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
		# 	return Response().success(product.id)

		taxonomy_response = self.api(path = f"/taxonomy/seller/{taxonomy_id}/properties", auth = self.auth())
		taxonomy_attributes = dict()
		taxonomy_support_variants = dict()
		for attribute in taxonomy_response['data']['results']:
			taxonomy_attributes[attribute['name'].lower()] = attribute['property_id']
			if attribute['supports_variations'] and to_int(attribute['property_id']) <= 514:
				taxonomy_support_variants[attribute['name'].lower()] = attribute['property_id']
		advance_data = template_category.get('advance')
		attributes = advance_data.get('attributes', [])
		product_attribute_ids = list()

		for attribute in attributes:
			if not attribute['attribute_id']:
				continue
			if not attribute['attribute_value']:
				self.api(path = f"/listings/{product_id}/attributes/{attribute['attribute_id']}", method = 'delete', auth = self.auth())
				continue
			attribute_data = {'value_ids': attribute.attribute_value}
			if attribute.scale_id:
				attribute_data['scale_id'] = attribute.scale_id
			attribute_update = self.api(path = f"/listings/{product_id}/attributes/{attribute['attribute_id']}", data = attribute_data, method = 'put', auth = self.auth())
			product_attribute_ids.append(attribute['attribute_id'])
		if product.attributes:
			for attribute in product.attributes:
				# print('attribute_name', att.attribute_name)
				attribute_code = self.attribute_name_to_code(attribute.attribute_name)
				attribute_id = None
				if attribute_code in taxonomy_attributes:
					attribute_id = taxonomy_attributes[attribute_code]
				elif 513 not in product_attribute_ids:
					attribute_id = 513
				elif 514 not in product_attribute_ids:
					attribute_id = 514
				if not attribute_id or attribute_id in product_attribute_ids:
					continue
				self.api(path = f"/listings/{product_id}/attributes/{attribute_id}",
				         data = {'values': attribute.attribute_value_name}, method = 'put', auth = self.auth())

		# TODO: push variants
		product_images_request = self.api(path = f'/listings/{product_id}/images', auth = self.auth())
		product_images = list()
		if product_images_request.result == Response.SUCCESS:
			product_images = product_images_request.data.results
		images = list()
		if product.thumb_image.url:
			img = product.thumb_image.url
			if img:
				images.append(img)
		all_images = product.all_images or product.images
		for img_src in all_images:
			if 'status' in img_src and not img_src['status']:
				continue
			img = img_src.url
			if img:
				images.append(img)
		main_image_id = None
		etsy_images = dict()

		for index, image in enumerate(images[0:10]):
			payload = {
				'listing_id': product_id,
				'overwite': 'true',
				'rank': index + 1
			}
			if product_images and to_len(product_images) > index:
				delete = self.api('delete', path = f"/listings/{product_id}/images/{product_images[index]['listing_image_id']}")
			try:
				# upload_image = False
				image_resize = self.resize(image)
				if image_resize:
					files = [
						('image', image_resize)
					]

					upload_image = self.api(path = f"/listings/{product_id}/images", method = 'post', data = payload,
					                        files = files, auth = self.auth())
					if upload_image.result == Response.SUCCESS and upload_image.data.count >= 1:
						etsy_images[image] = upload_image.data.results[0].listing_image_id
						if not index:
							main_image_id = upload_image.data.results[0].listing_image_id
			except Exception as e:

				self.log_traceback('images', f"image error: {image}")
		if product_images and to_len(product_images) > to_len(images):
			for image in product_images[to_len(images):]:
				delete = self.api('delete', path = f"/listings/{product_id}/images/{image['listing_image_id']}")
				c = 3
		# if not product.variants:
		# 	qty = product.qty
		# 	payload = {"products": json.dumps([{"property_values": [], 'sku': product.sku[:32],
		# 	                                    "offerings": [{"price": to_decimal(product.price), "quantity": qty}]}])}
		# 	res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
		# 	               auth = self.auth())
		# 	if res['result'] != 'success':
		# 		return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
		# 	return Response().success(product_id)
		#
		# variants = []
		# pro_on_property = []
		# len_attributes = 0
		# for variant in product.variants:
		# 	if not variant.visible:
		# 		continue
		# 	sku = variant.sku if variant.sku else self.random_sku()
		# 	var_qty = variant.qty
		# 	property_values = []
		# 	property_id_custom = None
		# 	attributes = []
		# 	# count attr is used
		# 	for attribute in variant.attributes:
		# 		if not attribute.use_variant:
		# 			continue
		# 		attributes.append(attribute)
		# 	if not len_attributes:
		# 		len_attributes = len(attributes)
		# 	# if > 2 -> attr: custom
		# 	if len(attributes) > 2:
		# 		values = []
		# 		for attribute in attributes:
		# 			values.append(attribute.attribute_value_name.replace(';', ''))
		# 		pro_on_property = [513]
		# 		property_values = [{"property_id": 513, "property_name": 'custom', "values": [','.join(values)]}]
		# 		variants.append({"property_values": property_values, "sku": sku[:32],
		# 		                 "offerings": [{"price": to_decimal(variant.price), "quantity": var_qty}]})
		# 	else:
		# 		# if len <= 2, sort property_id
		# 		property_values_dict = {}
		# 		for attribute in attributes:
		# 			attribute_code = self.attribute_name_to_code(attribute.attribute_name)
		# 			values = attribute.attribute_value_name
		#
		# 			if taxonomy_support_variants.get(attribute_code):
		# 				property_id = taxonomy_support_variants[attribute_code]
		# 			else:
		# 				property_id = 514 if property_id_custom else 513
		# 				property_id_custom = property_id
		# 			if str(property_id) not in pro_on_property:
		# 				pro_on_property.append(str(property_id))
		# 			property_values_dict[property_id] = {"property_id": property_id, "property_name": attribute.attribute_name, "values": [values.replace(';', '')]}
		#
		# 		sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
		# 		property_values = [sorted_dict[key] for key in sorted_dict]
		# 		variants.append({"property_values": property_values, "sku": sku[:32], "offerings": [{"price": to_decimal(variant.price), "quantity": var_qty}]})
		#
		# if len(variants) > 0:
		# 	pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), pro_on_property))))
		# 	payload = {
		# 		"products": json.dumps(variants),
		# 		"quantity_on_property": pro_on_properties,
		# 		"price_on_property": pro_on_properties,
		# 		"sku_on_property": pro_on_properties
		# 	}
		# 	res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
		# 	               auth = self.auth())
		# 	if res['result'] != 'success':
		# 		if res.get('msg') and "cannot be more than 70 items" in res.get('msg'):
		# 			return Response().error(code = Errors.ETSY_VARIANT_LIMIT)
		# 		if res.get('msg') and "One offering must have quantity greater than 0" in res.get('msg'):
		# 			return Response().error(code = Errors.ETSY_INVENTORY_VARIANT_FAIL)
		# 		return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
		# 	variant_images = list()
		# 	for index, variant_res in enumerate(res['data']['results'].get('products')[:len(product.variants)]):
		# 		child = product.variants[index]
		# 		self.update_map_product(child, child['_id'], variant_res.get('product_id'))
		# 		if len_attributes and len_attributes != 2:
		# 			child_image = child.thumb_image.url
		# 			if child_image and etsy_images.get(child.thumb_image.url):
		# 				child_image_id = etsy_images.get(child.thumb_image.url)
		# 			else:
		# 				child_image_id = main_image_id
		# 			if not child_image_id:
		# 				continue
		# 			property = variant_res.property_values[0]
		# 			variant_images.append({
		# 				'property_id': property.property_id,
		# 				'value_id': property.value_ids[0],
		# 				'image_id': child_image_id,
		# 			})
		# 	if variant_images:
		# 		listing_variant_images = {
		# 			'listing_id': to_int(product_id),
		# 			'variation_images': json_encode(variant_images)
		# 		}
		# 		upload = self.api('post', path = f'listings/{product_id}/variation-images', data = listing_variant_images, auth = self.auth())
		update_variant = self.product_channel_update_variant(product_id, product, taxonomy_support_variants, main_image_id, etsy_images)
		if update_variant.result != Response.SUCCESS:
			return update_variant
		return Response().success(product.id)


	def delete_product_import(self, product_id):
		self.api(path = f"/listings/{product_id}", method = 'delete', auth = self.auth())
		return Response().success()


	def convert_variants(self, products):
		properties = {}
		for property in products[0]['property_values']:
			properties[property['property_name']] = set()
		list_key_properties = []
		for product in products:
			set_values = set()
			for property in properties.keys():
				values = self.choice_values(property, product['property_values'])
				properties[property].add(values[0])
				set_values.add(values[0])
			list_key_properties.append(set_values)
		t = 1
		for property in properties:
			t *= len(properties[property])
		if len(products) == t:
			return products
		key_properties = list(properties.keys())
		# Products can have a maximum of two property values
		if len(properties) == 1:
			list_properties = properties[key_properties[0]]
		else:  # len(properties) == 2:
			list_properties = list(itertools.product(properties[key_properties[0]], properties[key_properties[1]]))
		results = products
		for key_properties in list_properties:
			if set(key_properties) not in list_key_properties:
				tmp = deepcopy(products[0])
				for i in range(len(tmp['property_values'])):
					tmp['property_values'][i]['values'] = [key_properties[i]]
				tmp['sku'] = 'sku_etsy'
				results.append(tmp)
		return results


	def choice_values(self, property_name, property_values):
		for property_value in property_values:
			if property_name in property_value['property_name']:
				return property_value['values']


	# # TODO: Order

	def get_orders_main_export(self):
		shop_id = self._state.channel.config.api.name
		try:
			imported = self._state.pull.process.orders.imported
			limit_data = self._state.pull.setting.orders
			created_channel = self.get_order_start_time(False)
			last_modifier = self._state.pull.process.orders.max_last_modified
			params = {'limit': limit_data, 'min_created': created_channel, 'offset': imported, 'includes': 'Listings,Transactions,Buyer,GuestBuyer'}
			if last_modifier:
				params['min_last_modified'] = last_modifier
			orders_data = self.api(path = f"/shops/{shop_id}/receipts", params = params, auth = self.auth())
		except Exception as e:
			self.log_traceback()
			return Response().finish(Errors.EXCEPTION, msg = e)
		return Response().success(data = orders_data['data']['results'])


	def get_order_by_id(self, order_id):
		params = {'includes': 'Listings,Transactions,Buyer,GuestBuyer'}

		order = self.api(path = f"receipts/{order_id}", params = params, auth = self.auth())
		if self._last_status == 200:
			return Response().success(order['data']['results'][0])
		return Response().success()


	def get_orders_ext_export(self, orders):
		user_ids = list()
		countries = list()
		for order in orders:
			user_ids.append(order.buyer_user_id)
			countries.append(order.country_id)
		users = dict()
		countries_data = dict()
		for user_id in user_ids:
			user_info = self.api(path = f'users/{user_id}', auth = self.auth(), params = {'includes': 'Profile'})
			if user_info.result == 'success':
				users[to_str(user_id)] = user_info.data.results[0]
		for country in countries:
			country_info = self.api(path = f'countries/{country}', auth = self.auth())
			if country_info.result == 'success':
				countries_data[to_str(country)] = country_info.data.results[0]
		return Response().success({'users': users, 'countries': countries_data})


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.last_modified_tsz)
		buyer_info = orders_ext['users'].get(to_str(order.buyer_user_id))
		country_info = orders_ext['countries'][to_str(order.country_id)]
		order_data = Order()
		order_id = order['receipt_id']
		order_data.id = order_id
		order_data.order_number = order_id
		if not order.was_paid:
			order_status = 'unpaid'
			return Response().skip()
		elif not order.was_shipped:
			order_status = 'processing'
		else:
			order_status = 'completed'
		order_data.status = self.ORDER_STATUS[order_status]
		order_data.currency = ''
		order_data.created_at = self.convert_format_time(order.creation_tsz)
		order_data.updated_at = self.convert_format_time(order.last_modified_tsz)
		order_data.channel_data = {
			'order_status': order_status,
			'created_at': order_data.created_at,
			'shipped_date': convert_format_time(order.shipped_date) if order.shipped_date else ''
		}
		first_name = ''
		last_name = ''
		if order.name:
			first_name, last_name = self.split_customer_fullname(order.name)
		customer_first_name = first_name
		customer_last_name = last_name
		if buyer_info:
			if buyer_info.Profile.first_name:
				customer_first_name = buyer_info.Profile.first_name
			if not customer_first_name and buyer_info.Profile.login_name:
				customer_first_name = buyer_info.Profile.login_name
			if buyer_info.Profile.last_name:
				customer_last_name = buyer_info.Profile.last_name
			if not customer_last_name and buyer_info.Profile.login_name:
				customer_last_name = buyer_info.Profile.login_name
		order_data.customer.id = order.buyer_user_id
		if buyer_info:
			order_data.customer.username = buyer_info.login_name
		order_data.customer.first_name = customer_first_name
		order_data.customer.last_name = customer_last_name
		order_data.customer.email = order.buyer_email
		# order_data.customer_address = dict()
		order_data.customer_address.first_name = customer_first_name
		order_data.customer_address.last_name = customer_last_name
		order_data.customer_address.country.country_code = country_info.iso_country_code
		order_data.customer_address.country.country_name = country_info.name
		order_data.customer_address.state.state_code = order.state
		order_data.customer_address.address_1 = order.first_line
		order_data.customer_address.address_2 = order.second_line
		order_data.customer_address.city = order.city
		order_data.customer_address.postcode = order.zip
		# order_data.billing_address = dict()
		order_data.billing_address.first_name = customer_first_name
		order_data.billing_address.last_name = customer_last_name
		order_data.billing_address.country.country_code = country_info.iso_country_code
		order_data.billing_address.country.country_name = country_info.name
		order_data.billing_address.state.state_code = order.state
		order_data.billing_address.address_1 = order.first_line
		order_data.billing_address.address_2 = order.second_line
		order_data.billing_address.city = order.city
		order_data.billing_address.postcode = order.zip
		# order_data.shipping_address = dict()
		order_data.shipping_address.first_name = first_name or customer_first_name
		order_data.shipping_address.last_name = last_name or customer_last_name
		order_data.shipping_address.country.country_code = country_info.iso_country_code
		order_data.shipping_address.country.country_name = country_info.name
		order_data.shipping_address.state.state_code = order.state

		order_data.shipping_address.address_1 = order.first_line
		order_data.shipping_address.address_2 = order.second_line
		order_data.shipping_address.city = order.city
		order_data.shipping_address.postcode = order.zip
		# order_data.payment = dict()
		order_data.payment.method = order.payment_method

		# order_data.payment = self.etsy_oauth().findShopPaymentByReceipt(shop_id = shop_id, receipt_id = order_id)
		# order_data.items = list()
		customer_notes = ['message_from_buyer', 'gift_message', 'message_from_payment', 'message_from_seller']
		for row in customer_notes:
			if order.get(row):
				if row == 'message_from_seller':
					history = OrderHistoryStaff()
				else:
					history = OrderHistory()
				history.comment = order[row]
				order_data.history.append(history)
		listings = {listing["listing_id"]: listing for listing in order.Listings}
		for item in order.Transactions:
			listing = listings[item['listing_id']]
			order_item = OrderProducts()
			order_item.product_id = item.product_data.product_id if listing.get('has_variations') else item['listing_id']
			order_item.price = item.price
			order_item.total = round(to_decimal(item.price) * to_decimal(item.quantity), 2)
			order_item.qty = item.quantity
			order_item.product_sku = item.product_data.sku
			order_item.product_name = item.title
			options = dict()
			if item.product_data.property_values:
				for option in item.product_data.property_values:
					options[option.property_id] = {
						"name": option.property_name,
						"value": option['values'][0]
					}
					option_data = OrderItemOption()
					option_data.option_id = option.property_id
					option_data.option_name = option.property_name
					option_data.option_value_name = option['values'][0]
					order_item.options.append(option_data)
			if item.variations:
				for option in item.variations:
					if not options.get(option.property_id):
						options[option.property_id] = {
							"name": option.formatted_name,
							"value": option.formatted_value
						}
			for option_id, option in options.items():
				option_data = OrderItemOption()
				option_data.option_id = option_id
				option_data.option_name = option['name']
				option_data.option_value_name = option['value']
				order_item.options.append(option_data)
			order_data.products.append(order_item)
		order_data.subtotal = to_decimal(order.total_price)
		order_data.total = to_decimal(order.grandtotal)
		order_data.discount.amount = to_decimal(order.discount_amt)
		order_data.shipping.amount = to_decimal(order.total_shipping_cost)
		if order.shipping_details and order.shipping_details.shipping_method:
			order_data.shipping.method = order.shipping_details.shipping_method
		order_data.tax.amount = to_decimal(order.total_tax_cost)
		order_data.currency = order.currency_code
		if order_data.tax.amount and self.is_import_order_without_tax():
			order_data.total = to_decimal(to_decimal(order_data.total) - to_decimal(order_data.tax.amount), 2)
			order_data.tax.amount = 0
		return Response().success(order_data)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.receipt_id


	def channel_order_completed(self, order_id, order: Order, current_order):
		channel_default = self.get_channel_default()

		submit_tracking = {
			'tracking_code': order.shipments.tracking_number or channel_default.get('type'),
			'carrier_name': order.shipments.tracking_company_code,
			'send_bcc': False
		}
		self.api(method = 'post', path = f'shops/{self.info()["name"]}/receipts/{order_id}/tracking', data = submit_tracking)
		order_id = order_id if order_id else order.order_number
		res = self.api(path = f"/receipts/{order_id}", data = {"was_shipped": True}, method = 'put', auth = self.auth())
		if res['result'] != 'success':
			if res.get('code') in [1303, 1305]:
				return Response().error(Errors.ETSY_FAIL_API, msg = res.get('msg'))
			elif res.get('code') == 2201:
				return Response().error(Errors.EXCEPTION, msg = res.get('msg'))
		return_order = {"status": res['data'][0].get('status')}
		return Response().success(return_order)


	def resize_image(self, url):
		try:
			r = requests.get(url)
			if r.status_code != 200:
				return
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			new_width = 570
			new_height = 450
			img = img.resize((new_width, new_height), Image.ANTIALIAS)
			if img.mode != 'RGB':
				img = img.convert('RGB')
			imgByteArr = io.BytesIO()
			img.save(imgByteArr, format = 'PNG')
			imgByteArr = imgByteArr.getvalue()
			return imgByteArr
		except Exception as e:
			self.log(e, 'resize_image')


	def resize(self, url):
		try:
			r = False
			retry = 0
			while r is False and retry < 5:
				try:
					r = requests.get(url, headers = {'User-Agent': get_random_useragent()})
				except Exception as e:
					time.sleep(2)
					retry += 1
					r = False
			if not r or r.status_code != 200:
				return
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			if img.mode != 'RGB':
				img = img.convert('RGB')
			imgByteArr = io.BytesIO()
			img.save(imgByteArr, format = self.image_content_type_to_mime_type(r.headers.get('content-type')))
			imgByteArr = imgByteArr.getvalue()
			return imgByteArr
		except Exception as e:
			self.log_traceback('images', f"image error: {url}")

			return False


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error(msg = 'no respone check_response_import')
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error(msg = msg_errors)

		else:
			return Response().success(response)


	def convert_child_to_option(self, childrens):
		max_attribute = 0
		option_src = list()
		for children in childrens:
			if max_attribute <= to_len(children['attributes']):
				max_attribute = to_len(children['attributes'])
				option_src = children['attributes']
		all_option_name = list()
		for option in option_src:
			if option['attribute_name'] in all_option_name:
				continue
			all_option_name.append(option['attribute_name'])
		options = dict()
		languages = dict()
		for children in childrens:
			for attribute in children['attributes']:
				if attribute['attribute_name'] not in all_option_name:
					continue
				if attribute['attribute_name'] not in options:
					options[attribute['attribute_name']] = dict()
				if not attribute['attribute_value_name'] or attribute['attribute_value_name'] in options[
					attribute['attribute_name']]:
					continue
				option_data = ProductVariant()
				option_data['attribute_code'] = attribute['attribute_code']
				option_data['attribute_value_name'] = attribute['attribute_value_name']
				option_data['attribute_value_code'] = attribute['attribute_value_code']
				option_data['attribute_value_languages'] = attribute['attribute_value_languages']
				option_data['attribute_value_price'] = attribute['price'] if attribute['price'] and to_int(
					attribute['price']) > 0 else (
					children['price'] if to_len(children['attributes']) < 2 and to_int(children['price']) > 0 else 0)
				option_data['price_prefix'] = attribute['price_prefix']
				languages[attribute['option_name']] = attribute['option_languages']
				options[attribute['option_name']][attribute['option_value_name']] = option_data
		all_options = list()
		for option_name, option in options.items():
			option_data = ProductVariant()
			option_data['id'] = None
			# option_data['code'] = self.convert_attribute_code(option_name)
			option_data['attribute_type'] = 'select'
			option_data['attribute_name'] = option_name
			option_data['attribute_languages'] = languages[option_name] if option_name in languages else ''
			for option_value_name, option_value in option.items():
				if option_value['attribute_code'] and option_value['attribute_code'] != '':
					option_data['code'] = option_value['attribute_code']
					option_data['attribute_code'] = option_value['attribute_code']
				option_data['values'].append(option_value)
			all_options.append(option_data)
		return all_options


	def random_sku(self, length = 16):
		chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
		return "".join(random.choice(chars) for _ in six.moves.xrange(length))


	def get_client_id(self, user_id = None):
		client_id = self._state.channel.config.api.consumer_key
		if not client_id:
			return get_config_ini('etsy', 'oauth_consumer_key')
		return client_id


	def get_client_secret(self, user_id = None):
		client_id = self._state.channel.config.api.consumer_secret
		if not client_id:
			return get_config_ini('etsy', 'oauth_consumer_secret')
		return client_id


	def replace_description(self, text):
		return self.strip_html_from_description(text)


	def channel_sync_inventory(self, product_id, product: Product, products_ext):
		if product.channel[f'channel_{self.get_channel_id()}'].get('is_variant'):
			return Response().error()
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success(product)
		etsy_convert = dict()
		etsy_product = self.get_product_by_id(product_id)
		if etsy_product.result != Response.SUCCESS:
			return Response().success(product)
		etsy_product_data = etsy_product['data']
		etsy_product_ext = self.get_products_ext_export([etsy_product['data']])
		etsy_convert = self.convert_product_export(etsy_product['data'], etsy_product_ext['data'])
		convert = etsy_convert.data
		params = {"api_key": self.get_client_id(self._user_id)}

		# Update product price, sku, inventory, barcode etc..
		update_data = {}
		# if self._state.channel.config.import_draft:
		# 	update_data['state'] = 'draft'
		quantity = product.qty
		product_state = product.state
		if product_state == 'edit':
			product_state = 'inactive'
		status = product_state
		if not product.variants:
			if setting_price and self.is_special_price(product):
				product.price = product.special_price.price
			qty = product.qty if to_int(product.qty) < 999 else 999
			product.qty = qty

			if setting_qty:
				if not qty:
					update_data = {
						'state': 'inactive'
					}

					res = self.api(path = f"/listings/{product_id}", method = 'put', data = update_data, auth = self.auth())
					if res['result'] == 'success':
						status = 'inactive'

						update_product = {
							f"channel.channel_{self.get_channel_id()}.state": "inactive",
							# f"channel.channel_{self.get_channel_id()}.inactive_during_sync": True,
						}
						self.get_model_catalog().update(product['_id'], update_product)
					return Response().success(product)
				else:
					if etsy_product_data.get('state') != 'active':
						update_data = {
							'state': 'active',
							'renew': True
						}
						res = self.api(path = f"/listings/{product_id}", method = 'put', data = update_data, auth = self.auth())
						if res['result'] == 'success':
							status = 'active'
							# update_product = {
							# 	f"channel.channel_{self.get_channel_id()}.state": "active",
							# 	f"channel.channel_{self.get_channel_id()}.inactive_during_sync": False,
							# }
							# self.get_model_catalog().update(product['_id'], update_product)
			update_data = {
				"price": to_decimal(product.price),
				"quantity": qty
			}
			if not setting_qty:
				update_data['quantity'] = convert.qty
			if not setting_price:
				update_data['price'] = convert.price
			payload = {
				"products": json.dumps([{"property_values": [], "offerings": [update_data], 'sku': product.sku[0:32]}])}
			res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
			               auth = self.auth())
			if res['result'] != 'success':
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			update_product = {
				f"channel.channel_{self.get_channel_id()}.state": status,
				# f"channel.channel_{self.get_channel_id()}.inactive_during_sync": False,
			}
			self.get_model_catalog().update(product['_id'], update_product)
			return Response().success(product)

		# TODO: push variants

		variants = []
		pro_on_property = []
		etsy_variants = dict()
		for variant in convert.variants:
			etsy_variants[to_str(variant['id'])] = variant
		number_sold_out = 0
		template_shipping = product.channel.get(f"channel_{self.get_channel_id()}").get('template_data', {}).get('shipping', {})

		template_category = product.channel.get(f"channel_{self.get_channel_id()}").get('template_data', {}).get('category', {})
		if not template_category or not template_shipping:
			return Response().error(Errors.TEMPLATE_NOT_FOUND,
			                        msg = 'Missing required template. Please add a template for the etsy channel')

		taxonomy_id = template_category.get('category').get('id')
		taxonomy_response = self.api(path = f"/taxonomy/seller/{taxonomy_id}/properties", auth = self.auth())
		taxonomy_support_variants = dict()
		for attribute in taxonomy_response['data']['results']:
			if attribute['supports_variations'] and to_int(attribute['property_id']) <= 514:
				taxonomy_support_variants[attribute['name'].lower()] = attribute['property_id']
		variants = []
		pro_on_property = []
		len_attributes = 0
		all_variants = {self.variant_key_generate(variant): variant for variant in product.variants}
		options = self.variants_to_option(product.variants)
		combinations = list()
		for option_key, values in options.items():
			combinations.append([{option_key: row} for row in values])
		combinations_variants = list(combination(*combinations))
		all_variant_keys = list()
		litcommerce_variants = list()
		for row in combinations_variants:
			attributes = list()
			for attribute in row:
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = list(attribute.keys())[0]
				attribute_data.attribute_value_name = list(attribute.values())[0]
				attributes.append(attribute_data)
			variant_key = self.variant_key_generate_by_attributes(attributes)
			all_variant_keys.append(variant_key)
			variant = all_variants.get(variant_key)
			etsy_variant = False
			if variant:
				if setting_price and self.is_special_price(variant):
					variant.price = variant.special_price.price
				sku = variant.sku or variant_key
				var_qty = variant.qty if to_int(variant.qty) < 998 else 998
				variant.qty = var_qty
				litcommerce_variants.append(variant)
				var_price = variant.price
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				if variant_id:
					etsy_variant = etsy_variants.get(variant_id)
			else:
				sku = variant_key
				var_qty = 0
				var_price = product.variants[0]['price']
			is_enabled = variant.visible if variant else False

			offerings = {
				"price": etsy_variant.price if etsy_variant else var_price,
				"quantity": etsy_variant.qty if etsy_variant else var_qty,
				"is_enabled": is_enabled
			}
			if setting_qty:
				offerings['quantity'] = var_qty
				if not var_qty > 0:
					number_sold_out += 1
			if setting_price:
				offerings['price'] = var_price
			property_id_custom = None
			if len(attributes) > 2:
				values = []
				names = []
				for attribute in attributes:
					values.append(attribute.attribute_value_name.replace(';', ''))
					names.append(attribute.attribute_name.replace(';', ''))
				pro_on_property = [513]
				property_values = [{"property_id": 513, "property_name": ", ".join(names), "values": [', '.join(values)]}]
				variants.append({"property_values": property_values, "sku": sku[:32],
				                 "offerings": [offerings]})
			else:

				property_values_dict = {}
				for attribute in attributes:
					attribute_code = self.attribute_name_to_code(attribute.attribute_name)
					values = attribute.attribute_value_name

					if taxonomy_support_variants.get(attribute_code):
						property_id = taxonomy_support_variants[attribute_code]
					else:
						property_id = 514 if property_id_custom else 513
						property_id_custom = property_id
					if str(property_id) not in pro_on_property:
						pro_on_property.append(str(property_id))
					property_values_dict[property_id] = {"property_id": property_id, "property_name": attribute.attribute_name, "values": [values.replace(';', '')]}

				sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
				property_values = [sorted_dict[key] for key in sorted_dict]
				variants.append({"property_values": property_values, "sku": sku[:32],
				                 "offerings": [offerings]})
		product.variants = litcommerce_variants
		if len(variants) > 0:
			if number_sold_out == len(variants):
				update = {
					'state': 'inactive',

				}
				res = self.api(path = f"/listings/{product_id}", method = 'put', data = update, auth = self.auth())
				if res['result'] == Response.SUCCESS:
					self.get_model_catalog().update_field(product['_id'], f"channel.channel_{self.get_channel_id()}.state", 'inactive')
				return Response().success(product)
			status = 'active'
			if etsy_product_data.get('state') != 'active':
				update_data = {
					'state': 'active',
					'renew': True
				}
				res = self.api(path = f"/listings/{product_id}", method = 'put', data = update_data, auth = self.auth())
				if res['result'] == 'success':
					status = 'active'
			update_product = {
				f"channel.channel_{self.get_channel_id()}.state": status,
			}
			self.get_model_catalog().update(product['_id'], update_product)
			pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), pro_on_property))))
			payload = {
				"products": json.dumps(variants),
				"quantity_on_property": pro_on_properties,
				"price_on_property": pro_on_properties,
				"sku_on_property": pro_on_properties
			}
			res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
			               auth = self.auth())
			if res['result'] != 'success':
				if res.get('msg') and "cannot be more than 70 items" in res.get('msg'):
					return Response().error(code = Errors.ETSY_VARIANT_LIMIT)

				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			for index, variant_res in enumerate(res['data']['results'].get('products')):
				variant_key = all_variant_keys[index]
				if not all_variants.get(variant_key):
					continue
				child = all_variants.get(variant_key)
				if not child['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
					self.insert_map_product(child, child['_id'], variant_res.get('product_id'))
				else:
					self.update_map_product(child, child['_id'], variant_res.get('product_id'))

		# for variant in product.variants:
		# 	if not variant.visible:
		# 		continue
		# 	variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
		# 	if not variant_id:
		# 		continue
		# 	etsy_variant = etsy_variants.get(variant_id)
		# 	var_qty = variant.qty if to_int(variant.qty) < 999 else 999
		# 	if not variant.manage_stock:
		# 		var_qty = 998
		# 	offerings = {
		# 		"price": to_decimal(variant.price),
		# 		"quantity": variant.qty
		# 	}
		# 	if setting_qty:
		# 		offerings['quantity'] = var_qty
		# 		if not var_qty > 0:
		# 			number_sold_out += 1
		# 	if setting_price:
		# 		offerings['price'] = to_decimal(variant.price)
		# 	property_values = list()
		# 	property_values_dict = {}
		# 	property_id_custom = None
		# 	for attribute in variant.attributes:
		# 		attribute_code = self.attribute_name_to_code(attribute.attribute_name)
		# 		values = attribute.attribute_value_name
		#
		# 		if taxonomy_support_variants.get(attribute_code):
		# 			property_id = taxonomy_support_variants[attribute_code]
		# 		else:
		# 			property_id = 514 if property_id_custom else 513
		# 			property_id_custom = property_id
		# 		if str(property_id) not in pro_on_property:
		# 			pro_on_property.append(str(property_id))
		# 		property_values_dict[property_id] = {"property_id": property_id, "property_name": attribute.attribute_name, "values": [attribute.attribute_value_name]}
		#
		# 	sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
		# 	property_values = [sorted_dict[key] for key in sorted_dict]
		# 	variants.append({
		# 		"offerings": [offerings],
		# 		# "product_id": to_int(variant_id),
		# 		"property_values": property_values,
		# 		'sku': variant.sku
		# 	})
		#
		# if len(variants) > 0:
		# 	if number_sold_out == len(variants):
		# 		update = {
		# 			'state': 'inactive',
		#
		# 		}
		# 		res = self.api(path = f"/listings/{product_id}", method = 'put', data = update, auth = self.auth())
		# 		if res['result'] == Response.SUCCESS:
		# 			self.get_model_catalog().update_field(product['_id'], f"channel.channel_{self.get_channel_id()}.state", 'sold_out')
		# 		return Response().success(product_id)
		# 	pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), pro_on_property))))
		# 	payload = {
		# 		"products": json.dumps(variants),
		# 		"quantity_on_property": pro_on_properties,
		# 		"price_on_property": pro_on_properties,
		# 		"sku_on_property": pro_on_properties
		# 	}
		# 	res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
		# 	               auth = self.auth())
		# 	if res['result'] != 'success':
		# 		if res.get('msg') and "cannot be more than 70 items" in res.get('msg'):
		# 			return Response().error(code = Errors.ETSY_VARIANT_LIMIT)
		#
		# 		return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
		#
		# 	for index, variant_res in enumerate(res['data']['results'].get('products')[:len(product.variants)]):
		# 		child = product.variants[index]
		# 		self.update_map_product(child, child['_id'], variant_res.get('product_id'))
		return Response().success(product)


	def set_imported_product(self, imported):
		if self._product_pull_type == 'active':
			self._state.pull.process.products.imported += imported
		else:
			if not self._state.pull.process.products.get(f'imported_{self._product_pull_type}'):
				self._state.pull.process.products[f'imported_{self._product_pull_type}'] = 0
			self._state.pull.process.products[f'imported_{self._product_pull_type}'] += imported


	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']
		if mass_action == 'delete':
			self.delete_product_import(product_id)
			self.product_deleted(product['_id'], product)
			return Response().success(product_id)

		if mass_action == 'renew':
			data_post = {
				'renew': True
			}
		elif mass_action == 'active':
			data_post = {
				'state': 'active'
			}
		else:
			return Response().success(product_id)
		res = self.api(method = 'put', path = f"/listings/{product_id}", data = data_post, auth = self.auth())
		if res['result'] != "success":
			return Response().error(Errors.ETSY_FAIL_API, msg = res.get('msg'))
		return Response().success(product_id)


	def get_draft_extend_channel_data(self, product):
		title = self.convert_title(product.name)
		description = product.description or product.short_description or title
		description = self.replace_description(description)
		extend = {}
		if product.description != description:
			extend['description'] = description
		if product.name != title:
			extend['name'] = title
		for attribute in product.attributes:
			if self.product_lower_name(attribute.attribute_name) == 'materials':
				extend['materials'] = attribute.attribute_value_name
				break
		if not product.manage_stock:
			extend['qty'] = 999
		sku = product.sku[:32]
		if sku != product.sku:
			extend['sku'] = sku
		return extend


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self._order_sync_inventory(order, '+')


	def order_sync_inventory(self, convert: Order, setting_order):
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):

				product_id = None
				variant_id = None
				if row['product_id'] and row['parent_id']:
					variant_id = row['product_id']
					product_id = row['parent_id']
				else:
					product_id = row['product_id']
				etsy_product = self.get_product_by_id(product_id)
				if etsy_product.result != Response.SUCCESS:
					continue
				etsy_product_ext = self.get_products_ext_export([etsy_product['data']])
				etsy_convert = self.convert_product_export(etsy_product['data'], etsy_product_ext['data'])
				convert = etsy_convert.data
				row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1

				if not convert.variants:
					qty = to_int(convert.qty)
					new_qty = qty - row_qty if prefix == '-' else qty + row_qty

					if new_qty <= 0:
						update_data = {
							'state': 'inactive'
						}
						res = self.api(path = f"/listings/{product_id}", method = 'put', data = update_data, auth = self.auth())
					else:
						update_data = {
							"price": convert.price,
							"quantity": new_qty
						}
						payload = {
							"products": json.dumps([{"property_values": [], "offerings": [update_data]}])}
						res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
						               auth = self.auth())
					continue
				variants = list()
				is_inactive = True
				for product in etsy_product['data']['Inventory']['products']:
					property_values_dict = {}
					for property in product.property_values:
						property_values_dict[property.property_id] = {
							"property_id": property.property_id,
							"property_name": property.property_name,
							"values": [property['values'][0]]
						}
					sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
					property_values = [sorted_dict[key] for key in sorted_dict]
					divisor_price = product['offerings'][0]['price'].get('divisor')
					divisor_before_conversion = product['offerings'][0]['price'].get('before_conversion', {}).get('divisor')
					price = product['offerings'][0]['price'].get('before_conversion', {}).get('amount') / divisor_before_conversion if product['offerings'][0]['price'].get('before_conversion') else product['offerings'][0]['price']['amount'] / divisor_price
					qty = product.offerings[0].quantity

					if to_str(variant_id) == to_str(product.product_id):
						qty = qty - row_qty if prefix == '-' else qty + row_qty

					if qty > 0:
						is_inactive = False
					offerings = {
						"price": price,
						"quantity": qty
					}
					variants.append({
						"offerings": [offerings],
						"property_values": property_values,
						'sku': product.sku
					})
				if is_inactive:
					update = {
						'state': 'inactive',

					}
					res = self.api(path = f"/listings/{product_id}", method = 'put', data = update, auth = self.auth())
					if res['result'] == Response.SUCCESS:
						self.get_model_catalog().update_field(row['product']['_id'], f"channel.channel_{self.get_channel_id()}.state", 'sold_out')
					continue
				payload = {
					"products": json.dumps(variants),
					"quantity_on_property": etsy_product['data']['Inventory'].quantity_on_property,
					"price_on_property": etsy_product['data']['Inventory'].price_on_property,
					"sku_on_property": etsy_product['data']['Inventory'].sku_on_property,
				}
				res = self.api(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
				               auth = self.auth())
		return Response().success()


	def get_all_section(self):
		if self._all_section:
			return self._all_section
		result = self.api(path = f"/shops/{self.info()['name']}/sections")
		if result.result == Response.SUCCESS:
			all_section = result.data.results
		else:
			all_section = []
		for section in all_section:
			self._all_section[to_int(section['shop_section_id'])] = section['title']
		return self._all_section


	def get_section_name(self, section_id):
		all_section = self.get_all_section()
		if all_section.get(to_int(section_id)):
			return all_section[to_int(section_id)]
		return ''


	def is_import_order_without_tax(self):
		return True if self._state.channel.config.setting.get('order', {}).get('without_tax') != 'disable' else False


	def convert_format_time(self, epoch_seconds):
		return convert_format_time(time_data = to_int(epoch_seconds) - 25200, old_format = 'timestamp')