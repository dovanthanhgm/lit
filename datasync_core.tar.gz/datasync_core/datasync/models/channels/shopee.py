from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import *
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute
from datasync.models.constructs.shopee import *
import hmac
import time
import requests
import hashlib
import base64
from itertools import product as combination

class ModelChannelsShopee(ModelChannel):
    TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category', 'shipping']

    def convert_order_status(self, status):
        ORDER_STATUS = {
            "UNPAID": Order.AWAITING_PAYMENT,
            "READY_TO_SHIP": Order.READY_TO_SHIP,
            "RETRY_SHIP": "processing",
            "PROCESSED": "processing",
            "SHIPPED": "processing",
            "COMPLETED": Order.COMPLETED,
            "CANCELLED": Order.CANCELED,
            "IN_CANCEL": Order.CANCELED,
            "TO_CONFIRM_RECEIVE": Order.COMPLETED,
            "TO_RETURN": Order.CANCELED,
        }
        return ORDER_STATUS.get(status, 'UNPAID') if status else 'UNPAID'

    def __init__(self):
        super().__init__()
        self._total_product = 0
        self._shop_id = None
        self._api_url = None
        self._flag_finish_product = False
        self._last_product_response = None
        self._total_orders = 0
        self._flag_finish_order = False
        self._next_cursor_order = False
        self._current_products = 0
        self._product_pull_type = 'normal'

    def get_api_info(self):
        return {
            "partner_id": "PARTNER ID",
            "partner_key": "PARTNER KEY",
            "shop_id": "SHOP ID",
            "access_token": "ACCESS TOKEN",
            "refresh_token": "REFRESH TOKEN",
            "region": "SELLER REGION"
        }

    def refresh_access_token(self):
        time_st = to_int(time.time())
        path = to_str("/api/v2/auth/access_token/get")
        partner_id = self._state.channel.config.api.partner_id
        partner_key = self._state.channel.config.api.partner_key
        refresh_token = self._state.channel.config.api.refresh_token
        shop_id = self._state.channel.config.api.shop_id
        tmp = partner_key
        tmp_base_string = "%s%s%s" % (partner_id, path, time_st)
        base_string = tmp_base_string.encode()
        partner_key = tmp.encode()
        sign = hmac.new(partner_key, base_string, hashlib.sha256).hexdigest()
        url = self.get_api_url() + to_str("/api/v2/auth/access_token/get")
        params = {
            "sign": sign,
            "partner_id": to_int(partner_id),
            "timestamp": time_st
        }
        body = {
            "shop_id": to_int(shop_id),
            "refresh_token": refresh_token,
            "partner_id": to_int(partner_id)
        }
        res = requests.request(method="post", params=params, url=url, json=body)
        refresh_error = {
            "method": "POST",
            "header": to_str(res.headers),
            "status": res.status_code,
            "body": body,
            "response": res.text
        }
        refresh_data = res.json()
        if refresh_data["error"] != "":
            self.log_request_error(url, **refresh_error)
            return False
        new_access_token = refresh_data["access_token"]
        new_refresh_token = refresh_data["refresh_token"]
        self._state.channel.config.api.access_token = new_access_token
        self._state.channel.config.api.refresh_token = new_refresh_token
        self.update_channel(api=json_encode(self._state.channel.config.api))
        return new_access_token

    def get_api_url(self):
        region = self._state.channel.config.api.region
        if region == "CN":
            self._api_url = "https://openplatform.shopee.cn"
        else:
            self._api_url = "https://partner.shopeemobile.com"
        return self._api_url

    def set_last_product_response(self, response):
        self._last_product_response = response

    def get_last_product_response(self):
        return self._last_product_response

    def api(self, path="", params=None, body=None, files=False, method="get"):
        url = self.get_api_url() + to_str(path)
        access_token = self._state.channel.config.api.access_token
        partner_id = self._state.channel.config.api.partner_id
        partner_key = self._state.channel.config.api.partner_key
        shop_id = self._state.channel.config.api.shop_id
        headers = {
            "Content-Type": "application/octet-stream"
        }
        timestamp = to_int(time.time())
        default_params = {
            "timestamp": timestamp,
            "partner_id": partner_id,
            "access_token": access_token,
            "shop_id": shop_id,
        }
        if params:
            params = {**default_params, **params}
        else:
            params = default_params
        sign = self.generate_signature(path, partner_id, partner_key, access_token, shop_id, timestamp)
        params["sign"] = sign
        if files:
            res = self.requests(url, params, files=files, method=method)
        else:
            res = self.requests(url, params, body, headers=headers, method=method)
        retry = 0
        while (res is False) or ('Our system is taking some time to respond, please try later.' in to_str(res)) or (
                "System error, please try again later or contact the OpenAPI support team." in to_str(res)) \
                or self._last_status >= 500:
            retry += 1
            time.sleep(5)
            res = self.requests(url, params, body, headers=headers, files=files, method=method)
            if retry > 5:
                break
        return res

    def generate_signature(self, path_xx, partner_id_xx, key, access_token, shop_id, timestamp):
        try:
            time_st = timestamp
            path = path_xx
            partner_id = partner_id_xx
            tmp = key
            tmp_base_string = "%s%s%s%s%s" % (partner_id, path, time_st, access_token, shop_id)
            base_string = tmp_base_string.encode()
            partner_key = tmp.encode()
            sign = hmac.new(partner_key, base_string, hashlib.sha256).hexdigest()
            return sign
        except (Exception,):
            self.log_traceback()

    def requests(self, url, params=None, body=None, headers=None, files=None, method="get", is_retry = False):
        def log_request_error(res):
            error = {
                "method": method,
                "header": to_str(res.headers),
                "status": res.status_code,
                "param": params,
                "body": body,
                "response": response.text
            }
            self.log_request_error(url, **error)

        method = to_str(method).lower()
        if not headers:
            headers = dict()
            headers['User-Agent'] = get_random_useragent()
        elif isinstance(headers, dict) and not headers.get('User-Agent'):
            headers['User-Agent'] = get_random_useragent()
        if not files:
            headers['Content-Type'] = 'application/json'
        else:
            headers = {}
        response = False
        request_options = {
            'headers': headers,
            'verify': True
        }
        if params:
            request_options["params"] = params
            if method in ["post", "put"]:
                if not files:
                    request_options["json"] = body
                else:
                    request_options["files"] = files
        request_options = self.combine_request_options(request_options)
        response_data = False
        try:
            response = requests.request(method, url, **request_options)
            self._last_header = response.headers
            self._last_status = response.status_code
            response_data = json_decode(response.text)
            if response.status_code == 403:
                self.refresh_access_token()
                if not is_retry:
                    return self.requests(
                        url = url, params = params, body = body, headers = headers,
                        files = files, method = method, is_retry = True
                    )

            if response.status_code > 201:
                log_request_error(response)
                # return Response().error(msg = response.text, status = response.status_code)
                # return response_data
            if response_data:
                try:
                    log_request_error(response)
                    response_prodict = Prodict(**response_data)
                except Exception:
                    response_prodict = response_data
                response_data = response_prodict
        except Exception:
            self.log_traceback()
        return response_data

    def display_setup_channel(self, data=None):
        parent = super().display_setup_channel(data)
        if parent.result != Response().SUCCESS:
            return parent
        get_info_shop = self.api("/api/v2/shop/get_shop_info")
        shop_name = get_info_shop.shop_name
        self._state.channel.config.api.shop = shop_name
        if not get_info_shop:
            return Response().error(msg="API SHOPEE INVALID")
        try:
            if not get_info_shop.shop_name:
                return Response().error(msg="API SHOPEE INVALID")
        except Exception as e:
            return Response().error(msg="API SHOPEE INVALID")

        # self._state.channel.clear_process.function = "clear_channel_taxes"
        return Response().success()

    def set_channel_identifier(self):
        parent = super().set_channel_identifier()
        if parent.result != Response().SUCCESS:
            return parent
        self.set_identifier(self._state.channel.config.api.shop_id)
        return Response().success()

    def after_create_channel(self, data):
        if is_local():
            return Response().success()
        return Response().success()

    def get_max_last_modified_product(self):
        if self._state.pull.process.products.last_modified:
            if to_str(self._state.pull.process.products.last_modified).isnumeric():
                return convert_format_time(self._state.pull.process.products.last_modified,
                                           new_format="%Y-%m-%dT%H:%M:%S+07:00")
            return self._state.pull.process.products.last_modified
        return False

    def display_pull_channel(self):
        parent = super().display_pull_channel()
        if parent.result != Response().SUCCESS:
            return parent

        if self.is_product_process():
            self._state.pull.process.products.error = 0
            self._state.pull.process.products.imported = 0
            self._state.pull.process.products.new_entity = 0
            self._state.pull.process.products.total = 0
            if not self._state.pull.process.products.id_src:
                self._state.pull.process.products.id_src = 0

            if not self.is_refresh_process():
                self._state.pull.process.products.total_view = 0
            store = self._state.channel.config.api.shop
            data = {
                "offset": 0,
                "page_size": 10,
                'item_status': 'NORMAL'
            }
            if self.is_refresh_process():
                self._state.pull.process.products.id_src = 0
                last_modified = self.get_max_last_modified_product()
            else:
                if not self.is_import_inactive():
                    data['item_status'] = 'NORMAL'

            products_api = self.api("/api/v2/product/get_item_list", params=data)
            try:
                if products_api and products_api.response:
                    total_items = products_api.response.total_count
                    self._total_product = total_items
                    # self._total_product_pages = math.ceil(total_items / 100)
                    if self.is_refresh_process():
                        self._state.pull.process.products.total = -1
                        self._state.pull.process.products.total_view = total_items
                    else:
                        self._state.pull.process.products.total = total_items
                        self._state.pull.process.products.total_view = total_items
            except:
                return Response().error(msg="API SHOPEE INVALID")

            for row in ['sdeleted', 'banned', 'unlist']:
                if self.is_import_product_by_status(row):
                    data['item_status'] = row.upper()
                    if row == 'sdeleted':
                        data['item_status'] = 'DELETED'
                    imported = self._state.pull.process.products.get(f'imported_{row}')
                    products_api = self.api("/api/v2/product/get_item_list", params=data)
                    if products_api and products_api.response:
                        products_data = products_api.response.total_count
                        if self.is_refresh_process():
                            self._state.pull.process.products.total = -1
                            if not self._state.pull.process.products.total_view:
                                self._state.pull.process.products.total_view = 0
                            self._state.pull.process.products.total_view += to_int(products_data)
                        else:
                            if not self._state.pull.process.products.total_view:
                                self._state.pull.process.products.total_view = 0
                            if not self._state.pull.process.products.total:
                                self._state.pull.process.products.total = 0
                            self._state.pull.process.products.total_view += to_int(products_data)
                            self._state.pull.process.products.total += to_int(products_data)
        if self.is_order_process():
            self._state.pull.process.orders.total = 0
            self._state.pull.process.orders.imported = 0
            self._state.pull.process.orders.new_entity = 0
            self._state.pull.process.orders.error = 0
            self._state.pull.process.orders.id_src = 0
            limit_data = self._state.pull.setting.orders
            start_time = to_int(self.get_order_start_time(''))
            last_modifier = self._state.pull.process.orders.max_last_modified
            orders_filter = {
                "time_range_field": "create_time",
                # "time_from": 1685694960,
                "time_from": start_time,
                "page_size": 100,  # limit_data,
                "time_to": start_time + 1200000
                # "time_to": 1685694960 + 1200000
            }
            if last_modifier:
                orders_filter["time_range_field"] = "update_time"
                orders_filter["time_from"] = to_timestamp(last_modifier)
                orders_filter["time_to"] = to_timestamp(last_modifier) + 1200000
            orders_api = self.api("/api/v2/order/get_order_list", params=orders_filter)
            if orders_api and orders_api.response:
                self._total_orders += len(orders_api.response.order_list)
                # self._total_order_pages = math.ceil(self._total_order / 100)
                if orders_api.response.more:
                    self.get_total_orders(orders_api, orders_filter)
                self._state.pull.process.orders.total = self._total_orders
        return Response().success()

    def get_total_orders(self, order, orders_filter):
        if order.response.next_cursor:
            orders_filter["next_cursor"] = order.response.next_cursor
        orders_api = self.api("/api/v2/order/get_order_list", params=orders_filter)
        if orders_api and orders_api.response:
            self._total_orders += len(orders_api.response.order_list)
            if orders_api.response.more:
                self.get_total_orders(orders_api, orders_filter)
            else:
                pass

    def clear_channel_taxes(self):
        next_clear = Prodict.from_dict({
            'result': 'process',
            'function': 'clear_channel_categories'
        })
        self._state.channel.clear_process = next_clear
        return next_clear

    def clear_channel_products(self):
        next_clear = Prodict.from_dict({
            'result': 'success',
            'function': '',
        })
        self._state.channel.clear_process = next_clear
        if not self._state.config.products:
            return next_clear
        # try:
        #     data = {
        #         "boothId": f"{self._state.channel.config.api.shop}",
        #         "itemsPerPage": 500,
        #         "itemStatus": "for_sale"
        #     }
        #     all_products = self.api("getBoothItems", data)
        #     while all_products:
        #         if not all_products:
        #             return next_clear
        #         if not all_products.items:
        #             return next_clear
        #         for product in all_products.getBoothItemsResponse.items:
        #             id_product = product.itemID
        #             _data = {
        #                 "itemID": f"{id_product}"
        #             }
        #             res = self.api("endFixedPriceItem", _data)
        #         all_products = self.api("getBoothItems", data)
        #         time.sleep(0.1)
        # except Exception:
        #     self.log_traceback()
        #     return next_clear
        return next_clear

    def get_product_by_id(self, product_id):
        data = {
            "item_id_list": f"{product_id}"
        }
        product = self.api("/api/v2/product/get_item_base_info", params=data)
        if self._last_status == 404:
            return Response().create_response(result=Response.DELETED)
        if not product or not product.response.item_list:
            return Response().error(msg="Get product by ID fail")
        product_data = product.response.item_list[0]
        return Response().success(product_data)

    def get_product_by_updated_at(self):
        list_id = []
        if self._flag_finish_product:
            return Response().finish()
        else:
            limit_data = self._state.pull.setting.products
            data = {
                "item_status": "NORMAL",
                "page_size": 100,
                "offset": self._current_products
            }
            if not self.is_import_inactive():
                data['item_status'] = 'NORMAL'
            list_products = self.api("/api/v2/product/get_item_list", params=data)
        if not list_products or not list_products.response:
            if self._last_status != 200:
                return Response().error(msg="GET PRODUCT LIST ID SHOPEE FAIL")
            return Response().finish()
        for item in list_products.response.get("item"):
            list_id.append(item.item_id)
        self._current_products += 100
        self._flag_finish_product = self.process_products_is_finish()

        id_data = {
            "item_id_list": list_id
        }
        products = self.api("/api/v2/product/get_item_base_info", params=id_data)
        if not products or not products.response:
            if self._last_status != 200:
                return Response().error(msg="GET PRODUCT SHOPEE FAIL")
            return Response().finish()
        return Response().success(data=products.response.get("item_list"))

    def set_product_pull_type(self):
        product_status = self._product_pull_type
        product_next_type = {
            'normal': 'unlist',
            'unlist': 'sdeleted',
            'sdeleted': 'banned',
            'banned': ''
        }
        self._product_pull_type = product_next_type.get(product_status, '')

    def process_products_is_finish(self) -> bool:
        return False if self._current_products < self._total_product else True

    def get_products_main_export(self):
        try:
            list_id = []
            products_data = list()
            if not self._product_pull_type:
                return Response().finish()
            if self._product_pull_type == 'normal':
                imported = self._state.pull.process.products.imported
            else:
                if self.is_refresh_process() or not self.is_import_product_by_status(self._product_pull_type):
                    self.set_product_pull_type()
                    return self.get_products_main_export()
                imported = self._state.pull.process.products.get(f'imported_{self._product_pull_type}')
            params = {
                "page_size": 50,
                "item_status": self._product_pull_type.upper(),
                "offset": 0
            }
            if to_int(imported):
                params['offset'] = to_int(imported)
            if self._product_pull_type == 'sdeleted':
                params['item_status'] = 'DELETED'
            list_products = self.api("/api/v2/product/get_item_list", params=params)
            if not list_products or not list_products.response:
                if self._last_status != 200:
                    return Response().error(msg="GET PRODUCT LIST ID SHOPEE FAIL")
                return Response().finish()
            if list_products.response.item:
                for item in list_products.response.get("item"):
                    list_id.append(item.item_id)
            id_data = {
                "item_id_list": list_id
            }
            products = self.api("/api/v2/product/get_item_base_info", params=id_data)
            if products and products.response:
                products_data = products.response.get("item_list")
            else:
                for state in ["sdeleted", "banned", "unlist"]:
                    if self.is_import_product_by_status(state):
                        self.set_product_pull_type()
                        return self.get_products_main_export()
        except Exception as e:
            self.log_traceback()
            return Response().finish(code=Errors.EXCEPTION, msg=e)
        return Response().success(products_data)

        # list_id = []
        # if self._flag_finish_product:
        #     return Response().finish()
        # else:
        #     limit_data = self._state.pull.setting.products
        #     data = {
        #         "item_status": "NORMAL",
        #         "page_size": 100,
        #         "offset": self._current_products
        #     }
        #     if not self.is_import_inactive():
        #         data['item_status'] = 'NORMAL'
        #     list_products = self.api("/api/v2/product/get_item_list", params=data)
        # if not list_products or not list_products.response:
        #     if self._last_status != 200:
        #         return Response().error(msg="GET PRODUCT LIST ID SHOPEE FAIL")
        #     return Response().finish()
        # for item in list_products.response.get("item"):
        #     list_id.append(item.item_id)
        # self._current_products += 100
        # self._flag_finish_product = self.process_products_is_finish()
        # id_data = {
        #     "item_id_list": list_id,
        #     "need_complaint_policy": True
        # }
        # products = self.api("/api/v2/product/get_item_base_info", params=id_data)
        # if not products or not products.response:
        #     if self._last_status != 200:
        #         return Response().error(msg="GET PRODUCT SHOPEE FAIL")
        #     return Response().finish()
        # for product in products.response.get("item_list"):
        #     product.item_id = to_str(product.item_id)
        # return Response().success(data=products.response.get("item_list"))

    def get_products_ext_export(self, products):
        extend = Prodict()
        for product in products:
            product_id = to_str(product.item_id)
            extend.set_attribute(product_id, Prodict())
        return Response().success(extend)

    def get_product_id_import(self, convert: Product, product, products_ext):
        return product.item_id

    def _convert_product_export(self, product, products_ext: Prodict):
        try:
            template_data = {}
            product_id = to_str(product.item_id)
            product_data = Product()
            channel_id = to_str(self._state.channel.id)
            product_data.sku = product.item_sku
            if product.price_info:
                product_data.price = product.price_info[0].original_price
            else:
                product_variants = self.api("/api/v2/product/get_model_list", params={"item_id": product.item_id})
                product_data.price = product_variants.response.model[0].price_info[0].original_price
            product_data.status = True if product.item_status == "NORMAL" else False
            if product.stock_info_v2:
                product_data.manage_stock = True if product.stock_info_v2.summary_info.total_available_stock > 0 else False
                product_data.qty = product.stock_info_v2.summary_info.total_available_stock
            else:
                product_variants = self.api("/api/v2/product/get_model_list", params={"item_id": product.item_id})
                for model in product_variants.response.model:
                    if model.stock_info_v2.summary_info.total_available_stock > 0:
                        product_data.manage_stock = True
                        break
                    else:
                        product_data.manage_stock = False
            product_data.condition = product_data.CONDITION_NEW if product.condition == "NEW" else product_data.CONDITION_USED
            product_data.weight = to_decimal(product.weight, 2) if to_decimal(product.weight) else 0
            product_data.dimension_units = "cm"
            product_data.weight_units = "kg"
            if product.dimension:
                product_data.height = product.dimension.package_height if product.dimension.package_height else 0
                product_data.width = product.dimension.package_width if product.dimension.package_width else 0
                product_data.length = product.dimension.package_length if product.dimension.package_length else 0
            if product_data.manage_stock:
                product_data.is_in_stock = True if product_data.manage_stock else False
            else:
                product_data.is_in_stock = True
            product_category = self.api("/api/v2/product/get_category", params={"language": "en"})
            category = product_category.response.category_list
            if product.category_id:
                category_template = ShopeeCategoryTemplate()
                category_template.primary_category.category_id = product.category_id
                for cate in category:
                    if cate.category_id == product.category_id:
                        category_template.primary_category.category_name = cate.original_category_name
                        break
                if product.size_chart_id:
                    category_template.size_chart_id = to_int(product.size_chart_id)
                if product.pre_order:
                    category_template.pre_order.is_pre_order = product.pre_order.is_pre_order
                    category_template.pre_order.days_to_ship = product.pre_order.days_to_ship
                if product.brand:
                    category_template.brand.brand_id = product.brand.brand_id
                    category_template.brand.brand_name = product.brand.original_brand_name
                if product.attribute_list:
                    spe_list = []
                    for attribute in product.attribute_list:
                        cate_spe = ShopeeCategorySpecifics()
                        cate_spe.name = attribute.original_attribute_name
                        spe_data = {
                            "attribute_id": attribute.attribute_id,
                            "attribute_value_list": attribute.attribute_value_list
                        }
                        cate_spe.override = spe_data
                        spe_list.append(cate_spe)
                    category_template.specifics = spe_list
                template_data["category"] = category_template
            if product.logistic_info:
                shipping_template = ShopeeShippingTemplate()
                for ship in product.logistic_info:
                    logi = DomensticShipping()
                    logi.logistic_id = ship.logistic_id
                    logi.enabled = ship.enabled
                    logi.is_free = ship.is_free
                    logi.shipping_fee = ship.estimated_shipping_fee
                    if not ship.size_id:
                        logi.size_id = 0
                    else:
                        logi.size_id = ship.size_id
                    shipping_template.domestic_shipping.append(logi)
                template_data["shipping"] = shipping_template
            # if product.complaint_policy:
            #     policy_template = ShopeeComplaintPolicyTemplate()
            #     policy_template.warranty_time = product.complaint_policy.warranty_time
            #     policy_template.exclude_entrepreneur_warranty = product.exclude_entrepreneur_warranty
            #     policy_template.complaint_address_id = product.complaint_address_id
            #     policy_template.additional_information = product.additional_information
            #     template_data["policy"] = policy_template
            if product.create_time:
                product_data.created_at = convert_format_time(product.create_time, "%Y-%m-%dT%H:%M:%S+07:00")
            if product.update_time:
                product_data.updated_at = convert_format_time(product.update_time, "%Y-%m-%dT%H:%M:%S+07:00")
            product_data.name = product.item_name
            if product.description or product.description_type == "normal":
                product_data.description = to_str(product.description)
            else:
                extended_description = ShopeeExtendedDescription()
                if product.description_info:
                    str_des = ""
                    for des in product.description_info.extended_description.field_list:
                        if des.field_type == "image":
                            str_des += f'<img src="{des.image_info.image_url}"/>'
                        else:
                            str_des += des.text
                    extended_description.extended_description = str_des
                    extended_description.status_extended = True
                template_data["description"] = extended_description
            # if product.productListingDetails:
            #     product_data.upc = product.productListingDetails[1]
            # if product.image:
            #     url_image = product.image.image_url_list[0]
            #     if to_str(url_image).split('/')[-1].find('.') == -1:
            #         url_image += '.jpg'
            #     product_data.thumb_image.url = url_image

            if product.image:
                for index, value in enumerate(product.image.image_url_list):
                    img_url = value + '.jpg'
                    if requests.get(img_url).status_code != 200:
                        image_info = self.upload_image(value)
                        if isinstance(image_info, str) or image_info.result != 'success':
                            if isinstance(image_info, str):
                                return Response().error(msg = image_info)
                            else:
                                return image_info
                        img_url = image_info.data.image_url_list[0].image_url + ".jpg"
                    if not index:
                        product_data.thumb_image.url = img_url
                        continue
                    product_image_data = ProductImage()
                    product_image_data.url = img_url
                    # product_image_data.label = image.alt
                    product_image_data.position = index
                    product_data.images.append(product_image_data)

            if product.brand:
                product_data.brand = product.brand.original_brand_name
            channel_data = dict()
            seo_url = ""
            region = self._state.channel.config.api.region
            if region == "VN" or region == "SG" or region == "JP" or region == "PH" or region == "TW" or region == "CN" or region == "CL":
                seo_url = f"https://shopee.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
            elif region == "BR" or region == "CO" or region == "MX" or region == "MY":
                seo_url = f"https://shopee.com.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
            elif region == "ID" or region == "TH":
                seo_url = f"https://shopee.co.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
            channel_data["shopee_url"] = seo_url
            channel_data["region"] = region
            channel_data["shop_id"] = self._state.channel.config.api.shop_id
            product_variants = self.api("/api/v2/product/get_model_list", params={"item_id": product.item_id})
            if product_variants.response:
                if product_variants.response.model:
                    qty = 0
                    is_in_stock = False
                    manage_stock = False
                    for variant in product_variants.response.model:
                        qty += to_int(variant.stock_info_v2.summary_info.total_available_stock)

                        if variant.stock_info_v2.summary_info.total_available_stock:
                            variant_is_in_stock = True if to_int(
                                variant.stock_info_v2.summary_info.total_available_stock) > 0 else False
                        else:
                            variant_is_in_stock = True
                        if variant_is_in_stock:
                            is_in_stock = True
                        variant_manage_stock = True if variant.stock_info_v2.summary_info.total_available_stock > 0 else False
                        if variant_manage_stock:
                            manage_stock = True
                        variant_data = ProductVariant()
                        # variant_data.upc = variant.upc
                        variant_title = ''
                        if variant.tier_index:
                            i = 0
                            for val_list in variant.tier_index:
                                variant_title += " " + product_variants.response.tier_variation[i].option_list[
                                    val_list].option + " /"
                                if i == 0:
                                    try:
                                        if product_variants.response.tier_variation[i].option_list[val_list].image:
                                            variant_url_image = product_variants.response.tier_variation[i].option_list[val_list].image.image_url
                                            img_url = variant_url_image + '.jpg'
                                            if requests.get(img_url).status_code != 200:
                                                image_info = self.upload_image(variant_url_image)
                                                if isinstance(image_info, str) or image_info.result != 'success':
                                                    if isinstance(image_info, str):
                                                        return Response().error(msg = image_info)
                                                    else:
                                                        return image_info
                                                img_url = image_info.data.image_url_list[0].image_url + ".jpg"
                                            variant_data.thumb_image.url = img_url
                                    except:
                                        self.log_traceback()
                                i += 1
                        variant_data.id = variant.model_id
                        variant_data.name = product.item_name + " -" + variant_title.rstrip('/')
                        variant_data.sku = variant.model_sku
                        variant_data.price = variant.price_info[0].original_price
                        variant_data.qty = to_int(variant.stock_info_v2.summary_info.total_available_stock)
                        variant_data.manage_stock = variant_manage_stock
                        variant_data.is_in_stock = variant_is_in_stock
                        variant_sku = to_str(variant.model_sku)
                        if variant.tier_index:
                            for index, variant_val in enumerate(variant.tier_index):
                                variant_attribute = ProductVariantAttribute()
                                variant_attribute.id = "{}_{}".format(product_id, index)
                                # variant_attribute.attribute_type = 'select'
                                variant_attribute.attribute_name = product_variants.response.tier_variation[index].name
                                variant_attribute.attribute_value_name = \
                                    product_variants.response.tier_variation[index].option_list[variant_val].option
                                variant_sku = variant_sku.replace(variant_attribute.attribute_value_name, '')
                                variant_data.attributes.append(variant_attribute)

                        if not variant_data.attributes:
                            continue
                        if not product_data.sku:
                            variant_sku = variant_sku.strip(' -_')
                            if to_str(variant.model_sku).startswith(variant_sku):
                                product_data.model_sku = variant_sku
                            else:
                                product_data.sku = variant.model_sku
                        variant_data.seo_url = f"https://shopee.vn/product/{self._state.channel.config.api.shop_id}/{product_id}"
                        product_data.variants.append(variant_data)
                    product_data.qty = qty
                    product_data.is_in_stock = is_in_stock
                    product_data.manage_stock = manage_stock

            if not product_data.sku:
                product_data.sku = product.item_id

            channel_data['shopee_status'] = product.item_status.lower()
            if product.item_status.lower() == 'deleted':
                channel_data['shopee_status'] = 'sdeleted'
            product_data.channel_data = channel_data
            product_data.template_data = template_data
            return Response().success(product_data)
        except (Exception,):
            self.log_traceback()
            return Response().error(msg="CONVERT PRODUCT FAIL")

    def log_response(self, log_data, log_name: str) -> None:
        self.log(log_data, log_name)

    def product_import(self, convert: Product, product, products_ext):
        category_template = product.get('template_data', {}).get('category')
        convert_product = self.product_to_shopee_data(product, products_ext, product.id)
        self.log_response(convert_product, "shopee_convert_product_import")
        if convert_product.result != Response().SUCCESS:
            return convert_product
        post_data = convert_product.data
        product_import = self.api("/api/v2/product/add_item", body=post_data, method="post")
        check_response = self.check_response_import(product_import, product, 'product')
        if check_response.result != Response().SUCCESS:
            return check_response
        product_id = to_str(product_import.response.item_id)
        return Response().success(product_id)


    def mass_action(self, product_id, data, product, product_ext):
        mass_action = data['mass_action']
        if mass_action == 'active':
            data_post = {
                'item_status': 'NORMAL',
                'item_id': to_int(product_id)
            }
        elif mass_action == 'unlist':
            data_post = {
                'item_list': [{
                    'unlist': True,
                    'item_id': to_int(product_id)
                }]
            }
            unlist = self.api("/api/v2/product/unlist_item", body = data_post, method = "post")
            check_response = self.check_response_import(unlist, product, 'product')
            if check_response.result != Response().SUCCESS:
                return check_response
            self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shopee_status', "unlist")
            return Response().success(product_id)
        else:
            return Response().success(product_id)
        update = self.api("/api/v2/product/update_item", body=data_post, method="post")
        check_response = self.check_response_import(update, product, 'product')
        if check_response.result != Response().SUCCESS:
            return check_response
        self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shopee_status', "normal")
        return Response().success(product_id)


    def upload_image(self, img_url=None, img_base64=None):
        try:
            if img_base64:
                img = img_base64
                files = [
                    ('image', ('image', img, 'application/octet-stream'))  # Replace with actual file path
                ]
                upload_image = self.api("/api/v2/media_space/upload_image", files = files, method = "post")
                if upload_image.response and upload_image.response.image_info:
                    return Response().success(data = upload_image.response.image_info)
                else:
                    return Response().error(msg = upload_image.error)
            else:
                if img_url.startswith("//i0.wp.com"):
                    img_url = to_str(img_url).replace("//i0.wp.com/", "https://")
                stop = 0
                img = ""
                while stop < 5:
                    try:
                        img = requests.get(img_url).content
                        stop = 5
                    except:
                        stop += 1
                        time.sleep(25)
                if not img:
                    return Response().error(msg="CANNOT get image :" + img_url)
                files = [
                    ('image', ('image', img, 'application/octet-stream'))  # Replace with actual file path
                ]
                upload_image = self.api("/api/v2/media_space/upload_image", files = files, method = "post")
                if upload_image.response and upload_image.response.image_info:
                    return Response().success(data = upload_image.response.image_info)
                else:
                    return Response().error(msg = f'Upload images error: {upload_image.error}')
        except:
            self.log_traceback()
            return "Image error:" + img_url

    def product_to_shopee_data(self, product: Product, product_ext, product_id):
        if not product.name:
            return Response().error(Errors.PRODUCT_DATA_INVALID)
        # list_img = list()
        # for index, image in enumerate(product.images):
        #     list_img.append(image.url)
        # Initiate Post data
        description_template = product.get('template_data', {}).get('description')
        post_data = {
            "item_name": product.name,
            "original_price": product.price,
            "brand": {}
        }
        list_des = []
        if description_template and description_template.status_extended:
            des = description_template.extended_description
            soup = BeautifulSoup(des, 'html.parser')
            for script in soup("img"):
                script.replace_with(f"htmlImageTagDiiiivide&{script}htmlImageTagDiiiivide&")
            des_reg = str(soup)
            des_reg = des_reg.replace("&gt;", ">")
            des_reg = des_reg.replace("&lt;", "<")
            list_des = des_reg.split("htmlImageTagDiiiivide&amp;")
            field_list = []
            for des in list_des:
                if f"<img src=" in des and "base64," in des:
                    des = des.split("base64,")
                    des = des[1]
                    des = des.replace(f"\"/>", "")
                    decoded_data = base64.urlsafe_b64decode(des)
                    image_info = self.upload_image(img_base64=decoded_data)
                    if isinstance(image_info, str) or image_info.result != 'success':
                        if isinstance(image_info, str):
                            return Response().error(msg = image_info)
                        else:
                            return image_info
                    image_info = image_info.data
                    field = {
                        "field_type": "image",
                        "image_info": {
                            "image_id": image_info.image_id
                        }
                    }
                    field_list.append(field)
                elif f"<img src=" in des and f"https" in des:
                    des = des.replace(f"<img src=\"", "")
                    des = des.replace(f"\"/>", "")
                    image_info = self.upload_image(img_url=des)
                    if isinstance(image_info, str) or image_info.result != 'success':
                        if isinstance(image_info, str):
                            return Response().error(msg = image_info)
                        else:
                            return image_info
                    image_info = image_info.data
                    field = {
                        "field_type": "image",
                        "image_info": {
                            "image_id": image_info.image_id
                        }
                    }
                    field_list.append(field)
                else:
                    field = {
                        "field_type": "text",
                        "text": des
                    }
                    field_list.append(field)
            post_data["description_info"] = {
                "extended_description": {
                    "field_list": field_list
                }
            }
            post_data["description_type"] = "extended"
        else:
            from bs4 import BeautifulSoup as BSHTML
            soup = BSHTML(product.description, features='html.parser')
            find_tag = soup.findAll()
            if len(find_tag) != 0:
                post_data["description"] = strip_html_tag(product.description)
            else:
                post_data["description"] = product.description[:2999]
            post_data["description_type"] = "normal"
        # return Response().error(msg="bo may dg test")
        shipping_template = product.get('template_data', {}).get('shipping')
        # if product.get('template_data', {}).get('policy'):
        #     product_complaint_policy_temp = product.get('template_data', {}).get('policy')
        #     if product_complaint_policy_temp:
        #         poli_post_data = {
        #             "additional_information": product_complaint_policy_temp.additional_information,
        #             "warranty_time": product_complaint_policy_temp.warranty_time,
        #             "exclude_entrepreneur_warranty": product_complaint_policy_temp.exclude_entrepreneur_warranty,
        #             "complaint_address_id": product_complaint_policy_temp.complaint_address_id
        #         }
        #         post_data["complaint_policy"] = poli_post_data
        if product.condition:
            post_data["condition"] = "NEW" if product.condition.lower() == "new" else "USED"
        category_template = product.get('template_data', {}).get('category')
        if not category_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing category template. Please add a template for the shopee channel')
        if not shipping_template:
            return Response().error(Errors.TEMPLATE_NOT_FOUND,
                                    msg='Missing shipping template. Please add a template for the shopee channel')
        if category_template and category_template.get('primary_category'):
            post_data["category_id"] = category_template.primary_category.category_id
            post_data["brand"]["brand_id"] = category_template.brand.brand_id
            if category_template.get("pre_order"):
                post_data["pre_order"] = {
                    "is_pre_order": category_template.pre_order.is_pre_order,
                    "days_to_ship": category_template.pre_order.days_to_ship
                }
            if category_template.get("specifics"):
                attr_list = []
                for spe in category_template.specifics:
                    if spe.mapping != "":
                        attr = {
                            "attribute_id": spe.override.attribute_id
                        }
                        attr_value = {
                            "value_id": 0,
                            "original_value_name": to_str(spe.value)
                        }
                        # if spe.override.input_validation_type == "FLOAT_TYPE":
                        #     attr_value["original_value_name"] = to_decimal(spe.value)
                        # elif spe.override.input_validation_type == "STRING_TYPE":
                        #     attr_value["original_value_name"] = to_str(spe.value)
                        # else:
                        #     attr_value["original_value_name"] = to_int(spe.value)
                        if spe.override.attribute_unit:
                            attr_value["value_unit"] = spe.override.value_unit
                        attr["attribute_value_list"] = [attr_value]
                        attr_list.append(attr)
                    elif spe.override != "":
                        attr = {
                            "attribute_id": spe.override.attribute_id
                        }
                        attr_val_list = []

                        if spe.override.dateTimeStamp:
                            attr_value = {
                                "value_id": 0,
                                "original_value_name": to_str(to_int(spe.override.dateTimeStamp / 1000)),
                            }
                            attr["attribute_value_list"] = [attr_value]
                            attr_list.append(attr)
                        elif isinstance(spe.override.attribute_value_list, list) and len(
                                spe.override.attribute_value_list) > 0:
                            for attr_val in spe.override.attribute_value_list:
                                if attr_val.value_id:
                                    attr_value = {
                                        "value_id": attr_val.value_id,
                                        "original_value_name": to_str(attr_val.original_value_name),
                                    }
                                    if spe.override.attribute_unit:
                                        attr_value["value_unit"] = spe.override.value_unit
                                    elif attr_val.value_unit:
                                        attr_value["value_unit"] = attr_val.value_unit
                                    attr_val_list.append(attr_value)
                                else:
                                    attr_value = {
                                        "value_id": 0,
                                        "original_value_name": to_str(attr_val.original_value_name),
                                    }
                                    if spe.override.attribute_unit:
                                        attr_value["value_unit"] = spe.override.value_unit
                                    elif attr_val.value_unit:
                                        attr_value["value_unit"] = attr_val.value_unit
                                    attr_val_list.append(attr_value)
                            attr["attribute_value_list"] = attr_val_list
                            attr_list.append(attr)
                        elif isinstance(spe.override.attribute_value_list, list):
                            if len(spe.override.attribute_value_list) == 0:
                                pass
                        elif isinstance(spe.override.attribute_value_list, dict):
                            if spe.override.attribute_value_list.value_id:
                                attr_value = {
                                    "value_id": spe.override.attribute_value_list["value_id"],
                                    "original_value_name": to_str(spe.override.attribute_value_list["original_value_name"]),
                                }
                                if spe.override.attribute_unit:
                                    attr_value["value_unit"] = spe.override.attribute_unit
                                elif spe.override.attribute_value_list.value_unit:
                                    attr_value["value_unit"] = spe.override.attribute_value_list.value_unit
                                attr["attribute_value_list"] = [attr_value]
                                attr_list.append(attr)
                            else:
                                attr_value = {
                                    "value_id": 0,
                                    "original_value_name": to_str(spe.override.attribute_value_list["original_value_name"]),
                                }
                                if spe.override.attribute_unit:
                                    attr_value["value_unit"] = spe.override.value_unit
                                attr["attribute_value_list"] = [attr_value]
                                attr_list.append(attr)
                        elif not spe.override.attribute_value_list:
                            pass
                        else:
                            attr_value = {
                                "value_id": 0,
                                "original_value_name": to_str(spe.override.attribute_value_list),
                            }
                            attr["attribute_value_list"] = [attr_value]
                            attr_list.append(attr)
                    elif spe.value != "":
                        attr = {
                            "attribute_id": spe.value.attribute_id
                        }
                        attr_val_list = []
                        for attr_val in spe.value.attribute_value_list:
                            attr_value = {
                                "value_id": attr_val["value_id"],
                                "original_value_name": to_str(attr_val["original_value_name"]),
                            }
                            attr_val_list.append(attr_value)
                            if spe.override.attribute_unit:
                                attr_value["value_unit"] = spe.override.value_unit
                            elif attr_val.value_unit:
                                attr_value["value_unit"] = spe.override.value_unit
                        attr["attribute_value_list"] = attr_val_list
                        attr_list.append(attr)
                post_data["attribute_list"] = attr_list
        if shipping_template and shipping_template.get('domestic_shipping'):
            ship_info_list = []
            for ship in shipping_template.domestic_shipping:
                if ship.enabled:
                    ship_info = {
                        "size_id": ship.size_id,
                        "enabled": ship.enabled,
                        "logistic_id": ship.logistic_id,
                        "is_free": ship.is_free
                    }
                    if ship.shipping_fee:
                        ship_info["shipping_fee"] = ship.shipping_fee
                    ship_info_list.append(ship_info)
            post_data["logistic_info"] = ship_info_list
        images = list()
        if product.thumb_image:
            images.append(product.thumb_image.url)
        if product.images:
            for img in product.images:
                images.append(img.url)
        shopee_images = list()
        images = images[0:9]
        for image in images:
            image_info = self.upload_image(image)
            if isinstance(image_info, str) or image_info.result != 'success':
                if isinstance(image_info, str):
                    return Response().error(msg = image_info)
                else:
                    return image_info
            image_info = image_info.data
            if image_info:
                shopee_images.append(image_info.image_id)
        # upload_post_data = {
        #     "image": shopee_images
        # }
        # upload_image = self.api("/api/v2/media_space/upload_image", body=upload_post_data, method="post")

        post_data["image"] = {
            "image_id_list": shopee_images
        }
        if product.sku:
            post_data["item_sku"] = product.sku

        if product.weight:
            weight_units = product.weight_units
            post_data["weight"] = self.convert_weight_to_kg(to_decimal(product.weight), weight_units) if self.convert_weight_to_kg(to_decimal(product.weight), weight_units) > 0 else 0.1
        if product.length and product.width and product.height:
            dimension_units = product.dimension_units
            post_data["dimension"] = {
                "package_height": self.convert_dimensions_to_cm(to_decimal(product.height), dimension_units),
                "package_length": self.convert_dimensions_to_cm(to_decimal(product.length), dimension_units),
                "package_width": self.convert_dimensions_to_cm(to_decimal(product.width), dimension_units)
            }
        if product.qty:
            post_data["seller_stock"] = [
                {
                    "stock": product.qty
                }
            ]
        return Response().success(post_data)

    def check_response_import(self, response, convert, entity_type=''):
        id = convert.id if convert.id else convert.code
        if not response:
            return Response().error(msg="Import failed")
        elif response and hasattr(response, 'message') and response.message:
            console = list()
            if isinstance(response.message, list):
                for error in response.error:
                    if isinstance(error, list):
                        error_messages = ' '.join(error)
                    else:
                        error_messages = error
                    console.append(error_messages)
            if isinstance(response.message, dict) or isinstance(response.message, Prodict):
                for key, error in response['message'].items():
                    if isinstance(error, list):
                        error_messages = ' '.join(error)
                    else:
                        error_messages = error
                    console.append(key + ': ' + error_messages)
            else:
                console.append(response['message'])
            msg_errors = '::'.join(console)
            if 'description.length.range' in response['message']:
                msg_errors = "Invalid description length. Description at least 100 characters, " \
                             " Up to 3000 characters (including spaces)"
            elif 'value must contain between 1 and 2 item' in response['message']:
                msg_errors = "Variation of shopee can't be more than 2"
            elif 'You are not in the whitelist' in response['message']:
                msg_errors = " You are not in the whitelist to add images in description, can only upload plain text"
            elif 'product is duplicated' in response['message']:
                msg_errors = " Product is duplicated"
            self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
                     "{}_errors".format(entity_type))
            return Response().error(msg=msg_errors)
        else:
            return Response().success()


    def get_skip_options(self, options):
        len_options = to_len(list(options.keys()))
        if len_options <= 2:
            return []
        skip_options = []
        for option_name, option_values in options.items():
            if to_len(option_values) == 1:
                skip_options.append(option_name)
        if self._state.channel.config.api.skip_options:
            skip_options.extend(self._state.channel.config.api.skip_options)
        return skip_options


    def exceed_variant(self, options, skip_options = None, product_variant = None):
        combinations = list()
        for option_key, values in options.items():
            if skip_options and option_key in skip_options:
                continue
            combinations.append([{option_key: row} for row in values])
        combinations_variants = list(combination(*combinations))
        list_combine_name = list()
        list_key_name = list()
        for index, combi in enumerate(list(combinations_variants)):
            list_name = ""
            if index == 0:
                for val_combi in combi:
                    for values in val_combi:
                        list_key_name.append(values)
            for val_combi in combi:
                for values in val_combi:
                    list_name += val_combi[values]
            list_combine_name.append(list_name)
        list_before_combine_name = list()
        len_variant = len(product_variant)
        if len_variant < len(combinations_variants):
            combinations_variants = combinations_variants[0:len_variant]
            # list_variant_name = ""
            # for key_name in list_key_name:
            #     for attr_name in variant.attributes:
            #         if key_name == attr_name['attribute_name']:
            #             list_variant_name += attr_name['attribute_value_name']
            #             continue
            # list_before_combine_name.append(list_variant_name)
        # for index, comb in enumerate(list_combine_name):
        #     if comb not in list_before_combine_name:
        #         for
        combinations_variants_default = combinations_variants[0]
        combinations_variants_default_attributes = list()
        for attribute in combinations_variants_default:
            attribute_data = ProductVariantAttribute()
            attribute_data.attribute_name = list(attribute.keys())[0]
            attribute_data.attribute_value_name = list(attribute.values())[0]
            combinations_variants_default_attributes.append(attribute_data)
        len_attributes = to_len(combinations_variants_default_attributes)
        if len_attributes == 2:
            for option_key, values in options.items():
                if skip_options and option_key in skip_options:
                    continue
        is_option_group = False
        option_group1 = []
        option_group2 = []
        if len_attributes == 3:
            option_length = []
            for option_key, values in options.items():
                if skip_options and option_key in skip_options:
                    continue
                option_length.append({'name': option_key, 'len': to_len(values)})
            option_length.sort(key = lambda x: x['len'])
            is_option_group = True
            option_group1 = [option_length[2]['name'], option_length[1]['name']]
            option_group2 = [option_length[0]['name']]
        if len_attributes == 4:
            option_length = []
            for option_key, values in options.items():
                if skip_options and option_key in skip_options:
                    continue
                option_length.append({'name': option_key, 'len': to_len(values)})
            option_length.sort(key = lambda x: x['len'])
            is_option_group = True
            option_group1 = [option_length[0]['name'], option_length[3]['name']]
            option_group2 = [option_length[2]['name'], option_length[1]['name']]
        if len_attributes > 4:
            is_option_group = True
            option_group1 = list(options.keys())
        return combinations_variants, is_option_group, option_group1, option_group2

    def variant_combine_to_shopee_data(self, variant, product, variant_options, ind):
        tier_index = []
        for attribute_object in variant_options:
            for index, atb_name in enumerate(attribute_object["option_values"]):
                for attribute in variant:
                    if attribute["attribute_value_name"] == atb_name:
                        tier_index.append(index)
                        continue
                    else:
                        if not attribute["attribute_name"]:
                            continue
        model_post_data = {
            "tier_index": tier_index,
            'original_price': product.variants[ind].price,
            "seller_stock": [{
                "stock": product.variants[ind].qty
            }],
            "model_sku": product.variants[ind].sku
        }
        return model_post_data

    # def combine_atr_title(self, raw_option, max_word = 14):
    #     """raw_option: ['BODY FIT OPTIONS', 'SIZE OPTIONS']"""
    #     if len(raw_option) == 1:
    #         return raw_option[0]
    #
    #     REMOVE_WORDS = ['options']
    #     option_list = [s.lower() for s in raw_option]
    #     combine_list = []
    #     for s in option_list:
    #         s = s.lower()
    #         for r in REMOVE_WORDS:
    #             s = s.replace(r, '')
    #         combine_list.append(s.upper().strip())
    #     return '-'.join(combine_list)
        # if not raw_option or not isinstance(raw_option, list) or not isinstance(raw_option[0], str):
        #     return ''
        #
        # option_split = [s.split() for s in raw_option]
        # min_word = min([len(s) for s in option_split])
        # sub_word = -1
        # combine_string = '-'
        # while sub_word <= min_word:
        #     sub_word += 1
        #     combine_string = '-'.join(
        #         [' '.join(s[:len(s) - sub_word]) for s in option_split]
        #     )
        #     if len(combine_string) <= max_word:
        #         break
        #
        # if combine_string == '-':
        #     combine_string = raw_option[0][:max_word+1]
        #
        # return combine_string

    def after_product_import(self, product_id, convert: Product, product, products_ext):
        category_template = product.get('template_data', {}).get('category')
        if category_template.get("size_chart_id") != "":
            data = {
                "item_id": to_int(product_id),
                "size_chart_id": to_int(category_template.size_chart_id)
            }
            update_size_chart = self.api("/api/v2/product/update_size_chart", body=data, method="post")
            check_response = self.check_response_import(update_size_chart, product, 'update_size_chart')
            if check_response.result != Response().SUCCESS:
                return check_response
        if product.variants:
            tier_variation_post_data = []
            model_post_data = []
            if len(product.variant_attributes) > 2:
                options = self.variants_to_option(product.variants)
                combinations_variants, is_option_group, option_group1, option_group2 = self.exceed_variant(options, product_variant = product.variants)
                variants_list_combine = list()
                attribute_name_list_combine = ""
                variant_options = list()
                for index, row in enumerate(combinations_variants):
                    attributes = list()
                    attributes_list = list()
                    for attribute in row:
                        attribute_data = ProductVariantAttribute()
                        attribute_data.attribute_name = list(attribute.keys())[0]
                        attribute_data.attribute_value_name = list(attribute.values())[0]
                        attributes.append(attribute_data)
                    if is_option_group:
                        option_dict_1 = {}
                        option_dict_2 = {}
                        option_1_name = []
                        option_1_value = []
                        option_2_name = []
                        option_2_value = []
                        for attribute in attributes:
                            if attribute.attribute_name.replace(';', '') in option_group1:
                                option_1_value.append(attribute.attribute_value_name.replace(';', ''))
                                option_1_name.append(attribute.attribute_name.replace(';', ''))
                            else:
                                option_2_value.append(attribute.attribute_value_name.replace(';', ''))
                                option_2_name.append(attribute.attribute_name.replace(';', ''))
                        option_dict_1["attribute_name"] = "-".join(option_1_name)
                        option_dict_1["attribute_value_name"] = "-".join(option_1_value)
                        option_dict_2["attribute_name"] = "-".join(option_2_name)
                        option_dict_2["attribute_value_name"] = "-".join(option_2_value)
                        if index == 0:
                            variant_options.append({"option_name": "-".join(option_1_name),
                                                    "option_values": list()})
                            variant_options.append({"option_name": "-".join(option_2_name),
                                                    "option_values": list()})
                        attributes_list.append(option_dict_1)
                        attributes_list.append(option_dict_2)
                    variants_list_combine.append(attributes_list)
                for variant in variants_list_combine:
                    for attr in variant:
                        for option in variant_options:
                            if attr["attribute_name"] == option["option_name"] and attr["attribute_value_name"] not in option["option_values"]:
                                option["option_values"].append(attr["attribute_value_name"])
                for index, variant in enumerate(variants_list_combine):
                    variant_post_data = self.variant_combine_to_shopee_data(variant, product, variant_options, ind=index)
                    model_post_data.append(variant_post_data)
                for index, variant in enumerate(variant_options):
                    if len(variant["option_name"]) > 14:
                        return Response().error(msg = 'Option name "' + variant["option_name"] + '" exceeds 14 characters. Shopee only allows a maximum of 14 characters for option name')
                    option_list = []
                    for val_variant in variant["option_values"]:
                        if len(val_variant) > 20:
                            return Response().error(msg = 'Optional value name "' + val_variant + '" in Option name "' + variant["option_name"] + '"  exceeds 20 characters. Shopee only allows a maximum of 20 characters for optional value name ')
                        option_data = {
                            "option": val_variant
                        }
                        option_list.append(option_data)

                    tier_variation = {
                        "name": variant["option_name"],
                        "option_list": option_list
                    }
                    tier_variation_post_data.append(tier_variation)

                post_variant_data = {
                    'item_id': to_int(product_id),
                    "tier_variation": tier_variation_post_data,
                    "model": model_post_data
                }
                init_var = self.check_response_retry(post_variant_data, product)
                if not init_var.get("res"):
                    return init_var["checking"]
                product_id_res = init_var["res"]["response"]["model"]
                for index, variant in enumerate(product.variants):
                    self.insert_map_product(variant, variant['_id'], product_id_res[index]["model_id"])
            else:
                for variant in product.variants:
                    variant_post_data = self.variant_to_shopee_data(variant, product)
                    model_post_data.append(variant_post_data)
                for index, variant in enumerate(product.variant_options):
                    if len(variant.option_name) > 14:
                        return Response().error(msg='Option name "' + variant.option_name + '" exceeds 14 characters. Shopee only allows a maximum of 14 characters for option name')
                    option_list = []
                    for val_variant in variant.option_values:
                        if len(val_variant) > 20:
                            return Response().error(msg = 'Optional value name "' + val_variant + '" in Option name "' + variant.option_name + '"  exceeds 20 characters. Shopee only allows a maximum of 20 characters for optional value name ')
                        option_data = {
                            "option": val_variant
                        }
                        option_list.append(option_data)

                    tier_variation = {
                        "name": variant.option_name,
                        "option_list": option_list
                    }
                    tier_variation_post_data.append(tier_variation)

                post_variant_data = {
                    'item_id': to_int(product_id),
                    "tier_variation": tier_variation_post_data,
                    "model": model_post_data
                }
                init_var = self.check_response_retry(post_variant_data, product)
                if not init_var.get("res"):
                    return init_var["checking"]
                product_id_res = init_var["res"]["response"]["model"]
                for index, variant in enumerate(product.variants):
                    self.insert_map_product(variant, variant['_id'], product_id_res[index]["model_id"])
        else:
            return Response().success()
        return Response().success()


    def extend_data_insert_map_product(self):
        extend = super().extend_data_insert_map_product()
        region = self._state.channel.config.api.region
        shop_id = self._state.channel.config.api.shop_id
        extend["region"] = region
        extend["shop_id"] = shop_id
        return extend

    def check_response_retry(self, data, product):
        retry = 0
        checking = None
        while retry < 3:
            var_response = self.api("/api/v2/product/init_tier_variation", body = data, method = "post")
            check_response = self.check_response_import(var_response, product, 'init_variants_product')
            checking = check_response
            if check_response.result != Response().SUCCESS:
                retry += 1
                time.sleep(1)
            else:
                return {"checking": checking, "res": var_response}
        return {"checking": checking}

    def variant_stock_shopee(self, variant: ProductVariant, product, models, product_id):
        tier_index = []
        for attribute in variant.attributes:
            if attribute.use_variant:
                for variation_shopee in models.tier_variation:
                    if attribute.attribute_name == variation_shopee.name:
                        for index, atb_name in enumerate(variation_shopee.option_list):
                            if attribute.attribute_value_name == atb_name.option:
                                tier_index.append(index)
        model_post_data = {
            "seller_stock": [{
                "stock": to_int(variant.qty)
            }]
        }
        price_post_data = {
            "original_price": variant.price
        }
        for model in models.model:
            if tier_index == model.tier_index:
                model_post_data["model_id"] = model.model_id
                price_post_data["model_id"] = model.model_id
                break
        # if product_id:
        #     body = {
        #         "item_id": to_int(product_id),
        #         "price_list": [{
        #             "model_id": model_post_data["model_id"],
        #             "original_price": variant.price
        #         }]
        #     }
        #     response = self.api("/api/v2/product/update_price", body = body, method = "post")
        #     if response["message"].lower() != "":
        #         return Response().error("Could not update price")
        return model_post_data, price_post_data

    def variant_combine_stock_shopee(self, variant, product, variant_options, models, ind, product_id):
        tier_index = []
        for attribute_object in variant_options:
            for index, atb_name in enumerate(attribute_object["option_values"]):
                for attribute in variant:
                    if attribute["attribute_value_name"] == atb_name:
                        tier_index.append(index)
                        continue
                    else:
                        if not attribute["attribute_name"]:
                            continue
        model_post_data = {
            "seller_stock": [{
                "stock": to_int(product.variants[ind].qty)
            }]
        }
        for model in models.model:
            if tier_index == model.tier_index:
                model_post_data["model_id"] = model.model_id
                break
        # if product_id:
        #     body = {
        #         "item_id": to_int(product_id),
        #         "price_list": [{
        #             "model_id": model_post_data["model_id"],
        #             "original_price": product.variants[ind].price
        #         }]
        #     }
        #     response = self.api("/api/v2/product/update_price", body = body, method = "post")
        #     if response["message"].lower() != "":
        #         return Response().error("Could not update price")
        return model_post_data

    def variants_to_option(self, variants):
        max_attribute = 0
        option_src = list()
        for variant in variants:
            attributes = list(filter(lambda x: x.use_variant, variant.attributes))
            if max_attribute <= to_len(attributes):
                max_attribute = to_len(attributes)
                option_src = attributes
        all_option_name = list()
        for option in option_src:
            if option.attribute_name in all_option_name:
                continue
            all_option_name.append(option.attribute_name)
        options = dict()
        for variant in variants:
            if variant and 'visible' in variant:
                if not to_bool(variant.visible):
                    continue
            for attribute in variant.attributes:
                if attribute.attribute_name not in all_option_name:
                    continue
                if attribute.attribute_name not in options:
                    options[attribute.attribute_name] = list()
                if not attribute.attribute_value_name or attribute.attribute_value_name in options[attribute.attribute_name]:
                    continue
                options[attribute.attribute_name].append(attribute.attribute_value_name)
        return options

    def variant_to_shopee_data(self, variant: ProductVariant, product):
        tier_index = []
        for attribute_object in product.variant_options:
            for index, atb_name in enumerate(attribute_object.option_values):
                for attribute in variant.attributes:
                    if attribute.use_variant:
                        if attribute.attribute_value_name == atb_name:
                            tier_index.append(index)
                            continue
                    else:
                        if not attribute.attribute_name:
                            continue
        model_post_data = {
            "tier_index": tier_index,
            'original_price': variant.price,
            "seller_stock": [{
                "stock": variant.qty
            }],
            "model_sku": variant.sku
        }
        return model_post_data

    def product_channel_update(self, product_id, product: Product, products_ext):
        # self.channel_sync_inventory(product_id, product, products_ext)
        # return Response().success()
        category_template = product.get('template_data', {}).get('category')
        check_status = self.api("/api/v2/product/get_item_base_info", params={"item_id_list": [{to_int(product_id)}]}, method="get")
        check_status_res = self.check_response_import(check_status, product, "check_status_product")
        if check_status_res.result != Response().SUCCESS:
            return check_status_res
        if check_status.get("response", {}) and check_status.get("response").get("item_list", {}):
            item_status = check_status.response.item_list[0].item_status
            if item_status.lower() not in ["normal", "unlist"]:
                if "delete" in item_status.lower():
                    self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shopee_status', "sdeleted")
                return Response().error(msg = f"Product status is {item_status} so it cannot be updated!")
        convert_product = self.product_to_shopee_data(product, products_ext, product_id)
        if convert_product.result != Response().SUCCESS:
            return convert_product
        product_data = convert_product.data
        product_data["item_id"] = to_int(product_id)
        # update_price = self.set_inventory_price(to_int(product_id), 0, product_data["original_price"])
        # if update_price.result != Response().SUCCESS:
        #     return update_price
        update = self.api("/api/v2/product/update_item", body=product_data, method="post")
        update_res = self.check_response_import(update, product, "update_product")
        if update_res.result != Response().SUCCESS:
            return update_res
        if category_template.size_chart_id != "":
            data = {
                "item_id": to_int(product_id),
                "size_chart_id": to_int(category_template.size_chart_id)
            }
            update_size_chart = self.api("/api/v2/product/update_size_chart", body=data, method="post")
            check_response = self.check_response_import(update_size_chart, product, 'update_size_chart')
            if check_response.result != Response().SUCCESS:
                return check_response
        model = self.api("/api/v2/product/get_model_list", params={"item_id": product_id}, method="get")
        if model.error:
            return Response().error(msg="Cannot get model")
        models = model.response
        if product.variants:
            stock_list = []
            if len(product.variant_attributes) > 2:
                options = self.variants_to_option(product.variants)
                combinations_variants, is_option_group, option_group1, option_group2 = self.exceed_variant(options, product_variant = product.variants)
                variants_list_combine = list()
                variant_options = list()
                for index, row in enumerate(combinations_variants):
                    attributes = list()
                    attributes_list = list()
                    for attribute in row:
                        attribute_data = ProductVariantAttribute()
                        attribute_data.attribute_name = list(attribute.keys())[0]
                        attribute_data.attribute_value_name = list(attribute.values())[0]
                        attributes.append(attribute_data)
                    if is_option_group:
                        option_dict_1 = {}
                        option_dict_2 = {}
                        option_1_name = []
                        option_1_value = []
                        option_2_name = []
                        option_2_value = []
                        for attribute in attributes:
                            if attribute.attribute_name.replace(';', '') in option_group1:
                                option_1_value.append(attribute.attribute_value_name.replace(';', ''))
                                option_1_name.append(attribute.attribute_name.replace(';', ''))
                            else:
                                option_2_value.append(attribute.attribute_value_name.replace(';', ''))
                                option_2_name.append(attribute.attribute_name.replace(';', ''))
                        option_dict_1["attribute_name"] = "-".join(option_1_name)
                        option_dict_1["attribute_value_name"] = "-".join(option_1_value)
                        option_dict_2["attribute_name"] = "-".join(option_2_name)
                        option_dict_2["attribute_value_name"] = "-".join(option_2_value)
                        if index == 0:
                            variant_options.append({"option_name": "-".join(option_1_name),
                                                    "option_values": list()})
                            variant_options.append({"option_name": "-".join(option_2_name),
                                                    "option_values": list()})
                        attributes_list.append(option_dict_1)
                        attributes_list.append(option_dict_2)
                    variants_list_combine.append(attributes_list)
                for variant in variants_list_combine:
                    for attr in variant:
                        for option in variant_options:
                            if attr["attribute_name"] == option["option_name"] and attr["attribute_value_name"] not in option["option_values"]:
                                option["option_values"].append(attr["attribute_value_name"])
                for index, variant in enumerate(variants_list_combine):
                    variant_post_data = self.variant_combine_stock_shopee(variant, product, variant_options, models, index, product_id)
                    stock_list.append(variant_post_data)
                post_variant_data = {
                    'item_id': to_int(product_id),
                    "stock_list": stock_list
                }
                var_response = self.api("/api/v2/product/update_stock", body = post_variant_data, method = "post")
                check_response = self.check_response_import(var_response, product, 'update_qty_product')
                if check_response.result != "success":
                    return check_response
                attribute_name_list_combine = list()
                for option_name in variants_list_combine[0]:
                    attribute_name_list_combine.append(option_name["attribute_name"])
                list_update = list()
                for index, variant in enumerate(variants_list_combine):
                    variant_attribute_list = list()
                    for variant_value in variant:
                        variant_attribute = ProductVariantAttribute()
                        variant_attribute.attribute_name = variant_value["attribute_name"]
                        variant_attribute.attribute_value_name = variant_value["attribute_value_name"]
                        variant_attribute.id = random_string(16)
                        variant_attribute_list.append(variant_attribute)
                    list_update.append(variant_attribute_list)
                for index, variant in enumerate(product.variants):
                    self.get_model_catalog().update_field(variant['_id'], f'channel.channel_{self.get_channel_id()}.attributes', list_update[index])
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.variant_attributes', attribute_name_list_combine)
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.variant_options', variant_options)
                seo_url = ""
                region = self._state.channel.config.api.region
                if region == "VN" or region == "SG" or region == "JP" or region == "PH" or region == "TW" or region == "CN" or region == "CL":
                    seo_url = f"https://shopee.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
                elif region == "BR" or region == "CO" or region == "MX" or region == "MY":
                    seo_url = f"https://shopee.com.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
                elif region == "ID" or region == "TH":
                    seo_url = f"https://shopee.co.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shopee_url', seo_url)
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shop_id', self._state.channel.config.api.shop_id)
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.region', self._state.channel.config.api.region)
            else:
                price_list_update = list()
                for variant in product.variants:
                    variant_name = ""
                    for attr in variant.attributes:
                        variant_name += attr.attribute_value_name + "/"
                    variant_name = variant_name.rstrip("/")
                    variant_post_data, price_post_data = self.variant_stock_shopee(variant, product, models, product_id = product_id)
                    if variant_post_data["model_id"]:
                        stock_list.append(variant_post_data)
                    else:
                        return Response().error(msg = f"Cannot get model id for variant {variant_name}. Please click to UPDATE FROM SHOPEE and try publish again.")
                    if price_post_data["model_id"]:
                        price_list_update.append(price_post_data)
                    else:
                        return Response().error(msg = f"Cannot get model id for variant {variant_name}. Please click to UPDATE FROM SHOPEE and try publish again.")
                post_variant_data = {
                    'item_id': to_int(product_id),
                    "stock_list": stock_list
                }
                var_response = self.api("/api/v2/product/update_stock", body=post_variant_data, method="post")
                check_response = self.check_response_import(var_response, product, 'update_qty_product')
                if check_response.result != "success":
                    return check_response
                post_price_data = {
                    'item_id': to_int(product_id),
                    "price_list": price_list_update
                }
                update_price_response = self.api("/api/v2/product/update_price", body = post_price_data, method = "post")
                check_response_price = self.check_response_import(update_price_response, product, 'update_price_product')
                if check_response_price.result != "success":
                    return check_response_price
                seo_url = ""
                region = self._state.channel.config.api.region
                if region == "VN" or region == "SG" or region == "JP" or region == "PH" or region == "TW" or region == "CN" or region == "CL":
                    seo_url = f"https://shopee.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
                elif region == "BR" or region == "CO" or region == "MX" or region == "MY":
                    seo_url = f"https://shopee.com.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
                elif region == "ID" or region == "TH":
                    seo_url = f"https://shopee.co.{region.lower()}/product/{self._state.channel.config.api.shop_id}/{product_id}"
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shopee_url', seo_url)
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.shop_id', self._state.channel.config.api.shop_id)
                self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.region', self._state.channel.config.api.region)
        else:
            return Response().success()
        return Response().success()

    @staticmethod
    def convert_weight_to_kg(weight, unit):
        weight_unit_to_kg = {
            "lb": 0.45359237,
            "lbs": 0.45359237,
            "g": 0.001,
            "oz": 0.02834952
        }
        if unit.lower() in ["", "kg", "kgs"]:
            result = weight
        else:
            result = weight * to_decimal(weight_unit_to_kg[unit.lower()])
        return to_decimal(result, 2)

    @staticmethod
    def convert_dimensions_to_cm(dimension, unit):
        if unit.lower() in ["inch", "in", "inches"]:
            result = dimension * 2.54
        elif unit.lower() == "m":
            result = dimension * 100
        else:
            result = dimension
        return to_int(result)

    def channel_sync_inventory(self, product_id, product, products_ext):
        setting_price = True if self._state.channel.config.setting.get('price', {}).get(
            'status') != 'disable' else False
        setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
        if not setting_price and not setting_qty:
            return Response().success()
        params = {"item_id": product_id}
        product_data = self.api("/api/v2/product/get_model_list", params=params)
        if not product_data.get('response'):
            return Response().error(msg = product_data["error"])
        shopee_variants = {row["model_id"]: row for row in product_data.response.model}
        if not product.variants:
            default_shopee_variant = product_data.response.model[0] if len(product_data.response.model) > 0 else 0
            if setting_qty:
                self.set_inventory_qty(product_id, 0 if default_shopee_variant == 0 else default_shopee_variant.id, product.qty)
            if setting_price:
                self.set_inventory_price(product_id, 0 if default_shopee_variant == 0 else default_shopee_variant.id, product.price)
        else:
            channel_id = self._state.channel.id
            for variant in product.variants:
                variant_id = to_int(variant.channel[f'channel_{self.get_channel_id()}'].get('product_id'))
                if not variant_id:
                    continue
                if setting_qty and shopee_variants.get(variant_id):
                    qty_res = self.set_inventory_qty(product_id, shopee_variants[variant_id].model_id, variant.qty)
                    check_res_qty = self.check_response_import(qty_res, product, "product")
                    if check_res_qty.result != Response().SUCCESS:
                        return check_res_qty
                if setting_price and shopee_variants.get(variant_id):
                    price_res = self.set_inventory_price(product_id, shopee_variants[variant_id].model_id, variant.price)
                    check_res_price = self.check_response_import(price_res, product, "product")
                    if check_res_price.result != Response().SUCCESS:
                        return check_res_price
        return Response().success()

    def set_inventory_qty(self, product_id, model_id, qty):
        body = {
            "item_id": to_int(product_id),
            "stock_list": [{
                "model_id": model_id if model_id else 0,
                "seller_stock": [{
                    "stock": qty
                }]
            }]
        }
        response = self.api("/api/v2/product/update_stock", body=body, method="post")
        if response["message"].lower() != "":
            return Response().error("Could not update quantity")
        return response

    def set_inventory_price(self, product_id, model_id, price):
        body = {
            "item_id": to_int(product_id),
            "price_list": [{
                "model_id": model_id if model_id else 0,
                "original_price": price
            }]
        }
        response = self.api("/api/v2/product/update_price", body=body, method="post")
        if response["message"].lower() != "":
            return Response().error("Could not update price")
        return response

    def delete_product_import(self, product_id):
        body = {
            "item_id": to_int(product_id)
        }
        remove = self.api(f'/api/v2/product/delete_item', body=body, method='post')
        if not remove.warning:
            return Response().error(msg="Delete product failed")
        return Response().success()

    def get_order_by_id(self, order_id):
        list_res = ["buyer_user_id,buyer_username,estimated_shipping_fee,recipient_address,actual_shipping_fee ,"
                    "goods_to_declare,note,note_update_time,item_list,pay_time,dropshipper,dropshipper_phone,split_up,"
                    "buyer_cancel_reason,cancel_by,cancel_reason,actual_shipping_fee_confirmed,buyer_cpf_id,"
                    "fulfillment_flag,pickup_done_time,package_list,shipping_carrier,payment_method,total_amount,"
                    "buyer_username,invoice_data, checkout_shipping_carrier, reverse_shipping_fee,recipient_address, "
                    "order_chargeable_weight_gram, edt, prescription_images, prescription_check_status "]
        params = {
            "order_sn_list": order_id,
            "response_optional_fields": list_res
        }
        order = self.api('/api/v2/order/get_order_detail', params=params)
        if not order or not order.response:
            return Response().error()
        return Response().success(order.response['order_list'][0])

    def get_orders_main_export(self):
        if self._flag_finish_order:
            return Response().finish()
        if not self._state.pull.process.products.id_src:
            self._state.pull.process.products.id_src = 0
        limit_data = self._state.pull.setting.orders
        start_time = self.get_order_start_time()
        last_modifier = self._state.pull.process.orders.max_last_modified
        orders_filter_condition = {
            "time_range_field": "create_time",
            # "time_from": 1685694960,
            "time_from": to_timestamp(start_time),
            "page_size": 100,  # limit_data,
            # "time_to": 1686694960,
            "time_to": to_timestamp(start_time) + 1200000,
            "response_optional_fields": "order_status"
        }
        if last_modifier:
            orders_filter_condition["time_range_field"] = "update_time"
            orders_filter_condition["time_from"] = to_timestamp(last_modifier)
            orders_filter_condition["time_to"] = to_timestamp(last_modifier) + 1200000
        if self._next_cursor_order:
            orders_filter_condition["cursor"] = self._next_cursor_order
        orders_api = self.api("/api/v2/order/get_order_list", params=orders_filter_condition)
        self._next_cursor_order = orders_api.response.next_cursor
        if not self._next_cursor_order or not orders_api.response.more:
            self._flag_finish_order = True
        if not orders_api["response"]:
            return Response().error(msg="Could not get orders from shopee")
        order_id_list = ""
        for order in orders_api.response.get("order_list"):
            order_id_list += order.order_sn + ","

        list_res = ["buyer_user_id,buyer_username,estimated_shipping_fee,recipient_address,actual_shipping_fee ,"
                    "goods_to_declare,note,note_update_time,item_list,pay_time,dropshipper,dropshipper_phone,split_up,"
                    "buyer_cancel_reason,cancel_by,cancel_reason,actual_shipping_fee_confirmed,buyer_cpf_id,"
                    "fulfillment_flag,pickup_done_time,package_list,shipping_carrier,payment_method,total_amount,"
                    "buyer_username,invoice_data, checkout_shipping_carrier, reverse_shipping_fee,recipient_address, "
                    "order_chargeable_weight_gram, edt, prescription_images, prescription_check_status "]
        body = {
            "order_sn_list": [order_id_list.rstrip(",")],
            "response_optional_fields": list_res
        }
        orders_detail = self.api("/api/v2/order/get_order_detail", params=body, method="get")
        if not orders_detail["response"]:
            return Response().error("Could not get order detail")
        order_detail_list = orders_detail["response"]["order_list"]
        return Response().success(data=order_detail_list)

    def get_orders_ext_export(self, orders):
        extend = Prodict()
        for order_detail in orders:
            order_id = order_detail.order_sn
            extend.set_attribute(to_str(order_id), Prodict())
        return Response().success(extend)

    def get_order_id_import(self, convert: Order, order, orders_ext):
        return order.order_sn

    def set_order_max_last_modifier(self, last_modifier):
        if last_modifier and (
                not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S") > to_timestamp(
            self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
            self._order_max_last_modified = last_modifier

    def convert_ms_timestamp_to_datetime(self, time_data, format="%Y-%m-%d %H:%M:%S"):
        time_data = to_int(time_data) / 1000
        try:
            timestamp = datetime.fromtimestamp(time_data)
            res = timestamp.strftime(format)
            return res
        except (Exception,):
            log_traceback()
            return get_current_time(format)

    def convert_order_export(self, order, orders_ext, channel_id=None):
        update_time = convert_format_time(order.update_time)
        self.set_order_max_last_modifier(update_time)
        order_data = Order()
        order_id = order.order_sn
        order_data.id = order_id
        order_data.order_number = order_id
        order_data.status = self.convert_order_status(order.order_status)
        # order_data.tax.amount = order.invoice_data.taxes
        order_data.shipping.title = order.shipping_carrier
        order_data.shipping.amount = to_decimal(order.estimated_shipping_fee)
        # order_data.subtotal = to_decimal(order.sub_total)
        order_data.total = to_decimal(order.total_amount)
        order_data.currency = order.currency
        order_data.created_at = convert_format_time(order.create_time)
        order_data.updated_at = convert_format_time(order.update_time)
        order_data.channel_data = {
            "order_status": self.convert_order_status(order.order_status),
            "created_at": order_data.created_at,
            "order_id": order_id
        }
        # Customer
        order_data.customer.id = order.buyer_user_id
        address = OrderAddress()
        if order.recipient_address:
            if len(order.recipient_address.name.split(" ")) >= 2:
                first_name, last_name = self.split_customer_fullname(order.recipient_address.name)
                order_data.customer.first_name = first_name
                order_data.customer.last_name = last_name
                order_data.customer.email = last_name + "@shopee.com"
            else:
                order_data.customer.last_name = order.recipient_address.name
                order_data.customer.email = order.recipient_address.name + "@shopee.com"
                address.last_name = order.recipient_address.name
            address.address_1 = order.recipient_address.full_address
            address.city = order.recipient_address.city
            address.state.state_code = order.recipient_address.state
            address.country.country_code = order.recipient_address.region
            address.country.country_name = order.recipient_address.region
            address.telephone = order.recipient_address.phone
            address.postcode = order.recipient_address.zipcode
            # address.company = invoice_info.company_name
            order_data.shipping_address.update(address)
            order_data.billing_address.update(address)
            order_data.customer_address.update(address)
        # product
        sub_total = 0
        order_products = order.item_list
        if order_products:
            for order_product in order_products:
                order_item = OrderProducts()
                order_item.product_id = order_product.model_id if order_product.model_id != 0 else order_product.item_id
                order_item.product_sku = order_product.item_sku
                order_item.listing_id = order_product.item_id
                order_item.product_name = order_product.item_name + " - " + order_product.model_name
                model_list_name = order_product.model_name.split(",")
                order_item.qty = order_product.model_quantity_purchased
                order_item.price = order_product.model_original_price
                order_item.discount_amount = to_decimal(order_product.model_original_price) - to_decimal(
                    order_product.model_discounted_price) * to_int(
                    order_product.model_quantity_purchased)
                order_item.subtotal = to_decimal(order_product.model_original_price) * to_int(
                    order_product.model_quantity_purchased)
                sub_total += order_item.subtotal
                order_item.total = order_item.subtotal - order_item.discount_amount
                tier_index = list()
                if order_product.model_id != 0:
                    product_variants = self.api("/api/v2/product/get_model_list", params={"item_id": order_product.item_id})
                    product_variants = product_variants.response
                    for model in product_variants.model:
                        if model.model_id == order_product.model_id:
                            tier_index = model.tier_index
                            if model.model_sku:
                                order_item.product_sku = model.model_sku
                                break
                    order_item.is_variant = True
                    if len(tier_index) > 0:
                        for index, tier in enumerate(tier_index):
                            option_data = OrderItemOption()
                            option_data.option_value_name = model_list_name[index]
                            option_data.option_name = product_variants.tier_variation[index].name
                            order_item.options.append(option_data)
                order_data.products.append(order_item)
        # Shipment
        order_data.subtotal = sub_total
        order_data.discount.amount = order_data.subtotal + order_data.shipping.amount - order_data.total
        tracking_info = self.api("/api/v2/logistics/get_tracking_number", {"order_sn": order_id})
        order_shipment = Shipment()
        if tracking_info.response and tracking_info.response.get('tracking_number'):
            order_shipment.tracking_number = tracking_info.response.tracking_number
        if order.pickup_done_time != 0:
            order_shipment.shipped_at = convert_format_time(order.pickup_done_time)
        order_data.shipments = order_shipment
        # History
        order_history = OrderHistory()
        if order.message_to_seller:
            order_history.comment = order.message_to_seller
            order_data.history.append(order_history)
        if order.recipient_address.note:
            order_history.comment = order.recipient_address.note
            order_history.staff_note = True
            order_data.history.append(order_history)
        return Response().success(order_data)

    def channel_order_cancel(self, order_id, order, current_order):
        order_status = current_order.order_status
        body = {
            "order_sn": to_str(order_id),
            "cancel_reason": "OUT_OF_STOCK"
        }
        order_canceled = self.api("/api/v2/order/cancel_order", body=body, method="post")
        if order_canceled["message"].lower() != Response().SUCCESS:
            return Response().error(msg="Cancel order failed")
        return Response().success()

    def channel_order_completed(self):
        return Response().success()

    def order_sync_inventory(self, order: Order, setting_order):
        return Response().success()

    def channel_assign_category_template(self, product, template_data) -> Product:
        """func choose mapping and override data from the category template"""

        item_specifics = template_data.get('specifics')
        if not item_specifics:
            return product
        for specific in item_specifics:
            status_changed = False
            if not specific.override and not specific.mapping:
                continue
            if specific.override:
                value = specific.override
            # if specific.override == '[]' and specific.mapping:  # hotfix
            # 	value = specific.mapping
            else:
                status_changed = True
                value = specific.mapping
            specific.value = self.assign_attribute_to_field(value, product)

        product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['specifics'] = item_specifics

        return product


    def channel_assign_shipping_template(self, product, template_data):
        dimensions = template_data.get('dimensions')
        if not dimensions:
            return product
        for dimension in dimensions:
            if dimension['name'] not in ['length', 'weight', 'width', 'height'] or not dimension.get('override') and not dimension.get('mapping'):
                continue
            if dimension.get('override'):
                value = dimension['override']
            else:
                value = dimension['mapping']
            value = self.assign_attribute_to_field(value, product)
            if to_decimal(value):
                dimension['value'] = value
                product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = value
        try:
            if product.channel[f'channel_{self.get_channel_id()}'].get('template_data', {}).get('shipping', {}).get('dimensions'):
                product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['dimensions'] = dimensions
        except:
            pass

        return product

    def channel_sync_title(self, product_id, product, products_ext):
        title = product.name
        if title != product.name:
            self._extend_product_map['name'] = title
        description = product.description or product.short_description or title
        post_data = {
            'title': title[0:120],
        }
        from bs4 import BeautifulSoup as BSHTML
        soup = BSHTML(product.description, features = 'html.parser')
        find_tag = soup.findAll()
        if len(find_tag) != 0:
            post_data["description"] = strip_html_tag(description)
        else:
            post_data["description"] = description
        post_data["description_type"] = "normal"
        if not self.is_setting_sync_title():
            del post_data['title']
        if not self.is_setting_sync_description():
            del post_data['description']
            del post_data['description_type']
        if post_data:
            post_data["item_id"] = to_int(product_id)
            res = self.api("/api/v2/product/update_item", method = 'post', body = post_data)
            if res['error']:
                return Response().error(msg = res.get('message'))
        return Response().success()