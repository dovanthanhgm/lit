import copy
from datetime import timedelta

import chardet
import requests

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.tracking_company import TrackingCompany
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory, CatalogCategoryParent
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory, OrderAddressCountry, Shipment, OrderShipmentItem
from datasync.models.constructs.product import *


class ModelChannelsBigcommerce(ModelChannel):
	ORDER_STATUS = {
		"Incomplete": Order.OPEN,
		"Pending": Order.SHIPPING,
		"Shipped": Order.COMPLETED,
		"Partially Shipped": Order.SHIPPING,
		"Refunded": Order.REFUNDED,
		"Cancelled": Order.CANCELED,
		"Declined": Order.CANCELED,
		"Awaiting Payment": Order.AWAITING_PAYMENT,
		"Awaiting Pickup": Order.READY_TO_SHIP,
		"Awaiting Shipment": Order.READY_TO_SHIP,
		"Completed": Order.COMPLETED,
		"Awaiting Fulfillment": Order.READY_TO_SHIP,
		"Manual Verification Required": Order.AWAITING_PAYMENT,
		"Disputed": Order.AWAITING_PAYMENT,
		"Partially Refunded": Order.REFUNDED,
	}
	BIGCOMMERCE_ORDER_STATUS = {
		"0": Order.OPEN,
		"1": Order.SHIPPING,
		"2": Order.COMPLETED,
		"3": Order.SHIPPING,
		"4": Order.REFUNDED,
		"5": Order.CANCELED,
		"6": Order.CANCELED,
		"7": Order.AWAITING_PAYMENT,
		"8": Order.READY_TO_SHIP,
		"9": Order.READY_TO_SHIP,
		"10": Order.COMPLETED,
		"11": Order.SHIPPING,
		"12": Order.AWAITING_PAYMENT,
		"13": Order.AWAITING_PAYMENT,
		"14": Order.REFUNDED,
	}

	MAP_ORDER_STATUS = {
		Order.OPEN: 1,
		Order.AWAITING_PAYMENT: 7,
		Order.READY_TO_SHIP: 11,
		Order.SHIPPING: 11,
		Order.COMPLETED: 10,
		Order.CANCELED: 5,
	}
	DATE_FORMAT = '%Y-%m-%dT%H:%M:%S'

	def __init__(self):
		super().__init__()
		self._categories = dict()
		self._brands = dict()
		self._flag_finish_product = False
		self._product_next_link = False
		self._weight_units = False
		self._dimension_units = False
		self._store_information = False


	def get_api_info(self):
		return {
			'api_path': "API Path",
			'client_id': "Client ID/Username",
			'api_token': "API Access Token"
		}


	def requests(self, url, data = None, headers = None, method = 'get', retry = 0):
		def log_request_error(_res):
			error = {
				'method': method,
				'status': _res.status_code,
				'data': to_str(data),
				'header': to_str(_res.headers),
				'response': _res.text,
			}
			self.log_request_error(url, **error)


		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if method.lower() == 'get' and data:
			request_options['params'] = data
		if method.lower() in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			index = 0
			response = requests.request(method, url, **request_options)
			if response.status_code > 204:
				log_request_error(response)
			while response.status_code == 429 and retry <= 5:
				retry += 1
				time_reset_ms = to_decimal(response.headers.get('X-Rate-Limit-Time-Reset-Ms'))
				time_reset = math.ceil(time_reset_ms / 1000)
				self.log(f"sleep {max(time_reset, 1)}s", 'sleep')
				time.sleep(max(time_reset, 1))
				return self.requests(url, data, headers, method, retry)
			self._last_header = response.headers
			self._last_status = response.status_code
			response_data = response.text
			response_data_decode = json_decode(response_data)
			if not response_data_decode and method != 'delete':
				log_request_error(response)
				return response_data_decode
			if response_data_decode:
				try:
					response_prodict = Prodict(**response_data_decode)
				except Exception:
					response_prodict = response_data_decode
				response_data = response_prodict
		except requests.exceptions.SSLError as e:
			if retry < 5:
				retry += 1
				time.sleep(retry * 2)
				return self.requests(url, data, headers, method, retry)
		except requests.exceptions.ReadTimeout as e:
			if retry < 5:
				retry += 1
				time.sleep(retry * 2)
				return self.requests(url, data, headers, method, retry)
		except Exception as e:
			self.log_traceback()
			# log_request_error(response)

		return response_data


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# order = self.get_product_by_id(9891)
		# order_ext = self.get_product_ext_export([order['data']])
		# convert = self.convert_product_export(order['data'], order_ext)

		try:
			store = self.get_store_information()
			if self._last_status != 200:
				return Response().error(Errors.BIGCOMMERCE_API_INVALID)

		except Exception as e:
			return Response().error(Errors.BIGCOMMERCE_API_INVALID)
		# self._state.channel.clear_process.function = "clear_channel_taxes"
		return Response().success()


	def get_weight_units(self):
		if self._weight_units:
			return self._weight_units
		store = self.get_store_information()
		if not store:
			return 'oz'
		unit = store['weight_units']
		if unit == 'Grams':
			self._weight_units = 'g'
		elif unit == 'LBS':
			self._weight_units = 'lb'
		elif unit == 'Tonnes':
			self._weight_units = 't'
		elif unit in ['Kilograms', 'KGS']:
			self._weight_units = 'kg'
		else:
			self._weight_units = 'oz'
		return self._weight_units


	def get_dimension_units(self):
		if self._dimension_units:
			return self._dimension_units
		store = self.get_store_information()
		if not store:
			return 'in'
		unit = store['dimension_units']
		if unit == 'Centimeters':
			self._dimension_units = 'cm'
		else:
			self._dimension_units = 'in'
		return self._dimension_units


	def get_store_information(self):
		if self._store_information:
			return self._store_information
		self._store_information = self.api('/store.json', api_version = 2)
		return self._store_information


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		api_path = to_str(self._state.channel.config.api.api_path).strip('/')
		store_hash = re.findall("https://api.bigcommerce.com/stores/(.*)/v[2,3]", api_path)
		self.set_identifier(store_hash[0])
		return Response().success()


	def after_create_channel(self, data):
		if is_local():
			return Response().success()
		return Response().success()
		entities = ['order']
		events = dict()
		if self.is_channel_default():
			for entity in entities:
				events[f"store/{entity}/updated"] = f'{entity}/update'
		events["store/product/deleted"] = 'product/delete'
		for event, url in events.items():
			webhook_data = {
				"scope": event,
				"destination": get_server_callback(f'merchant/bigcommerce/webhook/{data.channel_id}/{url}'),
				"is_active": True,
				"headers": {
					"username": "litcommerce",
					"password": hash_hmac('sha256', to_str(data.channel_id), get_config_ini('server', 'private_key'))
				}
			}
			webhook = self.api('hooks', webhook_data, 'post', api_version = 2)

		return Response().success()


	def validate_api_info(self):
		validate = super(ModelChannelsBigcommerce, self).validate_api_info()
		if validate.result != Response.SUCCESS:
			return validate
		api_path = to_str(self._state.channel.config.api.api_path).strip('/')
		store_hash = re.findall("https://api.bigcommerce.com/stores/(.*)/v[2,3]", api_path)
		if not store_hash:
			return Response().error(Errors.BIGCOMMERCE_API_PATH_INVALID)
		return Response().success()


	def get_max_last_modified_product(self):
		last_modified = False
		if self._state.pull.process.products.last_modified:
			if to_str(self._state.pull.process.products.last_modified).isnumeric():
				last_modified = convert_format_time(self._state.pull.process.products.last_modified, new_format = "%Y-%m-%d")
			else:
				last_modified = self._state.pull.process.products.last_modified[0:10]

		if not last_modified:
			return False
		date_1 = datetime.strptime(last_modified, "%Y-%m-%d")

		end_date = date_1 - timedelta(days = 1)
		return end_date.strftime("%Y-%m-%d")


	def get_product_updated_at(self, product):
		return product.date_modified


	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(updated_at[0:10], '%Y-%m-%d')


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent

		# product
		if self.is_product_process():
			id_src_prd = self._state.pull.process.products.id_src
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.total = 0
			if not self._state.pull.process.products.id_src:
				self._state.pull.process.products.id_src = 0
			product_filter_condition = {
				'id:greater': id_src_prd,
				'limit': 1
			}
			if not self.is_import_inactive():
				product_filter_condition['is_visible'] = 1
			if self.is_refresh_process():
				self._state.pull.process.products.total_view = 0
				product_filter_condition = {
					"limit": 1
				}
				last_modified = self.get_max_last_modified_product()
				if last_modified:
					product_filter_condition['date_modified:min'] = last_modified
			else:
				if self._state.channel.config.api.filter_in_stock:
					product_filter_condition['inventory_level:min'] = 1
			if self._request_data.get('include_filters'):
				for field_filter, value in self._request_data['include_filters'].items():
					if field_filter not in ['id:in', 'brand_id', 'is_visible', 'categories:in']:
						continue
					if field_filter == 'id:in':
						product_filter_condition[field_filter] = value.split(",")
					else:
						if field_filter == 'is_visible':
							value = 1 if value else 0
						product_filter_condition[field_filter] = value
			products_api = self.api('catalog/products', data = product_filter_condition)
			if products_api and products_api.meta:
				if self.is_refresh_process():
					self._state.pull.process.products.total = -1
					self._state.pull.process.products.total_view = products_api.meta.pagination.total

				else:
					self._state.pull.process.products.total = products_api.meta.pagination.total
		# category
		if self.is_category_process():
			self._state.pull.process.categories.total = 0
			self._state.pull.process.categories.imported = 0
			# self._state.pull.process.categories.new_entity = 0
			self._state.pull.process.categories.error = 0
			# self._state.pull.process.categories.id_src = 0
			# start_time = self.get_order_start_time('iso')
			# last_modifier = self._state.pull.process.orders.max_last_modified
			id_src = self._state.pull.process.categories.id_src
			if id_src:
				id_src = to_int(id_src) + 1
			params = {
				"id:min": id_src,
				"limit": 1,
			}

			category_api = self.api("catalog/categories", data = params)
			if category_api and category_api.meta:
				self._state.pull.process.categories.total = category_api.meta.pagination.total
		# order
		if self.is_order_process():
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			start_time = self.get_order_start_time('iso')
			last_modifier = self._state.pull.process.orders.max_last_modified
			params = {
				"min_date_created": start_time,
			}
			if last_modifier:
				params['min_date_modified'] = last_modifier
				self.set_order_max_last_modifier(last_modifier)

			orders_api = self.api("/orders/count.json", data = params, api_version = 2)
			if orders_api and orders_api.count:
				self._state.pull.process.orders.total = orders_api.count
		return Response().success()


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S") > to_timestamp(self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
			self._order_max_last_modified = last_modifier


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		# try:
		# 	api_delete_categories = self.api('/categories', None, 'Delete', version = 2)
		# except Exception:
		# 	self.log_traceback()
		# 	return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			api_delete_pro = self.api('/products', None, 'Delete')
			api_delete_options = self.api('/options', None, 'Delete')
			api_delete_opt_set = self.api('/option_sets', None, 'Delete')
			res = self.api('/brands', None, 'Delete')
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_category_by_id(self, category_id):
		api_categories = self.api(f'/catalog/categories/{category_id}', data = {'include_fields': 'parent_id,name'})
		categories_data = api_categories.data
		if not categories_data:
			return Response().error(msg = "Could not get category data from Bigcommerce")
		return Response().success(api_categories.data)


	def get_categories_main_export(self):
		limit_data = 250
		id_src = self._state.pull.process.categories.id_src
		categories_data = self.api('/catalog/categories', data = {'limit': limit_data, 'id:greater': id_src, 'include_fields': 'parent_id,name'})
		if self._last_status != 200:
			return Response().finish()
		return Response().success(categories_data.data)


	def get_categories_ext_export(self, categories):
		return Response().success()


	def convert_category_export(self, category, categories_ext):
		category_data = CatalogCategory()
		parent = CatalogCategoryParent()
		parent['id'] = 0
		category_data['id'] = category['id']
		category_data['name'] = category['name']
		category_data['parent'] = parent
		category_data.path = category['name']
		if to_int(category['parent_id']) > 0:
			parent = self.get_category_parent(category['parent_id'])
			if parent.result == Response.SUCCESS:
				parent = parent['data']
				category_data['parent'] = parent
				category_data.parent_id = parent.id
				category_data.path = f'{parent.path} > {category.name}'
		return Response().success(category_data)


	def get_category_parent(self, parent_id):
		categories_data = self.get_category_by_id(parent_id)
		if categories_data.result != Response.SUCCESS:
			return categories_data
		category = categories_data['data']
		categories_ext = self.get_categories_ext_export([categories_data['data']])
		parent_data = self.convert_category_export(category, categories_ext.data)
		return parent_data


	#
	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']


	# def category_import(self, convert, category, categories_ext):
	# 	parent_id = 0
	# 	active = True if convert['active'] else False
	# 	if convert['parent'] and 'id' in convert['parent'] and (convert['parent']['id'] or convert['parent']['code']) and convert['id'] != convert['parent']['id']:
	# 		parent_import = self.import_category_parent(convert['parent'])
	# 		if parent_import['result'] == 'success' and parent_import['data']:
	# 			parent_id = parent_import['data']
	# 			if not parent_import['active']:
	# 				active = False
	# 	category_name = get_value_by_key_in_dict(convert, 'name', '')
	# 	cat_data = {
	# 		'parent_id': parent_id if parent_id else 0,
	# 		'name': category_name[0:50],
	# 		'description': get_value_by_key_in_dict(convert, 'description', ' '),
	# 		'page_title': get_value_by_key_in_dict(convert, 'meta_title', ''),
	# 		'search_keywords': get_value_by_key_in_dict(convert, 'meta_keyword', '')[:254],
	# 		'meta_keywords': get_value_by_key_in_dict(convert, 'meta_keyword', '').split(','),
	# 		'meta_description': get_value_by_key_in_dict(convert, 'meta_description', ''),
	# 		'sort_order': to_int(get_value_by_key_in_dict(convert, 'sort_order', 0)),
	# 		'is_visible': active,
	# 	}
	# 	if '&lt;' in cat_data['description']:
	# 		cat_data['description'] = to_str(cat_data['description']).replace('&lt;', '<')
	# 	if '&gt;' in cat_data['description']:
	# 		cat_data['description'] = to_str(cat_data['description']).replace('&gt;', '>')
	# 	if '&quot;' in cat_data['description']:
	# 		cat_data['description'] = to_str(cat_data['description']).replace('&quot;', '"')
	# 	if 'seo_url' in convert and convert['seo_url']:
	# 		default_url = to_str(convert['seo_url']).replace(' ', '-')
	# 		default_url = to_str(default_url).replace('--', '-')
	# 		if default_url:
	# 			cat_data['custom_url'] = {
	# 				'url': '/' + default_url.lstrip('/'),
	# 				'is_customized': True
	# 			}
	#
	# 	response = self.api('/catalog/categories', cat_data, 'Post')
	# 	old_name = cat_data['name']
	# 	if (not response or response == '') and cat_data['image_url']:
	# 		check_image = self.image_exist(cat_data['image_url'])
	# 		if not check_image:
	# 			del cat_data['image_url']
	# 			response = self.api('/catalog/brands', cat_data, 'Post')
	# 	response_data = json_decode(response)
	# 	n = 0
	# 	while response_data and 'status' in response_data and to_str(response_data['status']) == '409' and n < 5:
	# 		n += 1
	# 		index = to_str(to_int(time.time()))
	# 		max_len = 49 - len(index)
	# 		new_name = old_name[0:max_len] + ' ' + to_str(index)
	# 		cat_data['name'] = new_name
	# 		response = self.api('/catalog/categories', cat_data, 'Post')
	# 		response_data = json_decode(response)
	# 	if 'status' in response_data and to_str(response_data['status']) in ['400', '422']:
	# 		return Response.error(msg = 'Category ' + to_str(convert['id']) + 'import fail. Error: ' + to_str(response_data['title']))
	# 	if not response_data or 'data' not in response_data or to_len(response_data['data']) == 0:
	# 		return Response.error(msg = 'Category ' + to_str(convert['id']) + 'import fail.')
	#
	# 	# self.insert_map(self.TYPE_CATEGORY, convert['id'], response_data['data']['id'], convert['code'], response_data['data']['name'], active)
	# 	res = response_success(response_data['data']['id'])
	# 	res['active'] = active
	# 	return res

	# def import_category_parent(self, convert_parent):
	# 	check_parent_imported = self.select_map(self._migration_id, self.TYPE_CATEGORY, convert_parent['id'], None, convert_parent['code'])
	# 	category = get_value_by_key_in_dict(convert_parent, 'category', dict())
	# 	categories_ext = get_value_by_key_in_dict(convert_parent, 'categories_ext', dict())
	# 	if check_parent_imported:
	# 		res = response_success(check_parent_imported['id_desc'])
	# 		res['active'] = check_parent_imported['value']
	# 		return res
	# 	return self.category_import(convert_parent, category, categories_ext)

	def get_products_main_export(self):
		limit_data = 10
		id_src = self._state.pull.process.products.id_src
		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0
		product_filter_condition = {
			'id:greater': id_src,
			'sort': 'id',
			'limit': limit_data,
			'include': 'variants,images,options,custom_fields,bulk_pricing_rules,modifiers'
		}
		if not self.is_import_inactive():
			product_filter_condition['is_visible'] = 1
		if not self.is_refresh_process() and self._state.channel.config.api.filter_in_stock:
			product_filter_condition['inventory_level:min'] = 1
		if self._request_data.get('include_filters'):
			for field_filter, value in self._request_data['include_filters'].items():
				if field_filter not in ['id:in', 'brand_id', 'is_visible', 'categories:in']:
					continue
				if field_filter == 'id:in':
					product_filter_condition[field_filter] = value.split(",")
				else:
					if field_filter == 'is_visible':
						value = 1 if value else 0
					product_filter_condition[field_filter] = value
		products = self.api('/catalog/products', data = product_filter_condition)
		products_data = products.get('data')
		if not products or not products_data or to_str(products_data) == '':
			return Response().error(msg = "Could not get Product data from Bigcommerce")
		return Response().success(data = products_data)


	def get_product_by_updated_at(self):
		if self._flag_finish_product:
			return Response().finish()
		if self._product_next_link:
			products = self.api(f"catalog/products{self._product_next_link}")
		else:
			limit_data = self._state.pull.setting.products
			params = {
				'limit': 10,
				'sort': "date_modified",
				'include': 'variants,images,options,custom_fields,bulk_pricing_rules,modifiers'

			}
			last_modified = self.get_max_last_modified_product()
			if last_modified:
				params['date_modified:min'] = last_modified

			products = self.api('catalog/products', data = params)
		links = self._last_header.get('link')
		next_link = ''
		if products.meta and products.meta.pagination and products.meta.pagination.links and products.meta.pagination.links.next:
			next_link = products.meta.pagination.links.next
		if not next_link:
			self._flag_finish_product = True
		else:
			self._product_next_link = next_link
		if not products or not products.data:
			if self._last_status != 200:
				return Response().error(msg = "Could not get Product data from Bigcommerce")
			return Response().finish()
		return Response().success(data = products.data)


	def get_products_ext_export(self, products):
		result = Prodict()
		# for product in products:
		# 	result[product['id']] = dict()
		#
		# 	discount_rules = self.api('/catalog/products/' + to_str(product['id']) + '/bulk-pricing-rules')
		# 	if discount_rules and discount_rules.get('data'):
		# 		discount_rules = discount_rules['data']
		# 	else:
		# 		discount_rules = list()
		#
		# 	images = self.api('/catalog/products/' + to_str(product['id']) + '/images')
		# 	if images and images.get('data'):
		# 		images = images['data']
		# 	else:
		# 		images = list()
		#
		# 	cus_fields = self.api('/catalog/products/' + to_str(product['id']) + '/custom-fields')
		# 	if cus_fields and cus_fields and cus_fields.get('data'):
		# 		cus_fields = cus_fields['data']
		# 	else:
		# 		cus_fields = list()
		#
		# 	options_data = self.api('/catalog/products/' + to_str(product['id']) + '/options')
		# 	if options_data and options_data.get('data'):
		# 		options_data = options_data['data']
		# 	else:
		# 		options_data = list()
		#
		# 	api_data = self.api('/catalog/products/' + to_str(product['id']) + '/variants')
		# 	if api_data and api_data and api_data.get('data'):
		# 		variants_data = api_data['data']
		# 		while 'next' in api_data['meta']['pagination']['links']:
		# 			api_variants = self.api('/catalog/products/' + to_str(product['id']) + '/variants' + api_data['meta']['pagination']['links']['next'])
		# 			api_data = json_decode(api_variants)
		# 			if api_variants and api_data and api_data.get('data'):
		# 				variants_data = [*variants_data, *api_data['data']]
		# 	else:
		# 		variants_data = list()
		#
		# 	rules_data = self.api('/catalog/products/' + to_str(product['id']) + '/modifiers')
		# 	# rules_data = json_decode(api_rules)
		# 	if rules_data and rules_data.get('data'):
		# 		rules_data = rules_data['data']
		# 	else:
		# 		rules_data = list()
		#
		# 	result[product['id']]['options'] = options_data
		# 	result[product['id']]['variants'] = variants_data
		# 	result[product['id']]['modifiers'] = rules_data
		# 	result[product['id']]['discount_rules'] = discount_rules
		# 	result[product['id']]['images'] = images
		# 	result[product['id']]['custom_fields'] = cus_fields
		return Response().success(result)


	def get_product_ext_export(self, product_id):
		result = dict()
		discount_rules = self.api(f'/catalog/products/{product_id}/bulk-pricing-rules')
		if discount_rules and discount_rules.get('data'):
			discount_rules = discount_rules['data']
		else:
			discount_rules = list()

		images = self.api(f'/catalog/products/{product_id}/images')
		if images and images.get('data'):
			images = images['data']
		else:
			images = list()

		cus_fields = self.api(f'/catalog/products/{product_id}/custom-fields')
		if cus_fields and cus_fields and cus_fields.get('data'):
			cus_fields = cus_fields['data']
		else:
			cus_fields = list()

		options_data = self.api(f'/catalog/products/{product_id}/options')
		if options_data and options_data.get('data'):
			options_data = options_data['data']
		else:
			options_data = list()

		api_data = self.api(f'/catalog/products/{product_id}/variants')
		if api_data and api_data and api_data.get('data'):
			variants_data = api_data['data']
			while 'next' in api_data['meta']['pagination']['links']:
				api_variants = self.api(f'/catalog/products/{product_id}/variants' + api_data['meta']['pagination']['links']['next'])
				api_data = json_decode(api_variants)
				if api_variants and api_data and api_data.get('data'):
					variants_data = [*variants_data, *api_data['data']]
		else:
			variants_data = list()

		# rules_data = self.api(f'/catalog/products/{product_id}/modifiers')
		# # rules_data = json_decode(api_rules)
		# if rules_data and rules_data.get('data'):
		# 	rules_data = rules_data['data']
		# else:
		# 	rules_data = list()

		result['options'] = options_data
		result['variants'] = variants_data
		# result['modifiers'] = rules_data
		result['discount_rules'] = discount_rules
		result['images'] = images
		result['custom_fields'] = cus_fields
		return Prodict.from_dict(result)


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		product_data = {
		}
		if setting_price:
			product_data['price'] = to_decimal(product.price) if product.price and to_decimal(product.price) > 0.000 else 0
			if self.is_special_price(product):
				product_data['sale_price'] = to_decimal(product.special_price.price)
			else:
				product_data['sale_price'] = 0
			if self.get_channel_default().get('type') and self.get_channel_default().get('type') in ['bigcommerce']:
				if product.msrp:
					product_data['retail_price'] = to_decimal(product.msrp)
				else:
					product_data['retail_price'] = 0

		if setting_qty:
			product_data['inventory_level'] = to_int(to_decimal(product.qty)) if to_decimal(product.qty) > 0 else 0
		update = self.api(f'/catalog/products/{product_id}', product_data, 'PUT')
		if self._last_status > 300:
			return Response().error()
		if not product.variants:
			return Response().success()
		for variant in product.variants:
			variant_id = self.get_variant_id(variant.channel[f'channel_{self.get_channel_id()}'].get('product_id'))
			if not variant_id:
				continue
			child_data = {
			}
			if setting_price:
				child_data['price'] = to_decimal(variant.price) if variant.price and to_decimal(variant.price) > 0.000 else 0
				if self.is_special_price(variant):
					child_data['sale_price'] = to_decimal(variant.special_price.price)
				else:
					child_data['sale_price'] = 0
				if self.get_channel_default().get('type') and self.get_channel_default().get('type') in ['bigcommerce']:
					if variant.msrp:
						child_data['retail_price'] = to_decimal(variant.msrp)
					else:
						child_data['retail_price'] = 0

			if setting_qty:
				child_data['inventory_level'] = to_int(to_decimal(variant.qty)) if to_decimal(variant.qty) > 0 else 0
			update = self.api(f'/catalog/products/{product_id}/variants/{variant_id}', child_data, 'put')

		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def get_product_by_id(self, product_id):
		product_data = self.api(f'/catalog/products/{product_id}', data = {'include': 'variants,images,options,custom_fields,bulk_pricing_rules,modifiers'})
		if self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		if product_data.get('data'):
			return Response().success(data = product_data.get('data'))
		else:
			return Response().error(msg = f'Product {product_id} not found!!')


	def _convert_product_export(self, product, products_ext: Prodict):
		try:
			if self.is_refresh_process():
				max_last_modified = self._state.pull.process.products.last_modified
				if max_last_modified:
					max_last_modified_timestamp = isoformat_to_datetime(max_last_modified)
					updated_at_timestamp = isoformat_to_datetime(product.date_modified)
					if max_last_modified_timestamp > updated_at_timestamp:
						return Response().skip()
		except:
			self.log_traceback()
		product_data = Product()
		product_data.id = product.id
		product_data.type = 'simple'
		product_data.sku = product.sku
		product_data.upc = product.upc
		product_data.bpn = product.bin_picking_number
		product_data.mpn = product.mpn
		product_data.weight = product.weight
		product_data.weight_units = self.get_weight_units()
		product_data.length = product.depth
		product_data.width = product.width
		product_data.height = product.height
		product_data.dimension_units = self.get_dimension_units()
		if product.condition == 'Used':
			product_data.condition = Product.CONDITION_USED
		if product.condition == 'Refurbished':
			product_data.condition = Product.CONDITION_RECONDITIONED
		product_data.gtin = product.gtin
		product_data.status = True if (product.is_visible == 1 or product.is_visible is True) else False
		product_data.invisible = not product_data.status
		product_data.qty = get_value_by_key_in_dict(product, 'inventory_level', 0)
		product_data.is_in_stock = True if product_data.qty > 0 else False
		product_data.manage_stock = False if product.inventory_tracking == 'none' else True
		if not product_data.manage_stock:
			product_data.is_in_stock = True
		if product.availability != 'available' and product.availability != 'preorder':
			product_data.invisible = True
		product_data.created_at = convert_format_time(product.date_created, self.DATE_FORMAT)
		product_data.updated_at = convert_format_time(product.date_modified, self.DATE_FORMAT)
		product_data.name = product.name
		product_data.description = to_str(get_value_by_key_in_dict(product, 'description', '')).replace('%%GLOBAL_ShopPath%%', self._channel_url.strip('/')).replace('%%GLOBAL_CdnStorePath%%', self._channel_url.strip('/'))
		product_data.short_description = ''
		product_data.meta_description = get_value_by_key_in_dict(product, 'meta_description', '')
		product_data.meta_title = get_value_by_key_in_dict(product, 'page_title', '')
		product_data.meta_keyword = ', '.join(product['meta_keywords']) if product.get('meta_keywords') and to_len(product['meta_keywords']) > 0 else ''
		product_data.tags = get_value_by_key_in_dict(product, 'search_keywords', '')
		product_data.is_featured = get_value_by_key_in_dict(product, 'is_featured', False)
		if product.custom_url and product.custom_url.url:
			product_data.seo_url = f"{self.get_channel_url()}/{to_str(product.custom_url.url).strip('/')}"
		product_data.cost = to_decimal(product['cost_price'])
		product_data.price = to_decimal(product.price)

		if product.retail_price:
			product_data.msrp = to_decimal(product.retail_price)

		if to_decimal(product.sale_price) > 0:
			product_data.special_price.price = to_decimal(product.sale_price)
		# elif to_decimal(product.retail_price) > 0 and to_decimal(product['retail_price']) > to_decimal(product.price):
		# 	product_data.price = to_decimal(product['retail_price'])
		# 	product_data.special_price.price = to_decimal(product.price)
		# else:
		# 	product_data.price = to_decimal(product.price)

		list_attributes = {
			# 'bin_picking_number': 'BIN picking number',
			'warranty': 'Warranty Infomation',
			# 'upc': 'Product UPC/EAN'
		}
		for attribute_code, attribute_label in list_attributes.items():
			if product.get(attribute_code):
				attribute_data = ProductAttribute()
				attribute_data.attribute_code = attribute_code
				attribute_data.attribute_mode = 'backend'
				attribute_data.attribute_name = attribute_label
				attribute_data.attribute_type = 'text' if attribute_code != 'warranty' else 'textarea'
				attribute_data.attribute_value_name = product.get(attribute_code)
				product_data.attributes.append(attribute_data)

		product_data.tax.id = product.tax_class_id if product.tax_class_id else None
		product_data.tax.code = 'Default Tax Class' if not product.tax_class_id else None

		if to_int(product['brand_id']) > 0:
			man_data = self.api('/catalog/brands/' + to_str(product['brand_id']))
			if man_data and man_data.get('data') and to_len(man_data['data']) > 0:
				product_data.brand = man_data.data.name
			product_data.manufacturer.id = product.brand_id

		# if to_len(product.bulk_pricing_rules) > 0:
		# 	for rule in product['bulk_pricing_rules']:
		# 		rule_data = ProductTierPrice()
		# 		rule_data.qty = to_int(rule.quantity_min)
		# 		rule_data.price = to_decimal(rule.amount)
		# 		rule_data.price_type = rule.type
		# 		product_data.tier_prices.append(rule_data)

		if product.custom_fields:
			for custom_field in product.custom_fields:
				attribute_data = ProductAttribute()
				attribute_data.attribute_code = custom_field.name
				attribute_data.attribute_mode = 'backend'
				attribute_data.attribute_name = custom_field.name
				attribute_data.attribute_type = 'text'
				attribute_data.attribute_value_name = custom_field.value
				product_data.attributes.append(attribute_data)

		if product.images:
			for image in product['images']:
				if 'url_zoom' in image and image['url_zoom']:
					real_path = re.sub("/\?.+/", "", to_str(image['url_zoom']))
					real_path = real_path[:real_path.find('?')]
					if image['is_thumbnail'] == 1:
						product_data.thumb_image.label = image.description
						product_data.thumb_image.url = real_path
						product_data.thumb_image.path = ''
					else:
						product_image_data = ProductImage()
						product_image_data['label'] = image.get('description')
						product_image_data['url'] = real_path
						product_image_data['path'] = ''
						product_data.images.append(product_image_data)

		# Migrate custom option

		# categories
		if product.categories:
			categories = self.api('catalog/categories', data = {'id:in': ','.join(list(map(lambda x: to_str(x), product.categories)))})
			if categories and categories.data:
				product_data.category_name_list = [row['name'] for row in categories['data']]
				category_template = [{'category_id': row['id'], 'category_name': row['name']} for row in categories['data']]
				product_data.template_data = {
					'category': {
						'categories': category_template
					}
				}
		# if product.availability != 'available':
		# 	product_data.is_in_stock = False
		# variant
		has_variant = False
		if product['variants'] and product['options']:
			has_variant = True
			option_value_is_empty = self.check_option_value(product['options'])
			if option_value_is_empty:
				Response().warning(msh = f'Product {product["id"]} option value is empty!!')
				return Response().success(product_data)
			base_variant_id = product.base_variant_id
			base_variant = False
			manager_stock = True
			inventory_tracking = product['inventory_tracking']
			if inventory_tracking == 'none':
				manager_stock = False
			custom_manage_stock = self.is_custom_manage_stock()
			if custom_manage_stock is not None:
				manager_stock = custom_manage_stock
				if manager_stock:
					if inventory_tracking == 'none':
						inventory_tracking = 'variant'
			if inventory_tracking != 'variant':
				product_data.no_manage_variants = True
				product_data.tracking_inventory = 'product'
			for variant in product['variants']:

				child = ProductVariant()
				child.id = self.to_variant_id(variant['id'])
				child.name = product_data.name
				child.status = True if not variant.purchasing_disabled else False
				child.invisible = True if variant.purchasing_disabled else False

				child.sku = variant.sku
				child.thumb_image.url = variant.image_url
				child.thumb_image.path = ''
				child.qty = product.inventory_level if inventory_tracking == 'product' else variant.inventory_level
				child.is_in_stock = True if child.qty > 0 else False
				child.manage_stock = manager_stock
				if not child.manage_stock:
					child.is_in_stock = True
				child.price = get_value_by_key_in_dict(variant, 'price', product_data.price)
				child.special_price.price = get_value_by_key_in_dict(variant, 'sale_price', product.sale_price)
				child.weight = get_value_by_key_in_dict(variant, 'weight', 0.0000)
				child.width = get_value_by_key_in_dict(variant, 'width', 0.0000)
				child.height = get_value_by_key_in_dict(variant, 'height', 0.0000)
				child.length = get_value_by_key_in_dict(variant, 'depth', 0.0000)
				child.bpn = variant.bin_picking_number
				child.upc = variant.upc
				child.mpn = variant.mpn
				child.gtin = variant.gtin
				child.created_at = product_data.created_at
				child.updated_at = product_data.updated_at
				child.seo_url = f"{product_data.seo_url}?sku={variant.sku}"
				if variant.option_values and to_len(variant.option_values) > 0:
					for option_variant in variant['option_values']:
						option = get_row_from_list_by_field(product.options, 'id', option_variant.option_id)
						if option:
							variant_attr = ProductVariantAttribute()
							variant_attr.id = option_variant.option_id
							variant_attr.attribute_code = option.name
							variant_attr.attribute_name = option.display_name
							if option.option_values:
								option_value = get_row_from_list_by_field(option.option_values, 'id', option_variant.id)
								if option_value:
									variant_attr.attribute_value_id = option_variant.id
									variant_attr.attribute_value_name = option_value.label
									variant_attr.attribute_value_code = option_value.label
								else:
									option_value = get_row_from_list_by_field(variant.option_values, 'id', option_variant.id)
									if option_value:
										variant_attr.attribute_value_name = option_value.label
										variant_attr.attribute_value_code = option_value.label
							child.attributes.append(variant_attr)
				if base_variant_id and to_int(variant['id']) == to_int(base_variant_id):
					base_variant = copy.deepcopy(child)
					base_variant.attributes = []
				product_data.variants.append(child)
				if base_variant:
					product_data.variants = []
					product_options = []
					for option in product.options:
						option_data = ProductOption()
						option_data.id = option.id
						option_data.option_type = 'select'
						option_data.option_name = option.display_name or option.name
						if option.option_values:
							for modifier_value in option.option_values:
								option_value_data = ProductOptionValue()
								option_value_data.id = modifier_value['id']
								option_value_data.option_value_name = modifier_value['label']
								option_data.option_values.append(option_value_data)
						product_options.append(option_data)
					variants = self.convert_option_to_child(product_options, base_variant, base_variant_id = base_variant_id)
					if to_len(variants) == 1:
						variants[0]['id'] = self.to_variant_id(base_variant_id)
					product_data.variants = variants
					product_data.no_manage_variants = True
					product_data.tracking_inventory = 'product'

		if not has_variant and product.option_set_id and product.modifiers:
			for modifier in product.modifiers:
				option_data = ProductOption()
				option_data.id = modifier.id
				if modifier.type in ['text', 'multi_line_text']:
					conf_type = 'text'
				elif modifier.type == 'file':
					conf_type = 'file'
				elif modifier.type == 'checkbox':
					conf_type = 'checkbox'
				else:
					conf_type = 'select'

				option_data.code = modifier.name
				option_data.option_code = modifier.name
				option_data.option_type = conf_type
				option_data.option_name = modifier.display_name or modifier.name
				option_data.sort_order = modifier.sort_order
				option_data.required = True if modifier.get('required') else False
				if modifier.option_values:
					for modifier_value in modifier.option_values:
						option_value_data = ProductOptionValue()
						option_value_data.id = modifier_value['id']
						option_value_data.code = modifier_value['label']
						option_value_data.option_value_code = modifier_value['label']
						option_value_data.option_value_name = modifier_value['label']
						option_value_data.sort_order = modifier_value['sort_order']
						if modifier_value.adjusters:
							option_value_data.option_value_price = modifier_value.adjusters.price.get('adjuster_value', 0.0000) if modifier_value['adjusters'].get('price') else 0.0000
							option_value_data.thumb_image.url = modifier_value.adjusters.get('image_url', '')
						option_data.option_values.append(option_value_data)
				product_data.options.append(option_data)
			variants = self.convert_option_to_child(product_data.options, product_data)
			product_data.variants = variants
			product_data.no_manage_variants = True
			product_data.tracking_inventory = 'product'

		return Response().success(product_data)


	def check_option_value(self, options):
		total_option_no_value = 0
		for option in options:
			if not option.option_values:
				total_option_no_value += 1
		return len(options) == total_option_no_value


	def get_category_id_by_name(self, category_name):
		if self._categories.get(category_name):
			return self._categories.get(category_name)
		param = {'name': category_name}
		category = self.api('catalog/categories', param)
		if category and category.get('data'):
			for row in category['data']:
				if to_str(row['name']).lower().strip('') == to_str(category_name).lower().strip():
					self._categories[category_name] = row['id']
		if not self._categories.get(category_name):
			category_data = {
				'parent_id': 0,
				'name': category_name,
				'is_visible': True
			}
			category = self.api('catalog/categories', category_data, 'post')
			if category and category.get('data'):
				self._categories[category_name] = category['data']['id']
		return self._categories.get(category_name)


	def get_brand_id_by_name(self, brand_name):
		if self._brands.get(brand_name):
			return self._brands.get(brand_name)
		param = {'name': brand_name}
		brands = self.api('catalog/brands', param)
		if brands and brands.get('data'):
			for brand in brands['data']:
				if to_str(brand['name']).lower().strip('') == to_str(brand_name).lower().strip():
					self._brands[brand_name] = brand['id']
		if not self._brands.get(brand_name):
			brand_data = {
				'name': brand_name,
			}
			brand = self.api('catalog/brands', brand_data, 'post')
			if brand and brand.get('data'):
				self._brands[brand_name] = brand['data']['id']
		return self._brands.get(brand_name)


	def product_to_bigcommerce_data(self, convert, product, product_ext):
		upc_ean_field = ['upc', 'ean']
		upc_data = ''
		for field in upc_ean_field:
			upc_data = product.get(field)
			if upc_data:
				break

		product_sku = product.sku
		# if not product_sku:
		# 	return Response().error(msg = 'Product SKU is empty!!')
		# if product.variants and product.src.channel_type == 'shopify':
		# 	product_sku += "-parent"
		# 	self._extend_product_map['sku'] = product_sku
		tracking = 'product' if 'manage_stock' in product and product.manage_stock else 'none'
		if product.variants:
			tracking = 'variant'

		product_data = {
			'name': self.strip_html_from_description(product.name),
			'type': 'physical',
			'description': nl2br(html.unescape(product.description) if product.description else ''),
			'price': to_decimal(product.price) if product.price and to_decimal(product.price) > 0.000 else 0,
			'availability': 'available' if product.status else 'disabled',
			'weight': self.convert_weight_unit(to_decimal(product.weight) if product.weight and to_decimal(product.weight) > 0 else 0, product.weight_units, self.get_weight_units()),
			'width': self.convert_dimension_unit(to_decimal(product.width), product.dimension_units, self.get_dimension_units()),
			'height': self.convert_dimension_unit(to_decimal(product.height), product.dimension_units, self.get_dimension_units()),
			'depth': self.convert_dimension_unit(to_decimal(product.length), product.dimension_units, self.get_dimension_units()),
			'inventory_tracking': tracking,
			'is_visible': True if product.status else False,
			'inventory_level': to_int(to_decimal(product.qty)) if to_decimal(product.qty) > 0 else 0,
			'upc': upc_data,
			'meta_description': product.meta_description or '',
			'page_title': to_str(get_value_by_key_in_dict(product, 'meta_title', ''))[:255].replace('|', ' ').replace('  ', ' '),
			'search_keywords': get_value_by_key_in_dict(product, 'meta_keyword', ''),
		}
		if product.meta_keyword:
			product_data['meta_keywords'] = product.meta_keyword.split(',')
		if product_sku and not product.variants or product.src.channel_type != 'shopify' and not self.product_import_without_sku():
			product_data['sku'] = product_sku
			# self._extend_product_map['sku'] = product_sku
		map_fields = {
			'mpn': 'mpn',
			'gtin': 'gtin',
			'bpn': 'bin_picking_number',
		}
		for field, bigcommcerce_field in map_fields.items():
			if product.get(field):
				value = product[field].split(',')[0]
				product_data[bigcommcerce_field] = value
		if product.msrp:
			product_data['retail_price'] = product.msrp
		if self.is_special_price(product):
			product_data['sale_price'] = to_decimal(product.special_price.price)

		template_category = product.get('template_data', {}).get('category', {})
		category_ids = []
		template_catgory_data = list()
		if template_category and template_category.get('categories'):
			category_ids = [category['category_id'] for category in template_category['categories']]
			template_catgory_data = template_category['categories']
		elif self.is_auto_import_category():
			category_name_list = product.category_name_list or []
			categories = list()
			if product.category_path:
				category_name_path = product.category_path.split('>')[-1].strip()
				if category_name_path not in category_name_list:
					category_name_list.append(category_name_path)
			for category_name in category_name_list:
				category_id = self.get_category_id_by_name(category_name)
				if category_id and category_id not in category_ids:
					category_ids.append(to_int(category_id))
					template_catgory_data.append({
						"category_id": category_id,
						"category_name": category_name,
					})

			if not self.is_channel_default() and template_catgory_data:
				self._extend_product_map = {
					'template_data': {
						'category': {
							'categories': template_catgory_data
						}
					}
				}
		if category_ids:
			product_data['categories'] = category_ids
		if product.brand:
			brand_id = self.get_brand_id_by_name(product.brand)
			if brand_id:
				product_data['brand_id'] = to_int(brand_id)
		if not product_data.get('categories'):
			category_id = self.get_category_id_by_name('All Products')
			if category_id:
				product_data['categories'] = [to_int(category_id)]

		# if product.seo:
		# 	product_data.custom_url = {
		# 		'url': '/' + product.seo.lstrip('/'),
		# 	}
		if product.condition:
			condition = 'New'
			if product.condition == Product.CONDITION_USED:
				condition = 'Used'
			elif product.condition == Product.CONDITION_RECONDITIONED:
				condition = 'Refurbished'
			product_data['condition'] = condition
			product_data['is_condition_shown'] = self.is_condition_shown()
		product.attributes = self.filter_product_atr_allow(product.attributes)
		if product.attributes:
			custom_fields = list()
			for attribute in product.attributes:
				if json_decode(attribute.attribute_value_name):
					continue
				custom_fields.append({
					'name': attribute.attribute_name[0:250],
					"value": attribute.attribute_value_name[0:250]
				})
			product_data['custom_fields'] = custom_fields
		return Response().success(product_data)


	def filter_product_atr_allow(self, atr_raw):
		"""seller want to import the specific list of atrs only"""
		atr_list_allow = self.product_import_attribute_allow_only()
		if not atr_list_allow:
			return  atr_raw

		try:
			return list(filter(
				lambda x: x['attribute_name'] in atr_list_allow
				          or x['use_variant'] is True, atr_raw
			))
		except:
			self.log_traceback()
			return atr_raw


	def product_import_attribute_allow_only(self):
		raw_ = self._state.channel.config.api.import_allow_attributes
		return raw_ if isinstance(raw_, list) else []

	def product_import_without_sku(self):
		return self._state.channel.config.api.product_import_without_sku


	def product_import(self, convert, product, products_ext):
		convert_product = self.product_to_bigcommerce_data(convert, product, products_ext)
		if convert_product.result != Response.SUCCESS:
			return convert_product
		product_data = convert_product.data
		response_data = self.api('/catalog/products', product_data, 'Post')
		if response_data and response_data.get('data') and response_data['data'].get('id'):
			product_id = response_data['data']['id']
			return Response().success(product_id)
		errors = response_data.title or "Something error"
		if response_data and response_data.get('errors'):
			errors = response_data.get('errors')
			if isinstance(errors, dict):
				errors = list(errors.values())
			if not isinstance(errors, list):
				errors = to_str(errors)
			else:
				errors = '_lic_nl_'.join(errors)
		return Response().error(msg = errors)


	def update_product_attribute(self, product_id, product, delete_image = False):
		if product.short_description:
			attr_data = {
				'name': 'Short Description',
				'value': to_str(product.short_description)[0:250]
			}
			self.api('/catalog/products/' + to_str(product_id) + '/custom-fields', attr_data, 'post')
		# if product.attributes:
		# 	for attr in product.attributes:
		# 		if not attr.option_value_name or attr.option_name == 'Description' or attr.option_name == 'Short Description':
		# 			continue
		# 		attr_data = {
		# 			'name': attr.option_name,
		# 			'value': attr.option_value_name[0:250]
		# 		}
		# 		self.api('/catalog/products/' + to_str(product_id) + '/custom-fields', attr_data, 'post')

		# Images
		if delete_image:
			bigc_image_request = self.api(f'catalog/products/{product_id}/images')
			if self._last_status == 200:
				for image in bigc_image_request.data:
					delete = self.api(f'catalog/products/{product_id}/images/{image["id"]}', api_type = 'delete')
		bigc_images = dict()
		if product.thumb_image.url:
			img_data = {
				'image_url': product.thumb_image.url,
				'is_thumbnail': True,
				'description': product.thumb_image.label if product.thumb_image.label else ''
			}
			save = self.api('catalog/products/' + to_str(product_id) + '/images', img_data, 'post')
			if self._last_status == 200:
				bigc_images[product.thumb_image.url] = save.data.id
		if product.images:
			for image in product.images:
				img_data = {
					'image_url': image.url,
					'is_thumbnail': False,
					'description': image.label if image.label else '',
				}
				save = self.api('catalog/products/' + to_str(product_id) + '/images', img_data, 'post')
				if self._last_status == 200:
					bigc_images[image.url] = save.data.id
		return bigc_images


	def variant_to_bigcommerce_data(self, product_id, variant: ProductVariant, product_option_data, parent: Product):
		variant_sku = variant.sku
		if not variant_sku:
			variant_sku = self.convert_attribute_code(self.strip_html_tag(variant.name, True))
		if not variant_sku:
			variant_sku = to_int(time.time())

		upc_ean_field = ['upc', 'ean']
		upc_data = ''
		for field in upc_ean_field:
			upc_data = variant.get(field)
			if upc_data:
				break
		child_data = {
			'price': to_decimal(variant.price) if variant.price and to_decimal(variant.price) > 0.000 else 0,
			'weight': to_decimal(variant.weight) if variant.weight and to_decimal(variant.weight) > 0 else 0,
			'width': variant.width,
			'height': variant.height,
			'depth': variant.length,
			'purchasing_disabled': True if not variant.status else False,
			'upc': upc_data,
			'inventory_level': to_int(to_decimal(variant.qty)) if to_decimal(variant.qty) > 0 else 0,
			'product_id': product_id,
			'sku': variant_sku,
			'option_values': list()
		}
		if self.is_special_price(variant):
			child_data['sale_price'] = to_decimal(variant.special_price.price)
		if variant.msrp or parent.msrp:
			child_data['retail_price'] = variant.msrp or parent.msrp
		for attr in variant.attributes:
			if not attr.use_variant:
				continue
			option_need = product_option_data[attr.attribute_name]
			attr_id = option_need.get('id')
			attr_value_id = option_need['option_values'].get(attr.attribute_value_name)
			# attr_value = get_row_from_list_by_field(option_need.option_values, 'label', attr.attribute_value_name)
			# attr_value_id = attr_value.id
			if not attr_id or not attr_value_id:
				continue
			option_value_data = {
				'id': attr_value_id,
				'option_id': attr_id
			}
			child_data['option_values'].append(option_value_data)
		return child_data


	def create_variant(self, product_id, variant: ProductVariant, product_option_data, parent = None):
		child_data = self.variant_to_bigcommerce_data(product_id, variant, product_option_data, parent)
		if not child_data['option_values'] or to_len(child_data['option_values']) == 0:
			return Response().error('Not found option values')
		response_variant = self.api(f'/catalog/products/{product_id}/variants', child_data, 'post')
		if to_str(response_variant.status) == '409':
			return Response().error(msg = response_variant.title)
		if not response_variant.data:
			return Response().error(msg = response_variant.title)
		if variant.thumb_image.url:
			img_data = {
				'image_url': variant.thumb_image.url,
			}
			save = self.api(f'catalog/products/{product_id}/variants/{response_variant.data.id}/image', img_data, 'post')
		return Response().success(response_variant.data.id)


	def after_product_import(self, product_id, convert, product, products_ext):
		extend_product_map = copy.deepcopy(self._extend_product_map)
		self._extend_product_map = dict()
		self.update_product_attribute(product_id, product)

		# if product.options:
		# 	for option in product.options:
		# 		if option.option_type == 'checkbox':
		# 			option_type = 'checkbox'
		# 		elif option.option_type == 'file':
		# 			option_type = 'file'
		# 		elif option.option_type == 'text':
		# 			option_type = 'text'
		# 		elif option.option_type == 'textarea':
		# 			option_type = 'multi_line_text'
		# 		elif option.option_type == 'radio':
		# 			option_type = 'radio_buttons'
		# 		else:
		# 			option_type = 'dropdown'
		# 		option_data = {
		# 			"type": option_type,
		# 			"required": option.required,
		# 			"sort_order": option.sort_order if option.get('sort_order') else 0,
		# 			"config": {},
		# 			"display_name": option.option_name,
		# 			'option_values': list()
		# 		}
		# 		for k, value in enumerate(option.values):
		# 			if value.thumb_image.url or value.thumb_image.path:
		# 				image_process = self.process_image_before_import(value.thumb_image.url, value.thumb_image.path)
		# 				value_data = {
		# 					'is_default': True if value.get('is_default') else False,
		# 					'label': value.option_value_name,
		# 					'sort_order': k,
		# 					'adjusters': {
		# 						'image_url': image_process.url if image_process and image_process.get('url') else '',
		# 						'price': None if not value.option_value_price else {
		# 							'adjuster': 'relative',
		# 							'adjuster_value': to_decimal(value.option_value_price),
		# 						},
		# 						'purchasing_disabled': {
		# 							'message': '',
		# 							'status': False
		# 						},
		# 						'weight': None
		# 					}
		# 				}
		# 				option_data['option_values'].append(value_data)
		# 		response_option = self.api('/catalog/products/' + to_str(product_id) + '/modifiers', option_data, 'post')
		# 		if response_option and not response_option.data:
		# 			return Response().error(msg = response_ option.get('title'))
		if not product.variants:
			self._extend_product_map = extend_product_map
			return Response().success(product_id)
		create_option = self.create_product_options(product_id, product)
		if create_option.result != Response.SUCCESS:
			return create_option
		product_option_data = create_option.data
		skus = []
		if product.src.channel_type != 'shopify':
			skus = [product.sku]

		for variant in product.variants:
			sku = variant.sku
			index = 1
			while sku in skus:
				index += 1
				sku = variant.sku + "_" + to_str(index)
			skus.append(sku)
			variant.sku = sku
			create_variant = self.create_variant(product_id, variant, product_option_data, product)
			if create_variant.result != Response.SUCCESS:
				return create_variant
			self._extend_product_map['sku'] = sku
			self.insert_map_product(variant, variant['_id'], self.to_variant_id(create_variant.data))
		self._extend_product_map = extend_product_map

		return Response().success()


	def to_variant_id(self, variant_id):
		return f"v-{variant_id}"


	def get_variant_id(self, variant_id):
		variant_id = to_str(variant_id)
		if variant_id[0] == 'v':
			variant_id = variant_id[2:]
		return variant_id


	def delete_product_import(self, product_id):
		self.api('/catalog/products/' + to_str(product_id), None, 'delete')
		return Response().success()


	def create_product_options(self, product_id, product):
		option_list = self.convert_child_to_option(product.variants)
		if not option_list:
			return Response().error(msg = 'Cannot convert option')
		product_option_data = dict()
		for option in option_list:
			option_data = {
				'product_id': product_id,
				'display_name': option.option_name,
				'type': 'dropdown',
				'option_values': list()
			}
			for k, option_value in enumerate(option.option_values):
				option_value_data = {
					'label': option_value.option_value_name,
					'sort_order': k,
					'is_default': True if option_value.get('is_default') else False
				}
				option_data['option_values'].append(option_value_data)
			response = self.api(f'/catalog/products/{product_id}/options', option_data, 'Post')
			if response and not response.get('data'):
				return Response().error(msg = response.get('title'))
			product_option_data.update(self.bigcommerce_option_to_option_data(response['data']))
		return Response().success(product_option_data)


	def product_channel_update(self, product_id, product: Product, products_ext):
		if product.attributes:
			attribute_names = []
			for attribute in product.attributes:
				attribute_names.append(attribute.attribute_name[0:250])

			custom_fields = self.api(f"catalog/products/{product_id}/custom-fields")
			if self._last_status < 300:
				for field in custom_fields['data']:
					if field['name'] in attribute_names:
						delete_field = self.api(f"catalog/products/{product_id}/custom-fields/{field['id']}", api_type = 'delete')
		convert_product = self.product_to_bigcommerce_data(product, product, products_ext)
		if convert_product.result != Response.SUCCESS:
			return convert_product
		product_data = convert_product.data
		update = self.api(f'/catalog/products/{product_id}', product_data, 'PUT')
		if self._last_status > 300:
			errors = update.title or "Something error"
			if update and update.get('errors'):
				errors = update.get('errors')
				if isinstance(errors, dict):
					errors = list(errors.values())
				if not isinstance(errors, list):
					errors = to_str(errors)
				else:
					errors = '_lic_nl_'.join(errors)
			return Response().error(msg = errors)

		bigc_images = self.update_product_attribute(product_id, product, delete_image = True)
		if not product.variants:
			return Response().success()
		product_option_data_response = self.api(f'/catalog/products/{product_id}/options')
		if product_option_data_response.get('data'):
			product_option_data = dict()
			for row in product_option_data_response['data']:
				product_option_data.update(self.bigcommerce_option_to_option_data(row))


		else:
			create_option = self.create_product_options(product_id, product)
			if create_option.result != Response.SUCCESS:
				return create_option
			product_option_data = create_option.data
		for variant in product.variants:
			variant_id = self.get_variant_id(variant.channel[f'channel_{self.get_channel_id()}'].get('product_id'))
			if not variant_id:
				create_variant = self.create_variant(product_id, variant, product_option_data, product)
				if create_variant.result == Response.SUCCESS:
					self.insert_map_product(variant, variant['_id'], self.to_variant_id(create_variant.data))
				continue
			child_data = self.variant_to_bigcommerce_data(product_id, variant, product_option_data, product)
			if not child_data['option_values'] or to_len(child_data['option_values']) == 0:
				return Response().error('Not found option values')
			update = self.api(f'/catalog/products/{product_id}/variants/{variant_id}', child_data, 'put')
		return Response().success()


	def bigcommerce_option_to_option_data(self, option):
		response = dict()
		response[option['display_name']] = {
			'id': option['id'],
			'option_values': dict(),

		}
		for row in option['option_values']:
			response[option['display_name']]['option_values'][row['label']] = row['id']
		return response


	# orders
	def get_orders_main_export(self):
		limit_data = self._state.pull.setting.orders
		start_time = self.get_order_start_time('iso')
		imported = self._state.pull.process.orders.imported
		current_page = math.floor((to_decimal(imported) / to_decimal(limit_data))) + 1
		last_modifier = self._state.pull.process.orders.max_last_modified
		params = {
			"min_date_created": start_time,
			'limit': limit_data,
			'page': current_page,
			'sort': 'date_modified:asc'
		}
		if last_modifier:
			params['min_date_modified'] = last_modifier
		orders = self.api('orders.json', data = params, api_version = 2)
		if not orders or (orders[0].get('status') and orders[0].get('message')):
			if orders.status != 200:
				return Response().error(msg = 'Could not get order data from Bigcommerce')
			return Response().finish()
		return Response().success(data = orders)


	# orders
	def get_order_by_id(self, order_id):
		order = self.api(f'orders/{order_id}', api_version = 2)
		if self._last_status != 200:
			return Response().error()
		return Response().success(order)


	def get_orders_ext_export(self, orders):
		result = Prodict()
		for order in orders:
			order_id = to_str(order.id)
			result[order_id] = Prodict()
			decode_shipping = order_pro = order_coupon = shipments = list()
			if order.shipping_addresses.resource:
				api_ship = self.api(order.shipping_addresses.resource + '.json', api_version = 2)
				if api_ship:
					decode_shipping = api_ship[0]

			if order.products.resource:
				order_pro = self.api(order.products.resource + '.json', api_version = 2)

			if order.coupons and order.coupons.resource:
				order_coupon = self.api(order.coupons.resource + '.json', api_version = 2)
			shipments = self.api(f"orders/{order_id}/shipments", api_version = 2)

			result[order_id].shipping_addresses = decode_shipping
			result[order_id].products = order_pro
			result[order_id].coupons = order_coupon
			result[order_id].shipments = shipments
		return Response().success(result)


	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_id = to_str(order.id)
		order_data = Order()
		decode_shipping = orders_ext[order_id].shipping_addresses
		order_ship = False
		if decode_shipping:
			order_ship = decode_shipping

		order_data.id = order_id
		order_data.status = self.BIGCOMMERCE_ORDER_STATUS.get(to_str(order.status_id), Order.OPEN)
		order_data.tax.amount = to_decimal(order.total_tax)
		if order_ship:
			order_data.shipping.title = order_ship.shipping_method
		order_data.shipping.amount = to_decimal(order.base_shipping_cost)
		order_data.subtotal = to_decimal(order.subtotal_ex_tax)
		order_data.total = order.total_inc_tax
		order_data.created_at = convert_format_time(order.date_created, "%a, %d %b %Y %H:%M:%S %z")
		order_data.updated_at = convert_format_time(order.date_modified, "%a, %d %b %Y %H:%M:%S %z")
		order_data.discount.amount = to_decimal(order.discount_amount) + to_decimal(order.coupon_discount)
		order_data.currency = order.currency_code
		order_data.channel_data = {
			'order_status': order.status,
			'created_at': order_data.created_at,
			'order_number': order_id,
		}
		decode_coupon = orders_ext[order_id].coupons
		order_coupon = False
		if decode_coupon:
			coupon_codes = [coupon.code or '' for coupon in decode_coupon]
			order_data.discount.code = ','.join(coupon_codes)
		order_data.customer.email = order.billing_address.email
		order_data.customer.first_name = order.billing_address.first_name
		order_data.customer.last_name = order.billing_address.last_name
		order_data.customer.telephone = order.billing_address.phone

		order_bill = order.billing_address
		order_data.customer_address.first_name = order_bill.first_name
		order_data.customer_address.last_name = order_bill.last_name
		order_data.customer_address.address_1 = order_bill.street_1
		order_data.customer_address.address_2 = order_bill.street_2
		order_data.customer_address.city = order_bill.city
		order_data.customer_address.postcode = order_bill.zip
		order_data.customer_address.telephone = order_bill.phone
		order_data.customer_address.company = order_bill.company
		order_data.customer_address.country.country_code = order_bill.country_iso2
		order_data.customer_address.country.country_name = order_bill.country
		order_data.customer_address.state.state_code = self._get_state_code_from_name(order_bill.state)
		order_data.customer_address.state.name = order_bill.state

		# billing
		order_data.billing_address.first_name = order_bill.first_name
		order_data.billing_address.last_name = order_bill.last_name
		order_data.billing_address.address_1 = order_bill.street_1
		order_data.billing_address.address_2 = order_bill.street_2
		order_data.billing_address.city = order_bill.city
		order_data.billing_address.postcode = order_bill.zip if order_bill.zip else ''
		order_data.billing_address.telephone = order_bill.phone
		order_data.billing_address.company = order_bill.company
		order_data.billing_address.country.code = order_bill.country_iso2
		order_data.billing_address.country.country_code = order_bill.country_iso2
		order_data.billing_address.country.name = order_bill.country
		order_data.billing_address.state.state_code = self._get_state_code_from_name(order_bill.state)
		order_data.billing_address.state.state_name = order_bill.state

		# shipping
		order_ship = orders_ext[order_id].shipping_addresses
		if order_ship:
			order_data.shipping_address.first_name = order_ship.first_name
			order_data.shipping_address.last_name = order_ship.last_name
			order_data.shipping_address.address_1 = order_ship.street_1
			order_data.shipping_address.address_2 = order_ship.street_2
			order_data.shipping_address.city = order_ship.city
			order_data.shipping_address.postcode = order_ship.zip
			order_data.shipping_address.telephone = order_ship.phone
			order_data.shipping_address.company = order_ship.company
			order_data.shipping_address.country.country_code = order_ship.country_iso2
			order_data.shipping_address.country.country_code = order_ship.country
			order_data.shipping_address.state.state_code = self._get_state_code_from_name(order_ship.state)
			order_data.shipping_address.state.state_name = order_ship.state

		order_data.payment.method = order.payment_method

		order_items = list()
		order_pro = orders_ext[order_id].products
		if order_pro:
			for order_product in order_pro:
				order_item = OrderProducts()
				order_item.product_id = order_product.product_id
				order_item.listing_id = order_product.product_id
				if order_product.variant_id and order_product.product_options:
					order_item.product_id = self.to_variant_id(order_product.variant_id)
					order_item.is_variant = True

				order_item.product_sku = order_product.name
				order_item.product_name = order_product.sku
				order_item.qty = order_product.quantity
				order_item.price = order_product.base_price
				order_item.original_price = order_product.base_price
				order_item.tax_amount = order_product.total_tax
				if order_product.applied_discounts:
					for discount in order_product.applied_discounts:
						order_item.discount_amount += to_decimal(discount.amount)
				order_item.subtotal = order_product.total_ex_tax
				order_item.total = order_product.total_inc_tax
				if order_product.product_options:
					for pro_opt in order_product.product_options:
						order_item_option = OrderItemOption()
						order_item_option.option_id = pro_opt.option_id
						order_item_option.option_name = pro_opt.display_name
						order_item_option.option_value_name = pro_opt.display_value
						order_item_option.price = 0
						order_item_option.price_prefix = 0
						order_item.options.append(order_item_option)
				order_items.append(order_item)
		order_data.products = order_items
		shipments = orders_ext[order_id].shipments
		if shipments:
			for index, shipment in enumerate(shipments):
				shipment_data = Shipment()
				tracking_company = shipment.tracking_carrier or shipment.shipping_method or shipment.shipping_provider
				tracking_company_code = shipment.tracking_carrier or shipment.shipping_provider or shipment.shipping_method
				if to_str(shipment.tracking_carrier).find('USPS') != -1 or to_str(shipment.shipping_provider).find('USPS') != -1 or to_str(shipment.shipping_method).find('USPS') != -1 or to_str(shipment.tracking_link).find('USPS') != -1 or to_str(shipment.shipping_provider).find('endicia') != -1:
					tracking_company = "USPS"
					tracking_company_code = 'USPS'
				if to_str(shipment.tracking_carrier).lower().find('ups') != -1 or to_str(shipment.shipping_provider).lower().find('ups') != -1 or to_str(shipment.shipping_method).lower().find('ups') != -1 or to_str(shipment.tracking_link).lower().find('USPS') != -1:
					tracking_company = "UPS"
					tracking_company_code = 'UPS'
				shipment_data.tracking_number = shipment.tracking_number
				shipment_data.tracking_url = shipment.tracking_link or shipment.generated_tracking_link
				shipment_data.tracking_company = tracking_company
				shipment_data.tracking_company_code = tracking_company_code
				shipment_data.shipped_at = convert_format_time(order.date_shipped, '%Y-%m-%dT%H:%M:%S')
				for item in shipment['items']:
					order_shipment_item = OrderShipmentItem()
					order_shipment_item.product_id = item['product_id']
					order_shipment_item.qty = item['quantity']
					shipment_data.line_items.append(order_shipment_item)
				if to_len(shipments) > 1:
					order_data.line_shipments.append(shipment_data)
				if not index:
					order_data.shipments.update(shipment_data)

		if order.customer_message:
			order_history = OrderHistory()
			order_history.comment = order.customer_message
			order_data.history.append(order_history)
		# if order.staff_notes:
		# 	tmp = OrderHistory()
		# 	tmp.comment = order.staff_notes
		# 	tmp.customer_note = ''
		# 	order_data.history.append(tmp)
		return Response().success(order_data)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if setting_order:
			cancel_data = {"status_id": 5}
			cancel_order = self.api(f'/orders/{order_id}', cancel_data, 'put', api_version = 2)
			return Response().success()
		return self._order_sync_inventory(order, '+')


	def create_order_shipment(self, order_id, order: Order):
		products = self.api(f"orders/{order_id}/products", api_version = 2)
		if not products:
			return Response().error()
		shipping_addresses = self.api(f"orders/{order_id}/shipping_addresses", api_version = 2)
		if not shipping_addresses:
			return Response().error()

		tracking_company = TrackingCompany(order.shipments.tracking_company_code, order.shipments.tracking_company, channel_type = 'bigcommerce')
		shipment_data = {
			'order_address_id': shipping_addresses[0]['id'],
			'tracking_number': order.shipments.tracking_number,
			'shipping_method': order.shipping.method or tracking_company.get_name(),
			'tracking_carrier': tracking_company.get_code(),
			'items': []
			# 'shippedDate': get_current_time("%Y-%m-%dT%H:%M:%S.000Z"),
		}
		for product in products:
			shipment_data['items'].append({
				'order_product_id': product['id'],
				'quantity': product['quantity']
			})
		shipment = self.api(f"orders/{order_id}/shipments", api_version = 2, api_type = 'post', data = shipment_data)
		if self._last_status < 300:
			return Response().success()
		return Response().error()


	def order_completed(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		order_bigc = self.get_order_by_id(channel_order_id)
		if order_bigc.result != Response.SUCCESS:
			return order_bigc
		order_bigc_data = order_bigc.data
		# if order.shipments.shipped_at and self.shipped_at_to_customer_message():
		# 	customer_message = order_bigc_data.customer_message
		# 	if customer_message:
		# 		customer_message += "\n"
		# 	customer_message += f"Shipped At: {order.shipments.shipped_at}"
		# 	order_data = {
		# 		"customer_message": customer_message
		# 	}
		# 	self.api(f'orders/{order_id}', order_data, 'put', 2)
		if to_int(order_bigc_data.status_id) in [10, 2]:
			return_order = {
				"status": 'Shipped',
			}
			return Response().success(return_order)
		order['order_bigc_data'] = order_bigc_data
		return self.channel_order_completed(channel_order_id, order, current_order)


	def channel_order_completed(self, order_id, order: Order, current_order):
		shipment = self.create_order_shipment(order_id, order)
		# if shipment.result != Response.SUCCESS:
		# 	return shipment

		order_data = {
			"status_id": 2
		}
		self.api(f'orders/{order_id}', order_data, 'put', 2)
		if self._last_status < 300:
			return_order = {
				"status": 'Shipped',
			}
			return Response().success(return_order)
		return Response().error()


	def order_sync_inventory(self, convert: Order, setting_order):
		# setting_order = True if self._state.channel.config.setting.get('order', {}).get('status') != 'disable' else False
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			product_id = None
			variant_id = None
			if row.get('sync_inventory') or row['link_status'] != 'linked' or not row.get('product'):
				continue
			if row['product_id'] and row['parent_id']:
				variant_id = self.get_variant_id(row['product_id'])
				product_id = row['parent_id']
			else:
				product_id = row['product_id']
			parent = row['parent'] or row['product']

			row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				if variant_id and not parent.no_manage_variants:
					variant = self.api(f'catalog/products/{product_id}/variants/{variant_id}')
					if not variant or not variant.data:
						continue
					quantity = variant.data.inventory_level
					new_qty = to_int(quantity) - to_int(row_qty) if prefix == '-' else to_int(quantity) + to_int(row_qty)
					if new_qty < 0:
						new_qty = 0
					update = {
						'inventory_level': new_qty
					}
					update_stock = self.api(f'/catalog/products/{product_id}/variants/{variant_id}', update, 'put')
				else:
					product = self.api(f'catalog/products/{product_id}')
					if not product or not product.data:
						continue
					quantity = product.data.inventory_level
					new_qty = to_int(quantity) - to_int(row_qty) if prefix == '-' else to_int(quantity) + to_int(row_qty)
					if new_qty < 0:
						new_qty = 0
					update = {
						'inventory_level': new_qty
					}
					update_stock = self.api(f'/catalog/products/{product_id}', update, 'put')
				if self._last_status < 300:
					row['sync_inventory'] = True
				else:
					errors = update_stock.title or "Something error"

					row['sync_msg_error'] = errors
		return Response().success()


	def custom_order_status(self, order_status, order: Order):
		if not self._state.channel.config.api.custom_order_status:
			return order_status
		custom_order_status = self._state.channel.config.api.custom_order_status.get(f'c_{order_status}', order_status)
		if custom_order_status == '_channel_type_':
			return order.channel_type or order_status
		return custom_order_status


	def shipped_at_to_customer_message(self):
		return self._state.channel.config.api.shipped_at_to_customer_message


	def order_import(self, convert: Order, order: Order, orders_ext):

		ord_data = Prodict()
		ord_data.external_id = f"{to_str(order.order_number_prefix)}{to_str(order.channel_order_number)}"
		ord_data.external_source = order.channel_name or order.channel_type
		ord_data.billing_address = Prodict()
		if not order.customer.email:
			order.customer.email = to_str(order.customer.first_name).lower().replace(' ', '') + to_str(order.customer.last_name).lower().replace(' ', '') + '@gmail.com'
		billing_address = order.billing_address
		ord_data.billing_address.first_name = billing_address.first_name
		ord_data.billing_address.last_name = billing_address.last_name
		ord_data.billing_address.street_1 = billing_address.address_1 or billing_address.city
		if billing_address.address_2:
			ord_data.billing_address.street_2 = billing_address.address_2
		if billing_address.company:
			ord_data.billing_address.company = billing_address.company

		ord_data.billing_address.city = billing_address.city[0:50] if billing_address.city else ' '
		if billing_address.state.name and self.validate_state(billing_address.state.name):
			ord_data.billing_address.state = billing_address.state.name
		else:
			ord_data.billing_address.state = self._get_state_name_from_code(billing_address.state.state_code if billing_address.state.state_code else billing_address.state.code)
		if not ord_data.billing_address.state:
			ord_data.billing_address.state = 'None'
		ord_data.billing_address.zip = billing_address.postcode or '123456'

		# 	make sure zip code is not empty
		# 	ord_data.billing_address.zip = '123456'
		country_code, country_name = self.validate_country(billing_address.country)
		ord_data.billing_address.country_iso2 = country_code
		ord_data.billing_address.country = country_name
		if billing_address.telephone:
			ord_data.billing_address.phone = billing_address.telephone
		ord_data.billing_address.email = to_str(get_value_by_key_in_dict(billing_address, 'email', order.customer.email)).replace(' ', '').replace(',', '.') if get_value_by_key_in_dict(billing_address, 'email', order.customer.email) else ''

		# shipping address
		shipping_address = Prodict()
		shipping_address.first_name = order.shipping_address.first_name
		shipping_address.last_name = order.shipping_address.last_name
		shipping_address.street_1 = order.shipping_address.address_1 or order.shipping_address.city
		if order.shipping_address.address_2:
			shipping_address.street_2 = order.shipping_address.address_2
		if order.shipping_address.company:
			shipping_address.company = order.shipping_address.company
		shipping_address.city = to_str(order.shipping_address.city)[:50]
		if order.shipping_address.state.name and self.validate_state(order.shipping_address.state.name):
			shipping_address.state = order.shipping_address.state.name
		else:
			shipping_address.state = self._get_state_name_from_code(order.shipping_address.state.state_code if order.shipping_address.state.state_code else order.shipping_address.state.code)
		if not shipping_address.state:
			shipping_address.state = 'None'
		# if order.shipping_address.postcode:
		shipping_address.zip = order.shipping_address.postcode or '123456'
		country_code, country_name = self.validate_country(order.shipping_address.country)
		shipping_address.country_iso2 = country_code
		shipping_address.country = country_name
		# shipping_address.country = order.shipping_address.country.country_name
		# shipping_address.country_iso2 = order.shipping_address.country.country_code
		if order.shipping_address.telephone:
			shipping_address.phone = order.shipping_address.telephone
		shipping_address.email = order.customer.email
		shipping_method = order.shipping.method or order.shipping.title
		if shipping_method:
			shipping_address.shipping_method = shipping_method
		ord_data.shipping_addresses = [shipping_address]
		customer_id = 0
		# order status
		order_status = self.MAP_ORDER_STATUS.get(order.status, 1)
		order_status = self.custom_order_status(order_status, convert)

		ord_items = order.products
		ord_items_count = to_len(ord_items) if ord_items else 0
		# ord_data.customer_id = customer_id
		ord_data.status_id = order_status
		ord_data.subtotal_ex_tax = to_str(order.subtotal)
		ord_data.subtotal_inc_tax = to_decimal(ord_data.subtotal_ex_tax) + to_decimal(order.tax.amount)
		if order.channel_type == 'shopify':
			ord_data.subtotal_inc_tax = to_str(order.subtotal)
			ord_data.subtotal_ex_tax = to_decimal(ord_data.subtotal_inc_tax) - to_decimal(order.tax.amount)
		ord_data.base_shipping_cost = order.shipping.amount if order.shipping.amount else 0.0000
		ord_data.shipping_cost_ex_tax = ord_data.base_shipping_cost
		ord_data.shipping_cost_inc_tax = ord_data.base_shipping_cost
		ord_data.total_ex_tax = to_decimal(order.total) - to_decimal(order.tax.amount)
		ord_data.total_inc_tax = order.total
		ord_data.items_total = ord_items_count
		ord_data.discount_amount = abs(to_decimal(order.discount.amount))
		ord_data.date_created = (convert_format_time(order.created_at, '%Y-%m-%d %H:%M:%S', "%a, %d %b %Y %H:%M:%S %z") + '+0000') if order.created_at else (convert_format_time(get_current_time(), '%Y-%m-%d %H:%M:%S', "%a, %d %b %Y %H:%M:%S %z") + '+0000')
		items_data = list()
		ord_comment = []
		staff_notes = []
		channel_type = order.channel_type
		if channel_type == 'walmartca':
			channel_type = 'walmart'
		staff_notes.append(f'Order Placed by {channel_type.capitalize()}')
		staff_notes.append(f'{channel_type.capitalize()} Order Number {order.channel_order_number}')
		for detail in order.additional_details:
			staff_notes.append(f'{detail.name} {detail.value}')
		if order.history:
			for history in order.history:
				if history.comment:
					if history.get('staff_note'):
						staff_notes.append(history.comment)
					else:
						ord_comment.append(history.comment)


		# todo: import note
		if order.get('notes'):
			staff_notes.append(order.notes)

		ship_by_date = []
		for item in order.products:
			if item.get('ship_by_date'):
				ship_by_date.append({
					'sku': item.product_sku or item.product_name,
					'ship_by_date': item['ship_by_date']
				})
			product_id = 0
			variant_id = 0
			option_data = None
			parent = item['parent'] or item['product']

			if item.parent_id and item.parent_id != item.product_id:
				product = item['product']
				if product.option_data:
					option_data = product['option_data']
				else:
					option_data = self.get_option_data(item.parent_id, item.product_id)
				if product.option_default_data and option_data:
					option_data.extend(product.option_default_data)
				product_id = item.parent_id
				variant_id = self.get_variant_id(item.product_id)
			elif item.product_id:
				product_id = item.product_id

			item_data = Prodict()
			item_data.product_options = list()

			if product_id:
				item_data.product_id = product_id
			if variant_id and not parent.no_manage_variants:
				item_data.variant_id = variant_id
			if option_data:
				item_data.product_options = option_data
			item_data.quantity = to_decimal(item.qty) if to_decimal(item.qty) > 0 else 0
			if to_decimal(item.price) < 0 or to_decimal(item_data.quantity) <= 0:
				continue
			item_data.name = item.product_name
			price_tax = 0
			if item.tax_amount:
				price_tax = to_decimal(to_decimal(item.tax_amount) / to_decimal(item_data.quantity))
			is_included_tax = True
			if to_decimal(item.price) * to_int(item.qty) + to_decimal(item.tax_amount) + item.shipping_amount - item.discount_amount <= item.total:
				is_included_tax = False
			if is_included_tax:
				item_data.price_inc_tax = item.price

				item_data.price_ex_tax = to_decimal(item.price) - price_tax
			else:
				item_data.price_ex_tax = item.price

				item_data.price_inc_tax = to_decimal(item.price) + price_tax
			product_res = self.get_product_by_id(product_id)
			modified_personal = []
			if product_res.result == Response().SUCCESS:
				modified_personal = list(filter(lambda x: x['type'].find('text') != -1, product_res["data"]["modifiers"]))
			option_required = [row['id'] for row in list(filter(lambda x: x['required'], modified_personal))]
			option_filled = []
			for option in item.options:
				if to_str(option.option_name).lower().startswith('personali'):
					staff_notes.append(f"Personalization for sku {item.product_sku}: {option.option_value_name}")
					if not modified_personal:
						continue
					if len(modified_personal) == 1:
						option_value_name = option.option_value_name.replace('\n', ' ')
						item_data.product_options.append({'id': modified_personal[0]['id'], 'value': option_value_name})
						option_filled.append(modified_personal[0]['id'])
					else:
						# TODO: update difffenet len
						product_options = option.option_value_name.split('\n')
						for index, bigc_option in enumerate(modified_personal):
							try:
								channel_option = product_options[index]
							except:
								channel_option = "Unknown"
							if channel_option:
								option_filled.append(bigc_option['id'])

								item_data.product_options.append({'id': bigc_option['id'], 'value': channel_option})

			if option_required:
				option_not_fill = list(set(option_required) - set(option_filled))
				if option_not_fill:
					for option_id in option_not_fill:
						item_data.product_options.append({'id': option_id, 'value': "Unknown"})

			items_data.append(item_data)
		try:
			if ship_by_date and self.shipped_at_to_customer_message():
				ship_by_date_default = ship_by_date[0]
				ord_comment.append(f"{to_str(ship_by_date_default['ship_by_date'])[0:10]}")
		except:
			self.log_traceback()
		ord_data.customer_message = "\n".join(ord_comment)
		# end for
		# end if
		ord_data.products = items_data

		ord_data.staff_notes = "\n".join(staff_notes)

		# todo: import payment method
		ord_data.payment_method = order.payment.method if order.payment.method else ' '

		response_order = self.api('/orders', ord_data, 'post', api_version = 2)
		if self._last_status < 300:
			if 'tracking_number' in order.shipping and order.shipping.tracking_number:
				ship_add = self.api('/orders/' + to_str(response_order.id) + '/shippingaddresses.json', api_version = 2)
				if ship_add:
					ship_add_id = ship_add[0].id
					shipment_data = dict()
					shipment_data.order_address_id = ship_add_id
					shipment_data.tracking_number = order.shipping.tracking_number
					shipment_data.items = list()
					response = self.api('/orders/' + to_str(response_order.id) + '/shipments', shipment_data, 'post', api_version = 2)
					if response.result == 'error':
						shipment_data.items = list()
						self.api('/orders/' + to_str(response_order.id) + '/shipments', shipment_data, 'post')
			# return Response().success([response_order.id, response_order.data])
			order_return = {
				'order_id': response_order.id,
				'order_status': response_order.status,
				'order_number': response_order.id,
				'created_at': response_order.date_created,
			}
			return Response().success([response_order.id, order_return])
		else:
			if isinstance(response_order, list):
				return Response().error(msg = response_order[0]['message'])
			else:
				return Response().error(msg = to_str(response_order))


	def get_option_data(self, parent_id, product_id):
		variant_data = self.api(f'catalog/products/{parent_id}/variants/{product_id}')
		if variant_data and 'data' in variant_data:
			option_data = list()
			option_values = variant_data.data.option_values
			for option_value in option_values:
				option_data.append({
					'id': option_value.option_id,
					'value': to_str(option_value.id),
				})
			return option_data
		else:
			self.log('Can not get child id: ' + to_str(product_id) + ' from product: ' + to_str(product_id))
			return None


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()


	def api(self, path, data = None, api_type = "get", api_version = 3):
		client_id = self._state.channel.config.api.client_id
		api_token = self._state.channel.config.api.api_token
		api_path = self._state.channel.config.api.api_path
		api_path = api_path.replace('stores/stores', 'stores')
		api_path = api_path.replace('/v3', f'/v{api_version}')
		header = {'Accept': 'application/json', 'Content-Type': 'application/json', 'X-Auth-Client': client_id, 'X-Auth-Token': api_token}
		url = api_path.rstrip('/') + '/' + path.strip().lstrip('/')
		url = url.replace('/v-', '/')
		res = self.requests(url, data, method = api_type, headers = header)
		if isinstance(data, dict) or isinstance(data, list):
			data = json.dumps(data)

		return res


	# def remove_html(self, text):
	# 	text = re.sub('<[^<]+?>', '', text)
	# 	return text

	def image_exist(self, url, path = ''):
		image_process = self.process_image_before_import(url, path)
		try:
			exist = requests.get(image_process['url'], headers = {"User-Agent": get_random_useragent()}, timeout = 10, verify = False)
		except requests.exceptions.Timeout as errt:
			self.log("image " + image_process['url'] + 'connection timeout', self._type + '_image')
			return False
		except Exception as e:
			self.log_traceback('img_exist')
			return False
		return exist.status_code == requests.codes.ok


	def create_async_request_data(self, path, data = None, method = 'POST'):
		return {
			'url': self._state.channel.config.api.api_path + path.strip(),
			'data': json_encode(data) if data else None,
			'method': method
		}


	def to_timestamp(self, value, str_format = '%Y-%m-%d %H:%M:%S'):
		try:
			timestamp = to_int(time.mktime(time.strptime(value, str_format)))
			if timestamp:
				return timestamp
			return to_int(time.time())
		except:
			return to_int(time.time())


	def strip_html_tag(self, html, none_check = False):
		if not html:
			return ''
		s = StripHtml()
		s.feed(to_str(html))
		return s.get_data()


	def _get_state_code_from_name(self, name):
		all_states = self.STATES
		if name:
			for code, state_name in all_states.items():
				if to_str(name).lower() == to_str(state_name).lower():
					return code
		return name


	def validate_state(self, state_name):
		if not to_str(state_name):
			return True
		state = list(map(lambda x: x.lower(), list(self.STATES.values())))
		return to_str(state_name).lower() in state


	def _get_state_name_from_code(self, code):
		all_states = self.STATES
		code = to_str(code).upper()
		if code and to_str(code) in all_states:
			return all_states[code]
		return ' '


	def get_country_code_by_name(self, name):
		countries = json.loads(self.COUNTRIES)

		if name:
			for code, country_name in countries.items():
				if to_str(name).lower() == to_str(country_name).lower():
					return code
		return ''


	def get_country_name_by_code(self, iso_code):
		if not to_str(iso_code):
			return ''
		try:
			# countries = urllib.request.urlopen("http://country.io/names.json").read()
			# countries = countries.decode('utf-8')
			countries = json.loads(self.COUNTRIES)
		except Exception as e:
			return ''
		return countries.get(to_str(iso_code).upper(), '')


	def validate_country(self, country: OrderAddressCountry):
		for item in [country.country_code, country.country_name]:
			if item:
				country_name = self.get_country_name_by_code(country.country_code)
				if country_name:
					return item, country_name
				country_code = self.get_country_code_by_name(item)
				if country_code:
					return country_code, country_name
		return 'US', 'United States'


	def convert_attribute_code(self, name):
		if not to_str(name).strip(' / - _'):
			return ''
		str_convert = html.unescape(name)
		if isinstance(str_convert, bool):
			if str_convert:
				str_convert = 'yes'
			else:
				str_convert = 'no'
		result = self.generate_url(str_convert)
		if not result:
			return self.parse_url(str_convert).lower()
		try:
			check_encode = chardet.detect(result.encode())
			if check_encode['encoding'] != 'ascii' or not result:
				return self.parse_url(result).lower()
		except Exception:
			pass
		return result.strip('- ')


	def get_draft_extend_channel_data(self, product):
		extend_data = dict()
		description = nl2br(product.description)
		if description != product.description:
			extend_data['description'] = description
		if self._state.channel.config.api.gtin_to_sku:
			gtin = product.gtin or product.upc or product.ean
			if gtin:
				extend_data['sku'] = gtin
		return extend_data


	def convert_child_to_option(self, childrens):
		max_attribute = 0
		option_src = list()
		for children in childrens:
			variant_attribute = list(filter(lambda x: x.get('use_variant'), children['attributes']))

			if max_attribute <= to_len(variant_attribute):
				max_attribute = to_len(variant_attribute)
				option_src = variant_attribute
		all_option_name = list()
		for option in option_src:
			if option.attribute_name in all_option_name:
				continue
			all_option_name.append(option.attribute_name)
		options = dict()
		for children in childrens:
			for attribute in children.attributes:
				if attribute.attribute_name not in all_option_name:
					continue
				if attribute.attribute_name not in options:
					options[attribute.attribute_name] = dict()
				if not attribute.attribute_value_name or attribute.attribute_value_name in options[attribute.attribute_name]:
					continue
				option_data = ProductOptionValue()
				option_data.option_code = attribute.attribute_code
				option_data.option_value_name = attribute.attribute_value_name
				option_data.option_value_code = attribute.attribute_value_code
				option_data.option_value_price = attribute.price if attribute.price and to_int(attribute.price) > 0 else (children.price if to_len(children.attributes) < 2 and to_int(children.price) > 0 else 0)
				option_data.price_prefix = attribute.price_prefix
				options[attribute.attribute_name][attribute.attribute_value_name] = option_data
		all_options = list()
		for option_name, option in options.items():
			option_data = ProductOption()
			option_data.id = None
			option_data.code = self.convert_attribute_code(option_name)
			option_data.option_type = 'select'
			option_data.option_name = option_name
			for option_value_name, option_value in option.items():
				if option_value.option_code and option_value.option_code != '':
					option_data.code = option_value.option_code
					option_data.option_code = option_value.option_code
				option_data.option_values.append(option_value)
			all_options.append(option_data)
		return all_options


	def is_condition_shown(self):
		if 'is_condition_shown' in self._state.channel.config.api:
			return to_bool(self._state.channel.config.api.is_condition_shown)
		return True


	def convert_option_to_child(self, options, parent, base_variant_id = False):
		variants = list()
		options_src = dict()
		number_variant = 1
		for option in options:
			if option.option_type != 'select':
				continue
			values = list()
			key_option = get_value_by_key_in_dict(option, 'id', option['option_code'])
			if option['option_values']:
				number_variant *= to_len(option['option_values'])
				for value in option['option_values']:
					values.append(value['option_value_name'])
					opt_val = {
						'option_id': option['id'],
						'option_name': option['option_name'],
						'qty': value['option_value_qty'],
						'sku': value['option_value_sku'],
						'option_value_name': value['option_value_name'],
						'option_value_id': value['id'],
						'price': value['option_value_price'],
						'price_prefix': value['price_prefix'],
						'thumb_image': get_value_by_key_in_dict(value, 'thumb_image', {'url': '', 'path': ''}),
						'weight': get_value_by_key_in_dict(value, 'option_value_weight', 0),
						'weight_prefix': get_value_by_key_in_dict(value, 'weight_prefix', '+')
					}
					if key_option not in options_src:
						options_src[key_option] = list()
					if opt_val['option_value_name']:
						options_src[key_option].append(opt_val)
		if not options_src or number_variant > 1000:
			return variants
		combinations = self.combination_from_multi_dict(options_src)

		children_base_data = self.copy_data_from_parent_product(parent)

		for item, children in enumerate(combinations):
			children_data = copy.deepcopy(children_base_data)
			images = list()
			sku = ''
			name = ''
			min_qty = to_int(parent['qty'])
			status = children_data['status']
			option_data = list()
			for index, attribute in enumerate(children):
				option_data.append({
					'id': attribute['option_id'],
					'value': attribute['option_value_id'],
				})
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = attribute['option_name']
				attribute_data.attribute_value_name = attribute['option_value_name']
				children_data['price'] = self.get_price_children(children_data['price'], attribute['price'], attribute['price_prefix'])
				children_data['weight'] = self.get_price_children(children_data['weight'], attribute['weight'], attribute['weight_prefix'])
				# children_data['weight'] = to_decimal(children_data['weight']) + to_decimal(attribute['weight_prefix'])
				if children_data['special_price']['price']:
					children_data['special_price']['price'] = self.get_price_children(children_data['special_price']['price'], attribute['price'], attribute['price_prefix'])
				children_data['attributes'].append(attribute_data)
				if sku:
					sku += '-'
				sku += attribute['sku'] if attribute['sku'] else attribute['option_value_name']
				if name:
					name += '-'
				name += attribute['option_value_name']
				if attribute['qty'] is not False and to_int(attribute['qty']) < min_qty:
					min_qty = to_int(attribute['qty'])
				if 'thumb_image' in attribute:
					if attribute['thumb_image']['url']:
						images.append(attribute['thumb_image'])
			if images:
				list_image = list()
				for index, image in enumerate(images):
					if index == 0:
						children_data['thumb_image']['url'] = image['url']
						children_data['thumb_image']['path'] = image['path']
					else:
						process_image = self.process_image_before_import(image['url'], image['path'])
						if process_image['url'] not in list_image:
							list_image.append(process_image['url'])
							children_data['images'].append(image)
			children_data['sku'] = to_str(children_data['sku']) + '-' + sku if not base_variant_id else children_data['sku']
			children_data['option_data'] = option_data
			children_data['qty'] = min_qty
			children_data['status'] = status
			children_data['code'] = children_data['sku'].lower()
			children_data['id'] = self.to_variant_id(f"{parent.id}-{self.variant_key_generate(children_data)}")
			if base_variant_id:
				children_data['channel_data'] = {
					'variant_id': base_variant_id
				}
			variants.append(children_data)
		return variants


	STATES = {
		'AL': 'Alabama',
		'AK': 'Alaska',
		'AS': 'American Samoa',
		'AZ': 'Arizona',
		'AR': 'Arkansas',
		'AF': 'Armed Forces Africa',
		'AA': 'Armed Forces Americas',
		'AC': 'Armed Forces Canada',
		'AE': 'Armed Forces Europe',
		'AM': 'Armed Forces Middle East',
		'AP': 'Armed Forces Pacific',
		'CA': 'California',
		'CO': 'Colorado',
		'CT': 'Connecticut',
		'DE': 'Delaware',
		'DC': 'District of Columbia',
		'FM': 'Federated States Of Micronesia',
		'FL': 'Florida',
		'GA': 'Georgia',
		'GU': 'Guam',
		'HI': 'Hawaii',
		'ID': 'Idaho',
		'IL': 'Illinois',
		'IN': 'Indiana',
		'IA': 'Iowa',
		'KS': 'Kansas',
		'KY': 'Kentucky',
		'LA': 'Louisiana',
		'ME': 'Maine',
		'MH': 'Marshall Islands',
		'MD': 'Maryland',
		'MA': 'Massachusetts',
		'MI': 'Michigan',
		'MN': 'Minnesota',
		'MS': 'Mississippi',
		'MO': 'Missouri',
		'MT': 'Montana',
		'NE': 'Nebraska',
		'NV': 'Nevada',
		'NH': 'New Hampshire',
		'NJ': 'New Jersey',
		'NM': 'New Mexico',
		'NY': 'New York',
		'NC': 'North Carolina',
		'ND': 'North Dakota',
		'MP': 'Northern Mariana Islands',
		'OH': 'Ohio',
		'OK': 'Oklahoma',
		'OR': 'Oregon',
		'PW': 'Palau',
		'PA': 'Pennsylvania',
		'PR': 'Puerto Rico',
		'RI': 'Rhode Island',
		'SC': 'South Carolina',
		'SD': 'South Dakota',
		'TN': 'Tennessee',
		'TX': 'Texas',
		'UT': 'Utah',
		'VT': 'Vermont',
		'VI': 'Virgin Islands',
		'VA': 'Virginia',
		'WA': 'Washington',
		'WV': 'West Virginia',
		'WI': 'Wisconsin',
		'WY': 'Wyoming',
		'AB': 'Alberta',
		'BC': 'British Columbia',
		'MB': 'Manitoba',
		'NF': 'Newfoundland',
		'NB': 'New Brunswick',
		'NS': 'Nova Scotia',
		'NT': 'Northwest Territories',
		'NU': 'Nunavut',
		'ON': 'Ontario',
		'PE': 'Prince Edward Island',
		'QC': 'Quebec',
		'SK': 'Saskatchewan',
		'YT': 'Yukon Territory',
		'NDS': 'Niedersachsen',
		'BAW': 'Baden-Württemberg',
		'BAY': 'Bayern',
		'BER': 'Berlin',
		'BRG': 'Brandenburg',
		'BRE': 'Bremen',
		'HAM': 'Hamburg',
		'HES': 'Hessen',
		'MEC': 'Mecklenburg-Vorpommern',
		'NRW': 'Nordrhein-Westfalen',
		'RHE': 'Rheinland-Pfalz',
		'SAR': 'Saarland',
		'SAS': 'Sachsen',
		'SAC': 'Sachsen-Anhalt',
		'SCN': 'Schleswig-Holstein',
		'THE': 'Thüringen',
		'NO': 'Niederösterreich',
		'OO': 'Oberösterreich',
		'SB': 'Salzburg',
		'KN': 'Kärnten',
		'ST': 'Steiermark',
		'TI': 'Tirol',
		'BL': 'Burgenland',
		'VB': 'Voralberg',
		'AG': 'Aargau',
		'AI': 'Appenzell Innerrhoden',
		'BE': 'Bern',
		'BS': 'Basel-Stadt',
		'FR': 'Freiburg',
		'GE': 'Genf',
		'GL': 'Glarus',
		'JU': 'Graubünden',
		'LU': 'Luzern',
		'NW': 'Nidwalden',
		'OW': 'Obwalden',
		'SG': 'St. Gallen',
		'SH': 'Schaffhausen',
		'SO': 'Solothurn',
		'SZ': 'Schwyz',
		'TG': 'Thurgau',
		'UR': 'Uri',
		'VD': 'Waadt',
		'VS': 'Wallis',
		'ZG': 'Zug',
		'ZH': 'Zürich',
		'A Coruña': 'A Coruña',
		'Alava': 'Alava',
		'Albacete': 'Albacete',
		'Alicante': 'Alicante',
		'Almeria': 'Almeria',
		'Asturias': 'Asturias',
		'Avila': 'Avila',
		'Badajoz': 'Badajoz',
		'Baleares': 'Baleares',
		'Barcelona': 'Barcelona',
		'Burgos': 'Burgos',
		'Caceres': 'Caceres',
		'Cadiz': 'Cadiz',
		'Cantabria': 'Cantabria',
		'Castellon': 'Castellon',
		'Ceuta': 'Ceuta',
		'Ciudad Real': 'Ciudad Real',
		'Cordoba': 'Cordoba',
		'Cuenca': 'Cuenca',
		'Girona': 'Girona',
		'Granada': 'Granada',
		'Guadalajara': 'Guadalajara',
		'Guipuzcoa': 'Guipuzcoa',
		'Huelva': 'Huelva',
		'Huesca': 'Huesca',
		'Jaen': 'Jaen',
		'La Rioja': 'La Rioja',
		'Las Palmas': 'Las Palmas',
		'Leon': 'Leon',
		'Lleida': 'Lleida',
		'Lugo': 'Lugo',
		'Madrid': 'Madrid',
		'Malaga': 'Malaga',
		'Melilla': 'Melilla',
		'Murcia': 'Murcia',
		'Navarra': 'Navarra',
		'Ourense': 'Ourense',
		'Palencia': 'Palencia',
		'Pontevedra': 'Pontevedra',
		'Salamanca': 'Salamanca',
		'Santa Cruz de Tenerife': 'Santa Cruz de Tenerife',
		'Segovia': 'Segovia',
		'Sevilla': 'Sevilla',
		'Soria': 'Soria',
		'Tarragona': 'Tarragona',
		'Teruel': 'Teruel',
		'Toledo': 'Toledo',
		'Valencia': 'Valencia',
		'Valladolid': 'Valladolid',
		'Vizcaya': 'Vizcaya',
		'Zamora': 'Zamora',
		'Zaragoza': 'Zaragoza',
		'ACT': 'Australian Capital Territory',
		'JBT': 'Jervis Bay Territory',
		'NSW': 'New South Wales',
		'QLD': 'Queensland',
		'SA': 'South Australia',
		'TAS': 'Tasmania',
		'VIC': 'Victoria',
	}

	COUNTRIES = '{"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon", "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar", "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China", "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "Korea, Republic of", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen", "DZ": "Algeria", "US": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India", "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}'
