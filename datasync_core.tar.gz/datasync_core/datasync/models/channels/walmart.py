# fix requests.exceptions.ConnectionError: ('Connection aborted.', HTTPException('got more than 100 headers',))
import http.client
http.client._MAXHEADERS = 1000

import csv
import copy
import urllib.parse
import uuid
import requests
import io
import zipfile
from collections import OrderedDict
from datetime import timedelta
from typing import Dict, Any, List
from countryinfo import CountryInfo
from copy import deepcopy
from ast import literal_eval
from requests.auth import HTTPBasicAuth
from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderAdditionalDetails
from datasync.models.constructs.product import (Product, ProductVariant, ProductImage, ProductVariantAttribute,
                                                ProductChannel, ProductAttribute)
from datasync.models.modes.test import ModelModesTest


class ModelChannelsWalmart(ModelChannel):
	ORDER_STATUS = {  # mapping status from the warehouse to walmart system
		Order.OPEN: 'Created',
		Order.AWAITING_PAYMENT: 'Acknowledged',
		Order.READY_TO_SHIP: 'Acknowledged',
		Order.SHIPPING: 'Shipped',
		Order.COMPLETED: 'Delivered',
		Order.CANCELED: 'Cancelled',
		Order.REFUNDED: 'Refund'
	}

	INGESTION = {
		'data': 'DATA_ERROR',
		'system': 'SYSTEM_ERROR',
		'timeout': 'TIMEOUT_ERROR',
		'success': 'SUCCESS',
		'inprogress': 'INPROGRESS',
	}

	_WALMART_STATUS = {
		'active': 'active',
		'retired': 'retired',
		'archived': 'archived',
		'unpublished': 'unpublished', # active but have problem
	}

	SELLING_CHANNEL = 'marketplace'
	API_VERSION = 4.5
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'shipping', 'category']
	_LIST_PRODUCT_ID_TYPE = ['gtin', 'upc', 'ean', 'isbn']
	_TEST_MODE = ['test_sandbox', 'test_marketplace']
	_TIME_SLEEP_FEED = 60
	_NOT_FOUND_CATEGORY = 'LITCOMMERCE_NOT_FOUND_CATEGORY'
	_MAX_ITEM_PER_FEED = 5
	_FORMAT_TIME = '%Y-%m-%dT%H:%M:%SZ'

	# Import feed items
	cache_products: List[Product] = list()
	cache_products_imported: List[Product] = list()
	cache_warnings = dict()
	cache_errors: Dict[str, list] = dict()
	cache_products_sku_index = dict()
	cache_products_insert = dict()
	parent_products = dict()
	parent_variants = dict()
	_extend_product_map = dict()
	_category_template: Dict = dict()
	_model_local: ModelModesTest = None

	def __init__(self):
		super().__init__()
		self._flag_finish_get: bool = False
		self._next_cursor_order: str = ''
		self._store_information: dict = dict()
		self._url_base: str = ''
		# flag to check feed type new_item or maintenance feed
		self._update_product_flow: bool = False
		self._update_qty: bool = False
		self._update_price: bool = False
		self._update_shipping: bool = True
		self._offset: int = 0
		self._total_parent_product: int = 0
		self._next_cursor_product: str = '*'
		self._convert_product: dict or str = dict()
		self._update_product_code: bool = False
		self._feed_has_error: bool = False
		self._republish_feed: bool or str = False
		self._table_product_id: int = 0

	def get_api_info(self):
		return {
			'client_id': to_str(self._state.channel.config.api.client_id),
			'client_secret': to_str(self._state.channel.config.api.client_secret)
		}

	def get_app_mode(self):
		app_mode = self._state.channel.config.api.app_mode
		if not app_mode:
			return get_config_ini('walmart', 'mode')
		return app_mode

	def get_url_base(self):
		mode = self.get_app_mode()
		if mode == 'test_sandbox':
			self._url_base = 'https://sandbox.walmartapis.com'
		elif mode == 'test_marketplace':
			self._url_base = 'https://marketplace.walmartapis.com'
		elif mode == 'production':
			self._url_base = 'https://marketplace.walmartapis.com'
		return self._url_base

	def get_model_local(self):
		if self._model_local:
			return self._model_local
		self._model_local = ModelModesTest()
		self._model_local.set_user_id(self._user_id)
		return self._model_local


	def get_state_pull_product_total_view(self):
		return to_int(self._state.pull.process.products.total_view)

	def set_state_pull_product_total_view(self, total_items):
		self._state.pull.process.products.total_view = to_int(total_items)


	def to_underscore(self, title_raw):
		"""convert the title from csv to underscore"""
		return title_raw.strip().lower().replace(' ', '_').strip('?')


	def product_title_default(self):
		return [
			'sku', 'item_id', 'product_name', 'lifecycle_status', 'publish_status',
			'product_category', 'price', 'currency', 'msrp', 'product_tax_code',
			'shipping_weight', 'shipping_weight_unit', 'fulfillment_lag_time',
			'wpid', 'gtin', 'upc', 'item_page_url', 'primary_image_url', 'shelf_name',
			'primary_category_path', 'brand', 'variant_group_id', 'primary_variant',
			'variant_grouping_attributes', 'variant_grouping_values', 'status_change_reason'
		]

	def products_table_construct(self):
		table_construct = {
			'table': self.get_product_table_name(),
			'rows': {
				'id': 'int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT',
				'user_id': 'int(11)',
				'solved': 'tinyint NOT NULL DEFAULT 0'
			}
		}
		fields = self.product_title_default()
		for field in fields:
			table_construct['rows'][field] = 'text'
		return table_construct

	def get_product_table_name(self):
		return f'products_{self.get_sync_id()}'

	def log_response_data(self, method, url, response, **request_options):
		"""
		Daily run not required
		Log request data from Walmart to check partner configuration
		"""
		client_id = to_str(self._state.channel.config.api.client_id)
		client_secret = to_str(self._state.channel.config.api.client_secret)
		auth = '"Authorization":' + '"' + f"Basic {string_to_base64(f'{client_id}:{client_secret}')}" + '"'
		msg = """
*** Endpoint ***
		{} {}
		""".format(to_str(method).upper(), to_str(url))

		msg += """
*** Headers ***
		{}
		{}
		
*** Payload ***
		{}
		""".format(to_str(request_options['headers']).replace('", "', '"\n\t\t "')[1:-1],
			auth,
			json_encode(request_options.get('params', '') or request_options.get('json', '')))

		msg += """
*** Response ***
		{} {}
		{}
		
		""".format(to_str(response.status_code), to_str(response.reason), to_str(response.text))

		name_log = 'response_data_' + to_str(url).split('v3/')[1].split('/')[0].split('?')[0]
		self.log(msg, name_log)
		return True

	def log_traceback(self, type_error = 'exceptions', msg = '') -> None:
		"""log the channel_id has exceptions"""
		super().log_traceback(type_error = type_error, msg = msg)
		error_log = {
			'channel_id': self.get_channel_id(),
			'process_type': self.get_process_type()
		}
		log(error_log, 'walmart', 'exceptions')

	def set_update_qty_mode(self, mode: bool = True) -> bool:
		"""Update _update_qty mode"""
		self._update_qty = mode
		return mode

	def set_update_price_mode(self, mode: bool = True) -> bool:
		"""Update _update_price mode"""
		self._update_price = mode
		return mode

	def set_update_product_mode(self, mode: bool = True) -> bool:
		"""Update _update_product mode"""
		self._update_product_flow = mode
		return mode

	def get_channel_type_key(self) -> str or None:
		channel_type = get_config_ini('walmart', 'channel_type_key')
		return channel_type

	def requests(self, url, data = None, headers = None, method = 'get', retry = 0, err: str = '') -> Response:
		"""Function send request to walmart
		1. Send a request to walmart
		2. If an access_token not create -> create new token
		3. After sending a response to walmart, update the last status, last header
		3. Catch an error and send an error message in a warp Response Error
		4. If the response success, try to convert response.text to dict/Prodict
		"""

		if retry > 3:
			return Response().error(msg = err)

		time.sleep(retry * retry)
		retry += 1
		RESPONSE_ERROR = 'RESPONSE_HAS_ERROR'
		NOT_HAVE_ERROR = 0
		THRESH_HOLD_ERROR = Errors.WALMART_RATE_LIMIT

		def generate_token_and_request() -> Response:
			access_token = self.create_access_token()
			request_options['headers']['WM_SEC.ACCESS_TOKEN'] = access_token
			response_ = requests.request(method, url, **request_options)
			return response_

		def reset_next_limit() -> int:
			""" get the next_reset_time in the response header
			and add 120 second to sleep
			"""
			sleep_time = 120
			next_replenishment = to_int(response.headers.get('X-Next-Replenishment-Time', 0))
			if next_replenishment:
				# timestamp in milliseconds
				wait_time_timestamp = to_int(next_replenishment / 1000 + 120)
				timestamp_now = time.time()
				sleep_time = min(wait_time_timestamp - timestamp_now, 600)

			time.sleep(sleep_time)

			log_data = {
				'url': url,
				'next-replenishment-time': next_replenishment,
				'x-current-token-count': to_int(response.headers.get('X-Current-Token-Count', 0)),
				'sleep_time': sleep_time
			}
			self.log_request_error(log_data, 'reset_next_limit')
			return sleep_time

		def update_last_response():
			nonlocal response
			self._last_header = response.headers
			self._last_status = response.status_code

		def update_timestamp_publish() -> None:
			nonlocal response
			try:
				# walmart respond with milliseconds format
				timestamp_ = to_int(response.headers['x-next-replenishment-time']) // 1000

			except Exception:
				timestamp_ = 0
			
			self.update_channel(walmart_timestamp_publish = timestamp_)


		def check_status_code_response() -> int:
			nonlocal response
			result: int = NOT_HAVE_ERROR
			if response.status_code == 429 or get_config_ini('walmart', 'mode') in self._TEST_MODE:
				# check limit feed
				if (
						'You have exceeded your API calls threshold' in response.text
						and response.url.find('feeds?feedType') != -1
				):
					update_timestamp_publish()
					time_sleep = reset_next_limit()
					response = generate_token_and_request()
					result = THRESH_HOLD_ERROR

			elif response.status_code > 300:
				if to_str(response.text).find('Unauthorized token or incorrect authorization header. Please verify correct format') != -1:
					error = Errors.WALMART_API_INVALID

				elif to_str(response.text).find('FORBIDDEN.GMP_GATEWAY_API') != -1 and to_str(response.text).find('Access denied') != -1:
					error = Errors.WALMART_SCOPE_INVALID

				else:
					error = Errors.WALMART_INTERNAL_ERROR
				result = error

			return result

		def convert_response_data() -> dict or str:
			nonlocal response, response_data

			response_data = response.text
			response_data_decode = json_decode(response_data)

			if not response_data_decode and method != 'delete':
				log_request_error(response)
				response = RESPONSE_ERROR

			elif response_data_decode:
				try:
					response_prodict = Prodict(**response_data_decode)
					log_validate = True
					if (
						log_validate
						or get_config_ini('walmart', 'mode') in self._TEST_MODE
						or self.is_log()
					):
						self.log_response_data(method, url, response, **request_options)

				except Exception:
					response_prodict = response_data_decode
				response_data = response_prodict

			else:
				response = RESPONSE_ERROR

			return response_data

		def log_request_error(_res):
			try:
				error = {
					'method': method,
					'status': _res.status_code,
					'data': to_str(data),
					'header': to_str(_res.headers),
					'response': _res.text,
				}
			except:
				error = {'status': 'ERROR', 'data': _res}
			self.log_request_error(url = url, log_type = 'response_error', **error)

		client_id = to_str(self._state.channel.config.api.client_id)
		client_secret = to_str(self._state.channel.config.api.client_secret)
		basic_auth = HTTPBasicAuth(client_id, client_secret)

		method = to_str(method).lower()

		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()

		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data

		request_options['auth'] = basic_auth
		request_options = self.combine_request_options(request_options)
		response_data = False

		try:
			response = requests.request(method, url, **request_options)
			if response.status_code == 401:
				response = generate_token_and_request()

			# https://developer.walmart.com/doc/us/mp/us-mp-errors/
			if response.status_code > 204:
				log_request_error(response)

			update_last_response()
			check_message = check_status_code_response()
			if check_message in [THRESH_HOLD_ERROR, Errors.WALMART_API_INVALID]:
				return self.requests(
					url = url,
					data = data,
					method = method,
					headers = headers,
					retry = retry,
					err = self.get_msg_error(check_message))

			elif check_message:
				return Response().error(code = check_message, msg = Errors().get_msg_error(check_message))

			response_data = convert_response_data()
			if response_data == RESPONSE_ERROR:
				return Response().error()

		except (requests.exceptions.SSLError, requests.exceptions.ReadTimeout) as e:
			if retry < 5:
				retry += 1
				time.sleep(retry * 2)
				return self.requests(url, data, headers, method, retry)

		except Exception as e:
			request_data = str({
				'method': method,
				'url': url,
				'request_options': request_options
			})
			self.log_traceback(msg = request_data)
			log_request_error(response)
			err = Errors.EXCEPTION
			return Response().error(code = err, msg = Errors().get_msg_error(err))

		return Response().success(data = response_data)

	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent

		try:
			url = 'settings/partnerprofile'
			response = self.api(url, api_type = 'get')
			if response.result != Response.SUCCESS:
				return Response().error(msg = response.msg)

			if isinstance(response.data.get('error'), list):
				error_code = to_str(response.data.error[0].get('code')).lower()
				if 'system_error' in error_code:
					return Response().error(code = Errors.WALMART_INTERNAL_ERROR)
				elif 'unauthorized' in error_code:
					return Response().error(code = Errors.WALMART_API_INVALID)

			partner_id = to_str(response.data.get('partner', {}).get('partnerId'))

		except Exception as e:
			self.log_traceback()
			return Response().error(code = Errors.EXCEPTION)

		self.set_channel_partner_id(partner_id)
		return Response().success()

	def set_channel_partner_id(self, partner_id: str) -> None:
		self._state.channel.config.api.partner_id = partner_id

	def get_channel_partner_id(self) -> str:
		return self._state.channel.config.api.partner_id

	def get_store_information(self):
		if self._store_information:
			return self._store_information
		self._store_information = self.api('settings/partnerprofile')
		return self._store_information.data

	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent

		self.set_identifier(self.get_channel_partner_id())
		return Response().success()

	def after_create_channel(self, data):
		return Response().success()

	def validate_api_info(self):
		validate = super(ModelChannelsWalmart, self).validate_api_info()
		if validate.result != Response.SUCCESS:
			return validate
		client_id = to_str(self._state.channel.config.api.client_id)
		client_secret = to_str(self._state.channel.config.api.client_secret)
		self._url_base = self.get_url_base()
		if not (client_id and client_secret):
			return Response().error(code = Errors.WALMART_API_INVALID)
		return Response().success()

	def get_product_updated_at(self, product):
		return product.date_modified

	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(updated_at[0:10], '%Y-%m-%d')

	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		# If we don't send param `publishedStatus`
		# Walmart response with both published and unpublished

		# product
		if self.is_product_process():
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.total = 0
			if not self._state.pull.process.products.id_src:
				self._state.pull.process.products.id_src = 0
			if self.is_refresh_process():
				self._state.pull.process.products.total_view = 0

			# recall product quick-fix
			product_filter_condition = {
				'limit': 1,
				'lifecycleStatus': (
						to_str(self._request_data.get('walmart_status'))
						or self._WALMART_STATUS['active']
				).upper()
			}

			offset = max(self._state.pull.process.products.imported, 50)
			if self._offset:
				product_filter_condition['offset'] = offset

			products_api, _ = self.recall_get_items(product_filter_condition)
			if products_api.result == Response.SUCCESS:
				products_api = products_api.data
				total_items = products_api.get('totalItems', 0)
				# TODO: create notification for user notice
				self.set_state_pull_product_total_view(total_items)
				self._state.pull.process.products.total = -1 if self.is_refresh_process() else total_items
				if self.is_use_get_item_report():
					report_requests = self.get_total_item_report()
					if report_requests.result != Response.SUCCESS:
						return Response().stop()
					total_item_report = report_requests['data']
					self.set_state_pull_product_total_view(total_item_report)
			else:
				return Response().stop()

		if self.is_order_process():
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			start_time = self.get_order_start_time('iso')
			last_modifier = self._state.pull.process.orders.max_last_modified
			# last_modifier = convert_format_time(last_modifier, old_format = '%Y-%m-%d %H:%M:%S', new_format = '%Y-%m-%dT%H:%M:%SZ')

			order_filter_condition = {
				'createdStartDate': start_time,
				'limit': 1
			}

			if last_modifier and 'Z' in to_str(last_modifier):
				order_filter_condition['lastModifiedStartDate'] = last_modifier
				self.set_order_max_last_modifier(last_modifier)

			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				order_filter_condition['createdStartDate'] = '2023-01-19T01:04:28Z'
				order_filter_condition['lastModifiedStartDate'] = '2023-02-24T04:40:29Z'

			order_api = self.api('orders', data = order_filter_condition)
			if order_api.result == Response.ERROR:
				return Response().stop()

			total_count = order_api.get('data', {}).get('list', {}).get('meta', {}).get('totalCount', 0)
			self._state.pull.process.orders.total = total_count
		return Response().success()

	def is_use_get_item_report(self):
		"""
		use this method to retrieve the seller catalog data on a larger
		sellers are required to wait for approx an hour for the report generation process
		"""

		# TODO: test mode
		MINIMUM_PRODUCT = to_int(self._state.channel.config.api.minimum_product_use_report) or 5000
		return self.get_state_pull_product_total_view() > MINIMUM_PRODUCT

	def get_total_item_report(self):
		"""
		# TODO: refactor
		1. send the request  to generate item report
		2. waiting to the walmart generate the report
		3. get downloadURL and generate the file
		-- walmart allow to request generate one generate per hours
		"""
		req_gen = self.api(
			path = 'reports/reportRequests?reportType=ITEM&reportVersion=v4',
			api_type = 'post',
			content_type = 'application/json'
		)
		request_id = ''
		if self._last_status < 300:
			request_id = req_gen.data.get('requestId', '')
		if not request_id:
			req_get_id = self.api('reports/reportRequests')
			if isinstance(req_get_id.data.get('requests'), list):
				request_id = next(
					filter(lambda q: q['reportType'] == 'ITEM', req_get_id.data.get('requests')), {}
				).get('requestId', '')

			if not request_id:
				# get tea time and import later
				# TODO: update error message
				return Response().error()
		# if test_mode:
		# 	request_id = '93d1308d-1864-4ebd-8ef5-0d1dba990bc0'
		res_report_file = self.api(
			path = f'reports/downloadReport?requestId={request_id}'
		)
		download_url = res_report_file.data.get('downloadURL', '')
		"""
		walmart note in their documents that the report will take 15 to 45
		minutes to generate
		"""
		recall, MAX_CHECK_ROUND = 0, 10
		while not download_url and recall < MAX_CHECK_ROUND:
			time.sleep(self.get_sleep_time(15))
			recall += 1
			res_report_file = self.api(
				path = f'reports/downloadReport?requestId={request_id}'
			)
			download_url = res_report_file.data.get('downloadURL', '')

		if not download_url:
			return Response().error()

		zip_request = requests.get(download_url)
		if zip_request.status_code != 200:
			return Response().error()
		try:
			zip_download = zipfile.ZipFile( io.BytesIO(zip_request.content) )
			with zip_download.open(zip_download.namelist()[0], 'r') as csv_byte:
				csv_file = csv.DictReader(
					io.TextIOWrapper(csv_byte, 'utf-8')
				)

				self.get_model_local().query_raw("DROP TABLE IF EXISTS `{}`".format(self.get_product_table_name()))

				products_table_construct = self.products_table_construct()
				query = self.get_model_local().dict_to_create_table_sql(products_table_construct)
				if query['result'] == Response.SUCCESS:
					self.get_model_local().query_raw(query['query'])

				values = []
				product_title_default = self.product_title_default()
				total_product = 0
				for product in csv_file:
					data = {
						'user_id': self._user_id
					}
					if not isinstance(product, dict):
						continue
					for field in product.keys():
						field_name = self.to_underscore(field)
						if self.to_underscore(field) in product_title_default:
							data[field_name] = to_str(product[field]).strip('"')
							if field_name == 'brand' and product[field] == 'unknow':
								data[field_name] = ''
					values.append(data)
					if len(values) >= 200:
						total_product += len(values)
						self.get_model_local().insert_multiple_obj(self.get_product_table_name(), values)
						values = []

				if values:
					total_product += len(values)
					self.get_model_local().insert_multiple_obj(self.get_product_table_name(), values)
		except Exception as e:
			self.log_traceback()
			return Response().error()
		return Response().success(total_product)


		pass
	def set_order_max_last_modifier(self, last_modifier):
		"""set max last modifier
		input can be: timestamp or date with timezone
		sub 12 hours because the delayed
		"""
		time_format = '%Y-%m-%dT%H:%M:%SZ'
		if 'Z' in to_str(last_modifier):
			last_modifier_timestamp = to_timestamp(last_modifier, time_format, limit_len = False)
		else:
			last_modifier_timestamp = to_int(last_modifier) // 1000
			last_modifier = datetime.fromtimestamp(last_modifier_timestamp).strftime(time_format)

		if last_modifier:
			twelve_hour_stamp = 43200
			last_modifier_sub_12 = last_modifier_timestamp - twelve_hour_stamp

			if not self._order_max_last_modified or last_modifier_sub_12 > to_timestamp(self._order_max_last_modified, time_format, limit_len = False):
				last_modifier_sub_12 = datetime.fromtimestamp(last_modifier_sub_12).strftime(time_format)
				self._order_max_last_modified = last_modifier_sub_12

	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear

	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		# try:
		# 	api_delete_categories = self.api('/categories', None, 'Delete', version = 2)
		# except Exception:
		# 	self.log_traceback()
		# 	return next_clear
		return next_clear

	def clear_channel_products(self):
		# TODO: write function
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			api_delete_pro = self.api('/products', None, 'Delete')
			api_delete_options = self.api('/options', None, 'Delete')
			api_delete_opt_set = self.api('/option_sets', None, 'Delete')
			res = self.api('/brands', None, 'Delete')
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear

	def get_category_by_id(self, category_id):
		return Response().success()

	def get_categories_main_export(self):
		return Response().success()

	def get_categories_ext_export(self, categories):
		return Response().success()

	def convert_category_export(self, category, categories_ext):
		return Response().success()

	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']

	def product_export_is_finish(self) -> bool:
		return bool(self._offset >= self.get_state_pull_product_total_view())

	def recall_get_items(self, product_filter_condition) -> (dict, dict):
		"""Walmart sometimes responds with empty items
		Recall this call, Walmart will return items
		"""
		repeat, max_repeat = 0, 10
		products_response, products_data = dict(), dict()
		while repeat < max_repeat and not products_data:
			repeat += 1
			time.sleep(repeat * 3)
			products_response = self.api('items', data = product_filter_condition)
			if products_response.result != Response.SUCCESS:
				break

			products_data = products_response.data.get('ItemResponse')

		return products_response, products_data

	def escape_reversed_character_url(self, line: str) -> str:
		"""escape product sku have reversed character like:
		#codisto-934, #codisto-39"""
		if not isinstance(line, str):
			line = to_str(line)

		return urllib.parse.quote(line).replace('/', '%2F')

	def get_product_by_report(self):
		limit_data = self._state.pull.setting.products
		lifecycle_status = [(to_str(self._request_data.get('walmart_status')) or self._WALMART_STATUS['active']).upper()]
		query = (
			f'SELECT * FROM `{self.get_product_table_name()}`'
			f' WHERE `solved` != -1'
			f' AND `lifecycle_status` in {self.get_model_local().list_to_in_condition(lifecycle_status)}'
			f' AND `id` > {self._table_product_id}'
			f' ORDER BY `id` LIMIT {limit_data}'
		)
		products_query = self.get_model_local().select_raw(query)
		if products_query.result != Response.SUCCESS or not products_query.data:
			return Response().finish()

		try:
			products_data = self.convert_table_data_to_api_data(products_query.data)
		except Exception as e:
			self.log_traceback()
			return Response().error(msg = 'Could\'t get product report')

		self._table_product_id = products_query.data[-1]['id']
		return Response().success(data = products_data)

	def get_product_by_api(self):
		product_filter_condition = {
			'includeDetails': True,
			'limit': self._state.pull.setting.products,
			'offset': self._offset,
			'lifecycleStatus': (
					to_str(self._request_data.get('walmart_status'))
					or self._WALMART_STATUS['active']
			).upper()
		}

		products, products_data = self.recall_get_items(product_filter_condition)
		if products.result != Response.SUCCESS or not products_data:
			if isinstance(products.data.get('totalItems', ''), int):
				self._flag_finish_get = True
			return Response().error(msg = "Could not get Product data from Walmart")

		self.log_response(products, 'get_products_main_export')
		if products.data.get('error', {}).get('code') == 'CONTENT_NOT_FOUND.GMP_ITEM_QUERY_API':
			self._state.pull.process.products.imported = self.get_state_pull_product_total_view()
			self._flag_finish_get = True
			return Response().finish()

		return Response().success(data = products_data)

	def convert_table_data_to_api_data(self, table_data_list):
		def get_inventory(sku_):
			inventory_response = self.api('inventory', data = {"sku": sku_})
			if (
					isinstance(inventory_response.data.get('quantity'), dict)
					and inventory_response.data['quantity'].get('amount')
			):
				
				return to_int(inventory_response.data['quantity']['amount'])
			return 0

		api_product_list = []
		for p_t in table_data_list:
			product = {
					'mart': 'WALMART_US',
					'sku': p_t.get('sku'),
					'wpid': p_t.get('wpid'),
					'upc': p_t.get('upc') or '',
					'gtin': p_t.get('gtin') or '',
					'productName': p_t.get('product_name', ''),
					'shelf': p_t.get('shelf_name'),
					'productType': '',
					'price': {
						'currency': p_t.get('currency'),
						'amount': to_decimal(p_t.get('price'))
					},
					'unpublishedReasons': {
						'reason': p_t.get('status_change_reason') or ''
					},
					'publishedStatus': p_t.get('publish_status'),
					'lifecycleStatus': p_t.get('lifecycle_status'),
					'extend_data_table': {
						'inventory': get_inventory(p_t.get('sku')),
						'data_search': {
							'brand': p_t.get('brand'),
							'description': ' ',
							'type': '',
							'wm_itemid': p_t.get('item_id') or '',
							'list_images': (
								[Prodict(url = p_t.get('primary_image_url'))]
								if p_t.get('primary_image_url')
								else [Prodict(url = '')]
							),
							'attribute_on_walmart': {}
						},
						'data_category': {},
						'data_insight': {}
					},
					'solved': to_int(p_t.get('solved')),
					'table_id': to_int(p_t['id'])
				}

			if p_t.get('variant_group_id'):
				variant_attribute_zip = [
					to_str(p_t.get('variant_grouping_attributes')).split(','),
					to_str(p_t.get('variant_grouping_values')).split(',')
				]
				group_atr = [
					{'name': atr_name, 'value': atr_val}
					for atr_name, atr_val in zip(*variant_attribute_zip)
				]
				product.update(
					{
						'variantGroupId': p_t.get('variant_group_id'),
						'variantGroupInfo': {
							'isPrimary': bool(p_t.get('primary_variant') == 'Y'),
							'groupingAttributes': group_atr
						}
					}
				)
			# TODO: qty, category name
			api_product_list.append(Prodict.from_dict(product))

		return api_product_list

	def get_products_main_export(self) -> Prodict:
		if self._flag_finish_get:
			return Response().finish()

		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0

		if self.is_use_get_item_report():
			product_report = self.get_product_by_report()
			if product_report.result == Response.SUCCESS:
				products_data = product_report.data
			else:
				return product_report

		else:
			product_api = self.get_product_by_api()
			if product_api.result == Response.SUCCESS:
				products_data = product_api.data
			else:
				return product_api

		self._offset += self._state.pull.setting.products
		if self.product_export_is_finish():
			self._flag_finish_get = True

		return Response().success(data = products_data)

	def log_response(self, log_data, log_name: str) -> None:
		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			self.log(log_data, log_name)

	def get_product_by_updated_at(self):
		# log warningpass
		return Response().success()

	def clean_url_image(self, image_url: str) -> str:
		"""remove the params in an image URL"""
		return image_url.split('?')[0]

	def _get_category_template(self, category_name: str = '') -> Prodict:
		category_path_api = dict()
		try:
			category_id = self.TEMPLATE_ID.get(category_name, '')
			type_search = 'category/{}/attributes'.format(category_id)
			category_path_api = self.get_category_path(channel_type = 'walmart', type_search = type_search, params = '')
		except Exception as e:
			err = f'Error category name: `{category_name}` not found in category list or {e} exception.'
			self.log(err, 'exception_get_category_template')
			log_traceback()

		# func `get_category_path` return False if not found category
		result = Prodict.from_dict(category_path_api) if category_path_api else Prodict()
		return result

	def _get_data_walmart_search(self, product: dict) -> dict:
		def get_product_search(item) -> dict:
			nonlocal product_data
			nonlocal is_searched
			if not item:
				return {}

			is_searched = True
			list_images = list(set([self.clean_url_image(image['url']) for image in item['images']]))
			product_data['list_images'] = [Prodict(url = img) for img in list_images] or list()
			product_data['description'] = item.get('description')
			product_data['brand'] = item.get('brand')
			product_data['product_type'] = item.get('productType')
			product_data['wm_itemid'] = item.get('itemId', '').replace('var_', '')

			return product_data

		def check_product_id(item_id: str) -> bool:
			nonlocal product
			params = {
				'productIdType': 'ITEM_ID'
			}
			item_response = self.api(f'items/{self.escape_reversed_character_url(item_id)}', data = params)
			if item_response.result != Response.SUCCESS \
				or not item_response.data.get('totalItems'):
				return False

			if item_response.data['ItemResponse'][0]['wpid'] != product['wpid']:
				return False

			return True

		def validate_top_search() -> dict:
			"""validate product"""
			nonlocal search
			nonlocal response
			MAX_PRODUCT = 1
			try:
				items_list: list = response.data.get('items', [])

			except (KeyError, IndexError, AttributeError):
				items_list = []

			total_check: int = min(len(items_list), MAX_PRODUCT)
			for idx, item in enumerate(items_list):
				if idx > total_check:
					break

				if check_product_id(item.get('itemId')):
					return item

			return {}

		search_params = [
			{'type': 'gtin', 'param': 'gtin'},
			# {'type': 'upc', 'param': 'upc'},
			{'type': 'productName', 'param': 'query'},
		]
		product_data = Prodict()
		product_data['list_images'] = list()
		product_data['description'] = ''
		product_data['brand'] = ''
		product_data['product_type'] = ''
		product_data['wm_itemid'] = ''
		is_searched = False
		for search in search_params:
			if not product.get(search['type']) or is_searched:
				break

			params = {
				search['param']: product[search['type']]
			}
			response = self.api(path = 'items/walmart/search', data = params)
			if response.result != Response.SUCCESS:
				continue

			item_validated = validate_top_search()
			product_data = get_product_search(item_validated)

		return product_data

	def _get_data_walmart_insight(self, product: Prodict) -> Prodict:
		params = {
			"query": {
				'field': 'sku',
				'value': product.sku
			}
		}

		response = self.api(path = 'insights/items/listingQuality/items', data = params, api_type = 'post')
		if response.result != Response.SUCCESS or not response.get('data').get('payload', [{}])[0]:
			return Prodict()

		data_res = response.data.payload[0]

		category_name = data_res.get('categoryName')
		# wpid = data_res.get('productId')
		# wm_itemid = data_res.get('itemId')
		sku = data_res.get('sku')
		product_type = data_res.get('productType')

		# we have 2 type of attribute, the attributes from the category schema and the recommended attributes
		atr_spec = list()
		atr_recommended = list()

		for atr in data_res.get('scoreDetails', {}).get('contentAndDiscoverability', {}).get('issues', []):
			atr_append = {
				'name': atr.get('attributeName'),
				'value': atr.get('attributeValue'),
				'score': atr.get('score')
			}

			if atr['isSpecAttribute']:
				atr_spec.append(atr_append)
			else:
				atr_recommended.append(atr_append)

		data_insight = {
			'category_name': category_name,
			'sku': sku,
			'product_type': product_type,
			'attributes': {
				'specific': atr_spec,
				'recommended': atr_recommended
			}
		}

		return Prodict.from_dict(data_insight)

	def get_products_ext_export(self, products) -> Response:
		"""Skip product_ext before check product is in warehouse
		Get product_ext in `convert_product_export`
		"""
		return Response().success()

	def after_get_products_ext_export(self, products: List[Prodict]) -> Prodict:
		"""get product_ext in walmart: qty, images, insight"""
		try:
			extend = self.get_products_ext_export_(products)

		except:
			log_traceback()
			return Response().error(code = 2201)

		return extend

	def get_products_ext_export_(self, products: List[Prodict]) -> Prodict:
		"""
		Func get `inventory`, `image`, `shortDescription`
		Get data from two endpoint: `inventory` and `walmart_search`
		Get data from the insight endpoint, Walmart score product quality. Need to wait 24 hours for new product
		"""
		extend = Prodict()
		# product_filter_condition = {
		# 	'productIdType': 'SKU'
		# }

		for product in products:
			extend.set_attribute(product.sku, Prodict())
			# if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			# 	extend[to_str(product.sku)].inventory = 0
			# 	continue

			inventory_response = self.api('inventory', data = {"sku": product.sku})
			if inventory_response.result != Response.SUCCESS or inventory_response.data.get("error"):
				extend[to_str(product.sku)].inventory = 0
			else:
				extend[to_str(product.sku)].inventory = inventory_response.data.get('quantity', {}).get('amount', 0)

			data_search = self._get_data_walmart_search(product)
			if any([val for val in data_search.values()]):
				extend[to_str(product.sku)].data_search = data_search

			data_insight = self._get_data_walmart_insight(product)
			if not data_insight:
				continue

			data_category = self._get_category_template(data_insight.get('category_name'))

			extend[to_str(product.sku)].data_insight = data_insight
			extend[to_str(product.sku)].data_category = data_category

		return Response().success(extend)

	def channel_sync_inventory(self, product_id, product: Product, products_ext):
		"""
		self.set_update_product_mode(True)
		self.set_update_price_mode(True)

		if self._state.channel.config.setting.get('price', {}).get('status') == 'disable':
			self.set_update_price_mode(False)
		if self._state.channel.config.setting.get('qty', {}).get('status') == 'disable':
			self.set_update_qty_mode(False)
		"""
		if self.is_setting_sync_qty():
			self._update_qty = True

		if self.is_setting_sync_price():
			self._update_price = True

		if not product.variants:
			product['sku'] = self.validate_product_sku(product['sku'])
			self.cache_products.append(product)

		else:
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			for variant in product.variants:
				self.parent_variants[product['_id']].append(variant['_id'])
				variant['sku'] = self.validate_product_sku(variant['sku'])
				self.cache_products.append(variant)

		return Response().success(product)

	def channel_sync_inventory_simple_product(self, product_sku, product: Product):
		# setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		# setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		# if not (setting_price and setting_qty):
		# 	return Response().success()
		#
		pass

	def get_product_id_import(self, convert: Product, product, products_ext):
		self._convert_product = dict()
		convert_product = self._convert_product_export(product, products_ext)
		if convert_product.result == Response.SUCCESS:
			self._convert_product = convert_product.data
			return convert_product.data.id
		elif convert_product.result == Response.SKIP:
			self._convert_product = 'skip'
			return product.get('variantGroupId')
		return product.wpid

	def get_product_main_export(self, product_id, main_product = False):
		"""sync_product_from_channel"""
		product_channel_id = product_id
		product = self.get_model_catalog().get(product_id, ['channel'])
		field_check = 'channel_{}'.format(self._state.channel.id)
		if not product or not product['channel'].get(field_check):
			return Response().finish()

		gtin_id = product['channel'][field_check].get('gtin')
		sku_id = product['channel'][field_check].get('sku')
		product_ids = OrderedDict([
			('GTIN', gtin_id),
			('SKU', sku_id),
		])
		product_channel = Response().finish()
		for id_type, product_channel_id in product_ids.items():
			if not product_channel_id or product_channel_id == '__empty__':
				continue
			product_channel = self.get_product_by_id(product_channel_id, id_type)
			if product_channel.get('data'):
				break

		return product_channel

	def get_product_by_id(self, product_id: str, id_type: str = 'SKU', max_retry: int = 5) -> Response:
		"""
		get the product update from walmart
		endpoint get items/id sometimes return empty but the product still active.
		retry to get the product
		"""
		params = {
			'productIdType': id_type,
			'includeDetails': 'true'
		}
		product_request = dict()
		retry = 0
		while retry < max_retry:
			product_request = self.api(f'items/{self.escape_reversed_character_url(product_id)}', data = params)
			if product_request.result != Response.SUCCESS:
				if product_request.code:
					return Response().error(code = product_request.code)
				return Response().error(code = Errors.WALMART_GET_PRODUCT_FAIL)

			if product_request.data.get('ItemResponse'):
				break

			retry += 1
			time.sleep(retry * 2)

		try:
			data = product_request.data['ItemResponse'][0]

		except:
			data = ''

		return Response().success(data = data)

	def _get_variants_by_variant_group_id(self, product: Prodict, variant_group_id) -> Prodict:
		"""
		get the variants from the variant_group_id
		1. get the list of products by variant_group_id
		2. remove the primary variant because duplicate
		3. mapping attribute
		"""
		def get_variant_response():
			nonlocal variant_list
			nonlocal variant_list_res
			nonlocal next_cursor
			params = {
				'includeDetails': True,
				'limit': 50,
				'variantGroupId': variant_group_id
			}

			retry_ = 0
			MAX_RETRY = 3
			while True or retry_ < MAX_RETRY:
				variant_response = self.api('items', data = params)
				if variant_response.result != Response.SUCCESS:
					break

				if not variant_response.data.get('ItemResponse'):
					retry_ += 1
					time.sleep(retry_ * 5)
					continue

				variant_response_data = variant_response.data.get('ItemResponse')
				if variant_response and isinstance(variant_response_data, list):
					variant_list_res += variant_response_data

				if variant_response.data.get('nextCursor'):
					next_cursor = variant_response.data.get('nextCursor')

				if next_cursor:
					params['nextCursor'] = next_cursor
				else:
					break

		def get_extend_data():
			nonlocal variant_list_res
			nonlocal extend

			get_products_export = self.after_get_products_ext_export(variant_list_res)
			if get_products_export.result != Response.SUCCESS:
				extend = {}
			extend = get_products_export.data
			return extend

		def convert_variant():
			nonlocal qty_total
			nonlocal variant_list
			for variant in variant_list_res:
				variant_data = ProductVariant()

				variant_data.qty = extend[to_str(variant.sku)].inventory
				variant_data.is_in_stock = bool(variant_data.qty > 0)
				qty_total += to_int(variant_data.qty)

				variant_data.name = variant.productName
				variant_data.lower_name = variant.productName.lower()
				variant_data.id = variant.get('wpid', '')
				variant_data.sku = variant.get('sku', '')
				variant_data.upc = variant.get('upc', '')
				variant_data.gtin = variant.get('gtin', '')
				variant_data.type = variant.productType
				variant_data.is_primary = True if variant.get('variantGroupInfo', {}).get('isPrimary') else False
				variant_data.manage_stock = True
				variant_data.price = to_decimal(variant.price.get('amount', 0), 2)

				variant_data.brand = extend.get(variant.sku, {}).get('data_search', {}).get('brand', '')
				variant_data.description = extend.get(variant.sku, {}).get('data_search', {}).get('description', '')
				variant_data.type = extend.get(variant.sku, {}).get('data_search', {}).get('brand', '')
				variant_data.wm_itemid = extend.get(variant.sku, {}).get('data_search', {}).get('wm_itemid', '')
				extend_image = extend.get(variant.sku, {}).get('data_search', {}).get('list_images', '') or list()
				if extend_image:
					variant_data.thumb_image.url = extend_image[0].get('url', '')
					variant_data.images = extend_image

				channel_data = Prodict()
				channel_data['wm_itemid'] = extend.get(variant.sku, {}).get('data_search', {}).get('wm_itemid', '')
				channel_data['wpid'] = variant.get('wpid', '')
				channel_data['variant_group_id'] = variant.get('variantGroupId', '')
				channel_data['attribute_on_walmart'] = self._get_attributes_from_walmart(variant, extend)
				channel_data['template_data'] = Prodict()
				channel_data['template_data']['category'] = self.get_category_template(channel_data)
				variant_data.channel_data = channel_data

				for variant_wal in variant.variantGroupInfo.groupingAttributes:
					variant_attribute = ProductVariantAttribute()
					variant_attribute.attribute_type = 'select'
					variant_attribute.attribute_name = self.convert_atr_walmart_name_res(variant_wal.name)
					variant_attribute.attribute_value_name = variant_wal.value

					variant_data.attributes.append(variant_attribute)

				variant_list.append(variant_data)

			return True

		variant_list = list()
		variant_list_res = list()
		next_cursor = ''
		extend = Prodict()
		qty_total = 0

		if self.is_use_get_item_report():
			variant_list_res = self.get_table_variant_group(variant_group_id)
			extend = Prodict.from_dict({
				var['sku']: var.get('extend_data_table', {})
				for var in variant_list_res
			})
			self.update_to_solved(
				[p['table_id'] for p in variant_list_res]
			)
		else:
			get_variant_response()
			if not variant_list_res:
				return Response().error(msg = "Can't get variants of the product name: {}".format(product.get('productName', '')))

			get_extend_data()

		try:
			convert_variant()
		except:
			self.log_traceback()
			variant_list = []
			qty_total = 0

		# Product variant
		return Response().success(data = {'variant_list': variant_list, 'variants_qty': qty_total})

	def _convert_refresh_product(self, product: Prodict, products_ext) -> Prodict:
		product_data = Product()
		product_data.name = product.get('productName', '')
		product_data.lower_name = product.get('productName', '').lower()
		product_data.sku = product.get('sku')
		product_data.upc = product.get('upc')
		product_data.gtin = product.get('gtin')
		product_data.price = product.get('price', {}).get('amount', 0)
		product_data.type = product.get('productType')
		product_data.status = True if product.publishedStatus == 'PUBLISHED' else False
		shelf = self.get_product_shelf(product.get('shelf'))
		for department in shelf:
			if department in ['Home Page', 'UNNAV']:
				continue
			if department not in product_data.category_name_list:
				product_data.category_name_list.append(department)

		product_data.category_lower_name = [cat.lower() for cat in product_data.category_name_list]

		product_data.qty = 0  # The parent product is a variant product
		product_data.is_in_stock = product_data.qty > 0
		product_data.brand = products_ext.get(product.sku, {}).get('data_search', {}).get('brand', '')
		product_data.description = products_ext.get(product.sku, {}).get('data_search', {}).get('description', '')
		product_data.type = products_ext.get(product.sku, {}).get('data_search', {}).get('brand', '')
		product_data.wm_itemid = products_ext.get(product.sku, {}).get('data_search', {}).get('wm_itemid', '')
		product_data.images = products_ext.get(product.sku, {}).get('data_search', {}).get('list_images', '') or list()

		product_data.allow_update = 'wm_itemid,name,lower_name,sku,upc,gtin,price,type,status,qty,is_in_stock'

		if product.get('variantGroupId'):
			pass

		if product.get('variantGroupInfo'):
			pass

		return product_data

	def _get_attributes_from_walmart(self, product: Prodict, products_ext: Prodict) -> Prodict:
		"""
		0. check if get category template and data insight
		1. convert to right type from template
		"""

		def get_attribute_type(atr_name_) -> str:
			atr_type_ = ''
			for atr_k, atr_v in data_category.get('properties', {}).items():
				if atr_name_ == atr_k:
					atr_type_ = atr_v['type']

			return atr_type_

		def get_pull_variant_attributes():
			nonlocal variant_attributes_name, variant_attributes
			if product.get('variantGroupInfo', {}).get('groupingAttributes', []):
				variant_attributes_name = [atr.name for atr in product.variantGroupInfo.groupingAttributes]
				variant_attributes = product.variantGroupInfo.groupingAttributes

		def get_attributes_from_data_insight():
			nonlocal attribute_convert
			for attribute_ in data_insight.get('attributes', {}).get('specific', []):
				if attribute_.name in (skip_attributes and variant_attributes_name):
					continue

				atr_name_ = self.convert_atr_walmart_name_res(attribute_.name)
				atr_type_ = get_attribute_type(atr_name_)

				# not convert object because we missed information attribute
				# if not found atr_type mean the attribute is not the category template
				# attribute.value have None is recommended attribute from Walmart
				if atr_type_ == 'object' or not atr_type_ or not attribute_.value:
					continue

				convert_ = {
					'value': attribute_.value,
					'type': atr_type_
				}
				atr_value_ = self.convert_catalog_value_type(status_changed = True, specific = convert_)
				attribute_convert.append({
					'name': atr_name_,
					'type': atr_type_,
					'value': atr_value_
				})

		def get_variant_attributes():
			nonlocal attribute_convert
			if variant_attributes_name:
				variant_list = [self.convert_atr_walmart_name_res(var_name) for var_name in variant_attributes_name]
				attribute_convert.append({
					'name': 'variantAttributeNames',
					'type': 'array',
					'value': variant_list
				})

			for attribute in variant_attributes:
				atr_name = self.convert_atr_walmart_name_res(attribute.name)
				atr_type = get_attribute_type(atr_name)
				if atr_type == 'object' or not atr_type or not attribute.value:
					continue

				convert = {
					'value': attribute.value,
					'type': atr_type
				}

				atr_value = self.convert_catalog_value_type(status_changed = True, specific = convert)
				attribute_convert.append({
					'name': atr_name,
					'type': atr_type,
					'value': atr_value
				})

		def get_category_data():
			category_name = data_insight.get('category_name')
			template_required = self._get_category_template(category_name)
			return template_required

		"""get attributes and format required from walmart insight"""
		data_insight = products_ext.get(product.sku, {}).get('data_insight', Prodict())
		data_category = products_ext.get(product.sku, {}).get('data_category', Prodict())
		if not (data_category and data_insight):
			return Prodict()

		attribute_convert = list()
		variant_attributes_name = []
		variant_attributes = []
		skip_attributes = ['product_name', 'images']
		# category_required = get_category_data()

		get_pull_variant_attributes()
		get_attributes_from_data_insight()
		result = {
			data_insight.get('category_name'): attribute_convert  # mutable list, append if have var atr
		}
		get_variant_attributes()

		return Prodict.from_dict(result)

	def get_category_template(self, channel_data) -> dict:
		"""get category name and value from attribute_on_walmart
		before use attribute_on_walmart when pull product
		but use template.category for showing on UI
		"""
		if not channel_data or not channel_data['attribute_on_walmart']:
			return {}

		try:
			category_name = list(channel_data['attribute_on_walmart'].keys())[0]
			# template_required = self._get_category_template(category_name)
			attrs_walmart = list(channel_data['attribute_on_walmart'].values())[0]

		except Exception as e:
			self.log(f'channel_data: {channel_data}', 'get_category_template_pull')
			return {}

		id_category = self.TEMPLATE_ID.get(category_name, '')
		specifics = [
			{
				'name': atr['name'],
				'type': atr['type'],
				'override': atr['value'],
				'mapping': '',
				'value': atr['value']

			}
			for atr in attrs_walmart
		]
		category_template = {
			"category": {
				"id_category": id_category,
				"name": category_name
			},
			"default": False,
			"specifics": specifics
		}

		return category_template

	def get_product_shelf(self, product_shelf_raw: Any) -> list:
		if not product_shelf_raw:
			return []

		product_shelf = to_str(product_shelf_raw)
		try:
			shelf = literal_eval(product_shelf)
		except ValueError:
			shelf = []
		except SyntaxError:
			# random item has the special case
			# "Home Page/Sports & Outdoors/Outdoor Sports/Camping Gear"
			if product_shelf.find('/') != -1:
				shelf = product_shelf.split('/')
			else:
				shelf = []
		except:
			log_traceback()
			shelf = []

		return shelf if isinstance(shelf, list) else []

	def update_to_solved(self, solved_ids):
		if not isinstance(solved_ids, list):
			solved_ids = [solved_ids]

		query = (f"UPDATE {self.get_product_table_name()}"
		         f" SET solved = 1 WHERE id"
		         f" IN {self.get_model_local().list_to_in_condition(solved_ids)}")
		self.get_model_local().query_raw(query)


	def get_table_variant_group(self, group_id):
		query = (
			f'SELECT * FROM `{self.get_product_table_name()}`'
			f' WHERE `variant_group_id` = "{group_id}"'
		)
		products_query = self.get_model_local().select_raw(query)
		if products_query.result != Response.SUCCESS or not products_query.data:
			return []

		try:
			return self.convert_table_data_to_api_data(products_query.data)
		except:
			self.log_traceback()
			return []

	def _convert_product_export(self, product: Prodict, products_ext: Prodict) -> Prodict:
		"""
		`Pull product flow`
		`Update from Walmart`: select by _update_product -
		update only the specific fields, WM not response all data
		"""

		def get_walmart_status() -> str:
			"""check `lifecycleStatus` and `published`
			"""
			nonlocal product
			walmart_status = to_str(product.lifecycleStatus).lower() or self._WALMART_STATUS['active']
			if walmart_status == self._WALMART_STATUS['active'] and product.publishedStatus == 'UNPUBLISHED':
				walmart_status = self._WALMART_STATUS['unpublished']

			return walmart_status

		def get_unpublished_reason() -> str:
			"""get unpublished reason from walmart"""
			nonlocal product, channel_data
			reasons = ''
			if not channel_data.get('walmart_status') == self._WALMART_STATUS['unpublished']:
				return reasons

			try:
				reasons = product.get('unpublishedReasons', {}).get('reason') or ''
				if reasons and isinstance(reasons, list):
					reasons = reasons[0]

			except:
				reasons = ''

			return reasons

		if to_int(product.get('solved')) == 1:
			return Response().skip()

		if self._convert_product:
			if self._convert_product == 'skip':
				return Response().skip()
			return Response().success(self._convert_product)
		if not self._update_product_flow and not self.is_refresh_product():
			# check if the product is already in the warehouse, get the variants by variantGroupId
			if product.get('variantGroupId') and self.get_product_warehouse_map(product.get('variantGroupId')):
				return Response().skip()

		if self.is_use_get_item_report() and product.get('extend_data_table'):
			products_ext = Prodict.from_dict(
				{product['sku']: product['extend_data_table']}
			)
			# TODO: check solved
			# TODO: marked solved for updated
		else:
			products_ext = self.after_get_products_ext_export([product]).data

		product_data = Product()
		product_data.name = product.get('productName', '')
		product_data.lower_name = product_data.name.lower()
		product_data.id = product.get('wpid', '')
		product_data.sku = product.get('sku', '')
		product_data.upc = product.get('upc', '')
		product_data.gtin = product.get('gtin', '')
		product_data.type = product.get('productType', '')

		# The status of an item when the item is in the submission process.
		# The status can be one of the following:
		# PUBLISHED, READY_TO_PUBLISH, IN_PROGRESS, UNPUBLISHED, STAGE, or SYSTEM_PROBLEM.

		product_data.status = bool(product.publishedStatus == 'PUBLISHED')
		product_data.price = product.get('price', {}).get('amount', 0) or 0
		shelf = self.get_product_shelf(product.get('shelf'))

		for department in shelf:
			if department in ['Home Page', 'UNNAV']:
				continue

			if department not in product_data.category_name_list:
				product_data.category_name_list.append(department)
		product_data.category_lower_name = [cat.lower() for cat in product_data.category_name_list]

		variant_group_id = product.get('variantGroupId') or ''
		variant_group: Prodict = product.get('variantGroupInfo') or Prodict()

		product_inventory = to_int(products_ext.get(product.sku).get('inventory', 0)
		                           if isinstance(products_ext.get(product.sku), dict) else 0)
		product_data.qty = product_inventory
		product_data.is_in_stock = product_inventory > 0

		if products_ext.get(product.sku, {}).get('data_search'):
			product_data_search = products_ext.get(product.sku, {}).get('data_search', {})
			product_data.brand = product_data_search.get('brand', '')
			product_data.description = product_data_search.get('description', '')
			product_data.type = product_data_search.get('productType', '')
			product_data.wm_itemid = product_data_search.get('wm_itemid', '')

			images_list = product_data_search.get('list_images', [{}])
			product_data.thumb_image.url = images_list[0].get('url')
			product_data.images = [image for image in images_list[1:]]

		channel_data = Prodict()
		channel_data['wpid'] = product.get('wpid', '') or ''
		channel_data['wm_itemid'] = products_ext.get(product.sku, {}).get('data_search', {}).get('wm_itemid', '') or ''
		channel_data['variant_group_id'] = variant_group_id
		channel_data['primary_variant_on_walmart'] = product.get('variantGroupInfo', {}).get('isPrimary', '')
		channel_data['attribute_on_walmart'] = self._get_attributes_from_walmart(product, products_ext)
		channel_data['walmart_status'] = get_walmart_status()
		channel_data['unpublished_reason'] = get_unpublished_reason()
		channel_data['template_data'] = Prodict()
		channel_data['template_data']['category'] = self.get_category_template(channel_data)
		product_data.channel_data = channel_data

		if variant_group:
			for attribute_wal in variant_group.groupingAttributes:
				attribute = ProductAttribute()
				attribute.attribute_type = 'select'
				attribute.attribute_name = self.convert_atr_walmart_name_res(attribute_wal.name)
				attribute.attribute_value_name = attribute_wal.value
				product_data.attributes.append(attribute)

		# get the variants product
		if variant_group_id:
			product_data.id = variant_group_id
			variant_request = self._get_variants_by_variant_group_id(product, variant_group_id)
			if variant_request.result == Response.SUCCESS:
				product_data.qty = variant_request.data.get('variants_qty', 0)
				product_data.variants = variant_request.data.get('variant_list')

		if product_data.qty:
			product_data.is_in_stock = True

		if self.is_use_get_item_report():
			self.update_to_solved(product['table_id'])
		self.log_response(product_data, 'product_data_convert_export')
		return Response().success(product_data)

	@staticmethod
	def random_sku(length = 20) -> str:
		chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
		return ''.join(random.choice(chars) for _ in range(length))

	def get_category_id_by_name(self, category_name):
		pass

	def get_brand_id_by_name(self, brand_name):
		pass

	# https://stackoverflow.com/questions/28425705/python-round-a-float-to-nearest-0-05-or-to-multiple-of-another-float
	def round_to_multiple(self, x: float, a: float = 1) -> float:
		try:
			number_type = ['int', 'float']
			if type(x).__name__ not in number_type or type(a).__name__ not in number_type:
				self.log(f'The variable x: {x}, or a: {a} in func `round_to_multiple`'
						 f' don\'t have right type')
				x = float(x)
				a = float(a)

			max_frac_digits = 100
			frac_digits = 0
			for i in range(max_frac_digits):
				if round(a, -int(math.floor(math.log10(a))) + i) == a:
					frac_digits = -int(math.floor(math.log10(a))) + i
					break

		except Exception as e:
			self.log_traceback()
			return x

		return round(round(x / a) * a, frac_digits)

	def convert_weight_to_lbs(self, weight_raw, unit):
		POUND = 2.2046226218488
		result = ''
		weight = to_decimal(weight_raw, 4)
		if unit == 'lbs' or unit == 'lb':
			result = weight
		elif unit == 'oz':
			result = weight / 16
		elif unit == 'kg':
			result = weight * POUND
		elif unit == 'g':
			result = weight / 1000 * POUND
		else:
			result = 0
		# Shipping Weight need multipleOf 0.001
		return self.round_to_multiple(result, 0.001)

	def variants_to_walmart_data(self, convert, product, product_ext):
		pass

	def combine_object_attributes_template_2(self, item_specific: List[Prodict]) -> List[Prodict]:
		measure_check = ['_Measure', '_Unit']
		default_atrs = list()
		measure_atrs = list()
		addition_atrs = list()
		for atr in item_specific:
			if any([atr['name'].find(x) != -1 for x in measure_check]): 
				measure_atrs.append(atr)

			elif atr['name'].find('productAttribute') != -1:
				addition_atrs.append(atr)

			else:
				default_atrs.append(atr)

		sorted(measure_atrs, key = lambda k: k['name'])
		for idx, atr in enumerate(measure_atrs):
			if atr['name'].find('_Measure') != -1:
				atr_name = atr['name'].split('_Measure')[0]
				if not measure_atrs[idx + 1]['name'] == atr_name + '_Unit':
					continue

				val_idx = idx + 1
				default_atrs.append(Prodict.from_dict({
					'mapping': '',
					'name': atr_name,
					'override': {
						'measure': atr['value'],
						'unit': measure_atrs[val_idx]['value']
					},
					'type': 'object',
					'value': {
						'measure': atr['value'],
						'unit': measure_atrs[val_idx]['value']
					}}))


		return default_atrs

	def combine_object_attributes_template(self, item_specific: List[Prodict]) -> List[Prodict]:
		"""Because we need mapping object attributes.
		We divide the object's properties into parts:
		object -> `object_measure` + `object_unit`
		Func combines parts into the object
		If we missed one of the parts -> skip that object
		"""
		w_check = ['_Measure', '_Unit']
		atr_obj_list = list(filter(lambda atr: any(w in atr['name'] for w in w_check), item_specific))
		default_list = list(filter(lambda atr: (atr not in atr_obj_list), item_specific))
		convert_list = copy.deepcopy(default_list)

		for atr_m in atr_obj_list:
			if atr_m['name'].find('_Measure') != -1:
				atr_name = atr_m['name'].split('_Measure')[0]
				filter_unit = list(filter(lambda atr: (atr['name'] == atr_name + '_Unit'), atr_obj_list))
				if not filter_unit:
					continue
				atr_u = filter_unit[0]
				if atr_u['name'] == atr_name + '_Unit':
					convert_list.append(Prodict.from_dict({
						'mapping': '',
						'name': atr_name,
						'override': {
							'measure': atr_m['value'],
							'unit': atr_u['value']
						},
						'type': 'object',
						'value': {
							'measure': atr_m['value'],
							'unit': atr_u['value']
						}
					}))

		return convert_list

	def convert_template_attributes(self, name_category_template: str, template_attribute_raw: List[Prodict], product_id) -> Prodict:
		"""
		Combine attributes -> validate type -> remove empty attributes

		Template attribute save in string
		attribute value have different types: string, list, object(json)
		Walmart have 5 attributes type: string, array[string - object], number, integer, object
		product_short_description - shortDescription
		product_long_description - longDescription
		"""
		template_attribute: List[Prodict] = self.combine_object_attributes_template(template_attribute_raw)
		# template_attribute_2: List[Prodict] = self.combine_object_attributes_template_2(template_attribute_raw)
		template_convert = []
		if not self._category_template.get(name_category_template):
			self._category_template[name_category_template] = self._get_category_template(name_category_template)

		category_required = self._category_template[name_category_template].get('properties', {})
		for attribute in template_attribute:
			try:
				atr_value = ''
				atr_type = attribute.get('type') or category_required.get(attribute.name).get('type')
				if attribute['name'].find('productIdentifier_') != -1:
					continue

				if attribute.type == '' or attribute.value == '':
					continue

				elif atr_type == 'string':
					enum_list = category_required.get(attribute.name, {}).get('enum', [])
					if not enum_list:
						atr_value = to_str(attribute.value)

					else:
						atr_value = to_str(attribute.value)
						if atr_value not in enum_list:
							atr_value = ''

				elif atr_type == 'number':
					atr_value = to_decimal(attribute.value)

				elif atr_type == 'integer':
					atr_value = to_int(attribute.value)

				elif atr_type == 'object':
					# the object atr has two nested attributes
					# and type can be number, integer, or string
					try:
						atr_convert = attribute.value
						if not isinstance(atr_convert, dict):
							continue

						atr_value = dict()
						item_type = category_required.get(attribute.name, {}).get('properties', {})
						for name, properties in item_type.items():
							if properties['type'] == 'integer':
								atr_value[name] = to_int(atr_convert.get(name, 0))

							elif properties['type'] == 'number':
								atr_value[name] = to_decimal(atr_convert.get(name, 0))

							else:
								atr_value[name] = to_str(atr_convert.get(name, ''))

					except AttributeError:
						continue

				elif atr_type == 'array':
					try:
						# the array attribute has two nested types: object and string
						item_type = category_required.get(attribute.name, {}).get('items').get('type')
						if item_type != 'object' or not item_type:
							atr_value = attribute.value if isinstance(attribute.value, list) else literal_eval(attribute.value)

						else:
							object_type = category_required.get(attribute.name, {}).get('items', {}).get('properties')
							object_type = {k: v['type'] for k, v in object_type.items()}
							atr_value = list()
							for atr in attribute.value:
								item_val = dict()
								for ak, av in atr.items():
									if object_type.get(ak) == 'number':
										val = to_decimal(av)

									elif object_type.get(ak) == 'integer':
										val = to_int(av)

									else:
										val = to_str(av)

									item_val[ak] = val
								atr_value.append(item_val)

					except AttributeError:
						atr_value = attribute.value.split(',') if isinstance(attribute.value, str) else []

				add = Prodict(**{'name': attribute.name, 'value': atr_value})
				template_convert.append(add)

			except:
				msg_error = "Category Template Error: The {}'s value must be a {} value. Please check your category template and try again.".format(attribute.name, attribute.value)
				self.cache_errors[product_id].append(msg_error)
				log_traceback()
				return Response().error(msg = msg_error)

		template_clean: List = self.clean_template_convert(template_convert)

		return Response().success(data = template_clean)

	def clean_template_convert(self, template_convert: List) -> List:
		"""
		Remove empty, null attributes
		Remove empty object dict in list
		TODO: assembled unit, measure missed one
		If the attribute have (unit, measure) but missed one
		"""

		template_convert_copy = copy.deepcopy(template_convert)
		template_clean = []
		for atr in template_convert_copy:
			check = True
			atr_val = atr['value']

			if not atr_val or atr_val == 'null':
				continue

			elif isinstance(atr_val, list) and isinstance(atr_val[0], dict):
				# add atr have both name and value
				try:
					atr_clean = []
					for atr_item in atr_val:
						atr_item_clean = dict()
						for k, v in atr_item.items():
							if k and v:
								atr_item_clean[k] = v
						atr_clean.append(atr_item_clean)
					atr['value'] = atr_clean
				except:
					continue

			elif isinstance(atr_val, list):
				atr['value'] = [atr_ for atr_ in atr_val if atr_.strip()]

			elif isinstance(atr_val, dict):
				for k, v in atr_val.items():
					if not (k and v):
						check = False
						break

			if check:
				template_clean.append(atr)

		return template_clean

	def is_refresh_product(self):
		"""check if the process is updating from walmart"""
		return bool(self.is_sync_product_process)

	def is_update_product_process(self):
		return bool(
			self._process_type == self.PROCESS_TYPE_PRODUCT
			and self._publish_action == 'update'
		)

	def is_product_pull_from_walmart(self, product: Prodict) -> bool:
		# get the product channel source id and check with the current channel id
		check_src = True if product.src.channel_id == self.get_channel_id() else False

		channel_data = product['channel'].get(f'channel_{self.get_channel_id()}', {})

		# if a product has auto_link or user_linked mean product pull from walmart
		# the product linked with a product in the main channel
		check_link = True if channel_data.get('auto_link') or channel_data.get('user_linked') else False

		return check_src or check_link

	def remove_attributes_except_some_tag(self, text: str) -> str:
		"""remove html tag attributes, keep
		tag `a` and `img`"""
		keep_tags = ['a', 'img']
		text_bs = BeautifulSoup(text, features = 'lxml')
		for tag in text_bs.find_all(True):

			if tag.name not in keep_tags:
				tag.attrs = {}

			else:
				attrs = dict(tag.attrs)
				for attr in attrs:

					if attr not in ['src', 'href']:
						del tag.attrs[attr]
		return str(text_bs)

	def validate_product_sku(self, original_sku: str) -> str:
		"""allow character, number, underscore, dash
		remove space, special character"""
		validate_sku = ''.join(char_ for char_ in original_sku
		                       if char_.isalnum() or char_ in ['-', '_'])
		return validate_sku

	def is_clean_description(self) -> bool:
		return bool(super().is_clean_description() or self._state.channel.config.api.description_cut_off)

	def description_cut(self, description: str) -> str:
		if not self.is_clean_description():
			return description

		CHARACTER_LIMIT = 4000
		return self.strip_html_from_description(description)[:CHARACTER_LIMIT]

	def product_to_walmart_data(self, product) -> Prodict:
		def remove_variant_field() -> bool:
			nonlocal visible
			for field_del in visible[name_category].get('variantAttributeNames', []):
				try:
					del visible[name_category][field_del]
				except (KeyError, IndexError):
					continue

			variant_field_list = ['variantGroupId', 'isPrimaryVariant', 'variantAttributeNames']
			for field_del in variant_field_list:
				try:
					del visible[name_category][field_del]
				except (KeyError, IndexError):
					continue

			return True

		def format_product_id() -> str:
			"""Walmart required Product ID digit lengths and verify that the format
			https://sellerhelp.walmart.com/seller/s/guide?language=en_US&article=000007156
			UPC: 12 digit-number
			GTIN: 14 digit-number
			ISBN: 10 or 13 digit-number
			EAN: 13 digit-number
			"""

			nonlocal product_id
			nonlocal product_id_type

			len_required = {
				'UPC': 12,
				'GTIN': 14,
				'EAN': 13
			}
			# if product_id is custom -> return product_id;
			# case: the product without product id
			if product_id.upper().find('CUSTOM') != -1:
				return product_id

			len_id = to_len(product_id)
			len_missed = len_required.get(product_id_type, 0) - len_id
			if len_missed <= 0 or product_id_type == 'ISBN':
				return product_id

			right_format = '0' * len_missed + product_id

			return right_format

		"""Item spec 4.5 - create new items for Walmart only
		https://developer.walmart.com/image/asdp/us/mp/item/spec/4.5/MP_ITEM_SPEC_4.5.json
		1. assign id, upc, sku
		2. get template data
		3. assign data
		"""

		product_id_type = ''
		product_id = ''
		external_product_id = ''
		name_category_pull = ''
		attributes_pull = Prodict()
		template_attributes_category = list()
		for field in self._LIST_PRODUCT_ID_TYPE:
			product_id_type = field.upper()
			product_id = product.get(field)
			if product_id:
				break

		# product can have multi product id
		# case product without product id
		product_id = 'CUSTOM' if not product_id else to_str(product_id)
		product_id = format_product_id()
		if product_id.upper().find('CUSTOM') != -1:
			product_id_type = 'GTIN'

		product_sku = product.sku
		if product.get('asin'):
			external_product_id = product.get('asin')

		if product.variants and product.src.channel_type == 'shopify':
			product_sku += "-parent"
			self._extend_product_map['sku'] = product_sku

		# get attribute from walmart
		# if product pull_from_walmart get attribute_on_walmart
		# product.pull_from_walmart is variable check
		# if have category template -> use category otherwise use attribute_on_walmart
		if product.pull_from_walmart and product.get('attribute_on_walmart', {}):
			name_category_pull, attributes_pull = list(product.attribute_on_walmart.items())[0]

		template_attributes_raw = product.get('template_data', {}).get('category', {}).get('specifics', {})
		name_category_template = product.get('template_data', {}).get('category', {}).get('category', {}).get('name', '')
		if template_attributes_raw:
			convert_template = self.convert_template_attributes(name_category_template, template_attributes_raw, product['_id'])
			if convert_template.result != Response.SUCCESS:
				msg_error = convert_template.get('msg')
				return Response().error(msg = msg_error)

			template_attributes_category = convert_template.data

		name_category = to_str(name_category_template or name_category_pull or self._NOT_FOUND_CATEGORY)
		template_attributes = template_attributes_category or attributes_pull
		NAME_CHARACTER_LIMIT = 200
		orderable = {
			'productName': self.title_cutting(strip_html_tag(product.name), NAME_CHARACTER_LIMIT),
			'sku': product_sku,
			'productIdentifiers': {
				"productIdType": product_id_type,
				"productId": product_id
			},
			'price': self.round_to_multiple(product.price, 0.01) if (product.price and to_decimal(product.price) > 0.000) else 0,
			'ShippingWeight': self.convert_weight_to_lbs(product.weight, product.weight_units)
		}
		# seller reuse the upc code with different sku will exception
		# this upc code already use
		# the feed maintenance not have skuUpdate field
		if not self._update_product_flow and product.get('is_sku_override'):
			orderable['SkuUpdate'] = 'Yes'

		if not self._update_product_flow and product.get('product_id_update'):
			orderable['ProductIdUpdate'] = 'Yes'
			orderable['SkuUpdate'] = 'No'

		# start_date = datetime.now().strftime(self._FORMAT_TIME)
		end_date = (datetime.now() + timedelta(weeks = 260)).strftime(self._FORMAT_TIME)

		# orderable['startDate'] = start_date
		orderable['endDate'] = end_date

		# client can override brand from a category template
		if product.brand:
			orderable['brand'] = product.get('brand')

		if external_product_id:
			orderable['externalProductIdentifier'] = {
				'externalProductIdType': 'ASIN',
				'externalProductId': external_product_id,
			}

		parent_group_id = to_str(product.parent_group_id) if product.parent_group_id else ''
		# variant_group_id get is get from walmart, update product flow
		variant_id = product.get('variant_group_id') or parent_group_id
		visible = {
			name_category: {
				'shortDescription': self.description_cut(
					self.remove_attributes_except_some_tag(product.description)
				),
				'mainImageUrl': product.thumb_image.url,
				'variantGroupId': variant_id,
				'isPrimaryVariant': 'Yes' if product.get('is_primary_variant') else 'No'
			}
		}

		# if self._state.channel.config.api.name_cut_off:
		# 	NAME_CHARACTER_LIMIT = 200
		# 	orderable['productName'] = orderable['productName'][:NAME_CHARACTER_LIMIT]

		# if self.is_clean_description():
		# 	CHARACTER_LIMIT = 4000
		# 	visible[name_category]['shortDescription'] = visible[name_category]['shortDescription'][:CHARACTER_LIMIT]

		# put category attributes or attributes on walmart to product feed
		if template_attributes:
			required_field = ['brand']
			for atr in template_attributes:
				if not atr['value']:
					continue
				# some require field from visible need mapping right
				if atr['name'] in required_field:
					orderable[atr['name']] = atr['value']
					continue
				visible[name_category][atr['name']] = atr['value']

		if not variant_id:
			# remove the variant attributes name and mapping variable attributes
			remove_variant_field()

		# clear product variant
		# get only field can get from visible
		list_variant = []
		for field in visible[name_category].get('variantAttributeNames', []):
			if visible[name_category].get(field):
				list_variant.append(field)

		if list_variant or visible[name_category].get('variantAttributeNames'):
			visible[name_category]['variantAttributeNames'] = list_variant
			if not list_variant:
				del visible[name_category]['variantAttributeNames']

		if product.get('remove_variant_group'):
			visible[name_category]['removeVariantGroup'] = 'Yes'

		if product.images:
			visible[name_category]['productSecondaryImageURL'] = [img['url'] for img in product.images]

		if product.msrp:
			visible[name_category]['msrp'] = self.round_to_multiple(product.msrp, 0.01)

		if not visible[name_category]['shortDescription']:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_DESCRIPTION_IMAGES))
			return Response().error(code = Errors.WALMART_MISSING_DESCRIPTION_IMAGES)

		if not visible[name_category]['mainImageUrl']:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_DESCRIPTION_IMAGES))
			return Response().error(code = Errors.WALMART_MISSING_DESCRIPTION_IMAGES)

		# if not product_id:
		# 	self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_PRODUCT_ID))
		# 	return Response().error(code = Errors.WALMART_MISSING_PRODUCT_ID)

		if not product_sku:
			self.cache_errors[product["_id"]].append(Errors().get_msg_error(Errors.WALMART_MISSING_PRODUCT_SKU))
			return Response().error(code = Errors.WALMART_MISSING_PRODUCT_SKU)

		if not name_category or name_category == self._NOT_FOUND_CATEGORY:
			self.cache_errors[product['_id']].append(Errors().get_msg_error(Errors.WALMART_MISSING_CATEGORY_TEMPLATE))
			return Response().error(code = Errors.WALMART_MISSING_CATEGORY_TEMPLATE)

		product_data = {
			"Orderable": orderable,
			"Visible": visible
		}

		return Response().success(product_data)

	def set_lowest_price_variant_is_primary(self, product) -> int or float:
		price_variant = dict()
		for variant in product.variants:
			price_variant.update(
				{variant.sku: variant.price}
			)
		min_sku, min_price = min(price_variant.items(), key = lambda x: x[0])
		for variant in product.variants:
			variant['is_primary_variant'] = False
			if variant.sku == min_sku:
				variant['is_primary_variant'] = True

		return min_price

	def remove_duplicate_image(self, variant: ProductVariant) -> None:
		"""Remove duplicate images in variant product"""
		image_list: List[ProductImage] = variant.images
		duplicate: Dict[str, list] = dict()
		for idx, img in enumerate(image_list):
			if not duplicate.get(img['url']):
				duplicate[img['url']] = list()

			duplicate[img['url']].append(idx)

		remove_list: List[int] = list()
		for idx_list in duplicate.values():
			if len(idx_list) > 1:
				remove_list.extend(idx_list[1:])

		if not remove_list:
			return None

		try:
			for r in sorted(remove_list, reverse = True):
				del image_list[r]
		except Exception:
			log_traceback()
			log_data = {
				'image_list': image_list,
				'remove_list': remove_list,
			}
			log(log_data, 'walmart', 'remove_duplicate_image')

	def use_parent_image(self, product: Product, variant: ProductVariant, is_already_used: bool) -> None:
		"""use parent thumbnail as main variant images"""
		if self._state.channel.config.api.use_parent_image:
			if not is_already_used:
				variant.images.insert(0, deepcopy(variant.thumb_image))

			variant.thumb_image.url = product.thumb_image.url
			self.remove_duplicate_image(variant)



	def product_import(self, convert, product: Product, products_ext):
		"""get product to add to cache_products
		link the product[_id] to two lists: products don't have variant and products have variants
		if product have variants - link between the parent product and variants
		"""

		def mapping_missing_field_variant_import():
			nonlocal product
			nonlocal variant
			# always get a parent description
			variant['description'] = product['description']
			required_field_list = ['brand', 'weight', 'weight_units', 'images', 'is_sku_override']
			for field in required_field_list:
				check = self.strip_html_from_description(variant.get(field))
				if not check:
					variant[field] = deepcopy(product.get(field))

			is_already_used_parent: bool = False
			if not variant.thumb_image.url:
				variant.thumb_image.url = product.thumb_image.url
				is_already_used_parent = True

			self.use_parent_image(product, variant, is_already_used_parent)
			return True

		product.pull_from_walmart = self.is_product_pull_from_walmart(product)
		if not product.variants:
			product.sku = self.validate_product_sku(product.sku)
			self.cache_products.append(product)
			if product.get('is_sku_override'):
				self._update_product_code = True

		else:
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			# create new variant_group_id, max length 20
			parent_id = ModelChannelsWalmart.random_sku(length = 20)

			# min_price = self.set_lowest_price_variant_is_primary(product)
			min_price_variant = min([variant['price'] for variant in product.variants])
			have_primary = False
			for index, variant in enumerate(product.variants):
				# check = self.get_product_map(variant['_id'])
				# if check:
				# 	continue
				if product.get('is_sku_override'):
					self._update_product_code = True

				variant.sku = self.validate_product_sku(variant.sku)
				variant.pull_from_walmart = product.pull_from_walmart
				# assign the variants with same parent id
				# use group_id but still can use for `old` product
				variant.parent_group_id = product.get('group_id') or parent_id
				# set the variant has the lowest price is the primary variant
				if not have_primary and variant.price == min_price_variant:
					have_primary = True
					variant['is_primary_variant'] = True

				self.parent_variants[product['_id']].append(variant['_id'])
				mapping_missing_field_variant_import()
				for product_attr in product.attributes:
					variant.attributes.append(product_attr)

				self.cache_products.append(variant)

		return Response().success()

	def create_error_message(self, ingestion_err: dict, product_id: str) -> str:
		def replace_field(desc):
			mapping_field_dict = {
				'Qarth': 'Product ID Code',
				'QARTH': 'Product ID Code',
				'Productid': 'Product ID Code',
				'ProductIdentifier': 'Product ID Code',
				'shortDescription': 'Description',
				'lagTime': 'Fulfillment Lag Time',
			}
			for raw, replace_ in mapping_field_dict.items():
				desc = desc.replace(raw, replace_)

			return desc

		if not ingestion_err:
			return ''

		self._feed_has_error = True

		description_raw = to_str(ingestion_err.get('description', ''))
		field = to_str(ingestion_err.get('field', ''))
		description = replace_field(description_raw if not field
		                           else f'{field}: {description_raw}')

		if description.find('The Product ID already exists in your seller catalog') != -1:
			id_type = ''
			product = list(filter(lambda product_: product_['_id'] == product_id, self.cache_products))
			if not product:
				return description

			product = product[0]
			for type_ in self._LIST_PRODUCT_ID_TYPE:
				if product.get(type_):
					id_type = type_
					break

			description = Errors().get_msg_error(Errors.WALMART_PRODUCT_ID_DUPLICATE).format(id_type.upper(), id_type.upper())

		if description.find("Main image URL setup failed.") != -1:
			self._republish_feed = True

		if description.find('invalid check-digit in product ID') != -1:
			try:
				id_type, id_code = re.findall(r'=(\w+),', description)

			except ValueError:
				id_type, id_code = '', ''

			if not (id_type and id_code):
				description.replace('invalid check-digit in product ID', 'The product identifier code is incorrect. Please check the code and try again.')

			else:
				description = f'The {id_type} code: {id_code} is incorrect. Please check the code and try again.'

		elif description.find('It looks like there was a glitch on our end. Please try again. If the problem persists') != -1:
			description = 'It looks like there was a glitch on Walmart end. Please try again. If the problem persists, contact us to support.'

		elif description.find('Please provide the complete information for the attribute') != -1:
			description = description.replace(
				'Please provide the complete information for the attribute:',
				'Please update the complete information for the Additional Product Attributes:'
			)

		elif description.find('Ensure GTINs are 14 digits and UPCs are 12 digits. See https://sellerhelp.walmart.com/s/guide?article=000007156 to troubleshoot.'):
			description.replace(' See https://sellerhelp.walmart.com/s/guide?article=000007156 to troubleshoot.', '')

		elif description.find('This SKU is already set up with a different Product ID (i.e., GTIN, UPC, ISBN, etc.).') != -1:
			description = 'This SKU is already set up with a different Product ID (i.e., GTIN, UPC, ISBN, EAN). Please check and try again.'

		elif description.find('Your item has been flagged by our internal team') != -1:
			description = 'Your item has been flagged by Walmart internal team.\
					To find out why, file a case in <a target="_blank"\
					href="https://sellerhelp.walmart.com/s/contact?language=en_US">\
					Case Management</a>.'

		elif description.lower().find('description') != -1 and description.lower().find('cannot exceed 4000 characters') != -1:
			description = Errors().get_msg_error(Errors.WALMART_DESCRIPTION_LIMIT)

		# if description.find('A promotion already exists with this date range') != -1:
		# 	# TODO: check flag self._feed_has_error
		# 	msg = ''

		return description

	def get_feed_item_report(self, feed_response: Prodict) -> bool:
		"""
		get a list of product successes and fail when pushing the feed
		create error msg
		with a system error, the status of the products did not have sku and id
		-> we can't map the product `sku` and the product `_id`

		# TODO: update error response `system_error`, `timeout_error`
		"""
		def get_success_product_data():
			"""Get data return from walmart"""
			try:
				if not item.get('productIdentifiers', {}) or not item.get('productIdentifiers', {}).get('productIdentifier'):
					return False
			except Exception as e:
				self.log(f'Exception get_success_product_data: {e}, item_data: {item}')
				return False

			product_sku = item.get('sku')
			for product in self.cache_products_insert.values():

				if to_str(product['sku']) != to_str(product_sku):
					continue

				product['sku_update'] = item.get('sku') or ''
				product['wpid'] = item.get('wpid') or ''
				product['wm_itemid'] = item.get('itemid') or ''

				# update the product id from walmart
				product_list = item.get('productIdentifiers', {}).get('productIdentifier') or []
				for id_ in product_list:
					id_name = to_str(id_.get('productIdType')).lower()

					if id_name not in self._LIST_PRODUCT_ID_TYPE:
						continue

					product[id_name] = id_.get('productId') or ''
				break
			return True

		item_list = feed_response.get('itemDetails', {}).get('itemIngestionStatus')

		if not item_list:
			return False

		for item in item_list:
			ingestion_status = item.get('ingestionStatus', '')
			product_id = ''

			if ingestion_status == self.INGESTION['success']:
				get_success_product_data()
				continue

			elif ingestion_status == self.INGESTION['data']:
				product_id = self.cache_products_sku_index.get(item['sku'], {}).get('_id')

			elif ingestion_status == self.INGESTION['system']:
				index_item = item.get('index', '-1')
				if index_item == -1:
					continue

				for val in self.cache_products_sku_index.values():
					if val.get('index') == index_item:
						product_id = val.get('_id')
						break

			if not product_id:
				continue

			try:
				if isinstance(item.get('ingestionErrors'), dict):
					ingestion_errors = item.get('ingestionErrors', {}).get('ingestionError', list())

				else:
					ingestion_errors = list()

			except (KeyError, IndexError, AttributeError):
				ingestion_errors = list()
				log({'item_error': item, 'feed_response': feed_response, 'channel_id': self.get_channel_id()},
				    'walmart',
				    'ingestion_errors')

			msg_error = ''
			for ingestion_err in ingestion_errors:
				msg = self.create_error_message(ingestion_err, product_id)
				if not msg:
					continue

				if msg_error:
					msg_error += " _lic_nl_ " + msg.replace('\n', '')  # \n in react
				else:
					msg_error += msg.replace('\n', '')  # not new line with empty line
			# get first error
			if msg_error:
				try:
					self.cache_errors[product_id].append(to_str(msg_error))  # remove last`_lic_nl_`
				except (KeyError, IndexError, AttributeError):
					log_data = {
						'product_id_error': product_id,
						'cache_product': self.cache_products,
						'cache_product_sku': self.cache_products_sku_index,
						'cache_error': self.cache_errors,
					}
					log(log_data, 'walmart', 'get_feed_item_report')

		return True

	def get_sleep_time(self, recall: int) -> int:
		"""wait time to get a result from walmart
		return the seconds to wait the feed
		"""
		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			return 10
		recall_threshold = 30
		second_ = 60
		return recall * second_ if recall < recall_threshold else 30 * second_

	def check_feed_status(self, response, feed_type = 'item') -> Prodict:
		"""
		Check feed result and update response from walmart
		Flow:
		1. Check feed process and item processing. Feed can be PROCESSED
		but item still processing
		2. Get result for each item
		3. Because the feed limit is 50 products.
		We will need to use `offset` to get all products response
		4. Send data to func `get_product_feed` or response error
		"""
		if response.result != Response.SUCCESS:
			if response.code:
				return Response().error(code = response.code)
			return Response().error(code = Errors.WALMART_PUSH_PRODUCT_ERROR)

		process_status_list = ['RECEIVED', 'INPROGRESS']
		done_status = 'PROCESSED'
		error_status = 'ERROR'
		recall, max_check_round = 0, 40
		offset, limit = 0, 50
		check_item_processing = True
		feed_params = {
			'includeDetails': 'true',
			'offset': offset,
			'limit': limit}
		feed_id = response.data.get('feedId')

		response_feed = self.api('feeds/' + to_str(feed_id), data = feed_params, api_type = 'get')
		feed_status = response_feed.get('data', {}).get('feedStatus', '')

		while (feed_status in process_status_list or check_item_processing) and recall < max_check_round:
			time.sleep(self.get_sleep_time(recall))
			recall += 1

			response_feed = self.api('feeds/' + to_str(feed_id), data = feed_params, api_type = 'get')
			if response_feed.result != Response.SUCCESS:
				feed_status = error_status
				break

			check_item_processing = True if response_feed.data.get('itemsProcessing', 0) != 0 else False
			if response_feed and response_feed.result == Response.SUCCESS:
				feed_status = response_feed.get('data', {}).get('feedStatus', error_status)
			else:
				feed_status = error_status

		# get all item when feed item > 50
		total_items = to_int(response_feed.data.get('itemsReceived', 0))
		offset += limit
		while total_items > offset:
			feed_params.update({'offset': offset})
			res_get = self.api('feeds/' + to_str(feed_id), data = feed_params, api_type = 'get')

			if res_get.result == Response.SUCCESS:
				response_feed.data["itemDetails"]["itemIngestionStatus"] += res_get.data.get('itemDetails', {}).get('itemIngestionStatus', [])

			offset += limit

		if feed_status == done_status:
			feed_item_detail = self.get_feed_item_report(response_feed.data)
			return Response().success()

		elif feed_status == 'ERROR' or not feed_status:
			self.log('The feed submit id {} has problems: {}'.format(feed_id, response_feed.data.get('feedStatus')), 'submit_feed_errors')

		elif feed_status == 'RECEIVED' or feed_status == 'INPROGRESS':
			self.log('The feed submit id {} has been received and processing.'.format(feed_id), 'submit_feed_received')

		return Response().error(code = Errors.WALMART_PUSH_PRODUCT_ERROR)

	def convert_atr_walmart_name_res(self, attribute_response: str) -> str:
		"""The Walmart response variable attributes are not the same as the template attributes

		response_walmart -> template_schema
		actual_color -> color (in the category schema)  # walmart have 2 type of color
		color -> colorCategory (in the category schema)
		material -> material
		age_group -> ageGroup
		manufacture_part_number -> manufacturePartNumber

		convert response_walmart style to template_schema

		"""
		mapping_name = {
			'actual_color': 'color',
			'color': 'color_category',
			'product_short_description': 'short_description',
			'product_long_description': 'long_description',
		}
		if not isinstance(attribute_response, str):
			return attribute_response

		attribute_response = mapping_name.get(attribute_response) if mapping_name.get(attribute_response) else attribute_response
		atr_split_list = attribute_response.split('_')
		atr_split_list[0] = atr_split_list[0].lower()
		if len(atr_split_list) == 1:
			return atr_split_list[0]

		for num in range(1, len(atr_split_list)):
			atr_split_list[num] = atr_split_list[num].title()

		return ''.join(atr_split_list)

	def get_walmart_product_insight(self) -> Prodict:
		pass

	def create_image_url_proxy(self, img_url: str) -> str:
		if not img_url:
			return ''

		return f'{self.URL_IMAGE_PROXY}{img_url}'

	def create_feed_item_product(self):
		"""Feed create from cache_product
		Create feed header
		get template and assign to product
		"""
		list_feed_product = []
		for product in self.cache_products:
			product_convert = self.product_to_walmart_data(product)
			if product_convert.result == Response.SUCCESS:
				list_feed_product.append(product_convert.data)
		return list_feed_product

	def insert_map_product_succeed(self):
		for product_ in self.cache_products:
			pro_id = product_['_id']
			if not self.cache_errors[pro_id]:
				wpid = self.cache_products_insert[pro_id].get('wpid')
				if get_config_ini('walmart', 'mode') in self._TEST_MODE:
					wpid = self.cache_products_insert[pro_id].get('sku')

				self._extend_product_map = {
					'id': self.cache_products_insert[pro_id].get('wpid'),
					'sku': self.cache_products_insert[pro_id].get('sku'),
					'wpid': self.cache_products_insert[pro_id].get('wpid'),
					'wm_itemid': self.cache_products_insert[pro_id].get('wm_itemid'),
					'walmart_status': self._WALMART_STATUS['active']
				}
				# Extend Product code and item_id_code from walmart
				for id_code in self._LIST_PRODUCT_ID_TYPE:
					self._extend_product_map.update({
						id_code: self.cache_products_insert[pro_id].get(id_code) or ''
					})

				self.insert_map_product(product_, pro_id, wpid)

		return True

	def check_cache_error_republish(self):
		"""func for republish feed - check error in cache_error
		and update the product attributes to republish
		"""
		def convert_image_proxy() -> str:
			"""convert url image to proxy url image"""
			nonlocal product

			product['thumb_image']['url'] = self.create_image_url_proxy(product['thumb_image']['url'])

			if not product.get('images') or not isinstance(product['images'], list):
				return 'Convert done.'

			for idx, img in enumerate(product['images']):
				product['images'][idx]['url'] = self.create_image_url_proxy(product['images'][idx]['url'])

			return 'Convert done.'

		for _id, err_list in self.cache_errors.items():
			if err_list:  # todo: change check err message in list
				product_filter = list(filter(lambda p: p['_id'] == _id, self.cache_products))

				if not product_filter:
					continue

				product = product_filter[0]

				if any([err.find('Main image URL setup failed.') != -1 for err in err_list]):
					convert = convert_image_proxy()

		return True

	def feed_items(self, republished: bool = False) -> bool:
		"""create feed and check feed result
		insert_map_product success, get new wpid, item_id, sku product
		Flow:
			1. Check the type of the feed (new item or updated already item)
			2. Create body feed - products, `product_to_walmart_data`
			3. Send feed to Walmart
			4. Check the feed status, Walmart needs time to process feed
			5. From the feed status, get the product status, `insert_map_product`
		"""

		if self._update_product_code:
			self._update_product_flow = False

		if self._update_product_flow:
			feed_type = 'MP_MAINTENANCE'
			selling_channel = 'mpmaintenance'
		else:
			feed_type = 'MP_ITEM'
			selling_channel = 'marketplace'

		mp_item_feed_header = {
			'sellingChannel': selling_channel,
			'processMode': 'REPLACE',
			'version': to_str(self.API_VERSION),
			'subset': 'EXTERNAL',
			'locale': 'en'
		}

		try:
			mp_item = self.create_feed_item_product()
		except:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()
			return False

		if not mp_item:
			return False

		post_data = {
			"MPItemFeedHeader": mp_item_feed_header,
			"MPItem": mp_item
		}

		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			self.log_response(post_data, 'post_data_feed_product')
			self.insert_map_product_succeed()
			return True

		response = self.api('feeds?feedType=' + feed_type, data = post_data, api_type = 'post')
		if response.result != Response.SUCCESS:
			error_message = response.get('msg', '') or Errors.EXCEPTION
			self.cache_errors = {product["_id"]: [error_message] for product in self.cache_products}
			return False

		check_feed = self.check_feed_status(response)
		if check_feed.result != Response.SUCCESS:
			return False

		# republished only one
		if self._republish_feed and not republished:
			self.check_cache_error_republish()
			self.cache_errors = {product['_id']: [] for product in self.cache_products}
			self.feed_items(republished = True)
		else:
			if not self.is_update_product_process():
				# insert new product when publish new product only
				self.insert_map_product_succeed()

		return True

	def get_item_associations(self) -> List[dict]:
		"""get shipping template of current product on walmart"""
		shipping_list = list()
		cache_split = split_list(self.cache_products_imported, 50)
		for list_ in cache_split:
			data = {
				'items': [{'sku': product['sku']} for product in list_]
			}
			response = self.api('items/associations', data = data, api_type = 'post')
			if response.result != Response.SUCCESS or self._last_status > 300:
				continue

			shipping_list += response.data.get('items', [])

		return shipping_list

	def feed_update_shipping_template(self):
		"""
		Update_shipping when create and update products
		1. Update shipping template - required
		2. Lagtime template - not required
		"""

		def feed_update_shipping():
			feed_type = 'SKU_TEMPLATE_MAP'
			item_feed_header = {
				"sellingChannel": "precisedelivery",
				"locale": "en",
				"version": "1.0"
			}
			item = []
			for product in self.cache_products_imported:
				if not product.get('template_data', {}).get('shipping'):
					continue

				sku_product = product.get('sku')
				add = {
					"PreciseDelivery": {
						"sku": sku_product,
						"actionType": "Add",
						"shippingTemplateId": product.template_data.shipping.get('shipping_id', ''),
						"fulfillmentCenterId": product.template_data.shipping.get('fulfillment_id', ''),
					}
				}
				item.append(add)

			if not item:
				return Response().success()

			post_data = {
				"ItemFeedHeader": item_feed_header,
				"Item": item
			}

			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				self.log_response(post_data, 'post_data_shipping')
				return True

			response = self.api('feeds/?feedType=' + feed_type, data = post_data, api_type = 'post')
			check_feed = self.check_feed_status(response)
			if check_feed.result != Response.SUCCESS:
				# if check_feed != Response().success():
				return check_feed

		def feed_update_lagtime():
			feed_type = 'lagtime'
			item_feed_header = {
				"version": "1.0"
			}
			item = []
			for product in self.cache_products_imported:
				lag_time: None or int = product.get('template_data', {}).get('shipping', {}).get('fulfillment_lag_time')
				# lag_time can be 0
				if lag_time is None:
					continue

				sku_product = product.get('sku')
				add = {
					"sku": sku_product,
					"fulfillmentLagTime": to_int(lag_time)
				}
				item.append(add)

			if not item:
				return Response().success()

			post_data = {
				"lagTimeHeader": item_feed_header,
				"lagTime": item
			}
			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				self.log_response(post_data, 'post_data_lagtime')
				return True

			response = self.api('feeds/?feedType=' + feed_type, data = post_data, api_type = 'post')
			check_feed = self.check_feed_status(response)
			if check_feed.result != Response.SUCCESS:
				# if check_feed != Response().success():
				return check_feed

		_ = feed_update_shipping()
		_ = feed_update_lagtime()

		return Response().success()

	def feed_update_promo(self):

		def get_end_time() -> (str, str):
			"""Because end_time promo maximum one year, check product_end_date"""
			product_end_date_timestamp = to_timestamp(product.special_price.end_date, '%Y-%m-%dT%H:%M:%S', False)

			next_year = datetime.now() + timedelta(days = 365)
			next_year_timestamp = datetime.timestamp(next_year)

			end_date_timestamp = min(next_year_timestamp, product_end_date_timestamp)
			end_time_product = datetime.fromtimestamp(end_date_timestamp).strftime(self._FORMAT_TIME)

			return end_time_product, to_decimal(end_date_timestamp, 2)

		def get_start_time() -> (str, str):
			product_start_date_timestamp = to_timestamp(product.special_price.start_date, '%Y-%m-%dT%H:%M:%S', False)

			now = datetime.now() + timedelta(minutes = 40)
			now_timestamp = datetime.timestamp(now)

			start_date_timestamp = max(product_start_date_timestamp, now_timestamp)
			start_date_product = datetime.fromtimestamp(start_date_timestamp).strftime(self._FORMAT_TIME)

			return start_date_product, to_decimal(start_date_timestamp, 2)

		def insert_map_product_promo():
			"""Update flag check promo price in the warehouse"""
			pro_id = product['_id']
			wpid = self.cache_products_insert[pro_id].get('wpid')
			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				wpid = self.cache_products_insert[pro_id].get('sku')
			self._extend_product_map.update({
				'have_promo_price': have_promo_price
			})
			self.insert_map_product(product, pro_id, wpid)

			return True

		def get_promo_on_walmart() -> (str, str):
			nonlocal product, end_date, promo_id

			check_ = self.api(f'promo/sku/{product.sku}')
			check_1 = False if check_.result != Response.SUCCESS or self._last_status > 300 else True
			check_2 = False if to_str(check_.data.get('status')).upper() != 'OK' else True

			if not (check_1 and check_2):
				return '', ''

			try:
				end_date_timestamp = to_int(check_.data["payload"]["pricingList"]["pricing"][0]["expirationDate"])
				promo_id = check_.data["payload"]["pricingList"]["pricing"][0]["promoId"]
				end_date = datetime.fromtimestamp(end_date_timestamp / 1000).strftime(self._FORMAT_TIME)

			except Exception as e:
				end_date = ''
				promo_id = ''
				self.log({'response': check_, 'exception': e}, log_file_name)

			return end_date, promo_id

		def put_promo(process_mode='new', promo_id=''):
			"""update promo price to walmart
			function can use to
			1. create a new promo
			2. delete all existing promo

			process_mode can be UPSERT (create new)
			or DELETE
			"""
			mode = {
				'new': 'UPSERT',
				'delete': 'DELETE'
			}

			nonlocal product

			if process_mode == 'delete':
				data = {
					'sku': product.sku,
					'replaceAll': True,
					'pricing': [
						{
							'promoId': promo_id,
							'processMode': mode['delete']
						}
					]
				}
			else:
				data = {
					'sku': product.sku,
					'replaceAll': True,
					'pricing': [
						{
							'currentPrice': {
								'currency': 'USD',
								'amount': product.special_price.price
							},
							'comparisonPrice': {
								'currency': 'USD',
								'amount': product.price
							},
							'effectiveDate': start_time,
							'expirationDate': end_time,
							'processMode': mode['new'],
							'currentPriceType': 'REDUCED',
							'comparisonPriceType': 'BASE',
							'priceDisplayCodes': 'CART',
						}
					]
				}

			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				self.log_response(data, 'put_promo')
				return True

			promo_update = self.api('price?promo=true', data = data, api_type = 'put')

			if promo_update.result != Response.SUCCESS or self._last_status > 300:
				self.log({'error when put promo': promo_update, 'data': data}, log_file_name)
				return False

			return True

		if not self.cache_products_imported:
			return Response().success()

		log_file_name = 'feed_update_promo'

		for product in self.cache_products_imported:
			try:
				have_product_special_price = self.is_special_price(product) and product.special_price.end_date
				have_promo_on_walmart = product.get('have_promo_price')

				if not have_product_special_price and not have_promo_on_walmart:
					continue

				end_date, promo_id = '', ''
				start_time, start_time_timestamp = get_start_time()
				end_time, end_time_timestamp = get_end_time()

				if not have_product_special_price and have_promo_on_walmart:
					# delete promo on main store -> delete promo on walmart
					end_date, promo_id = get_promo_on_walmart()
					delete_promo = put_promo('delete', promo_id)
					have_promo_price = False if delete_promo else True

				elif have_product_special_price and not have_promo_on_walmart:
					# new promo on main store -> create new promo on walmart
					if start_time_timestamp > end_time_timestamp:
						continue

					create_promo = put_promo()
					have_promo_price = True if create_promo else False

				elif have_product_special_price and have_promo_on_walmart:
					# current products have promo on walmart and already upload to walmart
					# check date, price on walmart, if new -> update
					end_date, promo_id = get_promo_on_walmart()
					delete_promo = put_promo('delete', promo_id)
					time.sleep(5)
					create_promo = put_promo()
					have_promo_price = True if create_promo else False

				insert_map_product_promo()
			except:
				log_traceback()
				continue

		return Response().success()

	def put_price_product(self):
		"""Update one by one product"""
		for product in self.cache_products_imported:
			item = {
				'sku': product.sku,
				'pricing': [
					{
						'currentPriceType': 'BASE',
						'currentPrice': {
							'currency': 'USD',
							'amount': product.price
						}
					}
				]
			}

			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				self.log_response(item, 'put_price_product')
				continue

			response = self.api('price', data = item, api_type = 'put')

		return Response().success()

	def feed_update_price(self):
		if not self.cache_products_imported:
			return Response().success()

		feed_type = 'price'
		price_header = {
			'version': '1.7'
		}
		price_list = []

		for product in self.cache_products_imported:
			item = {
				'sku': product.sku,
				'pricing': [
					{
						'currentPriceType': 'BASE',
						'currentPrice': {
							'currency': 'USD',
							'amount': product.price
						}
					}
				]
			}
			price_list.append(item)

		if not price_list:
			return Response().success()

		post_data = {
			'PriceHeader': price_header,
			'Price': price_list
		}
		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			self.log_response(post_data, 'post_data_feed_price')
			return True

		response = self.api('feeds/?feedType=' + feed_type, data = post_data, api_type = 'post')
		check_feed = self.check_feed_status(response)

		if check_feed.result != Response.SUCCESS:
			return check_feed

		return Response().success()

	def put_inventory_product(self):

		for product in self.cache_products_imported:
			item = {
				'sku': product.get('sku'),
				'quantity': {
					'unit': 'EACH',
					'amount': product.get('qty')
				}
			}

			if get_config_ini('walmart', 'mode') in self._TEST_MODE:
				self.log_response(item, 'put_inventory_product')
				continue

			response = self.api('inventory', data = item, api_type = 'put')

		return Response().success()

	def feed_update_inventory(self):
		"""https://developer.walmart.com/api/us/mp/inventory#operation/updateInventoryForAnItem
		Inventory spec 1.4 feed type: inventory
		Inventory spec 1.5 feed type: MP_INVENTORY still beta on 09/2022
		1.5 support multi node inventory update feed, json only
		"""
		if not self.cache_products_imported:
			return Response().success()

		feed_type = 'inventory'
		inventory_header = {
			'version': '1.4'
		}
		inventory = []

		for product in self.cache_products_imported:
			item = {
				'sku': product.get('sku'),
				'quantity': {
					'unit': 'EACH',
					'amount': product.get('qty')
				}
			}
			inventory.append(item)

		if not inventory:
			return Response().success()

		post_data = {
			'InventoryHeader': inventory_header,
			'Inventory': inventory
		}
		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			self.log_response(post_data, 'post_data_feed_inventory')
			return True

		response = self.api('feeds/?feedType=' + feed_type, data = post_data, api_type = 'post')
		check_feed = self.check_feed_status(response)

		if check_feed.result != Response.SUCCESS:
			return check_feed

		return Response().success()

	def get_cache_product_imported(self) -> bool:
		"""Get the list of the products imported success when listing new product
		If the products already listing no need to check"""

		if not self.is_product_process():
			self.cache_products_imported = copy.deepcopy(self.cache_products)
			return True

		for product in self.cache_products:
			if self.cache_errors[product['_id']]:
				continue

			self.cache_products_imported.append(product)

		# The sku list changed after update the feed item
		# Due to failed product
		self.create_products_sku_index(self.cache_products_imported)
		# TODO: add product import sku

		return True if self.cache_products_imported else False

	def wait_secs_feed_process(self, base_time_secs: int = 30) -> None:
		"""Wait a moment WM processed new product """
		MAX_SECS_WAIT = 2 * 60 * 60
		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			return

		if self._update_product_flow:
			# decrease time if the products are already on the Walmart
			base_time_secs = to_int(base_time_secs / 2)

		sleep_time = 0
		if self.is_product_process():
			sleep_time = len(self.cache_products_imported) * base_time_secs

		sleep_time_min = min(sleep_time, MAX_SECS_WAIT)

		time.sleep(sleep_time_min)

	def split_cache_product(self) -> List[List[Prodict]]:
		"""split self.cache_products to sublist
		with a simple product, add the product and check if sub_list has a length less
		than `max_item_per_feed`

		with variants product, check when add with simple product
		if a variants product have totals of variants is greater than `max_item_per_feed`
		or total of current sublist and variants is greater than `max_item_per_feed`
		-> get the new sublist
		"""

		if len(self.cache_products) < self._MAX_ITEM_PER_FEED:
			return [self.cache_products]

		total_list: List[List[Prodict]] or List = []
		sub_list: List[Dict] or List = []
		variant_list: List[Dict] or List = []
		pre_parent_id = ''

		for product in self.cache_products:
			if len(sub_list) >= self._MAX_ITEM_PER_FEED:
				total_list.append(sub_list)
				sub_list = []

			# simple variant
			if not product.get('parent_group_id'):
				sub_list.append(product)
				continue

			# first time only
			if not pre_parent_id:
				pre_parent_id = product['parent_group_id']

			if pre_parent_id == product['parent_group_id']:
				variant_list.append(product)
			else:
				pre_parent_id = product['parent_group_id']
				if len(sub_list) + len(variant_list) > self._MAX_ITEM_PER_FEED:
					# Two variant products that are close together
					if sub_list:
						total_list.append(sub_list)

					total_list.append(variant_list)
					sub_list = []

					# Remember add current product
					variant_list = [product]
				else:
					sub_list += variant_list
					variant_list = [product]

		if sub_list:
			total_list.append(sub_list)

		if variant_list:
			total_list.append(variant_list)

		return total_list

	def check_duplicate_sku(self) -> bool:
		"""check self.cache_products has duplicate sku
		if the list has duplicate sku. replace sku duplicate with a new sku
		"""
		try:
			sku_list = [product['sku'] for product in self.cache_products]

			if len(sku_list) == len(set(sku_list)):
				return True

			# get the sku and the index list of duplicate sku
			# but we pass the first sku
			duplicates = {}
			for index_, sku in enumerate(sku_list):
				if sku_list.count(sku) < 2:
					continue

				if isinstance(duplicates.get(sku), list):
					duplicates[sku].append(index_)
				else:
					duplicates[sku] = []

			for sku, index_ in duplicates.items():
				self.cache_products[to_int(index_)]['sku'] = to_str(sku) + '_' + self.random_sku(5)
			# TODO:
			# add postfix and check max length of sku condition
			# but the new sku can be same as already sku on walmart -> walmart response error
			# or the cache_products -> check
		except Exception as e:
			self.log(f'Exception check_duplicate_sku: {e}', 'check_duplicate_sku')

		return True

	def addition_product_import(self):
		"""
		Walmart use feed to create, update product, inventory, price,..
		1. Create product feed
		2. Update inventory
		"""
		if not self.cache_products:
			return Response().success()

		# split_list = self.split_cache_product()
		# check_duplicate_sku = self.check_duplicate_sku()
		self.create_products_cache()
		feed_items_succeed = False
		try:
			feed_items_succeed = True
			# check create new product or update product
			feed_product_mode = self.is_product_process()
			if feed_product_mode:
				feed_items_succeed = self.feed_items()

			# Get the product imported and then update that products.
			# If the feed don't have any product then skip feed inventory, price
			product_imported = self.get_cache_product_imported()
			self.wait_secs_feed_process(base_time_secs = 30)
			if self.cache_products_imported:
				len_cache_imported = len(self.cache_products_imported)
				if not feed_product_mode and not self._update_price:
					pass

				elif feed_product_mode or len_cache_imported > 50:
					self.feed_update_price()

				else:
					self.put_price_product()

				if not feed_product_mode and not self._update_qty:
					pass

				elif feed_product_mode or len_cache_imported > 50:
					self.feed_update_inventory()

				else:
					self.put_inventory_product()

				if feed_product_mode:
					self.feed_update_shipping_template()

		except Exception:
			for product in self.cache_errors.keys():
				self.cache_errors[product].append(Errors().get_msg_error(Errors.EXCEPTION))
			log_traceback()

		self.after_push_feed(feed_items_succeed)
		return Response().success()

	def reset_cache_products(self) -> None:
		"""Reset the product cache to prepare for the next round."""
		self.cache_products= list()
		self.cache_products_imported= list()
		self.cache_warnings = dict()
		self.cache_errors = dict()
		self.cache_products_sku_index = dict()
		self.cache_products_insert = dict()
		self.parent_products = dict()
		self.parent_variants = dict()

	def after_push_feed(self, feed_items_succeed: bool):
		"""feed_items_succeed: True if a feed create new items or maintenance
		published success.
		If False means doesn't have product published
		"""
		for product in self.cache_products:
			if not feed_items_succeed or self.cache_errors.get(product["_id"]):
				if self.cache_errors.get(product['_id']):
					err_list = [to_str(err) for err in self.cache_errors[product['_id']]]
					# error = "\n".join(self.cache_errors[product["_id"]])
					error = "\n".join(err_list)
				else:
					error = Errors().get_msg_error(Errors.WALMART_FEED_ERROR)

				self.after_push_product(product['_id'], Response().error(msg = error), product)
				self.log(f'Error product_id {product["_id"]}: {error}', 'products')
			else:
				self.after_push_product(product['_id'], Response().success(), product)

			if self.cache_warnings.get(product["_id"]):
				for warning in self.cache_warnings[product["_id"]]:
					self.log(f'Warning {product["_id"]}: {warning}', 'products')

		for parent_id, variant_ids in self.parent_variants.items():
			errors = list(filter(lambda x: self.cache_errors.get(x), variant_ids))
			if feed_items_succeed and not errors:
				self.after_push_product(parent_id, Response().success(), self.parent_products[parent_id], is_parent = True)
				if self.is_inventory_process():
					self.update_qty_for_parent(parent_id)
				else:

					product_map = self.parent_products[parent_id]
					self.insert_map_product(product_map, parent_id, parent_id)
			else:
				if not feed_items_succeed:
					try:
						if not errors:
							msg_errors = Errors().get_msg_error(Errors.WALMART_ERROR_PARENT_PRODUCT)
						else:
							msg_errors = "\n".join(self.cache_errors[errors[0]])
					except (IndexError, Exception) as e:
						msg_errors = Errors().get_msg_error(Errors.WALMART_ERROR_PARENT_PRODUCT)
						log_data = {
							'exception': str(e),
							'errors': errors,
							'cache_error': self.cache_errors
						}
						self.log(log_data, 'log_reset_cache_exception')
				else:
					msg_errors = 'Your product variants have errors. Click the "Variations" tab to see the errors.'
					if to_str(self.cache_errors[errors[0]][0]).find('Variant metadata bag') != -1:
						# show variants error on the parent product
						msg_errors += '\n Variant metadata bag is missing or empty.'

				self.after_push_product(parent_id, Response().error(msg = msg_errors), self.parent_products[parent_id], is_parent = True)

		self._state.push.process.products.error += len([1 for errors in self.cache_errors.values() if errors])
		self.reset_cache_products()

		return Response().success()

	def create_products_sku_index(self, cache_products: List[Product]) -> None:
		"""self.cache_products_sku_index: map feed data error
		the feed new item['data error'] only contains the product sku and the error message
		if the feed has duplicate skus:
			walmart inserts _idx for each duplicate skus
		example:
			the seller send:
			 {'sku': 'abc'}, {'sku': 'abc'}, {'sku': 'abc'}
			walmart will response with:
			{'sku': 'abc'}, {'sku': 'abc_1'}, {'sku': 'abc_2'}
		warning: feed maintance will have same sku
		TODO: update feed maintance
		"""
		self.cache_products_sku_index = dict()
		sku_count = dict()
		index = 0
		for product in cache_products:
			sku_add = product['sku']
			if sku_count.get(product['sku']):
				sku_add += f"_{sku_count[product['sku']]}"

				self.cache_errors[product['_id']].append(
					Errors().get_msg_error(Errors.WALMART_SKU_DUPLICATE))

			self.cache_products_sku_index.update({
				sku_add: {
					'_id': product['_id'],
					'index': index
				}
			})
			sku_count[product['sku']] = sku_count.get(product['sku'], 0) + 1
			index += 1


	def create_products_cache(self):
		"""
		create cache error, cache product, mapping product _id and sku
		"""
		self.cache_errors = {product['_id']: [] for product in self.cache_products}
		self.cache_warnings = {product['_id']: [] for product in self.cache_products}
		self.cache_products_sku_index = {}
		self.create_products_sku_index(self.cache_products)
		for product in self.cache_products:
			self.cache_products_insert.update({
				# upc, gtin, wpid - default, item_id - default
				product['_id']: {
					'sku': product.sku,
					'upc': product.upc,
					'gtin': product.gtin,
					'ean': product.ean,
					'isbn': product.isbn,
					'sku_update': '',
					'wpid': '',
					'wm_itemid': ''
				}
			})

		return True

	def replace_description(self, text):
		return self.strip_html_from_description(text)

	def update_product_attribute(self, product_id, product, delete_image = False):
		pass

	def after_product_import(self, product_id, convert, product, products_ext):
		return Response().success()

	def delete_product_import(self, product_id) -> Response:
		# self.api('/catalog/products/' + to_str(product_id), None, 'delete')
		sku_list = self.get_product_sku_list(product_id)
		if not sku_list:
			return Response().error()

		for sku in sku_list:
			response = self.api(path = f'items/{self.escape_reversed_character_url(sku)}', api_type = 'delete')
			self.log(f'Delete product sku: {sku}', 'retire_product')

		return Response().success()

	def get_product_sku_list(self, product_id) -> list:
		"""get product sku list from `product.id`
		product_id can be `wpid` or `variant_group_id`
		product_id: get from function `get_product_id_import`
		"""
		channel_id = self.get_channel_id()
		where = {
			f'channel.channel_{channel_id}.wpid': product_id,
			'is_variant': False
		}
		limit = 10
		product = self.get_model_catalog().find_all(where = where, limit = limit)

		if not product:
			where = {
				f'channel.channel_{channel_id}.variant_group_id': product_id,
				'is_variant': False
			}

		product = self.get_model_catalog().find_all(where = where, limit = limit)

		if not product:
			error_log = f'Can\'t get product id: {product_id}, channel_id: {channel_id}'
			self.log(error_log, 'get_product_sku_list')
			return []

		product = product[0]

		if product.variant_count:
			where = {
				f'channel.channel_{channel_id}.status': 'active',
				'is_variant': True,
				'parent_id': to_str(product['_id'])
			}
			variant_list = self.get_model_catalog().find_all(where = where, limit = limit)
			sku_list = [variant['channel'][f'channel_{channel_id}']['sku'] for variant in variant_list]
		else:
			sku_list = [product['channel'][f'channel_{channel_id}']['sku']]

		return sku_list

	def create_product_options(self, product_id, product):
		pass

	def check_item_update(self, item: Product) -> Product:
		"""Get product/variant, check is product update code or sku"""
		if item.get('changed_field') and isinstance(item['changed_field'], list):

			if 'sku' in item['changed_field']:
				item['sku_update'] = True
			elif set(self._LIST_PRODUCT_ID_TYPE) & set(item['changed_field']):
				item['product_id_update'] = True

			if item.get('sku_update') or item.get('product_id_update'):
				self._update_product_code = True

		return item

	def check_remove_variant_group(self, product: Product) -> bool:
		"""some seller use used upcs.
		in the past, they published product with variant formats
		normally, walmart not remove variant group id
		in specs 4.8, walmart allows remove group id
		check if a simple product (on LitC) have variant group have group_id
		if product have group_id remove it
		"""
		if not self._state.channel.config.api.remove_variant_group:
			return False

		item_request = self.get_product_by_id(
			product_id = product.sku,
			id_type = 'sku',
			max_retry = 3
		)
		if item_request.result != Response.SUCCESS:
			return False

		if item_request.data.get('variantGroupId'):
			return True

		return False
	def product_channel_update(self, product_id, product: Product, products_ext):
		"""get product update to add to cache_products
		link product[_id] to two lists: products don't have variant and products have variants
		if product have variants - link between the parent product and variants
		"""

		def mapping_missing_field_variant_update():
			nonlocal product
			nonlocal variant
			# always get a parent description
			variant['description'] = product['description']
			required_field_list = ['brand', 'variant_group_id', 'weight', 'weight_units', 'images', 'is_sku_override']
			for field in required_field_list:
				check = self.strip_html_from_description(variant.get(field))

				if not check:
					variant[field] = deepcopy(product.get(field))

			is_already_used_parent: bool = False
			if not variant.thumb_image.url:
				variant.thumb_image.url = product.thumb_image.url
				is_already_used_parent = True

			self.use_parent_image(product, variant, is_already_used_parent)
			return True

		self.set_update_product_mode(True)

		product.pull_from_walmart = self.is_product_pull_from_walmart(product)

		if not product.variants:
			product = self.check_item_update(product)
			previous_sku = product.sku
			product.sku = self.validate_product_sku(product.sku)

			is_simple_product_have_variant_id = self.check_remove_variant_group(product)
			if product.get('is_sku_override'):
				self._update_product_code = True
			# TODO: remove self.version when upgrade to 4.8
			if is_simple_product_have_variant_id:
				self.API_VERSION = 4.8
				product['remove_variant_group'] = True

			# check remove variant group id
			if previous_sku != product.sku:
				self._update_product_code = True

			self.cache_products.append(product)
		else:
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			# create new variant_group_id, max length 20
			parent_id = ModelChannelsWalmart.random_sku(length = 20)
			# min_price = self.set_lowest_price_variant_is_primary(product)
			min_price_variant = min([variant['price'] for variant in product.variants])
			have_primary = False

			for index, variant in enumerate(product.variants):
				# check the status of product: linked or active
				check = variant['channel'][f'channel_{self.get_channel_id()}'].get('product_id')
				if not check:
					# product add the new variant to Walmart
					self.set_update_product_mode(False)

				if product.get('is_sku_override'):
					self._update_product_code = True

				# TODO: product id, sku update, refactor
				previous_sku = variant.sku
				variant.sku = self.validate_product_sku(variant.sku)
				if previous_sku != variant.sku:
					self._update_product_code = True

				variant = self.check_item_update(variant)
				variant.pull_from_walmart = product.pull_from_walmart
				# backup when the variants can't get group_id from walmart
				variant.parent_group_id = product.get('group_id') or parent_id
				# set the variant has the lowest price is the primary variant
				if not have_primary and variant.price == min_price_variant:
					have_primary = True
					variant['is_primary_variant'] = True

				self.parent_variants[product['_id']].append(variant['_id'])
				mapping_missing_field_variant_update()
				for product_attr in product.attributes:
					variant.attributes.append(product_attr)

				self.cache_products.append(variant)

		return Response().success()

	# orders
	def get_orders_main_export(self):
		if self._flag_finish_get:
			return Response().finish()

		# Walmart sandbox doesn't change nextCursor in response. It makes loop import main
		if get_config_ini('walmart', 'mode') == 'test_sandbox':
			self._flag_finish_get = True

		if not self._state.pull.process.products.id_src:
			self._state.pull.process.products.id_src = 0

		limit_data = self._state.pull.setting.orders
		start_time = self.get_order_start_time('iso')
		last_modifier = self._state.pull.process.orders.max_last_modified
		# last_modifier = convert_format_time(last_modifier_raw, old_format = '%Y-%m-%d %H:%M:%S', new_format = '%Y-%m-%dT%H:%M:%SZ')
		orders_filter_condition = {
			'limit': limit_data,
			'replacementInfo': 'true',  # get additional attributes
			'productInfo': 'true',
			'createdStartDate': start_time,
		}

		if last_modifier and 'Z' in last_modifier:
			orders_filter_condition['lastModifiedStartDate'] = last_modifier

		if get_config_ini('walmart', 'mode') in self._TEST_MODE:
			orders_filter_condition['limit'] = 40
			orders_filter_condition['createdStartDate'] = '2023-01-19T01:04:28Z'
		# 	del orders_filter_condition['lastModifiedStartDate']

		if self._next_cursor_order:
			# next cursor: string to be used as query parameter
			order_response = self.api(f'orders{self._next_cursor_order}')
		else:
			order_response = self.api('orders', data = orders_filter_condition)

		order_data = order_response.data.get('list', {}).get('elements', {}).get('order', {})
		self._next_cursor_order = order_response.get('data', {}).get('list', {}).get('meta', {}).get('nextCursor', '')
		if not self._next_cursor_order or to_str(self._next_cursor_order) == '*':
			self._flag_finish_get = True

		if not order_response or not order_data:
			return Response().error(msg = "Could not get list of orders from Walmart")

		return Response().success(data = order_data)

	def get_orders_ext_export(self, orders):
		return Response().success()

	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.purchaseOrderId

	def convert_order_status(self, status: str) -> str:
		order_status = {
			'Created': Order.READY_TO_SHIP,  # use ready_to_ship fix payment_open shopify
			'Acknowledged': Order.READY_TO_SHIP,
			'Shipped': Order.SHIPPING,
			'Delivered': Order.COMPLETED,
			'Cancelled': Order.CANCELED,
			'Refund': Order.REFUNDED
		}
		return order_status.get(status.title(), Order.READY_TO_SHIP)

	def time_to_walmart_timestamp(self, date) -> int:
		"""Walmart use timestamp - 64bit - have nanoseconds
		Convert date to walmart timestamp
		If can't convert the time, the function has been used
		current time as the date
		"""
		if not date:
			date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		convert = to_timestamp(date)

		return convert * 1000

	def walmart_timestamp_to_time(self, timestamp: int) -> str:
		# Walmart timestamp milliseconds to datetime
		date_time = None
		try:
			timestamp /= 1000
			date_time = datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
		except:
			pass
		return date_time

	def total_tax_orderlines(self, order):
		"""
		orderLines:
			orderLine []
				charges:
					charge[] - [product, shipping] each charge have tax
		"""
		try:
			total_tax = 0
			for order_line in order.orderLines.orderLine:
				for charge in order_line.charges.charge:
					try:
						charge_amount = charge.tax.taxAmount.amount
						total_tax += charge_amount
					except (KeyError, IndexError, AttributeError):
						continue
		except:
			total_tax = 0

		return to_decimal(total_tax, 2)

	def total_shipping_orderlines(self, order):
		"""
		orderLines:
			orderLine []
				charges:
					charge[] - [product, shipping]
		"""
		try:
			total_shipping = 0
			for order_line in order.orderLines.orderLine:
				for charge in order_line.charges.charge:
					if charge.chargeType != 'SHIPPING':
						continue
					try:
						shipping = to_decimal(charge.chargeAmount.amount, 2)
					except:
						continue
					total_shipping += shipping
		except:
			total_shipping = 0

		return to_decimal(total_shipping, 2)

	def get_order_data_status(self, order: Prodict) -> (str, bool):
		order_lines = order.orderLines.orderLine
		status_list = list()
		is_status_created = False

		for order_line in order_lines:
			# after an order delivered to customer, if an order has cancelled
			# walmart will update new status, and will not override the delivered status before
			order_line_status = order_line.get('orderLineStatuses', {}).get('orderLineStatus', [{}])[-1].get('status')
			status_list.append(self.convert_order_status(order_line_status))

			if to_str(order_line_status) == 'Created':
				is_status_created = True

		"""order line has four statuses: ready-to-ship, shipping, canceled, and completed.
		the order is completed when all of the order lines completed
		if one of them canceled or is still ready-to-ship set the order status by them
		"""
		if not status_list:
			return ''

		if Order.CANCELED in status_list:
			status_order = Order.CANCELED
		elif Order.SHIPPING in status_list:
			status_order = Order.SHIPPING
		elif Order.READY_TO_SHIP in status_list:
			status_order = Order.READY_TO_SHIP
		# elif Order.OPEN in status_list:
		# 	status_order = Order.OPEN
		else:
			status_order = Order.COMPLETED

		return status_order, is_status_created

	def total_amount_orderlines(self, order) -> float:
		"""Total of amount the products in the order
		rounding result
		get product price only
		"""
		total_amount = 0
		try:
			for order_line in order.orderLines.orderLine:
				for charge in order_line.charges.charge:

					if charge.chargeType != 'PRODUCT':
						continue

					try:
						product_price = to_decimal(charge.chargeAmount.amount, 2)

					except:
						continue

					total_amount += product_price

		except:
			total_amount = 0
		return to_decimal(total_amount, 2)

	def convert_order_export(self, order: Prodict, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.orderDate)
		order_data = Order()
		# order id
		order_data.id = to_str(order.purchaseOrderId)
		order_data.order_number = to_str(order.customerOrderId)
		custom_id = OrderAdditionalDetails(name = 'customer_order_id', value = order.customerOrderId)
		order_data.additional_details.append(custom_id)

		# order status [canceled, completed, shipping,..]
		try:
			order_line_status = order.orderLines.orderLine[0].orderLineStatuses.orderLineStatus[0]
		except:
			order_line_status = dict()

		order_data.status, is_status_created = self.get_order_data_status(order)
		order_data.tax.title = 'Tax of products'
		order_data.tax.amount = self.total_tax_orderlines(order)
		# order_data.shipping.title = order_data.shipments.tracking_company
		order_data.shipping.amount = self.total_shipping_orderlines(order)
		# TODO: discount
		order_data.subtotal = self.total_amount_orderlines(order)
		order_data.total = to_decimal((order_data.subtotal + order_data.tax.amount + order_data.shipping.amount), 2)
		try:
			order_data.currency = order.orderLines.orderLine[0].charges.charge[0].chargeAmount.currency
		except:
			order_data.currency = ''

		# created_at, updated_at
		order_data.created_at = self.walmart_timestamp_to_time(order.orderDate)
		order_data.updated_at = self.walmart_timestamp_to_time(order.orderDate)
		order_data.imported_at = get_current_time()

		# get first, middle, last name
		# TODO: middle name
		full_name = order.shippingInfo.postalAddress.get('name')
		full_name_list = full_name.split(' ')
		first_name = full_name_list[0]
		last_name = ' '.join([to_str(ele) for ele in full_name_list[1:]]) if len(full_name_list) > 1 else ''

		order_data.customer.id = order.customerOrderId
		order_data.customer.username = full_name
		order_data.customer.telephone = order.shippingInfo.phone
		order_data.customer.first_name = first_name
		order_data.customer.last_name = last_name

		# the seller doesn't want to import walmart relay into their mainstore
		if self._state.channel.config.api.email_override:
			order_data.customer.email = self._state.channel.config.api.email_override
		else:
			order_data.customer.email = order.customerEmailId

		# Walmart has only one field address, loop for address_fields to mapping
		address_fields = ['customer_address', 'billing_address', 'shipping_address']
		order_ship = order.shippingInfo
		order_data.shipping.method = order_ship.methodCode
		for address_field in address_fields:
			order_data[address_field].first_name = first_name
			order_data[address_field].last_name = last_name
			order_data[address_field].telephone = order_ship.phone
			order_data[address_field].address_1 = order_ship.postalAddress.address1
			order_data[address_field].address_2 = order_ship.postalAddress.get('address2', '')
			order_data[address_field].city = order_ship.postalAddress.city
			order_data[address_field].country.country_name = order_ship.postalAddress.country
			order_data[address_field].country.country_code = self.get_country_name_from_code(order_ship.postalAddress.country)  # TODO: re-check
			try:
				country_info = CountryInfo(order_ship.postalAddress.country)
				country_info.iso(2)
			except:
				country_info = False
			if country_info:
				order_data[address_field].country.country_name = country_info.native_name()
				order_data[address_field].country.country_code = country_info.iso(2)
			order_data[address_field].state.state_code = order_ship.postalAddress.state
			order_data[address_field].state.state_name = self.get_state_code_from_name(order_ship.postalAddress.state)  # TODO: re-check
			order_data[address_field].postcode = order_ship.postalAddress.postalCode

		# order.orderLines.orderLine[0].statusDate recent order status
		order_data.shipments.shipped_at = self.walmart_timestamp_to_time(order_ship.estimatedShipDate)
		order_data.shipments.status = order_line_status.get('status', {})
		order_tracking_info = order_line_status.get('trackingInfo', Prodict())
		if order_tracking_info:
			order_data.shipments.methodCode = order_tracking_info.get('methodCode')
			order_data.shipments.tracking_number = order_tracking_info.get('trackingNumber')
			order_data.shipments.tracking_url = order_tracking_info.get('trackingURL')

			if order_tracking_info.get('carrierName'):
				carrier = order_tracking_info.carrierName.get('carrier')
				other_carrier = order_tracking_info.carrierName.get('otherCarrier')
				order_data.shipments.tracking_company = carrier or other_carrier

		order_data.shipments.tracking_company_code = order_data.shipments.tracking_company
		order_data.shipments.fulfillment_id = order.orderLines.orderLine[0].get("fulfillment", {}).get("storeId")
		order_data.channel_data = {
			'order_status': order_data.status,
			'created_at': order_data.created_at,
			'order_number': order_data.order_number,
			'shipped_date': self.walmart_timestamp_to_time(order_tracking_info.get('shipDateTime')) if order_tracking_info else None
		}

		if order.shipNode.type == "WFSFulfilled":
			order_data['fulfillment_status'] = 'fulfilled'

		# payment
		order_data.payment.title = order.get('paymentTypes')
		order_data.payment.method = order.get('paymentTypes')

		# items in order
		"""
		order
			orderLines
				orderLine: []
		"""
		for order_line in order.orderLines.orderLine:
			order_line_price = 0.0
			# product_id = ''
			order_item = OrderProducts()
			# order_item.id = order_line.item.sku
			order_item.product_sku = order_line.item.sku
			order_item.product_name = order_line.item.productName

			tax_total = 0
			for charge in order_line.charges.charge:
				if charge.chargeType == 'PRODUCT':
					order_item.total = charge.chargeAmount.amount
					order_line_price = charge.chargeAmount.amount
					if charge.get('tax', {}) and charge.get('tax', {}).get('taxAmount', {}):
						tax = charge.get('tax', {}).get('taxAmount', {}).get('amount')
						if tax:
							tax_total += to_decimal(tax, 2)
			order_item.tax_amount = to_decimal(tax_total, 2)
			order_item.qty = to_int(order_line.get('orderLineQuantity', {}).get('amount', 0))

			product_id, id_type = order_item.product_sku, 'SKU'
			product_sku_has_slash = order_item.product_sku.find('/') != -1
			if product_sku_has_slash:
				product_query: list = self.get_product_sku_in_warehouse(order_item.product_sku)
				if product_query:
					id_type = 'GTIN'
					product_id = product_query[0]['channel'][f'channel_{self.get_channel_id()}'].get('gtin')

			item_request = Response().error()
			if product_id:
				# check in the case product_sku_has_slash not found the gtin
				item_request = self.get_product_by_id(product_id = product_id, id_type = id_type, max_retry = 5)

			if item_request.result != Response.SUCCESS:
				msg = f"Can't get product id: {order_item.product_sku},\n" \
				      f"Order id: {order.purchaseOrderId},\n" \
				      f"channel_id: {self.get_channel_id()}"
				log(msg, 'order/order_walmart', 'exception_get_product')

			item_request = item_request.get('data') or {}
			order_item.price = item_request.get('price', {}).get('amount', 0) or to_decimal(order_line_price, 2)
			# TODO: get product_id from warehouse
			order_item.product_id = item_request.get('wpid') or item_request.get('upc') or item_request.get('gtin') or order_item.product_sku
			order_item.original_price = item_request.get('price', {}).get('amount', 0) or to_decimal(order_line_price, 2)
			item_request_option_list = item_request.get('variantGroupInfo', {}).get('groupingAttributes') or []
			if item_request_option_list:
				for option in item_request_option_list:
					option_data = OrderItemOption()
					option_data.option_name = option.name
					option_data.option_value_name = option.value
					order_item.options.append(option_data)

			order_data.products.append(order_item)

		if is_status_created:
			_ = self.acknowledge_order(order_data.id)
		if self._state.channel.config.api.random_order_email:
			order_data.custom_order_email = f"{random_string(16)}@walmart.com"

		return Response().success(data = order_data)

	def get_product_sku_in_warehouse(self, sku: str) -> List[dict]:
		"""get product by sku in warehouse"""
		where = {
			f'channel.channel_{self.get_channel_id()}.sku': sku,
		}
		product = self.get_model_catalog().find_all(where = where, limit = 1, select_fields = ['channel'])
		return product

	def acknowledge_order(self, order_id: str) -> Response:
		"""function auto acknowledge new order when pull from walmart"""
		if self._state.channel.config.setting.get('order', {}).get('auto_acknowledgement') == 'enable':
			try:
				request = self.api(path = f'orders/{order_id}/acknowledge', api_type = 'post')

				msg = f"Order id: {order_id},\n" \
					  f"channel_id: {self.get_channel_id()}"
				log(msg, 'order/order_walmart', 'acknowledge_order')

			except:
				log_traceback(type_error = 'acknowledge_order')

		return Response().success()

	def get_state_update(self) -> str:
		"""get update state variable"""
		from datasync.controllers.channel import ControllerChannel
		return ControllerChannel.ACTION_UPDATE

	def after_push_product(self, product_id, import_data, product: Product, is_parent = False):
		if self.is_inventory_process():
			if import_data.result == Response.SUCCESS:
				update_field = dict()
				if self.is_setting_sync_qty():
					update_field[f'channel.channel_{self._state.channel.id}.qty'] = product.qty
				if self.is_setting_sync_price():
					update_field[f'channel.channel_{self._state.channel.id}.price'] = product.price
				if update_field:
					self.get_model_catalog().update(product_id, update_field)
			return Response().success(product)
		update_field = dict()
		product_channel_data = product['channel'][f'channel_{self._state.channel.id}']
		if import_data.result in (Response.ERROR, Response.WARNING):
			publish_status = ProductChannel.ERRORS
			msg = import_data.msg or Errors().get_msg_error(import_data.code)
			# TODO: Product error update more information, update to msg not response
			if not product_channel_data.get('product_id') and self._publish_action != self.get_state_update():
				# if the mainstore has a new variant add to an existing active product on channel walmart
				# the publishing process may encounter an error and status will change to ERROR
				# as a result, the variant may disappear from the UI
				# -> check _publish_action
				update_field[f'channel.channel_{self._state.channel.id}.status'] = ProductChannel.ERRORS
		else:
			msg = ''
			publish_status = ProductChannel.COMPLETED
			update_field[f'channel.channel_{self._state.channel.id}.edited'] = False
			update_field[f'channel.channel_{self._state.channel.id}.status'] = ProductChannel.ACTIVE
			if is_parent:  # don't override product_id wpid - a simple product and variant products
				update_field[f'channel.channel_{self._state.channel.id}.product_id'] = product['_id']
			update_field[f'channel.channel_{self._state.channel.id}.product_sku'] = product.sku
		# TODO: reset changed_field to empty
		# changed_field is the list of updated field from UI
		if product.get('changed_field'):
			update_field[f'channel.channel_{self._state.channel.id}.changed_field'] = []

		update_field[f"channel.channel_{self._state.channel.id}.publish_status"] = publish_status
		update_field[f'channel.channel_{self._state.channel.id}.error_message'] = msg

		product.channel[f"channel_{self._state.channel.id}"] = self.get_product_channel_data(product, '')
		product.channel[f"channel_{self._state.channel.id}"]['publish_status'] = publish_status
		# TODO: Product error authorized to list
		product.channel[f'channel_{self._state.channel.id}']['error_message'] = msg
		self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)

	def get_mapping_addition_attribute(self, product: Product, specific: dict) -> None:
		"""Mapping list object addition attributes
		[{
		"productAttributeName": "",
		"productAttributeValue": "",
		"productAttributeMapping": ""
		}]
		"""

		for sub_field in specific['override']:
			try:
				if (not isinstance(sub_field, dict) or
						not (sub_field.get('productAttributeValue') or sub_field.get('productAttributeMapping'))):
					continue

				add_ = {
					'productAttributeName': sub_field['productAttributeValue']
				}
				mapping_field = sub_field.get('productAttributeMapping')
				if mapping_field:
					value_ = self.assign_attribute_to_field(mapping_field, product)
					add_['productAttributeValue'] = value_

				else:
					add_['productAttributeValue'] = sub_field['productAttributeValue']

				specific['value'].append(add_)

			except Exception as e:
				err_ = {
					'sub_field': sub_field,
					'err': e
				}
				self.log_traceback(type_error = 'mapping_addition', msg = str(err_))


	def channel_assign_shipping_template(self, product, template_data):
		dimension_detail_list = template_data.get('dimensions')
		if not dimension_detail_list:
			return product

		for dimension_name, dimension_detail in dimension_detail_list.items():
			if dimension_name in ['weight_unit']:
				product['channel'][f'channel_{self.get_channel_id()}'][f'{dimension_name}s'] = dimension_detail
				continue

			if not dimension_detail.get('override') and not dimension_detail.get('mapping'):
				continue

			value_template = (
				dimension_detail.override
				if dimension_detail.override
				else dimension_detail.mapping
				)

			new_value = self.assign_attribute_to_field(value_template, product)

			if to_decimal(new_value):
				product['channel'][f'channel_{self.get_channel_id()}'][dimension_name] = to_decimal(new_value, 4)

		return product

	def channel_assign_category_template(self, product, template_data) -> Product:
		"""func choose mapping and override data from the category template"""

		item_specifics = template_data.get('specifics')
		if not item_specifics:
			return product

		for specific in item_specifics:
			try:
				status_changed = False
				if not specific.override and not specific.mapping:
					continue

				if specific['name'] == 'additionalProductAttributes':
					self.get_mapping_addition_attribute(product, specific)
					continue

				if specific.override:
					value = specific.override

				else:
					status_changed = True
					value = specific.mapping

				check_mapping_list_attribute = (
						isinstance(value, list)
						and value and isinstance(value[0], str)
						and re.findall("{{.*?}}", value[0])
				)

				if check_mapping_list_attribute:
					# mapping with attributes list
					status_changed = True
					spec_sub_list = list()
					for sub_val in value:
						spec_sub = self.assign_attribute_to_field(sub_val, product)
						spec_sub_list.append(spec_sub)
					specific.value = '- '.join(spec_sub_list).strip()

				else:
					specific.value = self.assign_attribute_to_field(value, product)
					mapping_override = isinstance(specific.override, str) and re.findall("{{.*?}}", specific.override)
					if mapping_override:
						status_changed = True

				specific.value = self.convert_catalog_value_type(status_changed, specific)
			except Exception as e:
				self.log_traceback(msg = str(e))
				err_log = {
					'exception': str(e),
					'channel_id': self.get_channel_id(),
				}
				log(err_log, 'walmart', 'channel_assign_category_template')

		product_code = self.get_product_code_template_channel(item_specifics)
		if not product.channel[f'channel_{self.get_channel_id()}']['template_data'].get('category'):
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['category'] = Prodict()

		product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['specifics'] = item_specifics
		if product_code:
			product.channel[f'channel_{self.get_channel_id()}'].update(product_code)

		return product

	def get_product_code_template_channel(self, item_specifics: list) -> dict:
		"""get product_code from item_specifics"""
		id_code = id_type = ''
		for spec in item_specifics:
			if spec['name'].find('productIdentifier_Product ID Code') != -1:
				id_code = spec['value']

			if spec['name'].find('productIdentifier_Product ID Type') != -1:
				id_type = spec['value']

		return { id_type.lower(): id_code } if (id_type and id_code) else {}

	def convert_catalog_value_type(self, status_changed, specific):
		"""The value and override type are json
		Convert a value from a string (a result of the func `assign_attribute_to_field`
		to right type)
		if status_changed mean the value is got from the mapping's value
		otherwise is got from override

		Walmart have 5 attributes type: string, array[string or object], number, integer, object

		"""

		def convert_string(spec_val):
			return strip_html_tag(to_str(spec_val))

		def convert_number(spec_val):
			return to_decimal(spec_val)

		def convert_integer(spec_val):
			return to_int(spec_val)

		def convert_object(spec_val):
			# TODO: convert most of the objects are measure + unit, check later
			if isinstance(spec_val, dict):
				return spec_val
			try:
				val = literal_eval(spec_val)
			except:
				val = {}
			return val

		def convert_array(spec_val):
			if isinstance(spec_val, list):
				return spec_val
			try:
				val = to_str(spec_val).split(',')
			except:
				val = ''
			return val

		if not status_changed:
			value = specific.get('override')
		else:
			try:
				spec_type = specific.get('type')
				value = locals()['convert_{}'.format(spec_type)](specific.get('value'))
			except:
				value = ''

		return value

	def get_order_by_id(self, order_id):
		params = {
			'productInfo': 'true',
			'replacementInfo': 'true'
		}
		order = self.api('orders/{}'.format(order_id), data = params)

		if order.result != Response.SUCCESS or not order['data'].get('order'):
			return Response().error()

		return Response().success(order['data']['order'])

	# currently, we do not support cancel, refund from the mainstore to the channel
	# def channel_order_cancel(self, order_id, order, current_order) -> Response:
		# def create_order_data():
		# 	nonlocal order
		# 	nonlocal current_order
		# 	order_line = list()
		# 	total_product = len(order.products)
		# 	cancel_status = 'Cancelled'
		# 	cancel_reason = 'CUSTOMER_REQUESTED_SELLER_TO_CANCEL'
		#
		# 	for product_index in range(1, total_product + 1):
		# 		order_line_add = {
		# 			'lineNumber': product_index,
		# 			'orderLineStatuses':{
		# 				'orderLineStatus': [
		# 					{
		# 						'status': cancel_status,
		# 						'cancellationReason': cancel_reason,
		# 						'statusQuantity': {
		# 							'unitOfMeasurement': 'EACH',
		# 							'amount': '1'
		# 						}
		# 					}
		# 				]
		# 			}
		# 		}
		# 		order_line.append(order_line_add)
		#
		# try:
		# 	purchase_id = order.get('id') or order.get('purchaseOrderId')
		# 	params = create_order_data()
		# 	response = self.api('orders/{}/cancel'.format(order_id), data = params, api_type = 'post')
		#
		# 	data_log = {
		# 		'param': params,
		# 		'order_id': order_id,
		# 		'purchase_id': purchase_id,
		# 		'response': response
		# 	}
		#
		# 	self.log(to_str(data_log), 'channel_order_cancel')
		#
		# 	if response.result != Response.SUCCESS or response.get('data', {}).get('errors'):
		# 		response = dict() if response is None else response
		# 		msg_res = response.get('data', {}).get('errors', {}).get('error', [{}])[0].get('description', '')
		# 		msg = 'Error when cancel a order'
		# 		self.log(msg_res or msg, 'error_channel_order_cancel')
		#
		# 		return Response().error(msg = msg_res or msg)
		#
		# 	try:
		# 		return_status = response.data["order"]["orderLines"]["orderLine"][0]["orderLineStatuses"]["orderLineStatus"][0]["status"]
		# 	except:
		# 		return_status = 'Shipped'
		# 		self.log_traceback()
		#
		# 	return_order = {'status': return_status}
		# except:
		# 	log_traceback()
		# 	return Response().error(Errors.EXCEPTION)
		#
		# return Response().success(return_order)

	def channel_order_completed(self, order_id, order: Order, current_order) -> Response:
		def get_result_status() -> dict:
			nonlocal response
			try:
				return_status = response.data["order"]["orderLines"]["orderLine"][0]["orderLineStatuses"]["orderLineStatus"][0]["status"]

			except:
				return_status = 'Shipped'
				self.log_traceback()

			return {'status': return_status}

		def create_order_data() -> dict:
			nonlocal order
			nonlocal current_order
			order_line = list()
			total_product = len(order.products)
			seller_order_id = order.id
			carrier_key = 'carrier' if order.shipments.tracking_company in self.TRACKING_COMPANY else 'otherCarrier'
			method_code_value = order.shipments.methodCode if order.shipments.methodCode in self.SHIPPING_METHOD else 'Standard'
			status_order_update = self.ORDER_STATUS.get(order.status, 'Created')
			shipped_at = self.time_to_walmart_timestamp(order.shipments.shipped_at)

			for product_index in range(1, total_product + 1):
				order_line_add = {
					'lineNumber': product_index,
					'sellerOrderId': seller_order_id,
					'orderLineStatuses': {
						'orderLineStatus': [
							{
								'status': status_order_update,
								'statusQuantity': {
									'unitOfMeasurement': 'EACH',
									'amount': '1'
								},
								'trackingInfo': {
									'shipDateTime': shipped_at,
									'carrierName': {
										carrier_key: order.shipments.tracking_company
									},
									'methodCode': method_code_value,
									'trackingNumber': order.shipments.tracking_number,
									'trackingURL': order.shipments.tracking_url
								}
							}
						]
					}
				}

				order_line.append(order_line_add)

			data = {
				'orderShipment':
					{
						'orderLines': {
							'orderLine': order_line
						}
					}
			}

			return data

		try:
			purchase_id = order.get('id') or order.get('purchaseOrderId')
			params = create_order_data()
			is_succeed: bool = False
			return_order: dict[str, str] = {'status': ''}
			for retry_ in range(3):
				time.sleep(retry_ * 15)
				response = self.api('orders/{}/shipping'.format(order_id), data = params, api_type = 'post')

				data_log = {
					'param': params,
					'order_id': order_id,
					'purchase_id': purchase_id,
					'response': response
				}
				if response.result == Response.SUCCESS:
					self.log(to_str(data_log), 'channel_order_completed')
					return_order = get_result_status()
					is_succeed = True
					break

				elif response.result != Response.SUCCESS or response.get('data', {}).get('errors'):
					self.log(to_str(data_log), 'error_channel_order_completed')
					is_succeed = False

		except:
			log_traceback()
			return Response().error(Errors.EXCEPTION)

		return Response().success(return_order) if is_succeed else Response().error()

	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if setting_order:
			return Response().success()
		# TODO: order_cancel
		return self._order_sync_inventory(order, '+')

	def order_sync_inventory(self, convert: Order, setting_order):
		# setting_order = True if self._state.channel.config.setting.get('order', {}).get('status') != 'disable' else False
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)

	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		pass

	def order_import(self, convert: Order, order: Order, orders_ext):
		pass

	def create_access_token(self) -> str:
		"""create new access token
		"""
		if not self._url_base:
			self.get_url_base()

		client_id = to_str(self._state.channel.config.api.client_id).strip()
		client_secret = to_str(self._state.channel.config.api.client_secret).strip()
		basic_auth = HTTPBasicAuth(client_id, client_secret)
		url = self._url_base + "/v3/token"
		headers = {
			"Accept": "application/json",
			"WM_QOS.CORRELATION_ID": str(uuid.uuid4()),
			"WM_CONSUMER.CHANNEL.TYPE": self.get_channel_type_key(),
			"WM_SVC.NAME": "LitCommerce",
		}
		data = {
			"grant_type": "client_credentials"
		}

		response = requests.post(url, headers = headers, data = data, auth = basic_auth)
		self._last_status = response.status_code

		if response.status_code != 200 or not json_decode(response.text):
			return ''

		response_data = json_decode(response.text)
		self._state.channel.config.api.access_token = response_data['access_token']
		self.update_channel(api = json_encode(self._state.channel.config.api))

		return response_data['access_token']

	def api(self, path, data = None, api_type = "get", version = 'v3', content_type = ''):
		if not self._url_base:
			self.get_url_base()
		access_token = self._state.channel.config.api.access_token
		if not access_token:
			access_token = self.create_access_token()
		url = self._url_base + "/" + version + "/" + path
		headers = {
			"Accept": "application/json",
			"WM_QOS.CORRELATION_ID": str(uuid.uuid4()),
			"WM_CONSUMER.CHANNEL.TYPE": self.get_channel_type_key(),
			"WM_SVC.NAME": "LitCommerce",
			"WM_SEC.ACCESS_TOKEN": access_token,
		}
		if content_type:
			headers.update({'Content-Type': content_type})

		response: Response = self.requests(url, data, method = api_type, headers = headers)

		if response.get('data') is None:
			response['data'] = Prodict()

		return response

	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']

		if mass_action == 'delete':
			self.delete_product_import(product_id)
			self.product_deleted(product['_id'], product)

		return Response().success(product_id)

	def get_draft_extend_channel_data(self, product):
		extend_data = dict()
		description_new = self.remove_attributes_except_some_tag(product.description)
		if product.description != description_new:
			extend_data['description'] = description_new

		if not product.sku and self._state.channel.config.api.auto_gen_sku:
			product.sku = ModelChannelsWalmart.random_sku(25)
		# flag: map `sku` field to `gtin`
		if product.sku and self._state.channel.config.api.sku_to_gtin:
			extend_data['gtin'] = product.sku
		if product.upc and self._state.channel.config.api.upc_to_gtin:
			extend_data['gtin'] = product.upc
		# prepare the group_id as variant_group_id
		if not product.is_variant and product.variant_count:
			extend_data['group_id'] = ModelChannelsWalmart.random_sku(20)
		return extend_data

	def get_state_code_from_name(self, name):
		if name:
			for code, state_name in self.STATES.items():
				if to_str(name).lower() == to_str(code).lower():
					return state_name
		return name

	def get_country_name_from_code(self, country_code):
		country_name = self.COUNTRIES.get(country_code, '')
		return country_name or country_code

	STATES = {'AL': 'Alabama', 'AK': 'Alaska', 'AS': 'American Samoa', 'AZ': 'Arizona', 'AR': 'Arkansas', 'AF': 'Armed Forces Africa', 'AA': 'Armed Forces Americas', 'AC': 'Armed Forces Canada', 'AE': 'Armed Forces Europe', 'AM': 'Armed Forces Middle East', 'AP': 'Armed Forces Pacific', 'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware', 'DC': 'District of Columbia', 'FM': 'Federated States Of Micronesia', 'FL': 'Florida', 'GA': 'Georgia', 'GU': 'Guam', 'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas', 'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MH': 'Marshall Islands', 'MD': 'Maryland', 'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'MP': 'Northern Mariana Islands', 'OH': 'Ohio',
	          'OK': 'Oklahoma', 'OR': 'Oregon', 'PW': 'Palau', 'PA': 'Pennsylvania', 'PR': 'Puerto Rico', 'RI': 'Rhode Island', 'SC': 'South Carolina', 'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont', 'VI': 'Virgin Islands', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming', 'AB': 'Alberta', 'BC': 'British Columbia', 'MB': 'Manitoba', 'NF': 'Newfoundland', 'NB': 'New Brunswick', 'NS': 'Nova Scotia', 'NT': 'Northwest Territories', 'NU': 'Nunavut', 'ON': 'Ontario', 'PE': 'Prince Edward Island', 'QC': 'Quebec', 'SK': 'Saskatchewan', 'YT': 'Yukon Territory', 'NDS': 'Niedersachsen', 'BAW': 'Baden-Württemberg', 'BAY': 'Bayern', 'BER': 'Berlin', 'BRG': 'Brandenburg', 'BRE': 'Bremen', 'HAM': 'Hamburg', 'HES': 'Hessen', 'MEC': 'Mecklenburg-Vorpommern', 'NRW': 'Nordrhein-Westfalen', 'RHE': 'Rheinland-Pfalz', 'SAR': 'Saarland', 'SAS': 'Sachsen', 'SAC': 'Sachsen-Anhalt', 'SCN': 'Schleswig-Holstein',
	          'THE': 'Thüringen', 'NO': 'Niederösterreich', 'OO': 'Oberösterreich', 'SB': 'Salzburg', 'KN': 'Kärnten', 'ST': 'Steiermark', 'TI': 'Tirol', 'BL': 'Burgenland', 'VB': 'Voralberg', 'AG': 'Aargau', 'AI': 'Appenzell Innerrhoden', 'BE': 'Bern', 'BS': 'Basel-Stadt', 'FR': 'Freiburg', 'GE': 'Genf', 'GL': 'Glarus', 'JU': 'Graubünden', 'LU': 'Luzern', 'NW': 'Nidwalden', 'OW': 'Obwalden', 'SG': 'St. Gallen', 'SH': 'Schaffhausen', 'SO': 'Solothurn', 'SZ': 'Schwyz', 'TG': 'Thurgau', 'UR': 'Uri', 'VD': 'Waadt', 'VS': 'Wallis', 'ZG': 'Zug', 'ZH': 'Zürich', 'A Coruña': 'A Coruña', 'Alava': 'Alava', 'Albacete': 'Albacete', 'Alicante': 'Alicante', 'Almeria': 'Almeria', 'Asturias': 'Asturias', 'Avila': 'Avila', 'Badajoz': 'Badajoz', 'Baleares': 'Baleares', 'Barcelona': 'Barcelona', 'Burgos': 'Burgos', 'Caceres': 'Caceres', 'Cadiz': 'Cadiz', 'Cantabria': 'Cantabria', 'Castellon': 'Castellon', 'Ceuta': 'Ceuta', 'Ciudad Real': 'Ciudad Real', 'Cordoba': 'Cordoba', 'Cuenca': 'Cuenca',
	          'Girona': 'Girona', 'Granada': 'Granada', 'Guadalajara': 'Guadalajara', 'Guipuzcoa': 'Guipuzcoa', 'Huelva': 'Huelva', 'Huesca': 'Huesca', 'Jaen': 'Jaen', 'La Rioja': 'La Rioja', 'Las Palmas': 'Las Palmas', 'Leon': 'Leon', 'Lleida': 'Lleida', 'Lugo': 'Lugo', 'Madrid': 'Madrid', 'Malaga': 'Malaga', 'Melilla': 'Melilla', 'Murcia': 'Murcia', 'Navarra': 'Navarra', 'Ourense': 'Ourense', 'Palencia': 'Palencia', 'Pontevedra': 'Pontevedra', 'Salamanca': 'Salamanca', 'Santa Cruz de Tenerife': 'Santa Cruz de Tenerife', 'Segovia': 'Segovia', 'Sevilla': 'Sevilla', 'Soria': 'Soria', 'Tarragona': 'Tarragona', 'Teruel': 'Teruel', 'Toledo': 'Toledo', 'Valencia': 'Valencia', 'Valladolid': 'Valladolid', 'Vizcaya': 'Vizcaya', 'Zamora': 'Zamora', 'Zaragoza': 'Zaragoza', 'ACT': 'Australian Capital Territory', 'JBT': 'Jervis Bay Territory', 'NSW': 'New South Wales', 'QLD': 'Queensland', 'SA': 'South Australia', 'TAS': 'Tasmania', 'VIC': 'Victoria', }

	COUNTRIES = {"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon",
	             "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar",
	             "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China",
	             "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen",
	             "DZ": "Algeria", "US": "United States", "USA": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India",
	             "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}
	TRACKING_COMPANY = ["UPS", "USPS", "FedEx", "Airborne", "OnTrac", "DHL Ecommerce - US" "LS", "UDS", "UPSMI", "FDX", "PILOT", "ESTES", "SAIA", "FDS Express" "Seko Worldwide" "HIT Delivery" "FEDEXSP", "RL Carriers" "Metropolitan Warehouse & Delivery" "China Post" "YunExpress", "Yellow Freight Sys" "AIT Worldwide Logistics" "Chukou1" "Sendle", "Landmark Global" "Sunyou", "Yanwen", "4PX" "GLS", "OSM Worldwide" "FIRST MILE" "AM Trucking" "CEVA", "India Post" "SF Express" "CNE", "TForce Freight" "AxleHire", "LSO"]

	SHIPPING_METHOD = ["Standard", "Express", "OneDay", "Freight", "WhiteGlove", "Value"]

	TEMPLATE_ID = {"Animal Accessories": 1, "Animal Food": 2, "Animal Health & Grooming": 3, "Animal Other": 4, "Art & Craft": 5, "Baby Diapering, Care, & Other": 6, "Baby Food": 7, "Baby Furniture": 8, "Baby Toys": 9, "Baby Transport": 10, "Beauty, Personal Care, & Hygiene": 11, "Bedding": 12, "Books & Magazines": 13, "Building Supply": 14, "Cameras & Lenses": 15, "Carriers & Accessories": 16, "Cases & Bags": 17, "Cell Phones": 18, "Ceremonial Clothing & Accessories": 19, "Clothing": 20, "Computer Components": 21, "Computers": 22, "Costumes": 23, "Cycling": 24, "Decorations & Favors": 25, "Electrical": 26, "Electronics Accessories": 27, "Electronics Cables": 28, "Electronics Other": 29, "Food & Beverage": 30, "Footwear": 31, "Fuels & Lubricants": 32, "Funeral": 33, "Furniture": 34, "Garden & Patio": 35, "Gift Supply & Awards": 36, "Grills & Outdoor Cooking": 37, "Hardware": 38, "Health & Beauty Electronics": 39, "Home Decor, Kitchen, & Other": 40,
	               "Household Cleaning Products & Supplies": 41, "Instrument Accessories": 42, "Jewelry": 43, "Land Vehicles": 44, "Large Appliances": 45, "Medical Aids & Equipment": 46, "Medicine & Supplements": 47, "Movies": 48, "Music Cases & Bags": 49, "Music": 50, "Musical Instruments": 51, "Office": 52, "Optical": 53, "Optics": 54, "Other": 55, "Photo Accessories": 56, "Plumbing & HVAC": 57, "Printers, Scanners, & Imaging": 58, "Safety & Emergency": 59, "Software": 60, "Sound & Recording": 61, "Sport & Recreation Other": 62, "Storage": 63, "TV Shows": 64, "TVs & Video Displays": 65, "Tires": 66, "Tools & Hardware Other": 67, "Tools": 68, "Toys": 69, "Vehicle Other": 70, "Vehicle Parts & Accessories": 71, "Video Games": 72, "Video Projectors": 73, "Watches": 74, "Watercraft": 75, "Wheels & Wheel Components": 76}
