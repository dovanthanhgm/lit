import copy
import io
import math
import zipfile
from io import BytesIO

import barcodenumber
import dateutil.relativedelta
import requests
from PIL import Image

from datasync.libs.errors import Errors
from datasync.libs.messages import Messages
from datasync.libs.response import Response
from datasync.libs.tracking_company import TrackingCompany
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.collections.template import Template
from datasync.models.constructs.activity import Activity
from datasync.models.constructs.ebay import *
from datasync.models.constructs.order import *
from datasync.models.constructs.product import *
from datasync.models.modes.test import ModelModesTest

try:
	from lxml.etree import Element, tostring, fromstring
except ImportError:
	from xml.etree.ElementTree import Element, tostring, fromstring


class ModelChannelsEbay(ModelChannel):
	_product_page_number: int
	_order_page_number: int
	_model_local: ModelModesTest or None
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category', 'shipping', 'business']
	EBAY_MIN_IMAGE_SIDE = 500
	TIME_FORMAT = '%Y-%m-%dT%H:%M:%S'
	INIT_INDEX_FIELDS = ['ebay_status']
	SITE_IDS = {
		'EBAY_AT': 16,
		'EBAY_AU': 15,
		'EBAY_CH': 193,
		'EBAY_DE': 77,
		'EBAY_ENCA': 2,
		'EBAY_ES': 186,
		'EBAY_FR': 71,
		'EBAY_FRBE': 23,
		'EBAY_FRCA': 210,
		'EBAY_GB': 3,
		'EBAY_HK': 201,
		'EBAY_IE': 205,
		'EBAY_IN': 203,
		'EBAY_IT': 101,
		'EBAY_MOTORS_US': 100,
		'EBAY_MY': 207,
		'EBAY_NL': 146,
		'EBAY_NLBE': 123,
		'EBAY_PH': 211,
		'EBAY_PL': 212,
		'EBAY_SG': 216,
		'EBAY_US': 0,
		'EBAY_BE': 123,
		'EBAY_CA': 2,
	}
	SITE_NAMES = {
		'EBAY_AT': 'Austria',
		'EBAY_AU': 'Australia',
		'EBAY_CH': 'Switzerland',
		'EBAY_DE': 'Germany',
		'EBAY_ENCA': 'Canada',
		'EBAY_ES': 'Spain',
		'EBAY_FR': 'France',
		'EBAY_FRBE': 'Belgium_French',
		'EBAY_FRCA': 'CanadaFrench',
		'EBAY_GB': 'UK',
		'EBAY_HK': 'HongKong',
		'EBAY_IE': 'Ireland',
		'EBAY_IN': 'India',
		'EBAY_IT': 'Italy',
		'EBAY_MOTORS_US': 'eBayMotors',
		'EBAY_MY': 'Malaysia',
		'EBAY_NL': 'Netherlands',
		'EBAY_NLBE': 'Belgium_Dutch',
		'EBAY_PH': 'Philippines',
		'EBAY_PL': 'Poland',
		'EBAY_SG': 'Singapore',
		'EBAY_US': 'US',
		'EBAY_BE': 'Belgium_Dutch',
		'EBAY_CA': 'Canada',
	}
	EBAY_CURRENCY_IDS = {
		'EBAY_US': 'USD',
		'EBAY_AT': 'EUR',
		'EBAY_AU': 'AUD',
		'EBAY_BE': 'EUR',
		'EBAY_FRBE': 'EUR',
		'EBAY_NLBE': 'EUR',
		'EBAY_CA': 'CAD',
		'EBAY_FRCA': 'CAD',
		'EBAY_ENCA': 'CAD',
		'EBAY_CH': 'CHF',
		'EBAY_DE': 'EUR',
		'EBAY_ES': 'EUR',
		'EBAY_FR': 'EUR',
		'EBAY_GB': 'GBP',
		'EBAY_HK': 'HKD',
		'EBAY_IE': 'EUR',
		'EBAY_IN': 'INR',
		'EBAY_IT': 'EUR',
		'EBAY_MY': 'MYR',
		'EBAY_NL': 'EUR',
		'EBAY_PH': 'PHP',
		'EBAY_SG': 'SGD',
		'EBAY_MOTORS_US': 100,
	}

	EBAY_LOCALE = {
		'EBAY_US': 'en-US',
		'EBAY_AT': 'de-AT',
		'EBAY_AU': 'en-AU',
		'EBAY_BE': 'fr-BE',
		'EBAY_FRBE': 'fr-BE',
		'EBAY_NLBE': 'nl-BE',
		'EBAY_CA': 'en-CA',
		'EBAY_FRCA': 'fr-CA',
		'EBAY_ENCA': 'en-CA',
		'EBAY_CH': 'de-CH',
		'EBAY_DE': 'de-DE',
		'EBAY_ES': 'es-ES',
		'EBAY_FR': 'fr-FR',
		'EBAY_GB': 'en-GB',
		'EBAY_HK': 'zh-HK',
		'EBAY_IE': 'en-IE',
		'EBAY_IN': 'en-GB',
		'EBAY_IT': 'it-IT',
		'EBAY_MY': 'en-US',
		'EBAY_NL': 'nl-NL',
		'EBAY_PH': 'en-PH',
		'EBAY_PL': 'pl-PL',
		'EBAY_SG': 'en-US',
		'EBAY_TH': 'th-TH',
		'EBAY_TW': 'zh-TW',
		'EBAY_VN': 'en-US',
		'EBAY_MOTORS_US': 'en-US',
	}


	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._product_page_number = 0
		self._order_page_number = 0
		self._shipping_service = None
		self._rate_tables = dict()
		self._custom_categories = dict()
		self._pull_active_listing = True
		self._order_max_last_modified = ''
		self._model_local = None
		self._error_return_policy = False
		self._item_group_id = dict()
		self._is_finish = False
		self._offer_data = dict()
		self._inventory_item_data = dict()
		self._inventory_group_data = dict()
		self.merchant_location_key_default = dict()
		self._ebay_condition_by_categories = dict()
		self._feed_active_listing = list()
		self._number_list_feed_active_listing = 0
		self._index_feed_active_listing = 0
		self._is_create_feed_active_product = False
		self._active_item_id = []
		self._pull_item_id_list: list = []
		self._is_pull_item_id: bool = False
		self._log_type = ''
		self._pull_category_id_list: set[str] = set()


	def get_category_conditions(self, category_id):
		conditions = dict()
		condition_request = self.api(f'sell/metadata/v1/marketplace/{self.get_marketplace_id()}/get_item_condition_policies', {'filter': f'categoryIds:{{{category_id}}}'})
		if self._last_status < 300 and condition_request:
			for condition in condition_request.get('itemConditionPolicies')[0].get('itemConditions'):
				conditions[to_str(condition.get('conditionDescription')).lower()] = condition.get('conditionId')
		return conditions


	def get_ebay_condition_by_categories(self, category_id, ebay_condition):
		if not self._ebay_condition_by_categories.get(to_int(category_id)):
			conditions = self.get_category_conditions(category_id)
			self._ebay_condition_by_categories[to_int(category_id)] = conditions
		if self._ebay_condition_by_categories[to_int(category_id)].get(to_str(ebay_condition).lower()):
			return self._ebay_condition_by_categories[to_int(category_id)].get(to_str(ebay_condition).lower())
		return False


	def is_eu(self):
		return self.get_marketplace_id() in ['EBAY_AT', 'EBAY_BE', 'EBAY_DE', 'EBAY_ES', 'EBAY_FR', 'EBAY_GB', 'EBAY_IE', 'EBAY_IT', 'EBAY_NL']


	def is_us(self):
		return self.get_marketplace_id() in ['EBAY_US']


	def is_ebay_fr(self):
		return self.get_marketplace_id() in ['EBAY_FR']


	def is_support_shipping_freight(self):
		return self.get_marketplace_id() in ['EBAY_US', 'EBAY_UK', 'EBAY_AU', 'EBAY_CA', 'EBAY_FRCA', 'EBAY_ENCA']


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier:
			if not self._order_max_last_modified:
				self._order_max_last_modified = last_modifier
				return
			date_obj = to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S")
			max_midified_obj = to_timestamp(self._order_max_last_modified, "%Y-%m-%dT%H:%M:%S")
			if date_obj > max_midified_obj:
				self._order_max_last_modified = last_modifier


	def get_rate_tables(self):
		if self._rate_tables:
			return self._rate_tables
		rate_tables = self.api('sell/account/v1/rate_table')
		if not rate_tables:
			return None
		for rate_table in rate_tables['rateTables']:
			self._rate_tables[to_int(rate_table['rateTableId'])] = rate_table['name']
		return self._rate_tables


	def get_rate_table_name(self, rate_table_id):
		rate_tables = self.get_rate_tables()
		if not rate_tables:
			return ''
		return rate_tables.get(to_int(rate_table_id))


	def get_sub_category_tree(self, category_id) -> list:
		"""get the store category and all its sub category ids"""
		def get_sub_category(sub_category_data, sub_category_id, sub_category = [], is_sub = False):
			for cat in sub_category_data:
				child_category = obj_to_list(cat.get('ChildCategory'))
				if cat['CategoryID'] == sub_category_id or is_sub:
					sub_category.append(cat['CategoryID'])
					if isinstance(child_category, list):
						get_sub_category(child_category, sub_category_id, sub_category, True)

				if isinstance(child_category, list):
					get_sub_category(child_category, sub_category_id, sub_category, False)

			return sub_category

		category_data = self.get_store_categories()
		sub_category_list = get_sub_category(category_data, to_str(category_id), [], False)

		return list(map(to_int, sub_category_list))

	def get_store_categories(self):
		body = '''<?xml version="1.0" encoding="utf-8"?>
					<GetStoreRequest xmlns="urn:ebay:apis:eBLBaseComponents">
					  <!-- This call works only for sellers with Store subscription-->    
						<ErrorLanguage>en_US</ErrorLanguage>
						<WarningLevel>High</WarningLevel>
					  <LevelLimit>3</LevelLimit>
					</GetStoreRequest>'''
		ebay_stores = self.xml_api('GetStore', body)
		try:
			categories = obj_to_list(ebay_stores['GetStoreResponse']['Store']['CustomCategories']['CustomCategory'])
		except:
			return []
		else:
			return categories


	def get_custom_categories(self):
		if self._custom_categories:
			return self._custom_categories

		categories = self.get_store_categories()
		if categories:
			categories_tree = self.get_categories_tree(categories)
			for category in categories_tree:
				self._custom_categories[to_int(category['category_id'])] = category['category_name']
		return self._custom_categories


	def get_categories_tree(self, categories):
		categories = obj_to_list(categories)
		custom_categories = []
		for category in categories:
			category_data = {
				'category_id': category['CategoryID'],
				'category_name': category['Name']
			}
			if category.get('ChildCategory'):
				trees = self.get_categories_tree(category.get('ChildCategory'))
				custom_categories.extend(trees)

			custom_categories.append(category_data)
		if custom_categories:
			custom_categories.sort(key = lambda x: x['category_name'])
		return custom_categories

	def get_custom_category_name(self, category_id):
		category_id = to_int(category_id)
		if self._state.channel.config.custom_categories:
			for sub_category, parent_id in self._state.channel.config.custom_categories.items():
				if to_int(sub_category) == category_id:
					category_id = parent_id
					break
		custom_categories = self.get_custom_categories()

		return category_id, html_unescape(custom_categories.get(category_id, ''))


	def get_api_info(self):
		"""
		Information required to make an API call
		"""
		return {
			'ebay_username': 'Ebay Username',
			'marketplace': 'Marketplace',
			'access_token': 'Access token',
			'refresh_token': 'Refresh_token',
		}


	def get_api_access_token(self):
		return self._state.channel.config.api.access_token


	def get_api_marketplace(self):
		if get_config_ini('ebay', 'marketplace'):
			return get_config_ini('ebay', 'marketplace')
		else:
			return self._state.channel.config.api.marketplace


	def get_ebay_host(self):
		return 'ebay.com' if self.get_app_mode() == 'production' else 'sandbox.ebay.com'


	def get_refresh_token(self):
		return self._state.channel.config.api.refresh_token


	def get_app_mode(self):
		app_mode = self._state.channel.config.api.app_mode
		if not app_mode:
			return get_config_ini('ebay', 'mode')
		return app_mode


	def get_product_import_mode(self):
		return get_config_ini('ebay', 'product_import')


	def get_client_id(self):
		client_id = self._state.channel.config.api.client_id
		if not client_id:
			return get_config_ini('ebay', 'client_id')
		return client_id


	def get_client_secret(self):
		client_secret = self._state.channel.config.api.client_secret
		if not client_secret:
			return get_config_ini('ebay', 'client_secret')
		return client_secret


	def refresh_access_token(self):
		url = f"{self.get_api_endpoint()}/identity/v1/oauth2/token"
		authorization = string_to_base64(f"{self.get_client_id()}:{self.get_client_secret()}")
		headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			"Authorization": f"Basic {authorization}"
		}
		payload = {
			'grant_type': 'refresh_token',
			'refresh_token': self.get_refresh_token(),
			'scope': "https://api.ebay.com/oauth/api_scope https://api.ebay.com/oauth/api_scope/sell.marketing.readonly https://api.ebay.com/oauth/api_scope/sell.marketing https://api.ebay.com/oauth/api_scope/sell.inventory.readonly https://api.ebay.com/oauth/api_scope/sell.inventory https://api.ebay.com/oauth/api_scope/sell.account.readonly https://api.ebay.com/oauth/api_scope/sell.account https://api.ebay.com/oauth/api_scope/sell.fulfillment.readonly https://api.ebay.com/oauth/api_scope/sell.fulfillment https://api.ebay.com/oauth/api_scope/sell.analytics.readonly https://api.ebay.com/oauth/api_scope/sell.finances https://api.ebay.com/oauth/api_scope/sell.payment.dispute https://api.ebay.com/oauth/api_scope/commerce.identity.readonly"
		}
		res = requests.request(method = 'post', url = url, data = payload, headers = headers)
		if res.status_code != 200:
			self.channel_disconnected()
			return False
		self._state.channel.config.api.access_token = res.json()['access_token']
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return res.json()['access_token']


	def get_api_endpoint(self):
		return 'https://api.ebay.com' if self.get_app_mode() == 'production' else 'https://api.sandbox.ebay.com'


	def get_apiz_endpoint(self):
		return 'https://apiz.ebay.com' if self.get_app_mode() == 'production' else 'https://apiz.sandbox.ebay.com'


	def get_apim_endpoint(self):
		return 'https://apim.ebay.com' if self.get_app_mode() == 'production' else 'https://apim.sandbox.ebay.com'


	def get_xml_endpoint(self):
		return 'https://api.ebay.com/ws/api.dll' if self.get_app_mode() == 'production' else 'https://api.sandbox.ebay.com/ws/api.dll'


	def get_compatibility_level(self):
		return get_config_ini('ebay', 'compatibility_level', '1227')


	def get_currency_code(self):
		if self._state.channel.config.api.currency:
			return self._state.channel.config.api.currency
		return self.EBAY_CURRENCY_IDS.get(self.get_marketplace_id(), False)


	def is_same_site(self, site):
		ebay_site = self.SITE_NAMES.get(self.get_marketplace_id())
		if ebay_site == site:
			return True
		if site in ['US', 'eBayMotors'] and self.get_marketplace_id() in ['EBAY_US', 'EBAY_MOTORS_US']:
			return True
		if site in ['Canada', 'CanadaFrench'] and self.get_marketplace_id() in ['EBAY_CA', 'EBAY_ENCA', 'EBAY_FRCA']:
			return True
		return False


	def get_locale(self):
		return self.EBAY_LOCALE.get(self.get_marketplace_id(), 'en-US')


	def get_site_id(self):
		return self.SITE_IDS.get(self.get_marketplace_id())


	def get_marketplace_id(self):
		marketplace_id = self._state.channel.config.api.marketplace_id
		if not marketplace_id or not self.SITE_IDS.get(marketplace_id):
			return 'EBAY_US'
		return marketplace_id


	def get_country(self):
		marketplace_id = self.get_marketplace_id()
		return marketplace_id.replace('EBAY_', '')


	def xml_api(self, action, body, custom_headers = None, retry = False, site_id = None, time_retry = 0, files = False):
		if not site_id:
			site_id = self.get_site_id()
		headers = {
			'X-EBAY-API-COMPATIBILITY-LEVEL': to_str(self.get_compatibility_level()),
			'X-EBAY-API-CALL-NAME': action,
			'X-EBAY-API-SITEID': to_str(site_id),
			'X-EBAY-API-IAF-TOKEN': self.get_api_access_token()
		}
		if custom_headers:
			headers.update(custom_headers)
		response = requests.post(self.get_xml_endpoint(), data = body.encode('utf-8') if isinstance(body, str) else body, headers = headers, files = files)
		if response.status_code != 200:
			self.log_for_channel(action, 'post', response.status_code, action)
			return False
		try:
			content = response.content.decode('utf8')
		except Exception as e:
			content = response.text
		response_data = xml_to_dict(content)
		if not response_data:
			self.log_for_channel(action, 'post', content, action)
			return False
		self.log_for_channel(action, 'post', response_data.get(f'{action}Response').get('Ack'), action)

		if response_data.get(f'{action}Response'):
			if response_data.get(f'{action}Response').get('Errors'):
				errors = obj_to_list(response_data.get(f'{action}Response').get('Errors'))
				if response_data.get(f'{action}Response').get('Ack') == 'Failure' or self.is_log():
					self.log_request_error(self.get_xml_endpoint(), body = body, action = action, response = response_data, siteid = site_id)

				msg_errors = list()
				all_error = list()
				for error in errors:
					error_code = to_int(error.get('ErrorCode'))
					if error_code == 240 and response_data.get(f'{action}Response').get('Message'):
						msg_errors.append(nl2br(self.strip_html_from_description(response_data.get(f'{action}Response').get('Message'))))
						break
					if error_code == 21916711 and error.get('SeverityCode') == 'Error':
						self._error_return_policy = True
					if error_code in [21919456, 21917236, 21916618, 21916619, 21920270] or (error_code in all_error and error_code not in [21919302, 21919301]) or error.SeverityCode == 'Warning':
						continue
					all_error.append(error_code)
					if error_code == 518:
						# self.send_email(subject = "Ebay exceeded api limit", content_mail = f"Channel id {self.get_channel_id()}: ebay exceeded api limit")
						self.set_action_stop(True)
						if time_retry == 0:
							notification_data = {
								'code': 'ebay_rate_limit',
								'activity_type': 'ebay_rate_limit',
								'description': 'Ebay rate limit',
								'date_requested': self._date_requested,
								'result': Activity.FAILURE,
								'content': Messages.EBAY_RATE_LIMIT
							}
							self.create_activity_notification(**notification_data)
						if time_retry < 100:
							time_retry += 1
							time.sleep(time_retry * 15 * 60)
							return self.xml_api(action, body, custom_headers, retry, site_id, time_retry)
					if error_code in [21916984, 21917053]:
						if retry:
							self.set_action_stop(True)
							return Prodict(**response_data)
						access_token = self.refresh_access_token()
						if not access_token:
							self.set_action_stop(True)
							return xmltodict.parse(response.text)
						self.get_model_state().update(self._state.get('_id'), {"channel.config.api.access_token": access_token})
						self._state.channel.config.api.access_token = access_token
						return self.xml_api(action, body, custom_headers, True)
					if hasattr(self, f'error_code_{error_code}'):
						data = xml_to_dict(body)
						try:
							long_msg = getattr(self, f'error_code_{error_code}')(error, data[f"{action}Request"])
						except Exception as e:
							log_traceback()
							long_msg = ''
						if long_msg:
							error['LongMessage'] = long_msg
					msg_errors.append(error['LongMessage'])
				# if msg_errors:
				# 	self.log_request_error(self.get_xml_endpoint(), body = body, action = action, response = response_data)

				errors_long_msg = [to_str(msg).replace('Please check API documentation.', '') for msg in msg_errors]

				response_data['msg_errors'] = "\n".join(errors_long_msg)
		return Prodict(**response_data)


	def api(self, path, data = None, method = 'get', **kwargs):
		response = self._api(path, data, method, **kwargs)
		retry = 0
		while self._last_status == 500 and retry < 5:
			time.sleep(5 - retry)
			response = self._api(path, data, method, **kwargs)
			retry += 1
		try:
			return Prodict.from_dict(response.json())
		except Exception:
			return False


	def _api(self, path, data = None, method = 'get', **kwargs):
		endpoint = self.get_api_endpoint()
		path = path.strip('/')
		method = method.lower()
		if kwargs.get('endpoint'):
			endpoint = kwargs['endpoint'].strip('/')
		url = endpoint + '/' + path
		token = self.get_api_access_token()
		headers = {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'Content-Language': self.get_locale(),
			'Authorization': f'Bearer {token}'
		}
		if kwargs.get('headers'):
			headers.update(kwargs.get('headers'))
		request_options = {
			'headers': headers,
		}
		if method.lower() == 'get' and data:
			request_options['params'] = data
		if method.lower() in ['post', 'put'] and data:
			if kwargs.get('headers') and kwargs['headers'].get('Content-Type') and kwargs['headers'].get('Content-Type') == 'application/octet-stream':
				request_options['data'] = data
			else:
				request_options['json'] = data
		response = requests.request(method, url, **request_options)
		self._last_status = response.status_code
		self._last_header = response.headers
		if response.status_code > 204 or self.is_log():
			try:
				response_data = response.json()
			except Exception:
				response_data = response.text
			self.log_request_error(url, data = data, response = response_data, status_code = response.status_code, method = method, log_type = self._log_type or 'request')
		if response.status_code == 401:
			token = self.refresh_access_token()
			if not token:
				self.set_action_stop(True)
				return response
			# self.get_model_state().update(self._state.get('_id'), {"channel.config.api.access_token": token})
			self._state.channel.config.api.access_token = token
			headers['Authorization'] = f'Bearer {token}'
			response = requests.request(method, url, **request_options)
			self._last_status = response.status_code
			if response.status_code == 401:
				# self.send_email(subject = "Ebay exceeded api limit", content_mail = f"Channel id {self.get_channel_id()}: ebay exceeded api limit")
				self.set_action_stop(True)
				return response
			return response
		else:
			return response


	def check_response_import(self, response):
		if response.status_code == 204:
			return Response().success()
		response_data = response.json()
		if response_data.get('errors'):
			messages = []
			for error in response_data['errors']:
				error_code = to_str(error.get('errorId'))
				error_message = error.get('message', '')
				long_error_message = error.get('longMessage', '')
				error_parameters = duplicate_field_value_from_list(error.get('parameters', []), 'value')
				message = ' - '.join([error_code, error_message, long_error_message, *error_parameters])
				messages.append(message)
			return Response().error(msg = '_lic_nl_'.join(messages))
		else:
			return Response().success(data = response_data)


	@classmethod
	def clean_empty_data(cls, data):
		if not isinstance(data, dict):
			return data
		tmp = {}
		for key, value in data.items():
			if isinstance(value, dict):
				value = cls.clean_empty_data(value)
			if isinstance(value, dict) and len(value) == 1 and list(value)[0] in ['unit', 'currency']:
				continue
			if isinstance(value, list) and not all(value):
				continue
			if value:
				tmp[key] = value
		return tmp


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		account_info = self.api('commerce/identity/v1/user/', endpoint = self.get_apiz_endpoint())
		# order1 = self.get_product_by_id('285306149706')
		# order2 = self.get_order_by_id('23-10911-62858')
		# order_ext = self.get_orders_ext_export([order2['data']])
		# convert1 = self._convert_product_export(order1['data'], order_ext['data'])
		# convert2 = self.convert_order_export(order2['data'], order_ext['data'])
		if not account_info:
			return Response().error(msg = 'Cannot connect Ebay API server. API invalid.')
		try:
			if account_info.errors:
				error_msg = account_info.errors[0].get('longMessage') or account_info.errors[0].get('message')
				return Response().error(msg = f'Cannot connect Ebay API server. {error_msg}')
			if not account_info.userId:
				return Response().error(msg = 'Cannot connect Ebay API server. API invalid.')
		except Exception:
			return Response().error(msg = 'Cannot connect Ebay API server. API invalid.')
		return Response().success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(f"{self._state.channel.config.api.ebay_username}-{self.get_marketplace_id()}")
		return Response().success()


	def clear_channel_products(self):
		skus = []
		limit = 200
		offset = 0
		product_response = self.api(f'sell/inventory/v1/inventory_item?limit={limit}&offset={offset}')
		check_product_response = self.check_response_import(product_response)
		if check_product_response.result != Response().SUCCESS:
			return check_product_response
		product_data = check_product_response.data
		total = product_data['total']
		offset += product_data['size']
		skus.extend(duplicate_field_value_from_list(product_data.get('inventoryItems', []), 'sku'))
		while len(skus) < total:
			product_response = self.api(f'sell/inventory/v1/inventory_item?limit={limit}&offset={offset}')
			check_product_response = self.check_response_import(product_response)
			if check_product_response.result != Response().SUCCESS:
				break
			product_data = check_product_response.data
			skus.extend(duplicate_field_value_from_list(product_data.get('inventoryItems', []), 'sku'))
			offset += len(product_data['size'])
		for sku in skus:
			clear_response = self.api(f'sell/inventory/v1/inventory_item/{sku}', method = 'delete')
			check_clear_response = self.check_response_import(clear_response)
			if check_clear_response.result != Response().SUCCESS:
				self.log(f'Clear product SKU: {sku} ' + to_str(check_clear_response.msg), 'clear_channel_products')
		return Response().success()


	def get_products_xml_body(self, page_number = 1, limit = 100):
		body = f'''<?xml version="1.0" encoding="utf-8"?>
		<GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">
		  <ActiveList>
		    <Sort>TimeLeft</Sort>
		    <Pagination>
		      <EntriesPerPage>{limit}</EntriesPerPage>
		      <PageNumber>{page_number}</PageNumber>
		    </Pagination>
		  </ActiveList>
		</GetMyeBaySellingRequest>'''
		return body


	def api_get_products(self, page_number = 1, limit = 100):
		extend = ''
		if self.is_refresh_process():
			extend = '''<DetailLevel>ReturnAll</DetailLevel>'''
		body = f'''<?xml version="1.0" encoding="utf-8"?>
				<GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">
				  <ActiveList>
				    <Sort>TimeLeft</Sort>
				    <Pagination>
				      <EntriesPerPage>{limit}</EntriesPerPage>
				      <PageNumber>{page_number}</PageNumber>
				    </Pagination>
				  </ActiveList>
					{extend}
				</GetMyeBaySellingRequest>'''
		return self.xml_api('GetMyeBaySelling', body)


	def api_get_ended_products(self, page_number = 1, limit = 100):
		extend = ''
		if self.is_refresh_process():
			extend = '''<DetailLevel>ReturnAll</DetailLevel>'''
		body = f'''<?xml version="1.0" encoding="utf-8"?>
				<GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">
				  <UnsoldList>
				    <Pagination>
				      <EntriesPerPage>{limit}</EntriesPerPage>
				      <PageNumber>{page_number}</PageNumber>
				    </Pagination>
				  </UnsoldList>
					{extend}

				</GetMyeBaySellingRequest>'''
		return self.xml_api('GetMyeBaySelling', body)


	def get_order_filter(self):
		start_time = self.get_order_start_time('iso').replace('Z', '.000Z')
		last_modifier = self._state.pull.process.orders.max_last_modified
		filter_order = {}
		if not last_modifier:
			filter_order['creationdate'] = start_time
		else:
			start_obj = to_timestamp(start_time, "%Y-%m-%dT%H:%M:%S")
			modified_obj = to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S")
			date_filter_obj = start_obj if start_obj > modified_obj else modified_obj
			date_filter = convert_format_time(date_filter_obj, new_format = "%Y-%m-%dT%H:%M:%S.000Z")
			self.set_order_max_last_modifier(date_filter)
			filter_order['lastmodifieddate'] = date_filter
		return filter_order


	def get_feed_active_listing(self):
		task = self.api('sell/feed/v1/inventory_task', data = {
			"schemaVersion": "1.0",
			"feedType": "LMS_ACTIVE_INVENTORY_REPORT"
		}, method = 'post')

		if self._last_status > 300:
			return 0
		self._is_create_feed_active_product = True
		location = self._last_header.get('location')
		task_id = location.split('/')[-1]
		index = 0
		while index < 20:
			task = self.api(f'sell/feed/v1/task/{task_id}')
			if task['status'] == 'COMPLETED':
				break
			index += 1
			time.sleep(min(index * 2, 120))
		result_file = self._api(f'sell/feed/v1/task/{task_id}/download_result_file', headers = {'Accept': '*/*'})
		z = zipfile.ZipFile(io.BytesIO(result_file.content))
		content = xml_to_dict(z.read(z.filelist[0].filename))
		sku_details = obj_to_list(content['BulkDataExchangeResponses']['ActiveInventoryReport']['SKUDetails'])
		products = list()
		for product in sku_details:
			price = product.BuyItNowPrice or product.Price
			if self.get_currency_code() and price and price.get('@currencyID') not in self.get_currency_code().split(','):
				continue
			products.append(product)
		self._feed_active_listing = split_list(products, 200)
		self._number_list_feed_active_listing = to_len(self._feed_active_listing)
		return to_len(products)


	def pull_items_id(self) -> int:
		"""get items_id and return the total of the list"""
		item_list = to_str(self._request_data.get('item_ids')).split(',')
		if item_list:
			self._is_pull_item_id = True

		self._pull_item_id_list = [{'ItemID': item_id.strip()} for item_id in item_list][:100]
		return len(item_list)


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			total = 0
			if self._request_data.get('item_ids'):
				total = self.pull_items_id()

			if self._request_data.get('store_categories'):
				store_category = to_str(self._request_data.get('store_categories')).split(',')[0]
				self._pull_category_id_list = set(self.get_sub_category_tree(store_category))

			if not self._is_pull_item_id and not self.is_refresh_process():
				try:
					total = self.get_feed_active_listing()
				except:
					self.log_traceback()
					total = 0
			if not self._is_pull_item_id and not self._is_create_feed_active_product:
				product_response = self.api_get_products()
				try:
					total = to_int(product_response.GetMyeBaySellingResponse.ActiveList.PaginationResult.TotalNumberOfEntries)
				except:
					self.log_traceback()
					total = 0
			self._state.pull.process.products.total = total
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.id_src = 0
			self._state.pull.process.products.page_number = 0
			self._state.pull.process.products.ended_page_number = 0
			if not self._is_pull_item_id and self.is_import_inactive():
				product_response = self.api_get_ended_products()
				try:
					total_ended = to_int(product_response.GetMyeBaySellingResponse.UnsoldList.PaginationResult.TotalNumberOfEntries)
				except:
					total_ended = 0
				self._state.pull.process.products.total += total_ended
		# if self._state.pull.process.products.total >= 25000:
		# 	self._state.pull.process.products.total = -1
		if self.is_order_process():
			# start_time = self.get_order_start_time('iso')
			# last_modifier = self._state.pull.process.orders.max_last_modified
			# filter_order = {}
			# if not last_modifier:
			# 	filter_order['creationdate'] = start_time
			# else:
			# 	filter_order['lastmodifieddate'] = last_modifier
			order_process = self.api_get_orders(1, 0)
			try:
				total_order = -1 if to_int(order_process.total) else 0
			except:
				total_order = 0

			self._state.pull.process.orders.total = total_order
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.id_src = 0
			self._state.pull.process.orders.page_number = 0
			self._state.pull.process.orders.ended_page_number = 0

		return Response().success()


	def product_data_to_xml(self, product_data):
		pass


	def is_ebay_motors_us(self, category_id, category_name):
		marketplace_id = self.get_marketplace_id()
		if marketplace_id != 'EBAY_US':
			return False
		if category_name:
			category_parent = to_str(category_name).split('>')[0]
			if category_parent.strip() == 'eBay Motors':
				return True
			return False
		category = self.get_model_local().select_row('merchant_ebay_category', {'category_id': category_id, 'marketplace': 'EBAY_US'})
		if not category:
			return False
		path_id = to_str(category['path_id']).split('>')[0]
		return to_int(path_id.strip()) == 6000


	def product_import(self, convert: Product, product, products_ext):
		# TODO: Shipping, Payment and Return template
		shipping_template = product.get('template_data', {}).get('shipping')
		payment_template = product.get('template_data', {}).get('payment')
		price_template = product.get('template_data', {}).get('price')
		category_template = product.get('template_data', {}).get('category')
		business_template = BusinessTemplate.from_dict(product.get('template_data', {}).get('business', Prodict()))
		is_business_template = False
		if business_template:
			is_business_template = True
			policy_map = {
				'payment': 'payment',
				'return': 'return',
				'fulfillment': 'shipping'
			}
			for policy_key, policy_type in policy_map.items():
				if not business_template.get(f'{policy_key}_policy') or not business_template[f'{policy_key}_policy'][f'{policy_key}_policy_id']:
					is_business_template = False
					break
		have_payment = bool(payment_template or business_template.item_location)
		if not have_payment and not is_business_template:
			return Response().error(Errors.EBAY_PAYMENT_REQUIRED)
		if not shipping_template and not is_business_template:
			return Response().error(Errors.EBAY_SHIPPING_REQUIRED)
		if not category_template or not category_template.get('primary_category') or not category_template.primary_category.get('category_id'):
			return Response().error(Errors.EBAY_CATEGORY_REQUIRED)
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		category_id = category_template.primary_category.category_id
		category_name = category_template.primary_category.category_name
		marketplace_id = self.get_marketplace_id()

		# TODO: createOrReplaceInventoryItem
		if listing_type in ['Auction', 'Chinese']:
			import_method = 'AddItem'
		else:
			import_method = 'AddFixedPriceItem'
		product_data_convert = self.product_to_ebay_data(product, insert = True)
		if product_data_convert.result != Response.SUCCESS:
			return product_data_convert
		product_data, main_images, delete_fields = product_data_convert.data
		if self.get_product_import_mode() != 'production':
			import_method = f"Verify{import_method}"
		product_xml = self.dict_to_xml_product_body(import_method, {
			'Item': product_data
		})
		if self.is_log():
			self.log(product_xml, 'product_xml')
		kwargs = {
			'action': import_method,
			'body': product_xml
		}
		if self.is_ebay_motors_us(category_id, category_name):
			kwargs['site_id'] = 100
		product_response = self.xml_api(**kwargs)
		response = product_response.get(f'{import_method}Response')
		if not response:
			return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		if self._error_return_policy and not response.ItemID:
			self._error_return_policy = False
			del product_data['ReturnPolicy']
			product_xml = self.dict_to_xml_product_body(import_method, {
				'Item': product_data
			})
			kwargs['body'] = product_xml
			product_response = self.xml_api(**kwargs)
			response = product_response.get(f'{import_method}Response')
			if not response:
				return Response().error(code = Errors.EBAY_NOT_RESPONSE)

		if response.ItemID:
			if product.variants:
				copy_insert_map = copy.deepcopy(self._extend_product_map)
				self._extend_product_map = dict()
				specifics_name = list()
				for specific in category_template.specifics:
					# if specific.value:
					specifics_name.append(specific.name)
				for variant in product.variants:
					for attribute in variant.attributes:
						attribute.attribute_name = self.get_variant_attribute_name(attribute.attribute_name, specifics_name)
					variant_id = self.variant_key_generate(variant)
					self.insert_map_product(variant, variant['_id'], f"{response.ItemID}-{variant_id}")
				self._extend_product_map = copy_insert_map
			return Response().success(response.ItemID)
		try:
			errors = obj_to_list(response.get('Errors'))
			for error in errors:
				if to_int(error['ErrorCode']) == 37 and 'Item.Country' in error['LongMessage']:
					if not is_business_template:
						return Response().error(msg = 'PAYMENT_ITEM_LOCATION')
					return Response().error(msg = 'BUSINESS_ITEM_LOCATION')

				if to_int(error['ErrorCode']) == 21919137:
					image_error = []
					params = obj_to_list(error['ErrorParameters'])
					for param in params:
						if param['Value'] in main_images:
							image_error.append(main_images[param['Value']])
					return_error = {
						'msg': 'Your product contains images that are too small in size. Ebay requires images with the longest side size of 500 pixels. Please replace the images that are too small, or hover over the faulty images to remove them from the product before uploading the product to ebay.',
						'images': image_error
					}
					return Response().error(msg = json_encode(return_error))
		except:
			self.log_traceback()
			pass
		msg_errors = product_response.get('msg_errors')
		msg_errors = to_str(msg_errors).replace('contact us', 'contact eBay support')
		return Response().error(msg = msg_errors)


	def to_ebay_price(self, product: Product):
		if not self._state.channel.config.api.custom_price or not self.is_special_price(product):
			return product.price
		return product.special_price.price


	def error_code_37(self, error, data):
		parameter = error.ErrorParameters.Value
		fields = parameter.split('.')
		value_error = data
		for field in fields:
			value_error = value_error.get(field)
		if not isinstance(value_error, (str, int, float)):
			return ''
		return f"The value of {'.'.join(fields[1:])}: {value_error} is invalid"


	# def error_code_240(self, error, data):
	# 	return f"You’ve exceeded the number of items and amount you can list. {url_to_link('https://www.ebay.com/help/selling/listings/selling-limits?id=4107', 'Learn about selling limits')} or {'https://scgi.ebay.com/ws/eBayISAPI.dll?UpgradeLimits', 'request higher selling limits'}"

	def image_in_ebay(self, url):
		if to_str(url).find('i.ebayimg.com') != -1:
			return True
		return False


	def skip_small_image(self):
		return self._state.channel.config.api.skip_small_image


	def skip_upload_image(self):
		return self._state.channel.config.api.skip_upload_image or is_local()

	def resize_image(self, image_url):
		try:
			r = False
			retry = 0
			while r is False and retry < 3:
				try:
					r = requests.get(image_url, verify = False)
				except Exception as e:
					time.sleep(1)
					retry += 1
					r = False
					if retry == 1:
						self.log_traceback("ebay_image_resize")
			if not r or r.status_code != 200:
				self.log_traceback("ebay_image_resize")
				return False
			is_png = False
			if r.headers.get('content-type') == 'image/png':
				is_png = True
			image_data = BytesIO(r.content)
			# Open the image using Pillow
			original_image = Image.open(image_data)
			# Auto convert to RGB mode
			width, height = original_image.size
			new_width = max(width, self.EBAY_MIN_IMAGE_SIDE)
			new_height = max(height, self.EBAY_MIN_IMAGE_SIDE)
			x_offset = (new_width - original_image.width) // 2
			y_offset = (new_height - original_image.height) // 2
			new_image = Image.new("RGB" if not is_png else "RGBA", (new_width, new_height), "WHITE")
			new_image.paste(original_image, (x_offset, y_offset))
			image_b64 = self.convert_image_file_to_base64(new_image, is_png)
			return image_b64
		except Exception as e:
			self.log_traceback('ebay_resize_images', f"image error: {image_url}")
			return False

	def convert_image_file_to_base64(self, image, is_png = False):
		try:
			buffered = BytesIO()
			image.save(buffered, format = "JPEG" if not is_png else "PNG")
			img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
			return img_str
		except:
			self.log_traceback()
			return None

	def upload_site_hosted_pictures(self, url, retry = 0, product: Product = None):
		if self.skip_upload_image():
			return url
		real_url = url
		if not retry:
			# url = to_str(url).split('?')[0]
			url = urllib.parse.quote(url, safe = ':/?=&')
			if self.skip_small_image():
				height, width = self.get_image_size(real_url)
				if height and width and height < 500 and width < 500:
					self.log(f'{product["_id"]}: image {real_url} error with height {height} and width {width}', 'image_error')
					return False
		height, width = self.get_image_size(real_url)
		files = False
		if height and width and (height < self.EBAY_MIN_IMAGE_SIDE or width < self.EBAY_MIN_IMAGE_SIDE):
			image_b64 = self.resize_image(real_url)
			xml_body = f'''<?xml version="1.0" encoding="utf-8"?>
				<UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">    
					<ErrorLanguage>en_US</ErrorLanguage>
					<WarningLevel>High</WarningLevel>
				</UploadSiteHostedPicturesRequest>
				'''
			files = {'file': base64.b64decode(image_b64)}
			xml_body = { "XML Payload": xml_body.encode("UTF-8") }
		else:
			xml_body = f'''<?xml version="1.0" encoding="utf-8"?>
	<UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">    
		<ErrorLanguage>en_US</ErrorLanguage>
		<WarningLevel>High</WarningLevel>
	  <ExternalPictureURL><![CDATA[{real_url}]]></ExternalPictureURL>
	</UploadSiteHostedPicturesRequest>
	'''
		image = self.xml_api('UploadSiteHostedPictures', xml_body, files = files)
		if image and image.get(f'UploadSiteHostedPicturesResponse') and image['UploadSiteHostedPicturesResponse'].get('SiteHostedPictureDetails') and image['UploadSiteHostedPicturesResponse']['SiteHostedPictureDetails'].get('FullURL'):
			image_url = re.sub('/\$_([0-9]+).', '/$_10.', image['UploadSiteHostedPicturesResponse']['SiteHostedPictureDetails'].get('FullURL'))
			return image_url
		if retry >= 5:
			return False
		retry += 1
		time.sleep(retry * 1)
		return self.upload_site_hosted_pictures(url, retry)


	# url = f'{self.URL_IMAGE_PROXY}{url}'
	#
	# xml_body = f'''<?xml version="1.0" encoding="utf-8"?>
	# <UploadSiteHostedPicturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
	# 	<ErrorLanguage>en_US</ErrorLanguage>
	# 	<WarningLevel>High</WarningLevel>
	#   <ExternalPictureURL>{url}</ExternalPictureURL>
	# </UploadSiteHostedPicturesRequest>
	# '''
	# image = self.xml_api('UploadSiteHostedPictures', xml_body)
	# if image and image.get(f'UploadSiteHostedPicturesResponse') and image['UploadSiteHostedPicturesResponse'].get('SiteHostedPictureDetails') and image['UploadSiteHostedPicturesResponse']['SiteHostedPictureDetails'].get('FullURL'):
	# 	image_url = re.sub('/\$_([0-9]+).', '/$_10.', image['UploadSiteHostedPicturesResponse']['SiteHostedPictureDetails'].get('FullURL'))
	# 	return image_url
	# return url

	def error_code_21916585(self, error, data):
		parameter = error.ErrorParameters.Value
		return f"SKU {parameter} is being used for many variations. Make sure the SKU for each variant is unique."


	def is_use_stp(self, product):
		return self._state.channel.config.setting.get('price', {}).get('use_stp') == 'enable' or (product and product.channel_data and product.channel_data.use_stp) or (product.channel.get(f'channel_{self.get_channel_id()}') and product.channel[f'channel_{self.get_channel_id()}'].get('use_stp'))


	def convert_weight(self, product: Product):
		weight_major_unit = 'lbs' if not product.weight_major_unit else product.weight_major_unit
		weight_major = to_decimal(product.weight_major, 2) if product.weight_major else 0
		weight_minor_unit = 'oz' if weight_major_unit == 'lbs' else 'gr'
		weight_minor = to_decimal(product.weight_minor, 2) if product.weight_minor else 0
		if weight_major_unit != 'lbs' and self.is_us():
			weight_major_unit = 'lbs'
			weight_minor_unit = 'oz'
			weight_major = to_decimal(weight_major) * 2.2046
			weight_minor = to_decimal(weight_minor) * 0.0352739619
		weight_multiple = 16 if weight_major_unit == 'lbs' else 1000

		extend_weight_minor = weight_major - math.floor(weight_major)
		weight_major = math.floor(weight_major)
		weight_minor += extend_weight_minor * weight_multiple
		weight_minor = math.ceil(weight_minor)
		while weight_minor >= weight_multiple:
			weight_major += 1
			weight_minor -= weight_multiple
		return weight_major, weight_major_unit, weight_minor, weight_minor_unit


	def product_to_ebay_data(self, product: Product, insert = False, ebay_variant_attributes = None):
		delete_fields = []
		product_name = self.strip_html_from_description(product.name)
		if self._state.channel.config.api.auto_cut_name:
			product_name = self.title_cutting(product_name, 80)
		if to_len(product_name) > 80:
			return Response().error(Errors.EBAY_NAME)
		# TODO: Shipping, Payment and Return template
		shipping_template = ShippingTemplate.from_dict(product.get('template_data', {}).get('shipping', Prodict()))
		payment_template = PaymentTemplate.from_dict(product.get('template_data', {}).get('payment', Prodict()))
		price_template = product.get('template_data', {}).get('price')
		category_template = product.get('template_data', {}).get('category')
		business_template = BusinessTemplate.from_dict(product.get('template_data', {}).get('business', Prodict()))
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		item_location = PaymentItemLocation.from_dict(payment_template.get('item_location'))
		if business_template.item_location:
			item_location = PaymentItemLocation.from_dict(business_template.item_location)

		# TODO: createOrReplaceInventoryItem
		product_data = dict()
		product_data['AutoPay'] = True if payment_template.auto_pay == PaymentTemplate.ENABLE else False
		product_data['DispatchTimeMax'] = payment_template.handling_time
		buyer_requirement_details = dict()
		if payment_template.buyer_requirements and payment_template.buyer_requirements.status == PaymentTemplate.ENABLE:
			if payment_template.buyer_requirements.maximum_item_requirements.status == PaymentTemplate.ENABLE:
				buyer_requirement_details['MaximumItemRequirements'] = {
					'MaximumItemCount': to_int(payment_template.buyer_requirements.maximum_item_requirements.count),
					'MinimumFeedbackScore': to_int(payment_template.buyer_requirements.maximum_item_requirements.feedback),
				}
			if payment_template.buyer_requirements.maximum_unpaid_item_strikes.status == PaymentTemplate.ENABLE:
				buyer_requirement_details['MaximumUnpaidItemStrikesInfo'] = {
					'Count': to_int(payment_template.buyer_requirements.maximum_unpaid_item_strikes.count),
					'Period': payment_template.buyer_requirements.maximum_unpaid_item_strikes.period,
				}
			buyer_requirement_details['ShipToRegistrationCountry'] = to_bool(payment_template.buyer_requirements.ship_to_registration_country)
		product_data['BuyerRequirementDetails'] = buyer_requirement_details
		product_data['DisableBuyerRequirements'] = True if payment_template.buyer_requirements.status == PaymentTemplate.DISABLE else False
		product_data['ProductListingDetails'] = dict()
		product_data['ListingDetails'] = dict()
		item_specifics = list()
		specifics_name = list()
		variant_attributes = list()
		for specific in category_template.specifics:
			specifics_name.append(to_str(specific.name).lower())
			if specific.value:
				if isinstance(specific.value, list):
					if isinstance(specific.value[0], dict):
						continue
				specific_value = to_str(specific.value).split('|')
				if to_len(specific_value) == 1:
					if is_decimal(specific.value) and not to_decimal(specific.value):
						continue
					specific_data = {
						'Name': specific.name,
						'Value': specific.value,

					}
				else:
					specific_data = {
						'Name': specific.name,
						'Value': specific_value,

					}
				item_specifics.append(specific_data)
		if item_specifics:
			product_data['ItemSpecifics'] = {
				'NameValueList': item_specifics
			}
		# ItemCompatibilityList
		try:
			if category_template.compatibilities:
				item_compatibility_list = list()
				compatibility_fields = {
					'year': 'Year',
					'make': 'Make',
					'model': 'Model',
					'sub_model': 'Submodel',
				}
				for compatibility in category_template.compatibilities:
					compatibility_data = {
						'CompatibilityNotes': compatibility.notes or ''
					}
					name_value_list = []
					for template_field, ebay_field in compatibility_fields.items():
						if compatibility.get(template_field):
							name_value_list.append({
								"Name": ebay_field,
								"Value": compatibility.get(template_field)
							})
					compatibility_data['NameValueList'] = name_value_list
					item_compatibility_list.append(compatibility_data)
				if item_compatibility_list:
					product_data['ItemCompatibilityList'] = {
						'Compatibility': item_compatibility_list
					}
		except:
			self.log_traceback()
		package_details = {
			'width': 'PackageWidth',
			'length': 'PackageLength',
			'height': 'PackageDepth',
		}
		product_data['ShippingPackageDetails'] = dict()
		if insert or not self.is_ebay_fr():
			for field, ebay_field in package_details.items():
				if product.get(field):
					value = product.get(field)
					if product.dimension_units == 'mm':
						value = math.ceil(to_decimal(product.get(field)) / 10)
					product_data['ShippingPackageDetails'][ebay_field] = value

		if listing_type in ['Auction', 'Chinese']:
			if price_template:
				if price_template.auction_price and price_template.auction_price.buy_it_now_price.status == 'enable':
					product_data['BuyItNowPrice'] = price_template.auction_price.buy_it_now_price.price
				product_data['StartPrice'] = price_template.auction_price.start_price.price
				if price_template.auction_price.reserve_price.price:
					product_data['ReservePrice'] = price_template.auction_price.reserve_price.price
			if not product_data.get('StartPrice'):
				product_data['StartPrice'] = self.to_ebay_price(product)

			product_data['ListingDuration'] = category_template.duration
			product_data['ListingType'] = 'Chinese'
		else:

			product_data['StartPrice'] = self.to_ebay_price(product)
			if not product.variants and self.is_use_stp(product):
				if self.is_special_price(product):
					product_data['DiscountPriceInfo'] = {
						"OriginalRetailPrice": product.price
					}
					product_data['StartPrice'] = product.special_price.price
				else:
					if not insert:
						product_data['DiscountPriceInfo'] = {
							"OriginalRetailPrice": 0
						}
			product_data['ListingDuration'] = 'GTC'
			if price_template and price_template.fixed_price.best_offer and price_template.fixed_price.best_offer.status == PriceTemplate.ENABLE:
				best_offer = price_template.fixed_price.best_offer
				product_data['BestOfferDetails'] = {
					'BestOfferEnabled': True
				}
				if best_offer.accept_price.status == PriceTemplate.ENABLE:
					if best_offer.accept_price.status == PriceTemplate.ENABLE and best_offer.accept_price.price:
						product_data['ListingDetails']['BestOfferAutoAcceptPrice'] = best_offer.accept_price.price
				if best_offer.decline_price.status == PriceTemplate.ENABLE:
					if best_offer.decline_price.status == PriceTemplate.ENABLE and best_offer.decline_price.price:
						product_data['ListingDetails']['MinimumBestOfferPrice'] = best_offer.decline_price.price
			else:
				product_data['BestOfferDetails'] = {
					'BestOfferEnabled': False
				}
		condition_id = False
		if product.ebay_condition:
			condition_id = self.get_ebay_condition_by_categories(category_template.primary_category.category_id, product.ebay_condition)
		if not condition_id and category_template.condition and category_template.condition.value and category_template.condition.value.condition_id:
			condition_id = category_template.condition.value.condition_id
		if condition_id:
			product_data['ConditionID'] = condition_id
		if category_template.condition_note:
			product_data['ConditionDescription'] = category_template.condition_note
		try:
			if category_template.condition_descriptor and isinstance(category_template.condition_descriptor, list):
				condition_descriptors = []
				for condition_descriptor in category_template.condition_descriptor:
					if not condition_descriptor.descriptor_id:
						continue
					descriptor_value = condition_descriptor.descriptor_value_id
					if to_str(descriptor_value) == '0':
						descriptor_value = condition_descriptor.descriptor_value_name
					if not descriptor_value:
						continue
					condition_descriptor_data = {
						'Name': condition_descriptor.descriptor_id,
						'Value': to_str(condition_descriptor.descriptor_value_id).split(','),
					}
					condition_descriptors.append(condition_descriptor_data)
				if condition_descriptors:
					product_data['ConditionDescriptors'] = {
						'ConditionDescriptor': condition_descriptors
					}
		except Exception:
			self.log_traceback()
		# product_data['Country'] = self.get_country()
		currency = self.get_currency_code().split(',')
		product_data['Currency'] = currency
		product_data['Description'] = self.escape_description(product.description)
		product_data['Location'] = item_location.address
		product_data['Country'] = item_location.country
		product_data['PostalCode'] = item_location.postal_code

		# product_data['PaymentMethods'] = 'PayPal'
		product_data['PayPalEmailAddress'] = payment_template.paypal_email
		picture_details = list()
		picture_urls = list()
		if product.thumb_image.url:
			picture_urls.append(product.thumb_image.url)
		for image in product.images:
			if not image.url or image.url in picture_urls:
				continue
			picture_urls.append(image.url)
		# picture_urls = picture_urls[0:24]
		convert_images = dict()
		main_images = dict()
		# if not insert:
		ebay_images = []
		for index, url in enumerate(picture_urls):
			if self.image_in_ebay(url):
				ebay_images.append(url)
				main_images[url] = index
			else:
				new_url = self.upload_site_hosted_pictures(url, product = product)
				if new_url:
					ebay_images.append(new_url)
					convert_images[url] = new_url
					main_images[new_url] = index

		if insert:
			thumb_image = ProductImage()
			map_images = []
			for index, image in enumerate(ebay_images):
				if not index:
					thumb_image.url = image
				else:
					image_data = ProductImage()
					image_data.url = image
					map_images.append(image_data)
			self._extend_product_map['thumb_image'] = thumb_image
			self._extend_product_map['images'] = map_images
		# else:
		# 	ebay_images = picture_urls
		primary_image = ebay_images[0]
		product_data['PictureDetails'] = {
			'GalleryType': 'Gallery',
			'PhotoDisplay': 'PicturePack',
			'PictureURL': ebay_images[0:24],
		}
		product_data['Title'] = product_name
		if product_name != product.name:
			self._extend_product_map['name'] = product_name
		if listing_type != 'Chinese':
			product_data['Quantity'] = to_int(product.qty)
		product_data['PrimaryCategory'] = dict()
		product_data['SecondaryCategory'] = dict()
		# product_data['ProductListingDetails'] = dict()
		product_data['Storefront'] = dict()
		if category_template.get('primary_category', dict()) and category_template.get('primary_category', dict()).get('category_id'):
			product_data['PrimaryCategory']['CategoryID'] = category_template.primary_category.category_id
		if category_template.get('secondary_category', dict()) and category_template.get('secondary_category', dict()).get('category_id'):
			product_data['SecondaryCategory']['CategoryID'] = category_template.secondary_category.category_id
		elif not insert:
			product_data['SecondaryCategory']['CategoryID'] = 0
		if category_template.get('store_category_1', dict()) and category_template.get('store_category_1', dict()).get('category_id'):
			product_data['Storefront']['StoreCategoryID'] = category_template.store_category_1.category_id
		elif not insert:
			product_data['Storefront']['StoreCategoryID'] = 0

		if category_template.get('store_category_2', dict()) and category_template.get('store_category_2', dict()).get('category_id') and to_str(category_template.get('store_category_2', dict()).get('category_id')) != to_str(category_template.get('store_category_1', dict()).get('category_id')):
			product_data['Storefront']['StoreCategory2ID'] = category_template.store_category_2.category_id
		elif not insert:
			product_data['Storefront']['StoreCategory2ID'] = 0
		listing_detail_field = {
			'epid': 'ProductReferenceID',
			# 'upc': 'UPC',
			'isbn': 'ISBN',
			# 'mpn': 'MPN',
		}
		for field, ebay_field in listing_detail_field.items():
			if product.get(field):
				product_data['ProductListingDetails'][ebay_field] = product[field]
		upc = self.get_product_identifier_unavailable_text()
		if product.upc and self.valid_upc(product.upc):
			upc = product.upc
		product_data['ProductListingDetails']['UPC'] = upc

		ean = self.get_product_identifier_unavailable_text()
		if product.ean and self.valid_ean(product.ean):
			ean = product.ean
		product_data['ProductListingDetails']['EAN'] = ean

		if self.is_eu() and product_data['ProductListingDetails'].get('UPC') and not product_data['ProductListingDetails'].get('EAN'):
			product_data['ProductListingDetails']['EAN'] = product_data['ProductListingDetails'].get('UPC')
			del product_data['ProductListingDetails']['UPC']
		if product.get('mpn') and product.get('brand'):
			brand_mpn = {
				'MPN': product['mpn'],
				'Brand': product.brand
			}
			product_data['ProductListingDetails']['BrandMPN'] = brand_mpn

		# if product.get('upc'):
		# 	product_data['ProductListingDetails']['UPC'] = product.upc
		# else:
		# 	if category_template.does_not_apply_upc:
		# 		product_data['ProductListingDetails']['UPC'] = self.get_product_identifier_unavailable_text()
		return_policies = dict()
		if payment_template.return_policy.status == PaymentReturnPolicy.ENABLE:
			domestic_return = payment_template.return_policy.domestic_return
			if domestic_return.status == BaseReturnPolicy.ENABLE:
				return_policies['ReturnsAcceptedOption'] = 'ReturnsAccepted'
				return_policies['ShippingCostPaidByOption'] = domestic_return.paid_by
				return_policies['ReturnsWithinOption'] = domestic_return.within
				if domestic_return.replace_or_exchange == BaseReturnPolicy.ENABLE:
					return_policies['RefundOption'] = 'MoneyBackOrReplacement'
				else:
					return_policies['RefundOption'] = 'MoneyBack'
			else:
				return_policies['ReturnsAcceptedOption'] = 'ReturnsNotAccepted'

			international_return = payment_template.return_policy.international_return
			if international_return.status == BaseReturnPolicy.ENABLE:
				return_policies['InternationalReturnsAcceptedOption'] = 'ReturnsAccepted'
				return_policies['InternationalShippingCostPaidByOption'] = international_return.paid_by
				return_policies['InternationalReturnsWithinOption'] = international_return.within
				if international_return.replace_or_exchange == BaseReturnPolicy.ENABLE:
					return_policies['InternationalRefundOption'] = 'MoneyBackOrReplacement'
				else:
					return_policies['InternationalRefundOption'] = 'MoneyBack'
			else:
				# if not insert:
				if not self.is_eu():
					return_policies['InternationalReturnsAcceptedOption'] = 'ReturnsNotAccepted'

		else:
			# if not insert:
			if not self.is_eu():
				return_policies['InternationalReturnsAcceptedOption'] = 'ReturnsNotAccepted'
			return_policies['ReturnsAcceptedOption'] = 'ReturnsNotAccepted'
		product_data['ReturnPolicy'] = return_policies
		domestic_shipping = shipping_template.domestic_shipping

		international_shipping = shipping_template.international_shipping
		shipping_details = dict()

		if shipping_template.excluded_locations.status == 'enable':
			shipping_details['ExcludeShipToLocation'] = shipping_template.excluded_locations.locations
		else:
			shipping_details['ExcludeShipToLocation'] = 'none'

		shipping_details['GlobalShipping'] = 'true' if shipping_template.global_shipping == 'enable' else 'false'
		shipping_type = 'NotSpecified'
		if domestic_shipping.shipment_type == 'Freight':
			if not self.is_support_shipping_freight():
				return Response().error(Errors.EBAY_FREIGHT_SHIPMENT_TYPE)
			shipping_type = 'FreightFlat'
		if domestic_shipping.shipment_type == 'Flat':
			if to_int(domestic_shipping.flat_shipping_discount):
				shipping_details['ShippingDiscountProfileID'] = to_int(domestic_shipping.flat_shipping_discount)
			shipping_type = 'Flat'
			if international_shipping.status == 'enable' and international_shipping.shipment_type != 'Flat':
				shipping_type = 'FlatDomesticCalculatedInternational'
		calculated_shipping_rate = dict()
		if domestic_shipping.shipment_type == 'Calculated':
			calculated_shipping_rate['OriginatingPostalCode'] = domestic_shipping.originating_postal_code
			calculated_shipping_rate['PackagingHandlingCosts'] = domestic_shipping.packaging_handling_costs
			if to_int(domestic_shipping.calculated_shipping_discount):
				shipping_details['ShippingDiscountProfileID'] = to_int(domestic_shipping.calculated_shipping_discount)
			shipping_type = 'Calculated'
			if shipping_template.domestic_shipping.shipping_package and shipping_template.domestic_shipping.shipping_package != "None":
				shipping_details['ShippingPackage'] = shipping_template.domestic_shipping.shipping_package
			if 'shipping_irregular' in shipping_template.domestic_shipping:
				shipping_details['ShippingIrregular'] = True if shipping_template.domestic_shipping.shipping_irregular else False
			if international_shipping.status == 'enable' and international_shipping.shipment_type != 'Calculated':
				shipping_type = 'CalculatedDomesticFlatInternational'

		shipping_details['ShippingType'] = shipping_type
		if insert or not self.is_ebay_fr():
			weight_major, weight_major_unit, weight_minor, weight_minor_unit = self.convert_weight(product)
			product_data['ShippingPackageDetails']['WeightMajor'] = {
				'@unit': weight_major_unit,
				'#text': to_str(weight_major) if weight_major else '0'
			}
			product_data['ShippingPackageDetails']['WeightMinor'] = {
				'@unit': weight_minor_unit,
				'#text': to_str(math.ceil(weight_minor)) if weight_minor else '0'
			}
		domestic_shipping_service_options = getattr(domestic_shipping, f'{domestic_shipping.shipment_type.lower()}_options_attributes')
		domestic_shipping_service = list()
		if domestic_shipping_service_options:
			number_domestic_shipping_service_options = to_len(domestic_shipping_service_options)
			for index, service_option in enumerate(domestic_shipping_service_options):
				ebay_service_option = {
					# 'FreeShipping': True if to_int(service_option.free_shipping) == 1 else False,
					'ShippingService': service_option.shipping_service_id,
					# 'ShippingServiceAdditionalCost': service_option.additional_cost,
					# 'ShippingServiceCost': service_option.cost if not service_option.free_shipping else 0,
				}
				if number_domestic_shipping_service_options > 1:
					ebay_service_option['ShippingServicePriority'] = index + 1
				if index == 0 and to_int(service_option.free_shipping) == 1:
					ebay_service_option['FreeShipping'] = True
				if domestic_shipping.shipment_type == 'Flat':
					ebay_service_option['ShippingServiceCost'] = service_option.cost if not service_option.free_shipping else 0
					ebay_service_option['ShippingServiceAdditionalCost'] = service_option.additional_cost
				domestic_shipping_service.append(ebay_service_option)
		if domestic_shipping_service:
			shipping_details['ShippingServiceOptions'] = domestic_shipping_service
		if domestic_shipping.promotional_shipping_discount:
			shipping_details['PromotionalShippingDiscount'] = True
		international_shipping_service = list()
		if international_shipping and international_shipping.status == InternationalShipping.ENABLE:
			if international_shipping.shipment_type:
				if international_shipping.shipment_type == 'Flat':
					if to_int(international_shipping.flat_shipping_discount):
						shipping_details['InternationalShippingDiscountProfileID'] = to_int(international_shipping.flat_shipping_discount)
				if international_shipping.shipment_type == 'Calculated':
					if international_shipping and international_shipping.packaging_handling_costs:
						calculated_shipping_rate['InternationalPackagingHandlingCosts'] = international_shipping.packaging_handling_costs
					if to_int(international_shipping.calculated_shipping_discount):
						shipping_details['InternationalShippingDiscountProfileID'] = to_int(international_shipping.calculated_shipping_discount)
				international_shipping_service_options = getattr(international_shipping, f'{international_shipping.shipment_type.lower()}_options_attributes')
				if international_shipping_service_options:
					number_international_shipping_service_options = to_len(international_shipping_service_options)
					for index, service_option in enumerate(international_shipping_service_options):
						ebay_service_option = {
							# 'FreeShipping': True if to_int(service_option.free_shipping) == 1 else False,
							'ShippingService': service_option.shipping_service_id,
							# 'ShippingServiceAdditionalCost': service_option.additional_cost,
							# 'ShippingServiceCost': service_option.cost,
						}
						if number_international_shipping_service_options > 1:
							ebay_service_option['ShippingServicePriority'] = index + 1
						if international_shipping.shipment_type == 'Flat':
							ebay_service_option['ShippingServiceCost'] = service_option.cost
							ebay_service_option['ShippingServiceAdditionalCost'] = service_option.additional_cost
						if to_str(service_option.ship_to_location).lower() == 'worldwide':
							ship_to_location = 'Worldwide'
						else:
							additional_ship_to_locations = service_option.additional_ship_to_locations
							all_additional_ship_to_locations = list()
							for additional_ship_to_location in additional_ship_to_locations:
								if additional_ship_to_location == 'N. and S. America':
									all_additional_ship_to_locations.append('Americas')
								else:
									all_additional_ship_to_locations.append(additional_ship_to_location)
							ship_to_location = all_additional_ship_to_locations
						ebay_service_option['ShipToLocation'] = ship_to_location
						international_shipping_service.append(ebay_service_option)
			if international_shipping.promotional_shipping_discount:
				shipping_details['InternationalPromotionalShippingDiscount'] = True
			if international_shipping.additional_locations:
				all_additional_ship_to_locations = list()
				for additional_ship_to_location in international_shipping.additional_locations:
					if additional_ship_to_location == 'N. and S. America':
						all_additional_ship_to_locations.append('Americas')
					else:
						all_additional_ship_to_locations.append(additional_ship_to_location)
				product_data['ShipToLocations'] = all_additional_ship_to_locations
		if calculated_shipping_rate:
			shipping_details['CalculatedShippingRate'] = calculated_shipping_rate

		if international_shipping_service:
			shipping_details['InternationalShippingServiceOption'] = international_shipping_service
		rate_tables = dict()
		if domestic_shipping.rate_table and domestic_shipping.rate_table.status == EbayRateTable.ENABLE:
			rate_tables['DomesticRateTableId'] = domestic_shipping.rate_table.rate_table_id
		if international_shipping and international_shipping.rate_table and international_shipping.rate_table.status == EbayRateTable.ENABLE:
			rate_tables['InternationalRateTableId'] = international_shipping.rate_table.rate_table_id
		shipping_details['RateTableDetails'] = rate_tables
		if payment_template.ebay_tax_table == PaymentTemplate.ENABLE:
			product_data['UseTaxTable'] = True
		else:
			if payment_template.sales_tax and payment_template.sales_tax.status == PaymentSalesTax.ENABLE:
				sales_tax = dict()
				sales_tax['SalesTaxPercent'] = payment_template.sales_tax.value
				sales_tax['SalesTaxState'] = payment_template.sales_tax.state
				sales_tax['ShippingIncludedInTax'] = to_bool(payment_template.sales_tax.shipping_include_tax)
				shipping_details['SalesTax'] = sales_tax
		if domestic_shipping.shipment_type == 'LocalPickup':
			shipping_details = ''
			product_data['ShipToLocations'] = 'None'
		if domestic_shipping.shipment_type == 'Freight':
			shipping_details = {
				'ShippingType': 'FreightFlat',
				'ShippingServiceOptions': '',
			}
		product_data['ShippingDetails'] = shipping_details
		product_data['SKU'] = product.sku
		list_sku = []
		is_business_template = True

		if business_template:
			product_data['SellerProfiles'] = dict()
			policy_map = {
				'payment': 'payment',
				'return': 'return',
				'fulfillment': 'shipping'
			}
			for policy_key, policy_type in policy_map.items():
				if not business_template.get(f'{policy_key}_policy') or not business_template[f'{policy_key}_policy'][f'{policy_key}_policy_id']:
					is_business_template = False
					break
			if is_business_template:
				for policy_key, policy_type in policy_map.items():
					if not business_template.get(f'{policy_key}_policy'):
						continue

					product_data['SellerProfiles'].update({
						f'Seller{policy_type.title()}Profile': {
							f'{policy_type.title()}ProfileID': business_template[f'{policy_key}_policy'][f'{policy_key}_policy_id'],
							f'{policy_type.title()}ProfileName': business_template[f'{policy_key}_policy'][f'{policy_key}_policy_name'],
						}
					})

				try:
					if product_data.get('SellerProfiles', {}).get('SellerShippingProfile'):
						del product_data['ShippingDetails']
				except:
					pass

				try:
					if product_data.get('SellerProfiles', {}).get('SellerReturnProfile'):
						del product_data['ReturnPolicy']
				except:
					pass

				# if product_data['SellerProfiles']['SellerPaymentProfile']:
				# 	del product_data['PaymentMethods']

				try:
					if not product_data.get('SellerProfiles', {}).get('SellerShippingProfile', {}).get('ShippingProfileID'):
						del product_data['SellerProfiles']
				except:
					pass
		# if not business_template and not insert:
		# 	delete_fields.extend(
		# 		['Item.SellerProfiles.SellerPaymentProfile','Item.SellerProfiles.SellerReturnProfile','Item.SellerProfiles.SellerShippingProfile']
		# 	)
		try:
			vat_percent = 0
			if is_business_template and business_template.vat_percent:
				vat_percent = business_template.vat_percent
			elif payment_template and payment_template.vat_percent:
				vat_percent = payment_template.vat_percent
			if vat_percent:
				product_data['VATDetails'] = dict()
				product_data['VATDetails']['VATPercent'] = to_decimal(vat_percent, 1)
		except:
			self.log_traceback()
		if product.variants:
			ebay_variants = list()
			variation_options = self.variants_to_option(product.variants)
			specific = list()
			variant_attribute_image = False
			for option_name, option_values in variation_options.items():
				attribute_name = self.get_variant_attribute_name(option_name, specifics_name, ebay_variant_attributes)
				variant_attributes.append(attribute_name)
				specific.append({
					'Name': attribute_name,
					'Value': option_values
				})
			if to_len(variation_options.keys()) > 1:
				option_multy_value = []
				for option_name, option_values in variation_options.items():
					attribute_name = self.get_variant_attribute_name(option_name, specifics_name, ebay_variant_attributes)
					if to_len(option_values) > 1:
						option_multy_value.append(attribute_name)
				if len(option_multy_value) == 1:
					variant_attribute_image = option_multy_value[0]
			if insert:
				self._extend_product_map['ebay_variant_attributes'] = variant_attributes
			# self._extend_product_map['variant_attributes'] = variant_attributes
			len_attributes = to_len(list(variation_options.keys()))
			variant_images = []
			variant_specific_name = ''
			channel_data = product['channel'][f'channel_{self.get_channel_id()}']
			if len_attributes == 1:
				variant_specific_name = self.get_variant_attribute_name(list(variation_options.keys())[0], specifics_name, ebay_variant_attributes)
			elif variant_attribute_image:
				variant_specific_name = variant_attribute_image
			for variant in product.variants:
				variant_data = dict()
				if not insert:
					is_variant_removed = self.is_variant_removed(variant)
					if is_variant_removed:
						variant_data['Delete'] = 'true'
				variant_data['Quantity'] = to_int(variant.qty) if not variant.invisible or self.is_keep_product_active() else 0
				if variant.sku and variant.sku not in list_sku:
					variant_data['SKU'] = variant.sku
					list_sku.append(variant.sku)
				variant_data['StartPrice'] = self.to_ebay_price(variant)
				if self.is_use_stp(product):
					if self.is_special_price(variant):
						variant_data['DiscountPriceInfo'] = {
							"OriginalRetailPrice": variant.price
						}
						variant_data['StartPrice'] = variant.special_price.price
					else:
						if not insert:
							variant_data['DiscountPriceInfo'] = {
								"OriginalRetailPrice": 0
							}
				listing_detail_field = {
					'epid': 'ProductReferenceID',
					# 'upc': 'UPC',
					'isbn': 'ISBN',
					'mpn': 'MPN',
				}
				listing_details = dict()
				for field, ebay_field in listing_detail_field.items():
					if variant.get(field):
						listing_details[ebay_field] = variant[field]
				variant_upc = self.get_product_identifier_unavailable_text()
				if self.valid_upc(variant.upc):
					variant_upc = variant.upc
				listing_details['UPC'] = variant_upc
				variant_ean = self.get_product_identifier_unavailable_text()
				if self.valid_ean(variant.ean):
					variant_ean= variant.upc
				listing_details['EAN'] = variant_ean
				if self.is_eu() and listing_details.get('UPC') and not listing_details.get('EAN'):
					listing_details['EAN'] = listing_details.get('UPC')
					del listing_details['UPC']
				# if variant.get('upc'):
				# 	listing_details['UPC'] = variant.upc
				# else:
				# 	if category_template.does_not_apply_upc:
				# 		listing_details['UPC'] = self.get_product_identifier_unavailable_text()
				if listing_details:
					variant_data['VariationProductListingDetails'] = listing_details
				variant_attributes = list()
				for attribute in variant.attributes:
					if not attribute.use_variant:
						continue
					variant_attribute_name = self.get_variant_attribute_name(attribute.attribute_name, specifics_name, ebay_variant_attributes)
					variant_attributes.append({
						'Name': variant_attribute_name,
						'Value': attribute.attribute_value_name,
					})
					if (len_attributes == 1 or (variant_attribute_image and variant_attribute_image == variant_attribute_name)) and variant.thumb_image.url and convert_images.get(variant.thumb_image.url) and convert_images.get(variant.thumb_image.url) != primary_image:
						variant_image = {
							'PictureURL': convert_images.get(variant.thumb_image.url),
							'VariationSpecificValue': attribute.attribute_value_name
						}
						variant_images.append(variant_image)
				variant_data['VariationSpecifics'] = {
					'NameValueList': variant_attributes
				}
				ebay_variants.append(variant_data)
			product_data['Variations'] = {
				'VariationSpecificsSet': {
					"NameValueList": specific
				},
				'Variation': ebay_variants
			}
			try:
				if not variant_images and channel_data.get('ebay_variant_images') and variation_options:
					attribute = channel_data['ebay_variant_images']['attribute']
					option_images = channel_data['ebay_variant_images']['options']
					variant_option_image = variation_options.get(attribute)
					variant_specific_name = self.get_variant_attribute_name(attribute, specifics_name, ebay_variant_attributes)
					if variant_option_image:
						for option in option_images:
							child_image = option.image
							child_value = option.name
							ebay_child_image = convert_images.get(child_image) if convert_images else child_image
							if ebay_child_image and ebay_child_image != primary_image:
								variant_images.append({
									'VariationSpecificValue': child_value,
									'PictureURL': ebay_child_image
								})
			except:
				self.log_traceback()
			if variant_images and variant_specific_name:
				product_data['Variations']['Pictures'] = {
					'VariationSpecificName': variant_specific_name,
					'VariationSpecificPictureSet': variant_images
				}
				all_variant_iamges = []
				for variant_image in variant_images:
					all_variant_iamges.append(variant_image['PictureURL'])
				parent_ebay_images = []
				for index_image, image in enumerate(ebay_images):
					if not index_image or image not in all_variant_iamges:
						parent_ebay_images.append(image)
				product_data['PictureDetails']['PictureURL'] = parent_ebay_images[0:24]
			else:
				product_data['Variations']['Pictures'] = ''

		if product.videos:
			try:
				update_field = {

				}
				if product.video_id:
					video_id = product.video_id
				else:
					video_id = self.create_video(product.videos[0], product)
					if video_id:
						update_field[f'channel.channel_{self.get_channel_id()}.video_id'] = video_id

				if video_id:
					video_upload_success = product.video_upload_success
					if not video_upload_success:
						upload_video = self.upload_video(product.videos[0], video_id)
						if upload_video:
							video_upload_success = True
							update_field[f'channel.channel_{self.get_channel_id()}.video_upload_success'] = True
					if update_field:
						self.get_model_catalog().update(product['_id'], update_field)

					if video_upload_success:
						product_data['VideoDetails'] = {
							'VideoID': video_id
						}
			except:
				self.log_traceback('video')
		product_data = strip_none(product_data)
		return Response().success(data = [product_data, main_images, delete_fields])


	def upload_video(self, product_video: ProductVideo, video_id):
		url = product_video.url
		video_req = requests.get(url, verify = False)
		if video_req.status_code > 300:
			return False
		content = video_req.content
		headers = {
			'Content-Type': 'application/octet-stream'
		}
		try:
			video = self.api(f'commerce/media/v1_beta/video/{video_id}/upload', content, endpoint = self.get_apim_endpoint(), method = 'post', headers = headers)
		except Exception:
			return False
		if self._last_status < 300:
			return True
		return False


	def create_video(self, product_video: ProductVideo, product):
		filesize = product_video.filesize
		if not filesize:
			headers = requests.head(product_video.url, verify = False)
			if headers.status_code > 300:
				return False
			filesize = to_int(headers.headers.get('content-length'))
			if not filesize:
				return False
		title = product_video.title or product.name
		create_data = {
			"size": filesize,
			"title": title[0:25],
			"classification": [
				"ITEM"
			]
		}
		video = self.api('commerce/media/v1_beta/video', create_data, endpoint = self.get_apim_endpoint(), method = 'post')
		if self._last_status > 300:
			return False
		location = self._last_header.get('location')
		video_id = location.split('/')[-1]
		return video_id


	def get_variant_attribute_name(self, attribute_name, specifics_name, ebay_variant_attributes = None):
		if ebay_variant_attributes and attribute_name in ebay_variant_attributes:
			return attribute_name
		specifics_name = list(map(lambda x: to_str(x).lower(), specifics_name))
		if attribute_name == 'Type':
			attribute_name = 'Type Kind'
		if attribute_name.lower() == 'style':
			attribute_name = 'Variant Style'
		# if attribute_name == 'Size':
		# 	attribute_name = 'Sizes'
		if to_str(attribute_name).lower() in specifics_name:
			attribute_name = f'Variant {attribute_name}'
		return attribute_name


	def dict_to_xml_product_body(self, import_method, product_data):
		return f'''<?xml version="1.0" encoding="utf-8"?>
				<{import_method}Request xmlns="urn:ebay:apis:eBLBaseComponents">
				    {self.parse_dict_to_xml(product_data, '')}
				    <ErrorLanguage>en_US</ErrorLanguage>
				</{import_method}Request>
						'''


	def product_channel_update(self, product_id, product: Product, products_ext):
		if product['channel'][f'channel_{self.get_channel_id()}'].get('inventory_api'):
			return self.channel_sync_inventory_by_inventory_api(product_id, product, is_update = True)
		# TODO: Shipping, Payment and Return template
		shipping_template = product.get('template_data', {}).get('shipping')
		payment_template = product.get('template_data', {}).get('payment')
		price_template = product.get('template_data', {}).get('price')
		category_template = product.get('template_data', {}).get('category')
		business_template = BusinessTemplate.from_dict(product.get('template_data', {}).get('business', Prodict()))
		is_business_template = False
		if business_template:
			is_business_template = True
			policy_map = {
				'payment': 'payment',
				'return': 'return',
				'fulfillment': 'shipping'
			}
			for policy_key, policy_type in policy_map.items():
				if not business_template.get(f'{policy_key}_policy') or not business_template[f'{policy_key}_policy'][f'{policy_key}_policy_id']:
					is_business_template = False
					break
		have_payment = bool(payment_template or business_template.item_location)
		if not have_payment and not is_business_template:
			return Response().error(Errors.EBAY_PAYMENT_REQUIRED)
		if not shipping_template and not is_business_template:
			return Response().error(Errors.EBAY_SHIPPING_REQUIRED)
		if not category_template or not category_template.get('primary_category') or not category_template.primary_category.get('category_id'):
			return Response().error(Errors.EBAY_CATEGORY_REQUIRED)
		# TODO: createOrReplaceInventoryItem
		ebay_variant_attributes = self.get_ebay_variant_attributes(product)

		product_data_convert = self.product_to_ebay_data(product, ebay_variant_attributes = ebay_variant_attributes)
		if product_data_convert.result != Response.SUCCESS:
			return product_data_convert
		product_data, main_images, delete_fields = product_data_convert.data
		product_data['ItemID'] = product_id
		del product_data['SKU']
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'

		if listing_type == 'Chinese':
			import_method = 'ReviseItem'
		else:
			import_method = 'ReviseFixedPriceItem'
		body_xml = {
			'Item': product_data
		}
		if delete_fields:
			body_xml['DeletedField'] = delete_fields
		product_xml = self.dict_to_xml_product_body(import_method, body_xml)

		kwargs = {
			'action': import_method,
			'body': product_xml,
			'custom_headers': {"X-EBAY-API-DETAIL-LEVEL": "0"}
		}
		category_id = category_template.primary_category.category_id
		category_name = category_template.primary_category.category_name

		if self.is_ebay_motors_us(category_id, category_name):
			kwargs['site_id'] = 100
		product_response = self.xml_api(**kwargs)

		if self.is_log():
			self.log(product_xml, 'product_xml')
		if self._error_return_policy:
			self._error_return_policy = False
			del product_data['ReturnPolicy']
			body_xml = {
				'Item': product_data
			}
			if delete_fields:
				body_xml['DeletedField'] = delete_fields
			product_xml = self.dict_to_xml_product_body(import_method, body_xml)
			kwargs['body'] = product_xml
			product_response = self.xml_api(**kwargs)
		# product_response = self.xml_api(import_method, product_xml, custom_headers = {"X-EBAY-API-DETAIL-LEVEL": "0"})
		response = product_response.get(f'{import_method}Response')
		if not response:
			return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		if response.get('Errors'):
			errors = obj_to_list(response['Errors'])
			for error in errors:
				if to_int(error['ErrorCode']) == 21919137:
					image_error = []
					params = obj_to_list(error['ErrorParameters'])
					for param in params:
						if param['Value'] in main_images:
							image_error.append(main_images[param['Value']])
					return_error = {
						'msg': 'Your product contains images that are too small in size. Ebay requires images with the longest side size of 500 pixels. Please replace the images that are too small, or hover over the faulty images to remove them from the product before uploading the product to ebay.',
						'images': image_error
					}
					return Response().error(msg = json_encode(return_error))
				if to_int(error.get('ErrorCode')) == 21919474:
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', True)
					return self.channel_sync_inventory_by_inventory_api(product_id, product, is_update = True)
				if to_int(error.get('ErrorCode')) == 21916591:
					sku_error = error.ErrorParameters.Value
					all_variants = []
					for variant in product.variants:
						if variant.sku == sku_error:
							self.product_deleted(variant['_id'], variant, self.get_channel_id())
							continue
						all_variants.append(variant)
					product.variants = all_variants
					return self.product_channel_update(product_id, product, products_ext)
		if response.Ack in ['Success', 'Warning']:
			specifics_name = list()
			for specific in category_template.specifics:
				# if specific.value:
				specifics_name.append(specific.name)

			for variant in product.variants:
				is_variant_removed = self.is_variant_removed(variant)
				if is_variant_removed:
					self.product_deleted(variant['_id'], variant, self.get_channel_id())
					continue
				for attribute in variant.attributes:
					attribute.attribute_name = self.get_variant_attribute_name(attribute.attribute_name, specifics_name)
				variant_id = f'{product_id}-{self.variant_key_generate(variant)}'
				if not variant['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
					self.insert_map_product(variant, variant['_id'], variant_id)
				else:
					self.update_map_product(variant, variant['_id'], variant_id)
			# self.insert_map_product(variant, variant['_id'], variant_id)
			return Response().success()
		msg_errors = product_response.get('msg_errors')
		msg_errors = to_str(msg_errors).replace('contact us', 'contact eBay support')
		return Response().error(msg = msg_errors)


	def get_product_by_id(self, product_id):
		product_data = {
			'ItemID': product_id,

		}
		return Response().success(Prodict.from_dict(product_data))


	def ended_listing(self, listing_id, product, forced = False):
		if not self.allow_ended() and not forced:
			return Response().error(Errors.EBAY_NOT_ALLOW_ENDED)
		category_template = product.get('template_data', {}).get('category') or product.channel.get(f'channel_{self.get_channel_id()}', {}).get('template_data', {}).get('category')

		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		if listing_type == 'Chinese':
			method = 'EndItem'
		else:
			method = 'EndFixedPriceItem'
		body_xml = f'''<?<?xml version="1.0" encoding="utf-8"?>
<{method}Request xmlns="urn:ebay:apis:eBLBaseComponents">
  <ItemID>{listing_id}</ItemID>
  <EndingReason>NotAvailable</EndingReason>
</{method}Request>'''
		self.xml_api(method, body_xml)
		self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.ebay_status', 'ended')
		return True


	def allow_ended(self):
		return self._state.channel.config.setting.get('qty', {}).get('out_of_stock_control') != 'enable'


	def allow_relist(self, product):
		category_template = product.get('template_data', {}).get('category')
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		if listing_type != 'Chinese':
			return self._state.channel.config.setting.get('qty', {}).get('allow_relist') == 'enable'
		return self._state.channel.config.setting.get('qty', {}).get('allow_relist_auction') == 'enable'


	def ebay_relist_success(self, old_item_id, new_item_id, product):
		if self.is_inventory_process():
			self.set_new_sync_product_id(new_item_id)

		category_template = product.get('template_data', {}).get('category') or product.channel.get(f'channel_{self.get_channel_id()}', {}).get('template_data', {}).get('category')
		update_data = {
			f'channel.channel_{self.get_channel_id()}.ebay_status': 'active',
			f'channel.channel_{self.get_channel_id()}.product_id': new_item_id,
			f'channel.channel_{self.get_channel_id()}.old_item_id': old_item_id,

		}
		if old_item_id == new_item_id:
			update_data = {
				f'channel.channel_{self.get_channel_id()}.ebay_status': 'active',

			}
		self.get_model_catalog().update(product['_id'], update_data)
		if to_int(product.variant_count) > 0 and old_item_id != new_item_id:
			variants = self.get_variants(product, self.get_channel_id())
			ebay_variant_attributes = self.get_ebay_variant_attributes(product)
			if variants:
				specifics_name = list()
				for specific in category_template.specifics:
					# if specific.value:
					specifics_name.append(specific.name)
				for variant in variants:
					for attribute in variant.attributes:
						attribute.attribute_name = self.get_variant_attribute_name(attribute.attribute_name, specifics_name, ebay_variant_attributes)
					variant_id = self.variant_key_generate(variant)
					self.get_model_catalog().update_field(variant['_id'], f"channel.channel_{self.get_channel_id()}.product_id", f"{new_item_id}-{variant_id}")


	def re_listing(self, listing_id, product, product_data = None, forced = False):
		if not self.allow_relist(product) and not forced:
			return Response().error(Errors.EBAY_NOT_ALLOW_RELIST)
		category_template = product.get('template_data', {}).get('category') or product.channel.get(f'channel_{self.get_channel_id()}', {}).get('template_data', {}).get('category')
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		if listing_type == 'Chinese':
			method = 'RelistItem'
		# return Response().error(Errors.EBAY_NOT_ALLOW_RELIST)

		else:
			method = 'RelistFixedPriceItem'
		if not product_data:
			product_data = {
				'ItemID': listing_id,
				'Quantity': product.qty if listing_type != 'Chinese' else 1
			}
		body_xml = self.dict_to_xml_product_body(method, {
			'Item': product_data
		})
		# 		body_xml = f'''<?xml version="1.0" encoding="utf-8"?>
		# <{method}Request xmlns="urn:ebay:apis:eBLBaseComponents">
		# 	<ErrorLanguage>en_US</ErrorLanguage>
		# 	<WarningLevel>High</WarningLevel>
		#     <Item>
		#     <ItemID>{listing_id}</ItemID>
		#     </Item>
		# </{method}Request>'''
		relist = self.xml_api(method, body_xml)
		old_item_id = product['channel'][f'channel_{self.get_channel_id()}'].get('old_item_id')
		if not old_item_id:
			old_item_id = []
		old_item_id.append(to_str(listing_id))
		if relist and relist.get(f'{method}Response') and relist[f"{method}Response"].get('Ack') != 'Failure':
			new_item_id = relist[f"{method}Response"]['ItemID']
			self.ebay_relist_success(old_item_id, new_item_id, product)
			return Response().success(new_item_id)
		if not relist:
			return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		if relist.get(f'{method}Response', {}).get('Errors'):
			errors = obj_to_list(relist[f'{method}Response']['Errors'])
			for error in errors:
				if to_int(error.get('ErrorCode')) == 196:
					self.ebay_relist_success(old_item_id, old_item_id, product)
					return Response().success(old_item_id)
				try:
					if to_int(error.get('ErrorCode')) == 21919067:
						new_item_id = error['ErrorParameters'][1]['Value']
						self.ebay_relist_success(old_item_id, new_item_id, product)
						return Response().success(new_item_id)
						return Response().error(msg = Errors().get_msg_error(Errors.EBAY_RELIST_DUPLICATE).format(url_to_link(f"https://www.ebay.com/itm/{new_item_id}", new_item_id)))
				except:
					self.log_traceback()
		msg_errors = relist.get('msg_errors')
		return Response().error(msg = msg_errors)


	def out_of_stock_control(self, control):
		control_bol = 'true' if control else 'false'
		body_xml = f'''<?xml version="1.0" encoding="utf-8"?> 
<SetUserPreferencesRequest xmlns="urn:ebay:apis:eBLBaseComponents"> 
  <WarningLevel>High</WarningLevel> 
  <OutOfStockControlPreference>{control_bol}</OutOfStockControlPreference>
</SetUserPreferencesRequest> '''
		self.xml_api('SetUserPreferences', body_xml)
		return True


	def get_inventory_item_data_default(self):
		if self._inventory_item_data:
			return self._inventory_item_data
		default_sku = self._offer_data['sku']
		inventory_item_data_default = self.api(f'sell/inventory/v1/inventory_item/{default_sku}')
		self._inventory_item_data = inventory_item_data_default
		return inventory_item_data_default


	def get_inventory_group_data_default(self):
		# if self._inventory_group_data:
		# 	return self._inventory_group_data
		inventory_item_group_key = self._inventory_item_data['inventoryItemGroupKeys'][0]
		inventory_item_data_default = self.api(f'sell/inventory/v1/inventory_item_group/{inventory_item_group_key}')
		# self._inventory_group_data = inventory_item_data_default
		return inventory_item_data_default


	def create_inventory_item(self, product, parent, item_id = False):
		inventory_item_data_default = self.get_inventory_item_data_default()
		upc = self.get_product_identifier_unavailable_text()
		if self.valid_upc(product.upc):
			upc = product.upc
		inventory_item_data = {
			"product": {
				"title": parent.name if parent else product.name,
				"aspects": {
				},
				"upc": [
					upc
				],
			},
			"condition": inventory_item_data_default.condition,
			"packageWeightAndSize": inventory_item_data_default.packageWeightAndSize,
			"availability": {
				"shipToLocationAvailability": {
					"quantity": product.qty,
					"allocationByFormat": {
						"auction": 0,
						"fixedPrice": product.qty
					}
				}
			}
		}
		if product.thumb_image.url:
			# new_url = self.upload_site_hosted_pictures(product.thumb_image.url)
			# if new_url:
			inventory_item_data['product']['imageUrls'] = [product.thumb_image.url]
		ebay_variant_attributes = self.get_ebay_variant_attributes(parent)

		category_template = parent.get('template_data', {}).get('category')
		specifics_name = list()
		ebay_variants = list()
		variant_attributes = list()
		for specific in category_template.specifics:
			# if specific.value:
			specifics_name.append(to_str(specific.name).lower())

		variation_options = self.variants_to_option(parent.variants)
		specific = list()
		for option_name, option_values in variation_options.items():
			attribute_name = self.get_variant_attribute_name(option_name, specifics_name, ebay_variant_attributes)
			variant_attributes.append(attribute_name)
			specific.append({
				'Name': attribute_name,
				'Value': option_values
			})
		for attribute in product.attributes:
			if not attribute.use_variant:
				continue
			inventory_item_data['product']['aspects'][self.get_variant_attribute_name(attribute.attribute_name, specifics_name, ebay_variant_attributes)] = [attribute.attribute_value_name]
		offer_req = self.api(f'sell/inventory/v1/inventory_item/{product.sku}', inventory_item_data, method = 'put')
		if self._last_status < 300:
			variant_id = f'{item_id}-{self.variant_key_generate(product)}'
			self.insert_map_product(product, product['_id'], variant_id)
			inventory_item_group = self.get_inventory_group_data_default()
			if inventory_item_group:
				if product.sku not in inventory_item_group['variantSKUs']:
					inventory_item_group['variantSKUs'].append(product.sku)
				specifications = dict()
				for row in inventory_item_group['variesBy']['specifications']:
					specifications[row['name']] = row['values']
				for attribute_name, attribute_value in inventory_item_data['product']['aspects'].items():
					value = attribute_value[0]
					if value not in specifications[attribute_name]:
						specifications[attribute_name].append(value)
				inventory_item_group['variesBy']['specifications'] = list()
				for attribute_name, attribute_values in specifications.items():
					inventory_item_group['variesBy']['specifications'].append({
						'name': attribute_name,
						'values': attribute_values
					})
				self.api(f"sell/inventory/v1/inventory_item_group/{self._inventory_item_data['inventoryItemGroupKeys'][0]}", inventory_item_group, method = 'put')
			return Response().success()
		errors = []
		if offer_req.errors:
			for error in offer_req.errors:
				errors.append(error.longMessage or error.message)
		return Response().error(msg = '_lic_nl_'.join(errors))


	def get_merchant_location_key_default(self):
		if self.merchant_location_key_default:
			return self.merchant_location_key_default
		merchant_location_keys = self.api('sell/inventory/v1/location', {'limit': 100, 'offset': 0})
		merchant_location_key_default = False
		for merchant_location_key in merchant_location_keys['locations']:
			if merchant_location_key.merchantLocationStatus == 'ENABLED':
				if not merchant_location_key_default:
					merchant_location_key_default = merchant_location_key.merchantLocationKey
				if merchant_location_key.locationTypes and 'WAREHOUSE' in merchant_location_key.locationTypes:
					merchant_location_key_default = merchant_location_key.merchantLocationKey
					break
		self.merchant_location_key_default = merchant_location_key_default
		return merchant_location_key_default


	def simple_sync_inventory_by_inventory_api(self, product, create_offer = False, parent = False, item_id = False, is_update = False):
		channel_data = product.channel.get(f'channel_{self.get_channel_id()}', {})
		sku = channel_data.get('sku') or product.sku
		if create_offer:
			if not self._offer_data:
				return Response().create_response(result = 'inventory')

			create_inventory_item = self.create_inventory_item(product, parent, item_id = item_id)
			if create_inventory_item.result != Response.SUCCESS:
				return create_inventory_item
			create_offer_data = {
				"sku": sku,
				"marketplaceId": self.get_marketplace_id(),
				"format": "FIXED_PRICE",
				"listingDescription": self.escape_description(product.description or parent.description),
				"availableQuantity": product.qty,
				"pricingSummary": {
					"price": {
						"value": product.price,
						"currency": self.get_currency_code()
					}
				},
				"listingPolicies": self._offer_data.get('listingPolicies', {}),
				"categoryId": self._offer_data['categoryId'],
				"tax": self._offer_data.get('tax', {
					"applyTax": False
				})
			}
			merchant_location_key = self._offer_data.get('merchantLocationKey')
			if not merchant_location_key:
				merchant_location_key = self.get_merchant_location_key_default()
			create_offer_data['merchantLocationKey'] = merchant_location_key

			offer_req = self.api('sell/inventory/v1/offer', create_offer_data, method = 'post')
			if self._last_status < 300:
				offer_id = offer_req.offerId
				self.api(f'sell/inventory/v1/offer/{offer_id}/publish', method = 'post')
				return Response().success()
			errors = []
			if offer_req.errors:
				for error in offer_req.errors:
					errors.append(error.longMessage or error.message)
			return Response().error(msg = '_lic_nl_'.join(errors))
		sync_data = {

			"sku": sku
		}
		if self.is_setting_sync_qty() or is_update:
			sync_data['shipToLocationAvailability'] = {
				'quantity': product.qty
			}
		offer_data = {}
		offer = self.api('sell/inventory/v1/offer', data = {'sku': sku})
		if self._last_status == 200:
			default_offer = offer['offers'][0]
			if default_offer.get('listing') and default_offer['listing']['listingId'] != item_id:
				return Response().create_response(result = 'inventory')
			self._offer_data = offer['offers'][0]
			offer_id = offer['offers'][0]['offerId']
			offer_data['offerId'] = offer_id
			if self.is_setting_sync_qty() or is_update:
				offer_data['availableQuantity'] = product.qty
			if self.is_setting_sync_price() or is_update:
				offer_data['price'] = {
					"value": product.price,
					"currency": offer['offers'][0]['pricingSummary']['price']['currency']
				}
		else:
			return Response().create_response('no_offer')
		sync_data['offers'] = [offer_data]
		update = self.api('sell/inventory/v1/bulk_update_price_quantity', data = {"requests": [sync_data]}, method = 'POST')
		if self._last_status >= 300:
			errors = []
			if update.responses:
				for error in update.responses:
					if not error.errors:
						continue
					for row in error.errors:
						if to_int(row.errorId) == 25013:
							create_inventory_item = self.create_inventory_item(product, parent, item_id = item_id)
							if create_inventory_item.result != Response.SUCCESS:
								return create_inventory_item
							update = self.api('sell/inventory/v1/bulk_update_price_quantity', data = {"requests": [sync_data]}, method = 'POST')

		if self._last_status >= 300:
			errors = []
			if update.responses:
				for error in update.responses:
					if not error.errors:
						continue
					for row in error.errors:
						msg = error.longMessage or error.message
						if msg and to_str(msg).find('You are not allowed to revise an ended item') != -1:
							self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.ebay_status', 'ended')
							return Response().success()
						errors.append(row.longMessage or row.message)
			return Response().error(msg = '_lic_nl_'.join(errors))
		if is_update:
			inventory_item = self.api(f'sell/inventory/v1/inventory_item/{product.sku}')
			if self._last_status < 300:
				inventory_item['product']['title'] = product.name
				images = []
				if product.thumb_image.url:
					images.append(product.thumb_image.url)
				for image in product.images:
					images.append(image.url)
				if not images and parent and parent.thumb_image.url:
					images.append(parent.thumb_image.url)
				inventory_item['product']['imageUrls'] = images
				inventory_item_update = self.api(f'sell/inventory/v1/inventory_item/{product.sku}', inventory_item, method = 'put')

		return Response().success()


	def simple_update_inventory_by_offer(self, product):
		offer = self.api('sell/inventory/v1/offer', data = {'sku': product.sku})
		if self._last_status != 200:
			try:
				msg = offer['errors'][0]['longMessage']
			except:
				msg = "Can't get offer"
			return Response().error(msg = msg)
		offer_data = offer['offers'][0]
		price = product.price if self.is_setting_sync_price() else offer_data['pricingSummary']['price']['value']
		qty = product.qty if self.is_setting_sync_qty() else offer_data['availableQuantity']
		offer_id = offer_data['offerId']
		del offer_data['offerId']
		offer_data['availableQuantity'] = qty
		offer_data['pricingSummary']['price']['value'] = price
		update = self.api(f'sell/inventory/v1/offer/{offer_id}', offer_data, 'put')
		if self._last_status >= 300:
			errors = []
			if update.errors:
				for error in update.errors:
					errors.append(error.message)
			return Response().error(msg = '_lic_nl_'.join(errors))
		return Response().success()


	def channel_sync_inventory_by_inventory_api(self, product_id, product, is_update = False):
		if product.is_retry_inventory:
			return Response().error(msg = "retry_inventory")
		self._offer_data = dict()
		self._inventory_item_data = dict()

		if not product.variants:
			simple_sync = self.simple_sync_inventory_by_inventory_api(product, item_id = product_id, is_update = is_update)
			if simple_sync.result == 'inventory':
				self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', False)
				product['channel'][f'channel_{self.get_channel_id()}']['inventory_api'] = False
				product.is_retry_inventory = True
				if is_update:
					return self.product_channel_update(product_id, product, None)
				return self.channel_sync_inventory(product_id, product, None)
			return simple_sync
		variant_default = False
		number_error = 0
		msg_error = ''
		same_error = True
		variant_no_error = []
		no_offer = []
		for variant in product.variants:
			if self.is_variant_removed(variant):
				inventory_item = self.api(f'sell/inventory/v1/inventory_item/{variant.sku}', method = 'delete')
				if self._last_status < 300:
					self.product_deleted(variant['_id'], variant, self.get_channel_id())
				continue
			variant_update = self.simple_sync_inventory_by_inventory_api(variant, item_id = product_id, is_update = is_update, parent = product)
			if variant_update.result != Response.SUCCESS:
				if variant_update.result == 'inventory':
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', False)
					product['channel'][f'channel_{self.get_channel_id()}']['inventory_api'] = False
					product.is_retry_inventory = True
					if is_update:
						return self.product_channel_update(product_id, product, None)
					return self.channel_sync_inventory(product_id, product, None)
				if variant_update.result == 'no_offer':
					no_offer.append(variant)
					continue
				if not msg_error:
					msg_error = variant_update.msg
				if variant_update.msg and variant_update.msg != msg_error:
					same_error = False
				number_error += 1
				update_data = {
					f'channel.channel_{self.get_channel_id()}.error_message': f"{variant_update.msg}",
					f'channel.channel_{self.get_channel_id()}.sync_error': True,

				}
				self.get_model_catalog().update(variant['_id'], update_data)
			else:
				variant_default = self.api(f'sell/inventory/v1/inventory_item/{variant.sku}')
				variant_no_error.append(variant['_id'])
		for variant in no_offer:
			variant_update = self.simple_sync_inventory_by_inventory_api(variant, create_offer = True, parent = product, item_id = product_id, is_update = is_update)
			if variant_update.result != Response.SUCCESS:
				if variant_update.result == 'inventory':
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', False)
					product['channel'][f'channel_{self.get_channel_id()}']['inventory_api'] = False
					product.is_retry_inventory = True
					if is_update:
						return self.product_channel_update(product_id, product, None)
					return self.channel_sync_inventory(product_id, product, None)
				if not msg_error:
					msg_error = variant_update.msg
				if variant_update.msg and variant_update.msg != msg_error:
					same_error = False
				number_error += 1
				update_data = {
					f'channel.channel_{self.get_channel_id()}.error_message': f"{variant_update.msg}",
					f'channel.channel_{self.get_channel_id()}.sync_error': True,

				}
				self.get_model_catalog().update(variant['_id'], update_data)
			else:
				variant_no_error.append(variant['_id'])
		if variant_no_error:
			update_data = {
				f'channel.channel_{self.get_channel_id()}.error_message': f"",
				f'channel.channel_{self.get_channel_id()}.sync_error': False,

			}
			self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', variant_no_error, 'in'), update_data)
		if not number_error:
			if is_update and variant_default:
				inventory_item_group_key = variant_default['inventoryItemGroupKeys'][0]
				inventory_item_group = self.api(f'sell/inventory/v1/inventory_item_group/{inventory_item_group_key}')
				if self._last_status < 300:
					inventory_item_group['title'] = product.name
					images = []
					if product.thumb_image.url:
						images.append(product.thumb_image.url)
					for image in product.images:
						images.append(image.url)
					inventory_item_group['imageUrls'] = images
					inventory_item_group_update = self.api(f'sell/inventory/v1/inventory_item_group/{inventory_item_group_key}', inventory_item_group, method = 'put')

			return Response().success()
		response_msg = msg_error if same_error else f"Have {number_error} sync error"
		return Response().error(msg = response_msg)


	def is_need_relist(self, error_code):
		return to_int(error_code) in [21916750, 291]


	def revise_inventory_status(self, item_id, product):
		update = {
			'ItemID': item_id,
			'Quantity': product.qty,
			'StartPrice': product.price
		}
		if not self.is_setting_sync_qty():
			del update['Quantity']
		if not self.is_setting_sync_price():
			del update['StartPrice']
		xml_body = self.dict_to_xml_product_body('ReviseInventoryStatus', {'InventoryStatus': update})
		product_response = self.xml_api('ReviseInventoryStatus', xml_body)
		response = product_response.get(f'ReviseInventoryStatusResponse')
		if not response:
			return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		if response.get('Errors'):
			errors = obj_to_list(response['Errors'])
			for error in errors:
				if self.is_need_refresh(to_int(error.get('ErrorCode'))):
					self.add_product_to_need_refresh(product['_id'])
				if to_int(error.get('ErrorCode')) == 21919474:
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', True)
					return self.channel_sync_inventory_by_inventory_api(item_id, product)
				if self.is_need_relist(to_int(error.get('ErrorCode'))):
					if self.allow_relist(product) and self.is_setting_sync_qty() and product.qty > 0:
						relist = self.re_listing(item_id, product)
						if relist.result != Response.SUCCESS:
							return relist
						new_item_id = relist.data
						return self.revise_inventory_status(new_item_id, product)
					else:
						self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.ebay_status', 'ended')
						return Response().success()

		if response.Ack in ['Success', 'Warning']:
			return Response().success()
		msg_errors = product_response.get('msg_errors')
		return Response().error(msg = msg_errors)


	def is_need_refresh(self, error_code):
		return error_code in [21916664, 21919248, 21916639, 21916587, 21916585, 21916736]


	def channel_sync_inventory(self, product_id, product, products_ext):
		# shipping_template = product.get('template_data', {}).get('shipping')
		# payment_template = product.get('template_data', {}).get('payment')
		# price_template = product.get('template_data', {}).get('price')
		category_template = product.get('template_data', {}).get('category')
		price_template = product.get('template_data', {}).get('price')

		setting_price = self.is_setting_sync_price()
		setting_qty = self.is_setting_sync_qty()
		setting_sku = self.is_setting_sync_sku()
		setting_title = self.is_setting_sync_title()
		out_of_stock_control = True if self._state.channel.config.setting.get('qty', {}).get('out_of_stock_control') == 'enable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		if self.is_sync_product_invisible(product):
			if not out_of_stock_control:
				self.ended_listing(product_id, product)
				return Response().success()
			if not product.variants:
				product.qty = 0
			else:
				for variant in product.variants:
					variant.qty = 0
		product_data = dict()
		product_data['ItemID'] = product_id
		channel_data = product.channel.get(f'channel_{self.get_channel_id()}', {})
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		product_qty = product.qty
		if product.variants:
			product_qty = 0
			for variant in product.variants:
				product_qty += to_int(variant.qty)
		if listing_type == 'Chinese':
			import_method = 'ReviseItem'
			if setting_price:
				price_template = product.get('template_data', {}).get('price')

				if price_template:
					# if price_template.auction_price and price_template.auction_price.buy_it_now_price.status == 'enable':
					# 	product_data['BuyItNowPrice'] = price_template.auction_price.buy_it_now_price.price
					product_data['StartPrice'] = price_template.auction_price.start_price.price
					if price_template.auction_price.reserve_price.price:
						product_data['ReservePrice'] = price_template.auction_price.reserve_price.price
				if not product_data.get('StartPrice'):
					product_data['StartPrice'] = self.to_ebay_price(product)
		else:
			import_method = 'ReviseFixedPriceItem'
			if setting_price:
				product_data['StartPrice'] = self.to_ebay_price(product)
				if not product.variants and self.is_use_stp(product):
					if self.is_special_price(product):
						product_data['DiscountPriceInfo'] = {
							"OriginalRetailPrice": product.price
						}
						product_data['StartPrice'] = product.special_price.price
					else:
						product_data['DiscountPriceInfo'] = {
							"OriginalRetailPrice": 0
						}
		sync_best_offer = False
		if setting_price:
			if price_template and price_template.fixed_price.best_offer and price_template.fixed_price.best_offer.status == PriceTemplate.ENABLE:
				best_offer = price_template.fixed_price.best_offer
				sync_best_offer = True
				product_data['BestOfferDetails'] = {
					'BestOfferEnabled': True
				}
				if not product_data.get('ListingDetails'):
					product_data['ListingDetails'] = dict()
				if best_offer.accept_price.status == PriceTemplate.ENABLE:
					if best_offer.accept_price.status == PriceTemplate.ENABLE and best_offer.accept_price.price:
						product_data['ListingDetails']['BestOfferAutoAcceptPrice'] = best_offer.accept_price.price
				if best_offer.decline_price.status == PriceTemplate.ENABLE:
					if best_offer.decline_price.status == PriceTemplate.ENABLE and best_offer.decline_price.price:
						product_data['ListingDetails']['MinimumBestOfferPrice'] = best_offer.decline_price.price
			else:
				product_data['BestOfferDetails'] = {
					'BestOfferEnabled': False
				}
		if setting_qty:
			if to_int(product_qty) == 0:
				if not out_of_stock_control:
					self.ended_listing(product_id, product)
					return Response().success()
			else:
				ebay_status = product.channel[f'channel_{self.get_channel_id()}'].get('ebay_status')
				if ebay_status == 'ended':
					relist = self.re_listing(product_id, product)
					product_id = relist.data
					if relist.result != Response.SUCCESS:
						self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.ebay_status', 'ended')
						return Response().success()
			product_data['Quantity'] = product.qty
		if product['channel'][f'channel_{self.get_channel_id()}'].get('inventory_api'):
			return self.channel_sync_inventory_by_inventory_api(product_id, product)
		if not sync_best_offer and not product.variants and listing_type == 'FixedPriceItem' and (not self.is_use_stp(product) or not self.is_special_price(product)):
			return self.revise_inventory_status(product_id, product)
		if setting_sku:
			product_data['SKU'] = product.sku
		if setting_title:
			product_data['Title'] = to_str(product.name[0:80])
		ebay_product = self.get_product_by_id(product_id)
		if ebay_product.result != Response.SUCCESS:
			return Response().success(product)
		ebay_product_data = ebay_product['data']
		ebay_product_data['syncing'] = True
		ebay_product_ext = self.get_products_ext_export([ebay_product_data])
		ebay_convert = self.convert_product_export(ebay_product_data, ebay_product_ext['data'])
		if ebay_convert.result != Response.SUCCESS:
			return Response().success(product)
		convert = ebay_convert.data
		all_ebay_variants = dict()
		for variant in convert.variants:
			all_ebay_variants[to_str(variant['id'])] = variant
		specifics_name = list()

		for specific in category_template.specifics:
			# if specific.value:
			specifics_name.append(specific.name)
		ebay_variant_attributes = self.get_ebay_variant_attributes(product)

		if product.variants:
			ebay_variants = list()
			number_sold_out = 0
			variation_options = self.variants_to_option(product.variants)
			specific = list()
			for option_name, option_values in variation_options.items():
				attribute_name = self.get_variant_attribute_name(option_name, specifics_name, ebay_variant_attributes)
				# ebay_variant_attributes.append(attribute_name)

				specific.append({
					'Name': attribute_name,
					'Value': option_values
				})
			list_sku = []
			for variant in product.variants:
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				ebay_variant = all_ebay_variants.get(to_str(variant_id))
				variant_data = dict()
				if variant.sku and variant.sku not in list_sku:
					variant_data['SKU'] = variant.sku
					list_sku.append(variant.sku)
				listing_details = dict()
				upc = self.get_product_identifier_unavailable_text()
				if self.valid_upc(variant.upc):
					upc = variant.upc
				listing_details['UPC'] = upc
				if self.is_eu():
					if listing_details.get('UPC'):
						listing_details['EAN'] = listing_details.get('UPC')
						del listing_details['UPC']

					if self.valid_ean(variant.ean):
						listing_details['EAN'] = variant.ean

				if listing_details:
					variant_data['VariationProductListingDetails'] = listing_details
				if setting_price:
					variant_data['StartPrice'] = self.to_ebay_price(variant)
					if self.is_use_stp(variant):
						if self.is_special_price(variant):
							variant_data['DiscountPriceInfo'] = {
								"OriginalRetailPrice": variant.price
							}
							variant_data['StartPrice'] = variant.special_price.price
						else:
							variant_data['DiscountPriceInfo'] = {
								"OriginalRetailPrice": 0
							}
				else:
					if ebay_variant:
						variant_data['StartPrice'] = ebay_variant.price
						if self.is_use_stp(ebay_variant):
							if self.is_special_price(ebay_variant):
								variant_data['DiscountPriceInfo'] = {
									"OriginalRetailPrice": ebay_variant.price
								}
								variant_data['StartPrice'] = ebay_variant.special_price.price
							else:
								variant_data['DiscountPriceInfo'] = {
									"OriginalRetailPrice": 0
								}
					else:
						variant_data['StartPrice'] = variant['channel'][f'channel_{self.get_channel_id()}'].get('price') or variant.price

				if setting_qty:
					variant_qty = variant.qty
					if variant.invisible and not self.is_keep_product_active():
						variant_qty = 0
					if variant_qty <= 0:
						number_sold_out += 1
					variant_data['Quantity'] = variant_qty
				else:
					if ebay_variant:
						variant_data['Quantity'] = ebay_variant.qty
					else:
						variant_data['Quantity'] = variant['channel'][f'channel_{self.get_channel_id()}'].get('qty') or variant.qty

				variant_attributes = list()
				for attribute in variant.attributes:
					if not attribute.use_variant:
						continue
					variant_attributes.append({
						'Name': self.get_variant_attribute_name(attribute.attribute_name, specifics_name, ebay_variant_attributes),
						'Value': attribute.attribute_value_name,
					})
				variant_data['VariationSpecifics'] = {
					'NameValueList': variant_attributes
				}
				ebay_variants.append(variant_data)
			product_data['Variations'] = {
				'VariationSpecificsSet': {
					"NameValueList": specific
				},
				'Variation': ebay_variants
			}
			if setting_qty and number_sold_out == to_len(product.variants) and not out_of_stock_control:
				self.ended_listing(product_id, product)
				return Response().success()
		else:
			product_data['ProductListingDetails'] = dict()
			upc = self.get_product_identifier_unavailable_text()
			if self.valid_upc(product.upc):
				upc = product.upc
			product_data['ProductListingDetails']['UPC'] = upc
			if self.is_eu():
				if product_data['ProductListingDetails']['UPC']:
					product_data['ProductListingDetails']['EAN'] = upc
					del product_data['ProductListingDetails']['UPC']

				if self.valid_ean(product.ean):
					product_data['ProductListingDetails']['EAN'] = product.ean

		ebay_specifics = convert.template_data.category.specifics
		item_specifics = list()
		for specific in ebay_specifics:
			if specific.value:
				specific_value = to_str(specific.value).split('|')
				if to_len(specific_value) == 1:
					if is_decimal(specific.value) and not to_decimal(specific.value):
						continue
					specific_data = {
						'Name': specific.name,
						'Value': specific.value,

					}
				else:
					specific_data = {
						'Name': specific.name,
						'Value': specific_value,

					}
				item_specifics.append(specific_data)
		product_data['ItemSpecifics'] = {
			'NameValueList': item_specifics
		}
		product_xml = self.dict_to_xml_product_body(import_method, {
			'Item': product_data
		})
		product_response = self.xml_api(import_method, product_xml)
		response = product_response.get(f'{import_method}Response')
		if not response:
			return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		specific_error = []
		while True:
			if response.get('Errors'):
				errors = obj_to_list(response['Errors'])
				specific_duplicate_error = False
				for error in errors:
					if to_int(error.get('ErrorCode')) == 21919309:
						specific_duplicate_error = error
						break
				if not specific_duplicate_error:
					break
				specific_error.append(specific_duplicate_error['ErrorParameters'][-1]['Value'])
				item_specifics = list()
				for specific in ebay_specifics:
					if specific.value:
						specific_value = to_str(specific.value).split('|')
						if to_len(specific_value) == 1:
							if is_decimal(specific.value) and not to_decimal(specific.value):
								continue
							specific_data = {
								'Name': specific.name,
								'Value': specific.value,

							}
						else:
							specific_data = {
								'Name': specific.name,
								'Value': specific_value,

							}
						if specific.name in specific_error and isinstance(specific_data['Value'], list):
							specific_value = ','.join(specific_data['Value'])
							specific_data = {
								'Name': specific.name,
								'Value': specific_value,

							}
						item_specifics.append(specific_data)
				product_data['ItemSpecifics'] = {
					'NameValueList': item_specifics
				}
				product_xml = self.dict_to_xml_product_body(import_method, {
					'Item': product_data
				})
				product_response = self.xml_api(import_method, product_xml)
				response = product_response.get(f'{import_method}Response')
				if not response:
					return Response().error(code = Errors.EBAY_NOT_RESPONSE)
				continue
			break
		if response.get('Errors'):
			errors = obj_to_list(response['Errors'])
			retry = False
			delete_fields = []
			for error in errors:
				if to_int(error.get('ErrorCode')) == 21916639:
					product_data['Variations']['Pictures'] = ''
					retry = True
				if to_int(error.get('ErrorCode')) == 23005:
					delete_fields.append('Item.ListingDetails.MinimumBestOfferPrice')
					retry = True
					break

			if retry:
				body_xml = {
					'Item': product_data
				}
				if delete_fields:
					body_xml['DeletedField'] = delete_fields
				product_xml = self.dict_to_xml_product_body(import_method, body_xml)
				product_response = self.xml_api(import_method, product_xml)
				response = product_response.get(f'{import_method}Response')
				if not response:
					return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		if response.get('Errors'):
			errors = obj_to_list(response['Errors'])
			for error in errors:
				if self.is_need_refresh(to_int(error.get('ErrorCode'))):
					self.add_product_to_need_refresh(product['_id'])
				if to_int(error.get('ErrorCode')) == 21919474:
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', True)
					return self.channel_sync_inventory_by_inventory_api(product_id, product)
				if self.is_need_relist(to_int(error.get('ErrorCode'))):
					if setting_qty and product.qty > 0 and self.allow_relist(product):
						relist_item = self.re_listing(product_id, product, product_data)
						if relist_item.result != Response.SUCCESS:
							return relist_item
						new_item_id = relist_item.data
						product_xml = product_xml.replace(to_str(product_id), to_str(new_item_id))
						product_response = self.xml_api(import_method, product_xml)
						response = product_response.get(f'{import_method}Response')
						if not response:
							return Response().error(code = Errors.EBAY_NOT_RESPONSE)
					else:
						self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.ebay_status', 'ended')
						return Response().success()
				if to_int(error.get('ErrorCode')) == 515:
					self.out_of_stock_control_preference()
					product_response = self.xml_api(import_method, product_xml)
					response = product_response.get(f'{import_method}Response')
					if not response:
						return Response().error(code = Errors.EBAY_NOT_RESPONSE)

		if response.Ack in ['Success', 'Warning']:
			specifics_name = list()
			for specific in category_template.specifics:
				# if specific.value:
				specifics_name.append(specific.name)
			for variant in product.variants:
				for attribute in variant.attributes:
					attribute.attribute_name = self.get_variant_attribute_name(attribute.attribute_name, specifics_name, ebay_variant_attributes)
				variant_id = f'{product_id}-{self.variant_key_generate(variant)}'
				if not variant['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
					self.insert_map_product(variant, variant['_id'], variant_id)
				else:
					self.update_map_product(variant, variant['_id'], variant_id)
			# if ebay_variant_attributes and product.channel[f'channel_{self.get_channel_id()}'].get('ebay_variant_attributes') != ebay_variant_attributes:
			# 	self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.ebay_variant_attributes', ebay_variant_attributes)
			return Response().success()
		msg_errors = product_response.get('msg_errors')
		return Response().error(msg = msg_errors)


	def parse_dict_to_xml(self, obj, declaration = '<?xml version="1.0" encoding="utf-8"?>', item_tag = 'item'):
		# xml = ''
		# if isinstance(obj, list):
		# 	item_elements = []
		# 	for item in obj:
		# 		item_element = tostring(bf.etree(item, root = Element(item_tag))).decode('utf-8')
		# 		item_elements.append(item_element)
		# 	xml = '\n'.join(item_elements)
		# if isinstance(obj, dict):
		# 	item_elements = []
		# 	for key, value in obj.items():
		# 		item_element = tostring(bf.etree(value, root = Element(key))).decode('utf-8')
		# 		item_elements.append(item_element)
		xml = xmltodict.unparse(obj, pretty = True, full_document = False)
		if declaration:
			xml = declaration + '\n' + xml
		return xml


	def get_product_by_updated_at(self):
		return self.get_products_main_export()


	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		limit_data = 200
		products = list()
		if self._is_pull_item_id and self._pull_item_id_list:
			if self._pull_item_id_list:
				return Response().success(data = self._pull_item_id_list)

			return Response().finish()

		if not self._is_pull_item_id and self._pull_active_listing:
			if not self.is_refresh_process() and self._is_create_feed_active_product:
				page_number = self._index_feed_active_listing
				if page_number < self._number_list_feed_active_listing:
					products = self._feed_active_listing[page_number]
					self._index_feed_active_listing += 1
				else:
					self._pull_active_listing = False
			else:
				page_number = self._state.pull.process.products.page_number
				if not page_number:
					page_number = 0
				self._product_page_number = page_number + 1
				product_response = self.api_get_products(self._product_page_number, limit_data)
				if product_response.GetMyeBaySellingResponse.ActiveList:
					try:
						response_page_number = to_int(product_response.GetMyeBaySellingResponse.ActiveList.PaginationResult.TotalNumberOfPages)
						if self._product_page_number > response_page_number:
							self._pull_active_listing = False
						else:
							products = product_response.GetMyeBaySellingResponse.ActiveList.ItemArray.Item
					except Exception:
						self.log_traceback()
				else:
					self._pull_active_listing = False

		# return Response().finish()
		if not products and self.is_import_inactive():
			page_number = self._state.pull.process.products.ended_page_number
			if not page_number:
				page_number = 0
			self._product_page_number = page_number + 1
			product_response = self.api_get_ended_products(self._product_page_number, limit_data)
			try:
				response_page_number = to_int(product_response.GetMyeBaySellingResponse.UnsoldList.PaginationResult.TotalNumberOfPages)
				if self._product_page_number > response_page_number:
					return Response().finish()
				products = product_response.GetMyeBaySellingResponse.UnsoldList.ItemArray.Item
			except Exception:
				return Response().finish()
		if products:
			products = obj_to_list(products)
			data = list()
			for product in products:
				price = product.BuyItNowPrice or product.Price
				if self.get_currency_code() and price and price.get('@currencyID') not in self.get_currency_code().split(','):
					continue
				data.append(product)
			if not data:
				if self._pull_active_listing:
					self._state.pull.process.products.page_number = self._product_page_number
				else:
					self._state.pull.process.products.ended_page_number = self._product_page_number
				return self.get_products_main_export()
			return Response().success(data = data)
		return Response().finish()


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.ItemID


	def set_imported_product(self, imported):
		super().set_imported_product(imported)
		if self._pull_active_listing:
			self._state.pull.process.products.page_number = self._product_page_number
		else:
			self._state.pull.process.products.ended_page_number = self._product_page_number


	def api_get_item(self, item_id):
		body = f'''<?xml version="1.0" encoding="utf-8"?>
				<GetItemRequest xmlns="urn:ebay:apis:eBLBaseComponents">
					<ItemID>{item_id}</ItemID>
					<IncludeItemSpecifics>true</IncludeItemSpecifics>
					<IncludeItemCompatibilityList>true</IncludeItemCompatibilityList>
					<DetailLevel>ReturnAll</DetailLevel>
				</GetItemRequest>'''
		return self.xml_api(f'GetItem', body)


	def get_products_ext_export(self, products):
		# extends = Prodict()
		# for product in products:
		# 	if self.get_currency_code() and product.BuyItNowPrice and product.BuyItNowPrice.get('@currencyID') != self.get_currency_code():
		# 		continue
		# 	item_id = product.ItemID
		# 	offer_response = self.api_get_item(item_id)
		# 	extends[item_id] = offer_response.GetItemResponse.Item
		return Response().success()


	def get_name_shipping_service(self, service):
		name = service['ShippingService']
		if service.get('ShippingTimeMin') and service.get('ShippingTimeMax'):
			if to_int(service.get('ShippingTimeMin')) == to_int(service.get('ShippingTimeMax')):
				if to_int(service.get('ShippingTimeMin')) == 1:
					day_title = 'day'
				else:
					day_title = 'days'
				name += f" (about {service.get('ShippingTimeMin')} business {day_title}"
			else:
				name += f" ({service['ShippingTimeMin']} - {service['ShippingTimeMax']} business days)"
		return name


	def is_skip_product_without_sku(self):
		return self._state.channel.config.api.skip_product_without_sku


	def finish_product_export(self):
		super(ModelChannelsEbay, self).finish_product_export()
		if self.is_refresh_process() and not self._state.channel.config.api.no_update_status:
			try:
				if not self._state.ebay_index:
					self.get_model_state().create_index(f'channel.channel_{self.get_channel_id()}.is_ebay_active')
					self._state.ebay_index = True
				where = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.product_id', '', '>')
				where.update(self.get_model_catalog().create_where_condition('is_variant', False))
				self.get_model_catalog().update_many(where, {f'channel.channel_{self.get_channel_id()}.is_ebay_active': False})
				active_ids = split_list(self._active_item_id, 1000)

				for ids in active_ids:
					where_update = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.product_id', ids, 'in')
					self.get_model_catalog().update_many(where_update, {
						f'channel.channel_{self.get_channel_id()}.is_ebay_active': True,
						'invisible': False
					})
				where_end = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.is_ebay_active', False)
				where_active = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.is_ebay_active', True)
				self.get_model_catalog().update_many(where_end, {f'channel.channel_{self.get_channel_id()}.ebay_status': 'ended'})
				self.get_model_catalog().update_many(where_active, {f'channel.channel_{self.get_channel_id()}.ebay_status': 'active'})
				where_invisible = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.is_ebay_active', False)
				where_invisible.update(self.get_model_catalog().create_where_condition('is_variant', False))
				where_invisible.update(self.get_model_catalog().create_where_condition('invisible', False))
				id_src = ''
				while True:
					if id_src:
						where_invisible.update(self.get_model_catalog().create_where_condition('_id', id_src, '>'))
					refresh_products = self.get_model_catalog().find_all(where_invisible, select_fields = '_id', sort = '_id', limit = 200)
					if not refresh_products:
						break
					for product in refresh_products:
						time.sleep(0.1)
						id_src = product['_id']
						self.get_model_catalog().update(product['_id'], {
							'invisible': True,
							'updated_time': time.time()
						})
					if to_len(refresh_products) < 200:
						break

			except Exception:
				self.log_traceback()


	def _convert_refresh_product(self, product, product_ext):
		if self._pull_active_listing:
			self._active_item_id.append(to_str(product.ItemID))
		product_data = Product()
		item_id = product.ItemID
		product_data.sku = product.SKU
		if self._state.channel.config.item_id_to_sku:
			product_data.sku = item_id
		product_data.id = item_id
		allow_update = "qty,name,price,is_in_stock"
		product_data.allow_update = allow_update
		product_data.qty = to_int(product.QuantityAvailable)
		product_data.is_in_stock = to_int(product.QuantityAvailable) > 0
		product_data.name = product.Title
		product_data.price = product.SellingStatus.CurrentPrice.get('#text')
		if product.Variations and product.Variations.Variation:
			# variants_specifics = obj_to_list(product.Variations.VariationSpecificsSet.NameValueList)
			# specifics = {}
			# for row in variants_specifics:
			# 	specifics[row['Name']] = [{'name': row['Name'], 'value': a} for a in row['Value']]
			# combinations = self.combination_from_multi_dict(specifics)
			# variant_keys = []
			# for row in combinations:
			# 	attributes_row = []
			# 	for attribute in row:
			# 		attribute_data = ProductVariantAttribute()
			# 		attribute_data.attribute_name = attribute['name']
			# 		attribute_data.attribute_value_name = attribute['value']
			# 		attributes_row.append(attribute_data)
			# 	variant_keys.append(self.variant_key_generate_by_attributes(attributes_row))
			variants = obj_to_list(product.Variations.Variation)
			is_in_stock = False
			for variant in variants:
				variant_data = ProductVariant()

				qty = variant.Quantity
				if variant.SellingStatus and variant.SellingStatus.QuantitySold:
					qty = to_int(variant.Quantity) - to_int(variant.SellingStatus.QuantitySold)
				variant_data.qty = qty
				if qty > 0:
					is_in_stock = True
				variant_data.is_in_stock = qty > 0
				variant_data.allow_update = f"{allow_update},attributes"
				variant_data.price = variant.StartPrice.get('#text')
				variant_data.name = product.Title
				name_value_list = obj_to_list(variant.VariationSpecifics.NameValueList)
				for attribute in name_value_list:
					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_name = attribute.Name
					attribute_data.attribute_value_name = attribute.Value
					variant_data.attributes.append(attribute_data)
				variant_sku = variant.SKU
				variant_id = f"{item_id}-{self.variant_key_generate(variant_data)}"
				variant_data.id = variant_id
				variant_data.sku = variant_sku
				product_data.variants.append(variant_data)
			# product_data.variants = sorted(product_data.variants, key = lambda variant: variant_keys.index(self.variant_key_generate(variant)))

			product_data.is_in_stock = is_in_stock
		return Response().success(data = product_data)


	def is_freight_shipping(self, shipping_service):
		if shipping_service == 'Freight' and self.get_marketplace_id() == 'EBAY_US':
			return True
		if shipping_service == 'Courier' and self.get_marketplace_id() == 'EBAY_UK':
			return True
		if shipping_service == 'AU_Freight' and self.get_marketplace_id() == 'EBAY_AU':
			return True
		if shipping_service == 'CA_Freight' and self.get_marketplace_id() in ['EBAY_CA', 'EBAY_ENCA', "EBAY_FRCA"]:
			return True
		return False


	def replace_ebay_description(self, description):
		styles = re.findall('<style>.*</style>', to_str(description))
		if not styles:
			return description
		for row in styles:
			import_url = re.findall('@import url\([\'\"](.*?)[\'\"]\)', row)
			if import_url:
				replace = []
				for url in import_url:
					replace.append(f'<link rel="stylesheet" href="{url}">')
				description = description.replace(row, '\n'.join(replace))
		return description


	def _convert_product_export(self, product, products_ext):
		price = product.BuyItNowPrice or product.Price
		if self.get_currency_code() and price and price.get('@currencyID') not in self.get_currency_code().split(','):
			return Response().skip()
		if self.is_refresh_process():
			return self._convert_refresh_product(product, products_ext)
		item_id = product.ItemID
		if product.is_item_data:
			item_data = product
		else:
			item_data_response = self.api_get_item(item_id)
			if not item_data_response or not item_data_response.GetItemResponse or not item_data_response.GetItemResponse.Item:
				return Response().error("Don't get product in ebay")
			item_data = item_data_response.GetItemResponse.Item
		currency = item_data.Currency or item_data.SellingStatus.CurrentPrice.get('@currencyID')
		if self._pull_category_id_list and item_data.Storefront:
			item_category_check = []
			if item_data.Storefront.StoreCategoryID:
				item_category_check.append(to_int(item_data.Storefront.StoreCategoryID))
			if item_data.Storefront.StoreCategory2ID:
				item_category_check.append(to_int(item_data.Storefront.StoreCategory2ID))
			item_category_check = set(item_category_check)
			if not item_category_check.intersection(self._pull_category_id_list):
				return Response().skip()

		if not self.is_same_site(item_data.Site):
			return Response().skip()
		product_data = Product()
		product_data.sku = item_data.SKU
		if self._state.channel.config.api.custom_tags:
			product_data.tags = self._state.channel.config.api.custom_tags
		if self.is_skip_product_without_sku():
			if not item_data.SKU:
				if not item_data.Variations:
					return Response().skip()
				skip = True
				if item_data.Variations and item_data.Variations.Variation:
					variants = obj_to_list(item_data.Variations.Variation)
					for variant in variants:
						if variant.SKU:
							skip = False
							break
				if skip:
					return Response().skip()
		if self._state.channel.config.item_id_to_sku:
			product_data.sku = item_id
		product_data.id = item_id
		product_data.created_at = convert_format_time(item_data.ListingDetails.StartTime, "%Y-%m-%dT%H:%M:%S")
		product_data.qty = to_int(item_data.Quantity) - to_int(item_data.SellingStatus.QuantitySold)
		product_data.is_in_stock = product_data.qty > 0
		product_data.name = item_data.Title
		product_data.price = item_data.SellingStatus.CurrentPrice.get('#text')
		if self._state.channel.config.api.price_gt_limit and to_decimal(product_data.price) < to_decimal(self._state.channel.config.api.price_gt_limit):
			return Response().skip()

		listing_type = 'Auction' if item_data.ListingType in ['Auction', 'Chinese'] else 'FixedPriceItem'
		if self.is_skip_auction_item() and listing_type == 'Auction':
			return Response().skip()

		status = 'active'
		if item_data.ListingDetails and item_data.ListingDetails.EndingReason:
			status = 'ended'
		# try:
		# 	if item_data.ListingDetails and item_data.ListingDetails.EndTime:
		# 		endtime = isoformat_to_datetime(item_data.ListingDetails.EndTime)
		# 		if endtime.timestamp() < time.time():
		# 			status = 'ended'
		# except:
		# 	self.log_traceback()
		channel_data = {
			'listing_type': listing_type,
			'ebay_status': status,
		}
		try:
			if item_data.RelistParentID:
				channel_data['relist_parent_id'] = to_str(item_data.RelistParentID)
			if item_data.ListingDetails and item_data.ListingDetails.RelistedItemID:
				channel_data['relist_item_id'] = to_str(item_data.ListingDetails.RelistedItemID)
		except:
			self.log_traceback()
		if item_data.DiscountPriceInfo and item_data.DiscountPriceInfo.OriginalRetailPrice and item_data.DiscountPriceInfo.OriginalRetailPrice.get('#text') and to_decimal(item_data.DiscountPriceInfo.OriginalRetailPrice.get('#text')) > to_decimal(product_data.price):
			product_data.price = to_decimal(item_data.DiscountPriceInfo.OriginalRetailPrice.get('#text'))
			product_data.special_price.price = item_data.SellingStatus.CurrentPrice.get('#text')
			channel_data['use_stp'] = True

		product_data.description = self.replace_ebay_description(item_data.Description)
		product_data.seo_url = item_data.ListingDetails.ViewItemURL
		product_images = list()
		if item_data.PictureDetails:
			gallery_url = ''
			if item_data.PictureDetails.GalleryURL:
				product_data.thumb_image.url = re.sub('/\$_([0-9]+).', '/$_10.', item_data.PictureDetails.GalleryURL)
				gallery_url = product_data.thumb_image.url
				product_images.append(gallery_url)
			if item_data.PictureDetails.PictureURL:
				images = obj_to_list(item_data.PictureDetails.PictureURL)
				for index, image in enumerate(images):
					image_url = re.sub('/\$_([0-9]+).', '/$_10.', image)
					if not gallery_url:
						product_data.thumb_image.url = image_url
						gallery_url = image_url
						continue
					if image_url == gallery_url or image_url in product_images:
						continue
					product_images.append(image_url)
					image_data = ProductImage()
					image_data.url = image_url
					image_data.position = index + 1
					product_data.images.append(image_data)
		if item_data.ConditionDisplayName:
			product_data.condition = self.get_product_condition(item_data.ConditionDisplayName)
		payment_template = PaymentTemplate()
		shipping_template = ShippingTemplate()

		if item_data.ShippingPackageDetails:
			package_details = {
				'weight_major': 'WeightMajor',
				'weight_minor': 'WeightMinor',
			}
			weight_major = item_data.ShippingPackageDetails.get('WeightMajor')
			weight_minor = item_data.ShippingPackageDetails.get('WeightMinor')
			weight = 0
			weight_unit = 'lb'
			if weight_major and weight_major.get('#text'):
				weight = to_int(weight_major.get('#text'))
				if weight_major.get('@unit') == 'kg':
					# weight += to_int(weight_major.get('#text')) * 1000
					weight_unit = 'g'
			# else:
			# 	weight += to_int(weight_major.get('#text')) * 16
			if weight_minor and to_int(weight_minor.get('#text')):
				weight_minor_value = to_int(weight_minor.get('#text'))
				if weight_minor.get('@unit') == 'gr':
					weight = weight * 1000 + weight_minor_value
					weight_unit = 'g'
				else:
					weight = weight * 16 + weight_minor_value

					weight_unit = 'oz'

			product_data.weight = weight
			product_data.weight_units = weight_unit
			for field, ebay_field in package_details.items():
				if item_data.ShippingPackageDetails.get(ebay_field):
					channel_data[field] = to_int(item_data.ShippingPackageDetails.get(ebay_field).get('#text'))
					channel_data[f"{field}_unit"] = item_data.ShippingPackageDetails.get(ebay_field).get('@unit')
			package_details = {
				'width': 'PackageWidth',
				'length': 'PackageLength',
				'height': 'PackageDepth',
			}
			for field, ebay_field in package_details.items():
				if item_data.ShippingPackageDetails.get(ebay_field):
					product_data[field] = to_decimal(item_data.ShippingPackageDetails.get(ebay_field).get('#text'))
			if item_data.ShippingPackageDetails.ShippingPackage:
				shipping_template.domestic_shipping.shipping_package = item_data.ShippingPackageDetails.ShippingPackage
		if listing_type == 'Auction':
			channel_data['start_price'] = item_data.StartPrice.get('#text')
			channel_data['buy_it_now_price'] = item_data.BuyItNowPrice.get('#text')
			if item_data.ReservePrice:
				channel_data['reverse_price'] = item_data.ReservePrice.get('#text')

		if item_data.ProductListingDetails:
			listing_detail_field = {
				'epid': 'ProductReferenceID',
				'upc': 'UPC',
				'isbn': 'ISBN',
				'ean': 'EAN',
				'mpn': 'MPN',
			}
			for field, ebay_field in listing_detail_field.items():
				if item_data.ProductListingDetails.get(ebay_field) and item_data.ProductListingDetails.get(ebay_field) != 'Does not apply':
					product_data[field] = item_data.ProductListingDetails.get(ebay_field)
			if item_data.ProductListingDetails.ProductReferenceID and item_data.ProductListingDetails.ProductReferenceID != 'Does not apply':
				channel_data['epid'] = item_data.ProductListingDetails.ProductReferenceID
				channel_data['epid_data'] = {
					'epid': channel_data['epid'],
					'image': product_data.thumb_image.url,
					'title': item_data.Title,
					'url': f"https://www.ebay.com/p/{channel_data['epid']}"
				}
			if item_data.ProductListingDetails.BrandMPN:
				product_data.brand = item_data.ProductListingDetails.BrandMPN.Brand

		item_location = PaymentItemLocation()
		item_location.country = item_data.Country
		item_location.address = item_data.Location
		item_location.postal_code = item_data.PostalCode

		payment_template.auto_pay = ConstructBase.ENABLE if to_bool(item_data.AutoPay) else ConstructBase.DISABLE
		payment_template.paypal_email = item_data.PayPalEmailAddress
		payment_template.handling_time = item_data.DispatchTimeMax
		payment_template.payment_instructions = item_data.ShippingDetails.PaymentInstructions
		payment_template.item_location = item_location

		if item_data.ReturnPolicy:
			payment_template.return_policy.status = PaymentReturnPolicy.DISABLE
			if item_data.ReturnPolicy.ReturnsAcceptedOption == 'ReturnsAccepted':
				payment_template.return_policy.status = PaymentReturnPolicy.ENABLE
				domestic_return = BaseReturnPolicy()
				domestic_return.status = BaseReturnPolicy.ENABLE
				domestic_return.paid_by = item_data.ReturnPolicy.ShippingCostPaidBy
				domestic_return.within = item_data.ReturnPolicy.ReturnsWithinOption
				if item_data.ReturnPolicy.RefundOption == 'MoneyBackOrReplacement':
					domestic_return.replace_or_exchange = BaseReturnPolicy.ENABLE
				payment_template.return_policy.domestic_return = domestic_return
			if item_data.ReturnPolicy.InternationalReturnsAcceptedOption == 'ReturnsAccepted':
				payment_template.return_policy.status = PaymentReturnPolicy.ENABLE
				international_return = BaseReturnPolicy()
				international_return.status = BaseReturnPolicy.ENABLE
				international_return.paid_by = item_data.ReturnPolicy.InternationalShippingCostPaidByOption
				international_return.within = item_data.ReturnPolicy.InternationalReturnsWithinOption
				if item_data.ReturnPolicy.InternationalRefundOption == 'MoneyBackOrReplacement':
					international_return.replace_or_exchange = BaseReturnPolicy.ENABLE
				payment_template.return_policy.international_return = international_return
		payment_template.buyer_requirements.status = BuyerRequirement.ENABLE if not item_data.DisableBuyerRequirements else BuyerRequirement.DISABLE
		if item_data.BuyerRequirementDetails:
			payment_template.buyer_requirements.ship_to_registration_country = to_bool(item_data.ShipToRegistrationCountry)
			if item_data.BuyerRequirementDetails.MaximumItemRequirements:
				payment_template.buyer_requirements.maximum_item_requirements.status = ConstructBase.ENABLE
				payment_template.buyer_requirements.maximum_item_requirements.count = item_data.BuyerRequirementDetails.MaximumItemRequirements.MaximumItemCount
				payment_template.buyer_requirements.maximum_item_requirements.feedback = item_data.BuyerRequirementDetails.MaximumItemRequirements.MinimumFeedbackScore
			if item_data.BuyerRequirementDetails.MaximumUnpaidItemStrikesInfo:
				payment_template.buyer_requirements.maximum_unpaid_item_strikes.status = ConstructBase.ENABLE
				payment_template.buyer_requirements.maximum_unpaid_item_strikes.count = item_data.BuyerRequirementDetails.MaximumUnpaidItemStrikesInfo.Count
				payment_template.buyer_requirements.maximum_unpaid_item_strikes.period = item_data.BuyerRequirementDetails.MaximumUnpaidItemStrikesInfo.Period

		payment_template.ebay_tax_table = to_bool(item_data.UseTaxTable)
		if item_data.ShippingDetails:
			shipping_details = item_data.ShippingDetails

			if not to_bool(item_data.UseTaxTable) and shipping_details.SalesTax and to_decimal(shipping_details.SalesTax.SalesTaxPercent):
				payment_template.sales_tax.status = PaymentSalesTax.ENABLE
				payment_template.sales_tax.state = shipping_details.SalesTax.SalesTaxState
				payment_template.sales_tax.value = to_decimal(shipping_details.SalesTax.SalesTaxPercent)
				payment_template.sales_tax.shipping_include_tax = to_bool(shipping_details.SalesTax.ShippingIncludedInTax)

			shipping_template.global_shipping = "enable" if to_bool(item_data.ShippingDetails.GlobalShipping) else "disable"
			if to_bool(shipping_details.SellerExcludeShipToLocationsPreference) and shipping_details.ExcludeShipToLocation:
				shipping_template.excluded_locations.status = ConstructBase.ENABLE
				shipping_template.excluded_locations.locations = obj_to_list(shipping_details.ExcludeShipToLocation)
			if shipping_details.ShippingServiceOptions:
				shipping_service_options = obj_to_list(shipping_details.ShippingServiceOptions)
				domestic_shipping = DomesticShipping()
				profile_id = 0
				if shipping_details.ShippingDiscountProfileID:
					profile_id = shipping_details.ShippingDiscountProfileID
				shipping_type = 'LocalPickup'
				if shipping_details.ShippingType in ['FreightFlat', 'Freight']:
					shipping_type = 'Freight'
				if shipping_details.ShippingType in ['Calculated', 'CalculatedDomesticFlatInternational']:
					shipping_type = 'Calculated'
					if profile_id:
						domestic_shipping.calculated_shipping_discount = profile_id
				if shipping_details.ShippingType in ['Flat', 'FlatDomesticCalculatedInternational']:
					shipping_type = 'Flat'
					if profile_id:
						domestic_shipping.flat_shipping_discount = profile_id
				if shipping_details.PromotionalShippingDiscount:
					domestic_shipping.promotional_shipping_discount = True
				domestic_shipping.originating_postal_code = shipping_details.CalculatedShippingRate.OriginatingPostalCode if shipping_details.CalculatedShippingRate else None
				domestic_shipping.packaging_handling_costs = shipping_details.CalculatedShippingRate.PackagingHandlingCosts.get('#text') if shipping_details.CalculatedShippingRate and shipping_details.CalculatedShippingRate.PackagingHandlingCosts else 0
				if shipping_details.RateTableDetails and shipping_details.RateTableDetails.DomesticRateTableId:
					rate_table = EbayRateTable()
					rate_table.rate_table_id = shipping_details.RateTableDetails.DomesticRateTableId
					rate_table.rate_table_name = self.get_rate_table_name(shipping_details.RateTableDetails.DomesticRateTableId)
					domestic_shipping.rate_table = rate_table
				for shipping_service in shipping_service_options:
					if self.is_freight_shipping(shipping_service.ShippingService):
						shipping_type = 'Freight'
						break
					domestic_shipping_service = DomesticShippingService()
					domestic_shipping_service.shipping_service_id = shipping_service.ShippingService
					domestic_shipping_service.shipping_service = self.get_name_shipping_service(shipping_service)
					domestic_shipping_service.free_shipping = 1 if to_bool(shipping_service.FreeShipping) else 0
					domestic_shipping_service.cost = shipping_service.ShippingServiceCost.get('#text') if shipping_service.ShippingServiceCost else 0
					domestic_shipping_service.additional_cost = shipping_service.ShippingServiceAdditionalCost.get('#text') if shipping_service.ShippingServiceAdditionalCost else 0
					if shipping_details.ShippingType == 'Flat':
						domestic_shipping.flat_options_attributes.append(domestic_shipping_service)
					else:
						domestic_shipping.calculated_options_attributes.append(domestic_shipping_service)
				domestic_shipping.shipment_type = shipping_type

				shipping_template.domestic_shipping = domestic_shipping
			if item_data.ShippingPackageDetails:
				if item_data.ShippingPackageDetails.ShippingPackage:
					shipping_template.domestic_shipping.shipping_package = item_data.ShippingPackageDetails.ShippingPackage
				if item_data.ShippingPackageDetails.ShippingIrregular:
					shipping_template.domestic_shipping.shipping_irregular = True
			if shipping_details.ShippingType not in ['Freight', 'FreightFlat', 'NotSpecified'] and shipping_details.InternationalShippingServiceOption:
				shipping_service_options = obj_to_list(shipping_details.InternationalShippingServiceOption)
				international_shipping = InternationalShipping()
				if shipping_details.InternationalPromotionalShippingDiscount:
					international_shipping.promotional_shipping_discount = True
				international_shipping.status = ConstructBase.ENABLE
				profile_id = 0
				if shipping_details.InternationalShippingDiscountProfileID:
					profile_id = shipping_details.InternationalShippingDiscountProfileID
				shipping_type = 'Calculated'
				if shipping_details.ShippingType in ['Flat', 'CalculatedDomesticFlatInternational']:
					shipping_type = 'Flat'
					if profile_id:
						international_shipping.flat_shipping_discount = profile_id
				else:
					if profile_id:
						international_shipping.calculated_shipping_discount = profile_id
				international_shipping.shipment_type = shipping_type
				international_shipping.originating_postal_code = shipping_details.CalculatedShippingRate.OriginatingPostalCode if shipping_details.CalculatedShippingRate else None
				international_shipping.packaging_handling_costs = to_decimal(shipping_details.CalculatedShippingRate.InternationalPackagingHandlingCosts) if shipping_details.CalculatedShippingRate else 0
				if shipping_details.RateTableDetails and shipping_details.RateTableDetails.InternationalRateTableId:
					rate_table = EbayRateTable()
					rate_table.rate_table_id = shipping_details.RateTableDetails.InternationalRateTableId
					rate_table.rate_table_name = self.get_rate_table_name(shipping_details.RateTableDetails.InternationalRateTableId)
					international_shipping.rate_table = rate_table
				for shipping_service in shipping_service_options:
					international_shipping_service = InternationalShippingService()
					international_shipping_service.shipping_service_id = shipping_service.ShippingService
					international_shipping_service.shipping_service = self.get_name_shipping_service(shipping_service)
					international_shipping_service.cost = shipping_service.ShippingServiceCost.get('#text') if shipping_service.ShippingServiceCost else 0
					international_shipping_service.additional_cost = to_decimal(shipping_service.ShippingServiceAdditionalCost.get('#text')) if shipping_service.ShippingServiceAdditionalCost else 0
					if shipping_service.ShipToLocation:
						if to_str(shipping_service.ShipToLocation).lower() == 'worldwide':
							international_shipping_service.ship_to_location = 'Worldwide'
						else:
							international_shipping_service.additional_ship_to_locations = obj_to_list(shipping_service.ShipToLocation)
							international_shipping_service.ship_to_location = 'Custom'
					if shipping_details.ShippingType == 'Flat':
						international_shipping.flat_options_attributes.append(international_shipping_service)
					else:
						international_shipping.calculated_options_attributes.append(international_shipping_service)
				shipping_template.international_shipping = international_shipping

		category_template = EbayCategory()
		try:
			compatibility_fields = {
				'Year': 'year',
				'Make': 'make',
				'Model': 'model',
				'Submodel': 'sub_model',
			}
			if item_data.ItemCompatibilityList and item_data.ItemCompatibilityList.Compatibility:
				item_compatibility_list = obj_to_list(item_data.ItemCompatibilityList.Compatibility)
				for item_compatibility in item_compatibility_list:
					compatibility_data = EbayCompatibility()
					compatibility_data.notes = item_compatibility.CompatibilityNotes
					compatibility_list = obj_to_list(item_compatibility.NameValueList)
					for compatibility in compatibility_list:
						if not compatibility:
							continue
						if isinstance(compatibility, dict) and compatibility.get('Name') in compatibility_fields:
							compatibility_data[compatibility_fields[compatibility.get('Name')]] = compatibility.get('Value')
					category_template.compatibilities.append(compatibility_data)

		except:
			self.log_traceback()
		if item_data.PrimaryCategory:
			category_template.primary_category.category_id = item_data.PrimaryCategory.CategoryID
			category_template.primary_category.category_name = to_str(html_unescape(item_data.PrimaryCategory.CategoryName)).replace(':', ' > ')
			if self._state.channel.config.api.primary_category_to_category:
				category_path = category_template.primary_category.category_name.split('>')[-1]
				product_data.category_name_list.append(category_path.strip())
		# channel_data['category_path'] = category_template.primary_category.category_name
		if item_data.SecondaryCategory:
			category_template.secondary_category.category_id = item_data.SecondaryCategory.CategoryID
			category_template.secondary_category.category_name = to_str(html_unescape(item_data.SecondaryCategory.CategoryName)).replace(':', ' > ')
		if item_data.Storefront:
			skip_product = False
			custom_categories_filter = self.filter_by_custom_categories()
			if custom_categories_filter:
				skip_product = True
			if to_int(item_data.Storefront.StoreCategoryID):
				category_id, category_name = self.get_custom_category_name(item_data.Storefront.StoreCategoryID)
				category_template.store_category_1.category_id = category_id
				if custom_categories_filter and to_int(category_id) in custom_categories_filter:
					skip_product = False
				if category_name:
					category_template.store_category_1.category_name = category_name
					if not self._state.channel.config.api.primary_category_to_category:
						product_data.category_name_list.append(category_name)
			if to_int(item_data.Storefront.StoreCategory2ID):
				category_id, category_name = self.get_custom_category_name(item_data.Storefront.StoreCategory2ID)
				category_template.store_category_2.category_id = category_id
				if custom_categories_filter and to_int(category_id) in custom_categories_filter:
					skip_product = False
				if category_name:
					if not self._state.channel.config.api.primary_category_to_category:
						product_data.category_name_list.append(category_name)

					category_template.store_category_2.category_name = category_name
			if skip_product:
				return Response().skip()
		category_template.listing_type = listing_type
		category_template.condition.value.condition_id = item_data.ConditionID
		category_template.condition.value.condition_name = item_data.ConditionDisplayName
		if item_data.ConditionDescription:
			category_template.condition_note = item_data.ConditionDescription
		try:
			if item_data.ConditionDescriptors and item_data.ConditionDescriptors.ConditionDescriptor:
				condition_descriptors = obj_to_list(item_data.ConditionDescriptors.ConditionDescriptor)
				ebay_condition_descriptors = []
				for condition_descriptor in condition_descriptors:
					condition_descriptor_data = EbayConditionDescriptor()
					condition_descriptor_data.descriptor_id = condition_descriptor.Name
					values = list(map(lambda x: to_str(x), obj_to_list(condition_descriptor.Value)))
					condition_descriptor_data.descriptor_value_id = ','.join(values)
					ebay_condition_descriptors.append(condition_descriptor_data)
				category_template.condition_descriptor = ebay_condition_descriptors
		except:
			self.log_traceback()

		if item_data.ListingType in ['Chinese', 'Auction']:
			category_template.duration = item_data.ListingDuration
		else:
			category_template.duration = 'GTC'
		if item_data.ItemSpecifics and item_data.ItemSpecifics.NameValueList:
			attributes = obj_to_list(item_data.ItemSpecifics.NameValueList)
			attribute_special = ['ean', 'upc', 'model', 'barcode', 'gtin', 'gcid', 'epid', 'isbn', 'mpn', 'gtn', 'bpn']
			for attribute in attributes:
				item_specific = EbayCategorySpecifics()
				item_specific.name = attribute.Name
				item_specific.value = attribute.Value
				category_template.specifics.append(item_specific)
				attribute_name = attribute.Name.lower()
				if attribute_name == 'gtn':
					attribute_name = 'gtin'
				if attribute_name == 'Manufacturer Part Number'.lower():
					attribute_name = 'mpn'
				if attribute_name in attribute_special:
					values = attribute.Value
					if isinstance(values, list):
						values = ','.join(values)
					product_data[attribute_name] = values
					continue
				attribute_data = ProductAttribute()
				attribute_data.attribute_name = attribute.Name
				attribute_data.attribute_value_name = attribute.Value
				product_data.attributes.append(attribute_data)

		price_template = PriceTemplate()
		if item_data.BestOfferDetails and item_data.BestOfferDetails.BestOfferEnabled:
			price_template.fixed_price.best_offer.status = PriceTemplate.ENABLE
		if item_data.ListingDetails and item_data.ListingDetails.BestOfferAutoAcceptPrice:
			price_template.fixed_price.best_offer.accept_price.status = PriceTemplate.ENABLE
			price_template.fixed_price.best_offer.accept_price.price = to_decimal(item_data.ListingDetails.BestOfferAutoAcceptPrice.get('#text'))
		if item_data.ListingDetails and item_data.ListingDetails.MinimumBestOfferPrice:
			price_template.fixed_price.best_offer.decline_price.status = PriceTemplate.ENABLE
			price_template.fixed_price.best_offer.decline_price.price = to_decimal(item_data.ListingDetails.MinimumBestOfferPrice.get('#text'))
		business_template = BusinessTemplate()

		try:
			seller_profiles_check = item_data.SellerProfiles.SellerShippingProfile.ShippingProfileID
		except:
			seller_profiles_check = False

		if seller_profiles_check:
			try:
				fulfillment_policy = FulfillmentPolicyTemplate()
				fulfillment_policy.fulfillment_policy_id = item_data.SellerProfiles.SellerShippingProfile.ShippingProfileID
				fulfillment_policy.fulfillment_policy_name = item_data.SellerProfiles.SellerShippingProfile.ShippingProfileName
			except:
				fulfillment_policy = Prodict()

			try:
				payment_policy = PaymentPolicyTemplate()
				payment_policy.payment_policy_id = item_data.SellerProfiles.SellerPaymentProfile.PaymentProfileID
				payment_policy.payment_policy_name = item_data.SellerProfiles.SellerPaymentProfile.PaymentProfileName
			except:
				payment_policy = Prodict()

			try:
				return_policy = ReturnPolicyTemplate()
				return_policy.return_policy_id = item_data.SellerProfiles.SellerReturnProfile.ReturnProfileID
				return_policy.return_policy_name = item_data.SellerProfiles.SellerReturnProfile.ReturnProfileName
			except:
				return_policy = Prodict()

			if all([fulfillment_policy, payment_policy, return_policy]):
				business_template.fulfillment_policy = fulfillment_policy
				business_template.payment_policy = payment_policy
				business_template.return_policy = return_policy
				business_template.item_location = item_location

		template_data = {
			'category': category_template,
			'payment': payment_template,
			'shipping': shipping_template,
			'price': price_template,
			'business': business_template
		}

		if item_data.Variations and item_data.Variations.Variation:
			ebay_variant_attributes = list()
			ebay_variant_images = dict()
			variants_specifics = obj_to_list(item_data.Variations.VariationSpecificsSet.NameValueList)
			specifics = {}
			for row in variants_specifics:
				specifics[row['Name']] = [{'name': row['Name'], 'value': a} for a in row['Value']]
			combinations = self.combination_from_multi_dict(specifics)
			variant_keys = []
			for row in combinations:
				attributes_row = []
				for attribute in row:
					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_name = attribute['name']
					attribute_data.attribute_value_name = attribute['value']
					attributes_row.append(attribute_data)
				variant_keys.append(self.variant_key_generate_by_attributes(attributes_row))
			variants = obj_to_list(item_data.Variations.Variation)
			variants_image = obj_to_list(item_data.Variations.Pictures)
			is_in_stock = False
			for variant in variants:
				variant_data = ProductVariant()

				qty = variant.Quantity
				if variant.SellingStatus and variant.SellingStatus.QuantitySold:
					qty = to_int(variant.Quantity) - to_int(variant.SellingStatus.QuantitySold)
				if qty > 0:
					is_in_stock = True
				variant_data.qty = qty
				variant_data.is_in_stock = qty > 0

				variant_data.price = variant.StartPrice.get('#text')
				if variant.DiscountPriceInfo and variant.DiscountPriceInfo.OriginalRetailPrice and variant.DiscountPriceInfo.OriginalRetailPrice.get('#text') and to_decimal(variant.DiscountPriceInfo.OriginalRetailPrice.get('#text')) > to_decimal(variant_data.price):
					variant_data.price = to_decimal(variant.DiscountPriceInfo.OriginalRetailPrice.get('#text'))
					variant_data.special_price.price = variant.StartPrice.get('#text')
					channel_data['use_stp'] = True
				if variant.VariationProductListingDetails:
					listing_detail_field = {
						'epid': 'ProductReferenceID',
						'upc': 'UPC',
						'isbn': 'ISBN',
						'ean': 'EAN',
						'mpn': 'MPN',
					}
					for field, ebay_field in listing_detail_field.items():
						if variant.VariationProductListingDetails.get(ebay_field) and variant.VariationProductListingDetails.get(ebay_field) != 'Does not apply':
							variant_data[field] = variant.VariationProductListingDetails.get(ebay_field)
					# if item_data.ProductListingDetails.ProductReferenceID and item_data.ProductListingDetails.ProductReferenceID != 'Does not apply':
					# 	channel_data['epid'] = item_data.ProductListingDetails.ProductReferenceID
					# 	channel_data['epid_data'] = {
					# 		'epid': channel_data['epid'],
					# 		'image': product_data.thumb_image.url,
					# 		'title': item_data.Title,
					# 		'url': f"https://www.ebay.com/p/{channel_data['epid']}"
					# 	}
					if variant.VariationProductListingDetails.BrandMPN:
						variant_data.brand = variant.VariationProductListingDetails.BrandMPN.Brand
				variant_data.name = item_data.Title
				name_value_list = obj_to_list(variant.VariationSpecifics.NameValueList)
				for attribute in name_value_list:
					if attribute.Name not in ebay_variant_attributes:
						ebay_variant_attributes.append(attribute.Name)
					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_name = attribute.Name
					attribute_data.attribute_value_name = attribute.Value
					variant_data.attributes.append(attribute_data)
				variant_sku = variant.SKU
				# if not variant_sku:
				variant_id = f"{item_id}-{self.variant_key_generate(variant_data)}"
				variant_data.id = variant_id
				variant_data.sku = variant_sku or variant_sku
				variant_image = self.get_variant_specific_image(variant_data.attributes, variants_image)
				if variant_image:
					for image in variant_image:
						image_url = re.sub('/\$_([0-9]+).', '/$_10.', image)
						if not variant_data.thumb_image.url:
							variant_data.thumb_image.url = image_url
							continue
						image_data = ProductImage()
						image_data.url = image_url
						variant_data.images.append(image_data)
						if image_url in product_images:
							continue
						product_images.append(image_url)
				key_generate = self.variant_key_generate(variant_data)
				if key_generate in variant_keys:
					variant_data['index'] = variant_keys.index(key_generate)
				else:
					variant_data['index'] = to_len(variant_keys) + 1

				product_data.variants.append(variant_data)
			product_data.variants = sorted(product_data.variants, key = lambda variant: variant.get('index', 999))
			product_data.is_in_stock = is_in_stock
			channel_data['ebay_variant_attributes'] = ebay_variant_attributes
			try:
				if variants_image and to_len(ebay_variant_attributes) > 1:
					variant_image_options = list()
					default_variant_image = variants_image[0]
					for image in default_variant_image.VariationSpecificPictureSet:
						variant_image_options.append({
							'name': image.VariationSpecificValue,
							'image': image.PictureURL
						})
					ebay_variant_images['attribute'] = default_variant_image.get('VariationSpecificName')
					ebay_variant_images['options'] = variant_image_options
					channel_data['ebay_variant_images'] = ebay_variant_images
			except:
				self.log_traceback()
		product_data.template_data = template_data
		product_data.channel_data = channel_data
		return Response().success(data = product_data)


	def get_variant_specific_image(self, attributes, variants_image):
		if not variants_image:
			return False
		pictures = list()
		for image in variants_image:
			if not image or not image.VariationSpecificPictureSet:
				continue
			specific_attributes = obj_to_list(image.VariationSpecificPictureSet)

			for attribute in attributes:
				for specific_attribute in specific_attributes:
					if image.VariationSpecificName == attribute.attribute_name and attribute.attribute_value_name == specific_attribute.VariationSpecificValue and specific_attribute.PictureURL:
						pictures += obj_to_list(specific_attribute.PictureURL)
		# remove the duplicates but still keep the same order of the list
		unique_pictures = []
		_ = [unique_pictures.append(pic) for pic in pictures if pic not in unique_pictures]
		return unique_pictures


	def get_product_condition(self, condition_name):
		condition_name = to_str(condition_name).lower()
		if not condition_name:
			return Product.CONDITION_NEW
		condition_new = ['open box']
		if (condition_name.find('new') != -1 and condition_name != 'like new') or condition_name in condition_new:
			return Product.CONDITION_NEW
		if condition_name.find('re') != -1:
			return Product.CONDITION_RECONDITIONED
		return Product.CONDITION_USED


	def fulfillment_policy_import(self, template_id):
		model_template = Template()
		model_template.set_user_id(self._state.user_id)
		template = model_template.get(template_id)
		if not template:
			return Response().error(msg = 'Cannot get shipping template data.')
		if template.type != 'shipping':
			return Response().error(msg = f'Invalid shipping template: {template.type}')
		update = True if template.update == 'enable' else False
		url = 'sell/account/v1/fulfillment_policy'
		method = 'post'
		fulfillment_id = template.get('fulfillmentPolicyId')
		if update:
			if not fulfillment_id:
				return Response().error(msg = 'Cannot update shipping template. Invalid fulfillment id.')
			url += f'/{fulfillment_id}'
			method = 'put'
		elif not update and fulfillment_id:
			return Response().success(data = {'fulfillmentPolicyId': fulfillment_id})
		fulfillment_post_data = dict(categoryTypes = [
			{
				'name': 'ALL_EXCLUDING_MOTORS_VEHICLES'
			}
		])
		fulfillment_post_data['marketplaceId'] = self.get_api_marketplace()
		fulfillment_post_data['name'] = template.name
		fulfillment_post_data['freightShipping'] = True \
			if template.domestic_shipping.shipment_type == 'freight' and \
			   template.domestic_shipping.freight_shipment.status == 'enable' else False
		fulfillment_post_data['localPickup'] = True \
			if template.international_shipping.status == 'enable' else False
		fulfillment_post_data['globalShipping'] = True if template.global_shipping_program == 'enable' else False
		fulfillment_post_data['handlingTime'] = {
			'unit': 'DAY',
			'value': template.handling_time,
		}
		fulfillment_post_data['shippingOptions'] = list()
		# TODO: add domestic shipping
		if template.domestic_shipping.flat_shipment.status == 'enable':
			option_data = dict()
			option_data['costType'] = 'FLAT_RATE'
			option_data['optionType'] = 'DOMESTIC'
			option_data['shippingServices'] = list()
			if template.domestic_shipping.flat_shipment.shipping_rate_table.status == 'enable' \
					and template.domestic_shipping.flat_shipment.shipping_rate_table.value:
				option_data['rateTableId'] = template.domestic_shipping.flat_shipment.shipping_rate_table.value
			option_service_data = dict()
			option_service_data['buyerResponsibleForShipping'] = False
			if template.domestic_shipping.flat_shipment.free_shipping == 'enable':
				option_service_data['freeShipping'] = True
			else:
				option_service_data['freeShipping'] = False
				option_service_data['shippingCost'] = {
					'currency': 'USD',
					'value': template.domestic_shipping.flat_shipment.shipping_service.cost or 0
				}
				option_service_data['additionalShippingCost'] = {
					'currency': 'USD',
					'value': template.domestic_shipping.flat_shipment.shipping_service.each_additional or 0
				}
			option_service_data['shippingServiceCode'] = template.domestic_shipping.flat_shipment.shipping_service.service_code
			option_data['shippingServices'].append(option_service_data)
			for service in template.domestic_shipping.flat_shipment.addition_services:
				option_service_data = dict()
				option_service_data['buyerResponsibleForShipping'] = False
				option_service_data['freeShipping'] = False
				option_service_data['shippingCost'] = {
					'currency': 'USD',
					'value': service.cost or 0
				}
				option_service_data['additionalShippingCost'] = {
					'currency': 'USD',
					'value': service.each_additional or 0
				}
				option_service_data['shippingServiceCode'] = service.service_code
				option_data['shippingServices'].append(option_service_data)
			fulfillment_post_data['shippingOptions'].append(option_data)
		if template.domestic_shipping.calculated_shipment.status == 'enable':
			option_data = dict()
			option_data['costType'] = 'CALCULATED'
			option_data['optionType'] = 'DOMESTIC'
			option_data['packageHandlingCost'] = {
				'currency': 'USD',
				'value': template.domestic_shipping.calculated_shipment.handling_cost or 0
			}
			option_data['shippingServices'] = list()
			option_service_data = dict()
			option_service_data['buyerResponsibleForShipping'] = False
			if template.domestic_shipping.calculated_shipment.free_shipping == 'enable':
				option_service_data['freeShipping'] = True
			else:
				option_service_data['freeShipping'] = False
			option_service_data['shippingServiceCode'] = template.domestic_shipping.calculated_shipment.shipping_service.service_code
			option_data['shippingServices'].append(option_service_data)
			for service in template.domestic_shipping.flat_shipment.addition_services:
				option_service_data = dict()
				option_service_data['buyerResponsibleForShipping'] = False
				option_service_data['freeShipping'] = False
				option_service_data['shippingServiceCode'] = service.service_code
				option_data['shippingServices'].append(option_service_data)
			fulfillment_post_data['shippingOptions'].append(option_data)
		# TODO: add international shipping
		if template.international_shipping.status == 'enable' and template.international_shipping.flat_shipment.status == 'enable':
			option_data = dict()
			option_data['costType'] = 'FLAT_RATE'
			option_data['optionType'] = 'INTERNATIONAL'
			option_data['shippingServices'] = list()
			option_service_data = dict()
			option_service_data['buyerResponsibleForShipping'] = False
			if template.international_shipping.flat_shipment.shipping_rate_table.status == 'enable' \
					and template.international_shipping.flat_shipment.shipping_rate_table.value:
				option_data['rateTableId'] = template.international_shipping.flat_shipment.shipping_rate_table.value
			option_data['shippingServices'] = list()
			for service in template.international_shipping.flat_shipment.addition_services:
				option_service_data = dict()
				option_service_data['buyerResponsibleForShipping'] = False
				option_service_data['freeShipping'] = False
				option_service_data['shippingCost'] = {
					'currency': 'USD',
					'value': service.cost or 0
				}
				option_service_data['additionalShippingCost'] = {
					'currency': 'USD',
					'value': service.each_additional or 0
				}
				option_service_data['shippingServiceCode'] = service.service_code
				option_service_data['shipToLocations'] = {'regionInclude': []}
				if service.ship_to != 'custom':
					option_service_data['shipToLocations']['regionInclude'].append({
						'regionName': service.ship_to
					})
				else:
					for location in template.international_shipping.additional_locations:
						option_service_data['shipToLocations']['regionInclude'].append({
							'regionName': location
						})
				option_data['shippingServices'].append(option_service_data)
			fulfillment_post_data['shippingOptions'].append(option_data)
		if template.international_shipping.status == 'enable' and template.international_shipping.calculated_shipment.status == 'enable':
			option_data = dict()
			option_data['costType'] = 'CALCULATED'
			option_data['optionType'] = 'INTERNATIONAL'
			option_data['shippingServices'] = list()
			option_data['packageHandlingCost'] = {
				'currency': 'USD',
				'value': template.international_shipping.calculated_shipment.handling_cost or 0
			}
			option_data['shippingServices'] = list()
			for service in template.international_shipping.calculated_shipment.addition_services:
				option_service_data = dict()
				option_service_data['buyerResponsibleForShipping'] = False
				option_service_data['freeShipping'] = False
				option_service_data['shippingServiceCode'] = service.service_code
				option_service_data['shipToLocations'] = {'regionInclude': []}
				if service.ship_to != 'custom':
					option_service_data['shipToLocations']['regionInclude'].append({
						'regionName': service.ship_to
					})
				else:
					for location in template.international_shipping.additional_locations:
						option_service_data['shipToLocations']['regionInclude'].append({
							'regionName': location
						})
				option_data['shippingServices'].append(option_service_data)
			fulfillment_post_data['shippingOptions'].append(option_data)
		if template.excluded_locations.status == 'enable':
			fulfillment_post_data['shipToLocations'] = {'regionExcluded': []}
			for location in template.excluded_locations.locations:
				fulfillment_post_data['shipToLocations']['regionExcluded'].append({
					'regionName': location
				})
		response = self.api(url, data = fulfillment_post_data, method = method)
		check_response = self.check_response_import(response)
		if check_response.result != Response().SUCCESS:
			return check_response
		fulfillment_id = check_response.data.get('fulfillmentPolicyId')
		if not fulfillment_id:
			return Response().error(msg = 'Cannot import fulfillment.')
		response_data = {'fulfillmentPolicyId': fulfillment_id}
		if not update:
			template.update(response_data)
			template['update'] = 'disable'
			model_template.update(template.id, template)
		return Response().success(data = response_data)


	def payment_policy_import(self, template_id):
		model_template = Template()
		model_template.set_user_id(self._state.user_id)
		template = model_template.get(template_id)
		if not template:
			return Response().error(msg = 'Cannot get payment template data.')
		if template.type != 'payment':
			return Response().error(msg = f'Invalid payment template: {template.type}')
		update = True if template.update == 'enable' else False
		url = 'sell/account/v1/fulfillment_policy'
		method = 'post'
		payment_id = template.get('paymentPolicyId')
		if update:
			if not payment_id:
				return Response().error(msg = 'Cannot update payment template. Invalid payment id.')
			url += f'/{payment_id}'
			method = 'put'
		if not update and payment_id:
			return Response().success(data = {'paymentPolicyId': payment_id})
		payment_post_data = {
			'categoryTypes': [
				{
					'name': 'ALL_EXCLUDING_MOTORS_VEHICLES'
				}
			]
		}
		payment_post_data['name'] = template.name
		payment_post_data['paymentInstructions'] = template.payment_instructions
		payment_post_data['marketplaceId'] = self.get_api_marketplace()
		payment_post_data['immediatePay'] = True if template.immediate_payment == 'enable' else False
		payment_post_data['paymentMethods'] = list()
		payment_method_data = dict()
		payment_method_data['paymentMethodType'] = 'PAYPAL'
		payment_method_data['recipientAccountReference'] = {
			'referenceType': 'PAYPAL_EMAIL',
			'referenceId': template.paypal_email
		}
		payment_post_data['paymentMethods'].append(payment_method_data)
		response = self.api(url, data = payment_post_data, method = method)
		check_response = self.check_response_import(response)
		if check_response.result != Response().SUCCESS:
			return check_response
		payment_id = check_response.data.get('paymentPolicyId')
		if not payment_id:
			return Response().error(msg = 'Cannot import payment.')
		response_data = {'paymentPolicyId': payment_id}
		if not update:
			template.update(response_data)
			template['update'] = 'disable'
			model_template.update(template.id, template)
		return Response().success(data = response_data)


	def return_policy_import(self, template_id):
		model_template = Template()
		model_template.set_user_id(self._state.user_id)
		template = model_template.get(template_id)
		if not template:
			return Response().error(msg = 'Cannot get payment template data.')
		if template.type != 'payment':
			return Response().error(msg = f'Invalid payment template: {template.type}')
		update = True if template.update == 'enable' else False
		url = 'sell/account/v1/return_policy'
		method = 'post'
		return_id = template.get('returnPolicyId')
		if update:
			if not return_id:
				return Response().error(msg = 'Cannot update payment template. Invalid return id.')
			url += f'/{return_id}'
			method = 'put'
		if not update and return_id:
			return Response().success(data = {'returnPolicyId': return_id})
		return_post_data = {
			'categoryTypes': [
				{
					'name': 'ALL_EXCLUDING_MOTORS_VEHICLES'
				}
			]
		}
		return_post_data['name'] = template.name
		return_post_data['marketplaceId'] = self.get_api_marketplace()
		return_post_data['refundMethod'] = 'MONEY_BACK'
		return_post_data['returnsAccepted'] = True if template.domestic_return.status == 'enable' else False
		return_post_data['returnPeriod'] = {
			'unit': 'DAY',
			'value': 30 if template.domestic_return.within == 'Days_30' else 60
		}
		if template.domestic_return.replace_or_exchange == 'enable':
			return_post_data['returnMethod'] = 'REPLACEMENT'
		return_post_data['returnShippingCostPayer'] = template.domestic_return.paid_by
		# TODO: override international return policy
		override_international_return = dict()
		override_international_return['returnsAccepted'] = True if template.international_return.status == 'enable' else False
		override_international_return['returnPeriod'] = {
			'unit': 'DAY',
			'value': 30 if template.international_return.within == 'Days_30' else 60
		}
		if template.international_return.replace_or_exchange == 'enable':
			override_international_return['returnMethod'] = 'REPLACEMENT'
		override_international_return['returnShippingCostPayer'] = template.international_return.paid_by
		return_post_data['internationalOverride'] = override_international_return
		response = self.api(url, data = return_post_data, method = method)
		check_response = self.check_response_import(response)
		if check_response.result != Response().SUCCESS:
			return check_response
		return_id = check_response.data.get('returnPolicyId')
		if not return_id:
			return Response().error(msg = 'Cannot import return.')
		response_data = {'returnPolicyId': return_id}
		if not update:
			template.update(response_data)
			template['update'] = 'disable'
			model_template.update(template.id, template)
		return Response().success(data = response_data)


	def channel_assign_shipping_template(self, product, template_data):
		shipping_details = template_data.get('dimensions')
		if not shipping_details:
			return product
		if shipping_details:
			shipping_details_data = {}
			for shipping_name, shipping_detail in shipping_details.items():
				if shipping_name in ['dimension_unit', 'weight_unit']:
					product['channel'][f'channel_{self.get_channel_id()}'][f'{shipping_name}s'] = shipping_detail
					continue
				if not shipping_detail or (not shipping_detail.override and not shipping_detail.mapping):
					continue
				if shipping_detail.override:
					value = shipping_detail.override
				else:
					value = shipping_detail.mapping
				new_value = self.assign_attribute_to_field(value, product)
				if to_decimal(new_value):
					product['channel'][f'channel_{self.get_channel_id()}'][shipping_name] = to_str(to_decimal(new_value, 4))
					if shipping_name == 'weight':
						product['channel'][f'channel_{self.get_channel_id()}'][shipping_name] = shipping_detail
						weight_data = self.weight_to_ebay_weight(to_decimal(new_value, 4), shipping_details.get('weight_unit'))
						if weight_data:
							product['channel'][f'channel_{self.get_channel_id()}'].update(weight_data)
		return product


	def channel_assign_business_template(self, product, template_data):
		shipping_details = template_data.get('dimensions')
		if not shipping_details:
			return product
		if shipping_details:
			shipping_details_data = {}
			for shipping_name, shipping_detail in shipping_details.items():
				if shipping_name in ['dimension_unit', 'weight_unit']:
					product['channel'][f'channel_{self.get_channel_id()}'][f'{shipping_name}s'] = shipping_detail
					continue
				if not shipping_detail.override and not shipping_detail.mapping:
					continue
				if shipping_detail.override:
					value = shipping_detail.override
				else:
					value = shipping_detail.mapping
				new_value = self.assign_attribute_to_field(value, product)
				if to_decimal(new_value):
					product['channel'][f'channel_{self.get_channel_id()}'][shipping_name] = to_str(to_decimal(new_value, 4))
					if shipping_name == 'weight':
						product['channel'][f'channel_{self.get_channel_id()}'][shipping_name] = shipping_detail
						weight_data = self.weight_to_ebay_weight(to_decimal(new_value, 4), shipping_details.get('weight_unit'))
						if weight_data:
							product['channel'][f'channel_{self.get_channel_id()}'].update(weight_data)
		return product


	def channel_assign_category_template(self, product, template_data):
		if template_data.get('listing_type') == 'Auction':
			product['channel'][f'channel_{self.get_channel_id()}']['listing_type'] = 'Auction'
		else:
			product['channel'][f'channel_{self.get_channel_id()}']['listing_type'] = 'FixedPriceItem'
		condition = template_data['condition']
		item_specifics = template_data['specifics']
		for specific in item_specifics:
			if not specific.override and not specific.mapping:
				continue
			if specific.override:
				value = specific.override
			else:
				value = specific.mapping
			specific_value = self.assign_attribute_to_field(value, product)
			if specific_value and isinstance(specific_value, list):
				if isinstance(specific_value[0], dict):
					specific_value = ''
			if to_len(specific_value) > 65:
				specific_value = to_str(specific_value).split('|') if to_str(specific_value).find('|') != -1\
					else to_str(specific_value).split(',')
			specific.value = specific_value
		product_condition = product.get('condition') or 'new'

		if condition.get(product_condition):
			ebay_condition = EbayCategoryConditionSimple()
			ebay_condition.condition_id = condition.get(product_condition)
			condition['value'] = ebay_condition
			if condition.get(f'{product_condition}_condition_note'):
				product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['condition_note'] = condition.get(f'{product_condition}_condition_note')
			if condition.get(f'{product_condition}_condition_descriptor') and isinstance(condition.get(f'{product_condition}_condition_descriptor'), list):
				product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['condition_descriptor'] = condition.get(f'{product_condition}_condition_descriptor')
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['condition'] = condition

		product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['specifics'] = item_specifics
		return product


	def channel_assign_price_template(self, product, template_data):
		price_setting = self._state.channel.config.setting.get('price')
		if price_setting and price_setting.get('use_sale_price') == 'enable' and self.is_special_price(product):
			product['price'] = product.special_price.price
			product['special_price'] = ProductSpecialPrice()

			product.channel[f'channel_{self.get_channel_id()}']['special_price'] = ProductSpecialPrice()

		if not product.channel[f'channel_{self.get_channel_id()}']['template_data'].get('price'):
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['price'] = template_data
		fixed_price = template_data['fixed_price']
		auction_price = template_data['auction_price']
		real_price = product.price
		price = self.adjustment_price(fixed_price['buy_it_now_price'], real_price, product)
		if product.special_price and product.special_price.price:
			special_price = self.adjustment_price(fixed_price['buy_it_now_price'], product.special_price.price, product)
			special_price_obj = product.special_price
			special_price_obj.price = special_price
			product.channel[f'channel_{self.get_channel_id()}']['special_price'] = special_price_obj
			product.special_price = special_price_obj
		product.price = price
		if fixed_price['best_offer'] and fixed_price['best_offer'].get('status') == 'enable':
			best_offer = fixed_price['best_offer']
			best_offer_field = ['accept_price', 'decline_price']
			for field in best_offer_field:
				field_data = best_offer[field]
				if field_data.get('status') != 'enable':
					continue
				field_price = self.adjustment_price(field_data, real_price, product)
				fixed_price['best_offer'][field]['price'] = field_price
		# product['best_offer'][field] = field_price
		product.channel[f'channel_{self.get_channel_id()}']['price'] = price
		fields = ['buy_it_now_price', 'start_price', 'reserve_price']
		for field in fields:
			template = auction_price.get(field)
			if not template or template.status != ConstructBase.ENABLE:
				continue
			adjustment_price = self.adjustment_price(template, real_price, product)
			auction_price[field]['price'] = adjustment_price
			product[field] = adjustment_price
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['price']['fixed_price'] = fixed_price
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['price']['auction_price'] = auction_price
		return product


	def convert_order_status(self, status):
		order_status = {
			"All": Order.OPEN,
			"InProcess": Order.SHIPPING,
			"Active": Order.READY_TO_SHIP,
			"CustomCode": Order.AWAITING_PAYMENT,
			"Completed": Order.COMPLETED,
			"CancelPending": Order.CANCELED,
			"Inactive": Order.CANCELED,
			"Cancelled": Order.CANCELED,
			"NOT_STARTED": Order.READY_TO_SHIP,
			"IN_PROGRESS": Order.SHIPPING,
		}
		return order_status.get(status, 'open') if status else 'open'


	def api_get_orders(self, limit = None, offset = None):
		params = {}
		if limit:
			params['limit'] = limit
		if offset:
			params['offset'] = offset
		filter_order = self.get_order_filter()
		if filter_order:
			params['filter'] = ",".join([f"{key}:[{value}]" for key, value in filter_order.items()])
		path = f"sell/fulfillment/v1/order"
		order_response = self.api(path, params)
		return order_response


	def get_orders_main_export(self):
		if self._is_finish:
			return Response().finish()

		orders_response = self.api_get_orders(limit = 50, offset = self._state.pull.process.orders.imported)
		try:
			orders = orders_response.orders
		except Exception:
			return Response().finish()
		if self._last_status < 300 and to_int(orders_response.total) < 50:
			self._is_finish = True
		return Response().success(data = orders)


	def get_order_by_id(self, order_id):
		order_response = self.api(f"sell/fulfillment/v1/order/{order_id}")
		if self._last_status == 200:
			return Response().success(order_response)
		return Response().success()


	def get_orders_ext_export(self, orders):
		extend = dict()
		order_ids = [f"<OrderID>{row['orderId']}</OrderID>" for row in list(filter(lambda x: to_len(to_str(x['orderId'])) <= 15, orders))]
		order_id_filter = "\n".join(order_ids)
		xml_body = f'''<?xml version="1.0" encoding="utf-8"?>
<GetOrdersRequest xmlns="urn:ebay:apis:eBLBaseComponents">    
	<ErrorLanguage>en_US</ErrorLanguage>
	<WarningLevel>High</WarningLevel>
  <OrderIDArray>
    {order_id_filter}
  </OrderIDArray>
  <OrderRole>Seller</OrderRole>
</GetOrdersRequest>'''
		orders_ext = self.xml_api('GetOrders', xml_body)
		orders_ext_data = {}
		if orders_ext and orders_ext.GetOrdersResponse and orders_ext.GetOrdersResponse.OrderArray:
			orders_ext_data = {row['OrderID']: row for row in obj_to_list(orders_ext.GetOrdersResponse.OrderArray.Order)}
		return Response().success(orders_ext_data)


	def get_ebay_variant_attributes(self, product):
		variant_attributes = product.channel[f'channel_{self.get_channel_id()}'].get('ebay_variant_attributes')
		# variant_attributes = product.channel[f'channel_{self.get_channel_id()}'].get('ebay_variant_attributes') or product.channel[f'channel_{self.get_channel_id()}'].get('variant_attributes') or product.variant_attributes
		return variant_attributes


	def is_same_market(self, marketplace):
		if marketplace == self.get_marketplace_id():
			return True
		if marketplace in ['EBAY_US', 'EBAY_MOTORS_US'] and self.get_marketplace_id() in ['EBAY_US', 'EBAY_MOTORS_US']:
			return True
		if marketplace in ['EBAY_CA', 'EBAY_ENCA', 'EBAY_FRCA'] and self.get_marketplace_id() in ['EBAY_CA', 'EBAY_ENCA', 'EBAY_FRCA']:
			return True
		return False


	def convert_order_export(self, order, orders_ext, channel_id = None):
		if to_len(order.orderId) > 15:
			self.log(order, 'order_length')
			return Response().skip()

		order.creationDate = order.creationDate[0:19]
		order_create = to_timestamp(order.creationDate, "%Y-%m-%dT%H:%M:%S")
		start_time = to_timestamp(self.get_order_start_time('iso'), '%Y-%m-%dT%H:%M:%S')
		marketplace = order.lineItems[0].get('listingMarketplaceId')
		purchase_marketplace = order.lineItems[0].get('purchaseMarketplaceId')
		if order_create < start_time or not self.is_same_market(marketplace):
			return Response().skip()
		order_ext_data = orders_ext.get(order.orderId, Prodict())

		order.lastModifiedDate = order.lastModifiedDate[0:19]
		self.set_order_max_last_modifier(order.lastModifiedDate)

		order_data = Order()
		order_data.id = order.orderId
		order_data.order_number = order.orderId
		order_data.subtotal = order.pricingSummary.priceSubtotal.value
		order_data.total = order.pricingSummary.total.value
		if order.totalFeeBasisAmount:
			order_data.total = order.totalFeeBasisAmount.value
		order_data.currency = order.pricingSummary.total.currency
		order_data.created_at = convert_format_time(order.creationDate, self.TIME_FORMAT)
		order_data.updated_at = convert_format_time(order.lastModifiedDate, self.TIME_FORMAT)
		order_data.channel_data = {
			'created_at': order_data.created_at,
			'order_number': order.orderId,
		}
		if order.cancelStatus.cancelState != 'NONE_REQUESTED':
			order_status = self.convert_order_status('Cancelled')
		elif order.orderPaymentStatus != 'PAID':
			if to_str(order.orderPaymentStatus) == 'FULLY_REFUNDED':
				order_status = Order.REFUNDED
			elif to_str(order.orderPaymentStatus) == 'PARTIALLY_REFUNDED':
				order_status = Order.PARTIALLY_REFUNDED
			else:
				order_status = Order.AWAITING_PAYMENT
				if self._state.channel.config.api.skip_awaiting_payment:
					return Response().skip()
		elif order.orderFulfillmentStatus != 'FULFILLED':
			order_status = self.convert_order_status(order.orderFulfillmentStatus)

		else:
			order_status = self.convert_order_status('Completed')
		if order.fulfillmentHrefs:
			fulfillment_info = self.api(f"sell/fulfillment/v1/order/{order.orderId}/shipping_fulfillment")
			if fulfillment_info and fulfillment_info['fulfillments'] and fulfillment_info['fulfillments'][0].shippedDate:
				# order_status = self.convert_order_status('Completed')
				order_data.channel_data.shipped_date = fulfillment_info['fulfillments'][0].shippedDate
				order_data.shipments.tracking_company = fulfillment_info['fulfillments'][0].shippingServiceCode
				order_data.shipments.tracking_company_code = fulfillment_info['fulfillments'][0].shippingCarrierCode
				order_data.shipments.tracking_number = fulfillment_info['fulfillments'][0].shipmentTrackingNumber
				order_data.shipments.shipped_at = convert_format_time(fulfillment_info['fulfillments'][0].shippedDate, old_format = '%Y-%m-%dT%H:%M:%S')
		order_data.status = order_status
		# if order.paymentSummary and order.paymentSummary.refunds:
		# 	for refund in order.paymentSummary.refunds:
		# 		order_refund = OrderRefund()
		# 		order_refund.amount = to_decimal(refund.amount.value, 2)
		# 		order_data.refunds.append(order_refund)
		order_data.channel_data.order_status = order_status
		# discount
		order_data.discount.amount = to_decimal(order.discountedLineItemCost.value) if order.discountedLineItemCost else None
		if not order_data.discount.amount:
			order_data.discount.amount = to_decimal(order.pricingSummary.get('priceDiscount').get('value')) if order.pricingSummary.get('priceDiscount') else None
			if order_data.discount.amount and order_data.discount.amount < 0:
				order_data.discount.amount = 0 - order_data.discount.amount
		if order.fulfillmentStartInstructions:
			order_data.shipping.title = order.fulfillmentStartInstructions[0].shippingStep.shippingServiceCode
		buyer = order.buyer.username
		order_data.customer.username = buyer
		if order.fulfillmentStartInstructions:
			email = order.fulfillmentStartInstructions[0].shippingStep.shipTo.get("email")
			try:
				if order_ext_data and order_ext_data.TransactionArray:
					transactions = obj_to_list(order_ext_data.TransactionArray.Transaction)
					for transaction in transactions:
						if transaction.Buyer and transaction.Buyer.Email and '@' in transaction.Buyer.Email:
							email = transaction.Buyer.Email
							break
			except:
				pass
			order_data.customer.email = email
			order_data.customer.first_name = buyer
			order_data.customer.last_name = buyer
		order_address = False
		try:
			if order_ext_data and order_ext_data.MultiLegShippingDetails and order_ext_data.MultiLegShippingDetails.SellerShipmentToLogisticsProvider:
				shipping_address = order_ext_data.MultiLegShippingDetails.SellerShipmentToLogisticsProvider.ShipToAddress
				order_address = OrderAddress()
				first_name, last_name = self.split_customer_fullname(shipping_address.Name)
				order_data.customer.first_name = first_name
				order_data.customer.last_name = last_name
				order_address.first_name = first_name
				order_address.last_name = last_name
				order_address.address_1 = shipping_address.Street1
				order_address.address_2 = shipping_address.Street2 or ''
				order_address.city = shipping_address.CityName
				order_address.state.state_code = shipping_address.StateOrProvince
				order_address.country.country_code = shipping_address.Country
				order_address.country.country_name = shipping_address.CountryName
				order_address.telephone = shipping_address.Phone
				order_address.postcode = shipping_address.PostalCode
		except:
			self.log_traceback()
			order_address = False
		if not order_address:
			if order_ext_data and order_ext_data.ShippingAddress:
				order_address = OrderAddress()
				first_name, last_name = self.split_customer_fullname(order_ext_data.ShippingAddress.Name)
				order_data.customer.first_name = first_name
				order_data.customer.last_name = last_name
				order_address.first_name = first_name
				order_address.last_name = last_name
				order_address.address_1 = order_ext_data.ShippingAddress.Street1
				order_address.address_2 = order_ext_data.ShippingAddress.Street2
				order_address.city = order_ext_data.ShippingAddress.CityName
				order_address.state.state_code = order_ext_data.ShippingAddress.StateOrProvince
				order_address.country.country_code = order_ext_data.ShippingAddress.Country
				order_address.country.country_name = order_ext_data.ShippingAddress.CountryName
				order_address.telephone = order_ext_data.ShippingAddress.Phone if to_str(order_ext_data.ShippingAddress.Phone).find('Invalid') == -1 else ''
				order_address.postcode = order_ext_data.ShippingAddress.PostalCode

			elif order.fulfillmentStartInstructions[0].shippingStep.shipTo:
				shipping_to = order.fulfillmentStartInstructions[0].shippingStep.shipTo
				first_name, last_name = self.split_customer_fullname(shipping_to.fullName)
				order_data.customer.first_name = first_name
				order_data.customer.last_name = last_name
				order_address = OrderAddress()
				order_address.first_name = first_name
				order_address.last_name = last_name
				order_address.address_1 = shipping_to.contactAddress.get('addressLine1')
				order_address.address_2 = shipping_to.contactAddress.get('addressLine2')
				order_address.city = shipping_to.contactAddress.get('city')
				order_address.country.country_code = shipping_to.contactAddress.get('countryCode')
				order_address.state.state_code = shipping_to.contactAddress.get('stateOrProvince')
				order_address.state.state_name = shipping_to.contactAddress.get('stateOrProvince')
				order_address.postcode = shipping_to.contactAddress.get('postalCode')
				order_address.telephone = shipping_to.primaryPhone.phoneNumber if shipping_to.primaryPhone else ''

		if not order_address.telephone and order.fulfillmentStartInstructions[0].shippingStep.shipTo:
			# case: get telephone phone from order_ext but get invalid number
			shipping_to = order.fulfillmentStartInstructions[0].shippingStep.shipTo
			order_address.telephone = shipping_to.primaryPhone.phoneNumber if shipping_to.primaryPhone else ''

		if order_address:
			order_data.shipping_address.update(order_address)
			order_data.billing_address.update(order_address)
			order_data.customer_address.update(order_address)
		# billing
		if order.fulfillmentStartInstructions[0].shippingStep.shipToReferenceId:
			order_data.additional_details.append({
				'name': 'ShipToReferenceId',
				'value': order.fulfillmentStartInstructions[0].shippingStep.shipToReferenceId,
			})
		if order.paymentSummary:
			order_data.payment.status = order.paymentSummary.payments[0].paymentStatus
			order_data.payment.method = order.paymentSummary.payments[0].paymentMethod
			order_data.payment.code = order.paymentSummary.payments[0].paymentReferenceId

		order_data.imported_at = get_current_time()
		tax_amount = 0
		if order.taxes:
			for tax in order.taxes:
				if tax.amount:
					tax_amount += to_decimal(tax.amount.value)
		special_fields = ['size', 'sizes']
		line_item_tax_amount = 0
		for item in order.lineItems:
			# refunds
			if item and item.refunds:
				for refund in item.refunds:
					order_refund = OrderRefund()
					order_refund.amount = to_decimal(refund.amount.value, 2)
					order_data.refunds.append(order_refund)
			order_item = OrderProducts()
			try:
				if item.lineItemFulfillmentInstructions and item.lineItemFulfillmentInstructions.shipByDate:
					order_item.ship_by_date = item.lineItemFulfillmentInstructions.shipByDate
			except:
				self.log_traceback()
			# order_item.id = item.lineItemId
			if item.legacyVariationId:
				if item.variationAspects:
					variant_attributes = list()
					for variation_aspect in item.variationAspects:
						option_data = OrderItemOption()
						option_data.option_name = variation_aspect['name']
						option_data.option_value_name = variation_aspect['value']
						order_item.options.append(option_data)
						attribute_data = ProductVariantAttribute()
						attribute_data.attribute_name = variation_aspect['name']
						attribute_data.attribute_value_name = variation_aspect['value']
						variant_attributes.append(attribute_data)
					variant_id = f"{item.legacyItemId}-{self.variant_key_generate_by_attributes(variant_attributes)}"
					order_item.product_id = variant_id
					order_item.is_variant = True

				else:
					product = self.get_product_warehouse_map(item.legacyItemId, return_product = True)
					item_group = self.get_items_by_item_group(item.legacyItemId)
					if item_group:
						variant = dict()
						for row in item_group:
							if to_int(to_str(row['itemId']).split('|')[-1]) == to_int(item.legacyVariationId):
								variant = row
								break
						if variant:
							if product:
								variant_attribute_value = list()
								variant_attributes = product.channel[f'channel_{self.get_channel_id()}'].get('ebay_variant_attributes') or product.channel[f'channel_{self.get_channel_id()}'].get('variant_attributes') or product.variant_attributes
								all_attributes = []
								for attribute in variant['localizedAspects']:
									if attribute['name'] in all_attributes:
										continue
									if attribute['name'] in variant_attributes:
										attribute_data = ProductVariantAttribute()
										attribute_data.attribute_name = attribute['name']
										attribute_data.attribute_value_name = attribute['value']
										variant_attribute_value.append(attribute_data)
										all_attributes.append(attribute['name'])
										continue
								if variant_attribute_value:
									for attribute in variant_attribute_value:
										option_data = OrderItemOption()
										option_data.option_name = attribute.attribute_name
										option_data.option_value_name = attribute.attribute_value_name
										order_item.options.append(option_data)
									variant_id = f"{item.legacyItemId}-{self.variant_key_generate_by_attributes(variant_attribute_value)}"
									order_item.product_id = variant_id
									order_item.is_variant = True

			if not order_item.product_id:
				order_item.product_id = item.legacyItemId
			order_item.listing_id = item.legacyItemId
			order_item.line_item_id = item.lineItemId
			order_item.product_name = item.title
			order_item.product_sku = item.sku
			order_item.qty = item.quantity
			order_item.price = to_decimal(to_decimal(item.lineItemCost.value) / to_int(item.quantity), 2)
			order_item.total = item.total.value
			order_data.shipping.amount += to_decimal(item.deliveryCost.shippingCost.value) if item.deliveryCost.shippingCost else 0
			order_data.handling_cost = to_decimal(item.deliveryCost.handlingCost.value) if item.deliveryCost.handlingCost else 0
			if item.taxes:
				for tax in item.taxes:
					line_item_tax_amount += to_decimal(tax.amount.value)
			if order.ebayCollectAndRemitTax and item.ebayCollectAndRemitTaxes:
				for tax in item.ebayCollectAndRemitTaxes:
					line_item_tax_amount += to_decimal(tax.amount.value)
			order_data.products.append(order_item)
		order_data.tax.amount = line_item_tax_amount or tax_amount
		order_data.tax.amount = to_decimal(order_data.tax.amount, 2)

		if (
				not self.is_import_order_without_tax()
				and not order_data.tax.amount
				and ((order_ext_data.ShippingDetails
				      and order_ext_data.ShippingDetails.SalesTax
				      and (to_decimal(order_ext_data.ShippingDetails.SalesTax.SalesTaxAmount)
				           or to_decimal(order_ext_data.ShippingDetails.SalesTax.SalesTaxPercent)))
				     or to_decimal(self._state.channel.config.api.order_tax_percent))
		):
			sale_tax_percent = to_decimal(order_ext_data.ShippingDetails.SalesTax.SalesTaxPercent)
			tax_amount = to_decimal(order_ext_data.ShippingDetails.SalesTax.SalesTaxAmount, 2)
			if not sale_tax_percent and not tax_amount:
				sale_tax_percent = to_decimal(self._state.channel.config.api.order_tax_percent)
			total = to_decimal(order_data.total, 2)
			if not sale_tax_percent:
				base_amount = total - tax_amount
				sale_tax_percent = to_decimal(tax_amount / base_amount, 2) * 100
			if not tax_amount and sale_tax_percent:
				tax_amount = to_decimal(total - total / (1 + sale_tax_percent/100), 2)
			order_data.subtotal = total - tax_amount
			order_data.tax.amount = tax_amount
			if not self._state.channel.config.api.order_include_tax:
				order_data.shipping.amount = to_decimal(order_data.shipping.amount / (1 + sale_tax_percent / 100), 2)

				for product in order_data.products:
					if sale_tax_percent:
						item_total = to_decimal(product.price, 2)
						item_sub_total = to_decimal(item_total / (1 + sale_tax_percent / 100), 2)
						item_tax_amount = to_decimal(item_total - item_sub_total, 2)
						product.price = item_sub_total
						product.subtotal = to_decimal(product.price * product.qty, 2)
						product.tax_amount = to_decimal(item_tax_amount * product.qty, 2)
		if order.buyerCheckoutNotes:
			history = OrderHistory()
			history.comment = order.buyerCheckoutNotes
			order_data.history.append(history)
		# if order_data.tax.amount and self.is_import_order_without_tax():
		# 	order_data.total = to_decimal(to_decimal(order_data.total) - to_decimal(order_data.tax.amount), 2)
		# 	order_data.tax.amount = 0
		if self._state.channel.config.api.custom_tags:
			order_data.tags = self._state.channel.config.api.custom_tags
		if self._state.channel.config.api.custom_order_email:
			order_data.custom_order_email = self._state.channel.config.api.custom_order_email
		return Response().success(order_data)


	def get_items_by_item_group(self, item_id):
		item_id = to_int(item_id)
		if self._item_group_id.get(item_id):
			return self._item_group_id[item_id]
		item = self.api('buy/browse/v1/item/get_items_by_item_group', {'item_group_id': item_id})
		if self._last_status == 200:
			self._item_group_id[item_id] = item['items']
			return self._item_group_id[item_id]
		return []


	def is_skip_auction_item(self):
		return bool(self._state.channel.config.api.skip_import_auction_item)

	def is_carrier_mapping(self) -> bool:
		other_settings = self._state.channel.config.setting.get('other_setting')
		try:
			if isinstance(other_settings, dict) and isinstance(other_settings.get('carrier_mapping'), dict):
				return bool(other_settings.carrier_mapping.get('status') == 'enable')
		except:
			self.log_traceback()

		return False

	def get_company_mapping(self) -> list:
		if self.is_carrier_mapping():
			try:
				carrier_mapping = self._state.channel.config.setting.other_setting.carrier_mapping.get('company_mapping')
				if not isinstance(carrier_mapping, list):
					carrier_mapping = []
				return carrier_mapping
			except:
				self.log_traceback()

		return []

	def channel_order_completed_line_shipments(self, order_id, order: Order, current_order: Order):
		try:
			for line_shipment in order.line_shipments:
				tracking_company = TrackingCompany(line_shipment.tracking_company_code, line_shipment.tracking_company, channel_type = 'ebay')
				shipped_date = datetime.now() - dateutil.relativedelta.relativedelta(hours = 7)
				shipment_data = {
					'lineItems': list(),
					'shippedDate': shipped_date.strftime('%Y-%m-%dT%H:%M:%S.000Z'),

				}
				tracking_number = ''
				tracking_company_ebay = 'other'
				if self._state.channel.config.api.log_shipment:
					data_log = {
						'_id': order['_id'],
						'shipments': order.shipments,
						'tracking_company': {
							'code': tracking_company.get_code(),
							'name': tracking_company.get_name(),
						}
					}
					self.log(data_log, 'order_shipments')
				if tracking_company.get_code() != 'other':
					tracking_number = line_shipment.tracking_number or order.order_number
					tracking_number = re.sub('[^a-zA-Z0-9]', '', to_str(tracking_number))
					shipment_data['shippingCarrierCode'] = tracking_company.get_code()
					tracking_company_ebay = tracking_company.get_code()
					shipment_data['trackingNumber'] = tracking_number

				if self.is_carrier_mapping():
					shipment_data = self.order_get_tracking_company_mapping(line_shipment, shipment_data)

				if line_shipment.tracking_number and self._state.channel.config.api.shippit_tracking:
					country_code = current_order.shipping_address.country.country_code
					is_domestic_shipping = False
					if country_code.lower() == self.get_country().lower():
						is_domestic_shipping = True
					if is_domestic_shipping:
						tracking_company_ebay = self._state.channel.config.api.shippit_tracking.domestic
					else:
						tracking_company_ebay = self._state.channel.config.api.shippit_tracking.intenational
					shipment_data['shippingCarrierCode'] = tracking_company_ebay
					shipment_data['trackingNumber'] = order.shipments.tracking_number

				for item in line_shipment.line_items:
					line_item_id = None
					if item['product']:
						product = item['product']
						for order_item in order.products:
							if order_item['id'] == product['_id'] or order_item['parent_id'] == product['_id']:
								line_item_id = order_item.line_item_id
								break
					if line_item_id:
						shipment_data['lineItems'].append({
							'lineItemId': line_item_id,
							'qty': item.qty
						})
				self.api(path = f'sell/fulfillment/v1/order/{order_id}/shipping_fulfillment', data = shipment_data, method = 'post')
				if self._last_status > 300:
					return Response().error()
			return_order = {
				"status": 'COMPLETED',
			}

			return Response().success(return_order)
		except:
			return Response().error()


	def order_get_tracking_company_mapping(self, order_line: dict, shipment_data: dict) -> dict:
		try:
			company_map_list = self.get_company_mapping()
			company_ebay_list = list(TrackingCompany().get_list_companies_ebay().items())
			for company in company_map_list:
				if self.name_to_code(company['main_company']) in list(map(self.name_to_code, [order_line['tracking_company_code'], order_line['tracking_company']])):
					shipment_data['shippingCarrierCode'] = next(
						filter(lambda x: x[1] == company['channel_company'], company_ebay_list), ['']
					)[0]
					break
		except Exception as e:
			self.log_traceback()

		return shipment_data

	def channel_order_completed(self, order_id, order: Order, current_order: Order):
		if order.line_shipments:
			return self.channel_order_completed_line_shipments(order_id, order, current_order)
		try:
			channel_default = self.get_channel_default()
			tracking_company = TrackingCompany(order.shipments.tracking_company_code, order.shipments.tracking_company, channel_type = 'ebay')
			shipped_date = datetime.now() - dateutil.relativedelta.relativedelta(hours = 7)
			shipment_data = {
				'lineItems': list(),
				'shippedDate': shipped_date.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
				# 'trackingNumber': order.shipments.tracking_number or channel_default.get('type'),

			}
			tracking_number = ''
			tracking_company_ebay = 'other'
			if self._state.channel.config.api.log_shipment:
				data_log = {
					'_id': order['_id'],
					'shipments': order.shipments,
					'tracking_company': {
						'code': tracking_company.get_code(),
						'name': tracking_company.get_name(),
					}
				}
				self.log(data_log, 'order_shipments')
				self._log_type = 'order_completed'
				self._state.channel.config.api.is_log = True
			if tracking_company.get_code() != 'other':
				tracking_number = order.shipments.tracking_number or order.order_number
				tracking_number = re.sub('[^a-zA-Z0-9]', '', to_str(tracking_number))
				shipment_data['shippingCarrierCode'] = tracking_company.get_code()
				tracking_company_ebay = tracking_company.get_code()
				shipment_data['trackingNumber'] = tracking_number

			if self.is_carrier_mapping():
				shipment_data = self.order_get_tracking_company_mapping(order.shipments, shipment_data)

			if order.shipments.tracking_number and self._state.channel.config.api.shippit_tracking:
				country_code = current_order.shipping_address.country.country_code
				is_domestic_shipping = False
				if country_code.lower() == self.get_country().lower():
					is_domestic_shipping = True
				if is_domestic_shipping:
					tracking_company_ebay = self._state.channel.config.api.shippit_tracking.domestic
				else:
					tracking_company_ebay = self._state.channel.config.api.shippit_tracking.intenational
				shipment_data['shippingCarrierCode'] = tracking_company_ebay
				shipment_data['trackingNumber'] = order.shipments.tracking_number

			for product in order.products:
				if not product.line_item_id:
					return Response().success()
				shipment_data['lineItems'].append({
					'lineItemId': product.line_item_id,
					'qty': product.qty
				})
			self.api(path = f'sell/fulfillment/v1/order/{order_id}/shipping_fulfillment', data = shipment_data, method = 'post')
			if self._last_status == 201:
				return_order = {
					"status": 'COMPLETED',
					"tracking_company": tracking_company_ebay,
				}

				return Response().success(return_order)
		except:
			self.log_traceback()
		return Response().error()


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.orderId


	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']
		if mass_action == 'delete':
			self.delete_product_import(product_id)
			self.product_deleted(product['_id'], product)
			return Response().success(product_id)
		xml_data = ''
		if mass_action == 'end':
			self.ended_listing(product_id, product, forced = True)
		if mass_action == 'relist':
			self.re_listing(product_id, product, forced = True)

		return Response().success(product_id)


	def escape_description(self, description):
		"""escape character and remove specifics tags"""
		try:
			soup = BeautifulSoup(description, 'html.parser')
			if self.is_clean_description():
				tags_remove = ['script', 'iframe']
				for tag in tags_remove:
					[x.decompose() for x in soup.find_all(tag)]

			description = soup.prettify(formatter = lambda s: s.replace(u'\xa0', ' '))
		except Exception:
			self.log_traceback(msg = description)
		return to_str(description).replace('’', "'").replace("”", '"').replace('“', '"').replace('–', '-').replace('http://', 'https://')


	def get_draft_extend_channel_data(self, product: Product):
		channel_data = {}
		upc = product.upc or product.gtin
		if upc:
			if not self.valid_upc(upc):
				channel_data['upc'] = self.FIELD_EMPTY
			elif upc != product.upc:
				channel_data['upc'] = upc

		ean = product.ean or product.gtin
		if ean:
			if not self.valid_ean(ean):
				channel_data['ean'] = self.FIELD_EMPTY
			elif ean != product.ean:
				channel_data['ean'] = ean

		description = self.escape_description(product.description)
		weight = to_decimal(product.weight, 4)

		product_name = self.strip_html_from_description(product.name)[0:80]
		if product_name != product.name:
			channel_data['name'] = product_name

		weight_unit = product.weight_units or 'oz'
		# if to_len(product.name) > 80:
		# 	channel_data['name'] = product.name[0:80]
		if product.description != description:
			channel_data['description'] = description
		qty_setting = self._state.channel.config.setting.get('qty')

		qty = product.qty
		if not product.is_in_stock:
			qty = 0
		elif not product.manage_stock:
			qty = 999
			if qty_setting and to_int(qty_setting.get('no_manage_stock_qty')):
				qty = to_int(qty_setting.get('no_manage_stock_qty'))
		if to_int(qty) != to_int(product.qty):
			channel_data['qty'] = qty
		if not weight:
			return channel_data
		weight_data = self.weight_to_ebay_weight(weight, weight_unit)
		if weight_data:
			channel_data.update(weight_data)
		return channel_data


	def weight_to_ebay_weight(self, weight, weight_unit):
		weight_data = {}
		# if to_len(product.name) > 80:
		# 	channel_data['name'] = product.name[0:80]
		if not weight:
			return weight_data
		weight_major_unit = 'lbs'
		if weight_unit in ['g', 'gr', 'kg'] and self.is_us():
			if weight_unit in ['g', 'gr']:
				weight = weight * 0.00220462262
			else:
				weight = weight * 2.2046
			weight_unit = 'lbs'

		if weight_unit in ['lb', 'lbs', 'kg']:
			weight_major = math.floor(weight)
			weight_major_unit = 'kg' if weight_unit == 'kg' else 'lbs'
			weight_data['weight_major'] = weight_major
			weight_minor = to_decimal(weight - weight_major, 4)
			if weight_minor:
				weight_minor = weight_minor * 1000 if weight_major_unit == 'kg' else weight_minor * 16
				weight_data['weight_minor'] = math.ceil(weight_minor)
				weight_data['weight_minor_unit'] = 'gr' if weight_major_unit == 'kg' else 'oz'
		if weight_unit in ['oz', 'g', 'gr']:
			weight_data['weight_minor'] = math.ceil(weight)
			weight_data['weight_minor_unit'] = 'oz' if weight_unit == 'oz' else 'gr'
			if weight_unit in ['g', 'gr']:
				weight_major_unit = 'kg'
		weight_data['weight_major_unit'] = weight_major_unit
		if not weight_data.get('weight_minor'):
			weight_data['weight_minor'] = 0
			weight_data['weight_minor_unit'] = 'oz' if weight_major_unit in ['lb', 'lbs'] else 'gr'
		if not weight_data.get('weight_major'):
			weight_data['weight_major'] = 0
		weight_major = to_decimal(weight_data['weight_major'], 4)
		weight_minor = to_decimal(weight_data['weight_minor'], 4)
		weight_multiple = 16 if weight_major_unit == 'lbs' else 1000

		extend_weight_minor = weight_data['weight_major'] - math.floor(weight_major)
		weight_major = math.floor(weight_major)
		weight_minor += extend_weight_minor * weight_multiple
		weight_minor = math.ceil(weight_minor)
		while weight_minor >= weight_multiple:
			weight_major += 1
			weight_minor -= weight_multiple
		weight_data['weight_major'] = weight_major
		weight_data['weight_minor'] = weight_minor
		return weight_data


	def get_model_local(self):
		if self._model_local:
			return self._model_local
		self._model_local = ModelModesTest()
		self._model_local.set_user_id(self._user_id)
		return self._model_local


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self._order_sync_inventory(order, '+')


	def order_sync_inventory(self, convert: Order, setting_order):
		return self._order_sync_inventory(convert)


	def update_inventory_status(self, update_inventory):
		update = list()
		for item_id, row in update_inventory.items():
			update_data = {
				'ItemID': item_id,
				'Quantity': row['qty']
			}
			if row.get('sku'):
				update_data['SKU'] = row['sku']
			update.append(update_data)
		all_update = split_list(update, 4)
		for row in all_update:
			xml_body = self.dict_to_xml_product_body('ReviseInventoryStatus', {'InventoryStatus': row})
			self.xml_api('ReviseInventoryStatus', xml_body)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		out_of_stock_control = True if self._state.channel.config.setting.get('qty', {}).get('out_of_stock_control') == 'enable' else False

		update_inventory = dict()
		for row in convert.products:
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):

				product_id = None
				variant_id = None
				if row['product_id'] and row['parent_id']:
					variant_id = row['product_id']
					product_id = row['parent_id']
				else:
					product_id = row['product_id']
				product = row.product
				ebay_product = self.api_get_item(product_id)
				if not ebay_product or not ebay_product.GetItemResponse or not ebay_product.GetItemResponse.Item:
					continue
				item_ebay = ebay_product.GetItemResponse.Item
				item_ebay['is_item_data'] = True
				ebay_product_ext = self.get_products_ext_export([item_ebay])
				ebay_convert = self.convert_product_export(item_ebay, ebay_product_ext['data'])
				if ebay_convert.result != Response.SUCCESS:
					continue
				ebay_product_data = ebay_convert.data
				row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1

				if not ebay_product_data.variants:
					qty = to_int(ebay_product_data.qty)
					new_qty = qty - row_qty if prefix == '-' else qty + row_qty

					if new_qty <= 0 and not out_of_stock_control:
						self.ended_listing(product_id, row.product)
					else:
						# ebay_status = product.channel[f'channel_{self.get_channel_id()}'].get('ebay_status')
						# if ebay_status == 'ended':
						# 	self.re_listing(product_id, product)
						update_inventory[product_id] = {
							'qty': new_qty
						}
					continue
				# variants = list()
				# is_ended = True
				# ebay_variants = list()
				# variation_options = self.variants_to_option(ebay_product_data.variants)
				# specific = list()
				# for option_name, option_values in variation_options.items():
				#
				# 	specific.append({
				# 		'Name': option_name,
				# 		'Value': option_values
				# 	})
				for variant in ebay_product_data.variants:
					if to_str(variant_id) != to_str(variant.id):
						continue
					variant_data = dict()
					qty = to_int(variant.qty)
					new_qty = qty
					new_qty = qty - row_qty if prefix == '-' else qty + row_qty
					update_inventory[product_id] = {
						'qty': new_qty,
						'sku': variant.sku
					}
					row['sync_inventory'] = True
					break
		# 	variant_data['Quantity'] = new_qty
		# 	variant_data['StartPrice'] = variant.price
		# 	listing_details = dict()
		# 	upc = self.get_product_identifier_unavailable_text()
		# 	if self.valid_upc(variant.upc):
		# 		upc = variant.upc
		# 	listing_details['UPC'] = upc
		# 	if self.is_eu() and listing_details.get('UPC') and not listing_details.get('EAN'):
		# 		listing_details['EAN'] = listing_details.get('UPC')
		# 		del listing_details['UPC']
		# 	if listing_details:
		# 		variant_data['VariationProductListingDetails'] = listing_details
		# 	variant_attributes = list()
		# 	for attribute in variant.attributes:
		# 		if not attribute.use_variant:
		# 			continue
		# 		variant_attributes.append({
		# 			'Name': attribute.attribute_name,
		# 			'Value': attribute.attribute_value_name,
		# 		})
		# 	variant_data['VariationSpecifics'] = {
		# 		'NameValueList': variant_attributes
		# 	}
		# 	ebay_variants.append(variant_data)
		# product_data = dict()
		# product_data['ItemID'] = product_id
		# product_data['Variations'] = {
		# 	'VariationSpecificsSet': {
		# 		"NameValueList": specific
		# 	},
		# 	'Variation': ebay_variants,
		# }
		# if is_ended:
		# 	self.ended_listing(product_id, row.product)
		# 	continue
		# ebay_status = product.channel[f'channel_{self.get_channel_id()}'].get('ebay_status')
		# if ebay_status == 'ended':
		# 	self.re_listing(product_id, product)
		# channel_data = product['channel'][f'channel_{self.get_channel_id()}']
		# category_template = ebay_product_data.get('template_data', {}).get('category') or ebay_product_data.channel.get(f'channel_{self.get_channel_id()}', {}).get('template_data', {}).get('category')
		#
		# listing_type = 'Auction' if category_template.listing_type == 'Auction' and not ebay_product_data.variants else 'FixedPriceItem'
		# if listing_type == 'Auction':
		# 	method = 'ReviseItem'
		# else:
		# 	method = 'ReviseFixedPriceItem'
		# product_xml = self.dict_to_xml_product_body(method, {
		# 	'Item': product_data
		# })
		# response = self.xml_api(method, product_xml)
		# if not response.get('Errors'):
		# 	row['sync_inventory'] = True
		# else:
		# 	errors = obj_to_list(response['Errors'])
		#
		# 	message = '\n'.join(errors)
		# 	row['sync_msg_error'] = message
		if update_inventory:
			self.update_inventory_status(update_inventory)
		return Response().success(convert)


	def out_of_stock_control_preference(self, stock_control = True):
		control_bol = 'true' if stock_control else 'false'
		body_xml = f'''<?xml version="1.0" encoding="utf-8"?> 
		<SetUserPreferencesRequest xmlns="urn:ebay:apis:eBLBaseComponents"> 
		  <WarningLevel>High</WarningLevel> 
		  <OutOfStockControlPreference>{control_bol}</OutOfStockControlPreference>
		</SetUserPreferencesRequest>'''
		self.xml_api('SetUserPreferences', body_xml)
		return True


	def get_product_identifier_unavailable_text(self):
		site_id = to_int(self.get_site_id())
		if site_id in [23, 71, 101, 210]:
			return 'Non applicable'
		if site_id in [16, 77, 193]:
			return 'Nicht zutreffend'
		if site_id in [186]:
			return 'No aplicable'
		if site_id in [123, 146]:
			return 'Niet van toepassing'
		if site_id in [201]:
			return '不适用'
		if site_id in [212]:
			return 'Nie dotyczy'
		return 'Does not apply'


	def extend_convert_product_data(self, product):
		return {
			'thumb_image': product.thumb_image,
			'images': product.images,
		}


	def valid_upc(self, upc):
		if not upc:
			return False
		return barcodenumber.check_code_upc(upc)  or (self.is_eu() and self.valid_ean(upc))


	def valid_ean(self, ean):
		if not ean:
			return False
		return barcodenumber.check_code_ean13(ean) or barcodenumber.check_code_ean8(ean) or barcodenumber.check_code_ean(ean)


	def filter_by_custom_categories(self):
		return self._state.channel.config.api.custom_categories


	def simple_sync_title_by_inventory_api(self, product_id, product, products_ext):
		inventory_item = self.api(f'sell/inventory/v1/inventory_item/{product.sku}')
		if self._last_status < 300:
			inventory_item['product']['title'] = product.name
			inventory_item['product']['description'] = self.escape_description(product.description)
			inventory_item_update = self.api(f'sell/inventory/v1/inventory_item/{product.sku}', inventory_item, method = 'put')
			return Response().success()
		return Response().error(msg = 'Inventory API Sync Title Error')

	def channel_sync_title_by_inventory_api(self, product_id, product, products_ext):
		if product.is_retry_inventory:
			return Response().error(msg = "retry_inventory")
		self._offer_data = dict()
		self._inventory_item_data = dict()

		if not product.variants:
			simple_sync = self.simple_sync_title_by_inventory_api(product_id, product, products_ext)
			if simple_sync.result == 'inventory':
				self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', False)
				product['channel'][f'channel_{self.get_channel_id()}']['inventory_api'] = False
				product.is_retry_inventory = True
				return self.channel_sync_title(product_id, product, None)
			return simple_sync
		variant_default = product.variants[0]
		inventory_item = self.api(f'sell/inventory/v1/inventory_item/{variant_default.sku}')

		if variant_default:
			inventory_item_group_key = variant_default['inventoryItemGroupKeys'][0]
			inventory_item_group = self.api(f'sell/inventory/v1/inventory_item_group/{inventory_item_group_key}')
			if self._last_status < 300:
				inventory_item_group['title'] = product.name
				inventory_item_group['description'] = self.escape_description(product.description)
				inventory_item_group_update = self.api(f'sell/inventory/v1/inventory_item_group/{inventory_item_group_key}', inventory_item_group, method = 'put')

		return Response().success()


	def channel_sync_title(self, product_id, product, products_ext):
		if not self.is_setting_sync_title() and not self.is_setting_sync_description():
			return Response().success()
		if product['channel'][f'channel_{self.get_channel_id()}'].get('inventory_api'):
			return self.channel_sync_title_by_inventory_api(product_id, product, None)
		product_data = dict()
		product_data['ItemID'] = product_id

		if self.is_setting_sync_description():
			product_data['Description'] = self.escape_description(product.description)
			product['description'] = product_data['Description']
		product_name = self.strip_html_from_description(product.name)
		product_name = self.title_cutting(product_name, 80)
		if self.is_setting_sync_title():
			product_data['Title'] = product_name
			product['name'] = product_data['Title']
		if self.is_setting_sync_sku():
			product_data['SKU'] = product.sku
		category_template = product.get('template_data', {}).get('category')
		listing_type = 'Chinese' if category_template.listing_type == 'Auction' and not product.variants else 'FixedPriceItem'
		if listing_type == 'Chinese':
			import_method = 'ReviseItem'
		else:
			import_method = 'ReviseFixedPriceItem'
		product_xml = self.dict_to_xml_product_body(import_method, {
			'Item': product_data
		})

		kwargs = {
			'action': import_method,
			'body': product_xml,
			'custom_headers': {"X-EBAY-API-DETAIL-LEVEL": "0"}
		}
		product_response = self.xml_api(**kwargs)
		response = product_response.get(f'{import_method}Response')
		if not response:
			return Response().error(code = Errors.EBAY_NOT_RESPONSE)
		if response.get('Errors'):
			errors = obj_to_list(response['Errors'])
			for error in errors:
				if to_int(error.get('ErrorCode')) == 21919474:
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.inventory_api', True)
					return self.channel_sync_title_by_inventory_api(product_id, product, None)
		if response.Ack in ['Success', 'Warning']:
			return Response().success(product)
		msg_errors = product_response.get('msg_errors')
		return Response().error(msg = msg_errors)


	def display_push_channel(self, data = None):
		parent = super().display_push_channel(data)
		if parent.result != Response.SUCCESS:
			return parent
		if not self.is_inventory_process():
			return Response().success()
		today = datetime.today()
		day = today.day
		date_format = today.strftime("%Y-%m-%d")
		if self._state.channel.config.reset_inventory_sync == date_format:
			return Response().success()
		self._state.channel.config.reset_inventory_sync = date_format
		self.get_model_state().update_field(self.get_state_id(), 'channel.config.reset_inventory_sync', date_format)
		try:
			where = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.link_status', "linked")
			where.update(self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.template_data.category.listing_type', "Auction"))
			where.update(self.get_model_catalog().create_where_condition('is_variant', False))
			id_src = ''
			while True:
				if id_src:
					where.update(self.get_model_catalog().create_where_condition('_id', id_src, '>'))
				products = self.get_model_catalog().find_all(where, select_fields = ['qty', f'channel.channel_{self.get_channel_id()}'], limit = 500, sort = '_id')
				if not products:
					break
				for product in products:
					self.get_model_catalog().update_field(product['_id'], 'updated_time', time.time())
					time.sleep(0.1)
					id_src = product['_id']
				if to_len(products) < 500:
					break
		except:
			self.log_traceback()
		return Response().success()


	def channel_order_is_completed(self, order_id):
		try:
			order = self.api(f"sell/fulfillment/v1/order/{order_id}/shipping_fulfillment")
			if self._last_status == 200:
				if not order.get('fulfillments'):
					return False
		except:
			self.log_traceback()
			return True
		return True


	def is_variant_removed(self, variant):
		return variant['channel'].get(f'channel_{self.get_channel_id()}', {}).get('is_variant_removed')
