import copy
import uuid

import barcodenumber
import requests
import validators

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.base import ConstructBase
from datasync.models.constructs.order import Order, OrderProducts
from datasync.models.constructs.product import (Product, ProductImage, ProductVariant, ProductVariantAttribute)
from datasync.models.constructs.state import EntityProcess


class ModelChannelsFacebook(ModelChannel):
	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	ORDER_STATUS = {'CREATED': Order.OPEN, 'PAYER_ACTION_REQUIRED': Order.AWAITING_PAYMENT, 'SAVE': Order.READY_TO_SHIP,
	                'APPROVED': Order.READY_TO_SHIP, 'COMPLETED': Order.COMPLETED, 'VOIDED': Order.CANCELED}
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'shipping']

	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._api_url = None
		self._version_api = None
		self._last_status = None

		self.__app_user_id = None
		self.__user_access_token = None
		self.graph_api_version = get_config_ini('facebook', 'graph_api_version')
		self.redirect_url = get_config_ini('facebook', 'redirect_url')
		self.base_url = None
		self.page_id = None
		self._currency = None
		self.link_next_product = None
		self.link_next_order = None
		self._flag_finish_product = False
		self.fields = ['additional_image_cdn_urls', 'additional_image_urls',
		               'additional_variant_attributes', 'age_group', 'availability',
		               'applinks', 'brand', 'capability_to_review_status', 'category', 'color',
		               'condition', 'commerce_insights', 'currency', 'custom_label_0',
		               'custom_data', 'custom_label_1', 'custom_label_2', 'custom_label_3',
		               'custom_label_4', 'pattern', 'retailer_id', 'product_type',
		               'review_rejection_reasons', 'review_status', 'retailer_product_group_id',
		               'sale_price,product_group', 'sale_price_start_date',
		               'shipping_weight_value', 'sale_price_end_date', 'size', 'start_date',
		               'short_description', 'visibility', 'url', 'shipping_weight_unit',
		               'product_feed', 'product_catalog', 'description', 'expiration_date',
		               'fb_product_category', 'gender', 'gtin', 'image_url', 'inventory',
		               'material', 'mobile_link', 'ordering_index', 'id', 'image_cdn_urls',
		               'name', 'price', 'manufacturer_part_number', 'product_sets']


	def get_api_info(self):
		return {
			'user_access_token': 'user access token',
			'app_user_id': 'App User Id',
		}


	def _extend_user_access_token(self, user_access_token):
		"""
		Extend short live user access token
		:param user_access_token: short live user access token
		:return: extended, long live token
		"""
		url = f'https://graph.facebook.com/{self.get_api_version()}/oauth/access_token'

		params = {'grant_type': 'fb_exchange_token',
		          'client_id': to_str(self.get_app_id(self._user_id)),
		          'client_secret': to_str(self.get_app_secret(self._user_id)),
		          'fb_exchange_token': user_access_token}

		resp = requests.request(method = 'GET',
		                        url = url,
		                        params = params)
		resp = resp.json()
		if 'access_token' in resp.keys():
			extended_token = resp['access_token']
			return extended_token

		self.log(f"Failed extend user_access_token {user_access_token}")
		return user_access_token


	def get_refreshing_code(self, long_lived_user_access_token):
		"""
		Get refreshing code for refreshing access token
		:param long_lived_user_access_token:
		:param redirect_url: redirect url
		:return: refreshing code
		"""
		self.log('Start get_refreshing_code...')
		url = f'https://graph.facebook.com/{self.get_api_version()}/oauth/client_code'
		params = {'client_id': to_str(self.get_app_id(self._user_id)),
		          'client_secret': to_str(self.get_app_secret(self._user_id)),
		          'redirect_uri': self.redirect_url,
		          'access_token': long_lived_user_access_token}

		resp = requests.request(method = 'GET',
		                        url = url,
		                        params = params)
		self.log(f'URL: {resp.url}')
		resp = resp.json()
		self.log(resp)

		if 'code' in resp.keys():
			refreshing_code = resp['code']
			self.log(f'Refreshing code: {refreshing_code}')
			return refreshing_code

		self.log(f'ERROR: {resp["error"]}')
		return


	def refresh_access_token(self, long_lived_user_access_token):
		self.log('Start refresh_access_token....')
		is_valid, user_id = self._is_access_token_valid(input_token = long_lived_user_access_token)
		if is_valid:
			self.log('This token is valid')
			return
		refreshing_code = self.get_refreshing_code(long_lived_user_access_token = long_lived_user_access_token)

		if refreshing_code and refreshing_code != '':
			url = f'https://graph.facebook.com/{self.get_api_version()}/oauth/access_token'
			params = {'code': refreshing_code,
			          'client_id': to_str(self.get_app_id(self._user_id)),
			          'redirect_uri': self.redirect_url,
			          'machine_id': user_id}
			resp = requests.request(method = 'GET',
			                        url = url,
			                        params = params)
			self.log(f'URL: {resp.url}')
			resp = resp.json()

			if 'access_token' in resp.keys():
				access_token = resp['access_token']
				self.log(f'Access token: {access_token}')
				return access_token

			self.log('Cannot refresh access token')
			self.log(resp)
			return


	def requests(self, url, params = None, data = None, headers = None, method = 'get'):
		method = to_str(method).lower()
		if not headers:
			headers = {
				'Authorization': f'Bearer {self._state.channel.config.api.user_access_token}',
				'Content-Type': 'application/json'
			}
		request_options = {
			'headers': headers,
			'verify': True,
		}
		if params:
			request_options['params'] = params
		if data:
			request_options['data'] = data
		request_options = self.combine_request_options(request_options)
		try:
			response = requests.request(method, url, **request_options)
			self._last_status = response.status_code
			if response.status_code > 300 or self.is_log():
				error = {
					'method': method,
					'headers': headers,
					'data': data,
					'status_code': response.status_code,
					'content': response.text
				}
				self.log_request_error(url, **error)
			if response.status_code in [200, 201]:
				return Response().success(response.json())
			self.log_request_error(url, response = response.text, method = method, data = data)

			if response.status_code == 401:
				access_token = self.refresh_access_token(self._state.channel.config.api.user_access_token)
				if not access_token:
					self.set_action_stop(True)
					self.channel_disconnected()
					if response and response.text:
						msg = response.text
						if json_decode(response.text):
							response_data = json_decode(response.text)
							if response_data.get('error', {}) and response_data.get('error', {}).get('message'):
								return Response().error(msg = response_data.get('error', {}).get('message'))
					return Response().error(msg = "Don't refresh token")
				self.get_model_state().update_field(self._state_id, "channel.config.api.user_access_token",
				                                    self._extend_user_access_token(access_token))
				return self.requests(url, data, headers, method)
			if "There have been too many calls to this ad-account" in response.text:
				retry = 5
				for i in range(retry):
					response = requests.request(method, url, **request_options)
					if response.status_code in [200, 201]:
						return Response().success(response.json())
					elif response.status_code == 400:
						time.sleep(5 * (i + 1))


			response_data = response.text
			msg = response_data
			if json_decode(response_data):
				response_data = json_decode(response_data)
			if response_data and response_data.get('error'):
				msg = response_data['error'].get('error_user_msg') or response_data['error'].get('error_user_title') or response_data['error'].get('message')
			return Response().error(code = Errors.FACEBOOK_FAIL_API, msg = msg)
		except Exception as e:
			error = {
				'method': method,
				'headers': headers,
				'data': data,
				'error': e
			}
			self.log_request_error(url, **error)
			return Response().error(code = Errors.EXCEPTION, msg = e)


	def api(self, api_prefix, method = 'get', params = None, data = None):
		url = f'https://graph.facebook.com/{self.get_api_version()}/%s' % api_prefix
		return self.requests(url, params = params, data = data, method = method)


	#  TODO
	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent

		valid, user_id = self._is_access_token_valid(self._state.channel.config.api.user_access_token)

		if not valid:
			return Response().error(Errors.FACEBOOK_INFO_INVALID, msg = 'token invalid')

		self._state.channel.support.categories = False
		self._state.channel.config.api.user_access_token = self._extend_user_access_token(self._state.channel.config.api.user_access_token)
		# catalog_info = self._get_catalog_info()
		# if not catalog_info:
		# 	return Response().error(msg = "Dont catalog info")
		# self._state.channel.config.api.update({"catalog_info": catalog_info})
		# self.get_model_state().update_field(self._state_id, "channel.config.api.catalog_info", catalog_info)
		# self.get_model_state().update_field(self._state_id, "channel.config.api.user_access_token", self._extend_user_access_token(self._state.channel.config.api.user_access_token))
		return Response().success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()

		if parent.result != Response().SUCCESS:
			return parent
		user_id = self._state.channel.config.api.app_user_id
		page_id = self.get_page_id()
		identifier = [to_str(user_id)]
		if page_id:
			identifier.append(page_id)
		self.set_identifier('-'.join(identifier))

		return Response().success()


	def _is_access_token_valid(self, input_token):
		"""
		check that the access token is valid or not
		"""
		resp = requests.request(method = 'get',
		                        url = 'https://graph.facebook.com/debug_token',
		                        params = {'input_token': input_token,
		                                  'access_token': to_str(self.get_app_access_token(self._user_id))}).json()
		if not resp or not resp.get('data'):
			return False, False
		if 'error' not in resp['data']:
			return True, resp['data']['user_id']
		else:
			error = {'input_token': input_token, 'access_token': to_str(self.get_app_access_token(self._user_id))}
			self.log_request_error('https://graph.facebook.com/debug_token', **error)
			return False, False


	# return resp if 'error' not in resp.keys() else Response().error(msg = resp['data']['error'])

	def _get_page_data(self):
		"""
		List of page data
		"""
		api_prefix = f'{self._state.channel.config.api.app_user_id}/accounts'
		page_data = self.api(api_prefix = api_prefix)
		page_id_str = str(self.get_page_id())

		if page_data['result'] != 'success':
			return Response().error(Errors.FACEBOOK_FAIL_API,
			                        msg = f" {json.loads(page_data.get('msg')).get('error').get('message')}")

		if page_data['result'] == 'success' and 'data' in page_data['data'].keys():
			page_info = [{'name': p['name'], 'id': p['id']} for p in page_data['data'].get('data')]

			for p in page_info:
				if int(p['id']) == int(page_id_str):
					return p

		return Response().error(msg = page_data['error'])


	def get_page_id(self):
		return self._state.channel.config.api.page_id


	def _get_catalog(self):
		# Just one page return when use the catalog management permission
		page_id = self.get_page_id()
		api_prefix = f"{self.get_page_id()}/product_catalogs"
		resp = self.api(api_prefix)

		if resp['result'] != 'success':
			return False

		if resp['result'] == 'success':
			if len(resp['data'].get('data')) > 0:
				list_catalogs = resp['data'].get('data')

				for catalog in list_catalogs:
					if page_id in catalog['name']:
						return catalog
				return list_catalogs[0]
			else:
				return False
		return False


	def _get_all_products_from_catalog(self, catalog_id, limit = None):
		api_prefix = f"{catalog_id}/products"

		if limit:
			params = {'limit': limit}
			self.log(f'log api catalog: {params}')
			resp = self.api(api_prefix, params = params)
			self.log(f"log res api catalog: {resp}")

		else:
			resp = self.api(api_prefix)

		if resp['result'] != 'success':
			return Response().error(Errors.FACEBOOK_FAIL_API,
			                        msg = f" {json.loads(resp.get('msg')).get('error').get('message')}")

		if resp['data'].get('data') and resp['data'].get('paging', {}).get('next'):
			return resp['data'].get('data'), resp['data'].get('paging', {}).get('next')

		if resp['data'].get('data'):
			return resp['data'].get('data'), None

		return Response().error(msg = resp['error']), None


	def count_product_import(self, product_catalog_id):
		total = 0
		next_cursor = self._state.pull.process.products.next_cursor
		api_prefix = f'{product_catalog_id}/product_groups'
		params = {'fields': 'id,retailer_id,variants,products,product_catalog', 'limit': 1}
		if not next_cursor:
			resp = self.api(api_prefix, params = params)
		else:
			resp = self.requests(next_cursor)

		if resp.result != Response.SUCCESS:
			return 0
		data = resp['data']['data']
		if data:
			return -1
		return total


	def _get_all_product_groups(self, product_catalog_id, limit = None, loop = True):
		api_prefix = f'{product_catalog_id}/product_groups'

		params = {'fields': 'id,retailer_id,variants,products,product_catalog',
		          'limit': limit}
		resp = self.api(api_prefix, params = params)
		data = resp['data'].get('data')

		next_cursor = resp['data'].get('paging', {}).get('next')

		error = resp.get('error')
		headers = {
			'Authorization': f'Bearer {self._state.channel.config.api.user_access_token}',
			'Content-Type': 'application/json'
		}

		if error:
			return Response().error(msg = str(error))

		if not loop:
			return data, next_cursor

		while next_cursor:
			resp = requests.request('get', next_cursor, headers = headers).json()
			data += resp.get('data')
			next_cursor = resp.get('paging', {}).get('next')

		return data


	def _delete_invalid_product_groups(self, all_product_group):
		"""
		Invalid == There is no product on that groups
		"""

		for group in all_product_group:
			if not group.get('products', {}).get('data') or not group.get('variants'):
				self._delete_item(group.get('id'))

		return


	def _delete_invalid_group(self, product_group_id):
		res = self.api(api_prefix = f"{product_group_id}/products")
		if res['result'] == 'success' and not res['data'].get('data'):
			self.api(api_prefix = f"{product_group_id}", method = 'delete')
			return True


	def display_pull_channel(self):
		limit_product = self._state.pull.setting.products
		page_id = self.get_page_id()
		parent = super().display_pull_channel()

		if parent.result != Response().SUCCESS:
			return parent

		# Get all product from facebook page
		if self.is_product_process():
			self._state.pull.process.products.finished = False
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.id_src = 0
			catalog_id = self._get_catalog_id()
			if catalog_id:
				self._state.pull.process.products.total = self.count_product_import(product_catalog_id = catalog_id)
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0

		if self._state.config.orders:
			created_channel = self._state.channel.created_at
			count_order = 0
			limit_order = self._state.pull.setting.orders
			while True:
				params = {
					'fields': 'id,order_status,created,last_updated,items,ship_by_date,merchant_order_id,channel,selected_shipping_option,shipping_address,estimated_payment_details,buyer_details',
					'limit': limit_order,
					'updated_after': created_channel,
				}
				orders_api = self.api(api_prefix = f"{page_id}/commerce_orders", params = params)
				if orders_api['result'] == 'success':
					count_order += len(orders_api['data'].get('data'))
				else:
					break
			self._state.pull.process.orders.total = count_order

		return Response().success()


	def _get_catalog_info(self) -> dict or bool:

		catalog_info = self._state.channel.config.api.catalog_info
		if catalog_info and catalog_info.get('id'):
			return catalog_info
		if self._state.channel.config.setting.fb_product_catalog and self._state.channel.config.setting.fb_product_catalog.catalog_id:
			return self._state.channel.config.setting.fb_product_catalog
		return False


	def _get_catalog_id(self) -> dict or bool:

		catalog_info = self._state.channel.config.api.catalog_info
		if catalog_info and catalog_info.get('id'):
			return catalog_info.get('id')
		if self._state.channel.config.setting.fb_product_catalog and self._state.channel.config.setting.fb_product_catalog.catalog_id:
			return self._state.channel.config.setting.fb_product_catalog.catalog_id
		return False


	def get_products_main_export(self):
		if self._flag_finish_product:
			return Response().finish()
		catalog_id = self._get_catalog_id()
		# limit = self._state.pull.setting.products
		next_cursor = self._state.pull.process.products.next_cursor
		api_prefix = f'{catalog_id}/product_groups'
		params = {'fields': 'id,retailer_id,variants,products,product_catalog', 'limit': 25}
		if not next_cursor:
			resp = self.api(api_prefix, params = params)
		else:
			resp = self.requests(next_cursor)
		if resp['result'] != 'success' or not resp['data'] or not resp['data'].get('data'):
			return Response().finish()
		products = resp['data']['data']
		self.link_next_product = resp.get('data', {}).get('paging', {}).get('next')
		if not self.link_next_product:
			self._flag_finish_product = True
		return Response().success(products)


	def get_product_main_export(self, group_id, main_product = None):
		product_channel_id = group_id
		product = self.get_model_catalog().get(group_id, ['channel'])
		field_check = 'channel_{}'.format(self._state.channel.id)
		if not product or not product['channel'].get(field_check):
			return Response().finish()
		product_channel_id = product['channel'][field_check].get('group_id')

		product_channel = self.get_product_by_id(product_channel_id)
		if product_channel.result != Response.SUCCESS:
			return Response().finish()
		return product_channel


	def get_products_ext_export(self, products):
		extend = Prodict()
		for pr_gr in products:
			product_id = pr_gr.get('id')
			variants = self._get_product_variants(product_id)
			if variants:
				extend[to_str(product_id)] = variants
		return Response().success(extend)


	def set_imported_product(self, imported):
		self._state.pull.process.products.imported += imported
		self._state.pull.process.products.next_cursor = self.link_next_product


	def _get_product_variants(self, product_group_id, limit = None):
		# if limit:
		# 	fields = 'variants,retailer_id,product_catalog,id,products.limit(%s){id,product_group,' \
		# 			 'retailer_id,retailer_product_group_id,additional_image_cdn_urls,additional_image_urls,' \
		# 			 'additional_variant_attributes,applinks,age_group,availability,condition,color,category,' \
		# 			 'capability_to_review_status,brand,commerce_insights,custom_data,currency,custom_label_1,' \
		# 			 'custom_label_2,custom_label_3,custom_label_4,description,custom_label_0,fb_product_category,' \
		# 			 'gender,expiration_date,image_cdn_urls,image_url,inventory,manufacturer_part_number,material,' \
		# 			 'mobile_link,gtin,ordering_index,pattern,name,product_catalog,product_feed,product_type,' \
		# 			 'review_rejection_reasons,review_status,sale_price,price,sale_price_start_date,shipping_weight_unit,' \
		# 			 'sale_price_end_date,short_description,size,start_date,url,visibility}'
		# 	fields = fields % str(limit)
		# 	api_prefix = f'{product_group_id}?fields={fields}'
		# 	return self.api(api_prefix)['data']

		fields = 'variants,retailer_id,product_catalog,id,products{id,product_group,retailer_id,' \
		         'retailer_product_group_id,additional_image_cdn_urls,additional_image_urls,' \
		         'additional_variant_attributes,applinks,age_group,availability,condition,color,' \
		         'category,capability_to_review_status,brand,custom_data,currency,' \
		         'custom_label_1,custom_label_2,custom_label_3,custom_label_4,description,' \
		         'custom_label_0,fb_product_category,gender,expiration_date,image_cdn_urls,' \
		         'image_url,inventory,manufacturer_part_number,material,mobile_link,gtin,' \
		         'ordering_index,pattern,name,product_catalog,product_feed,product_type,' \
		         'review_rejection_reasons,review_status,sale_price,price,sale_price_start_date,' \
		         'shipping_weight_unit,sale_price_end_date,short_description,size,start_date,url,visibility}'
		api_prefix = f'{product_group_id}?fields={fields}'
		variants = self.api(api_prefix)
		if variants.result == Response.SUCCESS:
			return variants.data
		return False


	def _convert_product_export(self, product, products_ext):
		"""
		Map facebook product to CM product
		link docs: https://developers.facebook.com/docs/marketing-api/reference/product-item/
		"""
		product_id = product.id
		products_extend = products_ext.get(product_id, {})

		list_variants = products_extend.get('products', {}).get('data', [])
		if not list_variants:
			return Response().skip()
		list_attribute = []
		for attr in products_extend.get('variants'):
			list_attribute.append(attr.product_field)

		variants_data = []
		variant_count = 0
		product_attribute = []
		category_path_product = None
		for variant in list_variants:
			variant_count += 1
			if not self.is_import_inactive():
				if variant.get('visibility') == 'hidden':
					continue
			variant_data = ProductVariant()
			variant_data.id = variant.get('id')
			variant_data.name = variant.get('name')
			variant_data.description = variant.get('description')
			try:
				price = re.sub(r"[^0-9.,]", '', variant.get('price'))
				if price.find('.') != -1 and price.find(',') != -1:
					price = price.replace('.', '')
					price = price.replace(',', ".")
				elif price.find(',') != -1:
					price = price.replace(',', "")
				variant_data.price = to_decimal(price)
			except:
				variant_data.price = 0.0
			if variant.image_cdn_urls:
				variant_data.thumb_image.url = variant.image_cdn_urls[1].get('value')
			else:
				variant_data.thumb_image.url = variant.get('image_url')

			if variant.additional_image_cdn_urls:
				k = 2
				for image in variant.additional_image_cdn_urls:
					variant_image_data = ProductImage()
					variant_image_data.url = image[1].get('value')
					variant_image_data.position = k
					variant_data.images.append(variant_image_data)
					k += 1
			elif variant.additional_image_urls:
				k = 2
				for image in variant.additional_image_urls:
					variant_image_data = ProductImage()
					variant_image_data.url = image
					variant_image_data.position = k
					variant_data.images.append(variant_image_data)
					k += 1

			variant_data.special_price.price = variant.get('sale_price')
			variant_data.special_price.end_date = variant.get('sale_price_end_date')
			variant_data.special_price.start_date = variant.get('sale_price_start_date')
			variant_data.condition = variant.get('condition')
			variant_data.gtin = variant.get('gtin')
			variant_data.mpn = variant.get('manufacturer_part_number')
			variant_data.sku = variant.get('retailer_id')
			variant_data.qty = variant.get('inventory')
			variant_data.brand = variant.get('brand')
			variant_data.seo_url = variant.get('url')

			for attr in list_attribute:
				variant_attribute = ProductVariantAttribute()
				variant_attribute.attribute_name = attr
				variant_attribute.attribute_value_name = variant.get(attr)
				variant_data.attributes.append(variant_attribute)

			for att in ['age_group', 'gender', 'material', 'color', 'size', 'product_type']:
				if att not in list_attribute and product.get(att):
					product_attr = ProductVariantAttribute()
					product_attr.attribute_name = att
					product_attr.attribute_value_name = variant.get(att)
					variant_data.attributes.append(product_attr)

			if variant.get('additional_variant_attributes'):
				for attr in variant.get('additional_variant_attributes'):
					variant_attribute = ProductVariantAttribute()
					variant_attribute.attribute_name = attr.get('key')
					variant_attribute.attribute_value_name = attr.get('value')
					variant_data.attributes.append(variant_attribute)
					list_attribute.append(attr.get('key'))

			if variant_count == 1:
				for att in ['age_group', 'gender', 'material', 'color', 'size', 'product_type']:
					if att not in list_attribute and product.get(att):
						product_attr = ProductVariantAttribute()
						product_attr.attribute_name = att
						product_attr.attribute_value_name = variant.get(att)
						product_attribute.append(product_attr)

			MAX_CUSTOM_LABEL = 4
			for idx in range(MAX_CUSTOM_LABEL + 1):
				if not variant.get(f'custom_label_{idx}'):
					break

				variant_attribute = ProductVariantAttribute()
				variant_attribute.attribute_name = f'Custom Label {idx}'
				variant_attribute.attribute_value_name = variant.get(f'custom_label_{idx}')
				variant_data.attributes.append(variant_attribute)

			data_channel = FacebookProductChannel()
			data_channel.commerce_insights = variant.get('commerce_insights')
			data_channel.currency = variant.get('currency')
			data_channel.start_date = variant.get('start_date')
			data_channel.expiration_date = variant.get('expiration_date')
			data_channel.shipping_weight_unit = variant.get('shipping_weight_unit')
			data_channel.shipping_weight_value = variant.get('shipping_weight_value')
			data_channel.visibility = variant.get('visibility')
			data_channel.fb_product_category = variant.get('fb_product_category')
			data_channel.commerce_tax_category = variant.get('commerce_tax_category')
			data_channel.group_id = product.id
			data_channel.retailer_id = variant.get('retailer_id')

			# variant_data.channel_data = data_channel
			template_data = {
				'category': {'category': {"name": variant.get("category", "")}},
				'shipping': {
					'shipping_weight_unit': variant.get('shipping_weight_unit', None),
					'shipping_weight_value': variant.get('shipping_weight_value', None)
				}
			}
			channel_data = {
				'retailer_id': variant.get('retailer_id')
			}
			variant_data.template_data = template_data
			# variant_data.channel_data = channel_data
			if variant_count == 1:
				category_path_product = variant.get("category", "")
			# category_path = self.get_category_path(channel_type = 'facebook', type_search = 'google_product_category', params = {"name": template_data['category']['category']})
			# if category_path:
			# 	category_path_product = category_path[0].get('path') if category_path else None
			# 	data_channel.path = category_path_product
			else:
				data_channel.path = category_path_product

			variant_data.channel_data = data_channel

			variants_data.append(variant_data)

		if len(list_variants) == 1:
			product_data = variants_data[0]
			product_data.type = 'simple'
		else:
			product_data = copy.deepcopy(variants_data[0])
			product_data.variants = variants_data
			product_data.type = 'configurable'
			product_data.id = product.id

		product_data.is_variant = False
		product_data.sku = variants_data[0].get('sku') or product_id
		product_data.attributes = product_attribute

		return Response().success(product_data)


	def get_product_by_id(self, product_id):
		product = self._get_product_variants(product_group_id = product_id)
		if not product:
			return Response().error(Errors.FACEBOOK_FAIL_API, msg = 'failed get product variants')
		return Response().success(data = product)


	def get_product_id_import(self, convert: Product, product, products_ext):
		convert_product = self.convert_product_export(product, products_ext)
		if convert_product.result != Response.SUCCESS:
			return product.id
		convert_data = convert_product.data
		return convert_data.id
		try:
			product_id = product.products.data[0].id
			return product_id
		except Exception:
			self.log_traceback()
			return False


	def _add_product_to_fb_shop(self, data: dict):
		"""
		Add product to facebook shop
		catalog_info: dictionary {name: , id: }
		"""
		catalog_id = self._get_catalog_id()
		if not catalog_id:
			return Response().error(code = Errors.FACEBOOK_CATALOG_INFO_IS_REQUIRED)

		api_prefix = f'{catalog_id}/products'
		try:
			resp = self.api(api_prefix, data = json.dumps(data), method = 'post')
			return resp

		except Exception as e:
			self.log_traceback()
			return Response().error(code = Errors.EXCEPTION, msg = e)


	def get_draft_extend_channel_data(self, product):
		seo_url = product.seo_url
		data = dict()
		if seo_url:
			if validators.url(seo_url):
				data = {'seo_url': seo_url}
			else:
				data = {'seo_url': f"{self._state.channel.url.strip('/')}/{to_str(seo_url.strip('/'))}"}
		data['gtin'] = product.gtin or product.upc or product.ean or product.isbn
		data['brand'] = product.brand or product.manufacturer.name
		data['mpn'] = product.mpn
		if not data['gtin'] and not data['brand'] or not data['mpn']:
			data['mpn'] = product.sku
		description = product.description or product.short_description
		data['description'] = self.strip_html_from_description(description)
		if to_len(product.name) > 150:
			data['name'] = to_str(product.name)[:150]
		data['retailer_id'] = product['_id']
		data['price'] = round(to_decimal(product.price))
		return data


	def to_fb_price(self, price):
		if not price:
			return 0
		return to_int(100 * to_decimal(price, 2))


	def convert_to_facebook_product(self, product: Product, parent: Product or None, products_ext, insert = False):
		channel_id = to_str(self._state.channel.id)
		name = product.name or (parent.name if parent else '')
		if parent:
			is_variant = True

			name = parent.name
			attribute_values = []
			for attribute in product.attributes:
				if not attribute.use_variant:
					continue
				attribute_values.append(attribute.attribute_value_name)
			if attribute_values:
				name = f"{name} - {'/'.join(attribute_values)}"
		else:
			is_variant = False
		name = name[:150]
		if not name:
			return Response().error(msg = 'product name is required')

		# Get catalog information: name, id from page name

		product_data = dict()
		parent = parent or product
		template_category = parent.get('channel').get(f'channel_{channel_id}').get('template_data', {}).get('category')
		if not template_category:
			return Response().error(Errors.TEMPLATE_NOT_FOUND)

		product_data['category'] = template_category.get('category', {}).get('name', '')
		product_data['brand'] = product.brand or parent.brand
		product_data['description'] = product.description or parent.description
		all_image = []
		if product.thumb_image.url:
			all_image.append(product.thumb_image.url)
		if is_variant and parent.thumb_image.url and parent.thumb_image.url not in all_image:
			all_image.append(parent.thumb_image.url)
		images = product.images or parent.images
		fb_images = []
		if to_len(images) > 0:
			for img in images:
				if img.url and img.url not in all_image:
					all_image.append(img.url)

		product_data['image_url'] = all_image[0] if all_image else None
		if all_image:
			del all_image[0]
			product_data['additional_image_urls'] = all_image[0:20] if all_image else None

		product_data['inventory'] = int(product.qty) if int(product.qty) > 0 else 100
		if insert:
			product_data['retailer_id'] = product.retailer_id or product['_id']
			# item_group_id = product_data['item_group_id'] = parent['_id']
			if parent:
				product_data['retailer_product_group_id'] = parent.retailer_id or parent['_id']
		product_data['name'] = name
		product_data['price'] = self.to_fb_price(product.price)
		product_data['url'] = product.link_url or product.seo_url or parent.link_url or parent.seo_url
		if self.is_special_price(product):
			product_data['sale_price'] = self.to_fb_price(product.special_price.price) if product.special_price.price else None
			product_data['sale_price_end_date'] = str(product.special_price.end_date) if product.special_price.end_date else None
			product_data['sale_price_start_date'] = str(product.special_price.start_date) if product.special_price.start_date else None
		additional_variant_attributes = dict()
		if product.attributes:
			for attr in product.attributes:
				if attr.attribute_name in self.fields:
					value = attr.attribute_value_name
					if attr.attribute_name == 'gender':
						value = to_str(value).lower()
						if value not in ['female', 'male', 'unisex']:
							value = 'unisex'
					product_data[attr.attribute_name] = value
					continue
				if attr.use_variant:
					if attr.attribute_name.lower() in ['color', 'colour', 'colore', 'couleur']:
						product_data['color'] = attr.attribute_value_name
						continue
					if attr.attribute_name.lower() in ['size', 'taille', 'dimensione', 'dimension']:
						product_data['size'] = attr.attribute_value_name
						continue
					additional_variant_attributes[to_str(attr.attribute_name)] = to_str(attr.attribute_value_name)
		if additional_variant_attributes:
			product_data['additional_variant_attributes'] = additional_variant_attributes
		product_data['currency'] = self.get_currency()
		product_data['condition'] = product.get('condition') or parent.condition
		if product.gtin and self.valid_gtin(product.gtin):
			product_data['gtin'] = product.get('gtin')
		if product.mpn:
			product_data['manufacturer_part_number'] = product.mpn
		template_shipping = parent.get('channel').get(f'channel_{channel_id}').get('template_data', {}).get('shipping')
		if template_shipping:
			product_data.update(template_shipping)
		channel_fields = ['start_date', 'expiration_date', 'shipping_weight_unit', 'shipping_weight_value', 'visibility', 'fb_product_category', 'commerce_tax_category']
		for field in channel_fields:
			if product.get(field):
				product_data[field] = product.get(field)
		return Response().success(product_data)
	def valid_isbn(self, isbn):
		return barcodenumber.check_code_isbn(isbn) or barcodenumber.check_code_isbn10(isbn) or barcodenumber.check_code_isbn13(isbn)


	def valid_gtin(self, gtin):
		return barcodenumber.check_code_gtin(gtin) or barcodenumber.check_code_gtin14(gtin)


	def valid_upc(self, upc):
		return barcodenumber.check_code_upc(upc) or self.valid_ean(upc)


	def valid_ean(self, ean):
		return barcodenumber.check_code_ean13(ean) or barcodenumber.check_code_ean8(ean) or barcodenumber.check_code_ean(ean)

	def simple_product_import(self, product: Product, parent: Product or None, products_ext):
		# Prepare Data
		post_data = self.convert_to_facebook_product(product, parent, products_ext, insert = True)
		if post_data.result != Response.SUCCESS:
			return post_data
		post_data = post_data.data
		resp = self._add_product_to_fb_shop(post_data)
		if resp.result == Response.SUCCESS:
			return Response().success(resp.data.id)
		# if resp.get('code') == Errors.FACEBOOK_FAIL_API:
		# 	errors = json_decode(resp.get('msg')).get('error')
		# 	msg = errors.get('error_user_msg') or errors.get('message')
		# 	return Response().error(Errors.FACEBOOK_FAIL_API, msg = msg)
		# elif resp.get('code') == 2201:
		# 	return Response().error(Errors.EXCEPTION, msg = resp.get('msg'))
		return resp


	def product_import(self, convert: Product, product, products_ext):
		if not product.variants:
			return self.simple_product_import(product, None, products_ext)
		product_errors = 0
		variant_no_error = []
		same_error = True
		msg_error = ''
		parent_group_id = ''
		for variant in product.variants:
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
			if channel_data and channel_data.get('product_id'):
				continue
			variant_import = self.simple_product_import(variant, product, products_ext)
			self.after_push_product(variant['_id'], variant_import, variant)
			if variant_import.result == Response.SUCCESS:
				if not parent_group_id:
					variant_id = variant_import.data
					api_prefix = f'{variant_id}?fields=id,product_group'
					retry = 0
					while True:
						fb_variant = self.api(api_prefix)
						if self._last_status == 200:
							parent_group_id = fb_variant.data.product_group.id
							break
						if self._last_status == 400 and retry < 5:
							time.sleep(1)
							retry += 1
							continue
						break

				self.insert_map_product(variant, variant['_id'], variant_import.data)
			else:
				variant_msg = variant_import.msg or variant_import.code
				if not msg_error:
					msg_error = variant_msg
				if variant_msg and variant_msg != msg_error:
					same_error = False
				product_errors += 1
		if not parent_group_id:
			parent_group_id = product.retailer_id or product['_id']
		if not product_errors:
			return Response().success(parent_group_id)
		response_msg = msg_error if same_error else 'You have {} variant{} import error'.format(product_errors, "s" if product_errors > 1 else '')

		return Response().error(msg = response_msg)


	def _product_import(self, convert: Product, product, products_ext):
		"""
		item_group_id <=> retailer_product_group_id
		"""
		channel_id = to_str(self._state.channel.id)

		if not product.name:
			return Response().error(msg = 'import product ' + to_str(convert['id']) + ' false.')

		# Get catalog information: name, id from page name

		product_data = dict()

		template_category = product.get('channel').get(f'channel_{channel_id}').get('template_data', {}).get('category')
		if not template_category:
			return Response().error(Errors.TEMPLATE_NOT_FOUND)

		product_data['category'] = template_category.get('category', {}).get('name', '')
		product_data['brand'] = product.manufacturer.name if product.manufacturer.name else None
		product_data['description'] = product.description
		product_data['image_url'] = product.thumb_image.url
		product_data['inventory'] = int(product.qty) if int(product.qty) > 0 else 100
		product_data['retailer_id'] = product.retailer_id or product.sku or str(uuid.uuid1())

		product_data['additional_image_urls'] = []
		if len(product.images) > 0:
			for img in product.images[0:10]:
				if img.url:
					product_data['additional_image_urls'].append(img.url)

		else:
			product_data['additional_image_urls'] = None

		product_data['name'] = product.name
		product_data['price'] = self.to_fb_price(product.price)
		product_data['url'] = product.link_url or product.seo_url
		# product_data['url'] = product.custom_url[0] if product.custom_url else None
		product_data['sale_price'] = self.to_fb_price(product.special_price.price) if product.special_price.price else None
		product_data['sale_price_end_date'] = str(product.special_price.end_date) if product.special_price.end_date else None
		product_data['sale_price_start_date'] = str(product.special_price.start_date) if product.special_price.start_date else None

		if product.attributes:
			for attr in product.attributes:
				if attr.attribute_name in self.fields:
					product_data[attr.attribute_name] = attr.attribute_value_name

		product_data['currency'] = self.get_currency()

		item_group_id = product_data['item_group_id'] = product['_id']
		product_data['retailer_product_group_id'] = item_group_id
		product_data['condition'] = product.get('condition')
		if product.gtin and self.valid_gtin(product.gtin):
			product_data['gtin'] = product.get('gtin')
		if product.mpn:
			product_data['manufacturer_part_number'] = product.mpn

		if product.template_data.get('shipping'):
			product_data.update(product.template_data.get('shipping'))

		# self._delete_invalid_keys(product_data)

		resp = None
		if product.variants:
			for variant in product.variants:
				for attr in variant.attributes:
					attribute_name = attr.get('attribute_name').lower() if attr.get('attribute_name') else None
					attribute_name_value = attr.get('attribute_value_name').lower() if attr.get('attribute_value_name') else None

					if attribute_name in self.fields:
						product_data[attribute_name] = attribute_name_value
					else:
						product_data['additional_variant_attributes'] = {attribute_name: attribute_name_value}

				product_data['item_group_id'] = item_group_id
				product_data['retailer_id'] = variant.retailer_id or variant.sku or str(uuid.uuid1())
				if variant.name:
					product_data['name'] = variant.name
				if variant.description:
					product_data['description'] = variant.description
				if variant.price:
					product_data['price'] = self.to_fb_price(variant.price)
				if variant.qty:
					product_data['inventory'] = int(variant.qty)

				data_channel = variant.get('channel_data', {})

				product_data['currency'] = data_channel.get('currency') if data_channel.get('currency') else product_data['currency']
				product_data['start_date'] = data_channel.get('start_date')
				product_data['expiration_date'] = data_channel.get('expiration_date')
				product_data['shipping_weight_unit'] = data_channel.get('shipping_weight_unit')
				product_data['shipping_weight_value'] = data_channel.get('shipping_weight_value')
				product_data['visibility'] = data_channel.get('visibility')
				product_data['fb_product_category'] = data_channel.get('fb_product_category')
				product_data['commerce_tax_category'] = data_channel.get('commerce_tax_category')
				product_data['url'] = variant.link_url or variant.seo_url or product.link_url or product.seo_url
				resp = self._add_product_to_fb_shop(product_data)

				if resp.get('code') == Errors.FACEBOOK_FAIL_API:
					errors = json_decode(resp.get('msg')).get('error')
					msg = errors.get('error_user_msg') or errors.get('message')
					return Response().error(Errors.FACEBOOK_FAIL_API,
					                        msg = msg)
				elif resp.get('code') == 2201:
					return Response().error(Errors.EXCEPTION, msg = resp.get('msg'))
				self.insert_map_product(variant, variant._id, resp.get('id'))
		else:
			resp = self._add_product_to_fb_shop(product_data)
			if resp.get('code') == 1503:
				errors = json_decode(resp.get('msg')).get('error')
				msg = errors.get('error_user_msg') or errors.get('message')
				return Response().error(Errors.FACEBOOK_FAIL_API,
				                        msg = msg)
			elif resp.get('code') == 2201:
				return Response().error(Errors.EXCEPTION, msg = resp.get('msg'))
		return Response().success(resp['data'].get('id'))


	def _delete_item(self, product_item_id):
		api_prefix = f'{product_item_id}'
		params = {'access_token': self._state.channel.config.api.user_access_token}
		self.api(api_prefix, method = 'delete', params = params)

		return


	def delete_product_import(self, product_id):
		api_prefix = f'{product_id}'
		params = {'access_token': self._state.channel.config.api.user_access_token}
		self.api(api_prefix, method = 'delete', params = params)

		return Response().success()


	@staticmethod
	def _delete_invalid_keys(dictionary):
		invalid_keys = []

		for key, val in dictionary.items():
			if val is None:
				invalid_keys.append(key)

		for k in invalid_keys:
			del dictionary[k]


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		return Response().success()


	def simple_product_update(self, product_id, product: Product, parent: Product or None = None, products_ext = None):
		# Prepare Data
		post_data = self.convert_to_facebook_product(product, parent, products_ext)
		if post_data.result != Response.SUCCESS:
			return post_data
		post_data = post_data.data
		if 'offerId' in post_data:
			del post_data['offerId']
		response = self.api(api_prefix = f"{product_id}", data = json.dumps(post_data), method = 'post')

		if self._last_status == 200 and response and response.data.success:
			return Response().success(product_id)
		msg = response.msg
		if to_str(msg).find('does not exist, cannot be loaded due to missing permissions, or does not support this operation') != -1 and to_str(msg).find(to_str(product_id)) != -1:
			response['msg'] = 'Your product on Facebook has been removed. Please delete the product on LitCommerce and recreate the product'
		return response


	def product_channel_update(self, product_id, product: Product, products_ext):
		if not product.variants:
			return self.simple_product_update(product_id, product, None, products_ext)
		product_errors = 0
		for variant in product.variants:
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']

			if not channel_data or not channel_data.get('product_id'):
				import_variant = self.simple_product_import(variant, product, products_ext)
				if import_variant.result == Response.SUCCESS:
					self.insert_map_product(variant, variant['_id'], import_variant.data)
				else:
					product_errors += 1
				self.after_push_product(variant['_id'], import_variant, variant)
				continue
			variant_update = self.simple_product_update(channel_data.get('product_id'), variant, product, products_ext)
			self.after_update_product(variant['_id'], variant_update, variant)
			if variant_update.result != Response.SUCCESS:
				product_errors += 1
		if not product_errors:
			return Response().success(product['_id'])
		return Response().error(msg = 'You have {} variant{} update error'.format(product_errors, "s" if product_errors > 1 else ''))


	def product_channel_update_test(self, product_id, product: Product, product_etx):
		channel_id = self._state.channel.id

		product_data = dict()

		template_category = product.get('template_data', {}).get('category')
		if not template_category:
			return Response().error(Errors.TEMPLATE_NOT_FOUND)

		product_data['category'] = template_category if template_category else "Animals & Pet Supplies"
		product_data['brand'] = product.manufacturer.name if product.manufacturer.name else None
		product_data['description'] = product.description
		product_data['image_url'] = product.thumb_image.url

		product_data['additional_image_urls'] = []
		if len(product.images) > 0:
			for img in product.images:
				if img.url:
					product_data['additional_image_urls'].append(img.url)

		else:
			product_data['additional_image_urls'] = None

		product_data['name'] = product.name
		product_data['price'] = int(product.price) * 100 if int(product.price) > 0 else 5
		product_data['url'] = product.custom_url[0] if product.custom_url else None
		product_data['sale_price'] = int(product.special_price.price) if product.special_price.price else None
		product_data['sale_price_end_date'] = str(
			product.special_price.end_date) if product.special_price.end_date else None
		product_data['sale_price_start_date'] = str(
			product.special_price.start_date) if product.special_price.start_date else None

		if product.attributes:
			for attr in product.attributes:
				if attr.attribute_name in self.fields:
					product_data[attr.attribute_name] = attr.attribute_value_name

		if not product_data.get('currency'):
			product_data['currency'] = 'USD'

		product_data['condition'] = product.get('condition')
		product_data['gtin'] = product.get('gtin')
		product_data['manufacturer_part_number'] = product.get('manufacturer', {}).get('name') \
			if product.get('manufacturer', {}).get('name') else product.get('manufacturer', {}).get('code')

		resp = None

		if product.variants:
			for variant in product.variants:
				variant_update = variant.channel.get(f"channel_{channel_id}")
				variant_id_facebook = variant_update.get('product_id')
				if not variant_id_facebook:
					self.log("no variant_id_facebook")
					continue

				for attr in variant.attributes:
					attribute_name = attr.get('attribute_name').lower() if attr.get('attribute_name') else None
					attribute_name_value = attr.get('attribute_value_name').lower() if attr.get(
						'attribute_value_name') else None

					if attribute_name in self.fields:
						product_data[attribute_name] = attribute_name_value
					else:
						product_data['additional_variant_attributes'] = {attribute_name: attribute_name_value}

				if variant.name:
					product_data['name'] = variant.name
				if variant.description:
					product_data['description'] = variant.description
				if variant.price:
					product_data['price'] = int(variant.price) * 100
				if variant.qty:
					product_data['inventory'] = int(variant.qty)

				data_channel = variant.get('channel_data', {})

				product_data['currency'] = data_channel.get('currency') \
					if data_channel.get('currency') else product_data['currency']
				product_data['start_date'] = data_channel.get('start_date')
				product_data['expiration_date'] = data_channel.get('expiration_date')
				product_data['visibility'] = data_channel.get('visibility')
				product_data['fb_product_category'] = data_channel.get('fb_product_category')
				product_data['commerce_tax_category'] = data_channel.get('commerce_tax_category')

				res = self.api(api_prefix = f"/{variant_id_facebook}", data = json.dumps(product_data), method = 'post')
				if res['result'] != 'success':
					self.log(f"failed update product_id {variant_id_facebook} with data update: {product_data}")
		else:
			product_update = product.channel.get(f"channel_{channel_id}")
			product_id_facebook = product_update.get('product_id')
			if not product_id_facebook:
				self.log('No product_id_facebook')

			product_update = self.unset_data(product_update, unset = (
				'product_id', 'channel_id', 'publish_status', 'templates', 'template_data', 'edit', 'parent_id'))

			resp = self.api(api_prefix = f"/{product_id_facebook}", data = json.dumps(product_update), method = 'post')
			if resp['result'] == 'success':
				return Response().success(product_id)
		return Response().success(product_id)


	def _update_product_fb(self, product_id, update_data: dict):
		"""
		Update info product existed to facebook shop
		catalog_info: dictionary {name: , id: }
		"""

		api_prefix = f'{product_id}'
		try:
			resp = self.api(api_prefix, data = json.dumps(update_data), method = 'post')
			if resp.get('error'):
				return Response().error(msg = json.loads(resp.get('msg')).get('error').get('message'))

			return resp

		except Exception as e:
			return Response().error(code = Errors.EXCEPTION, msg = e)


	# TODO: Order

	def get_orders_main_export(self):
		limit = self._state.pull.setting.orders
		page_id = self.get_page_id()
		created_channel = self._state.channel.created_at
		response = None

		if self._state.pull.process.orders.imported == 0:
			params = {
				'fields': 'id,order_status,created,last_updated,items,ship_by_date,merchant_order_id,channel,selected_shipping_option,shipping_address,estimated_payment_details,buyer_details',
				'limit': limit,
				'updated_before': None,
				'updated_after': created_channel,
				'state': None,  # enum('FB_PROCESSING', 'CREATED', 'IN_PROGRESS', 'COMPLETED')
				'filters': None
				# enum('no_shipments', 'has_cancellations', 'no_cancellations', 'has_refunds', 'no_refunds')
			}
			response = self.api(api_prefix = f"{page_id}/commerce_orders", params = params)

		elif self._state.pull.process.orders.imported > 0:
			headers = {
				'Authorization': f'Bearer {self._state.channel.config.api.user_access_token}',
				'Content-Type': 'application/json'
			}
			response = requests.request('get', self.link_next_order, headers = headers).json()

		if response['result'] == 'success':
			order_main = response['data'].get('data')
			self.link_next_order = response['data'].get('paging', {}).get('next')
			self._state.pull.process.orders.imported += limit
			return Response().success(data = order_main)
		return Response().finish()


	def get_orders_ext_export(self, orders):
		extend = dict()
		for order in orders:
			order_id = to_str(order.id)
			extend[to_str(order_id)] = order
		return Response().success(extend)


	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_data = Order()
		order_data.id = order['id']
		order_data.status = self.ORDER_STATUS.get(order.get('order_status', {}).get('state')) or 'VOIDED'
		# order_data.tax = dict()
		order_data.tax.amount = order.get('estimated_payment_details', {}).get('tax')
		# order_data.discount = dict()
		order_data.shipping.title = order.get('selected_shipping_option', {}).get('name')
		order_data.shipping.amount = order.get('selected_shipping_option', {}).get('price')
		order_data.subtotal = order.get('estimated_payment_details', {}).get('subtotal')
		order_data.total = order.get('estimated_payment_details', {}).get('total_amount')
		order_data.currency = order.get('currency_amount', {}).get('currency')
		order_data.created_at = order.get('created')
		order_data.updated_at = order.get('last_updated')
		order_data.channel_data = {
			'order_status': order.get('order_status', {}).get('state'),
			'created_at': order_data.created_at
		}
		# order_data.customer = dict()
		order_data.customer.username = order.get('buyer_details', {}).get('name')
		order_data.customer.email = order.get('buyer_details', {}).get('email')
		# order_data.customer_address = dict()		# order_data.shipping_address = dict()
		order_data.shipping_address.first_name = order.get('shipping_address', {}).get('name')
		order_data.shipping_address.address_1 = order.get('shipping_address', {}).get('street1')
		order_data.shipping_address.address_2 = order.get('shipping_address', {}).get('street2')
		order_data.shipping_address.city = order.get('shipping_address', {}).get('city')
		order_data.shipping_address.postcode = order.get('shipping_address', {}).get('postal_code')
		order_data.shipping_address.state.state_name = order.get('shipping_address', {}).get('state')
		order_data.shipping_address.country.country_name = order.get('shipping_address', {}).get('country')
		order_data.shipping_address.country.country_code = order.get('shipping_address', {}).get('country')
		# order_data.billing_address = dict()
		order_data.billing_address = order_data.shipping_address
		# order_data.customer_address = dict()
		order_data.customer_address = order_data.shipping_address
		# order_data.payment = dict()
		# order_data.products = list()
		for item in order.items.data:
			product_data = OrderProducts()
			product_data.id = item.id
			product_data.product_id = item.get('product_id')
			product_data.product_sku = item.get('retailer_id')
			product_data.qty = item.get('quantity')
			order_data.products.append(product_data)

		# order_data.history = dict()
		order_data.channel = {'channel': order.channel}
		return Response().success(order_data)


	def channel_order_completed(self, order_id, order: Order, current_order):
		order_id = order_id if order_id else order.order_number
		page_id = self.get_page_id()
		api_prefix = f"/{page_id}/acknowledge_orders"
		data = {"idempotency_key": str(uuid.uuid1()), "orders": [{"id": order_id}]}
		res = self.api(api_prefix = api_prefix, method = 'post', data = data)
		if res['result'] != 'success':
			if res.get('code') == 1503:
				return Response().error(Errors.FACEBOOK_FAIL_API,
				                        msg = json.loads(res.get('msg')).get('error').get('message'))
			elif res.get('code') == 2201:
				return Response().error(Errors.EXCEPTION, msg = res.get('msg'))
		try:
			return_order = {"status": res['data'].get('data')[0].get('order_status').get('state')}
			return Response().success(return_order)
		except:
			return Response().success()


	# def get_order_by_id(self, order_id):
	# 	order = self.
	#
	#
	# def get_product_by_id(self, product_id):
	# 	product = self._get_product_variants(product_group_id = product_id)
	# 	if not product:
	# 		return Response().error(Errors.FACEBOOK_FAIL_API, msg = 'failed get product variants')
	# 	return Response().success(data = product)

	def unset_data(self, channel_data, unset = (
			'product_id', 'product_sku', 'channel_id', 'status', 'templates', 'template_data', 'edit', 'code',
			'publish_status')):
		for field in unset:
			if field in channel_data:
				del channel_data[field]
		return channel_data


	def get_app_id(self, user_id = None):
		if self._state.channel.config.api.app_id:
			return self._state.channel.config.api.app_id
		default = get_config_ini('facebook', 'app_id')
		if not user_id:
			return default
		return get_config_ini('facebook', f"app_id_{user_id}", default = default)


	def get_app_secret(self, user_id = None):
		if self._state.channel.config.api.app_secret:
			return self._state.channel.config.api.app_secret
		default = get_config_ini('facebook', 'app_secret')
		if not user_id:
			return default
		return get_config_ini('facebook', f"app_secret_{user_id}", default = default)


	def get_api_version(self):
		if self._state.channel.config.api.api_version:
			return self._state.channel.config.api.api_version
		return get_config_ini('facebook', 'api_version')


	def get_app_access_token(self, user_id = None):
		if self._state.channel.config.api.app_access_token:
			return self._state.channel.config.api.app_access_token
		default = get_config_ini('facebook', 'app_access_token')
		if not user_id:
			return default
		return get_config_ini('facebook', f"app_access_token_{user_id}", default = default)


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()

		# Update product price, sku, inventory, barcode etc..
		response = None
		if not product.variants:
			data_update = {}
			if setting_price:
				special_price = product.special_price
				price = product.price
				if self.is_special_price(product):
					sale_price = special_price.price
				else:
					sale_price = price
				data_update['price'] = self.to_fb_price(sale_price),
			if setting_qty:
				data_update['inventory'] = to_int(product.qty)
			if self.is_setting_sync_sku():
				data_update['retailer_id'] = product.sku
			response = self.api(api_prefix = f'{product_id}', method = 'post', data = data_update)
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
		else:
			channel_id = self._state.channel.id
			for variant in product.variants:
				data_update = {}
				variant_id = variant.get('channel').get(f'channel_{channel_id}', {}).get('product_id')
				if variant_id:
					if setting_price:
						special_price = variant.special_price
						if self.is_special_price(variant):
							var_price = special_price.price
						else:
							var_price = variant.price
						data_update['price'] = self.to_fb_price(var_price)
					if setting_qty:
						data_update['inventory'] = to_int(variant.qty)
					if self.is_setting_sync_sku():
						data_update['retailer_id'] = variant.sku
					response = self.api(api_prefix = f'{variant_id}', method = 'post', data = data_update)
				else:
					continue
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
		return Response().success()


	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']
		if mass_action == 'delete':
			self.delete_product_import(product_id)
			self.product_deleted(product['_id'], product)
			return Response().success(product_id)
		if mass_action == 'active':
			data_post = {
				'visibility': 'published'
			}
		else:
			return Response().success(product_id)
		resp = self._update_product_fb(product_id, data_post)
		if resp['result'] != "success":
			return Response().error(code = Errors.FACEBOOK_FAIL_API,
			                        msg = json.loads(resp.get('msg')).get('error').get('message'))

		return Response().success(product_id)
	def channel_assign_shipping_template(self, product, template_data):
		shipping_weight_value = template_data.get('shipping_weight_value')
		if not isinstance(shipping_weight_value, dict):
			return product
		if shipping_weight_value:
			if shipping_weight_value.get('override'):
				value = shipping_weight_value['override']
			else:
				value = shipping_weight_value['mapping']
			new_value = self.assign_attribute_to_field(value, product)
			if to_decimal(new_value):
				product['channel'][f'channel_{self.get_channel_id()}']['weight'] = to_str(to_decimal(new_value, 4))
		return product

	def get_currency(self):

		if self._currency:
			return self._currency
		if self._state.channel.config.api.custom_currency:
			self._currency = self._state.channel.config.api.custom_currency
			return self._currency
		user_info = self.get_user_info()
		country = user_info.get('country')
		if not country:
			country = 'US'
		if country == "CH":
			return "CHF"
		if country == "CN":
			return "USD"
		from countryinfo import CountryInfo
		country_info = CountryInfo(country)
		# languages = country_info.languages()
		currency = country_info.currencies()
		# if isinstance(languages, list):
		# 	languages = languages[0]
		if isinstance(currency, list):
			currency = currency[0]
		self._currency = currency
		return self._currency

	def convert_to_facebook_product_sync(self, product: Product, parent: Product or None):
		name = product.name or (parent.name if parent else '')
		if parent:
			name = parent.name
			attribute_values = []
			for attribute in product.attributes:
				if not attribute.use_variant:
					continue
				attribute_values.append(attribute.attribute_value_name)
			if attribute_values:
				name = f"{name} - {'/'.join(attribute_values)}"
		name = name[:150]
		if not name:
			return Response().error(msg = 'product name is required')
		product_data = dict()
		parent = parent or product
		if self.is_setting_sync_description():
			product_data['description'] = product.description or parent.description
		if self.is_setting_sync_title():
			product_data['name'] = name
		return Response().success(product_data)

	def simple_product_sync(self, product_id, product: Product, parent: Product or None = None, products_ext = None):
		if not self.is_setting_sync_title() and not self.is_setting_sync_description():
			return Response().success()
		product_data = self.convert_to_facebook_product_sync(product, parent)
		if product_data.result != Response.SUCCESS:
			return product_data
		response = self.api(api_prefix = f"{product_id}", data = json.dumps(product_data), method = 'post')
		if self._last_status == 200 and response and response.data.success:
			return Response().success()
		msg = response.msg
		if to_str(msg).find('does not exist, cannot be loaded due to missing permissions, or does not support this operation') != -1 and to_str(msg).find(to_str(product_id)) != -1:
			response['msg'] = 'Your product on Facebook has been removed. Please delete the product on LitCommerce and recreate the product'
		return response

	def channel_sync_title(self, product_id, product, products_ext):
		if not self.is_setting_sync_title() and not self.is_setting_sync_description():
			return Response().success()
		if not product.variants:
			return self.simple_product_sync(product_id, product)
		product_errors = 0
		for variant in product.variants:
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
			if not channel_data or not channel_data.get('product_id'):
				import_variant = self.simple_product_import(variant, product, products_ext)
				if import_variant.result == Response.SUCCESS:
					self.insert_map_product(variant, variant['_id'], import_variant.data)
				else:
					product_errors += 1
				self.after_push_product(variant['_id'], import_variant, variant)
				continue
			variant_update = self.simple_product_sync(channel_data.get('product_id'), variant, product)
			self.after_update_product(variant['_id'], variant_update, variant)
			if variant_update.result != Response.SUCCESS:
				product_errors += 1
		if not product_errors:
			return Response().success()
		return Response().error(msg = 'You have {} variant{} update error'.format(product_errors, "s" if product_errors > 1 else ''))



class FacebookProductChannel(ConstructBase):
	def __init__(self, **kwargs):
		self.currency = ''
		self.start_date = ''
		self.expiration_date = ''
		self.shipping_weight_unit = ''
		self.shipping_weight_value = ''
		self.visibility = ''
		self.fb_product_category = ''
		self.commerce_tax_category = ''
		self.group_id = ''
		self.retailer_id = ''
		super().__init__(**kwargs)
