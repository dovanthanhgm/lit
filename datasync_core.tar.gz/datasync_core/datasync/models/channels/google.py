import copy
import time

import requests

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import *
from datasync.models.constructs.product import *
from datasync.models.constructs.state import EntityProcess
from datasync.models.modes.test import ModelModesTest


class ModelChannelsGoogle(ModelChannel):
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category']

	# Order status mapping
	ORDER_STATUS = {
		"canceled": Order.CANCELED,
		"delivered": Order.COMPLETED,
		"inProgress": Order.READY_TO_SHIP,
		"partiallyDelivered": Order.SHIPPING,
		"partiallyReturned": Order.OPEN,
		"partiallyShipped": Order.SHIPPING,
		"pendingShipment": Order.OPEN,
		"returned": Order.OPEN,
		"shipped": Order.COMPLETED
	}
	category_template = {
		'category': None,
		'brand': {
			'mapping': None,
			'override': '',
		},
		'specifics': []
	}
	category_specific_template = {
		'name': '',
		'mapping': '',
		'string': '',
	}
	_target: bool or dict

	def __init__(self):
		super().__init__()
		self._categories = dict()
		self._flag_finish_product = False
		self._product_next_link = False
		self._flag_finish_order = False
		self._order_next_link = False
		self._target = False
		self._convert_product = None
		self._model_local = None
	def get_api_info(self):
		"""
		Return info needed for making an API call
		"""
		return {
			'access_token': 'Access Token',
			'refresh_token': 'Refresh Token',
			'merchant_id': 'Merchant ID',
		}


	def api_get_access_token(self, refresh_token, client_id, client_secret):
		"""
		Get a new Access Token using Refresh Token, ClientID & Client Secret
		"""
		endpoint = "https://oauth2.googleapis.com/token"
		headers = {'Content-Type': 'application/x-www-form-urlencoded'}
		data = {
			'client_id': client_id,  # '325932942319-q2d0iegbth42u5u71rr36cv6pr48em1o.apps.googleusercontent.com',
			'client_secret': client_secret,  # 'ZZzQ44FqU02C_Oz6ZB0owKFx',
			'refresh_token': refresh_token,  # '1//0efT5iLRsxwq1CgYIARAAGA4SNwF-L9IrUNbSvQUsWpjE-uFXp3IqqSPpR-8UBOcNgmXGU6TT6Oo7Nnv_ATku8oXnAQhi7Z8A8ew',
			'grant_type': 'refresh_token'
		}
		try:
			access_token = requests.post(url = endpoint, data = data, headers = headers).json().get('access_token')
			self._state.channel.config.api.access_token = access_token
			self.update_channel(api = json_encode(self._state.channel.config.api))
		except Exception:
			access_token = False
		return access_token


	def get_client_id(self):
		client_id = self._state.channel.config.api.client_id
		if not client_id:
			return get_config_ini('google', 'client_id')
		return client_id


	def get_client_secret(self):
		client_secret = self._state.channel.config.api.client_secret
		if not client_secret:
			return get_config_ini('google', 'client_secret')
		return client_secret


	# TODO: API code
	# BUG: FIX post api to insert product
	def requests(self, url, data, method = 'get', params = {}):
		method = method.lower()
		access_token = self._state.channel.config.api.access_token
		merchant_id = self._state.channel.config.api.merchant_id
		refresh_token = self._state.channel.config.api.refresh_token
		token_type = self._state.channel.config.api.token_type

		client_id = self.get_client_id()
		client_secret = self.get_client_secret()
		update_access_token = False

		if not merchant_id:
			return Response().error(Errors.GOOGLE_API_INVALID, msg = 'not merchant_id')
		if not access_token:
			return Response().error(Errors.GOOGLE_API_INVALID, msg = 'not access_token')
		if not refresh_token:
			return Response().error(Errors.GOOGLE_API_INVALID, msg = 'not refresh_token')

		headers = {
			"Content-Type": "application/json",
			"Authorization": f"{token_type} {access_token}"
		}
		request_options = {
			'headers': headers,
			'verify': True
		}
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put', 'patch'] and data:
			request_options['json'] = data
		if params:
			if not request_options.get('params'):
				request_options['params'] = params
			else:
				request_options['params'].update(params)
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code
			if response.status_code in [201, 204]:
				return Response().success()
			if response.status_code > 204 or self.is_log():
				self.log_request_error(url, data = data, response = response.text, method = method, status_code = response.status_code)


			if response.status_code == 401:
				access_token = self.api_get_access_token(refresh_token, client_id, client_secret)
				if not access_token:
					self.set_action_stop(True)
					return response_data
				request_options['headers']['Authorization'] = f"{token_type} {access_token}"
				response = requests.request(method, url, **request_options)
				self._last_status = response.status_code
				self._last_header = response.headers
				if response.status_code > 204:
					self.log_request_error(url, data = data, response = response.text, method = method)
			response_data = json_decode(response.text)
			if response_data:
				response_data = Prodict.from_dict(response_data)
			return response_data
		except Exception:
			self.log_traceback()
			return False


	def api(self, path, method = 'get', data = {}, id_required = False, params = {}):
		"""
		Make an API call

		Args:
			path: API endpoint (merchantID isn't included)
			data: dict contains info for post method
			id_required: API requires merchantID or not
			method: API method

		Returns:
			res: response of the api call
		"""
		merchant_id = self._state.channel.config.api.merchant_id

		if not merchant_id:
			return Response().error(Errors.GOOGLE_API_INVALID, msg = 'not merchant_id')

		if id_required:
			endpoint = f'https://www.googleapis.com/content/v2.1/{merchant_id}/{path}'
		else:
			endpoint = f'https://www.googleapis.com/content/v2.1/{path}'

		return self.requests(endpoint, data, method, params)


	def display_setup_channel(self, data = None):
		"""
		Check api information
		:param data:
		:return: _response

		"""
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		self._state.channel.support.taxes = False
		self._state.channel.support.categories = False
		# order = self.get_product_by_id('online:en:GB:MJ3552')
		# order_ext = self.get_products_ext_export([order['data']])
		# convert = self._convert_product_export(order['data'], order_ext['data'])
		# Test API call
		product_response = self.api(path = 'products', method = 'get', id_required = True, data = {"maxResults": 1})
		if product_response and product_response.error:
			if product_response.code == 400:
				return Response().error(Errors.GOOGLE_MERCHANT_ID_INVALID)

			if (product_response.message and 'User cannot access account' in product_response.message) or (product_response.error.errors and product_response.error.errors[0].reason == 'auth/account_access_denied'):
				return Response().error(Errors.GOOGLE_MERCHANT_ID_INVALID)
			return Response().error(Errors.GOOGLE_API_INVALID)

		res = self.api(path = 'accounts/authinfo', id_required = False)
		if self._last_status != 200:
			return Response().error(Errors.GOOGLE_API_INVALID)
		return Response().success()


	def get_target(self, category_template):
		if self._target:
			return self._target
		if category_template and category_template.get("target_country"):
			country = category_template.get("target_country")
		else:
			user_info = self.get_user_info()
			country = user_info.get('country')
		if not country:
			country = 'US'
		from countryinfo import CountryInfo
		country_info = CountryInfo(country)
		languages = country_info.languages()
		currency = country_info.currencies()
		if isinstance(languages, list):
			languages = languages[0]
		if isinstance(currency, list):
			currency = currency[0]
		if country in ['IE', 'ZA', 'Latvia', 'LV', 'BD']:
			languages = 'en'
		if country in ['CH']:
			currency = 'CHF'
		self._target = {
			'country': country_info.iso(2),
			'language': languages,
			'currency': currency,
		}
		return self._target

	def set_channel_identifier(self):
		"""
		in api info there will be 1 information that is unique to a channel.

		:return:
		"""
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self._state.channel.config.api.merchant_id)
		return Response().success()
	def get_product_table_name(self):
		return f'products_{self.get_sync_id()}'
	def products_table_construct(self):
		table_construct = {
			'table': self.get_product_table_name(),
			'rows': {
				'id': 'int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT',
				'user_id': 'int(11)',
				'solved': 'tinyint NOT NULL DEFAULT 0',
				'parent_id': 'text',
				'product_id': 'text',
				'product': 'longtext',

			}
		}
		return table_construct

	def display_pull_channel(self):
		"""
		Count all entity in channel
		"""
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		# Count Products
		if self.is_product_process():
			if self._state.pull.process.products.finished:
				self._state.pull.process.products = EntityProcess()
				self._state.pull.process.products.finished = False
			self.get_model_local().query_raw("DROP TABLE IF EXISTS `{}`".format(self.get_product_table_name()))
			products_table_construct = self.products_table_construct()
			query = self.get_model_local().dict_to_create_table_sql(products_table_construct)
			if query['result'] == 'success':
				self.get_model_local().query_raw(query['query'])
			next_page_token = ''
			params = {"maxResults": 250}
			while True:
				if next_page_token:
					params['pageToken'] = next_page_token
				product_response = self.api(path = 'products', method = 'get', id_required = True, data = params)
				if not product_response or not product_response.resources:
					break
				products = []
				for product in product_response.resources:
					products.append({
						'user_id': self._user_id,
						'parent_id': product.itemGroupId,
						'product_id': product.id,
						'product': json_encode(product),

					})
				self.get_model_local().insert_multiple_obj(self.get_product_table_name(), products)
				next_page_token = product_response.nextPageToken
				if not next_page_token:
					break
			query = f'SELECT count(1) as count FROM `{self.get_product_table_name()}` WHERE solved != 1'
			products = self.get_model_local().select_raw(query)
			if products.result == Response.SUCCESS:
				self._state.pull.process.products.total = products.data[0]['count']
		# Count Orders
		if self.is_order_process():
			self._state.pull.process.orders = EntityProcess()
			start_time = self.get_order_start_time("iso")
			# if id_src:
			# 	start_date = datetime.fromtimestamp(to_int(id_src.split('-')[-1])).strftime('%Y-%m-%d')
			params = {
				"maxResults": 1,
				"orderBy": "placedDateAsc",
			}
			if start_time:
				params['placedDateStart'] = start_time
			order_response = self.api(path = f'orders', method = 'get', id_required = True, data = params)
			if order_response and order_response.resources:
				self._state.pull.process.orders.total = -1
		return Response().success()

	def get_model_local(self):
		if self._model_local:
			return self._model_local
		self._model_local = ModelModesTest()
		self._model_local.set_user_id(self._user_id)
		return self._model_local
	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		return next_clear


	def get_products_main_export(self):
		"""
		data: list of products, each is saved as a dict
		:rtype: object
		"""
		# if self._flag_finish_product:
		# 	return Response().finish()
		# params = {
		# 	"maxResults": 10
		# }
		# if self._state.pull.process.products.next_token:
		# 	params['pageToken'] = self._state.pull.process.products.next_token
		# product_response = self.api(path = "products", method = 'get', id_required = True, data = params)
		# if not product_response or not product_response.resources:
		# 	return Response().finish()
		# if not product_response.nextPageToken:
		# 	self._flag_finish_product = True
		# else:
		# 	self._product_next_link = product_response.nextPageToken
		id_src = self._product_id
		if not id_src:
			id_src = ''
		query = f'SELECT * FROM `{self.get_product_table_name()}` WHERE solved != 1 AND `id` > "{id_src}" ORDER BY `id` LIMIT 100'
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS or not products.data:
			return Response().finish()
		self._product_id = products.data[-1]['id']
		response = []
		for product in products.data:
			product_data = json_decode(product['product'])
			product_data['db_id'] = product['id']
			response.append(product_data)
		return Response().success(data = response)


	def set_imported_product(self, imported):
		super(ModelChannelsGoogle, self).set_imported_product(imported)
		if self._product_next_link:
			self._state.pull.process.products.next_token = self._product_next_link


	def get_product_by_id(self, product_id):
		product = self.api(path = f"products/{product_id}", method = 'get', id_required = True)
		if self._last_status != 200:
			msg = Errors.GOOGLE_API_INVALID
			if product and product.error and product.error.message:
				msg = product.error.message
			return Response().error(msg = msg)
		return Response().success(data = product)


	def get_products_ext_export(self, products):
		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		self._convert_product = None
		convert_product = self._convert_product_export(product, products_ext)
		if convert_product.result == Response.SUCCESS:
			self._convert_product = convert_product.data
			return self._convert_product.id
		group_id = product.get('itemGroupId')
		if group_id:
			parent_id = self.get_product_warehouse_map(group_id)
			if parent_id:
				return product.id
			else:
				return group_id
		else:
			return product.id


	def _convert_variant(self, product, group_id, is_variant = False):
		product = Prodict.from_dict(product)
		product_data = Product() if not is_variant else ProductVariant()
		product_data.id = product.id
		product_data.code = product_data.sku = to_str(product.offerId)
		product_data.name = product.title or ''
		product_data.seo_url = product.link or ''
		product_data.description = product.description or ''
		# Product Images
		atr_images = get_row_value_from_list_by_field(product.customAttributes, 'name', 'image', 'value')
		product_data.thumb_image.url = product.imageLink or atr_images or ''
		for image in product.get('additionalImageLinks', []):
			product_data.images.append(ProductImage(url = image))
		if not product_data.thumb_image.url and product_data.images:
			product_data.thumb_image.url = product_data.images[0].url
		# Product Price, Sale Price
		product_data.price = product.price.value if product.price else 0
		product_data.special_price.price = product.salePrice.value if product.salePrice else 0
		product_data.brand = product.brand or ''
		product_data.manufacturer.name = product.brand or ''
		gtin = product.gtin or ''
		if gtin and to_len(gtin) < 12:
			gtin = (12 - to_len(gtin)) * '0' + gtin
		product_data.gtin = gtin
		product_data.mpn = product.mpn or ''
		product_data.condition = product.condition or product_data.CONDITION_NEW
		# Product status, quantity
		product_data.status = True if product.availability == 'in stock' else False
		product_data.qty = to_int(product.sellOnGoogleQuantity or 0)
		product_data.is_in_stock = True if product.availability == 'in stock' and product_data.qty else False
		# Product Color attribute
		variant_attribute = ['color', 'gender', 'material', 'pattern', 'aceGroup']
		for attribute in variant_attribute:
			if product.get(attribute):
				attr = ProductAttribute(attribute_code = attribute.lower(), attribute_name = attribute.capitalize(),
				                        attribute_value_name = product.get(attribute))
				if is_variant:
					attr.use_variant = True
				product_data.attributes.append(attr)
		# Product Sizes attribute
		if product.get('sizes'):
			size = product['sizes'][0]
			attr = ProductAttribute(attribute_code = 'size', attribute_name = 'Size',
			                        attribute_value_name = size)
			if is_variant:
				attr.use_variant = True
			product_data.attributes.append(attr)

		# Product Gender attribute
		# Product Custom attribute
		for custom_attr in product.get('customAttributes', []):
			attr = ProductAttribute(attribute_code = custom_attr.name, attribute_name = custom_attr.name,
			                        attribute_value_code = custom_attr.value, attribute_value_name = custom_attr.value)
			product_data.attributes.append(attr)
		# Product Detail attribute
		for detail in product.get('productDetails', []):
			attr = ProductAttribute(attribute_code = detail.attributeName, attribute_name = detail.attributeName,
			                        attribute_value_code = detail.attributeValue, attribute_value_name = detail.attributeValue)
			product_data.attributes.append(attr)
		# Product Category
		product_data.tags = '; '.join(product.productTypes) if product.productTypes else ''
		# Product Dimensions
		product_data.weight = product.shippingWeight.value if product.shippingWeight else 0
		product_data.height = product.shippingHeight.value if product.shippingHeight else 0
		product_data.length = product.shippingLength.value if product.shippingLength else 0
		product_data.width = product.shippingWidth.value if product.shippingWidth else 0
		# Product Category template
		category_template_data = Prodict.from_dict(self.category_template.copy())
		category_path = None
		if product.googleProductCategory:
			category_template_data.category = {
				"id": product.googleProductCategory,
				"name": ""
			}
			category_path = self.get_category_path(channel_type = 'facebook', type_search = 'google_product_category', params = {"category_id": product.googleProductCategory})
			if category_path and category_path.get('data'):
				category_path = category_path['data'][0]
				category_template_data.category['name'] = category_path['path']
		if product.brand:
			category_template_data.brand['value'] = product.brand
		specific_keys = ['condition', 'adult', 'multipack', 'isBundle', 'energyEfficiencyClass',
		                 'minEnergyEfficiencyClass', 'maxEnergyEfficiencyClass', 'ageGroup', 'material',
		                 'color', 'gender', 'pattern', 'sizes', 'sizeType', 'sizeSystem']
		for specific_key in specific_keys:
			specific_value = product.get(specific_key)
			if isinstance(specific_value, bool):
				specific_value = 'yes' if specific_value else 'no'
			if not specific_value:
				continue
			if isinstance(specific_value, list):
				specific_value = specific_value[0]
			specific_data = Prodict.from_dict(self.category_specific_template.copy())
			specific_data.name = specific_key
			specific_data.override = specific_value
			category_template_data.specifics.append(specific_data)
		identifiers = self.identifier_fields()
		for specific_key in identifiers:
			specific_value = product.get(specific_key)
			if isinstance(specific_value, list):
				specific_value = specific_value[0]
			product_data[specific_key] = specific_value
		product_data.template_data['category'] = category_template_data
		product_data.channel_data = {
			"group_id": group_id,
			"path": category_path.get('path') if category_path else None
		}
		return product_data


	def _convert_product_export(self, product, products_ext: Prodict):
		product = Prodict.from_dict(product)
		if self._convert_product:
			product_data = copy.deepcopy(self._convert_product)
			self._convert_product = None
			return Response().success(product_data)
		# Product Color attribute
		solved_ids = list()
		if product.get('db_id'):
			solved_ids.append(product['db_id'])
		group_id = product.get('itemGroupId')
		has_variant = False
		variants = []
		if group_id:
			variant_query = f'SELECT * FROM `{self.get_product_table_name()}` WHERE parent_id = "{group_id}"'
			variants_response = self.get_model_local().select_raw(variant_query)
			if variants_response.data and to_len(variants_response.data) > 1:
				has_variant = True
				for variant in variants_response.data:
					solved_ids.append(variant['id'])
					variants.append(json_decode(variant['product']))
		if not has_variant:
			product_data = self._convert_variant(product, group_id)
			if product_data.qty <= 0:
				product_data.channel_data.gg_status = 'sold_out'

			return Response().success(product_data)
		# Convert parent product
		product_data = self._convert_variant(product, group_id)
		parent = Product()
		parent.id = to_str(group_id)
		parent.sku = to_str(group_id)
		parent.name = product_data.name
		parent.thumb_image = product_data.thumb_image
		parent.images = product_data.images
		parent.template_data = product_data.template_data
		parent.description = product_data.description
		parent.qty = product_data.qty
		qty = 0
		for variant in variants:
			variant_data = self._convert_variant(variant, group_id, True)
			qty += variant_data.qty
			parent.qty = qty
			parent.variants.append(variant_data)
		if qty <= 0:
			parent.channel_data.gg_status = 'sold_out'
		self.update_to_solved(solved_ids)
		return Response().success(parent)

	def update_to_solved(self, solved_ids):
		if solved_ids:
			query = f"UPDATE {self.get_product_table_name()} SET solved = 1 where id in {self.get_model_local().list_to_in_condition(solved_ids)}"
			self.get_model_local().query_raw(query)

	def after_product_pull(self, product_id, convert: Product, product, products_ext):
		group_id = product.get('itemGroupId')
		parent_id = None
		if group_id:
			parent_id = self.get_product_warehouse_map(group_id)
		if parent_id:
			self.get_model_catalog().update_parent_product_inventories(parent_id)
		return Response().success()


	def product_import(self, convert: Product, product, products_ext):
		product = self.mapping_category_template(product)
		if not product.variants:
			return self.simple_product_import(product, None, products_ext)
		product_errors = 0
		for variant in product.variants:
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
			if channel_data and channel_data.get('product_id'):
				continue
			variant_import = self.simple_product_import(variant, product, products_ext)
			self.after_push_product(variant['_id'], variant_import, variant)
			if variant_import.result == Response.SUCCESS:
				self.insert_map_product(variant, variant['_id'], variant_import.data)
			else:
				product_errors += 1
		if not product_errors:
			return Response().success(product['_id'])
		return Response().error(msg = 'You have {} variant{} import error'.format(product_errors, "s" if product_errors > 1 else ''))


	def product_channel_update(self, product_id, product: Product, products_ext):
		product = self.mapping_category_template(product)
		if not product.variants:
			return self.simple_product_update(product_id, product, None, products_ext)
		product_errors = 0
		for variant in product.variants:
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']

			if not channel_data or not channel_data.get('product_id'):
				import_variant = self.simple_product_import(variant, product, products_ext)
				if import_variant.result == Response.SUCCESS:
					self.insert_map_product(variant, variant['_id'], import_variant.data)
				else:
					product_errors += 1
				self.after_push_product(variant['_id'], import_variant, variant)
				continue
			variant_update = self.simple_product_update(channel_data.get('product_id'), variant, product, products_ext)
			self.after_update_product(variant['_id'], variant_update, variant)
			if variant_update.result != Response.SUCCESS:
				product_errors += 1
		if not product_errors:
			return Response().success(product['_id'])
		return Response().error(msg = 'You have {} variant{} update error'.format(product_errors, "s" if product_errors > 1 else ''))


	def to_google_product_id(self, product_id):
		return to_str(product_id).replace('+', '%2B')


	def simple_product_update(self, product_id, product: Product, parent: Product or None = None, products_ext = None):
		# Prepare Data
		post_data = self.convert_to_google_product(product, parent, products_ext)
		if post_data.result != Response.SUCCESS:
			return post_data
		post_data = post_data.data
		if 'offerId' in post_data:
			del post_data['offerId']
		params = {'updateMask':','.join(list(post_data.keys()))}
		response = self.api(path = f'products/{self.to_google_product_id(product_id)}', method = 'PATCH', data = post_data, id_required = True, params = params)
		if response and response.id:
			return Response().success(response.id)
		if (response and response.error and response.error.code == 404) or self._last_status == 404:
			product_import = self.simple_product_import(product, parent, products_ext)
			if product_import.result != Response.SUCCESS:
				return product_import
			product_import_id = product_import.data
			self.update_map_product(product, product['_id'], product_import_id)
			return Response().success(product_import_id)
		msg = response.error.message or Errors.GOOGLE_API_INVALID
		return Response().error(msg = msg)


	def simple_product_import(self, product: Product, parent: Product or None, products_ext):
		# Prepare Data
		post_data = self.convert_to_google_product(product, parent, products_ext, insert = True)
		if post_data.result != Response.SUCCESS:
			return post_data
		post_data = post_data.data
		response = self.api(path = 'products', method = 'post', data = post_data, id_required = True)
		if response and response.id:
			return Response().success(response.id)
		msg = response.error.message or Errors.GOOGLE_API_INVALID
		return Response().error(msg = msg)


	def simple_sync_title(self, product_id, product: Product, parent: Product or None, products_ext):
		try:
			post_data = {}
			if self.is_setting_sync_title():
				name = product.name or (parent.name if parent else '')
				if name:
					if parent:
						attribute_values = []
						for attribute in product.attributes:
							if not attribute.use_variant:
								continue
							attribute_values.append(attribute.attribute_value_name)
						if attribute_values:
							name = f"{name} - {'/'.join(attribute_values)}"

					post_data['title'] = name[:150]

				link = product.seo_url or (parent.seo_url if parent else '')
				if link:
					post_data['link'] = link

			if self.is_setting_sync_description():
				description = product.description or (parent.description if parent else '')
				if description:
					post_data['description'] = self.strip_html_from_description(description)[:5000]

			update_mask = list(post_data.keys())
			if not update_mask:
				# empty data need updating
				return Response().success()

			params = {'updateMask':','.join(update_mask)}

			response = self.api(path = f'products/{product_id}', method = 'PATCH', data = post_data, id_required = True, params = params)
			if self._last_status < 300:
				return Response().success()

			msg = response.error.message if response and response.error else 'Exception'
			return Response().error(msg = msg)

		except Exception as e:
			self.log_traceback(type_error = 'simple_sync_title_except', msg = str(e))
			return  Response().error(msg = 'Exception')

	def simple_sync_inventory(self, product_id, product: Product, parent: Product or None, products_ext, is_variant = False):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		price = product.price
		qty = to_int(product.qty)
		availability = 'in stock' if qty > 0 else 'out of stock'
		post_data = dict()
		category_template = product.template_data.category

		target = self.get_target(category_template)
		# params = {}
		delete_sale_price = False
		if setting_price:
			# params = {'updateMask': 'salePriceEffectiveDate,salePrice'}
			post_data['price'] = {
				'value': price,
				'currency': target['currency'],
			}
			if self.is_special_price(product):
				special_price = product.special_price
				post_data['salePrice'] = {
					'value': special_price.price,
					'currency': target['currency'],
				}
				if to_timestamp_or_false(special_price.start_date) and to_timestamp_or_false(special_price.end_date) and to_timestamp_or_false(special_price.end_date) > to_timestamp_or_false(special_price.start_date):
					post_data['salePriceEffectiveDate'] = convert_format_time(special_price.start_date, new_format = '%Y-%m-%dT%H:%M:%S') + '/' + convert_format_time(special_price.end_date, new_format = '%Y-%m-%dT%H:%M:%S')
			else:
				delete_sale_price = True
		if setting_qty:
			post_data['availability'] = availability
			post_data['sellOnGoogleQuantity'] = qty
		update_mask = list(post_data.keys())
		if delete_sale_price:
			update_mask.extend(['salePrice', 'salePriceEffectiveDate'])
		params = {'updateMask':','.join(update_mask)}

		response = self.api(path = f'products/{product_id}', method = 'PATCH', data = post_data, id_required = True, params = params)
		if self._last_status < 300:
			if not is_variant:
				channel_data = product.channel[f'channel_{self.get_channel_id()}']
				if product.qty <= 0 and channel_data.get('gg_status') != 'sold_out':
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.gg_status', 'sold_out')

				if product.qty > 0 and channel_data.get('gg_status') != 'active':
					self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.gg_status', 'active')
			return Response().success()
		msg = response.error.message if response and response.error else 'Exception'
		return Response().error(msg = msg)


	def mapping_category_template(self, product):
		if not product.variants:
			return product
		channel_data = product.channel[f'channel_{self.get_channel_id()}']
		parent_template = channel_data.template_data.category if channel_data.template_data else {}
		if not parent_template:
			return product
		field_check = ['brand','expirationDate','target_country','category']
		for variant in product.variants:
			variant_channel_data = variant.channel[f'channel_{self.get_channel_id()}']

			variant_template = (variant_channel_data.template_data.category if variant_channel_data.template_data else {}) or {}
			for field in field_check:
				if not variant_template.get(field) and parent_template.get(field):
					variant_template[field] = parent_template[field]
			specifics = []
			if not variant_template.get('specifics'):
				variant_template['specifics'] = list()
			variant_specifics = []
			if variant_template.get('specifics'):
				for specific in variant_template['specifics']:
					if specific.get('value'):
						specifics.append(specific.name)
						variant_specifics.append(specific)
			for specific in parent_template['specifics']:
				if specific.get('value') and specific.name not in specifics:
					variant_specifics.append(specific)
			variant_template['specifics'] = variant_specifics

			# variant_template['shipping_details'] = p
			variant['template_data']['category'] = variant_template
			if not variant['channel'][f'channel_{self.get_channel_id()}'].get('template_data'):
				variant['channel'][f'channel_{self.get_channel_id()}']['template_data'] = {}
			variant['channel'][f'channel_{self.get_channel_id()}']['template_data']['category'] = variant_template
		return product


	def convert_to_google_product(self, product: Product, parent: Product or None, products_ext, insert = False):
		category_template = product.template_data.category or (parent.template_data.category if parent and parent.template_data else '') or Prodict()
		if not category_template:
			return Response().error(msg = 'GOOGLE_CATEGORY_TEMPLATE_NOT_FOUND')
		category_template = Prodict.from_dict(category_template)
		shipping_template = product.template_data.shipping or (parent.template_data.shipping if parent and parent.template_data else '') or Prodict()
		img_link = ''
		if product.thumb_image.url:
			img_link = product.thumb_image.url
		elif product.images:
			img_link = product.images[0].url
		if not img_link and parent:
			if parent.thumb_image.url:
				img_link = parent.thumb_image.url
			elif parent.images:
				img_link = parent.images[0].url
		product_id = product.sku
		name = product.name or (parent.name if parent else '')
		description = product.description or (parent.description if parent else '')
		link = product.seo_url or (parent.seo_url if parent else '')
		price = product.price
		special_price = product.special_price
		# status = product_channel.status if product_channel.status is not None else product.status
		# status = True if status is True or status == 'active' else False
		qty = product.qty
		availability = 'in stock' if product.is_in_stock else 'out of stock'

		# Check necessary field
		if not product_id:
			return Response().error(Errors.GOOGLE_SKU_EMPTY)
		if to_len(product_id) > 50:
			product_id = to_str(to_int(time.time() * 10000000))
		target = self.get_target(category_template)
		post_data = {
			# 'kind': "content#prodfuct",
			'offerId': product_id,
			'price': {
				'value': price,
				'currency': target['currency'],
			},
			'availability': availability,
			'sellOnGoogleQuantity': qty,
		}
		if category_template and category_template.expirationDate:
			post_data['expirationDate'] = category_template.expirationDate
		if insert:
			post_data['targetCountry'] = target['country']
			post_data['channel'] = 'online'
			post_data['contentLanguage'] = target['language']
		if shipping_template and shipping_template.country and shipping_template.price:
			post_data['shipping'] = {
				"price": {
					"currency": target['currency'],
					"value": shipping_template.price
				},
				'country': shipping_template.country
			}
			map_field = {
				'min_handling_time': "minHandlingTime",
				'max_handling_time': "maxHandlingTime",
				'min_transit_time': "minTransitTime",
				'max_transit_time': "maxTransitTime",
			}
			for field, gg_field in map_field.items():
				if shipping_template.get(field):
					post_data['shipping'][gg_field] = shipping_template[field]
			if shipping_template.delivery_area.value:
				if shipping_template.delivery_area.target == 'region':
					post_data['shipping']['region'] = shipping_template.delivery_area.value
				else:
					post_data['shipping']['postalCode'] = shipping_template.delivery_area.value
			else:
				post_data['shipping']['region'] = ''
				post_data['shipping']['postalCode'] = ''
		if name:
			if parent:
				attribute_values = []
				for attribute in product.attributes:
					if not attribute.use_variant:
						continue
					attribute_values.append(attribute.attribute_value_name)
				if attribute_values:
					name = f"{name} - {'/'.join(attribute_values)}"
			post_data['title'] = name[:150]
		if description:
			post_data['description'] = self.strip_html_from_description(description)[:5000] if description else '',
		if link:
			post_data['link'] = link
		if img_link:
			post_data['imageLink'] = self.parse_url(img_link)

		if self.is_special_price(product):
			post_data['salePrice'] = {
				'value': special_price.price,
				'currency': target['currency'],
			}
			if to_timestamp_or_false(special_price.start_date) and to_timestamp_or_false(special_price.end_date) and to_timestamp_or_false(special_price.end_date) >to_timestamp_or_false(special_price.start_date):
				post_data['salePriceEffectiveDate'] = convert_format_time(special_price.start_date, new_format = '%Y-%m-%dT%H:%M:%S') + '/' + convert_format_time(special_price.end_date, new_format = '%Y-%m-%dT%H:%M:%S')

		if product.images:
			images = duplicate_field_value_from_list(product.images, 'url')
			images = list(map(lambda x: self.parse_url(x), images))
			post_data['additionalImageLinks'] = images[0:10]
		# Addition fields
		mapping_fields = {
			'mpn': 'mpn',
			# 'gtin': 'gtin',
			# 'condition': 'condition',
		}
		for post_key, product_key in mapping_fields.items():
			if product.get(product_key):
				post_data[post_key] = product.get(product_key)
		gtin = product.gtin or product.upc or product.ean or product.isbn
		if gtin:
			post_data['gtin'] = gtin
		# Product dimensions
		weight = product.weight or (parent.weight if parent else 0)
		weight_unit = product.weight_units
		if self._state.channel.config.api.weight_units:
			if self._state.channel.config.api.weight_units == 'kg':
				if weight_unit in ['g', 'gr', 'gram', 'grams']:
					weight = weight/1000
					weight_unit = 'kg'
		if weight:
			post_data['shippingWeight'] = {
				'value': to_decimal(weight, 4),
				'unit': weight_unit,
			}
		post_dimensions = {
			'shippingLength': product.length or (parent.length if parent else 0),
			'shippingWidth': product.width or (parent.width if parent else 0),
			'shippingHeight': product.height or (parent.height if parent else 0),
		}
		for key, value in post_dimensions.items():
			dimension = value
			unit = 'in'
			if product.dimension_units == 'cm':
				unit = 'cm'
			if product.dimension_units == 'm':
				dimension = value * 1000
				unit = 'cm'
			if product.dimension_units == 'mm':
				dimension = value / 10
				unit = 'cm'
			if value and to_int(value) > 0:
				post_data[key] = {
					'value': to_decimal(dimension, 4),
					'unit': unit
				}

		# Product category
		if product.categories:
			post_data['productTypes'] = duplicate_field_value_from_list(product.categories, 'name')

		# Product parent id (group_id):
		if parent:
			post_data['itemGroupId'] = parent['_id']

		# Assign specific aspects
		if category_template.category:
			post_data['googleProductCategory'] = category_template.category.id
		brand = category_template.brand.value
		specifics = category_template.get('specifics', [])

		if brand:
			post_data['brand'] = brand
		text_mapping = ''
		for specific in specifics:
			mapping = specific.override or specific.mapping
			if mapping:
				text_mapping += to_str(mapping)
			specific_value = specific.value
			if specific_value in ['yes', 'no']:
				specific_value = True if specific_value == 'yes' else False
			if specific.name == 'sizes':
				specific_value = [specific_value]
			if isinstance(specific_value, bool) or specific_value:
				post_data[specific.name] = specific_value
		if insert:
			attributes = []
			for attribute in product.attributes:
				if attribute.attribute_name.lower() in ['color', 'colour', 'colore', 'couleur']:
					post_data['color'] = attribute.attribute_value_name
					continue
				if attribute.attribute_name.lower() in ['size', 'taille', 'dimensione', 'dimension']:
					post_data['sizes'] = [attribute.attribute_value_name]
					continue
				if text_mapping and text_mapping.find("{{" + attribute.attribute_name + "}}"):
					continue
				attributes.append({
					'name': attribute.attribute_name,
					'value': attribute.attribute_value_name
				})
			if attributes:
				post_data['customAttributes'] = attributes
		return Response().success(post_data)


	def channel_sync_title(self, product_id, product, products_ext):
		if not self.is_setting_sync_title() and not self.is_setting_sync_description():
			return Response().success()

		if not product.variants:
			return self.simple_sync_title(product_id, product, None, products_ext)

		number_error = 0
		msg_error = ''
		same_error = True
		variant_no_error = []
		for variant in product.variants:
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
			if not channel_data or not channel_data.get('product_id'):
				continue

			variant_update = self.simple_sync_title(channel_data['product_id'], product, None, products_ext)
			if variant_update.result != Response.SUCCESS:
				if not msg_error:
					msg_error = variant_update.msg
				if variant_update.msg and variant_update.msg != msg_error:
					same_error = False
				number_error += 1
				update_data = {
					f'channel.channel_{self.get_channel_id()}.error_message': f"Error while syncing title: {variant_update.msg}",
					f'channel.channel_{self.get_channel_id()}.sync_error': True,

				}
				self.get_model_catalog().update(variant['_id'], update_data)
			else:
				variant_no_error.append(variant['_id'])

		if variant_no_error:
			update_data = {
				f'channel.channel_{self.get_channel_id()}.error_message': f"",
				f'channel.channel_{self.get_channel_id()}.sync_error': False,

			}
			self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', variant_no_error, 'in'), update_data)
		if not number_error:
			return Response().success()
		response_msg = msg_error if same_error else f"Have {number_error} sync error"
		return Response().error(msg = response_msg)


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		if not product.variants:
			return self.simple_sync_inventory(product_id, product, None, products_ext)
		number_error = 0
		msg_error = ''
		same_error = True
		variant_no_error = []
		qty = 0
		for variant in product.variants:
			qty += variant.qty
			channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
			if not channel_data or not channel_data.get('product_id'):
				continue
			variant_update = self.simple_sync_inventory(channel_data.get('product_id'), variant, product, products_ext, is_variant = True)
			if variant_update.result != Response.SUCCESS:
				if not msg_error:
					msg_error = variant_update.msg

				if variant_update.msg and variant_update.msg != msg_error:
					same_error = False
				number_error += 1
				update_data = {
					f'channel.channel_{self.get_channel_id()}.error_message': f"Error while syncing: {variant_update.msg}",
					f'channel.channel_{self.get_channel_id()}.sync_error': True,

				}
				self.get_model_catalog().update(variant['_id'], update_data)

			else:
				variant_no_error.append(variant['_id'])

		if variant_no_error:
			update_data = {
				f'channel.channel_{self.get_channel_id()}.error_message': f"",
				f'channel.channel_{self.get_channel_id()}.sync_error': False,

			}
			self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', variant_no_error, 'in'), update_data)

		if not number_error:
			channel_data = product.channel[f'channel_{self.get_channel_id()}']
			if qty <= 0 and channel_data.get('gg_status') != 'sold_out':
				self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.gg_status', 'sold_out')

			if qty > 0 and channel_data.get('gg_status') != 'active':
				self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.gg_status', 'active')

			return Response().success()

		response_msg = msg_error if same_error else f"Have {number_error} sync error"
		return Response().error(msg = response_msg)


	def get_orders_main_export(self):
		if self._flag_finish_order:
			return Response().finish()
		start_time = self.get_order_start_time('iso')
		params = {
			"maxResults": 100,
			"orderBy": "placedDateAsc",
		}
		if start_time:
			params['placedDateStart'] = start_time
		if self._state.pull.process.orders.next_token:
			params['pageToken'] = self._state.pull.process.orders.next_token
		order_response = self.api(path = f'orders', method = 'get', id_required = True, data = params)
		if not order_response or not order_response.resources:
			return Response().finish()
		if not order_response.nextPageToken:
			self._flag_finish_order = True
		else:
			self._order_next_link = order_response.nextPageToken
		return Response().success(data = order_response.resources)


	def set_imported_order(self, imported):
		super(ModelChannelsGoogle, self).set_imported_order(imported)
		if self._order_next_link:
			self._state.pull.process.orderes.next_token = self._order_next_link


	def get_orders_ext_export(self, orders):
		return Response().success()


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id + '-' + to_str(to_timestamp(order.placedDate, '%Y-%m-%d'))


	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_data = Order()
		order_data.id = order.id + '-' + to_str(to_timestamp(order.placedDate, '%Y-%m-%d'))
		order_data.order_number = order.id
		# Order Items
		for item in order.get('lineItems', []):
			product_data = OrderProducts()
			product_data.id = item.id
			product_data.product_id = item.product.id if item.product else ''
			product_data.product_sku = item.product.offerId if item.product else ''
			product_data.qty = item.quantityOrdered or 0
			product_data.price = item.price.value if item.price else 0
			product_data.tax_amount = item.tax.value if item.tax else 0
			product_data.subtotal = product_data.total = product_data.qty * product_data.price
			order_data.products.append(product_data)
		status = order.status
		order_data.status = self.ORDER_STATUS.get(status, Order.OPEN)
		order_data.created_at = convert_format_time(order.placedDate, old_format = '%Y-%m-%d')
		order_data.channel_data = {
			'order_status': order.status,
			'created_at': order_data.created_at
		}
		if order.deliveryDetails:
			order_data.shipping_address.telephone = order.deliveryDetails.phoneNumber or ''
			if order.deliveryDetails.address:
				order_data.shipping_address.last_name = order.deliveryDetails.address.recipientName or ''
				order_data.shipping_address.address_1 = order.deliveryDetails.address.streetAddress[0] if order.deliveryDetails.address.streetAddress else ''
				order_data.shipping_address.city = order.deliveryDetails.address.locality or ''
				order_data.shipping_address.state.state_name = order.deliveryDetails.address.region or ''
				order_data.shipping_address.state.state_code = order.deliveryDetails.address.region or ''
				order_data.shipping_address.country.country_name = order.deliveryDetails.address.country or ''
				order_data.shipping_address.country.country_code = order.deliveryDetails.address.country or ''
				order_data.shipping_address.postcode = order.deliveryDetails.address.postalCode or ''
		if order.billingAddress:
			order_data.billing_address.last_name = order.billingAddress.recipientName or ''
			order_data.billing_address.address_1 = order.billingAddress.streetAddress[0] if order.billingAddress.streetAddress else ''
			order_data.billing_address.city = order.billingAddress.locality or ''
			order_data.billing_address.state.state_name = order.billingAddress.region or ''
			order_data.billing_address.state.state_code = order.billingAddress.region or ''
			order_data.billing_address.country.country_name = order.billingAddress.country or ''
			order_data.billing_address.country.country_code = order.billingAddress.country or ''
			order_data.billing_address.postcode = order.billingAddress.postalCode or ''
		if order.customer:
			order_data.customer.last_name = order.customer.fullName or ''
			order_data.customer.email = order.customer.invoiceReceivingEmail or ''
		order_data.shipping.amount = order.shippingCost.value if order.shippingCost else 0
		order_data.subtotal = order.netPriceAmount.value if order.netPriceAmount else 0
		order_data.tax.amount = order.netTaxAmount.value if order.netTaxAmount else 0
		order_data.total = order_data.subtotal + order_data.tax.amount + order_data.shipping.amount
		return Response().success(data = order_data)


	def channel_order_completed(self, order_id, order: Order, current_order):
		order_id = order_id if order_id else order.order_number
		data_post = {
			# "operationId": "operation-4",
			# "shipmentId": "shipment-1",
			"id": order_id,
			"status": "delivered" if order.status == 'completed' else 'canceled'
		}
		res = self.api(path = f"orders/{order_id}/updateShipment", method = 'post', data = data_post, id_required = True)
		if res['result'] != "success":
			return Response().error(Errors.GOOGLE_API_INVALID, msg = res.get('msg'))
		return_order = {"status": data_post.get('status')}
		return Response().success(return_order)


	def delete_google_product(self, product_id):
		self.api(path = f'products/{product_id}', method = 'DELETE', id_required = True)

	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']
		if mass_action == 'active':
			data_post = {
				'availability': 'in stock'
			}
		elif mass_action == 'delete':
			if not product.variants:
				self.delete_google_product(product_id)
				self.product_deleted(product['_id'], product)
			else:
				for variant in product.variants:
					variant_id = variant['channel'][f'channel_{self.get_channel_id()}'].get('product_id')
					if variant_id:
						self.delete_google_product(variant_id)
					self.product_deleted(variant['_id'], variant)
		else:
			return Response().success(product_id)
		res = self.api(path = f'products/{product_id}', method = 'PATCH', data = data_post, id_required = True)
		if self._last_status > 300:
			if res and res.error and res.error.message:
				msg = res.error.message
			else:
				msg = Errors.GOOGLE_API_INVALID
			return Response().error(msg = msg)
		return Response().success(product_id)


	def channel_assign_category_template(self, product, template_data):
		brand = template_data['brand']
		if brand.override:
			brand_value = brand.override
		else:
			brand_value = brand.mapping
		if brand_value:
			brand.value = self.assign_attribute_to_field(brand_value, product)
		template_data.brand = brand
		item_specifics = template_data['specifics']
		for specific in item_specifics:
			if not specific.override and not specific.mapping:
				continue
			if specific.override:
				value = specific.override
			else:
				value = specific.mapping
			specific.value = self.assign_attribute_to_field(value, product)
		template_data.specifics = item_specifics
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['category'] = template_data
		return product


	def is_sku_to_gtin(self):
		return self._state.channel.config.api.sku_to_gtin


	def get_draft_extend_channel_data(self, product):
		description = product.description or product.short_description
		description = self.strip_html_from_description(description)[0:5000]
		title = product.name[0:150]
		extend = {}
		if not product.gtin:
			gtin = product.upc or product.ean or product.isbn
			if gtin:
				extend['gtin'] = gtin
		if product.description != description:
			extend['description'] = description
		if product.name != title:
			extend['name'] = title
		if self.is_sku_to_gtin() and not product.gtin:
			extend['gtin'] = product.sku
		if not product.sku:
			sku = random_string(16)
			extend['sku'] = sku
		return extend


	def display_push_channel(self, data = None):
		parent = super().display_push_channel(data)
		if parent.result != Response.SUCCESS:
			return parent
		if not self.is_inventory_process():
			return Response().success()
		today = datetime.today()
		day = today.day
		date_format = today.strftime("%Y-%m-%d")
		if day % 15 or (self._state.channel.config.reset_inventory_sync and self._state.channel.config.reset_inventory_sync == date_format):
			return Response().success()
		where = self.get_model_catalog().create_where_condition(f'channel.channel_{self.get_channel_id()}.link_status', "linked")
		where.update(self.get_model_catalog().create_where_condition('is_variant', False))
		id_src = ''
		while True:
			if id_src:
				where.update(self.get_model_catalog().create_where_condition('_id', id_src, '>'))
			products = self.get_model_catalog().find_all(where, limit = 200, select_fields = '_id', sort = '_id')
			if not products:
				break
			for product in products:
				self.get_model_catalog().update_field(product['_id'], 'updated_time', time.time())
				time.sleep(0.1)
				id_src = product['_id']
			if to_len(products) < 200:
				break
		self._state.channel.config.reset_inventory_sync = date_format
		self.get_model_state().update_field(self.get_state_id(), 'channel.config.reset_inventory_sync', date_format)
		return Response().success()
