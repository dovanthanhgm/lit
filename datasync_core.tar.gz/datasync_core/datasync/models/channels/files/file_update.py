from datasync.libs.prodict import Prodict
from datasync.libs.response import Response
from datasync.models.channels.file import ModelChannelsProductFile, CsvFile, CsvBulkEdit, CsvFromUrl



class ModelChannelsProductFileUpdate(ModelChannelsProductFile):

	def get_query_count_product(self):
		table = self.table_construct()
		query = f"SELECT COUNT(1) as count FROM `{table['table']}` WHERE `sku` IS NOT NULL AND `sku` > ''"
		return query


	def get_csv_method(self, method):
		return f"CsvUpdateFrom{method.capitalize()}"


	# TODO: Products
	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._id_src
		table = self.table_construct()
		query = f'SELECT * FROM `{table["table"]}` WHERE `sku` IS NOT NULL AND `sku` > "" AND id > "{id_src}" ORDER BY id LIMIT {limit_data}'
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS or not products.data:
			return Response().finish()
		self._id_src = products.data[-1]['id']
		return Response().success(data = products.data)


	def get_products_ext_export(self, products):
		product_ext = Prodict()
		product_ext['variants'] = []
		return Response().success(product_ext)
