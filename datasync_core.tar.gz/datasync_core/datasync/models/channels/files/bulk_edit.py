from datasync.libs.prodict import Prodict
from datasync.libs.response import Response
from datasync.models.channels.file import ModelChannelsProductFile, CsvFile, CsvBulkEditFromUrl, to_str
from datasync.models.constructs.product import Product, ProductVariant, ProductImage


class ProductBulkEdit(ModelChannelsProductFile):
	TABLE_NAME = 'products_bulk_edit'
	PARENT_FIELD = 'parent_id'
	CHILD_FIELD = 'product_id'


	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self._url = ''


	def get_model_csv(self) -> CsvFile:
		csv_object = CsvBulkEditFromUrl(url = self._request_data['file_url'])
		return csv_object


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response.SUCCESS:
			return parent
		self._url = data['url']
		csv_object = self.get_model_csv()
		validate = csv_object.validate_file()
		if validate.result != Response.SUCCESS:
			return validate

		return Response().success()


	def get_csv_title(self):
		return self.construct_products_csv_bulk_edit()


	def table_construct(self):
		table_product = super().table_construct()
		table_product['rows'].update({
			'id': "int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT",
			'product_id': "varchar(25) NULL",
			'parent_id': "varchar(25) NULL",
			'sku': "varchar(255)",
			'parent_sku': "varchar(25) NULL",
			'name': "varchar(255) NULL",
			'qty': "text",
			'description': "text NULL",
			'brand': "varchar(255) NULL",
			'price': "text",
			# 'mpn': "varchar(255) NULL",
			# 'upc': "varchar(255) NULL",
			# 'ean': "varchar(255) NULL",
			# 'isbn': "varchar(255) NULL",
			# 'gtin': "varchar(255) NULL",
			# 'gcid': "varchar(255) NULL",
			# 'asin': "varchar(255) NULL",
			# 'epid': "varchar(255) NULL",
			'height': "text",
			'length': "text",
			'width': "text",
			'dimension_units': "text",
			'weight': "text",
			'weight_units': "text",
		})
		# for i in range(1, 6):
		# 	table_product['rows']['variation_' + to_str(i)] = "varchar(255) NULL"
		for i in range(1, 11):
			table_product['rows']['product_image_' + to_str(i)] = "text NULL"
		return table_product


	def get_query_count_product(self):
		table = self.table_construct()
		query = f"SELECT COUNT(1) as count FROM `{table['table']}` WHERE (parent_sku IS NULL OR parent_sku = '' or parent_sku = 'False')"
		return query


	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._state.pull.process.products.id_src
		table = self.table_construct()
		query = f'SELECT * FROM `{table["table"]}` WHERE (parent_sku is null or parent_sku = "" or parent_sku = "False") AND `product_id` > "{id_src}" ORDER BY product_id LIMIT {limit_data}'
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS or not products.data:
			return Response().finish()
		products_data = products.data
		for product in products_data:
			product['litc_id'] = product['product_id']
		return Response().success(data = products_data)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product['product_id']


	def _convert_product_export(self, product, products_ext: Prodict):
		product_id = product.product_id
		current_product = self.get_model_catalog().get(product_id)
		if not current_product or not current_product.channel.get(f'channel_{self.get_channel_default_id()}') or not current_product.channel[f'channel_{self.get_channel_default_id()}'].get('product_id'):
			return Response().skip()
		return super(ProductBulkEdit, self)._convert_product_export(product, products_ext)


	def _convert_product(self, product: Product, parent = None):
		if parent:
			product_data = ProductVariant()
		else:
			product_data = Product()
		equal_fields = ('sku', 'name', 'qty', 'description', 'condition', 'condition_note', 'price', 'seo_url', 'msrp', 'upc', 'ean', 'isbn', 'gtin', 'gcid', 'asin', 'epid', 'height', 'length', 'width', 'weight')
		for field in equal_fields:
			if field in product_data:
				product_data[field] = product[field]
		product_data.dimension_units = product.dimension_units if product.dimension_units in ['in', 'm', 'cm', 'ft', 'mm'] else 'in'
		product_data.dimension_units = product.weight_units if product.weight_units in ['oz', 'lb', 'g', 'kg'] else 'oz'
		product_id = self.get_product_id_import(product, product, None)
		product_data.id = product_id
		product_data.allow_update = self.get_fields_allow_update()

		for i in range(1, 11):
			field = 'product_image_{}'.format(to_str(i))
			if not product.get(field):
				continue
			if not product_data.thumb_image.url:
				product_data.thumb_image.url = product[field]
			else:
				product_image = ProductImage()
				product_image.url = product[field]
				product_image.position = i
				product_data.images.append(product_image)
		return product_data