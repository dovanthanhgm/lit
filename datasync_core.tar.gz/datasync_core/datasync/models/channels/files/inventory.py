from datasync.libs.response import Response
from datasync.libs.utils import duplicate_field_value_from_list
from datasync.models.channels.file import BaseModelChannelsFile, to_int
from datasync.models.constructs.product import Product
from datasync.models.constructs.state import EntityProcess


class ModelChannelsInventoryFile(BaseModelChannelsFile):
	TABLE_NAME = 'inventory'
	_location_id = 0
	_import_type = 'override'


	def table_construct(self):
		table_inventory = super().table_construct()
		table_inventory['rows'].update({
			'id': "varchar(25) NULL",
			'sku': "varchar(255)",
			'parent_id': "varchar(25) NULL",
			'available': "int(10) NOT NULL",
			'on_hand': "int(10) NOT NULL",
			'reserved': "int(10) NOT NULL",
			'location_id': "int(10)",
			'import_type': "varchar(25)",
			'row_id': "int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT",
		})
		return table_inventory


	def set_data_context(self, data = {}):
		self._location_id = data.get('location_id', 0)
		self._import_type = data.get('import_type', 'override')


	def read_csv_from_url(self, csv_url, delimiter = ','):
		csv_data = super().read_csv_from_url(csv_url, delimiter)
		if isinstance(csv_data, dict):
			for row_data in csv_data.values():
				for field in ('available', 'reserved', 'on_hand'):
					row_data[field] = to_int(row_data[field])
				row_data['location_id'] = self._location_id
				row_data['import_type'] = self._import_type
		return csv_data


	def restart_pull(self):
		self._state.resume.action = 'pull'
		self._state.resume.type = 'products'
		self._state.pull.resume.action = 'display_pull'
		self._state.pull.resume.type = 'products'
		self._state.pull.process.products = EntityProcess()
		self.save_state()
		return Response().success()


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		self.setup_storage_csv()
		self.storage_data()
		table = self.table_construct()
		query = "SELECT COUNT(1) as count FROM `{}`".format(table['table'])
		count = self.get_model_local().select_raw(query)
		if count.result != Response().SUCCESS:
			return count
		self._state.pull.process.products.total = count['data'][0]['count']
		return Response().success()


	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._state.pull.process.products.id_src
		table = self.table_construct()
		query = 'SELECT * FROM `{}` WHERE row_id > "{}" ORDER BY row_id LIMIT {}'.format(table['table'], id_src, limit_data)
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS:
			return products
		if not products.data:
			return Response().finish()
		return Response().success(data = products.data)


	def get_products_ext_export(self, products):
		products_ext = list()
		product_ids = duplicate_field_value_from_list(products, 'id')
		product_ids = set(filter(None, product_ids))
		# Get main products
		where = self.get_model_catalog().create_where_condition('_id', list(product_ids), 'in')
		products_data = self.get_model_catalog().find_all(where)
		products_ext.extend(products_data)
		# Get parent products
		parent_ids = duplicate_field_value_from_list(products_data, 'parent_id')
		parent_ids = set(filter(None, parent_ids))
		where = self.get_model_catalog().create_where_condition('_id', list(parent_ids - product_ids), 'in')
		parents_data = self.get_model_catalog().find_all(where)
		products_ext.extend(parents_data)
		return Response().success(data = products_ext)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.row_id


	def _convert_product_export(self, product, products_ext):
		return Response().success(product)


	def add_channel_to_convert_product_data(self, product, product_channel_id):
		return product
