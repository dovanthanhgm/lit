import copy
import time
from html import unescape
from itertools import product

import barcodenumber
import requests
import validators
from bs4 import Comment
from woocommerce import API

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.libs.woo_api import WooCloudFlareApi
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory, CatalogCategoryParent
from datasync.models.constructs.order import Order, OrderProducts, OrderHistory, Shipment
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, \
	ProductVariantAttribute, ProductAttribute


class ModelChannelsWoo(ModelChannel):
	USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36"
	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	ORDER_STATUS = {
		Order.OPEN: "on-hold",
		Order.READY_TO_SHIP: "processing",
		Order.AWAITING_PAYMENT: "on-hold",
		Order.COMPLETED: "completed",
		Order.CANCELED: "cancelled",
		Order.REFUNDED: "refunded",
		Order.SHIPPING: "processing",
	}


	def __init__(self):
		super().__init__()
		self._api_url = None
		self._last_status = None
		self._last_product_created_at = None
		self._last_order_created_at = None
		self._api_version = ''
		self._brands = {}
		self._query_string_auth = None
		self._zero_tax = None
		self._weight_units = False
		self._dimension_units = False
		self._store_information = False
		self._pull_custom = False
		self._attributes = dict()
		self._all_attributes = dict()
		self._flag_finish_category = False
		self._category_next_page = 1
		self._product_images = {}
		self._product_pull_type = "publish"
		self._category_id = None
		self._storage_image_list = []

	def get_api_version(self):
		if self._api_version:
			return self._api_version
		if self._state.channel.config.api.api_version:
			self._api_version = self._state.channel.config.api.api_version
			return self._api_version
		return 'wc/v3'


	def get_custom_params(self):
		if self._state.channel.config.api.custom_params:
			return self._state.channel.config.api.custom_params
		return {}


	def get_query_string_auth(self):
		if self._query_string_auth is not None:
			return self._query_string_auth
		if self._state.channel.config.api.query_string_auth:
			self._query_string_auth = self._state.channel.config.api.query_string_auth
			return self._query_string_auth
		return False


	def set_api_version(self, api_version):
		self._api_version = api_version


	def set_query_string_auth(self, query_string_auth):
		self._query_string_auth = query_string_auth


	def get_api_info(self):
		return {
			'consumer_key': "Consumer Key",
			'consumer_secret': 'Consumer Secret'
		}


	def get_user_agent(self):
		return self._state.channel.config.api.user_agent if 'user_agent' in self._state.channel.config.api else 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36'


	def get_api_object(self, api_version = None) -> API:
		if self._state.channel.config.api.object_api == 'cloud_flare':
			object_api = WooCloudFlareApi
		else:
			object_api = API
		api_version = api_version or self.get_api_version()
		api_data = dict(url = self.get_api_url(),  # Your store URL
			consumer_key = self._state.channel.config.api.consumer_key,  # Your consumer key
			consumer_secret = self._state.channel.config.api.consumer_secret,  # Your consumer secret
			wp_api = True,  # Enable the WP REST API integration
			version = api_version,  # WooCommerce WP REST API version
			timeout = to_int(self._state.channel.config.api.api_timeout) or 100,
			query_string_auth = self.get_query_string_auth(),
			verify_ssl = False)
		user_agent = self.get_user_agent()
		if user_agent:
			api_data['user_agent'] = user_agent
		return object_api(

			**api_data
		)


	def get_api_url(self):
		url = self._state.channel.url
		if self._state.channel.config.api.mod_rewrite:
			url = self._state.channel.url.strip('/') + '/index.php'
		return url


	def solve_api_response(self, data):
		if isinstance(data, list):
			return_data = []
			for row in data:
				return_data.append(self.solve_api_response(row))
			return return_data
		if isinstance(data, dict):
			return_data = {}
			for key, value in data.items():
				if key in ['_link', '_links', 'self']:
					key = f'litc{key}'
				return_data[key] = self.solve_api_response(value)
			return return_data
		return data


	def setup_api(self):
		api_data = dict(url = self.get_api_url(),  # Your store URL
			consumer_key = self._state.channel.config.api.consumer_key,  # Your consumer key
			consumer_secret = self._state.channel.config.api.consumer_secret,  # Your consumer secret
			wp_api = True,  # Enable the WP REST API integration
			version = 'wc/v3',  # WooCommerce WP REST API version
			timeout = 100,
			verify_ssl = False,
			)
		user_agent = self.get_user_agent()
		if user_agent:
			api_data['user_agent'] = user_agent
		wcapi = API(
			**api_data

		)
		requets_options = {
			'params': {'per_page': 1}
		}
		if self._state.channel.config.api.cookies:
			requets_options['cookies'] = self._state.channel.config.api.cookies
		setup = wcapi.get('products', **requets_options)
		response_text = setup.text
		if json_decode(to_str(setup.text).split('</script>', 1)[-1]):
			response_text = to_str(setup.text).split('</script>', 1)[-1]
		if json_decode(response_text) is not False:
			json_data = json_decode(response_text)
			if '_links' in json_data:
				del json_data['_links']
			if 'routes' in json_data:
				del json_data['routes']
			return Response().success(self.solve_api_response(json_data))
		if setup.status_code == 404:
			check = requests.get(f"{self._state.channel.url}/wp-admin", **requets_options)
			if check.status_code == 404:
				return Response().error(Errors.WOOCOMMERCE_INVALID_URL)
			else:
				return Response().error(Errors.WOOCOMMERCE_MOD_REWRITE)
		if setup.status_code == 401:
			# return Response().success()
			wcapi = API(
				url = self.get_api_url(),  # Your store URL
				consumer_key = self._state.channel.config.api.consumer_key,  # Your consumer key
				consumer_secret = self._state.channel.config.api.consumer_secret,  # Your consumer secret
				wp_api = True,  # Enable the WP REST API integration
				version = '',  # WooCommerce WP REST API version
				timeout = 100,
				verify_ssl = False,
				query_string_auth = True,

			)
		if setup.status_code in [200, 403]:
			detect_firewall = self.detect_firewall(setup.text)
			if detect_firewall:
				if detect_firewall == 'CloudFlare':
					wcapi = WooCloudFlareApi(
						url = self.get_api_url(),  # Your store URL
						consumer_key = self._state.channel.config.api.consumer_key,  # Your consumer key
						consumer_secret = self._state.channel.config.api.consumer_secret,  # Your consumer secret
						wp_api = True,  # Enable the WP REST API integration
						version = 'wc/v3',  # WooCommerce WP REST API version
						timeout = 100,
						verify_ssl = False,

					)
					setup = wcapi.get('products')
					response_text = setup.text
					if json_decode(to_str(setup.text).split('</script>', 1)[-1]):
						response_text = to_str(setup.text).split('</script>', 1)[-1]
					if setup.status_code == 200 and json_decode(response_text):
						self._state.channel.config.api.object_api = 'cloud_flare'
						json_data = json_decode(response_text)
						if '_links' in json_data:
							del json_data['_links']
						if 'routes' in json_data:
							del json_data['routes']
						return Response().success(self.solve_api_response(json_data))
				if detect_firewall == 'BPS':
					return Response().error(Errors.WOOCOMMERCE_ERROR_BPS)
				if detect_firewall == 'Imunify360':
					try:
						return self.try_connect_with_selenium()
					except:
						self.log_traceback()
				return Response().error(msg = Errors().get_msg_error(Errors.WOOCOMMERCE_ERROR_FIREWALL).format(detect_firewall))
		return Response().error(Errors.WOOCOMMERCE_CONNECT_FAIL)


	def try_connect_with_selenium(self):
		from selenium import webdriver

		chrome_options = webdriver.ChromeOptions()
		chrome_options.add_argument('--headless')
		chrome_options.add_argument('--no-sandbox')
		chrome_options.add_argument("start-maximized")
		driver = webdriver.Chrome(chrome_options = chrome_options)
		driver.get(self.get_api_url())
		time.sleep(5)
		all_cookies = driver.get_cookies()
		cookies_dict = {}
		for cookie in all_cookies:
			cookies_dict[cookie['name']] = cookie['value']
		self._state.channel.config.api.user_agent = driver.execute_script("return navigator.userAgent")
		self._state.channel.config.api.cookies = cookies_dict
		wcapi = self.get_api_object()
		driver.close()
		setup = wcapi.get('products', cookies = cookies_dict)
		response_text = setup.text
		if json_decode(to_str(setup.text).split('</script>', 1)[-1]):
			response_text = to_str(setup.text).split('</script>', 1)[-1]
		if json_decode(response_text) is not False:
			json_data = json_decode(response_text)
			if '_links' in json_data:
				del json_data['_links']
			if 'routes' in json_data:
				del json_data['routes']
			return Response().success(self.solve_api_response(json_data))
		return Response().error(msg = Errors().get_msg_error(Errors.WOOCOMMERCE_ERROR_FIREWALL).format('Imunify360'))

	# api code
	def api(self, path, data = None, api_type = "get", params = None, retry = 0, api_version = None):
		wcapi = self.get_api_object(api_version)
		api_type = api_type.lower()
		api_obj = getattr(wcapi, api_type)
		res = None
		response_data = None
		request_option = {
			"endpoint": path
		}
		if not params:
			params = {}
		if self.get_custom_params():
			params.update(self.get_custom_params())
		if params:
			request_option['params'] = params
		if api_type in ['put', 'post']:
			request_option['data'] = data
		if self._state.channel.config.api.cookies:
			request_option['cookies'] = self._state.channel.config.api.cookies
		try:
			res = api_obj(**request_option)
		except Exception as e:
			self.log_request_error(path, data = data, params = params, response = res.text if res else '', status = res.status_code if res else 0, method = api_type)

			self.log_traceback()
			if retry <= 5:
				retry += 1
				time.sleep(retry * 5)
				return self.api(path, data, api_type, params, retry)
			res = False
		if res is not False:
			if res.status_code == 401:
				self.channel_disconnected()
				self.set_action_stop(True)
			if res.status_code > 204 or self.is_log() or (api_type.lower() in ['get', 'post'] and not res.text):
				self.log_request_error(path, data = data, params = params, response = res.text, status = res.status_code, method = api_type, retry = retry)
			self._last_status = res.status_code
			self._last_header = res.headers
			response_text = res.text
			if ".woocommerce-variation-price" in to_str(res.text):
				response_text_find = to_str(res.text).split('\t\t[')
				if len(response_text_find) == 2 and json_decode('[' + response_text_find[1]):
					response_text = '[' + response_text_find[1]

			if json_decode(to_str(res.text).split('</script>', 1)[-1]):
				response_text = to_str(res.text).split('</script>', 1)[-1]

			if "</p>" in response_text and 'DOCTYPE' in response_text:
				response_text_dup = response_text.split('</p>')[-1]
				if json_decode(response_text_dup):
					response_text = response_text_dup

			response_data = json_decode(response_text)
			if not response_data:
				if self.detect_firewall(response_text) == 'Imunify360':
					connect = self.try_connect_with_selenium()
					if connect.result == Response.SUCCESS:
						self.update_channel(api = json_encode(self._state.channel.config.api))
						retry += 1
						return self.api(path, data, api_type, params, retry)
					return False
				try:
					response_text = to_str(res.text).encode('ascii', 'ignore')
					if json_decode(to_str(res.text).split('</script>', 1)[-1]):
						response_text = to_str(res.text).split('</script>', 1)[-1]
					response_data = json_decode(response_text)
				except Exception as e:
					response_data = False

			if response_data:
				try_decode = json_decode(base64_to_string(response_data))
				if try_decode:
					response_data = try_decode
			response_data = self.solve_api_response(response_data)
			if isinstance(response_data, list):
				for res1 in response_data:
					if '_links' in res1:
						del res1['_links']
				response_data = list(map(lambda x: Prodict(**x), response_data))
			if isinstance(response_data, dict) and path:
				if '_links' in response_data:
					del response_data['_links']
				response_data = Prodict(**response_data)

			self._last_status = res.status_code
		while (self._last_status == 429 or (res is False and (not self._last_status or self._last_status > 500)) or (res and self._last_status == 502)) and retry <= 5 and self._last_status != 504:
			retry += 1
			time.sleep(retry * 5)
			return self.api(path, data, api_type, params, retry)
		return response_data


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		index_api = self.setup_api()
		if index_api.result != Response.SUCCESS:
			success = False
			if index_api.code == Errors.WOOCOMMERCE_MOD_REWRITE:
				channel_url = self._state.channel.url.strip('/')
				self._state.channel.url = self._state.channel.url.strip('/') + '/index.php'
				index_api_check = self.setup_api()
				if index_api_check.result == Response.SUCCESS:
					self._state.channel.url = channel_url
					self._state.channel.config.api.mod_rewrite = True
					success = True
			if not success:
				return index_api
		# order = self.get_order_by_id(5536)
		# order_ext = self.get_orders_ext_export([order['data']])
		# convert = self.convert_order_export(order['data'], order_ext['data'])
		index_api_data = index_api.data
		namespaces = ['wc/v3']
		# if index_api_data.get('namespaces'):
		# 	namespaces_ext = list(filter(lambda x: x.split('/')[0] == 'wc' and x.split('/')[-1] not in ['v1', 'v2', 'v3'], index_api_data['namespaces']))
		# else:
		# 	namespaces_ext = list()
		# namespaces.extend(namespaces_ext)
		query_string_auth_value = [False, True]
		for query_string_auth in query_string_auth_value:
			self.set_query_string_auth(query_string_auth)
			for api_version in namespaces:
				self.set_api_version(api_version)
				check_read_per = self.api('products', params = {'per_page': 1})
				if self._last_status == 200:
					self._state.channel.config.api.api_version = self.get_api_version()
					if query_string_auth:
						self._state.channel.config.api.query_string_auth = True

					return Response().success()
		if self._last_status == 503:
			return Response().error(Errors.WOOCOMMERCE_ERROR_503)
		if self._last_status == 406:
			return Response().error(Errors.WOOCOMMERCE_ERROR_406)
		if self._last_status >= 500:
			return Response().error(Errors.WOOCOMMERCE_ERROR_500)

		return Response().error(Errors.WOOCOMMERCE_API_PERMISSION)


	def after_create_channel(self, data):
		if is_local():
			return Response().success()
		return Response().success()
		entities = ['order']
		events = dict()
		if self.is_channel_default():
			for entity in entities:
				events[f"{entity}.updated"] = f'{entity}/update'
		events["product.deleted"] = 'product/delete'
		for event, url in events.items():
			webhook_data = {
				"topic": event,
				"delivery_url": get_server_callback(f'merchant/woocommerce/webhook/{data.channel_id}/{url}'),
				"name": "litCommerce Webhook - Don't Delete or edit",
				"secret": self._state.channel.config.api.consumer_secret,
			}
			response = self.api(path = 'webhooks', data = webhook_data, api_type = 'post')

		return Response().success()


	def get_max_last_modified_product(self):
		last_modified = False
		if self._state.pull.process.products.last_modified:
			if to_str(self._state.pull.process.products.last_modified).isnumeric():
				last_modified = convert_format_time(self._state.pull.process.products.last_modified)
			else:
				last_modified = self._state.pull.process.products.last_modified
		# if last_modified and not self._state.channel.config.api.skip_gmt:
		# 	last_modified += 'Z'
		return last_modified


	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(updated_at, '%Y-%m-%dT%H:%M:%S')


	def get_product_updated_at(self, product):
		if self._state.channel.config.api.date_gmt:
			return product.date_modified_gmt
		return product.date_modified or get_current_time("%Y-%m-%dT%H:%M:%S")

	def get_product_created_at(self, product):
		if self._state.channel.config.api.date_gmt:
			return product.date_created_gmt
		return product.date_created or get_current_time("%Y-%m-%dT%H:%M:%S")


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S") > to_timestamp(self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
			self._order_max_last_modified = last_modifier

	def get_cate_before_import(self, cate_name):
		cate_id = self._category_id
		if cate_id:
			return cate_id
		woo_categories = self.api(path = "products/categories", params = {"search": cate_name})
		if woo_categories and isinstance(woo_categories, list):
			cate_id = woo_categories[0].get('id')
			self._category_id = cate_id
		return cate_id



	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent

		if self.is_product_process():
			if self._state.pull.process.products.finished:
				self._state.pull.process.products.finished = False
				self._state.pull.process.products.id_src = 0
				self._state.pull.process.products.total_view = 0
				self._state.pull.process.products.total = 0
				self._state.pull.process.products.error = 0
				self._state.pull.process.products.imported = 0
				self._state.pull.process.products.new_entity = 0

			params = {'per_page': 1}
			if self._state.channel.config.api.category_id:
				params['category'] = self._state.channel.config.api.category_id
			if self._state.channel.config.api.product_filter:
				params.update(self._state.channel.config.api.product_filter)
			if self.is_refresh_process():
				status = 'any'
				self._state.pull.process.products.id_src = 0
				last_modified = self.get_max_last_modified_product()
				if last_modified:
					params['modified_after'] = last_modified
				params['status'] = status
			offset = self._state.pull.process.products.imported
			if offset:
				params['offset'] = offset
			skip_filter = False

			if not self.is_refresh_process():
				if self._request_data.get('include_filters'):
					if self._request_data['include_filters'].get('ids'):
						ids = self._request_data['include_filters'].get('ids').split(',')
						for index, item in enumerate(ids):
							params[f'include[{index}]'] = to_int(item)
					if self._request_data['include_filters'].get('category'):
						cate_name = self._request_data['include_filters'].get('category')
						cate_id = self.get_cate_before_import(cate_name)
						if cate_id:
							params['category'] = cate_id
						else:
							skip_filter = True
					for field_filter, value in self._request_data['include_filters'].items():
						if field_filter not in ['tag', 'stock_status', 'status']:
							continue
						params[field_filter] = value
				else:
					params['status'] = 'any'
			if not skip_filter:
				self.api(path = "products", params = params)
				total_product = to_int(self._last_header.get('x-wp-total')) if self._last_header else 0
			else:
				total_product = 0
			if total_product:
				if self.is_refresh_process():
					self._state.pull.process.products.total = -1
					self._state.pull.process.products.total_view = total_product
				else:
					self._state.pull.process.products.total = total_product
			if not self.is_refresh_process():
				if self._state.channel.config.api.custom_ids:
					self._state.pull.process.products.total += to_len(to_str(self._state.channel.config.api.custom_ids).split(','))
		if self._state.config.orders:
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			start_time = self.get_order_start_time('%Y-%m-%dT%H:%M:%S')
			last_modifier = self._state.pull.process.orders.max_last_modified
			params = {
				"after": start_time,
				"per_page": 1
			}
			if last_modifier:
				params['modified_after'] = f'{last_modifier}'
				self.set_order_max_last_modifier(last_modifier)
			self.api(path = "orders", params = params)
			self._state.pull.process.orders.total = self._last_header.get('x-wp-total', 0)
		if self.is_category_process():
			self._state.pull.process.categories.total = 0
			self._state.pull.process.categories.imported = 0
			self._state.pull.process.categories.error = 0
			self._state.pull.process.categories.id_src = ''
			params = {
				"per_page": 1,
				"page": 1,
			}

			category_api = self.api("products/categories", params = params)
			self._state.pull.process.categories.total = self._last_header.get('x-wp-total', 0)
		return Response().success()


	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		try:
			categories = self.api(
				path = f"products/categories?per_page={self._state.pull.setting.categories}")
			while categories:
				for category in categories:
					res = self.api(path = f"products/categories/{category['id']}?force=true", api_type = 'delete')
				categories = self.api(
					path = f"products/categories?per_page={self._state.pull.setting.categories}")
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			products = self.api(path = f'products?per_page={self._state.pull.setting.products}')
			while products:
				for product in products:
					id_product = product['id']
					res = self.api(path = f'products/{id_product}?force=true', api_type = 'delete')
				products = self.api(path = f'products?per_page={self._state.pull.setting.products}')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_categories_main_export(self):
		if self._flag_finish_category:
			return Response().finish()
		if self._category_next_page:
			params = {'per_page': 100, 'page': self._category_next_page}

		else:
			params = {'per_page': 100, 'page': 1}
		categories = self.api('products/categories', params = params)
		links = self._last_header.get('Link')
		next_link = ''
		if links and 'next' in links:
			self._category_next_page += 1
		if self._last_status != 200:
			return Response().finish()
		if not next_link:
			self._flag_finish_category = True
		return Response().success(data = categories)


	def get_categories_ext_export(self, categories):
		extend = dict()
		return Response().success(extend)
	def get_category_by_id(self, category_id):
		api_categories = self.api(f'/products/categories/{category_id}')
		if self._last_status < 300:
			return Response().success(api_categories.data)
		return Response().error()
	def get_category_parent(self, parent_id):
		categories_data = self.get_category_by_id(parent_id)
		if categories_data.result != Response.SUCCESS:
			return categories_data
		category = categories_data['data']
		categories_ext = self.get_categories_ext_export([categories_data['data']])
		parent_data = self.convert_category_export(category, categories_ext.data)
		return parent_data

	def convert_category_export(self, category, categories_ext):
		category_data = CatalogCategory()
		parent = CatalogCategoryParent()
		parent['id'] = 0
		category_data['id'] = category['id']
		category_data['name'] = category['name']
		category_data['parent'] = parent
		category_data.path = category['name']
		if to_int(category['parent']) > 0:
			parent = self.get_category_parent(category['parent_id'])
			if parent.result == Response.SUCCESS:
				parent = parent['data']
				category_data['parent'] = parent
				category_data.parent_id = parent.id
				category_data.path = f'{parent.path} > {category.name}'
		return Response().success(category_data)


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		if not category.name:
			return response_error('import category ' + to_str(category.id) + ' false.')
		post_data = {
			'smart_collection': {
				'title': category.name,
				'body_html': category.description,
				'published_scope': 'web',
				'disjunctive': 'false',
				'sort_order': 'best-selling',
				'rules': []
			}
		}

		# Add Thumbnail image
		if category.thumb_image.url:
			main_image = self.process_image_before_import(category.thumb_image.url, category.thumb_image.path)
			image_data = self.resize_image(main_image['url'])
			if image_data:
				post_data['smart_collection']['image'] = image_data

		# Status
		if not category.active:
			post_data['smart_collection']['published_at'] = None

		# Add rules: the list of rules that define what products go into the smart collections.
		tag_rule = {
			'column': 'tag',
			'relation': 'equals',
			'condition': category.name
		}
		post_data['smart_collection']['rules'].append(tag_rule)

		# Post data
		response = self.api('smart_collections.json', post_data, 'Post')
		check_response = self.check_response_import(response, category, 'category')
		if check_response.result != Response.SUCCESS:
			if 'Image' in check_response.msg:
				del post_data['smart_collection']['image']
				response = self.api('smart_collections.json', post_data, 'Post')
				check_response = self.check_response_import(response, category, 'category')
				if check_response.result != Response.SUCCESS:
					return check_response
			else:
				return check_response

		category_id = response['smart_collection']['id']
		handle = response['smart_collection'].get('handle')
		return Response().success(category_id)

	def get_products_main_export(self):
		imported = self._state.pull.process.products.imported
		params = {
			'per_page': 25,
			'order': 'asc',
			'orderby': 'id',
		}
		if self._state.channel.config.api.product_filter:
			params.update(self._state.channel.config.api.product_filter)
		if self._request_data.get('include_filters'):
			if self._request_data['include_filters'].get('ids'):
				ids = self._request_data['include_filters'].get('ids').split(',')
				for index, item in enumerate(ids):
					params[f'include[{index}]'] = to_int(item)
			if self._request_data['include_filters'].get('category'):
				cate_name = self._request_data['include_filters'].get('category')
				cate_id = self.get_cate_before_import(cate_name)
				if cate_id:
					params['category'] = cate_id
			for field_filter, value in self._request_data['include_filters'].items():
				if field_filter not in ['tag', 'stock_status', 'status']:
					continue
				params[field_filter] = value
		else:
			params['status'] = 'any'
		if self._state.channel.config.api.category_id:
			params['category'] = self._state.channel.config.api.category_id
		if imported:
			params['offset'] = imported
		# if not self._state.pull.process.products.include_inactive:
		# 	params['status'] = 'publish'
		products = self.api(path = "products", params = params)
		if not products:
			if self._state.channel.config.api.custom_ids and not self._pull_custom:
				self._pull_custom = True
				params = {'include': self._state.channel.config.api.custom_ids}
				products = self.api(path = "products", params = params)
				if products:
					return Response().success(data = products)
			return Response().finish()
		last_product = products[-1]
		# self._last_product_created_at = to_str(last_product.date_created).replace('T', ' ')
		return Response().success(data = products)

	# def set_product_pull_type(self):
	# 	product_status = self._product_pull_type
	# 	product_next_type = {
	# 		'publish': 'draft',
	# 		'draft': 'pending',
	# 		'pending': 'private',
	# 		'private': '',
	# 	}
	# 	self._product_pull_type = product_next_type.get(product_status, '')
	#
	# def set_imported_product(self, imported):
	# 	if self._product_pull_type == 'publish':
	# 		self._state.pull.process.products.imported += imported
	# 	else:
	# 		if not self._state.pull.process.products.get(f'imported_{self._product_pull_type}'):
	# 			self._state.pull.process.products[f'imported_{self._product_pull_type}'] = 0
	# 		self._state.pull.process.products[f'imported_{self._product_pull_type}'] += imported

	def get_product_by_updated_at(self):
		imported = self._state.pull.process.products.imported
		params = {
			'per_page': 25,
			'order': 'asc',
			"orderby": "modified"
		}
		if self._state.channel.config.api.product_filter:
			params.update(self._state.channel.config.api.product_filter)
		if self._state.channel.config.api.category_id:
			params['category'] = self._state.channel.config.api.category_id
		if self._state.channel.config.sql_injection:
			del params['order']
			del params['orderby']
		if imported:
			params['offset'] = imported

		last_modified = self.get_max_last_modified_product()
		if last_modified:
			params['modified_after'] = last_modified
		products = self.api(path = "products", params = params)
		if not products:
			if self._state.channel.config.api.custom_ids and not self._pull_custom:
				self._pull_custom = True
				params = {'include': self._state.channel.config.api.custom_ids}
				products = self.api(path = "products", params = params)
				if products:
					return Response().success(data = products)
			return Response().finish()
		last_product = products[-1]
		# self._last_product_created_at = to_str(last_product.date_created).replace('T', ' ')
		return Response().success(data = products)


	def get_products_ext_export(self, products):
		extend = Prodict()
		for product in products:
			product_id = to_str(product.id)
			extend[to_str(product_id)] = product
		return Response().success(extend)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def valid_isbn(self, isbn):
		return barcodenumber.check_code_isbn(isbn) or barcodenumber.check_code_isbn10(isbn) or barcodenumber.check_code_isbn13(isbn)


	def valid_gtin(self, gtin):
		return barcodenumber.check_code_gtin(gtin) or barcodenumber.check_code_gtin14(gtin) or self.valid_upc(gtin) or self.valid_ean(gtin) or self.valid_isbn(gtin)


	def valid_upc(self, upc):
		return barcodenumber.check_code_upc(upc) or self.valid_ean(upc)


	def valid_ean(self, ean):
		return barcodenumber.check_code_ean13(ean) or barcodenumber.check_code_ean8(ean) or barcodenumber.check_code_ean(ean)
	# def set_imported_product(self, imported):
	# 	super().set_imported_product(imported)
	# 	self._state.pull.process.products.created_at = self._last_product_created_at

	def set_product_max_last_modified(self, product):
		if self._state.channel.config.api.date_gmt and not product.date_modified_gmt:
			return
		if not product.date_modified:
			return
		super().set_product_max_last_modified(product)

	def validate_image_url(self, src):
		is_url_start_with_http = src.find('http://') == 0 or src.find('https://') == 0
		if not is_url_start_with_http and not validators.url(src):
			if src.find('//') == 0:
				src = f"https:{src}"
			else:
				src = f"{self.get_channel_url().strip('/')}/{src.strip()}"

		return src

	def _convert_product_export(self, product, products_ext: Prodict):
		product_id = to_str(product.id)
		product_data = Product()
		product_data.id = product_id
		product_data.status = True if product.status == 'publish' else False
		product_data.invisible = False if product.status == 'publish' else True

		product_data.manage_stock = True if product.manage_stock else False
		product_data.is_in_stock = True if product.stock_status == 'instock' else False
		created_at = self.get_product_created_at(product)
		updated_at = self.get_product_updated_at(product)
		product_data.created_at = to_str(created_at).replace('T', ' ') if created_at else to_str(updated_at).replace('T', ' ')
		product_data.updated_at = to_str(updated_at).replace('T', ' ')
		product_data.name = product.name
		product_data.description = product.description
		product_data.short_description = product.short_description
		product_data.sku = product.sku
		meta_title = get_row_value_from_list_by_field(product.meta_data, 'key', '_genesis_title', 'value')
		meta_description = get_row_value_from_list_by_field(product.meta_data, 'key', '_genesis_description', 'value')
		meta_description_divi_build = get_row_value_from_list_by_field(product.meta_data, 'key', '_et_pb_old_content', 'value')
		meta_specification = get_row_value_from_list_by_field(product.meta_data, 'key', 'specification', 'value')
		meta_keywords = get_row_value_from_list_by_field(product.meta_data, 'key', '_genesis_keywords', 'value')
		if meta_title:
			product_data.meta_title = meta_title
		if meta_description:
			product_data.meta_description = meta_description
		if meta_keywords:
			product_data.meta_keyword = meta_keywords
		if not product.description and meta_specification:
			product_data.description = meta_specification
		if meta_description_divi_build and product.description.find('et_pb_') > -1:
			# Divi builder override the product description with
			# [et_pb_section fb_built="1" _builder_version="4.16" custom_padding="0px|
			# https://wordpress.org/support/topic/divi-description-corruption/
			product_data.description = meta_description_divi_build
		if self._state.channel.config.api.des_include_faq_properties:
			woo_tabs = get_row_value_from_list_by_field(product.meta_data, 'key', 'yikes_woo_products_tabs', 'value')
			try:
				if woo_tabs and isinstance(woo_tabs, list):
					for value in woo_tabs:
						if value["id"] == "properties-care":
							product_data.description = product_data.description + "<p><h3>Properties & Care</h3></p>" + value["content"]
						elif value["id"] == "faq":
							product_data.description = product_data.description + "<p><h3>FAQ</h3></p>" + value["content"]
			except:
				log_traceback()
		# thumb_image_id = 0
		if product.images:
			# thumb_image_id = product.images[0]['id']

			for index, image in enumerate(product.images):
				src = self.validate_image_url(image.src)
				if not index:
					product_data.thumb_image.url = src
					product_data.thumb_image.label = image.alt
					continue
				product_image_data = ProductImage()
				product_image_data.url = src
				product_image_data.label = image.alt
				product_data.images.append(product_image_data)
		# custom images
		try:
			if not product_data.images:
				b2s_post_meta = get_row_value_from_list_by_field(product.meta_data, 'key', '_b2s_post_meta', 'value')
				if b2s_post_meta:
					custom_image = True
					if product_data.thumb_image.url:
						image_size_h, image_size_w = self.get_image_size(product_data.thumb_image.url)
						if image_size_h > 500 and image_size_w > 500:
							custom_image = False
					if custom_image:
						images_key = ['og_image', 'card_image']
						images = []
						for field in images_key:
							if b2s_post_meta.get(field) and b2s_post_meta[field] not in images:
								images.append(b2s_post_meta[field])
						if images:
							product_data.thumb_image.url = images[0]
							del images[0]
							product_data.images = list()
							for image in images:
								product_image_data = ProductImage()
								product_image_data.url = image
								product_data.images.append(product_image_data)
		except:
			log_traceback()
		product_data.seo_url = product.permalink
		prices = product.prices or copy.deepcopy(product)
		product_data.price = prices.litc_regular_price or prices.litc_price or prices.regular_price or prices.price
		if prices.litc_sale_price or prices.sale_price:
			product_data.special_price.price = prices.litc_sale_price or prices.sale_price
			if product.date_on_sale_from:
				product_data.special_price.start_date = product.date_on_sale_from
			if product.date_on_sale_to:
				product_data.special_price.end_date = product.date_on_sale_to
		product_data.qty = product.stock_quantity or 0
		if self.sale_price_to_price() and product_data.special_price.price:
			product_data.price = product_data.special_price.price
		if product.weight:
			product_data.weight = product.weight
			product_data.weight_units = self.get_weight_units()
		if product.dimensions:
			if product.dimensions['length']:
				product_data.length = product.dimensions['length']
			if product.dimensions['width']:
				product_data.width = product.dimensions['width']
			if product.dimensions['height']:
				product_data.height = product.dimensions['height']
			product_data.dimension_units = self.get_dimension_units()
		if product.tags:
			for tag in product.tags:
				if product_data.tags == '':
					product_data.tags += tag['name']
				else:
					product_data.tags += ',' + tag['name']
		attributes = product.attributes
		product_variant_attributes = dict()
		if product.brands:
			product_data.brand = product.brands[0]['name']
		elif product.litc_product_brand:
			product_data.brand = product.litc_product_brand.split(',')[0]
		else:
			if product.tax_additional and product.tax_additional.brands and product.tax_additional.brands.linked:
				brand = strip_html_tag(product.tax_additional.brands.linked[0])
				if brand:
					product_data.brand = brand
		if not product_data.brand:
			brand_id = get_row_value_from_list_by_field(product.meta_data, 'key', '_yoast_wpseo_primary_product_brand', 'value')
			if brand_id:
				product_data.brand = self.get_brand_by_id(brand_id)
		identifier_fields = self.identifier_fields()
		for field in identifier_fields:
			if product.get(f'{field}_code'):
				product_data[field] = product[f'{field}_code']
		if attributes:
			for attr in attributes:
				attribute_data = ProductAttribute()
				if to_str(attr['name']).lower() == 'barcode':
					product_data.upc = ', '.join(attr.get('options')) if attr.get('options') else ''
					continue
				if to_str(attr['name']).lower() in identifier_fields:
					product_data[to_str(attr['name']).lower()] = attr['options'][0]
					continue
				attribute_data.attribute_name = attr['name']
				if attr.get('variation'):
					product_variant_attributes[attr['name']] = attr['options']
				# continue
				attribute_data.attribute_code = attr['name']
				attribute_data.attribute_value_name = ', '.join(attr.get('options')) if attr.get('options') else ''
				product_data.attributes.append(attribute_data)
		if product.categories:
			product_data.category_name_list = [row['name'] for row in product.categories]
		custom_ean_key = ['EAN','ean','_alg_ean', 'ced_onbuy_ean']
		if self.custom_ean_key():
			custom_ean_key.append(self.custom_ean_key())
		# if not product_data.ean:
		# 	for field in custom_ean_key:
		# 		custom_ean = get_row_value_from_list_by_field(product.meta_data, 'key', field, 'value')
		# 		if custom_ean:
		# 			product_data.ean = custom_ean
		custom_fields_key = {
			'ean': custom_ean_key,
			'mpn': ['ced_onbuy_mpn'],
			'asin': ['_asin'],
			'brand': ['ced_onbuy_brand']
		}
		for fields, custom_keys in custom_fields_key.items():
			for field in custom_keys:
				if product_data.get(field):
					continue
				custom_value = get_row_value_from_list_by_field(product.meta_data, 'key', field, 'value')
				if custom_value:
					product_data[field] = custom_value
					break
		custom_gtin_key = 'wpseo_global_identifier_values'
		custom_gtin = get_row_value_from_list_by_field(product.meta_data, 'key', custom_gtin_key, 'value')
		_amazon_price = get_row_value_from_list_by_field(product.meta_data, 'key', '_amazon_price', 'value')
		if _amazon_price:
			_amazon_price_attribute = ProductAttribute()
			_amazon_price_attribute.attribute_name = 'amazon_price'
			_amazon_price_attribute.attribute_value_name = _amazon_price
			product_data.attributes.append(_amazon_price_attribute)
		if custom_gtin:
			product_data.gtin = product_data.gtin or custom_gtin.gtin12 or custom_gtin.gtin13 or custom_gtin.gtin14 or custom_gtin.gtin8
			product_data.upc = product_data.upc or custom_gtin.upc or custom_gtin.gtin12
			product_data.ean = product_data.ean or custom_gtin.ean or custom_gtin.gtin8 or custom_gtin.gtin13
			product_data.isbn = product_data.isbn or custom_gtin.isbn or custom_gtin.gtin13
			product_data.mpn = product_data.mpn or custom_gtin.mpn
		try:
			for identifier_field in identifier_fields:
				if product_data.get(identifier_field):
					continue
				for meta_data in product.meta_data:
					if to_str(meta_data.get('key')).lower().find(identifier_field) == -1:
						continue
					if identifier_field == 'brand' and to_str(meta_data.get('key')).lower() not in ['brand', '_brand']:
						continue
					value = to_str(meta_data.get('value'))
					if not hasattr(self, f'valid_{identifier_field}'):
						product_data[identifier_field] = value
						break
					if not getattr(self, f'valid_{identifier_field}')(value):
						continue
					product_data[identifier_field] = value
					break
		except:
			self.log_traceback()
		variant_exist = []
		if product.variations:
			variants = self.get_all_product_variants(product)
			variants.sort(key = lambda x: to_int(x['menu_order']))
			for variant in variants:
				variant_data = ProductVariant()
				for field in identifier_fields:
					if variant.get(f'{field}_code'):
						variant_data[field] = variant[f'{field}_code']
				variant_attributes = dict()
				count = 0
				for attribute, options in product_variant_attributes.items():
					value = options
					for woo_attribute in variant.attributes:
						if woo_attribute['name'] == attribute:
							value = [woo_attribute['option']]
							count += 1
					variant_attributes[attribute] = value
				try:
					for woo_attribute in variant.attributes:
						if to_str(woo_attribute['name']).lower() == 'barcode':
							variant_data.upc = woo_attribute['options'][0]
							continue
						if to_str(woo_attribute['name']).lower() in identifier_fields:
							variant_data[to_str(woo_attribute['name']).lower()] = woo_attribute['options'][0]
							continue
				except:
					self.log_traceback()
				options_src = dict()
				for attribute_name, attribute_options in variant_attributes.items():
					options_src[attribute_name] = list()
					for value in attribute_options:
						opt_val = {
							'option_name': attribute_name,
							'option_value_name': value,
						}
						options_src[attribute_name].append(opt_val)
				variant_data.name = product.name
				variant_data.sku = variant.sku
				variant_data.status = True if variant.status == 'publish' else False
				variant_data.invisible = False if variant.status == 'publish' else True
				variant_data.price = variant.litc_regular_price or variant.litc_price or variant.regular_price or variant.price

				if variant.litc_sale_price or variant.sale_price:
					variant_data.special_price.price = variant.litc_sale_price or variant.sale_price
					if variant.date_on_sale_from:
						variant_data.special_price.start_date = variant.date_on_sale_from
					if variant.date_on_sale_to:
						variant_data.special_price.end_date = variant.date_on_sale_to
				if self.sale_price_to_price() and variant_data.special_price.price:
					variant_data.price = variant_data.special_price.price
				if variant.image:
					variant_data.thumb_image.url = self.validate_image_url(variant.image['src'])
					variant_data.thumb_image.label = variant.image['alt']
				variant_data.qty = variant.stock_quantity if variant.stock_quantity else 0
				if not variant.manage_stock:
					variant_data.manage_stock = False
				elif variant.manage_stock == 'parent':
					variant_data.manage_stock = product_data.manage_stock
					variant_data.qty = product_data.qty
				else:
					variant_data.manage_stock = True

				variant_data.is_in_stock = True if variant.stock_status == 'instock' else False
				variant_data.weight = variant.weight
				variant_data.weight_units = self.get_weight_units()
				if variant.dimensions:
					if variant.dimensions['length']:
						variant_data.length = variant.dimensions['length']
					if variant.dimensions['width']:
						variant_data.width = variant.dimensions['width']
					if variant.dimensions['height']:
						variant_data.height = variant.dimensions['height']
				variant_data.dimension_units = self.get_dimension_units()
				variant_data.created_at = to_str(variant.date_created).replace('T', ' ') if variant.date_created else to_str(variant.date_modified).replace('T', ' ')
				variant_data.updated_at = to_str(variant.date_modified).replace('T', ' ')
				for field in self.identifier_fields():
					if not variant_data.get(field):
						meta_key = self.custom_identifier_key(field) or f'_{field}'
						custom_field = get_row_value_from_list_by_field(variant.meta_data, 'key', meta_key, 'value')
						if custom_field:
							variant_data[field] = custom_field
				if not variant_data.ean:
					for field in custom_ean_key:
						custom_ean = get_row_value_from_list_by_field(variant.meta_data, 'key', field, 'value')
						if custom_ean:
							variant_data.ean = custom_ean
				custom_gtin_key = 'wpseo_global_identifier_values'
				custom_gtin = get_row_value_from_list_by_field(variant.meta_data, 'key', custom_gtin_key, 'value')
				if custom_gtin:
					variant_data.gtin = custom_gtin.gtin12 or custom_gtin.gtin13 or custom_gtin.gtin14 or custom_gtin.gtin8
					variant_data.upc = custom_gtin.upc or custom_gtin.gtin12
					variant_data.ean = custom_gtin.ean or custom_gtin.gtin8 or custom_gtin.gtin13
					variant_data.isbn = custom_gtin.isbn or custom_gtin.gtin13
					variant_data.mpn = custom_gtin.mpn
				try:
					for identifier_field in identifier_fields:
						if variant_data.get(identifier_field):
							continue
						for meta_data in variant.meta_data:
							if to_str(meta_data.get('key')).lower().find(identifier_field) == -1:
								continue
							if identifier_field == 'brand' and to_str(meta_data.get('key')).lower() not in ['brand', '_brand']:
								continue
							value = to_str(meta_data.get('value'))
							if not hasattr(self, f'valid_{identifier_field}'):
								variant_data[identifier_field] = value
								break
							if not getattr(self, f'valid_{identifier_field}')(value):
								continue
							variant_data[identifier_field] = value
							break
				except:
					self.log_traceback()
				combinations = self.combination_from_multi_dict(options_src)
				if combinations:
					for combination in combinations:
						if not combination:
							continue
						child_data = copy.deepcopy(variant_data)
						key_generate = list()
						for attr in combination:
							key_generate.append({"name": attr['option_name'], 'value': attr['option_value_name']})
							variant_attribute = ProductVariantAttribute()
							variant_attribute.attribute_type = 'select'
							variant_attribute.attribute_name = attr['option_name']
							variant_attribute.attribute_value_name = attr['option_value_name']
							child_data.attributes.append(variant_attribute)
						key_generate = sorted(key_generate, key = lambda d: d['name'])
						base64_generate = list()
						for row in key_generate:
							base64_generate.append(f"{row['name']}:{row['value']}")
						str_generate = string_to_base64('|'.join(base64_generate))
						if str_generate in variant_exist:
							continue
						if count == to_len(list(product_variant_attributes.keys())):
							child_data.id = variant.id
							child_data.seo_url = variant.permalink
						else:
							child_data.id = f"{product_id}-{self.variant_key_generate(child_data)}"
							child_data.seo_url = product.permalink + '?'
							for attribute in child_data.attributes:
								child_data.seo_url += f'attribute_pa_{self.name_to_code(attribute.attribute_name)}={self.name_to_code(attribute.attribute_value_name)}'

						child_data.channel_data = {
							'variant_id': variant.id
						}
						variant_exist.append(str_generate)
						product_data.variants.append(child_data)
		else:
			for field in self.identifier_fields():
				if not product_data.get(field):
					meta_key = self.custom_identifier_key(field) or f'_{field}'
					custom_field = get_row_value_from_list_by_field(product.meta_data, 'key', meta_key, 'value')
					if custom_field:
						product_data[field] = custom_field
		return Response().success(product_data)


	def get_product_by_id(self, product_id):
		product = self.api(path = f"products/{product_id}")
		if not product or self._last_status != 200:
			return Response().error(msg = "WOO GET PRODUCT FAIL")
		return Response().success(data = product)


	def get_wcpa_product_meta(self):
		return self._state.channel.config.api.wcpa_product_meta

	def is_create_on_woo_inactive(self):
		"""check if user want to create product inactive"""
		return bool(self._state.channel.config.api.create_product_inactive)


	def woocommerce_product_base_data(self, product, parent = None):
		if not parent:
			parent = product
		product_sku = product.sku
		if not product_sku:
			product_sku = to_str(to_int(time.time()))
			self._extend_product_map['sku'] = product_sku

		if product.sku and product.variants and product.src.channel_type == 'shopify' and product_sku.find('-parent') == -1:
			product_sku += "-parent"
			self._extend_product_map['sku'] = product_sku
		if self._state.channel.config.api.listing_id_to_sku:
			listing_channel_id = self._state.channel.config.api.listing_id_to_sku
			if product.channel.get(f'channel_{listing_channel_id}', {}).get('product_id'):
				product_sku = product.channel.get(f'channel_{listing_channel_id}', {}).get('product_id')
				self._extend_product_map['sku'] = product_sku

		product_data = {
			'name': product.name or parent.name,
			'description': self.clean_description(product.description),
			'short_description': self.clean_description(product.short_description or product.description),
			'sku': product_sku,
			# 'date_created': product.created_at or parent.created_at,
			# 'date_modified': product.updated_at or parent.updated_at,
			'status': 'publish' if product.status else 'draft',
			'regular_price': to_str(round(to_decimal(product.price), 2)),
			'stock_quantity': to_int(product.qty),
			'stock_status': 'instock' if to_int(to_int(product.qty)) else 'outofstock',
			'tags': list()
		}
		if product.src.channel_type == 'woocommerce':
			product_data['short_description'] = self.clean_description(product.short_description)

		if self.is_create_on_woo_inactive():
			product_data['status'] = 'draft'
		woo_meta_data = list()
		if self.get_wcpa_product_meta():
			woo_meta_data.append(
				{
					"key": "_wcpa_product_meta",
					"value": self.get_wcpa_product_meta()
				}
			)
		custom_seo_dict = {"meta_title": "_genesis_title", "meta_description": "_genesis_description", "meta_keyword": "_genesis_keywords"}
		meta_origin_product = {
			"key": "_origin_of_product",
			"value": "litcommerce"
		}
		woo_meta_data.append(meta_origin_product)
		for meta_key, woo_meta_key in custom_seo_dict.items():
			meta_value = product.get(meta_key)
			if meta_value:
				woo_meta_data.append(
					{
						"key": woo_meta_key,
						"value": meta_value
					}
				)
		product_data["meta_data"] = woo_meta_data
		if product.manage_stock:
			product_data['manage_stock'] = True
		if product.is_variant and product.tracking_inventory and product.tracking_inventory == 'product':
			product_data['manage_stock'] = False
		if self.is_special_price(product):
			if product.special_price.price:
				product_data['sale_price'] = to_str(round(to_decimal(product.special_price.price)))
			if product.special_price.start_date:
				product_data['date_on_sale_from'] = product.special_price.start_date
			if product.special_price.end_date:
				product_data['date_on_sale_to'] = product.special_price.end_date
		if product.weight or parent.weight:
			weight = to_decimal(product.weight) or to_decimal(parent.weight)
			weight_unit = parent.weight_units if parent else product.weight_units
			if weight_unit:
				config_weight_unit = self.get_weight_units()
				if config_weight_unit == 'lb':
					if weight_unit == 'oz':
						weight = to_decimal(weight / 16, 2)
				if config_weight_unit == 'oz':
					if weight_unit == 'lb':
						weight = to_decimal(weight * 16, 2)
			product_data['weight'] = to_str(weight)
		product_dimensions = dict()
		fields = ['length', 'width', 'height']
		for field in fields:
			if product.get(field) or parent.get(field):
				# woocommerce length, width, height must be strings
				product_dimensions[field] = to_str(
					product.get(field) if to_decimal(product.get(field)) > 0 else parent.get(field)
				)
		if product_dimensions:
			product_data['dimensions'] = product_dimensions
		if product.tags:
			list_tags = product.tags.split(',')
			for tag in list_tags:
				tag_data = {
					'name': tag
				}
				product_data['tags'].append(tag_data)
		product_data['type'] = 'variable' if product.variants else 'simple'
		return product_data


	def need_check_image_exixt(self):
		return self._state.channel.config.api.need_check_image_exixt


	def product_to_woocommerce_data(self, product: Product, parent = None, is_variant = False):
		# if not product.name and (not parent or ):
		# 	return response_error(Errors.PRODUCT_DATA_INVALID)

		product_data = self.woocommerce_product_base_data(product, parent)
		if not is_variant:
		# Add thumbnail, images
			images = list()
			if product.thumb_image.url:
				main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
				if self.need_check_image_exixt():
					check_image = self.image_exist(main_image['url'])
					if not check_image:
						return False
				images.append({'src': main_image['url']})
			for img_src in product.images:
				image_process = self.process_image_before_import(img_src.url, img_src.path)
				if self.need_check_image_exixt():
					check_image = self.image_exist(image_process['url'])
					if not check_image:
						continue
				images.append({'src': image_process['url']})
			if to_int(self._state.channel.config.api.limit_image):
				images = images[0:to_int(self._state.channel.config.api.limit_image)]
			if self._state.channel.config.api.skip_images:
				images = []
			if images:
				images = images[0:20]
				if self._state.channel.config.api.image_proxy:
					for image in images:
						image_url = self.upload_image(image['src'], self.create_destination_product_image(None, image['src']), force = True)
						if image_url:
							self._storage_image_list.append(image_url)
							image['src'] = image_url
				product_data['images'] = images[0:20]
			template_category = product.get('template_data', {}).get('category', {})
			category_ids = []
			template_category_data = list()
			product_data['categories'] = list()
			if template_category and template_category.get('categories'):
				category_ids = [category['category_id'] for category in template_category['categories']]
				template_category_data = template_category['categories']
			# Categories
			elif self.is_auto_import_category():
				category_name_list = product.category_name_list or []

				if product.category_path:
					category_name_path = product.category_path.split('>')[-1].strip()
					if category_name_path not in category_name_list:
						category_name_list.append(category_name_path)
				if product.product_type:
					category_name_list.append(product.product_type)
				category_name_list = list(set(category_name_list))
				for category_name in category_name_list:
					category_id = self.get_category_by_name(category_name.strip())
					if category_id and category_id not in category_ids:
						category_ids.append(category_id)
						template_category_data.append({
							"category_id": category_id,
							"category_name": category_name,
						})
				if not self.is_channel_default() and template_category_data:
					self._extend_product_map = {
						'template_data': {
							'category': {
								'categories': template_category_data
							}
						}
					}
			if category_ids:
				for category_id in category_ids:
					product_data['categories'].append({'id': category_id})
		else:
			if product.thumb_image.url:

				if self._product_images and self._product_images.get(product.thumb_image.url):
					product_data['image'] = {
						"id": self._product_images.get(product.thumb_image.url)
					}
				else:
					product_data['image'] = {
						"src": product.thumb_image.url
					}
		# Attribute
		product_data['attributes'] = list()

		attributes = product.attributes
		if product.brand:
			attribute_brand = ProductAttribute()
			attribute_brand.attribute_name = 'Brand'
			attribute_brand.attribute_value_name = product.brand
			attributes.append(attribute_brand)
		if self.is_ignore_attributes():
			attributes = []
		position = 0
		attribute_names = list()
		if product.variants:
			for attr in product.variants[0].attributes:
				if not attr.use_variant:
					continue
				attribute_id = self.get_attribute_by_name(to_str(attr.attribute_name))
				if attribute_id is False:
					return self.error_by_last_status()
				if not attribute_id:
					continue
				attribute_names.append(to_str(attr.attribute_name))
				product_attribute = dict()
				product_attribute['id'] = to_int(attribute_id)
				product_attribute['name'] = to_str(attr.attribute_name)
				product_attribute['position'] = position
				product_attribute['visible'] = False
				product_attribute['variation'] = True
				options = list()
				for variant in product.variants:
					for att in variant.attributes:
						if to_str(att.attribute_name) == product_attribute['name']:
							if to_str(att.attribute_value_name) not in options:
								options.append(to_str(att.attribute_value_name))
				product_attribute['options'] = options
				product_data['attributes'].append(product_attribute)
				position += 1
		if attributes:
			for attr in attributes:
				if to_str(attr.attribute_name) not in attribute_names:
					attribute_id = self.get_attribute_by_name(to_str(attr.attribute_name))
					if attribute_id is False:
						return self.error_by_last_status()
					if not attribute_id:
						continue
					product_attribute = dict()
					if attr.use_variant:
						product_attribute['id'] = attribute_id
						product_attribute['option'] = to_str(attr.attribute_value_name)
					else:
						product_attribute = dict()
						product_attribute['id'] = to_int(attribute_id)
						product_attribute['name'] = to_str(attr.attribute_name)
						product_attribute['position'] = position
						product_attribute['visible'] = True
						product_attribute['options'] = [to_str(attr.attribute_value_name)]
						position += 1
					product_data['attributes'].append(product_attribute)
		return Response().success(product_data)


	def error_by_last_status(self):
		if self._last_status == 401:
			if self.is_channel_default():
				path = 'source-cart'
			else:
				path = f"listing/{self.get_channel_id()}/settings"
			msg = Errors().get_msg_error(Errors.WOOCOMMERCE_ERROR_401).format(url_to_link(get_app_url(path), "Settings"))
			return Response().error(msg = msg)

		if hasattr(Errors, f"WOOCOMMERCE_ERROR_{self._last_status}"):
			return Response().error(getattr(Errors, f"WOOCOMMERCE_ERROR_{self._last_status}"))

		return Response().error(Errors.WOOCOMMERCE_CONNECT_FAIL)


	def delete_image_storage(self):
		if self._storage_image_list:
			for row in self._storage_image_list:
				self.get_storage_image_service().delete_file(row)
		self._storage_image_list = []


	def product_import(self, convert: Product, product: Product, products_ext):
		self._product_images = {}
		convert_product = self.product_to_woocommerce_data(product)
		if convert_product.result != Response.SUCCESS:
			self.delete_image_storage()
			return convert_product
		product_data = convert_product.data
		response = self.api(path = 'products', data = product_data, api_type = 'post')
		self.delete_image_storage()

		if self._last_status == 503:
			return Response().error(code = Errors.WOOCOMMERCE_ERROR_503)
		if self._last_status == 504:
			return Response().error(code = Errors.WOOCOMMERCE_ERROR_504)
		if self._last_status == 406:
			return Response().error(code = Errors.WOOCOMMERCE_ERROR_406)
		if self._last_status >= 500:
			return Response().error(code = Errors.WOOCOMMERCE_ERROR_500)

		check_response = self.check_response_import(response, product, 'product')
		if not response:
			return Response().error(code = Errors.WOOCOMMERCE_ERROR_500)
		if not response.id:
			msg = response.message or response.code
			if self._last_status == 400 and response.code:
				if response.code == 'product_invalid_sku':
					return Response().error(code = Errors.WOOCOMMERCE_INVALID_SKU)
			return Response().error(msg = msg)
		product_id = response['id']
		try:
			woo_images = response['images']
			images = list()
			if product.thumb_image.url:
				main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
				# check_image = self.image_exist(main_image['url'])
				# if check_image:
				images.append(main_image['url'])
			for img_src in product.images:
				image_process = self.process_image_before_import(img_src.url, img_src.path)
				# check_image = self.image_exist(image_process['url'])
				# if check_image:
				images.append(image_process['url'])
			if to_int(self._state.channel.config.api.limit_image):
				images = images[0:to_int(self._state.channel.config.api.limit_image)]
			if images and woo_images:
				for index, image in enumerate(woo_images):
					self._product_images[images[index]] = image['id']
		except:
			self.log_traceback('woo_images')
		return Response().success(product_id)


	def create_variant(self, product_id, variant, parent = None):
		convert_product = self.product_to_woocommerce_data(variant, parent, is_variant = True)
		if convert_product.result != Response.SUCCESS:
			return convert_product
		variant_post_data = convert_product.data
		response = self.api(f'products/{product_id}/variations', variant_post_data, 'post')
		if response and response.get('code') == 'product_invalid_sku':
			variant_post_data['sku'] = variant.sku + '-' + to_str(to_int(time.time()))
			response = self.api(f'products/{product_id}/variations', variant_post_data, 'post')
		if not response:
			if self._last_status == 503:
				return Response().error(code = Errors.WOOCOMMERCE_ERROR_503)
			if self._last_status == 406:
				return Response().error(code = Errors.WOOCOMMERCE_ERROR_406)
			return Response().error(code = Errors.WOOCOMMERCE_ERROR_500)
		if not response or not response.get('id'):
			msg = response.message or response.msg or response.code
			return Response().error(msg = msg)
		return Response().success(response.id)


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		# Product variants, inventory
		# if product.variants and 'attribute_manage_quantity' in product:
		# 	if not product.attribute_manage_quantity:
		# 		variant = copy.deepcopy(product.variants[0])
		# 		variant.attributes = []
		# 		if variant.sku == product.sku:
		# 			variant.sku += to_str(to_int(time.time()))
		# 		create_variant = self.create_variant(product_id, variant, product)
		# 		if create_variant.result != Response.SUCCESS:
		# 			return create_variant
		# 		variant_id = create_variant.data
		# 		for variant_row in product.variants:
		# 			variant_map_id = f"{product_id}-{self.variant_key_generate(variant_row)}"
		# 			self._extend_product_map = {
		# 				'variant_id': variant_id
		# 			}
		# 			self.insert_map_product(variant_row, variant_row['_id'], variant_map_id)
		# 	else:
		# 		all_variants = {}
		# 		attribute_manage_quantity = list(product.attribute_manage_quantity.values())
		# 		for variant in product.variants:
		# 			for attribute in variant.attributes:
		# 				if attribute.attribute_name in attribute_manage_quantity:
		# 					if not all_variants.get(attribute.attribute_value_name):
		# 						all_variants[attribute.attribute_value_name] = list()
		# 					all_variants[attribute.attribute_value_name].append(copy.deepcopy(variant))
		# 					break
		# 		skus = [product.sku]
		#
		# 		for attribute_value, variants in all_variants.items():
		# 			attribute = ProductVariantAttribute()
		# 			attribute.attribute_name = attribute_manage_quantity[0]
		# 			attribute.attribute_value_name = attribute_value
		# 			variant = copy.deepcopy(variants[0])
		# 			sku = variant.sku
		# 			index = 1
		# 			while sku in skus:
		# 				index += 1
		# 				sku = variant.sku + "_" + to_str(index)
		# 			skus.append(sku)
		# 			variant.sku = sku
		# 			variant.attributes = [attribute]
		# 			create_variant = self.create_variant(product_id, variant, product)
		# 			if create_variant.result != Response.SUCCESS:
		# 				return create_variant
		# 			variant_id = create_variant.data
		# 			for variant_row in variants:
		# 				variant_map_id = f"{product_id}-{self.variant_key_generate(variant_row)}"
		# 				self._extend_product_map = {
		# 					'variant_id': variant_id
		# 				}
		# 				self.insert_map_product(variant_row, variant_row['_id'], variant_map_id)
		# 	return Response().success()
		if product.variants:
			extend_map = copy.deepcopy(self._extend_product_map)
			self._extend_product_map = {}
			product_sku = product.sku
			if product.variants and product.src.channel_type == 'shopify':
				product_sku += "-parent"
			skus = [product_sku]
			insert_map = list()
			for variant in product.variants:
				sku = variant.sku
				if not sku:
					sku = to_str(to_int(time.time()))
				index = 1
				while sku in skus:
					index += 1
					sku = variant.sku + "_" + to_str(index)
				skus.append(sku)
				variant.sku = sku
				create_variant = self.create_variant(product_id, variant, product)
				if create_variant.result != Response.SUCCESS:
					return create_variant
				insert_map.append((variant, create_variant.data))
			for row in insert_map:
				self._extend_product_map['sku'] = row[0]['sku']
				self.insert_map_product(row[0], row[0]['_id'], row[1])
			self._extend_product_map = extend_map
		# variant_post_data = {
		# 	'regular_price': to_str(round(to_decimal(variant.price), 2)),
		# 	'sku': variant.sku,
		# 	'weight': to_str(to_decimal(variant.weight)) if to_decimal(variant.weight) > 0 else '0',
		# 	'date_created': variant.created_at,
		# 	'date_modified': variant.updated_at,
		# 	'status': 'publish' if variant.status else 'draft',
		# 	'stock_quantity': to_int(variant.qty),
		# 	'stock_status': 'instock' if variant.is_in_stock else 'outofstock'
		# }
		# if variant.manage_stock:
		# 	variant_post_data['manage_stock'] = True
		# if variant.special_price.price:
		# 	variant_post_data['sale_price'] = to_str(round(to_decimal(variant.special_price.price)))
		# if variant.special_price.start_date:
		# 	variant_post_data['date_on_sale_from'] = variant.special_price.start_date
		# if variant.special_price.end_date:
		# 	variant_post_data['date_on_sale_to'] = variant.special_price.end_date
		# variant_post_data['attributes'] = list()
		# for attribute in variant.attributes:
		# 	attribute_id = self.get_attribute_by_name(to_str(attribute.attribute_name))
		# 	if not attribute_id:
		# 		continue
		# 	variant_attribute = dict()
		# 	variant_attribute['id'] = attribute_id
		# 	variant_attribute['option'] = to_str(attribute.attribute_value_name)
		# 	variant_post_data['attributes'].append(variant_attribute)
		# response = self.api('products/' + to_str(product_id) + '/variations', variant_post_data, 'post')
		# if 'code' in response and response['code'] == 'product_invalid_sku':
		# 	variant_post_data['sku'] = variant.sku + '-' + to_str(variant.id)
		# 	response = self.api('products/' + to_str(product_id) + '/variations', variant_post_data, 'post')
		# 	self.insert_map_product(variant, variant['_id'], response.get('id'))
		# else:
		# 	self.insert_map_product(variant, variant['_id'], response.get('id'))
		return Response().success()


	def delete_product_import(self, product_id):
		params = {
			'force': True
		}
		self.api(path = 'products/' + to_str(product_id), params = params, api_type = 'delete')
		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		# Get product woo data
		self._product_images = {}
		# product_woo_data = self.api(f'products/{product_id}')

		# Update name, description, tag, status
		convert_product = self.product_to_woocommerce_data(product)
		if convert_product.result != Response.SUCCESS:
			return convert_product
		update_data = convert_product.data

		response = self.api('products/' + to_str(product_id), update_data, 'Put')
		check_response = self.check_response_import(product, response)
		if check_response.result != Response().SUCCESS:
			return check_response
		try:
			woo_images = response['images']
			images = list()
			if product.thumb_image.url:
				main_image = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
				# check_image = self.image_exist(main_image['url'])
				# if check_image:
				images.append(main_image['url'])
			for img_src in product.images:
				image_process = self.process_image_before_import(img_src.url, img_src.path)
				# check_image = self.image_exist(image_process['url'])
				# if check_image:
				images.append(image_process['url'])
			if to_int(self._state.channel.config.api.limit_image):
				images = images[0:to_int(self._state.channel.config.api.limit_image)]
			if images and woo_images:
				for index, image in enumerate(woo_images):
					self._product_images[images[index]] = image['id']
		except:
			self.log_traceback('woo_images')
		# Update variant price, inventory etc..
		if product.variants:
			channel_id = self._state.channel.id
			for variant in product.variants:
				variant_id = variant['channel'].get(f'channel_{channel_id}', {}).get('product_id')
				if not variant_id:
					create_variant = self.create_variant(product_id, variant, product)
					if create_variant.result != Response.SUCCESS:
						return create_variant
					self.insert_map_product(variant, variant['_id'], create_variant.data)
					continue
				is_variant_removed = variant['channel'].get(f'channel_{self.get_channel_id()}', {}).get('is_variant_removed')
				if is_variant_removed:
					response = self.api(f'products/{product_id}/variations/{variant_id}', api_type = 'delete')
					if self._last_status <300:
						self.product_deleted(variant['_id'], variant, self.get_channel_id())

					continue

				convert_variant = self.product_to_woocommerce_data(variant, product, is_variant = True)
				if convert_variant.result != Response.SUCCESS:

					return convert_variant
				variant_update_data = convert_variant.data
				response = self.api(f'products/{product_id}/variations/{variant_id}', variant_update_data, 'Put')
				if self._last_status == 400 and response.code == 'woocommerce_rest_product_variation_invalid_id':
					create_variant = self.create_variant(product_id, variant, product)
					if create_variant.result != Response.SUCCESS:
						continue
					self.update_map_product(variant, variant['_id'], create_variant.data)
					continue
		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		if self.is_sync_product_invisible(product):
			update_data = {
				"status": "private"
			}
			response = self.api('products/' + to_str(product_id), update_data, 'Put')
			check_response = self.check_response_import(product, response)
			if check_response.result != Response().SUCCESS:
				return check_response
			return Response().success()
		update_data = {
			'regular_price': to_str(round(to_decimal(product.price), 2)),
			'stock_quantity': to_int(product.qty),
			'stock_status': 'instock' if to_int(product.qty) > 0 else 'outofstock',
			'name': product.name,
			'description': product.description,
		}
		if not self.is_setting_sync_title():
			del update_data['name']
		if not self.is_setting_sync_description():
			del update_data['description']
		if not setting_qty:
			del update_data['stock_quantity']
			del update_data['stock_status']
		if not setting_price:
			del update_data['regular_price']
		response = self.api('products/' + to_str(product_id), update_data, 'Put')
		check_response = self.check_response_import(product, response)
		if check_response.result != Response().SUCCESS:
			return check_response
		for variant in product.variants:
			if not variant['channel'].get(f'channel_{self.get_channel_id()}', {}):
				continue
			variant_data = variant['channel'][f'channel_{self.get_channel_id()}']
			variant_id = variant_data.variant_id or variant_data.product_id
			if not variant_id:
				create_variant = self.create_variant(product_id, variant, product)
				if create_variant.result != Response.SUCCESS:
					return create_variant
				self.insert_map_product(variant, variant['_id'], create_variant.data)
				continue
			variant_update_data = {
				'regular_price': to_str(round(to_decimal(variant.price), 2)),
				'stock_quantity': to_int(variant.qty),
				'stock_status': 'instock' if to_int(variant.qty) > 0 else 'outofstock',
			}
			if not setting_qty:
				del variant_update_data['stock_quantity']
				del variant_update_data['stock_status']
			if not setting_price:
				del variant_update_data['regular_price']
			response = self.api(f'products/{product_id}/variations/{variant_id}', variant_update_data, 'Put')
			check_response = self.check_response_import(product, response)
			if self._last_status == 400 and response.code == 'woocommerce_rest_product_variation_invalid_id':
				create_variant = self.create_variant(product_id, variant, product)
				if create_variant.result != Response.SUCCESS:
					continue
				self.update_map_product(variant, variant['_id'], create_variant.data)
				continue
			if check_response.result != Response().SUCCESS:
				return check_response

		return Response().success()


	# orders
	def get_orders_main_export(self):
		limit_data = self._state.pull.setting.orders
		id_src = self._state.pull.process.orders.id_src
		imported = self._state.pull.process.products.imported

		start_time = self.get_order_start_time('%Y-%m-%dT%H:%M:%S')
		last_modifier = self._state.pull.process.orders.max_last_modified
		params = {
			"after": start_time,
			'per_page': limit_data,
			'order': 'asc',
			"orderby": "modified"
		}
		if last_modifier:
			params['modified_after'] = f'{last_modifier}'
		if imported:
			params['offset'] = imported
		orders = self.api(path = "orders", params = params)
		if not orders:
			return Response().finish()
		last_order = orders[-1]
		self._last_order_created_at = to_str(last_order.date_created).replace('T', ' ')
		return Response().success(data = orders)


	def get_orders_ext_export(self, orders):
		extend = Prodict()
		for order in orders:
			order_id = to_str(order.id)
			extend[to_str(order_id)] = order
		return Response().success(extend)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	def set_imported_order(self, imported):
		super().set_imported_order(imported)
		self._state.pull.process.orders.created_at = self._last_order_created_at


	def convert_order_status(self, status):
		if self._state.channel.config.api.convert_order_status:
			return self._state.channel.config.api.convert_order_status
		order_status = {
			"pending": Order.OPEN,
			"processing": Order.SHIPPING,
			"on-hold": Order.OPEN,
			"completed": Order.COMPLETED,
			"shipped": Order.SHIPPING,
			"delivered": Order.COMPLETED,
			"marketplace": Order.COMPLETED,
			"refunded": Order.REFUNDED,
			"cancelled": Order.CANCELED,
			"failed": Order.CANCELED,
			"trash": Order.CANCELED,
		}
		if self._state.channel.config.api.custom_convert_order_status:
			order_status.update(self._state.channel.config.api.custom_convert_order_status)
		return_order_status = order_status.get(status, 'open') if status else 'open'
		if self._state.channel.config.api.mapping_order_status:
			return self._state.channel.config.api.mapping_order_status.get(status, return_order_status)
		return order_status.get(status, 'open') if status else 'open'


	def tracking_by_printful_tracking_company(self, tracking, order):
		"""the seller needs to add printful_tracking_company to every order
		the tracking_url field is not required
		"""
		shipment = Shipment()
		printful_tracking_number = get_row_value_from_list_by_field(order.meta_data, 'key', 'printful_tracking', 'value')
		printful_tracking_company = get_row_value_from_list_by_field(order.meta_data, 'key', 'printful_tracking_company', 'value')
		printful_tracking_url = get_row_value_from_list_by_field(order.meta_data, 'key', 'printful_tracking_url', 'value')
		if printful_tracking_number:
			shipment.tracking_number = printful_tracking_number

		if printful_tracking_company:
			shipment.tracking_company_code = printful_tracking_company
			shipment.tracking_company = printful_tracking_company

		if printful_tracking_url:
			shipment.tracking_url = printful_tracking_url

		return shipment

	def tracking_by_wc_shipment_tracking_items(self, tracking, order):
		shipment = Prodict()
		shipping_info = tracking[0]
		shipment.tracking_number = shipping_info.tracking_number or shipping_info.custom_tracking_number
		shipment.tracking_company_code = shipping_info.tracking_product_code or shipping_info.tracking_provider or shipping_info.custom_tracking_provider
		shipment.tracking_url = shipping_info.tracking_link or shipping_info.custom_tracking_link
		shipment.tracking_company = shipping_info.tracking_product_code or shipping_info.tracking_provider or shipping_info.custom_tracking_provider
		return shipment


	def tracking_by_wc_connect_labels(self, tracking, order):
		shipment = Prodict()
		shipping_info = tracking[0]
		if shipping_info.tracking:
			shipment.tracking_number = shipping_info.tracking
			shipment.tracking_company_code = shipping_info.carrier_id
			shipment.tracking_company = shipping_info.service_name
		return shipment

	def tracking_by_linnworks_tracking_provider(self, tracking, order):
		shipment = Shipment()
		linnworks_tracking_provider = get_row_value_from_list_by_field(order.meta_data, 'key', 'linnworks_tracking_provider', 'value')
		if linnworks_tracking_provider:
			shipment.tracking_company_code = linnworks_tracking_provider
			shipment.tracking_company = linnworks_tracking_provider
		linnworks_tracking_number = get_row_value_from_list_by_field(order.meta_data, 'key', 'linnworks_tracking_number', 'value')
		if linnworks_tracking_number:
			shipment.tracking_number = linnworks_tracking_number
		linnworks_tracking_url = get_row_value_from_list_by_field(order.meta_data, 'key', 'linnworks_tracking_url', 'value')
		if linnworks_tracking_url:
			shipment.tracking_url = linnworks_tracking_url
		return shipment


	def custom_tracking(self, metadata):
		if not self._state.channel.config.api.custom_tracking:
			return {}
		shipment = Prodict()
		custom_tracking = self._state.channel.config.api.custom_tracking
		carrier_tracking_code = custom_tracking.get('carrier_code')
		carrier_tracking_name = custom_tracking.get('carrier_name')
		tracking_number_code = custom_tracking.get('number')
		tracking_url_code = custom_tracking.get('url')
		fields = {
			'tracking_number': tracking_number_code,
			'tracking_url': tracking_url_code,
			'tracking_company_code': carrier_tracking_code,
			'tracking_company': carrier_tracking_name,
		}
		for field, code in fields.items():
			value = get_row_value_from_list_by_field(metadata, 'key', code, 'value')
			if value:
				shipment[field] = value
		return shipment


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.date_modified)

		order_data = Order()
		if self._state.channel.config.api.financial_status:
			order_data.financial_status = self._state.channel.config.api.financial_status
		if self._state.channel.config.api.fulfillment_status:
			order_data.fulfillment_status = self._state.channel.config.api.fulfillment_status
		order_data.order_number = order.number
		order_data.status = self.convert_order_status(order.status)
		order_data.tax.amount = to_decimal(order.total_tax)
		order_data.discount.amount = to_decimal(order.discount_total)
		has_tracking = False
		# plugin Germanized Tracking
		if order.shipments:
			try:
				shipment = order.shipments[0]
				if shipment.shipping_provider:
					order_data.shipments.tracking_company = shipment.shipping_provider
					order_data.shipments.tracking_company_code = shipment.shipping_provider
					order_data.shipments.tracking_url = shipment.tracking_url
					order_data.shipments.tracking_number = shipment.tracking_id
					has_tracking = True
			except:
				log_traceback()
				has_tracking = False
		if not has_tracking:
			shipping_meta = ['_wc_shipment_tracking_items', 'wc_connect_labels', 'linnworks_tracking_provider', 'printful_tracking_company']
			for shipping_key in shipping_meta:
				metadata = get_row_value_from_list_by_field(order.meta_data, 'key', shipping_key, 'value')
				if metadata:
					function = f"tracking_by_{shipping_key.strip('_')}"
					if hasattr(self, function):
						try:

							tracking = getattr(self, function)(metadata, order)
							if tracking.tracking_company or tracking.tracking_company_code:
								order_data.shipments.update(tracking)
								has_tracking = True

						except Exception:
							self.log_traceback('order_tracking', metadata)
							has_tracking = False
		if not has_tracking:
			if self._state.channel.config.api.custom_tracking_provider:
				order_data.shipments.tracking_company = self._state.channel.config.api.custom_tracking_provider
				order_data.shipments.tracking_company_code = self._state.channel.config.api.custom_tracking_provider
			tracking_number = get_row_value_from_list_by_field(order.meta_data, 'key', '_tracking_number', 'value')
			if tracking_number:
				order_data.shipments.tracking_number = tracking_number
				has_tracking = True
			_tracking_url = get_row_value_from_list_by_field(order.meta_data, 'key', '_tracking_url', 'value')
			if _tracking_url:
				order_data.shipments.tracking_url = _tracking_url
			_tracking_provider = get_row_value_from_list_by_field(order.meta_data, 'key', '_tracking_provider', 'value')
			if _tracking_provider:
				order_data.shipments.tracking_company = _tracking_provider

		if not has_tracking:
			tracking = self.custom_tracking(order.meta_data)
			if tracking:
				order_data.shipments.update(tracking)

		if order.coupon_lines:
			order_data.discount.code = order['coupon_lines'][0]['code']
			order_data.discount.title = order['coupon_lines'][0]['code']
		if order.shipping_lines:
			order_data.shipping.title = order['shipping_lines'][0]['method_title']
			order_data.shipping.amount = order['shipping_lines'][0]['total']
		# order_data.subtotal = order.subtotal_price
		order_data.total = order.total
		order_data.currency = order.currency
		order_data.created_at = order['date_created'].replace('T', ' ')
		order_data.updated_at = order['date_modified'].replace('T', ' ')
		order_data.channel_data = {
			'order_status': order.status,
			'created_at': order_data.created_at
		}
		if order.customer_id:
			customer_data = self.api(path = "customers/" + to_str(order.customer_id))
			if customer_data:
				order_data.customer.id = customer_data.id
				order_data.customer.email = customer_data.email
				order_data.customer.first_name = customer_data.first_name
				order_data.customer.last_name = customer_data.last_name
				if customer_data.billing:
					order_data.customer_address.first_name = customer_data.billing.first_name
					order_data.customer_address.last_name = customer_data.billing.last_name
					order_data.customer_address.address_1 = customer_data.billing.address_1
					order_data.customer_address.address_2 = customer_data.billing.address_2
					order_data.customer_address.city = customer_data.billing.city
					order_data.customer_address.country.country_code = customer_data.billing.country
					order_data.customer_address.state.state_code = customer_data.billing.state
					order_data.customer_address.postcode = customer_data.billing.postcode
					order_data.customer_address.telephone = customer_data.billing.phone
					order_data.customer_address.company = customer_data.billing.company
		if order.customer_note:
			order_history = OrderHistory()
			order_history.comment = order.customer_note
			order_data.history.append(order_history)
		if order.billing:
			order_data.billing_address.first_name = order.billing.first_name
			order_data.billing_address.last_name = order.billing.last_name
			order_data.billing_address.address_1 = order.billing.address_1
			order_data.billing_address.address_2 = order.billing.address_2
			order_data.billing_address.city = order.billing.city
			order_data.billing_address.country.country_code = order.billing.country
			order_data.billing_address.state.state_code = order.billing.state
			order_data.billing_address.postcode = order.billing.postcode
			order_data.billing_address.telephone = order.billing.phone
			order_data.billing_address.company = order.billing.company
		if order.shipping:
			order_data.shipping_address.first_name = order.shipping.first_name
			order_data.shipping_address.last_name = order.shipping.last_name
			order_data.shipping_address.address_1 = order.shipping.address_1
			order_data.shipping_address.address_2 = order.shipping.address_2
			order_data.shipping_address.city = order.shipping.city
			order_data.shipping_address.country.country_code = order.shipping.country
			order_data.shipping_address.state.state_code = order.shipping.state
			order_data.shipping_address.postcode = order.shipping.postcode
			order_data.shipping_address.company = order.shipping.company
		if order.payment_method:
			order_data.payment.method = order.payment_method
		if order.payment_method_title:
			order_data.payment.title = order.payment_method_title
		for item in order.line_items:
			order_item = OrderProducts()
			order_item.id = item.id
			sub_total = to_decimal(item.subtotal)
			if item.variation_id:
				order_item.is_variant = True

			order_item.product_id = item.variation_id if item.variation_id else item.product_id
			order_item.listing_id = item.product_id
			order_item.product_name = item.name
			order_item.product_sku = item.sku
			order_item.qty = item.quantity
			order_item.price = item.price
			if not sub_total:
				sub_total = to_decimal(item.price)
			order_item.original_price = round(sub_total / to_int(item.quantity), 2)
			if item.taxes and item.tax_lines:
				tax_amount = 0
				for row in item.tax_lines:
					tax_amount += to_decimal(row.total)
				order_item.tax_amount = tax_amount
			order_item.subtotal = sub_total
			order_data.products.append(order_item)
			if not has_tracking:
				try:
					# plugin wot order
					vi_wot_order_item_tracking_data = get_row_value_from_list_by_field(item.meta_data, 'key', '_vi_wot_order_item_tracking_data', 'value')
					if vi_wot_order_item_tracking_data and json_decode(vi_wot_order_item_tracking_data):
						vi_wot_order_item_tracking_row = json_decode(vi_wot_order_item_tracking_data)[0]
						order_data.shipments.tracking_company = vi_wot_order_item_tracking_row.get('carrier_name')
						order_data.shipments.tracking_company_code = vi_wot_order_item_tracking_row.get('carrier_name')
						order_data.shipments.tracking_number = vi_wot_order_item_tracking_row.get('tracking_number')
						order_data.shipments.tracking_url = to_str(vi_wot_order_item_tracking_row.get('carrier_url')).replace('{tracking_number}', vi_wot_order_item_tracking_row.get('tracking_number'))
						has_tracking = True
				except Exception:
					self.log_traceback('wot_order')
		try:
			if not has_tracking and order.shipping_lines:
				# plugin ChitChats tracking
				for shipping_line in order.shipping_lines:
					if not shipping_line.meta_data:
						continue
					tracking_carrier = ''
					tracking_carrier_code = ''
					tracking_number = ''
					tracking_url = ''
					for metadata in shipping_line.meta_data:
						if metadata.get('key') == 'Shipping Carrier':
							tracking_carrier_code = metadata['value']
							tracking_carrier = metadata.get('display_value') or metadata['value']
						if metadata.get('key') == 'Tracking Code':
							tracking_number = metadata.get('value')
						if metadata.get('key') == 'Tracking Url':
							tracking_url = metadata.get('value')
					if tracking_carrier or tracking_carrier_code:
						has_tracking = True
						order_data.shipments.tracking_company = tracking_carrier or tracking_carrier_code
						order_data.shipments.tracking_company_code = tracking_carrier_code
						order_data.shipments.tracking_number = tracking_number
						order_data.shipments.tracking_url = tracking_url
						break
		except Exception:
			self.log_traceback()
		if self._state.channel.config.api.custom_tags:
			order_data.tags = self._state.channel.config.api.custom_tags
		if self._state.channel.config.api.custom_order_email:
			order_data.custom_order_email = self._state.channel.config.api.custom_order_email
		if order_data.status == Order.COMPLETED and self._state.channel.config.api.shippit_tracking and not has_tracking:
			private_notes = self.api(f"orders/{order.id}/notes")
			if self._last_status < 300:
				for note in private_notes:
					if has_tracking:
						break
					if note.note.find('Order Synced with Shippit') != -1:
						tracking_number = note.note.split(':')[-1].strip('. ')
						order_data.shipments.tracking_number = tracking_number
						has_tracking = True
					if note.note.find('This order has been shipped with') != -1:
						tracking_info = re.findall('This order has been shipped with: (.*). The Tracking Number is: (.*). The Url is: (.*)', note.note)
						if to_len(tracking_info) == 3:
							order_data.shipments.tracking_number = tracking_info[1]
							order_data.shipments.tracking_url = tracking_info[2]
							order_data.shipments.tracking_company = tracking_info[0]
							has_tracking = True
		if not has_tracking and order_data.status == Order.COMPLETED and self._state.channel.config.api.shipstation:
			regex = self._state.channel.config.api.shipstation.regex
			shipments = self._state.channel.config.api.shipstation.shipments
			private_notes = self.api(f"orders/{order.id}/notes")
			if self._last_status < 300:
				for note in private_notes:
					if has_tracking:
						break
					tracking_infos = re.findall(regex, note.note)
					if tracking_infos:
						tracking_info = tracking_infos[0]
						if to_len(tracking_info) == to_len(shipments):
							for index, field in enumerate(shipments):
								order_data.shipments[field] = tracking_info[index]
								has_tracking = True
		return Response().success(order_data)


	def get_order_by_id(self, order_id):
		order = self.api(path = f"orders/{order_id}")
		if not order:
			return Response().error(msg = "WOO GET ORDER FAIL")
		return Response().success(data = order)


	def custom_order_status(self, order_status, order: Order):
		if order_status == 'completed':
			order_status = self.get_order_completed_status()
		if not self._state.channel.config.api.custom_order_status:
			return order_status
		custom_order_status = self._state.channel.config.api.custom_order_status.get(order_status, order_status)
		if custom_order_status == '_channel_type_':
			return order.channel_type or order_status
		return custom_order_status


	def is_order_vat_exempt(self):
		return bool(self._state.channel.config.api.tax_exempt == 'yes')


	def order_import(self, order: Order, convert: Order, orders_ext):

		status = self.ORDER_STATUS.get(convert['status'], 'on-hold')
		status = self.custom_order_status(status, convert)
		channel_name = convert.channel_name or 'litcommerce'
		post_data = {
			'status': status,
			'currency': convert.currency or 'USD',
			'meta_data': [
				{'key': '_litc_new_order', 'value': 1},
				{'key': '_litc_order_from', 'value': channel_name},
				{'key': '_litc_order_id', 'value': convert['_id']},
				# {'key': '_litc_order_number', 'value': convert.channel_order_number or convert.order_number},
				{'key': 'is_vat_exempt', 'value': 'yes'},

			]
		}
		if self.is_order_vat_exempt():
			post_data['meta_data'].append({'key': 'is_vat_exempt', 'value': 'yes'})
		if self._state.channel.config.api.order_completed_meta_data:
			post_data['meta_data'].extend(self._state.channel.config.api.order_completed_meta_data)

		shipping_method = convert.shipping.title or convert.shipping.method
		if shipping_method:
			post_data['meta_data'].append({'key': '_shipping_method', 'value': shipping_method})
		if not self._state.channel.config.api.skip_order_number:
			post_data['meta_data'].append({'key': '_litc_order_number', 'value': convert.channel_order_number})
		if convert.order_number_prefix:
			post_data['meta_data'].append({'key': '_litc_order_number_prefix', 'value': convert.order_number_prefix})
		if convert.order_number_suffix:
			post_data['meta_data'].append({'key': '_litc_order_number_suffix', 'value': convert.order_number_suffix})
		if convert.send_email:
			post_data['meta_data'].append({'key': '_litc_allow_send_email', 'value': 1})
		else:
			post_data['meta_data'].append({'key': '_litc_allow_send_email', 'value': 2})
		if convert.send_email_owner:
			post_data['meta_data'].append({'key': '_litc_allow_send_email_owner', 'value': 1})
		else:
			post_data['meta_data'].append({'key': '_litc_allow_send_email_owner', 'value': 2})
		if convert.additional_details:
			for row in convert.additional_details:
				post_data['meta_data'].append({'key': row.name, 'value': row.value})
		if convert['status'] == Order.COMPLETED:
			completed_metadata = [
				{'key': '_tracking_provider', 'value': convert.shipments.tracking_company},
				{'key': '_tracking_number', 'value': convert.shipments.tracking_number},
				{'key': '_tracking_url', 'value': convert.shipments.tracking_url},
				{'key': '_wc_shipment_tracking_items', 'value': [{
					"tracking_provider": convert.shipments.tracking_company,
					"tracking_number": convert.shipments.tracking_number,
					"tracking_product_code": "",
					"date_shipped": time.time()
				}]},
				{'key': 'ts_shipment_status', 'value': [{'status': 'delivered'}]},

			]
			post_data['meta_data'].extend(completed_metadata)
		# Billing and shipping
		billing_data = {
			'first_name': convert.billing_address.first_name or '',
			'last_name': convert.billing_address.last_name or '',
			'company': convert.billing_address.company or '',
			'address_1': convert.billing_address.address_1 or '',
			'address_2': convert.billing_address.address_2 or '',
			'city': convert.billing_address.city or 'City',
			'postcode': convert.billing_address.postcode or '',
			'country': convert.billing_address.country.country_code or '',
			'email': convert.customer.email,
			'phone': convert.billing_address.telephone or '',
		}
		state = convert.billing_address.state.state_code or convert.billing_address.state.state_name
		if state:
			billing_data['state'] = state

		shipping_data = {
			'first_name': convert.shipping_address.first_name or '',
			'last_name': convert.shipping_address.last_name or '',
			'company': convert.shipping_address.company or '',
			'address_1': convert.shipping_address.address_1 or '',
			'address_2': convert.shipping_address.address_2 or '',
			'city': convert.shipping_address.city or 'City',
			'state': convert.shipping_address.state.state_code or '',
			'postcode': convert.shipping_address.postcode or '',
			'phone': convert.shipping_address.telephone or '',
			'country': convert.shipping_address.country.country_code or convert.shipping_address.state.state_name,
		}
		post_data['billing'] = billing_data
		post_data['shipping'] = shipping_data

		# note
		comment = ''
		for history in convert.history:
			if history['comment'] and not history.staff_note:
				comment += self.clear_tags(to_str(history['comment']).replace('<br />', '\n'))
		post_data['customer_note'] = comment

		# tax
		fee_lines = list()
		if convert.tax.amount and to_decimal(convert.tax.amount) > 0:
			fee_lines.append({
				'name': 'TAX',
				'total': to_str(to_decimal(convert.tax.amount, 2)),
				'tax_class': self.check_zero_tax_class()
			})
		# discount
		if convert.discount.amount and (abs(to_decimal(convert.discount.amount)) > 0):
			title = 'Discount'
			if convert.discount.code:
				title += f'({convert.discount.code})'
			fee_lines.append({
				'name': title,
				'total': f'-{to_str(abs(to_decimal(convert.discount.amount, 2)))}',
				'tax_class': self.check_zero_tax_class()
			})
		if convert.gift_wrap_price:
			fee_lines.append({
				'name': 'Gift Wrap Price',
				'total': f'{to_str(convert.gift_wrap_price)}',
				'tax_class': self.check_zero_tax_class()
			})
		if convert.handling_cost:
			fee_lines.append({
				'name': 'Handling Cost',
				'total': f'{to_str(convert.handling_cost)}',
				'tax_class': self.check_zero_tax_class()
			})
		shipping_line = True
		if not self._state.channel.config.api.order_custom_shipping:

			if convert.shipping.amount and to_decimal(convert.shipping.amount) > 0:
				shipping_line = False

				name = 'Shipping'
				if shipping_method:
					name += f' ({shipping_method})'
				fee_lines.append({
					'name': name,
					'total': to_str(to_decimal(convert.shipping.amount)),
					'tax_class': self.check_zero_tax_class()
				})

		if shipping_line:
			post_data['shipping_lines'] = list()
			ship_lines = dict()
			ship_lines['method_title'] = shipping_method
			ship_lines['total'] = to_str(to_decimal(convert.shipping.amount))
			ship_lines['method_id'] = 'flat_rate' if to_decimal(convert.shipping.amount) > 0 else 'free_shipping'
			post_data['shipping_lines'].append(ship_lines)
		if fee_lines:
			post_data['fee_lines'] = fee_lines
		if self._state.channel.config.api.order_custom_payment_method:
			post_data['payment_method'] = self._state.channel.config.api.order_custom_payment_method
		# shipping

		# customer
		# customer_email = convert.customer.email
		# if customer_email:
		# 	check_customer = self.api('customers', params = {'email': customer_email})
		# 	if check_customer:
		# 		post_data['customer_id'] = check_customer[0]['id']
		# 	else:
		# 		customer_data = {
		# 			'first_name': convert.customer.first_name or convert.billing_address.first_name or convert.shipping_address.first_name,
		# 			'last_name': convert.customer.last_name or convert.billing_address.last_name or convert.shipping_address.last_name,
		# 			'email': convert.customer.email,
		# 			'username': convert.customer.email
		# 		}
		# 		billing_data = {
		# 			'first_name': convert.billing_address.first_name or '',
		# 			'last_name': convert.billing_address.last_name or '',
		# 			'company': convert.billing_address.company or '',
		# 			'address_1': convert.billing_address.address_1 or '',
		# 			'address_2': convert.billing_address.address_2 or '',
		# 			'city': convert.billing_address.city or 'City',
		# 			'state': convert.billing_address.state.state_code or '',
		# 			'postcode': convert.billing_address.postcode or '',
		# 			'phone': convert.billing_address.telephone or '',
		# 			'country': convert.billing_address.country.country_code or '',
		# 		}
		# 		shipping_data = {
		# 			'first_name': convert.shipping_address.first_name or '',
		# 			'last_name': convert.shipping_address.last_name or '',
		# 			'company': convert.shipping_address.company or '',
		# 			'address_1': convert.shipping_address.address_1 or '',
		# 			'address_2': convert.shipping_address.address_2 or '',
		# 			'city': convert.shipping_address.city or 'City',
		# 			'state': convert.shipping_address.state.state_code or '',
		# 			'postcode': convert.shipping_address.postcode or '',
		# 			'phone': convert.shipping_address.telephone or '',
		# 			'country': convert.shipping_address.country.country_code or '',
		# 		}
		# 		customer_data['billing'] = billing_data
		# 		customer_data['shipping'] = shipping_data
		# 		customer_post = self.api('customers', data = customer_data, api_type = 'post')
		# 		if customer_post:
		# 			post_data['customer_id'] = customer_post['id']

		# items
		order_items = list()
		have_tax = False
		for row in convert.products:
			product_id = None
			variant_id = None
			if row['product_id'] and row['parent_id']:
				variant_id = row['product_id']
				if row.get('product'):
					channel_data = row['product']['channel'][f'channel_{self.get_channel_id()}']
					if channel_data.get('variant_id'):
						variant_id = channel_data['variant_id']
				product_id = row['parent_id']
			else:
				product_id = row.get('product_id')
			subtotal = self.get_line_item_price(to_int(row.qty) * to_decimal(row.price, 2))
			item_data = {
				'name': to_str(row.product_name),
				'product_id': product_id if product_id else 0,
				'quantity': to_int(row['qty']) if to_int(row.qty) > 0 else 1,
				'subtotal': subtotal,
				'total': subtotal,
				# 'tax_class': self.check_zero_tax_class()
			}
			if not item_data.get('product_id'):
				item_data['sku'] = row['product_sku'] or f'unknown_{time.time()}'
			if self.is_order_vat_exempt():
				item_data['tax_class'] = self.check_zero_tax_class()
			custom_tax_rate = to_decimal(self._state.channel.config.api.order_tax_rate)
			if not custom_tax_rate:
				item_data.update({
					'subtotal': subtotal,
					'total': subtotal,
					'tax_class': self.check_zero_tax_class()
				})
			else:
				total = to_decimal(to_decimal(subtotal) * 100 / (100 + custom_tax_rate), 2)
				item_data.update({
					'subtotal': to_str(total),
					'total': to_str(total),
				})
			if variant_id:
				item_data['variation_id'] = variant_id
			meta_data = list()

			if row.options:
				for option in row.options:
					if to_str(option.option_name).lower() != 'personalization':
						continue
					meta_data.append({
						'key': option.option_name,
						'value': option.option_value_name,
					})

			if row.tax_amount:
				have_tax = True
				meta_data.append({
					'key': '_litc_item_tax',
					'value': to_str(row.tax_amount),
				})
			if meta_data:
				item_data['meta_data'] = meta_data
			# option_data = self.get_option_data(product_id, variant_id)
			# if option_data:
			# 	item_data['meta_data'] = option_data
			order_items.append(item_data)
		if not order_items or len(order_items) == 0:
			item = {
				'name': 'Product Name',
				'product_id': 0,
				'quantity': 1,
				'subtotal': to_str(round(to_decimal(convert['total']['amount']), 2)),
				'total': to_str(round(to_decimal(convert['total']['amount']), 2)),
			}
			order_items.append(item)
		post_data['line_items'] = order_items
		if have_tax:
			post_data['meta_data'].append({'key': '_litc_has_tax', 'value': '1'})
		response = self.api('orders', data = post_data, api_type = 'post')
		if self._last_status == 400 and to_str(response).find('rest_invalid_email') != -1:
			domain_email = post_data['billing']['email'].split('@')[1]
			new_email = f'unknown_{to_int(time.time())}@{domain_email}'
			post_data['billing']['email'] = new_email
			response = self.api('orders', data = post_data, api_type = 'post')

		check_response = self.check_response_import(response, convert, 'order')
		if check_response['result'] != 'success':
			return check_response
		id_desc = response['id']
		order_return = {
			'order_id': response['id'],
			'order_status': response['status'],
			'order_number': response['number'],
			'created_at': response['date_created'].replace('T', ' '),
		}
		return Response().success([id_desc, order_return])


	def get_option_data(self, parent_id, product_id):
		variant_data = self.api(f'products/{parent_id}/variations/{product_id}')
		if variant_data and variant_data.attributes:
			option_data = list()
			for attribute in variant_data.attributes:
				option_data.append({
					'key': attribute.name,
					'value': attribute.option,
				})
			return option_data
		else:
			self.log('Can not get child id: ' + to_str(product_id) + ' from product: ' + to_str(product_id))
			return None


	def order_completed(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.channel_order_completed(channel_order_id, order, current_order)


	def get_order_completed_status(self):
		return self._state.channel.config.api.order_completed_status or 'completed'


	def channel_order_completed(self, order_id, order: Order, current_order):
		if self.is_keep_order_status():
			return Response().error()
		completed_status = self.get_order_completed_status()
		woo_order = self.get_order_by_id(order_id)
		if woo_order.result != Response.SUCCESS:
			return Response().error()

		woo_order_data = woo_order.data
		woo_order_data_meta_data_keys = [row['key'] for row in woo_order_data['meta_data']]
		order_data = {
			"status": completed_status,
			"meta_data": []
		}
		meta_data = [
			{'key': '_tracking_provider', 'value': order.shipments.tracking_company},
			{'key': '_tracking_number', 'value': order.shipments.tracking_number},
			{'key': '_tracking_url', 'value': order.shipments.tracking_url},
			{'key': '_wc_shipment_tracking_items', 'value': [{
				"tracking_provider": order.shipments.tracking_company,
				"tracking_number": order.shipments.tracking_number,
				"tracking_product_code": "",
				"date_shipped": time.time()
			}]},
			{'key': 'ts_shipment_status', 'value': [{'status': 'delivered'}]},

		]
		if self._state.channel.config.api.order_completed_meta_data:
			meta_data.extend(self._state.channel.config.api.order_completed_meta_data)
		for row in meta_data:
			if row['key'] not in woo_order_data_meta_data_keys:
				order_data['meta_data'].append(row)
		self.api(f'orders/{order_id}', order_data, 'put')
		if self._last_status < 300:
			return_order = {"status": 'Completed'}
			return Response().success(return_order)
		return Response().error()

	def order_refunded(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.order_canceled(channel_order_id, order_id, order, current_order, setting_order)

	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		# if setting_order:
		# 	return Response().success()
		#
		# self._order_sync_inventory(order, '+')
		order_data = {
			"status": "cancelled"
		}
		self.api(f'orders/{channel_order_id}', order_data, 'put')
		if self._last_status < 300:
			return_order = {"status": 'cancelled'}

			return Response().success(return_order)
		return Response().error()


	def order_sync_inventory(self, convert: Order, setting_order):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			product_id = None
			variant_id = None
			if row['product_id'] and row['parent_id']:
				variant_id = row['product_id']
				product_id = row['parent_id']
			else:
				product_id = row.get('product_id')
			if row.get('sync_inventory') or row['link_status'] != 'linked' or not row.get('product'):
				continue
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1
				update_stock = False
				if variant_id:
					variant_data = self.api(f'products/{product_id}/variations/{to_str(variant_id)}')
					inventory_quantity = to_int(variant_data.stock_quantity)
					new_qty = to_int(inventory_quantity) - to_int(row_qty) if prefix == '-' else to_int(inventory_quantity) + to_int(row_qty)
					if new_qty < 0:
						new_qty = 0
					update_data = {
						'stock_quantity': new_qty
					}
					update_stock = self.api(path = f'products/{product_id}/variations/{to_str(variant_id)}', data = update_data, api_type = 'put')
				elif product_id:
					product_data = self.api(f'products/{product_id}')
					inventory_quantity = product_data.stock_quantity
					new_qty = to_int(inventory_quantity) - to_int(row_qty) if prefix == '-' else to_int(inventory_quantity) + to_int(row_qty)
					if new_qty < 0:
						new_qty = 0
					update_data = {
						'stock_quantity': new_qty
					}
					update_stock = self.api(path = f'products/{product_id}', data = update_data, api_type = 'put')
				if self._last_status < 300:
					row['sync_inventory'] = True
				else:
					message = update_stock.message if update_stock else "Something Error"
					row['sync_msg_error'] = message
		return Response().success(convert)


	def check_response_import(self, response, convert, entity_type = ''):
		# if self._last_status == 500:
		# 	return Response().error(code = Errors.WOOCOMMERCE_ERROR_500)

		product_id = convert.id if convert.id else convert.code
		if not response:
			return self.error_by_last_status()
		if 'code' in response and 'message' in response:
			if response['code'] == 'product_invalid_sku' and entity_type == 'product':
				return Response().error(code = Errors.WOOCOMMERCE_INVALID_SKU, msg = Errors().get_msg_error(Errors.WOOCOMMERCE_INVALID_SKU))
			elif response['code'] == 'woocommerce_rest_required_product_reference' and entity_type == 'order':
				return Response().error(code = Errors.WOOCOMMERCE_ID_OR_SKU_REQUIRED, msg = Errors().get_msg_error(Errors.WOOCOMMERCE_ID_OR_SKU_REQUIRED))
			else:
				console = list()
				if isinstance(response, dict) or isinstance(response, Prodict):
					for key, error in response.items():
						if isinstance(error, list):
							error_messages = ' '.join(error)
						else:
							error_messages = json.dumps(error)
						console.append(key + ': ' + error_messages)
				else:
					console.append(response['errors'])
				msg_errors = '::'.join(console)
				self.log(entity_type + ' id ' + to_str(product_id) + ' import failed. Error: ' + msg_errors,
				         "{}_errors".format(entity_type))
				return Response().error()
		else:
			return Response().success()


	def clear_tags(self, text_src):
		tag_re = re.compile(r'<[^>]+>')
		return tag_re.sub('', to_str(text_src))


	def get_category_by_name(self, category_name):
		all_categories = self.api('products/categories', params = {'per_page': 100, "search": category_name})
		if all_categories and self._last_status == 200:
			for category in all_categories:
				if to_str(category['name']).lower() == to_str(category_name).lower():
					return category['id']
		data = {
			'name': category_name,
			'parent': 0
		}
		response = self.api('products/categories', data, 'post')
		if response:
			if 'id' in response:
				return response['id']
			if self._last_status == 400 and response.get('code') == 'term_exists':
				return response['data']['resource_id']
		return None


	def get_all_attributes(self):
		if self._all_attributes:
			return self._all_attributes
		all_attributes = self.api('products/attributes')
		if self._last_status != 200:
			return False
		if all_attributes:
			for attr in all_attributes:
				self._all_attributes[attr['name']] = attr['id']
		return self._all_attributes


	def get_attribute_type(self):
		return self._state.channel.config.api.attribute_type or 'select'


	def get_attribute_by_name(self, attribute_name):
		all_attributes = self.get_all_attributes()
		if all_attributes is False:
			return False
		if all_attributes.get(attribute_name):
			return all_attributes.get(attribute_name)
		data = {
			"name": attribute_name,
			"slug": attribute_name_to_code(attribute_name).replace('_', '-'),
			"type": self.get_attribute_type(),
			"order_by": "menu_order",
			"has_archives": False
		}
		response = self.api('products/attributes', data, 'post')
		if response:
			if 'id' in response:
				self._all_attributes[attribute_name] = response['id']
				return response['id']
			elif 'code' in response and 'message' in response and 'is already in use' in response['message']:
				data['slug'] = attribute_name.lower() + to_str(to_int(time.time()))
				data['slug'] = data['slug'][0:28]
				response = self.api('products/attributes', data, 'post')
				if response:
					if 'id' in response:
						self._all_attributes[attribute_name] = response['id']
						return response['id']
		return None


	def check_coupon_exists(self, discount_code, discount_amount):
		all_coupons = self.api(path = 'coupons', data = {'code': discount_code})
		if all_coupons:
			for coupon in all_coupons:
				if coupon['code'] == discount_code and round(abs(to_decimal(coupon['amount'])), 2) == discount_amount and coupon['discount_type'] == 'percent':
					return True
		return None


	def create_coupon(self, discount_code, discount_amount):
		data = {
			"code": discount_code,
			"discount_type": 'percent',
			"amount": to_str(discount_amount),
		}
		response = self.api(path = 'coupons', data = data, api_type = 'post')
		if response and 'id' in response and 'code' in response:
			return response['code']
		return None


	def combination_from_multi_dict(self, data = None):
		if data is None:
			data = dict()
		data = list(data.values())
		result = list(product(*data))
		return result


	def set_channel_identifier(self):
		"""
		in api info there will be 1 information that is unique to a channel.

		:return:
		"""
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self.channel_url_to_identifier())
		return Response().success()


	def image_exist(self, url, path = ''):
		image_process = self.process_image_before_import(url, path)
		try:
			exist = requests.get(image_process['url'], headers = {"User-Agent": self.USER_AGENT}, timeout = 10, verify = False)
		except requests.exceptions.Timeout as errt:
			self.log("image " + image_process['url'] + 'connection timeout', self._type + '_image')
			return False
		except Exception as e:
			self.log_traceback('img_exist')
			return False
		return exist.status_code == requests.codes.ok


	def format_url(self, url, **kwargs):
		if not url:
			return ''
		char = ['wp-admin', 'wp-login.php']
		for row in char:
			url = url.split(row)[0]
		url = super(ModelChannelsWoo, self).format_url(url, **kwargs)
		return url


	def check_zero_tax_class(self):
		if self._zero_tax:
			return self._zero_tax
		all_tax_class = self.api('taxes/classes')
		if not isinstance(all_tax_class, list):
			all_tax_class = []

		for row in all_tax_class:
			if row['name'] == 'LitCommerce Zero Tax Class':
				self._zero_tax = row['slug']
				return self._zero_tax
		create = self.api('taxes/classes', data = {'name': 'LitCommerce Zero Tax Class'}, api_type = 'post')
		if create and create.get('slug'):
			self._zero_tax = create['slug']

			return create['slug']
		return ''


	def get_weight_units(self):
		if self._weight_units:
			return self._weight_units
		store = self.get_store_information()
		if not store:
			return 'oz'
		for row in store:
			if row['id'] == 'woocommerce_weight_unit':
				self._weight_units = row['value']
				if self._weight_units == 'lbs':
					self._weight_units = 'lb'
				return self._weight_units
		self._weight_units = 'oz'

		return self._weight_units


	def get_dimension_units(self):
		if self._dimension_units:
			return self._dimension_units
		store = self.get_store_information()
		if not store:
			return 'in'
		for row in store:
			if row['id'] == 'woocommerce_dimension_unit':
				self._dimension_units = row['value']
				return self._dimension_units
		self._dimension_units = 'in'

		return self._dimension_units


	def get_store_information(self):
		if self._store_information:
			return self._store_information
		store_information = self.api('settings/products')
		if self._last_status != 200 or not store_information:
			return False
		self._store_information = store_information
		return self._store_information


	def validate_channel_url(self):
		if not is_local():
			validate = self.channel_is_local_host()
			if validate.result != Response.SUCCESS:
				return validate
		return Response().success()


	def get_line_item_price(self, price):
		if self._state.channel.config.api.adjustment_line_item:
			adjustment_line_item = to_int(self._state.channel.config.api.adjustment_line_item)
			price += price * adjustment_line_item / 100
		return to_str(to_decimal(price, 2))


	def get_product_variants(self, product, offset = 0, per_page = 100):
		product_id = to_str(product.id)

		params = {
			'per_page': per_page,
			'order': 'asc',
			'orderby': 'id',

		}
		if offset:
			params['offset'] = offset
		# if product.status == 'publish':
		# 	params['status'] = 'publish'
		return self.api(f'products/{product_id}/variations', params = params)


	def get_all_product_variants(self, product):
		product_id = to_str(product.id)
		per_page = 100
		imported = 0
		variants = []
		total_variants = 0
		while True:
			variants_page = self.get_product_variants(product, offset = imported, per_page = per_page)
			if self._last_status != 200:
				return variants
			variants.extend(variants_page)
			if not total_variants:
				total_variants = to_int(self._last_header.get('x-wp-total'))
			imported += to_len(variants)
			if imported < per_page or imported >= total_variants:
				return variants


	def is_ignore_attributes(self):
		return self._state.channel.config.api.ignore_attributes


	def is_keep_order_status(self):
		return self._state.channel.config.api.keep_order_status


	def custom_ean_key(self):
		return self._state.channel.config.api.custom_ean_key


	def custom_identifier_key(self, field):
		return self._state.channel.config.api.get(f'custom_{field}_key')


	def sale_price_to_price(self):
		return self._state.channel.config.import_sale_price or self._state.channel.config.api.import_sale_price


	def display_finish_channel_pull(self):
		super().display_finish_channel_pull()
		# if is_local():
		# 	return Response().success()
		if self.is_refresh_process() and not self._state.channel.config.api.delete_webhook:
			webhooks = self.api('webhooks', params = {'status': 'active', 'per_page': 100})
			verify = {
				'order': False,
				'product': False
			}
			order_webhook_id = None
			product_webhook_id = None
			if webhooks:
				for hook in webhooks:
					if hook['delivery_url'].find(f'api/v1/merchant/woocommerce/webhook/{self.get_channel_id()}/order/update') != -1 and hook['topic'] == 'order.updated':
						if hook['status'] == 'active':
							verify['order'] = True
						else:
							if not order_webhook_id:
								order_webhook_id = hook['id']
					if hook['delivery_url'].find(f'api/v1/merchant/woocommerce/webhook/{self.get_channel_id()}/product/delete') != -1 and hook['topic'] == 'product.deleted':
						if hook['status'] == 'active':
							verify['product'] = True
						else:
							if not product_webhook_id:
								product_webhook_id = hook['id']
			events = dict()
			update_ids = []

			if not verify['order']:
				if order_webhook_id:
					update_ids.append(order_webhook_id)
				else:
					events[f"order.updated"] = f'order/update'
			if not verify['product']:
				if product_webhook_id:
					update_ids.append(product_webhook_id)
				else:
					events["product.deleted"] = 'product/delete'
			if not events and not update_ids:
				return Response().success()
			for webhook_id in update_ids:
				data_update = {"status": "active"}
				self.api(f'webhooks/{webhook_id}', data_update, api_type = 'put')
			webhook_secret = self._state.channel.config.api.webhook_secret or self._state.channel.config.api.consumer_secret
			for event, url in events.items():
				webhook_data = {
					"topic": event,
					"delivery_url": get_server_callback(f'merchant/woocommerce/webhook/{self.get_channel_id()}/{url}'),
					"name": "litCommerce Webhook - Don't Delete or edit",
					"secret": webhook_secret,
				}
				response = self.api(path = 'webhooks', data = webhook_data, api_type = 'post')
			self._state.channel.config.api.webhook_secret = webhook_secret
			self.update_channel(api = json_encode(self._state.channel.config.api))

		return Response().success()


	def get_brand_by_id(self, brand_id):
		brand_id = to_int(brand_id)
		if not brand_id:
			return ''
		if self._brands.get(brand_id):
			return self._brands[brand_id]
		brand = self.api(f'product_brand/{brand_id}', api_version = 'wp/v2')
		if self._last_status < 300:
			brand_name = brand['name']
			self._brands[brand_id] = brand['name']
			return brand_name
		return ''


	def clean_description(self, description):
		if not bool(BeautifulSoup(description, "html.parser").find()):
			return nl2br(description)
		try:
			soup = BeautifulSoup(unescape(description), "html.parser")
			for element in soup(['style']): element.extract()
			comments = soup.findAll(text = lambda t: isinstance(t, Comment))
			for comment in comments:
				comment.extract()
			return soup.prettify().replace('<br>', '').replace('<br/>', '').replace('<br/>', '').replace('\n','')
		except:
			return description