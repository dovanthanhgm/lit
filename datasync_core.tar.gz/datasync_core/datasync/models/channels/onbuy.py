import time

import barcodenumber
import requests

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import json_encode, get_config_ini, to_timestamp, convert_format_time, \
	get_current_time, to_int, to_str, to_decimal, log_traceback, log
from datasync.models.channel import ModelChannel
from datasync.models.constructs.order import Order, OrderProducts, OrderHistory, OrderHistoryStaff, OrderAddress
from datasync.models.constructs.product import Product, ProductSpecialPrice, ProductChannel, ProductImage, ProductAttribute
from datasync.libs.tracking_company import TrackingCompany


class ModelChannelsOnbuy(ModelChannel):
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category']

	cache_products = list()
	cache_warnings = dict()
	cache_errors = dict()
	parent_variants = dict()
	parent_products = dict()
	check_product = dict()
	onbuy_product_opc = dict()

	ORDER_STATUS = {
		'all': Order.OPEN,
		'awaiting dispatch': Order.READY_TO_SHIP,
		'awaiting_dispatch': Order.READY_TO_SHIP,
		'dispatched': Order.COMPLETED,
		'partially dispatched': Order.SHIPPING,
		'partially_dispatched': Order.SHIPPING,
		'completed': Order.COMPLETED,
		'canceled': Order.CANCELED,
		'cancelled by seller': Order.CANCELED,
		'cancelled_by_seller': Order.CANCELED,
		'cancelled_by_buyer': Order.CANCELED,
		'cancelled by buyer': Order.CANCELED,
		'partially_refunded': Order.REFUNDED,
		'partially refunded': Order.REFUNDED,
		'refunded': Order.REFUNDED
	}

	ONBUY_CONDITION_LISTING = {
		"New": "new",
		"Used (Excellent) (Used)": "excellent",
		"Used (Very Good) (Used)": "verygood",
		"Used (Good) (Used)": "good",
		"Used (Average) (Used)": "average",
		"Used (Below Average) (Used)": "belowaverage",
		"Refurbished (Diamond) (Refurbished)": "diamond",
		"Refurbished (Platinum) (Refurbished)": "platinum",
		"Refurbished (Gold) (Refurbished)": "gold",
		"Refurbished (Silver) (Refurbished)": "silver",
		"Refurbished (Bronze) (Refurbished)": "bronze",
		"Refurbished (Refurbished)": "refurbished-ungraded"
	}

	ONBUY_CONDITION = {
		1: "new",
		2: "excellent",
		3: "verygood",
		4: "good",
		5: "average",
		6: "belowaverage",
		7: "diamond",
		8: "platinum",
		9: "gold",
		10: "silver",
		11: "bronze",
		12: "refurbished-ungraded"
	}

	ONBUY_CONDITION_MAPPING = {
		1: "new",
		2: "used",
		3: "used",
		4: "used",
		5: "used",
		6: "used",
		7: "reconditioned",
		8: "reconditioned",
		9: "reconditioned",
		10: "reconditioned",
		11: "reconditioned",
		12: "reconditioned"
	}


	def __init__(self):
		super().__init__()


	def get_api_info(self):
		return {
			"seller_id": "Seller ID",
			"consumer_key": "Consumer key",
			"secret_key": "Secret key"
		}


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		response = self.api(f"/sites/{self.get_site_id()}")
		if response.result != Response().SUCCESS:
			return Response().error(msg = "Setup channel error.")
		return Response().success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self.get_seller_id())
		return Response().success()


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			# id_src_prd = self._state.pull.process.products.id_src
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.total = 0
			if not self._state.pull.process.products.id_src:
				self._state.pull.process.products.id_src = 0

			product_filter_condition = {}
			offset = self._state.pull.process.products.imported
			if offset:
				product_filter_condition['offset'] = offset
			if self._state.pull.setting.products:
				product_filter_condition['limit'] = self._state.pull.setting.products
			else:
				product_filter_condition['limit'] = get_config_ini('limit', 'products', '-1', file = 'local.ini')

			products = self.api('listings', data = product_filter_condition)
			if products .result == Response().SUCCESS:
				products_data = products.data
				self._state.pull.process.products.total = products_data['metadata']['total_rows']

		if self.is_order_process():
			offset = 0
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			start_time = self.get_order_start_time('%Y-%m-%d %H:%M:%S')
			last_modifier = self._state.pull.process.orders.max_last_modified
			order_filter_condition = {
				"limit": 50,
				"filter[status]": "all",
				"sort[created]": "desc"
			}
			if last_modifier:
				self.set_order_max_last_modifier(last_modifier)
			result = list()
			orders = self.api('orders', data = order_filter_condition)
			if orders.result == Response().SUCCESS:
				for order in orders.data['results']:
					last_update = last_modifier if last_modifier else start_time
					if order['date'] >= start_time and order['updated_at'] >= last_update:
						result.append(order)
				self._state.pull.process.orders.total = len(result)

		return Response().success()


	# products
	def get_products_main_export(self):
		params = dict()
		# if self._state.pull.setting.products:
		#     params['limit'] = self._state.pull.setting.products
		# else:
		#     params['limit'] = get_config_ini('limit', 'products', '-1', file='local.ini')
		params['limit'] = 10
		offset = self._state.pull.process.products.imported
		data = list()
		params['offset'] = offset
		products = self.api('listings', data = params)
		if products.result != Response().SUCCESS:
			return Response().finish(code = Errors.EXCEPTION, msg = "Can not get OnBuy's listings")
		for product in products.data['results']:
			data.append(product)
		return Response().success(data = data)


	def get_products_ext_export(self, products):
		data = dict()
		# get product description
		description_data = dict()
		variant_product = dict()
		variant_attributes = dict()
		attributes = dict()
		for product in products:
			opc = product.opc
			data = {
				"filter[query]": opc,
				"filter[field]": "opc"
			}
			product_info = self.api('products', data=data)
			if product_info.result != Response().SUCCESS:
				return Response().finish(code = Errors.EXCEPTION, msg = "Can not get OnBuy's listings info")
			if len(product_info.data['results']) == 0:
				description_data[opc] = ""
			else:
				description = product_info.data['results'][0]['description']
				description_data[opc] = description
				url = product_info.data['results'][0]['url']
				if "variant" in url:
					try:
						split_url = url.split("?")
						if len(split_url) > 1:
							parent_url = split_url[0]
							options = split_url[1].split("&")
							parent_onbuy_id = parent_url.split("~")[-1].split("p")[-1]
							if not variant_product.get(parent_onbuy_id):
								variant_product[parent_onbuy_id] = list()
							variant_product[parent_onbuy_id].append(opc)
							if not attributes.get(opc):
								attributes[opc] = list()
							if not variant_attributes.get(parent_onbuy_id):
								variant_attributes[parent_onbuy_id] = list()
							for i in range(1, len(options)):
								temp = options[i].split("=")
								attribute = {
									"attribute_name": temp[0],
									"attribute_value_name": temp[1]
								}
								variant_attributes[parent_onbuy_id].append(temp[0])
								attributes[opc].append(attribute)
					except Exception as e:
						log_traceback()
						continue
		data['description'] = description_data
		data['variant_product'] = variant_product
		data['variant_attributes'] = variant_attributes
		data['attributes'] = attributes

		# get product brand base on shop/company name
		# disable because the seller doesn't want to import their name to
		# the product brand

		# seller_id = self.get_seller_id()
		# seller = self.api(path = "sellers/" + str(seller_id))
		# if seller.result != Response().SUCCESS:
		# 	brand = "Unknown Brand"
		# else:
		# 	brand = seller.data['results']['company_name']
		# data['brand'] = brand

		# get product category path
		# categories = self.get_onbuy_categories(None)['data']
		# if not categories:
		# 	return Response().finish(code = Errors.EXCEPTION, msg = "Can not get OnBuy's listings categories")
		# category_path = dict()
		# category_path_list = dict()
		# for product in products:
		# 	category_path[product.opc] = list()
		# 	category_path_list[product.opc] = [None] * 10
		# 	log(product.product_url)
		# 	category_id = product.product_url.split("~")[1].split("c")[1]
		# 	parent_id = category_id
		# 	count = 0
		# 	while parent_id != "1" and count < 10:
		# 		count += 1
		# 		category = self.get_onbuy_categories(parent_id)['data'][0]
		# 		if not category:
		# 			continue
		# 		if parent_id != 1:
		# 			category_path[product.opc].insert(0, int(parent_id))
		# 		parent_id = category['parent_id']
		# 		index = category['level'] - 2
		# 		if index >= 0:
		# 			category_path_list[product.opc][index] = list()
		# 		for cate in categories:
		# 			if cate['parent_id'] == parent_id and index >= 0:
		# 				temp = {
		# 					"category_id": cate['category_id'],
		# 					"name": cate['name']
		# 				}
		# 				category_path_list[product.opc][index].insert(0, temp)

		# data['category_path'] = category_path
		# data['category_path_list'] = category_path_list

		return Response().success(data = data)


	def _convert_product_export(self, product, products_ext):
		product_attributes = products_ext['attributes']
		variant_product = products_ext['variant_product']
		description_data = products_ext['description']
		variant_attributes = products_ext['variant_attributes']
		brand = ''
		# category_path = products_ext['category_path'][product.opc]
		# category_path_list = products_ext['category_path_list'][product.opc]
		product_data = Product()
		if self.is_refresh_process():
			product_data.deny_update = ['brand']
		try:
			product_data.id = product.opc  # fix product id
			product_data.opc = product.opc
			product_data.brand = brand
			product_data.sku = product.sku
			product_data.name = product.name
			product_data.product_skus = product.group_sku
			product_data.price = product.price
			product_data.qty = product.stock
			product_data.condition = product.condition
			product_data.weight = product.delivery_weight
			product_data.seo_url = product.product_url
			product_data.ean = product.product_codes[0]
			product_data.created_at = product.created_at
			product_data.updated_at = get_current_time()
			product_data.imported_at = get_current_time()
			product_data.description = description_data[product.opc]

			image = ProductImage()
			image.url = product.image_url
			product_data.thumb_image = image

			sale = ProductSpecialPrice()
			sale.price = product.sale_price
			sale.start_date = product.sale_start_date
			sale.end_date = product.sale_end_date
			product_data.special_price = sale

			product_data.template_data['category'] = dict()
			product_data.template_data['category']['category'] = dict()
			product_data.template_data['category']['category']['category_path'] = []
			# product_data.template_data['category']['category']['category_path_list'] = list(filter(
			# 	lambda cate_list: cate_list is not None, category_path_list))
			product_data.template_data['category']['category']['category_id'] = ""
			if product.condition not in self.ONBUY_CONDITION_LISTING.keys():
				product_data.template_data['category']['condition'] = "new"
			else:
				product_data.template_data['category']['condition'] = self.ONBUY_CONDITION_LISTING[product.condition]
			# product_data.template_data['category']['brand'] = dict()
			# product_data.template_data['category']['brand']['value'] = brand
			shipping_template = dict()
			shipping_template['delivery_template_id'] = product.delivery_template_id
			shipping_template['warranty'] = product.get('warranty', 0)
			shipping_template['return_time'] = product.get('return_time', 0)
			shipping_template['handling_time'] = product.get('handling_time', 0)
			shipping_template['free_returns'] = 'yes' if product.get('free_returns', 0) else 'no'
			product_data.template_data['shipping'] = shipping_template
		
			for product_id in variant_product.keys():
				for variant_opc in variant_product[product_id]:
					if variant_opc == product.opc:
						parent_product = Product()
						parent_product.name = product.name
						parent_product.description = product_data.description
						parent_product.id = product_id
						parent_product.brand = product_data.brand
						parent_product.sku = product_id
						parent_product.variant_count = len(variant_product[product_id])
						parent_product.price = product_data.price
						parent_product.qty = product_data.qty
						parent_product.thumb_image.url = product_data.thumb_image.url
						parent_product.condition = product_data.condition
						parent_product.seo_url = product_data.seo_url
						parent_product.variant_attributes = variant_attributes[product_id]
						parent_product.template_data = product_data.template_data
						product_data.is_variant = True
						product_data.parent = parent_product
			
			attributes = None
			for key in product_attributes.keys():
				if product.opc == key:
					attributes = list()
					for option in product_attributes[key]:
						attribute = ProductAttribute()
						attribute.attribute_name = option['attribute_name']
						attribute.attribute_value_name = option['attribute_value_name']
						attribute.use_variant = True
						attribute.attribute_type = "select"
						attributes.append(attribute)
			if attributes:
				product_data.attributes = attributes

		except Exception as e:
			log_traceback()
			return Response().error(msg = "Pull product error")

		return Response().success(data = product_data)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.sku or product.product_listing_id

	def get_product_by_id(self, product_id):
		product_response = self.api(f'listings', data = {
			'filter[sku]': product_id
		})
		if product_response.result == Response().SUCCESS and product_response.data['results']:
			return Response().success(product_response.data['results'][0])

		return Response().error(msg = "Can not get product ID")


	def product_import(self, convert: Product, product, products_ext):
		if not product.variants:
			is_exist = self.check_product_exist(product)
			if is_exist.result != Response().SUCCESS:
				self.cache_errors[product['_id']].append("Could not check product " + str(product['_id']))
			else:
				self.check_product[product['_id']] = is_exist.data
			self.cache_products.append(product)
		else:
			self.parent_variants[product['_id']] = list()
			self.parent_products[product['_id']] = product
			for variant in product.variants:
				is_exist = self.check_product_exist(variant)
				if is_exist.result != Response().SUCCESS:
					self.cache_errors[variant['_id']].append("Could not check product " + str(variant['_id']))
				else:
					self.check_product[variant['_id']] = is_exist.data
				self.parent_variants[product['_id']].append(variant['_id'])
				if not variant.title:
					variant.title = product.title
				if not variant.description:
					variant.description = product.description
				self.cache_products.append(variant)
			# self.insert_map_product(product, product['_id'], product['id'])
		return Response().success()


	def addition_product_import(self):
		if not self.cache_products:
			return Response().success()
		self.cache_errors = {product["_id"]: [] for product in self.cache_products}
		self.cache_warnings = {product["_id"]: [] for product in self.cache_products}
		import_cache_product = True
		if not self.is_inventory_process():
			import_cache_product = self.import_cache_products()
		for product in self.cache_products:
			if not import_cache_product or self.cache_errors.get(product["_id"]):
				error = "\n".join(self.cache_errors[product["_id"]]) if self.cache_errors[product["_id"]] else "Don't submit feed"
				self.after_push_product(product['_id'], Response().error(msg = error), product)
				self.log(f'Error product_id {product["_id"]}: {error}', 'products')
			else:
				self.after_push_product(product['_id'], Response().success(), product)
			if self.cache_warnings.get(product["_id"]):
				for warning in self.cache_warnings[product["_id"]]:
					self.log(f'Warning {product["_id"]}: {warning}', 'products')
		for parent_id, variant_ids in self.parent_variants.items():
			if self.cache_errors.get(parent_id):
				self.after_push_product(parent_id, Response().error(msg = '_lic_nl_'.join(self.cache_errors.get(parent_id))), self.parent_products[parent_id])
				continue
			errors = list(filter(lambda x: self.cache_errors.get(x), variant_ids))
			if import_cache_product and not errors:
				self.after_push_product(parent_id, Response().success(), self.parent_products[parent_id])
				if self.is_inventory_process():
					self.update_qty_for_parent(parent_id)
			else:
				if not import_cache_product:
					msg_errors = "\n".join(self.cache_errors[errors[0]])
				else:
					msg_errors = \
						'You have {} variant{} import error'.format(len(errors), "s" if len(errors) > 1 else '')
				self.after_push_product(parent_id, Response().error(msg = msg_errors), self.parent_products[parent_id])

		self._state.push.process.products.error += len([1 for errors in self.cache_errors.values() if errors])
		self.cache_products = []
		return Response().success()


	def after_push_product(self, product_id, import_data, product: Product):
		if self.is_inventory_process():
			if import_data.result == Response.SUCCESS:
				update_field = dict()
				if self.is_setting_sync_qty():
					update_field[f"channel.channel_{self._state.channel.id}.qty"] = product.qty
				if self.is_setting_sync_price():
					update_field[f"channel.channel_{self._state.channel.id}.price"] = product.price
				if update_field:
					self.get_model_catalog().update(product_id, update_field)
			return Response().success(product)
		update_field = dict()
		product_channel_data = product['channel'][f'channel_{self._state.channel.id}']
		if import_data.result in (Response.ERROR, Response.WARNING):
			publish_status = ProductChannel.ERRORS
			msg = import_data.msg or Errors().get_msg_error(import_data.code)
			if not product_channel_data.get('product_id'):
				update_field[f"channel.channel_{self._state.channel.id}.status"] = ProductChannel.ERRORS
		else:
			msg = ''
			publish_status = ProductChannel.COMPLETED
			update_field[f"channel.channel_{self._state.channel.id}.edited"] = False
			update_field[f"channel.channel_{self._state.channel.id}.status"] = 'active'
			update_field[f"channel.channel_{self._state.channel.id}.product_id"] = product.sku
			update_field[f"channel.channel_{self._state.channel.id}.product_sku"] = product.sku

		update_field[f"channel.channel_{self._state.channel.id}.publish_status"] = publish_status
		update_field[f"channel.channel_{self._state.channel.id}.error_message"] = msg

		product.channel[f"channel_{self._state.channel.id}"] = self.get_product_channel_data(product, '')
		product.channel[f"channel_{self._state.channel.id}"]['publish_status'] = publish_status
		product.channel[f"channel_{self._state.channel.id}"]['error_message'] = msg
		self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)


	def check_product_exist(self, product):
		if not product.opc and not product.ean and not product.upc:
			return Response().success(data = False)
		opc = product.opc
		if not opc:
			product_code = product.ean if product.ean else product.upc
			params = {
				"filter[field]": "product_code",
				"filter[query]": product_code
			}
			is_product = self.api("products", data = params)
			if is_product.result != Response().SUCCESS:
				return Response().error(msg = "Can not check product's code")
			if is_product.data['metadata']['total_rows'] != 0:
				return Response().success(data = is_product.data['results'][0]['opc'])
			else:
				return Response().success(data = False)
		else:
			params = {
				"filter[field]": "opc",
				"filter[query]": opc
			}
			is_product = self.api("products", data = params)
			if is_product.result != Response().SUCCESS:
				return Response().error(msg = "Can not check product's opc")
			if is_product.data['metadata']['total_rows'] != 0:
				return Response().success(data = True)
			else:
				return Response().success(data = False)


	def import_cache_products(self):
		data = list()

		# push product with variant
		for key in self.parent_products.keys():
			map_variants = dict()
			first_variant = self.parent_variants[key][0]
			parent = self.parent_products[key]
			template_data = parent['channel']['channel_' + str(self._state.channel.id)]['template_data'].get('category')
			if not template_data:
				self.cache_errors[first_variant].append(parent['_id'] + ' product errors: Missing category info')
				continue
			category = template_data['category']['category_id']
			parent_condition = template_data['condition']
			brand = template_data['brand']['value']
			if not category:
				self.cache_errors[first_variant].append(parent['_id'] + ' product errors: Missing category')
				continue
			if not brand:
				self.cache_errors[first_variant].append(parent['_id'] + ' product errors: Missing brand')
				continue
			if not parent.thumb_image.url:
				self.cache_errors[first_variant].append(parent['_id'] + ' product errors: No image found')
				continue
			product_data = {
				"category_id": category,
                "brand_name": brand,
                "product_name": parent.name,
                "description": parent.description,
                "default_image": parent.thumb_image.url,
                "additional_images": [row['url'] for row in parent.images],
		        "live": 1
            }
			variants = list()
			for variant_id in self.parent_variants[key]:
				variant = None
				if self.check_product[variant_id]:
					continue
				for product in self.cache_products:
					if product['_id'] == variant_id:
						variant = product
				if not variant:
					self.cache_errors[variant_id].append(variant_id + ' variant errors: Variant not found')
					continue
				map_variants[variant_id] = variant
				variant_data = dict()
				main_attributes = variant.get('attributes')
				if not main_attributes:
					self.cache_errors[variant_id].append(variant_id  + ' variant errors: No attribute found')
					continue
				for i in range(len(main_attributes)):
						field = "variant_" + str(i+1)
						product_data[field] = {
							"name": main_attributes[i].get('attribute_name')
						}
						variant_data[field] = {
							"name": main_attributes[i].get('attribute_value_name')
						}
				# if not variant.get('onbuy_attributes') or len(variant.onbuy_attributes) == 0:
				# 		variant_data["variant_1"] = {
				# 			"name": main_attributes[0].get('attribute_value_name')
				# 		}
				# 		product_data["variant_1"] = {
				# 			"name": main_attributes[0].get('attribute_name')
				# 		}
				# else:
				# 	for i in range(len(variant.onbuy_attributes)):
				# 		field = "variant_" + str(i+1)
				# 		product_data[field] = {
				# 			"feature_id": variant.onbuy_attributes[i]['feature_id']
				# 		}
				# 		variant_data[field] = {
				# 			"option_id": variant.onbuy_attributes[i]['option_id'],
				# 			"name": main_attributes[0].get('attribute_value_name')
				# 		}
				variant_data["default_image"] = variant.thumb_image.url if variant.thumb_image.url else parent.thumb_image.url
				variant_data["product_codes"] = [ variant.ean if variant.ean else variant.upc ]
				if not variant_data["default_image"]:
					self.cache_errors[variant_id].append(variant_id + ' variant errors: No image found')
					continue
				if len(variant_data["product_codes"]) == 1 and not variant_data["product_codes"][0]:
					self.cache_errors[variant_id].append(variant_id + ' variant errors: Missing product code EAN13')
					continue
				variant_data["listings"] = {
					parent_condition: {
                        "sku": variant.sku if variant.sku else parent.sku,
                        "price": variant.price,
                        "stock": variant.qty
                    }
                }
				variants.append(variant_data)
			if len(variants) == 0:
				continue
			product_data["variants"] = variants
			new_product = self.api("products", method = 'post', data = product_data)
			opc = None
			if new_product.result != Response().SUCCESS:
				error_msg = new_product.msg

				self.cache_errors[first_variant].append(error_msg)
				continue
			queue_id = new_product.data['queue_id']
			queue = self.api("queues/" + str(queue_id))
			if queue.result != Response().SUCCESS:
				self.cache_errors[first_variant].append(parent['_id'] + ' queue errors: ' + str(queue.msg))
				continue
			try:
				while queue.data['results'].get('status') != 'success':
					if queue.data['results'].get('status') == "failed":
						self.cache_errors[parent['_id']].append( str(queue.data['results']['error_message']))
						break
					if queue.data['results']['status'] == "pending":
						time.sleep(10)
						queue = self.api("queues/" + str(queue_id))
						if queue.result != Response.SUCCESS:
							self.cache_errors[parent['_id']].append(parent['_id'] + ' queue errors: ' + str(queue.msg))
							break
				if queue.result == Response.SUCCESS and queue.data['results'].get('status') == 'success':
					opc = queue.data['results']['opc']
					self.onbuy_product_opc[parent['_id']] = opc
					self.insert_map_product(parent, parent['_id'], parent.sku)
					for variant_key in map_variants.keys():
						self.insert_map_product(map_variants[variant_key], variant_key, map_variants[variant_key].sku)
			except Exception as e:
				self.log_traceback()
				continue

		# push simple product
		cache_product = dict()
		for product in self.cache_products:
			is_variant = False
			for key in self.parent_variants.keys():
				for variant_id in self.parent_variants[key]:
					if product['_id'] == variant_id:
						is_variant = True
			if is_variant:
				continue
			template_data = product['channel']['channel_' + str(self._state.channel.id)]['template_data'].get('category')
			if not template_data:
				self.cache_errors[product['_id']].append(product['_id'] + ' product errors: Missing category info')
				continue
			condition = template_data['condition']
			opc = None
			error_msg = ''
			if self.check_product[product['_id']]:
				opc = product.opc if product.opc else self.check_product[product['_id']]
				self.onbuy_product_opc[product['_id']] = opc
			elif self.check_product[product['_id']] is False:
				category = template_data['category']['category_id']
				brand = template_data['brand']['value']
				product_code = product.ean or product.upc
				if not category:
					self.cache_errors[product['_id']].append(product['_id'] + ' product errors: Missing category')
					continue
				if not brand:
					self.cache_errors[product['_id']].append(product['_id'] + ' product errors: Missing brand')
					continue
				if not product_code:
					self.cache_errors[product['_id']].append(product['_id'] + ' product errors: Missing product code EAN13')
					continue
				if not product.thumb_image.url:
					self.cache_errors[product['_id']].append(product['_id'] + ' product errors: No image found')
					continue

				product_data = {
					"product_name": product.name,
					"category_id": category,
					"published": 1,
					"product_codes": [product_code],
					"description": product.description,
					"brand_name": brand,
					"default_image": product.thumb_image.url
				}
				if product.images:
					product_data['additional_images'] = [row['url'] for row in product.images]
				new_product = self.api("products", method = 'post', data = product_data)
				if new_product.result != Response().SUCCESS:
					error_msg = new_product.msg
					self.cache_errors[product['_id']].append(error_msg)
					continue
				else:
					if new_product.data.get('data') and new_product.data['data'].get('existing_opc'):
						opc = new_product.data['data'].get('existing_opc')
						# self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.opc', to_str(opc))
						self.onbuy_product_opc[product['_id']] = opc
					else:
						queue_id = new_product.data['queue_id']
						queue = self.api("queues/" + str(queue_id))
						if queue.result != Response().SUCCESS:
							self.cache_errors[product['_id']].append(product['_id'] + ' queue errors: ' + str(queue.msg))
							continue
						else:
							try:
								if not queue.data['results'].get('status') or queue.data['results']['status'] == "failed":
									self.cache_errors[product['_id']].append(
										product['_id'] + ' queue errors: ' + str(queue.msg))
									continue
								elif queue.data['results']['status'] == "pending":
									status = queue.data['results']['status']
									while status == "pending":
										time.sleep(10)
										queue = self.api("queues/" + str(queue_id))
										if queue.result != Response().SUCCESS:
											self.cache_errors[product['_id']].append(product['_id'] + ' queue errors: ' + str(queue.msg))
											continue
										else:
											status = queue.data['results']['status']
											if status == "success":
												opc = queue.data['results']['opc']
												self.onbuy_product_opc[product['_id']] = opc
											if status == "failed":
												error_msg = to_str(queue.data['results'].get('error_message'))
								else:
									opc = queue.data['results']['opc']
									# model_catalog = self.get_model_catalog()
									# update_data = {
									#     "opc": opc
									# }
									# self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.opc', to_str(opc))
									self.onbuy_product_opc[product['_id']] = opc

							except Exception as e:
								self.log_traceback()
								continue

			if opc:
				if not product.price:
					self.cache_errors[product['_id']].append(product['_id'] + ' product errors: Price must not be empty')
					continue
				listing = {
					"opc": opc,
					"condition": condition,
					"sku": product.sku,
					"price": product.price,
					"stock": product.qty,
					"delivery_weight": product.weight,

				}
				if self.is_special_price(product):
					listing.update({
						"sale_price": product.special_price.price,
						"sale_start_date": convert_format_time(product.special_price.start_date),
						"sale_end_date": convert_format_time(product.special_price.end_date)
					})
				shipping_template = product.get('template_data', {}).get('shipping')
				if shipping_template:
					fields = ['handling_time', 'return_time', 'free_returns', 'warranty', 'delivery_template_id']
					for field in fields:
						if shipping_template.get(field):
							listing[field] = shipping_template.get(field)
				data.append(listing)
				cache_product[product.sku] = product
			else:
				default_msg = 'Missing OPC value'
				self.cache_errors[product['_id']].append(error_msg or default_msg)
				continue
		listings = {
			"listings": data
		}
		res = self.api('listings', data = listings, method = 'post')
		if res.result != Response().SUCCESS:
			return Response().error(msg = "Push product error")
		results = res.data['results']
		log_error = False
		index = 0
		for sku, product in cache_product.items():

			result = results[index]
			index += 1
			if not result['success']:
				self.cache_errors[product['_id']].append(result.get('message') or 'Exception')
				if not log_error:
					log_error = True
					self.log_request_error('https://api.onbuy.com/v2/listings', data = data, response = res.msg, status = res.status_code)
				continue
			check_sku = self.api('listings', data = {'filter[sku]': sku})
			extend_map = {}
			try:
				if check_sku.result == Response.SUCCESS:
					onbuy_product = check_sku.data['results']
					if onbuy_product:
						extend_map['seo_url'] = onbuy_product[0]['product_url']
			except:
				self.log_traceback()
			self.insert_map_product(product, product['_id'], sku, **extend_map)
		
		self.log(self.onbuy_product_opc)
		for key in self.onbuy_product_opc.keys():
			self.get_model_catalog().update_field(key, f'channel.channel_{self.get_channel_id()}.opc', self.onbuy_product_opc[key])

		return Response().success()


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		return Response().success()


	def delete_product_import(self, product_id):
		return super().delete_product_import(product_id)

	def product_channel_update(self, product_id, product: Product, products_ext):
		try:
			template_data = product['channel']['channel_' + str(self._state.channel.id)]['template_data']
			shipping = template_data.get("shipping")
			category = template_data.get("category")
			if not category:
				return Response().error(msg = "Missing category data")
			brand = category['brand']['value']
			condition = category['condition']
			category_id = category['category']['category_id']
			if not category_id:
				return Response().error(msg = product['sku'] + ' product errors: Missing category')
			if not condition:
				return Response().error(msg = product['sku'] + ' product errors: Missing condition')
			if not brand:
				return Response().error(msg = product['sku'] + ' product errors: Missing brand')
			if not product.variants:
				product_opc = product.opc
				product_codes = [product.ean if product.ean else product.upc]
				if not product_codes:
					return Response().error(msg = product['sku'] + ' product errors: Missing product code EAN13')
				if not product.thumb_image.url:
					return Response().error(msg = product['sku'] + ' product errors: No image found')
				product_data = {
					"product_name": product.name,
					"category_id": category_id,
					"published": 1,
					"product_codes": product_codes,
					"description": product.description,
					"brand_name": brand,
					"default_image": product.thumb_image.url
				}
				if product.images:
					product_data['additional_images'] = [row['url'] for row in product.images]

				product_update = self.api("/products/"+str(product_opc), method="put", data=product_data)
				if product_update.result != Response().SUCCESS:
					self.log(product_update.msg)
				else:
					queue_id = product_update.data['queue_id']
					update_process = self.api("queues/" + queue_id)
					if update_process.result != Response().SUCCESS:
						# self.log(update_process.msg)
						return Response().error(msg = update_process.msg)
					else:
						status = update_process.data['results'].get('status')
						if not status or status == "failed":
							return Response().error(msg = update_process.data['results'].get('error_message'))
						if status == "pending":
							retry = 0
							while status == "pending" and retry < 5:
								time.sleep(10)
								retry += 1
								update_process = self.api("queues/" + queue_id)
								if update_process.result != Response().SUCCESS:
									self.log(update_process.msg)
									return Response().error(msg = update_process.msg)
								else:
									status = update_process.data['results'].get('status')
									if not status or status == "failed":
										return Response().error(msg = update_process.data['results']['error_message'])
				
				listing_data = dict()
				listings = [{
					"sku": product.sku,
					"price": product.price,
					"stock": product.qty,
					"delivery_weight": product.weight,
					"sale_price": product.special_price.price,
					"sale_start_date": product.special_price.start_date,
					"sale_end_date": product.special_price.end_date
				}]
				if shipping:
					fields = ['handling_time', 'return_time', 'free_returns', 'warranty', 'delivery_template_id']
					for field in fields:
						if shipping.get(field):
							listings[0][field] = shipping.get(field)
				listing_data["listings"] = listings
				listing_update = self.api("listings/by-sku", data = listing_data, method = "put")
				if listing_update.result != Response().SUCCESS:
					# self.log(product_update.msg)
					return Response().error(msg = product_update.msg)
					
			else:
				error = ""
				product_opc = product.opc
				if not product_opc:
					params = {
						"filter[field]": "product_code",
						"filter[query]": product.ean if product.ean else product.upc
					}
					product_info = self.api("/products", data=params)
					if product_info.result != Response().SUCCESS:
						return Response().error(msg=product_info.msg)
					if product_info.data.get('results') and len(product_info.data['results']) != 1:
						return Response().error(msg="Could not find correct listing to update.")
					if product_info.data.get('results') and (product_info.data['results'], list):
						product_opc = product_info.data['results'][0].get('opc')

				if product_opc:
					product_data = {
						"published": 1,
						"product_name": product.name,
						"description": product.description,
						"default_image": product.thumb_image.url,
						"additional_images": [row['url'] for row in product.images]
					}
					if product.template_data.get('category'):
						category_info = product.template_data['category'].get('category')
						if category_info:
							product_data['category_id'] = category_info.get('category_id')
						# if product.template_data['category'].get('brand'):
						# 	product_data['brand_name'] = product.template_data['category']['brand'].get('value')
						product_condition = product.template_data['category'].get('condition')
						if not product_condition:
							return Response().error(msg="Missing condition inforamtion.")
					else:
						return Response().error(msg="Missing category inforamtion.")
					
					product_update = self.api("products/" + product_opc, data = product_data, method = "put")
					if product_update.result != Response().SUCCESS:
						# self.log(product_update.msg)
						error = error + product['sku'] + ": " + product_update.msg + ". "
					else:
						queue_id = product_update.data['queue_id']
						update_process = self.api("queues/" + queue_id)
						if update_process.result != Response().SUCCESS:
							# self.log(update_process.msg)
							error = error + product['sku'] + ": " + update_process.msg + ". "
						else:
							status = update_process.data['results'].get('status')
							if not status or status == "failed":
								error = error + product['sku'] + ": " + update_process.data['results']['error_message'] + ". "
							if status == "pending":
								retry = 0
								while status == "pending" and retry < 5:
									time.sleep(10)
									retry += 1
									update_process = self.api("queues/" + queue_id)
									if update_process.result != Response().SUCCESS:
										self.log(update_process.msg)
										error = error + product['sku'] + ": " + update_process.msg + ". "
										break
									else:
										status = update_process.data['results'].get('status')
										if not status or status == "failed":
											error = error + product['sku'] + ": " + update_process.data['results']['error_message'] + ". "
				else:
					self.log("Missing OPC: " + str(product.sku))
				
				variants = {
					"listings": []
				}
				for variant in product.variants:
					variant_data = {
						"sku": variant.sku if variant.sku else product.sku,
						"price": variant.price,
						"stock": variant.qty
					}
					if shipping:
						fields = ['handling_time', 'return_time', 'free_returns', 'warranty', 'delivery_template_id']
						for field in fields:
							if shipping.get(field):
								variant_data[field] = shipping.get(field)
					variants['listings'].append(variant_data)
				if len(variants['listings']) <= 0:
					return Response().error(msg="Could not find any variant to update.")
				variant_update = self.api('listings/by-sku', method='put', data=variants)
				if variant_update.result != Response().SUCCESS:
					return Response().error(msg=variant_update.msg)
				if error:
					return Response().error(msg = error)

		except Exception as e:
			log_traceback()
			return Response().error(msg = e)
		return Response().success()

	# orders
	def get_orders_main_export(self):
		imported = self._state.pull.process.orders.imported
		limit_data = self._state.pull.setting.orders
		start_time = self.get_order_start_time('%Y-%m-%d %H:%M:%S')
		last_modifier = self._state.pull.process.orders.max_last_modified
		# offset = 0
		# total = 1
		params = {
			"limit": limit_data,
			"filter[status]": "all",
			"sort[created]": "desc"
		}
		# TODO: update params modified
		if imported:
			params['offset'] = imported
		orders = self.api('orders', data = params)
		result = list()
		if orders.result == Response().SUCCESS:
			for order in orders.data['results']:
				last_update = last_modifier if last_modifier else start_time
				if order['date'] >= start_time and order['updated_at'] >= last_update:
					result.append(order)
			return Response().success(data = result)

		return Response().finish()


	def get_orders_ext_export(self, orders):
		return Response().success()


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.order_id


	def convert_order_export(self, order, orders_ext, channel_id = None):
		order_create = to_timestamp(order.date, "%Y-%m-%dT%H:%M:%S")
		start_time = to_timestamp(self.get_order_start_time('iso'), '%Y-%m-%dT%H:%M:%S')
		if order_create < start_time:
			return Response().skip()

		self.set_order_max_last_modifier(order.date)

		order_data = Order()
		order_data.id = order['order_id']
		order_data.order_number = order['order_id']
		order_data.status = self.ORDER_STATUS.get(to_str(order.status).lower(), 'open')
		order_data.created_at = convert_format_time(order.date)
		order_data.updated_at = convert_format_time(order.updated_at)
		order_data.channel_data = {
			'order_status': order.status,
			'created_at': order_data.created_at,
			'shipped_date': convert_format_time(order.shipped_at) if order.shipped_at else ''
		}
		order_data.shipments.tracking_company = order['delivery_service']
		first_name = ''
		last_name = ''
		if order.buyer.name:
			first_name, last_name = self.split_customer_fullname(order.buyer.name)
		# order_data.customer.id = order.buyer.id
		order_data.customer.username = order.buyer.name
		order_data.customer.first_name = first_name
		order_data.customer.last_name = last_name
		order_data.customer.telephone = order.buyer.phone
		order_data.customer.email = order.buyer.email
		billing_address = OrderAddress()
		billing_address.country.country_code = order.billing_address.country_code
		billing_address.country.country_name = order.billing_address.country
		billing_address.state.state_name = order.billing_address.county
		billing_address.address_1 = order.billing_address.line_1
		billing_address_line2 = []
		if order.billing_address.line_2:
			billing_address_line2.append(order.billing_address.line_2)
		if order.billing_address.line_3:
			billing_address_line2.append(order.billing_address.line_3)
		billing_address.address_2 = "\n".join(billing_address_line2)
		billing_address.city = order.billing_address.town
		billing_address.postcode = order.billing_address.postcode
		billing_address.first_name = first_name
		billing_address.last_name = last_name
		if order.billing_address.name:
			billing_first_name, billing_last_name = self.split_customer_fullname(order.billing_address.name)
			billing_address.first_name = billing_first_name
			billing_address.last_name = billing_last_name
		order_data.customer_address.update(billing_address)
		# order_data.customer_address.last_name = last_name
		# order_data.customer_address.country.country_code = order.billing_address.country_code
		# order_data.customer_address.country.country_name = order.billing_address.country
		# order_data.customer_address.state.state_code = order.billing_address.county
		# order_data.customer_address.address_1 = order.billing_address.line_1
		# order_data.customer_address.address_2 = order.billing_address.line_2
		# order_data.customer_address.city = order.billing_address.town
		# order_data.customer_address.postcode = order.billing_address.postcode

		order_data.billing_address.update(billing_address)

		shipping_first_name, shipping_last_name = self.split_customer_fullname(order.delivery_address.name)
		order_data.shipping_address.first_name = shipping_first_name or first_name
		order_data.shipping_address.last_name = shipping_last_name or last_name
		order_data.shipping_address.country.country_code = order.delivery_address.country_code
		order_data.shipping_address.country.country_name = order.delivery_address.country
		order_data.shipping_address.state.state_name = order.delivery_address.county
		order_data.shipping_address.address_1 = order.delivery_address.line_1
		shipping_address_line2 = list()
		if order.delivery_address.line_2:
			shipping_address_line2.append(order.delivery_address.line_2)
		if order.delivery_address.line_3:
			shipping_address_line2.append(order.delivery_address.line_3)
		order_data.shipping_address.address_2 = "\n".join(shipping_address_line2)
		order_data.shipping_address.city = order.delivery_address.town
		order_data.shipping_address.postcode = order.delivery_address.postcode

		if order.refunds:
			customer_notes = OrderHistory()
			customer_notes.comment = order.refunds.customer_notes
			seller_note = OrderHistoryStaff()
			seller_note.comment = order.refunds.seller_note
			order_data.history.append(customer_notes)
			order_data.history.append(seller_note)

		for item in order.products:
			order_item = OrderProducts()
			order_item.opc = item.opc
			order_item.product_id = item.sku
			order_item.price = item.unit_price
			order_item.total = item.total_price
			order_item.subtotal = to_decimal(item.unit_price) * to_int(item.quantity)
			order_item.qty = item.quantity
			order_item.product_sku = item.sku
			order_item.product_name = item.name
			order_data.products.append(order_item)

		order_data.subtotal = order.price_subtotal
		order_data.total = order.price_total
		order_data.discount.amount = order.price_discount
		order_data.shipping.amount = order.price_delivery
		order_data.shipping.method = order.delivery_service
		order_data.currency = order.currency_code
		if order.tax.tax_total:
			order_data.tax.amount = order.tax.tax_total
		additional_details = {
			'onbuy_internal_reference': 'Onbuy Internal Reference',
			'paypal_capture_id': 'Paypal Capture Id',
			'stripe_transaction_id': 'Stripe Transaction Id',
			'delivery_tag': 'Delivery Tag',
		}
		for field, label in additional_details.items():
			if order.get(field):
				order_data.additional_details.append({
					'name': label,
					'value': order.get(field)
				})
		return Response().success(order_data)


	def get_order_by_id(self, order_id):
		order = self.api(path = f"orders/{order_id}")
		if order.result == Response().SUCCESS:
			return Response().success(order.data['results'])
		return Response().success()


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def get_site_id(self):
		return 2000


	def to_sync_data(self, product):
		setting_price = self.is_setting_sync_price()
		setting_qty = self.is_setting_sync_qty()
		listing_data = {
			'sku': product.sku,
		}
		if setting_qty:
			listing_data['stock'] = product.qty
		if setting_price:
			listing_data['price'] = product.price
			if self.is_special_price(product):
				listing_data['price'] = product.special_price.price
		return listing_data


	def channel_sync_inventory(self, product_id, product: Product, products_ext):
		setting_price = self.is_setting_sync_price()
		setting_qty = self.is_setting_sync_qty()
		if not setting_price and not setting_qty:
			return Response().success(product)
		update_data = {
			'site_id': self.get_site_id(),
			'listings': []
		}
		if not product.variants:
			update_data['listings'].append(self.to_sync_data(product))
		else:
			for variant in product.variants:
				update_data['listings'].append(self.to_sync_data(variant))

		res = self.api('listings/by-sku', data = update_data, method = 'put')
		if res.result != Response().SUCCESS:
			msg = res.msg
			return Response().error(msg = msg)
		return Response().success(product)


	def order_sync_inventory(self, order: Order, setting_order):
		for item in order.products:
			product_opc = item['opc']
			onbuy_product = self.get_product_by_opc(product_opc)
			onbuy_convert = self.convert_product_export(onbuy_product, None)
			convert = onbuy_convert.data
			item_qty = to_int(item['qty'] if to_int(item.qty) > 0 else 1)
			qty = to_int(convert.qty)
			new_qty = qty - item_qty

			update_data = {
				"listings": [
					{
						"sku": item['sku']
					}
				]
			}
			if new_qty <= 0:
				continue
			else:
				update_data['price']: item.price
				update_data['stock']: item.qty

			res = self.api('listings', data = update_data)
			if res.result != Response().SUCCESS:
				return Response().error(msg = "Order sync error")

		return Response().success()

	def channel_order_completed(self, order_id, order: Order, current_order):
		try:
			tracking_company = TrackingCompany(order.shipments.tracking_company_code, order.shipments.tracking_company, channel_type = 'onbuy')
			tracking_company_onbuy_code = tracking_company.get_code()
			order_id = order_id if order_id else order.order_number
			products = list()
			for product in order.products:
				product_data = {
					"sku": product.product_sku,
					"quantity": product.qty
				}
				products.append(product_data)
			orders = {
				"orders": [
					{
						"order_id": order_id,
						"products": products,
						"tracking":  {
						'tracking_id': tracking_company_onbuy_code,
						'number': order.shipments.tracking_number,
						'url': order.shipments.tracking_url or None
				}
					}
				]
			}
			res = self.api("orders/dispatch", method = "put", data = orders, log_type = 'order_completed')
			if res.result != Response().SUCCESS:
				return Response().error(msg="Can not complete order")
			if res.data.get("success"):
				return_order = {"status": "dispatched"}
				return Response().success(return_order)
			else:
				return Response().error(msg="Order complete error")
		except:
			self.log_traceback()
			return Response().error(msg = "Order complete error")


	def channel_order_canceled(self, order_id, order: Order, current_order):
		order_id = order_id if order_id else order.order_number
		orders = {
			"orders": [
				{
					"order_id": order_id
				}
			]
		}
		res = self.api("orders/cancel", method = "put", data = orders)
		if res.result != Response().SUCCESS:
			return Response().error(msg="Can not cancel order")
		if res.data.get("success"):
			return_order = {"status": Order.CANCELED}
			return Response().success(return_order)
		else:
			return Response().error(msg="Order cancel error")

	def api(self, path = '', method = 'get', data = None, retry = 0, log_type = 'request'):
		def log_request_error(request_url, _res):
			error = {
				'method': method,
				'status': _res.status_code,
				'data': to_str(data),
				'header': to_str(_res.headers),
				'response': _res.text,
			}
			self.log_request_error(request_url, log_type= log_type, **error)


		response = None
		access_token = self.get_access_token()
		if not access_token:
			return response
		headers = {
			"Authorization": access_token
		}
		if not data:
			data = {}
		url = self.get_api_url() + "/" + path.strip("/")
		if method in ['post', 'put', 'delete']:
			params = {'site_id': self.get_site_id()}
			response = requests.request(method = method, url = url, params = params, json = data, headers = headers)
		elif method == 'get':
			data['site_id'] = self.get_site_id()
			response = requests.request(method = method, url = url, params = data, headers = headers)
		self._last_status = response.status_code
		self._last_header = response.headers
		if response.status_code > 300 or self.is_log():
			log_request_error(url, response)
		if response.status_code == 429 and retry <= 60:
			retry += 1
			self.log(f"sleep {retry}th time", 'sleep')
			time.sleep(60)
			return self.api(path, method, data, retry)
		if response.status_code > 300 and response.status_code != 401:
			if response.json().get('error') and response.json()['error'].get('message'):
				msg = response.json()['error']['message']
			else:
				msg = response.text
			return Response().error(msg = msg)
		if response.status_code == 401 and 'The authorization token is missing, unknown or expired' in response.text:
			token = self.refresh_access_token()

			if token.result != Response().SUCCESS:
				self.set_action_stop(True)
				return Response().error(msg = "Disconnected")
			return self.api(path, method, data)

		return Response().success(data = response.json())


	@staticmethod
	def get_api_url():
		return 'https://api.onbuy.com/v2'


	def get_seller_id(self):
		return self._state.channel.config.api.seller_id


	def get_consumer_key(self):
		return self._state.channel.config.api.consumer_key


	def get_secret_key(self):
		return self._state.channel.config.api.secret_key


	def get_access_token(self):
		if not self._state.channel.config.api.access_token:
			access_token = self.refresh_access_token()
			if access_token.result != Response().SUCCESS:
				return None
			return access_token.data
		return self._state.channel.config.api.access_token


	def refresh_access_token(self):
		data = {
			"consumer_key": self.get_consumer_key(),
			"secret_key": self.get_secret_key()
		}
		response = requests.post("https://api.onbuy.com/v2/auth/request-token", json = data)
		if response.status_code != 200:
			return Response().error(msg = "Can not connect to OnBuy")
		access_token = response.json()['access_token']
		expired_at = response.json()['expires_at']
		self._state.channel.config.api.access_token = access_token
		self._state.channel.config.api.expired_at = expired_at
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return Response().success(data = access_token)


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%d %H:%M:%S") > to_timestamp(self._order_max_last_modified, '%Y-%m-%d %H:%M:%S')):
			self._order_max_last_modified = last_modifier


	@staticmethod
	def convert_format_time(epoch_seconds):
		return convert_format_time(time_data = to_int(epoch_seconds) - 25200, old_format = 'timestamp')


	def get_product_by_opc(self, product_opc):
		params = {
			"filter[field]": "opc",
			"filter[query]": product_opc
		}
		product = self.api(f"products", data = params)
		if product.result != Response().SUCCESS:
			return Response().error(msg="Could not get product by opc")
		if len(product.data['results']) != 1:
			return Response().error(msg = "Not Found")
		product = product.data['results'][0]
		return Response().success(data = product)


	def get_onbuy_categories(self, category_id):
		params = {}
		if category_id:
			params["category_id"] = category_id
		categories = self.get_model_sync_mode().api("merchant/onbuy/find-category", params, 'get', merchant = True)
		if not categories:
			return False
		return categories


	def channel_assign_category_template(self, product, template_data):
		brand = template_data['brand']
		if brand.override:
			brand_value = brand.override
		else:
			brand_value = brand.mapping
		if brand_value:
			brand.value = self.assign_attribute_to_field(brand_value, product)
		template_data.brand = brand
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['category'] = template_data
		return product


	def get_draft_extend_channel_data(self, product: Product):
		channel_data = {}
		ean = product.ean or product.upc
		if ean and not product.ean:
			channel_data['ean'] = ean
		if product.sku and self._state.channel.config.api.sku_to_ean:
			channel_data['ean'] = product.sku
		if product.sku and self._state.channel.config.api.sku_to_upc:
			channel_data['upc'] = product.sku
		return channel_data