import copy
import csv
import re
import time
from html import unescape

from sp_api.base import Marketplaces

from datasync.libs.amazon_api import *
from datasync.libs.amazon_descriptions import AMAZON_DESCRIPTIONS, AMAZON_CLOTHING_TYPE_SIZE, MAPPING_SIZE_VALUE, AMAZON_DESCRIPTION_EXTEND
from datasync.libs.clothing_specifics import clothing_specifics, SHOES_SPECIFICS
from datasync.models.constructs.amazon import OfferTemplate, PriceTemplate

try:
	from lxml.etree import Element, tostring, fromstring
except ImportError:
	from xml.etree.ElementTree import Element, tostring, fromstring
from io import StringIO

from datasync.libs.utils import *
from datasync.models.modes.test import ModelModesTest
from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.models.channel import ModelChannel
from datasync.models.constructs.product import *
from datasync.models.constructs.order import *


class ModelChannelsAmazon(ModelChannel):
	INIT_INDEX_FIELDS = ['amazon_status']
	_model_local = None
	_product_table_name = 'products'
	DEBUG_MODE = True
	TRANSLATES = {"us": ["seller-sku", "asin1", "item-name", "item-description", "listing-id", "price", "quantity", "open-date", "product-id-type", "item-note", "item-condition", "will-ship-internationally", "expedited-shipping", "product-id", "pending-quantity", "fulfillment-channel", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "merchant-shipping-group", "standard-price-point", "ProductTaxCode", "status", "minimum-seller-allowed-price", "maximum-seller-allowed-price"], "ca": ["seller-sku", "asin1", "item-name", "item-description", "listing-id", "price", "quantity", "open-date", "product-id-type", "item-note", "item-condition", "will-ship-internationally", "expedited-shipping", "product-id", "pending-quantity", "fulfillment-channel", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "merchant-shipping-group", "point-value", "ProductTaxCode", "status", "minimum-seller-allowed-price", "maximum-seller-allowed-price"],
	              "uk": ["seller-sku", "asin1", "item-name", "item-description", "listing-id", "price", "quantity", "open-date", "product-id-type", "item-note", "item-condition", "will-ship-internationally", "expedited-shipping", "product-id", "pending-quantity", "fulfilment-channel", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "merchant-shipping-group", "standard-price-point", "ProductTaxCode", "status", "minimum-seller-allowed-price", "maximum-seller-allowed-price"],
	              "gb": ["seller-sku", "asin1", "item-name", "item-description", "listing-id", "price", "quantity", "open-date", "product-id-type", "item-note", "item-condition", "will-ship-internationally", "expedited-shipping", "product-id", "pending-quantity", "fulfilment-channel", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "merchant-shipping-group", "standard-price-point", "ProductTaxCode", "status", "minimum-seller-allowed-price", "maximum-seller-allowed-price"],
	              "fr": ["sku-vendeur", "asin1", "nom-produit", "description-article", "id-offre", "prix", "quantit\u00e9", "date-ouverture", "type-id-produit", "note-\u00e9tat-article", "\u00e9tat-produit", "exp\u00e9dition-international", "livraison-express", "id-produit", "quantit\u00e9-attente", "canal-traitement", "type-paiement-exclus-optionnel", "lot-sku-livraison-programm\u00e9e", "groupe-exp\u00e9dition-vendeur", "standard-price-point (point de prix standard)", "Code fiscal du produit", "\u00e9tat", "Prix-vendeur-minimum-autoris\u00e9", "Prix-vendeur-maximum-autoris\u00e9"],
	              "de": ["Händler-SKU", "ASIN 1", "Artikelbezeichnung", "Artikelbeschreibung", "Angebotsnummer", "Preis", "Menge", "Erstellungsdatum", "Produkt-ID-Typ", "Anmerkung zum Artikel", "Artikelzustand", "Internationaler Versand", "Expressversand", "Produkt-ID", "Anzahl Bestellungen", "Versender", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "H\u00e4ndlerversandgruppe", "Standardpreis", "Produktsteuerschl\u00fcssel", "Status", "minimum-seller-allowed-price", "maximum-seller-allowed-price"],
	              "it": ["SKU venditore", "ASIN 1", "Nome dell'articolo", "Descrizione dell'articolo", "Numero offerta", "Prezzo", "Quantit\u00e0", "Data di creazione", "Tipo di identificativo del prodotto", "Note sull'articolo", "Condizione dell'articolo", "Spedizione internazionale", "Spedizione Express", "Identificativo del prodotto", "Quantit\u00e0 in sospeso", "Canale di gestione", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "gruppo-spedizione-venditore", "prezzo di vendita standard", "codice fiscale del prodotto", "stato", "prezzo-minimo-consentito-al-venditore", "prezzo-massimo-consentito-al-venditore"],
	              "es": ["SKU del vendedor", "ASIN 1", "T\u00edtulo del producto", "item-description", "listing-id", "Precio", "Cantidad", "open-date", "product-id-type", "item-note", "item-condition", "will-ship-internationally", "expedited-shipping", "product-id", "Cantidad pendiente", "fulfillment-channel", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "merchant-shipping-group", "Precio de venta est\u00e1ndar", "C\u00f3digo fiscal del producto", "estado", "precio m\u00ednimo permitido por el vendedor", "precio m\u00e1ximo permitido por el vendedor"],
	              "in": ["seller-sku", "asin1", "item-name", "item-description", "listing-id", "price", "quantity", "open-date", "product-id-type", "item-note", "item-condition", "will-ship-internationally", "expedited-shipping", "product-id", "pending-quantity", "fulfilment-channel", "optional-payment-type-exclusion", "scheduled-delivery-sku-set", "merchant-shipping-group", "point-value", "ProductTaxCode", "status", "minimum-seller-allowed-price", "maximum-seller-allowed-price"]}
	MARKETPLACE_IDS = {
		'A2EUQ1WTGCTBG2': 'CA',
		'ATVPDKIKX0DER': 'US',
		'A1AM78C64UM0Y8': 'MX',
		'A2Q3Y263D00KWC': 'BR',
		'A1RKKUPIHCS9HS': 'ES',
		'A1F83G8C2ARO7P': 'GB',
		'A13V1IB3VIYZZH': 'FR',
		'A1805IZSGTT6HS': 'NL',
		'A1PA6795UKMFR9': 'DE',
		'APJ6JRA9NG5V4': 'IT',
		'A2NODRKZP88ZB9': 'SE',
		'A1C3SOZRARQ6R3': 'PL',
		'ARBP9OOSHTCHU': 'EG',
		'A33AVAJ2PDY3EV': 'TR',
		'A2VIGQ35RCS4UG': 'AE',
		'A21TJRUUN4KGV': 'IN',
		'A19VAU5U5O7RUS': 'SG',
		'A39IBJ37TRP1C6': 'AU',
		'A1VC38T7YXB528': 'JP',
		'AMEN7PMS3EDWL': 'BE',
	}
	REGIONS = {
		'us': 'us-east-1',
	}

	# Order status mapping
	ORDER_STATUS = {
		'PendingAvailability': Order.OPEN,
		'Pending': Order.OPEN,
		'Unshipped': Order.READY_TO_SHIP,
		'PartiallyShipped': Order.SHIPPING,
		'Shipped': Order.COMPLETED,
		'Canceled': Order.CANCELED,
		'Unfulfillable': Order.CANCELED,
	}
	# Offer templete
	offer_template = {
		'condition': {
			'new': 'New',
			'used': 'UsedLikeNew',
			'reconditioned': 'Refurbished',
			'note': {
				'mapping': '',
				'override': '',
			}
		},
		'fulfillment': 'fbm',
		'handling_time': None,
		'tax_code': None,
		'gift_message': None,
		'gift_wrap': None,
		'max_order_qty': None,
	}

	# Handle import process
	cache_products = list()
	product_relations_ship = dict()
	cache_warnings = dict()
	cache_errors = dict()
	cache_images = dict()
	parent_variants = dict()
	parent_variants_listing = dict()
	parent_products = dict()
	parent_skus = dict()
	# Handle update process
	_update_product = False
	_update_qty = True
	_update_price = True
	_feed_obj: AmazonFeed or None
	_listing_item_obj: AmazonListingItems or None


	# MWS API information - Startswith MWS prefix
	FULFILLMENT_CENTER = {
		'ATVPDKIKX0DER': 'AMAZON_NA',
		'A2EUQ1WTGCTBG2': 'AMAZON_NA',
		'A1AM78C64UM0Y8': 'AMAZON_NA',
		'A1F83G8C2ARO7P': 'AMAZON_EU',
		'A1PA6795UKMFR9': 'AMAZON_EU',
		'A1RKKUPIHCS9HS': 'AMAZON_EU',
		'A13V1IB3VIYZZH': 'AMAZON_EU',
		'A21TJRUUN4KGV': 'AMAZON_EU',
		'APJ6JRA9NG5V4': 'AMAZON_EU',
		'AMEN7PMS3EDWL': 'AMAZON_EU',
		'A1VC38T7YXB528': 'AMAZON_JP',
		'A39IBJ37TRP1C6': 'AMAZON_JP',
		'A2YD9RVN0GGS2Z': 'AMAZON_IN',
	}
	MWS_CURRENCY = {
		'ATVPDKIKX0DER': 'USD',
		'A2EUQ1WTGCTBG2': 'CAD',
		'A1AM78C64UM0Y8': 'MXN',
		'A1F83G8C2ARO7P': 'EUR',
		'A1PA6795UKMFR9': 'EUR',
		'A1RKKUPIHCS9HS': 'EUR',
		'A13V1IB3VIYZZH': 'EUR',
		'AMEN7PMS3EDWL': 'EUR',
		'APJ6JRA9NG5V4': 'EUR',
		'A39IBJ37TRP1C6': 'AUD',
	}
	MWS_MARKETPLACES = {
		'ATVPDKIKX0DER': 'https://mws.amazonservices.com',
		'A2EUQ1WTGCTBG2': 'https://mws.amazonservices.ca',
		'A1AM78C64UM0Y8': 'https://mws.amazonservices.com.mx',
		'A1F83G8C2ARO7P': 'https://mws-eu.amazonservices.com',
		'A1PA6795UKMFR9': 'https://mws-eu.amazonservices.com',
		'A1RKKUPIHCS9HS': 'https://mws-eu.amazonservices.com',
		'A13V1IB3VIYZZH': 'https://mws-eu.amazonservices.com',
		'APJ6JRA9NG5V4': 'https://mws-eu.amazonservices.com',
	}
	MWS_SESSIONS = {
		'Products': ('/Products/2011-10-01', '2011-10-01'),
		'Feeds': ('/', '2009-01-01'),
		'Sellers': ('/Sellers/2011-07-01', '2011-07-01'),
		'Reports': ('/', '2009-01-01'),
		'Orders': ('/Orders/2013-09-01', '2013-09-01'),
		'Fulfillment': ('/FulfillmentInventory/2010-10-01', '2010-10-01')
	}
	MWS_CONDITIONS = {
		1: 'UsedLikeNew',
		2: 'UsedVeryGood',
		3: 'UsedGood',
		4: 'UsedAcceptable',
		5: 'CollectibleLikeNew',
		6: 'CollectibleVeryGood',
		7: 'CollectibleGood',
		8: 'CollectibleAcceptable',
		9: 'Used',
		10: 'Refurbished',
		11: 'New',
	}
	MWS_CONDITIONS_MAPPING = {
		1: 'used',
		2: 'used',
		3: 'used',
		4: 'used',
		5: 'used',
		6: 'used',
		7: 'used',
		8: 'used',
		9: 'used',
		10: 'reconditioned',
		11: 'new',
	}
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'offer', 'amz_details','amz_product_type','title','amz_seo']
	AMAZON_SELLERCENTRAL = {
		'A2EUQ1WTGCTBG2': 'https://sellercentral.amazon.ca',
		'ATVPDKIKX0DER': 'https://sellercentral.amazon.com',
		'A1AM78C64UM0Y8': 'https://sellercentral.amazon.com.mx',
		'A2Q3Y263D00KWC': 'https://sellercentral.amazon.com.br',
		'AMEN7PMS3EDWL': 'https://sellercentral.amazon.com.be',
		'A1RKKUPIHCS9HS': 'https://sellercentral.amazon.es',
		'A1F83G8C2ARO7P': 'https://sellercentral.amazon.co.uk',
		'A13V1IB3VIYZZH': 'https://sellercentral.amazon.fr',
		'A1805IZSGTT6HS': 'https://sellercentral.amazon.nl',
		'A1PA6795UKMFR9': 'https://sellercentral.amazon.de',
		'APJ6JRA9NG5V4': 'https://sellercentral.amazon.it',
		'A2NODRKZP88ZB9': 'https://sellercentral.amazon.se',
		'A1C3SOZRARQ6R3': 'https://sellercentral.amazon.pl',
		'ARBP9OOSHTCHU': 'https://sellercentral.amazon.eg',
		'A33AVAJ2PDY3EV': 'https://sellercentral.amazon.com.tr',
		'A17E79C6D8DWNP': 'https://sellercentral.amazon.sa',
		'A2VIGQ35RCS4UG': 'https://sellercentral.amazon.ae',
		'A21TJRUUN4KGV': 'https://sellercentral.amazon.in',
		'A19VAU5U5O7RUS': 'https://sellercentral.amazon.sg',
		'A39IBJ37TRP1C6': 'https://sellercentral.amazon.com.au',
		'A1VC38T7YXB528': 'https://sellercentral.amazon.co.jp',
	}
	FEED_SLEEP = 30


	def __init__(self, **kwargs):

		super().__init__(**kwargs)
		self._feed_obj = None
		self._catalog_obj = None
		self._order_obj = None
		self._listing_item_obj = None
		self._order_max_last_modified = 0
		self.next_token = None
		self._flag_finish_order = None
		self._is_filter_product = None
		self._product_id = 0
		self._convert_product = None
		self._cache_inventory = dict()
		self._soup = dict()
		self._product_type_not_support = list()
		self.product_relations_ship = dict()
		self.cache_images = dict()
		self.cache_relations_ship = dict()
		self._product_skus = dict()
		self._product_type_template = dict()
		self._pull_products_sku: list[str] = list()


	def get_item_specifics(self, product_type_id):
		if self._product_type_template.get(product_type_id):
			return self._product_type_template[product_type_id]
		specifics = self.get_category_path(channel_type = 'amazon', type_search = f'{self.get_channel_id()}/product_type/{product_type_id}/categoryspecific', params = {'is_private': True})
		self._product_type_template[product_type_id] = specifics
		return specifics


	def get_feed_object(self) -> AmazonFeed:
		if self._feed_obj:
			return self._feed_obj
		self._feed_obj = AmazonFeed(**self.get_amazon_environment())
		return self._feed_obj


	def get_catalog_object(self) -> AmazonCatalog:
		if self._catalog_obj:
			return self._catalog_obj
		self._catalog_obj = AmazonCatalog(**self.get_amazon_environment())
		return self._catalog_obj


	def get_order_object(self) -> AmazonOrder:
		if self._order_obj:
			return self._order_obj
		self._order_obj = AmazonOrder(**self.get_amazon_environment())
		return self._order_obj


	def get_api_info(self):
		"""
		Information required to make an API call
		"""
		return {
			'seller_id': 'Seller ID',
			'refresh_token': 'Authorization token',
			'marketplace_id': 'Marketplace',
		}


	def get_product_table_name(self):
		return f'products_{self.get_sync_id()}'


	def is_valid_condition(self, condition):
		return condition in [
			'New',
			'UsedLikeNew',
			'UsedVeryGood',
			'UsedGood',
			'UsedAcceptable',
			'CollectibleLikeNew',
			'CollectibleVeryGood',
			'CollectibleGood',
			'CollectibleAcceptable',
			'Club',
			'NewOpenBox',
			'Refurbished',
		]


	def parse_dict_to_xml(self, obj, declaration = '<?xml version="1.0" encoding="utf-8"?>', item_tag = 'item'):
		obj = self.solve_dict_before_xml(obj)
		xml = xmltodict.unparse(obj, pretty = True, full_document = False)
		if declaration:
			xml = declaration + '\n' + xml
		return xml


	def solve_dict_before_xml(self, data):
		if isinstance(data, list):
			return_data = []
			for row in data:
				return_data.append(self.solve_dict_before_xml(row))
			return return_data
		if isinstance(data, dict):
			return_data = {}
			for key, value in data.items():
				return_data[key] = self.solve_dict_before_xml(value)
			return return_data
		if isinstance(data, bool):
			if data:
				return 'true'
			else:
				return 'false'
		return to_str(data)


	@staticmethod
	def enumerate_param(param, values):
		"""
		Builds a dictionary of an enumerated parameter, using the param string and some values.
		If values is not a list, tuple or set it will be force to be a list
		with a signle item.

		Example:
			self.enumerate_param('MarketpalceIdList.Id', (123, 456, 789))
		Returns:
			{
				'MarketplaceIdList.Id.1': 123,
				'MarketplaceIdList.Id.2': 456,
				'MarketplaceIdList.Id.3': 789,
			}
		"""
		if not isinstance(values, (list, tuple, set)):
			# Force a single value to a list before continuing.
			values = [values]
		if not any(values):
			return {}
		if not param.endswith('.'):
			# Ensure this enumerated param ends in '.'
			param += '.'
		# Return final output: dict comprehension of the enumerated param and values.
		return {'{}{}'.format(param, index): value
		        for index, value in enumerate(values, 1)}


	@staticmethod
	def hash_md5_feed_content(xml):
		"""
		Calculates the MD5 encryption of feed content for SubmitFeed extra_headers.
		Args:
			xml (str)
		"""
		md5_hash = hashlib.md5()
		md5_hash.update(xml.encode())
		return base64.b64encode(md5_hash.digest()).strip(b"\n")


	def get_marketplace_id_api(self):
		"""
		Get marketplace Id, depend on market place region.
		ref: https://docs.developer.amazonservices.com/en_US/dev_guide/DG_Endpoints.html

		Return:
			'ATVPDKIKX0DER'
		"""
		return self._state.channel.config.api.marketplace_id


	def get_amazon_domain(self):
		sellercentral = self.AMAZON_SELLERCENTRAL.get(self.get_marketplace_id_api())
		return sellercentral.replace('sellercentral.', '')


	def get_currency(self):
		# return self._state.channel.config.api.currency or 'DEFAULT'
		return self.MWS_CURRENCY.get(self.get_marketplace_id_api(), 'DEFAULT')


	def get_default_feed_content(self, feed_type):
		"""
		Get default feed data (dict) for each SubmitFeed requests.
		Args:
			feed_type (str)
		Example:
			feed_type = 'Product'
		"""
		content = {
			'AmazonEnvelope': {
				# '@xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance',
				# '@xsi:noNamespaceSchemaLocation': 'amzn-envelope.xsd',
				'Header': {
					'DocumentVersion': 1.01,
					'MerchantIdentifier': self.get_marketplace_id_api(),
				},
				'MessageType': feed_type,
				'PurgeAndReplace': False,
				'Message': [],
			}
		}
		if feed_type != 'Product':
			del content['AmazonEnvelope']['PurgeAndReplace']
		return content


	def get_access_token(self):
		headers = {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
		data = {
			'grant_type': 'refresh_token',
			'refresh_token': self.get_refresh_token(),
			'client_id': self.get_lwa_client_id(),
			'client_secret': self.get_lwa_client_secret(),
		}
		url = 'https://api.amazon.com/auth/o2/token'
		res = requests.post(url, data = data, headers = headers)
		response = res.json()
		if not isinstance(response, dict) and not response.get('access_token'):
			return ''
		return response.get('access_token', '')


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# order = self.get_order_by_id('113-9197189-0239467')
		# order_ext = self.get_orders_ext_export([order['data']])
		# convert = self.convert_order_export(order.data, order_ext.data)
		access_token = self.get_access_token()
		if not access_token:
			return Response().error(code = Errors.AMAZON_API_INVALID)
		return Response().success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(f"{self._state.channel.config.api.seller_id}-{self.MARKETPLACE_IDS.get(self.get_marketplace_id_api())}")
		return Response().success()


	def get_seller_id(self):
		return self._state.channel.config.api.seller_id


	def get_model_local(self):
		if self._model_local:
			return self._model_local
		self._model_local = ModelModesTest()
		self._model_local.set_user_id(self._user_id)
		return self._model_local


	def get_app_id(self):
		return get_config_ini('amazon_sp', 'application_id')


	def get_app_mode(self):
		return get_config_ini('amazon_sp', 'app_mode')


	def get_lwa_client_id(self):
		return get_config_ini('amazon_sp', 'lwa_client_id')


	def get_lwa_client_secret(self):
		return get_config_ini('amazon_sp', 'lwa_client_secret')


	def get_user_access_key(self):
		return get_config_ini('amazon_sp', 'user_access_key')


	def get_user_secret_key(self):
		return get_config_ini('amazon_sp', 'user_secret_secret')


	def get_role_arn(self):
		return get_config_ini('amazon_sp', 'role_arn')


	def get_refresh_token(self):
		return self._state.channel.config.api.refresh_token


	def get_credentials(self):
		credentials = dict(
			refresh_token = self.get_refresh_token(),
			lwa_app_id = self.get_lwa_client_id(),
			lwa_client_secret = self.get_lwa_client_secret(),
			aws_access_key = self.get_user_access_key(),
			aws_secret_key = self.get_user_secret_key(),
			role_arn = self.get_role_arn(),
		)
		return credentials


	def get_amazon_environment(self):
		marketplace = self.get_language()
		return {
			'credentials': self.get_credentials(),
			'marketplace': Marketplaces.__getattr__(marketplace),
			'channel_id': self.get_channel_id(),
			'user_id': self._user_id,
			'sync_id': self._sync_id,
			'process_type': self.get_process_type(),
			'log_request': self.is_log()
		}


	def get_object(self, instance):
		amazon_environment = self.get_amazon_environment()
		try:
			amazon_object = instance(**amazon_environment)
			return amazon_object
		except Exception:
			self.log_traceback()
		return False


	def api(self, instance, function, **kwargs):
		try:
			response = getattr(instance, function)(**kwargs)
			return response
		except Exception:
			self.log_traceback()
			return False


	def get_language(self):
		marketplace_id = self.get_marketplace_id_api()
		return self.MARKETPLACE_IDS.get(marketplace_id)


	def product_title_default(self):
		return self.TRANSLATES['us']


	def _(self, string, to_lang = 'us'):
		language = self.get_language()
		translates_data = self.TRANSLATES
		language_data = translates_data.get(language.lower())
		if not language_data:
			return string
		try:
			index = language_data.index(string)
		except Exception:
			index = False
		if index is not False:
			return self.TRANSLATES[to_lang][index]
		return string


	def table_construct_default(self, table_name: str):
		table_construct = {
			'table': table_name,
			'rows': {
				'id': 'int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT',
				'user_id': 'int(11)',
			}
		}
		return table_construct


	def products_table_construct(self):
		table_construct = {
			'table': self.get_product_table_name(),
			'rows': {
				'id': 'int(10) PRIMARY KEY NOT NULL AUTO_INCREMENT',
				'user_id': 'int(11)',
				'solved': 'tinyint NOT NULL DEFAULT 0'
			}
		}
		fields = self.product_title_default()
		for field in fields:
			table_construct['rows'][field] = 'text'
		return table_construct


	def get_detail_product_by_asin(self, asin):
		catalog = self.get_catalog_object().get_item(asin, MarketplaceId = self.get_marketplace_id_api())
		if not catalog or not catalog.payload:
			return False
		return Prodict.from_dict(catalog.payload)


	def get_variant_info_by_asin(self, asin):
		catalog = self.get_catalog_object().get_item_variant(asin, includedData = 'variations,summaries,images,identifiers', marketplaceIds = self.get_marketplace_id_api())
		if not catalog or not catalog.payload:
			return False
		return Prodict.from_dict(catalog.payload)


	def decode_csv_data(self, data, encoding = 'utf-8'):
		return data.encode('iso-8859-1').decode(encoding)


	def get_products_count_export(self):

		"""
		Get products, count and save to database
		"""
		report_type = 'GET_MERCHANT_LISTINGS_DATA'
		if self._state.pull.process.products.include_inactive:
			report_type = 'GET_MERCHANT_LISTINGS_ALL_DATA'

		report_obj = AmazonReport(**self.get_amazon_environment())
		report = report_obj.create_report(reportType = report_type)
		# report = self.api(report_obj, 'create_report', reportType = report_type)
		if not report or not report.payload or not report.payload.get('reportId'):
			return Response().error(Errors.AMAZON_GET_PRODUCT_ERROR)
		report_id = report.payload['reportId']
		time.sleep(self.FEED_SLEEP)
		report_details = report_obj.get_report(report_id)
		# report_details = self.api(report_obj, 'get_report', report_id = report_id)

		processing_status = report_details.payload.get('processingStatus')
		old_processing_status = processing_status
		idx = 0
		while processing_status != 'DONE':
			if processing_status in ['FATAL', 'CANCELLED']:
				return Response().error(Errors.AMAZON_GET_PRODUCT_ERROR)
			time.sleep(self.FEED_SLEEP)
			idx += 1
			if processing_status != old_processing_status:
				idx = 0
				old_processing_status = processing_status
			self.log(f'report id: {report_id} {processing_status} number {idx}', 'reports')

			if processing_status == 'IN_QUEUE' and idx > 100:
				report_obj.cancel_report(report_id)
				# report_obj.cancel_report(report_id)
				self.log(f'cancel report {report_id}', 'cancel_reports')
				return Response().error(Errors.AMAZON_GET_PRODUCT_ERROR)
			report_details = report_obj.get_report(report_id)
			# report_details = self.api(report_obj, 'get_report', report_id = report_id)

			processing_status = report_details.payload.get('processingStatus')
		report_document = report_obj.get_report_document(report_details.payload.get('reportDocumentId'), decrypt = True, download = True)
		# report_document = self.api(report_obj, 'get_report_document', document_id = report_details.payload.get('reportDocumentId'))
		document_payload = report_document.payload
		# report_data = report_obj.decrypt_report_document(url = document_payload['url'], initialization_vector = document_payload['encryptionDetails']['initializationVector'], key = document_payload['encryptionDetails']['key'], encryption_standard = document_payload['encryptionDetails']['standard'], payload = document_payload)
		report_data = document_payload['document']
		# report_data = self.api(report_obj, 'decrypt_report_document', url = document_payload['url'], initialization_vector = document_payload['encryptionDetails']['initializationVector'], key = document_payload['encryptionDetails']['key'], encryption_standard = document_payload['encryptionDetails']['standard'], payload = document_payload)
		if report_data and isinstance(report_data, str):
			try:
				f = StringIO(report_data)
				products = list(csv.DictReader(f, delimiter = '\t'))
				if not products:
					return Response().success(data = 0)
				self.get_model_local().query_raw("DROP TABLE IF EXISTS `{}`".format(self.get_product_table_name()))
				products_table_construct = self.products_table_construct()
				query = self.get_model_local().dict_to_create_table_sql(products_table_construct)
				if query['result'] == 'success':
					self.get_model_local().query_raw(query['query'])
				values = []
				product_title_default = self.product_title_default()
				entities_limit = self.get_entity_limit()
				product_limit = None
				if entities_limit:
					product_limit = to_int(entities_limit.get('products'))
				count = 0
				for index, product in enumerate(products):
					# if product_limit and index > product_limit:
					# 	break
					data = {
						'user_id': self._user_id
					}
					for field, value in product.items():
						field_name = self._(field)
						if field_name in product_title_default:
							data[field_name] = to_str(value)
					values.append(data)
				if values:
					row_values = split_list(values, 200)
					for row in row_values:
						insert_data = []
						for product_data in row:
							asin = product_data.get('asin1') or product_data.get('asin2') or product_data.get('asin3')
							if not asin and product_data.get('seller-sku'):
								listing = self.get_listing_item(product_data.get('seller-sku'), included_data = 'summaries')
								if listing and listing.status_code < 300:
									amazon_product = listing.payload.get('summaries')
									if amazon_product:
										amazon_product = amazon_product[0]
										if amazon_product.get('asin'):
											asin = amazon_product['asin']
											product_data['asin1'] = asin
							if not asin:
								continue
							insert_data.append(product_data)
						if not insert_data:
							continue
						insert = self.get_model_local().insert_multiple_obj(self.get_product_table_name(), row)
			# if insert['result'] != Response().SUCCESS:
			# 	return insert
			except Exception as e:
				self.log_traceback()
				return Response().error(Errors.EXCEPTION)
			return Response().success(data = len(products))
		return Response().error(Errors.AMAZON_GET_PRODUCT_ERROR)


	def is_filter_product(self):
		if self._is_filter_product is not None:
			return self._is_filter_product
		row = self.get_model_local().select_page(f"{self.get_product_table_name()}_filter", {}, limit = 1)
		self._is_filter_product = row['result'] == 'success'
		return self._is_filter_product


	def ignore_new_report(self):
		return self._state.channel.config.api.ignore_new_report

	def get_pull_product_sku(self) -> list:
		"""get the product sku list to pull from amz"""
		product_sku_str = to_str(self._request_data.get('product_sku'))
		if product_sku_str:
			self._pull_products_sku = list(
						set(
							[
								x.replace('\"', '').replace("'", '').strip()
								for x in product_sku_str.split(',')[:100]
							]
						)
					)

		return self._pull_products_sku


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			if not self.ignore_new_report():
				total_product = self.get_products_count_export()
			# if total_product.result == Response().SUCCESS:
			# 	total_product = total_product.data
			#
			# 	self._state.pull.process.products.total = total_product
			# else:
			# 	self._state.pull.process.products.total = 0
			status = ['Active']
			if self.is_refresh_process():
				self._state.pull.process.products.include_inactive = True
				self._state.pull.process.products.include_fba = False
			if self.is_import_inactive():
				status.append('Inactive')
			query = f'SELECT count(1) as count FROM `{self.get_product_table_name()}` WHERE solved != 1 and (`status` IN {self.get_model_local().list_to_in_condition(status)} OR `status` is NULL) {self.fba_query()} '
			if self.is_filter_product():
				query += f" AND `seller-sku` in (SELECT `sku` FROM {self.get_product_table_name()}_filter)"
			if self.get_pull_product_sku():
				query += self.filter_product_sku_query(self._pull_products_sku, left_and = True)
			self._state.pull.process.products.total = 0
			products = self.get_model_local().select_raw(query)
			if products.result == Response.SUCCESS:
				self._state.pull.process.products.total = self.pull_limit() or products.data[0]['count']
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
			self._state.pull.process.products.error = 0
			self._state.pull.process.products.id_src = 0

		if self._state.config.orders:
			self._state.pull.process.orders.total = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0
			self._state.pull.process.orders.next_token = ''
			last_modifier = self._state.pull.process.orders.max_last_modified
			created_after = self.get_order_start_time('iso')
			if not created_after:
				created_after = '2013-09-01T00:00:00Z'
			extra_data = dict(MarketplaceIds = [self.get_marketplace_id_api()])
			extra_data['CreatedAfter'] = created_after
			extra_data['MaxResultsPerPage'] = 100
			if last_modifier:
				del extra_data['CreatedAfter']
				# last_modifier = convert_format_time(last_modifier, new_format = '%Y-%m-%dT%H:%M:%SZ')
				extra_data['LastUpdatedAfter'] = last_modifier
			order_obj = self.get_order_object()

			response = order_obj.get_orders(**extra_data)
			if self.is_log():
				self.log_request_error('orders', param = extra_data, response = response.payload, status = response.status_code)
			if response.payload and response.payload.get('Orders'):
				self._state.pull.process.orders.total = -1
				if to_len(response.payload.get('Orders')) <= 100:
					self._state.pull.process.orders.total_view = to_len(response.payload.get('Orders'))
			if last_modifier:
				self.set_order_max_last_modifier(last_modifier)
		return Response().success()


	def fba_query(self):
		if not self.is_import_product_by_status('fba'):
			return f" AND (`fulfillment-channel` = 'DEFAULT' OR `fulfillment-channel` is NULL) "
		return ""

	def filter_product_sku_query(self, products_list: list, left_and: bool = True) -> str:
		"""query concat with query"""
		if not products_list:
			return ''

		query_ = f'(`seller-sku` IN {self.get_model_local().list_to_in_condition(products_list)})'
		return f'AND {query_}' if left_and else f'{query_} AND'


	# TODO: Product

	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._product_id
		if not id_src:
			id_src = ''
		status = ['Active']
		if self.is_import_inactive():
			status.append('Inactive')
		query_filter = ''
		if self.is_filter_product():
			query_filter = f" `seller-sku` in (SELECT `sku` FROM {self.get_product_table_name()}_filter) AND "
		if self._pull_products_sku:
			query_filter += self.filter_product_sku_query(self._pull_products_sku, left_and = False)
		query = f'SELECT * FROM `{self.get_product_table_name()}` WHERE {query_filter} solved != 1 and (`status` IN {self.get_model_local().list_to_in_condition(status)} OR `status` is NULL) AND `id` > "{id_src}" {self.fba_query()} ORDER BY `id` LIMIT {limit_data}'
		products = self.get_model_local().select_raw(query)
		if products.result != Response.SUCCESS or not products.data:
			return Response().finish()
		self._product_id = products.data[-1]['id']
		return Response().success(data = products.data)


	def get_product_by_updated_at(self):
		return self.get_products_main_export()


	def get_products_ext_export(self, products):
		# if self.is_refresh_process():
		# 	return Response().success()
		# extend = Prodict()
		# for product in products:
		# 	asin = product['asin1'] or product['asin2'] or product['asin3']
		# 	product_variants = self.get_variant_info_by_asin(asin)
		# 	product_extend = self.get_detail_product_by_asin(asin)
		# 	extend[asin] = {
		# 		"variants": product_variants,
		# 		"extend": product_extend
		# 	}
		return Response().success()


	def convert_product_by_asin(self, product, product_extend, variant_attributes = None, is_variant = False, product_details = {}, variant_atr_lower = []):
		asin = product['asin1'] or product.get('asin2') or product.get('asin3')

		if variant_attributes or is_variant:
			product_data = ProductVariant()
		else:
			product_data = Product()
		attribute_names = []
		if variant_attributes:
			attribute_names = list(variant_attributes.keys())
		if not product_details:
			product_details = self.get_variant_info_by_asin(asin)
		product_data.name = product.get('item-name')
		product_data.description = product['item-description']
		if not product.get('item-description') and self.is_allow_crawl_description():
			description = self.crawl_description(asin)
			product_data.description = description
		product_data.id = product['seller-sku']
		product_data.sku = product['seller-sku']
		product_data.price = to_decimal(product['price'])
		product_data.qty = to_int(product['quantity'])
		product_data.is_in_stock = True if to_int(product['quantity']) > 0 else False
		if product['open-date']:
			product_data.created_at = convert_format_time(product['open-date'].replace('PDT', '').strip())
		product_data.type = 'simple'
		product_data.status = False if product['status'] == 'Inactive' else True
		product_data.condition = self.MWS_CONDITIONS_MAPPING.get(product['item-condition'], 'new')
		product_data.asin = asin
		product_data.seo_url = f'{self.get_amazon_domain()}/gp/product/{asin}'
		# product_data.upc = product['product-id']
		# product_data.ean = product['product-id']
		if self.is_refresh_process():
			product_data.allow_update = ['name', 'description', 'price', 'qty', 'condition']
		else:
			if product_details:
				if product_details.get('identifiers'):
					for row in product_details['identifiers']:
						if row['marketplaceId'] == self.get_marketplace_id_api():
							identifier_field = ['ean', 'upc', 'isbn', 'barcode', 'gtin', 'mpn', 'bpn']
							for identifier in row['identifiers']:
								if identifier['identifierType'].lower() in identifier_field:
									product_data[identifier['identifierType'].lower()] = identifier['identifier']
								else:
									attribute = ProductAttribute()
									attribute.attribute_name = identifier['identifierType']
									attribute.attribute_value_name = identifier['identifier']
									product_data.attributes.append(attribute)
				if product_details.get('images'):
					images = product_details.get('images')[0]['images']
					main_image = ''
					all_images = dict()
					product_images = list()
					for image in images:
						if not all_images.get(image['variant']):
							all_images[image['variant']] = list()
						all_images[image['variant']].append(image)
					for variant, image_variant in all_images.items():
						dimension = 0
						image_url = ''
						for image in image_variant:
							image_dimension = image['height'] * image['width']
							if image_dimension > dimension:
								dimension = image_dimension
								image_url = image['link']
						if variant == 'MAIN':
							main_image = image_url
						else:
							product_images.append(image_url)
					product_data.thumb_image.url = main_image
					for image in product_images:
						product_image = ProductImage()
						product_image.url = image
						product_data.images.append(product_image)
			if product_extend:
				if product_extend.get('AttributeSets') and product_extend.get('AttributeSets')[0].get('ItemDimensions'):
					dimensions = product_extend.get('AttributeSets')[0].get('ItemDimensions')
					product_data.height = to_decimal(dimensions.get('Height').get('value') if dimensions.get('Height') else 0)
					product_data.length = to_decimal(dimensions.get('Length').get('value') if dimensions.get('Length') else 0)
					product_data.width = to_decimal(dimensions.get('Width').get('value') if dimensions.get('Width') else 0)
					product_data.weight = to_decimal(dimensions.get('Weight').get('value') if dimensions.get('Weight') else 0)

				if not product_data.thumb_image.url:
					product_data.thumb_image.url = product_extend.get('AttributeSets')[0].get('SmallImage').get('URL').replace('._SL75_', '') if product_extend.get('AttributeSets') else ''

				if product_extend.get('AttributeSets'):
					for attribute_name, attribute_value in product_extend.get('AttributeSets')[0].items():
						if not attribute_value or isinstance(attribute_value, (dict, Prodict)) or attribute_name in ['ItemDimensions', 'SmallImage', 'Languages', 'Platform', 'ListPrice']:
							continue
						if isinstance(attribute_value, (list, tuple)):
							try:
								attribute_value = ' '.join(attribute_value)
							except:
								continue
						if attribute_name == 'Brand':
							product_data.brand = attribute_value
							continue
						if attribute_name == 'Title':
							product_data.name = attribute_value
							continue
						if attribute_name == 'Manufacturer':
							product_data.manufacturer.name = attribute_value
							continue
						try:
							# case the attribute name have postfix likes
							# sizeName, MarterialType,..
							# attribute_data = ProductAttribute()
							attribute_data = (ProductVariantAttribute()
							                  if list(
								filter(lambda var: attribute_name.lower().startswith(var), variant_atr_lower)
							) else ProductAttribute())
						except:
							self.log_traceback(type_error = 'convert_combine_attribute')
							attribute_data = ProductAttribute()

						attribute_data.attribute_name = attribute_name
						attribute_data.attribute_value_name = attribute_value
						product_data.attributes.append(attribute_data)
			offer_template_data = OfferTemplate()
			offer_template_data.condition.value = self.MWS_CONDITIONS.get(to_int(product['item-condition']), '')
			if product['fulfillment-channel'] == 'DEFAULT' or not product['fulfillment-channel']:
				offer_template_data.fulfillment = 'fbm'
			else:
				offer_template_data.fulfillment = 'fba'
				product_data.manage_stock = False
			product_data.template_data['offer'] = offer_template_data
			amazon_product = False
			if not product_data.description:
				amazon_product = self.get_listing_item(product['seller-sku'], included_data = 'attributes')
				if amazon_product:
					amazon_product_attributes = amazon_product.payload.get('attributes', {}) if amazon_product and amazon_product.payload else {}
					if amazon_product_attributes.get('product_description'):
						product_data.description = amazon_product_attributes['product_description'][0]['value']
			# get `use variant` attributes
			if is_variant:
				amazon_variant_attributes = dict()
				use_variant_list = list()
				try:
					# this method work only with active product
					amazon_product_2022 = self.get_asin_attribute_lower(asin)
					use_variant_list = list(x['attribute_name'] for x in
					                          list(filter(lambda x: x['use_variant'], product_data.attributes)))

					for var_atr in amazon_product_2022['variant_attribute_list']:
						if amazon_product_2022['attribute_dict'].get(var_atr) and var_atr.title() not in use_variant_list:
							amazon_variant_attributes.update(
								{var_atr.title(): amazon_product_2022['attribute_dict'][var_atr]})
				except:
					self.log_traceback()

				is_use_new_variant = amazon_variant_attributes or use_variant_list
				if not amazon_product:
					amazon_product = self.get_listing_item(product['seller-sku'], included_data = 'attributes')
				if amazon_product and not is_use_new_variant:
					amazon_product_attributes = amazon_product.payload.get('attributes', {}) if amazon_product and amazon_product.payload else {}
					if amazon_product_attributes:
						if amazon_product_attributes.get('variation_theme'):
							attribute_variant_names = list(map(lambda x: to_str(x).lower(), amazon_product.payload['attributes']['variation_theme'][0]['name'].split('/')))
							for attribute_name in attribute_variant_names:
								for attribute_detail_name, attribute_detail_value in product_details['summaries'][0].items():
									if attribute_detail_name.lower().replace('_', '') == attribute_name.replace('_', ''):
										amazon_variant_attributes[attribute_detail_name] = attribute_detail_value
						if not amazon_variant_attributes:
							if not attribute_names and amazon_product_attributes.get('variation_theme'):
								attribute_names = list(map(lambda x: to_str(x).lower().replace('_name', ''), amazon_product.payload['attributes']['variation_theme'][0]['name'].split('/')))
							for attribute_name, attribute_value in amazon_product_attributes.items():
								if to_str(attribute_name).lower() in attribute_names:
									amazon_variant_attributes[to_str(attribute_name).capitalize()] = attribute_value[0]['value']
							value_by_sku = product['seller-sku'].split('-')[0 - len(attribute_names):]
							for index, attribute_name in enumerate(attribute_names):
								if not amazon_variant_attributes.get(to_str(attribute_name).capitalize()):
									if variant_attributes:
										for attribute_name_default, attribute_value_default in variant_attributes.items():
											if to_str(attribute_name).lower() == to_str(attribute_name_default).lower():
												amazon_variant_attributes[to_str(attribute_name).capitalize()] = attribute_value_default
									if not amazon_variant_attributes.get(to_str(attribute_name).capitalize()):
										value_by_name = re.findall("\(.*?\)", product_data.name)
										try:
											value_by_name_split = value_by_name[-1].strip('()').split(',')
											amazon_variant_attributes[to_str(attribute_name).capitalize()] = value_by_name_split[index]
										except Exception:
											pass
										if not amazon_variant_attributes.get(to_str(attribute_name).capitalize()):

											value_by_sku = product['seller-sku'].split('-')[0 - len(attribute_names):]

											try:
												amazon_variant_attributes[to_str(attribute_name).capitalize()] = value_by_sku[index]

											except Exception:
												self.log(asin, 'asin_variant')
				if amazon_variant_attributes:

					# if variant_attributes:
					for attribute_name, attribute_value in amazon_variant_attributes.items():
						attribute_data = ProductVariantAttribute()
						attribute_data.attribute_name = attribute_name
						attribute_data.attribute_value_name = attribute_value
						product_data.attributes.append(attribute_data)

			channel_data = {
				'amazon_status': 'Active' if product['status'] != 'Inactive' else 'Inactive',
				'asin': asin,
				'asin_data': {
					'name': product_data.name,
					'thumbnail': product_data.thumb_image.url,
					'asin': product_data.asin,
					'url': f'{self.get_amazon_domain()}/gp/product/{asin}',
				}
			}
			product_data.channel_data = channel_data
		return product_data


	def get_product_by_id(self, product_id):
		product = self.get_model_local().select_row(self.get_product_table_name(), {'id': product_id})
		return Response().success(product)


	def _convert_product_export(self, product, products_ext: Prodict):
		# if to_int(product.id) == 4:
		# 	c = 3
		self._soup = dict()
		if self.is_refresh_process():
			return Response().success(self.convert_product_by_asin(product, None))
		if self._convert_product:
			product_data = copy.deepcopy(self._convert_product)
			self._convert_product = None
			return Response().success(product_data)
		if to_int(product.get('solved')) == 1:
			return Response().skip()
		solved_ids = list()
		solved_ids.append(product['id'])
		asin = product['asin1'] or product.get('asin2') or product.get('asin3')
		if not asin:
			return Response().skip()
		# check_product = self.get_product_warehouse_map(asin)
		# if check_product:
		# 	return Response().skip()
		# product_ext = products_ext[asin]
		parent_asin = None
		product_variants = self.get_variant_info_by_asin(asin)
		product_extend = self.get_detail_product_by_asin(asin)
		if not product_extend:
			return Response().error('not found asin')

		if product_variants and product_variants.variations:
			variants = product_variants.variations[0]
			if variants.variationType == 'CHILD':
				parent_asin = variants.asins[0]
			else:
				parent_asin = asin

		product_data = self.convert_product_by_asin(product, product_extend, product_details = product_variants)
		if not parent_asin or self.is_import_as_simple_product():
			self.update_to_solved(solved_ids)
			return Response().success(data = product_data)

		if self.get_product_warehouse_map(parent_asin):
			return Response().skip()
		if parent_asin != asin:
			product_parent = self.get_detail_product_by_asin(parent_asin)
		else:
			product_parent = product_extend
		parent_data = dict()

		if product_parent and product_parent.Relationships:
			parent_like_child = False
			childs = {}
			for row in product_parent.Relationships:
				identifiers = row.Identifiers
				del row['Identifiers']
				childs[identifiers.MarketplaceASIN.ASIN] = row
			child_asin = list(childs.keys())
			# if parent_asin not in child_asin:
			# 	child_asin.append(parent_asin)
			query_filter = ''
			if self.is_filter_product():
				query_filter = f" `seller-sku` in (SELECT `sku` FROM {self.get_product_table_name()}_filter) AND "
			status = ['Active']
			if self.is_import_inactive():
				status.append('Inactive')
			query = f"select * from {self.get_product_table_name()} where {query_filter} asin1 in {self.get_model_local().list_to_in_condition(child_asin)} AND (`status` IN {self.get_model_local().list_to_in_condition(status)} OR `status` is NULL) {self.fba_query()}"
			product_childs = self.get_model_local().select_raw(query)
			variant_asin_exist = list()
			if product_childs.result == Response.SUCCESS:
				first_child = list(childs.keys())[0] if childs.keys() else ''
				variant_atr_lower = self.get_asin_attribute_lower(first_child) if first_child else []

				all_child = sorted(product_childs.data, key = lambda row: 'fbm' if row['fulfillment-channel'] == 'DEFAULT' else "fba", reverse = True)
				for child in all_child:
					solved_ids.append(child['id'])
					if child['asin1'] == parent_asin:
						parent_like_child = True

					product_amazon_child = self.get_detail_product_by_asin(child['asin1'])
					product_child = self.convert_product_by_asin(
						child, product_amazon_child, childs[child['asin1']],
						is_variant = True, variant_atr_lower = variant_atr_lower['variant_attribute_list'])

					if child['asin1'] in variant_asin_exist:
						product_child['variant_like_simple'] = True
					else:
						variant_asin_exist.append(child['asin1'])

					product_data.variants.append(product_child)

				# self.log(msg = str({ 'product_data': product_data, 'product_childs': product_childs, 'variant_attribute': variant_atr_lower}), log_type = 'product_data_combine')
			if len(product_data.variants) <= 1:
				product_data.variants = list()
			else:
				if parent_asin != asin:
					where = {'asin1': parent_asin}
					if not self.is_import_product_by_status('fba'):
						where['fulfillment-channel'] = 'DEFAULT'
					parent = self.get_model_local().select_row(self.get_product_table_name(), where)
					if parent:

						parent_variant = self.get_variant_info_by_asin(parent_asin)
						parent_data = self.convert_product_by_asin(parent, product_parent, product_details = parent_variant)
						if parent_like_child:
							product_data.id += "-parent"
						parent_data.variants = product_data.variants
						parent_data.qty = sum([row.qty for row in product_data.variants])
						parent_data.is_in_stock = parent_data.qty > 0
				if not parent_data:
					product_data.asin = parent_asin
					product_data.id = product_data.sku
					product_data.name = product_parent['AttributeSets'][0]['Title']
					product_data.channel_data.asin = parent_asin
					product_data.channel_data.asin_data = {
						'name': product_parent['AttributeSets'][0]['Title'],
						'thumbnail': product_parent['AttributeSets'][0]['SmallImage']['URL'],
						'asin': parent_asin,
						'url': f"{self.get_amazon_domain()}/gp/product/{parent_asin}",
					}
			# update variant status according to parent status
			try:
				for var in product_data.variants:
					var['channel_data']['amazon_status'] = 'Active' if product_data.status else 'Inactive'
					var['status'] = product_data.status
			except:
				self.log_traceback()

		self.update_to_solved(solved_ids)

		return Response().success(data = parent_data or product_data)


	def get_asin_attribute_lower(self, asin):
		"""this function retrieves variant attributes from amz
		some products may not return fully variant attribute
		so, we need to check with the parent asin
		"""
		asin_data = self.get_catalog_object().get_item_v2022(
			to_str(asin),
			includedData = 'relationships,summaries,attributes',
			marketplaceIds = self.get_marketplace_id_api()
		)

		try:
			# inactive variant not return variant attribute
			# use the parent attributes to mapping
			parent_asin = ''
			if isinstance(asin_data.payload.get('relationships'), list):
				parent_asin = asin_data.payload["relationships"][0]["relationships"][0]["parentAsins"][0]
		except:
			parent_asin = ''

		try:
			if (
				isinstance(asin_data.payload.get('relationships'), list)
				and isinstance(asin_data.payload["relationships"][0]["relationships"][0].get('variationTheme'), dict)
			):
				atr_var_list = asin_data.payload["relationships"][0]["relationships"][0]["variationTheme"]["attributes"]
				atr_var_list = list(map(lambda x: x.lower(), atr_var_list))
			else:
				atr_var_list = []

			if parent_asin:
				parent_attribute = self.get_asin_attribute_lower(parent_asin)
				atr_parent_list = parent_attribute['variant_attribute_list']
				atr_var_list = atr_parent_list if len(atr_parent_list) > len(atr_var_list) else atr_var_list
		except:
			self.log_traceback()
			atr_var_list = []

		try:
			attribute_dict = {}
			if asin_data.payload and asin_data.status_code < 300:
				attribute_dict_raw = asin_data.payload['attributes']
				for atr_get in atr_var_list:
					if attribute_dict_raw.get(atr_get):
						atr_list = obj_to_list(attribute_dict_raw[atr_get])
						attribute_dict[atr_get] = atr_list[0]['value']

				# old method
				# attribute_dict = asin_data.payload['summaries'][0]
				# if not isinstance(attribute_dict, dict):
				# 	attribute_dict = {}
		except Exception:
			attribute_dict = {}

		return {'variant_attribute_list': atr_var_list, 'attribute_dict': attribute_dict}




	def update_to_solved(self, solved_ids):
		query = f"UPDATE {self.get_product_table_name()} SET solved = 1 where id in {self.get_model_local().list_to_in_condition(solved_ids)}"
		self.get_model_local().query_raw(query)


	def get_product_id_import(self, convert: Product, product, products_ext):
		if self.is_refresh_process():
			return product['seller-sku']
		self._convert_product = None
		convert_product = self._convert_product_export(product, products_ext)
		if convert_product.result == Response.SUCCESS:
			self._convert_product = convert_product.data
			return self._convert_product.id
		asin = product['seller-sku']
		return asin


	def add_product_to_cache(self, product):
		if not product.asin and not is_local():
			sku = product.sku
			listing = self.get_listing_item(sku, included_data = 'summaries,issues')
			if listing and listing.status_code < 300:
				listing_data = listing.payload
				if listing_data.get('summaries'):
					summaries = listing_data['summaries'][0]
					asin = summaries.get('asin')
					if asin:
						product['asin'] = asin
						update_data = {
							'asin': asin,
							'asin_data': {
								'name': product.name,
								'thumbnail': product.thumb_image.url,
								'asin': asin,
								'url': f'{self.get_amazon_domain()}/gp/product/{asin}',
							}
						}
						self.get_model_catalog().update(product['_id'], update_data)
		self.cache_products.append(product)


	def mapping_gtin_template(self, product):
		if not product.variants:
			return product
		channel_data = product.channel[f'channel_{self.get_channel_id()}']
		parent_template = channel_data.template_data.amz_product_type if channel_data.template_data else {}
		if not parent_template:
			return product
		for variant in product.variants:
			variant_channel_data = variant.channel[f'channel_{self.get_channel_id()}']

			variant_template = (variant_channel_data.template_data.amz_product_type if variant_channel_data.template_data else {}) or {}
			parent_specifics = []
			if not variant_template.get('parent_specifics'):
				variant_template['parent_specifics'] = list()
			if variant_template.get('parent_specifics'):
				for parent_specific in variant_template['parent_specifics']:
					if parent_specific.get('value'):
						parent_specifics.append(parent_specific.name)
			for parent_specific in parent_template['parent_specifics']:
				if parent_specific.get('value') and parent_specific.name not in parent_specifics:
					variant_template['parent_specifics'].append(parent_specific)
			specifics = []
			if not variant_template.get('specifics'):
				variant_template['specifics'] = list()
			if variant_template.get('specifics'):
				for specific in variant_template['specifics']:
					if specific.get('value'):
						specifics.append(specific.name)
			for specific in parent_template['specifics']:
				if specific.get('value') and specific.name not in specifics:
					variant_template['specifics'].append(specific)
			# variant_template['shipping_details'] = p
			variant['template_data']['amz_product_type']  = variant_template
			if not variant['channel'][f'channel_{self.get_channel_id()}'].get('template_data'):
				variant['channel'][f'channel_{self.get_channel_id()}']['template_data'] = {}
			variant['channel'][f'channel_{self.get_channel_id()}']['template_data']['amz_product_type']  = variant_template
		return product
	def product_import(self, convert: Product, product, products_ext):
		if not product.variants:
			self.add_product_to_cache(product)
		else:
			fields = ['title', 'description']
			if self.is_amazon_gtin_exemption():
				product = self.mapping_gtin_template(product)
			parent_sku = product.sku
			variant_skus = [variant.sku for variant in product.variants]
			if parent_sku in variant_skus:
				parent_sku += '-parent'
				product.sku = parent_sku
				self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.sku', parent_sku)
			product_skus = [parent_sku]
			product_channel_data = product['channel'][f'channel_{self.get_channel_id()}']
			templates = ['offer', 'amz_seo', 'amz_details', 'amz_product_type']
			for variant in product.variants:
				channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
				if not channel_data.get('template_data'):
					channel_data['template_data'] = product_channel_data['template_data']
					variant['channel'][f'channel_{self.get_channel_id()}']['template_data'] = product_channel_data['template_data']
					variant['template_data'] = product_channel_data['template_data']
				for template in templates:
					if not channel_data['template_data'].get(template) and product_channel_data['template_data'].get(template):
						channel_data['template_data'][template] = product_channel_data['template_data'][template]
						variant['channel'][f'channel_{self.get_channel_id()}']['template_data'][template] = product_channel_data['template_data'][template]
						variant['template_data'][template] = product_channel_data['template_data'][template]

				attribute_data = [to_str(attribute['attribute_value_name']).replace(' ', '') for attribute in list(filter(lambda x: x.get('use_variant'),variant.attributes))]
				variant.name = f'{product.name} ({",".join(attribute_data)})'
				if variant.sku in product_skus:
					variant.sku = f'{variant.sku}-{"-".join(attribute_data)}'
					if not channel_data.get('product_id'):
						self.get_model_catalog().update_field(variant['_id'], f'channel.channel_{self.get_channel_id()}.sku', variant.sku)
				if channel_data and channel_data.get('product_id'):
					variant.sku = channel_data.get('product_id')
				product_skus.append(variant.sku)


			self.parent_variants[product['_id']] = list()
			self.parent_variants_listing[product['_id']] = list()
			self.parent_products[product['_id']] = product

			self.product_relations_ship[parent_sku] = list()

			if self.is_amazon_gtin_exemption():
				product['is_parent_product'] = True
				self.add_product_to_cache(product)
				self._product_skus[parent_sku] = product['_id']
			if product.variants:
				all_images = [product.thumb_image]
				if product.images:
					all_images.extend(product.images)
				amz_product_type_template = product.template_data.amz_product_type if product.template_data else {}
				variants = product.variants
				variants.sort(key = lambda x: x.get('price'))
				for index, variant in enumerate(variants):
					# if not variant.description:
					if self.is_amazon_gtin_exemption() and (not amz_product_type_template or not amz_product_type_template.variant_data or not amz_product_type_template.variant_data.variant_theme):
						variant['missing_variant_theme'] = True

					variant.description = product.description
					if not variant.thumb_image.url:
						variant.thumb_image = product.thumb_image
					if all_images and len(all_images) > 1:
						variant_images = []
						for image in all_images:
							if image.url == variant.thumb_image.url:
								continue
							variant_images.append(image)
						variant.images = variant_images
					channel_data = variant['channel'][f'channel_{self.get_channel_id()}']

					self.parent_variants[product['_id']].append(variant['_id'])
					self.parent_variants_listing[product['_id']].append(variant)
					if not variant.name:
						variant.name = product.name
					if not variant.description:
						variant.description = product.description
					if self.is_amazon_gtin_exemption():

						attribute_data = [to_str(attribute['attribute_value_name']).replace(' ', '') for attribute in variant.attributes]
						variant.name = f'{product.name} ({",".join(attribute_data)})'
						# if variant.sku in product_skus:
						# 	variant.sku = f'{parent_sku}-{"-".join(attribute_data)}'
						# if channel_data and channel_data.get('product_id'):
						# 	variant.sku = channel_data.get('product_id')
						self.product_relations_ship[parent_sku].append(variant.sku)

						self._product_skus[variant.sku] = variant['_id']

					if not variant.manufacturer.name:
						variant.manufacturer.name = product.manufacturer.name
					# if channel_data and channel_data.get('product_id'):
					# 	continue
					self.add_product_to_cache(variant)

		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		self._update_product = True
		if not product.variants:
			self.add_product_to_cache(product)
		else:
			fields = ['title', 'description']
			if self.is_amazon_gtin_exemption():
				product = self.mapping_gtin_template(product)
			parent_sku = product.sku
			product_skus = [parent_sku]
			for variant in product.variants:
				channel_data = variant['channel'][f'channel_{self.get_channel_id()}']
				attribute_data = [to_str(attribute['attribute_value_name']).replace(' ', '') for attribute in list(filter(lambda x: x.get('use_variant'), variant.attributes))]
				variant.name = f'{product.name} ({",".join(attribute_data)})'
				if variant.sku in product_skus:
					variant.sku = f'{variant.sku}-{"-".join(attribute_data)}'
					if not channel_data.get('product_id'):
						self.get_model_catalog().update_field(variant['_id'], f'channel.channel_{self.get_channel_id()}.sku', variant.sku)
				if channel_data and channel_data.get('product_id'):
					variant.sku = channel_data.get('product_id')
				product_skus.append(variant.sku)
			variant_skus = [variant.sku for variant in product.variants]
			if parent_sku in variant_skus:
				parent_sku += '-parent'
				product.sku = parent_sku
			self.parent_variants[product['_id']] = list()
			self.parent_variants_listing[product['_id']] = list()
			self.parent_products[product['_id']] = product

			self.product_relations_ship[parent_sku] = list()

			if self.is_amazon_gtin_exemption():
				product['is_parent_product'] = True
				self.add_product_to_cache(product)
				self._product_skus[parent_sku] = product['_id']
			if product.variants:
				all_images = [product.thumb_image]
				if product.images:
					all_images.extend(product.images)
				amz_product_type_template = product.template_data.amz_product_type if product.template_data else {}
				variants = product.variants
				variants.sort(key = lambda x: x.get('price'))
				for index, variant in enumerate(variants):
					# if not variant.description:
					if self.is_amazon_gtin_exemption() and (not amz_product_type_template or not amz_product_type_template.variant_data or not amz_product_type_template.variant_data.variant_theme):
						variant['missing_variant_theme'] = True

					variant.description = product.description
					if not variant.thumb_image.url:
						variant.thumb_image = product.thumb_image
					if all_images and len(all_images) > 1:
						variant_images = []
						for image in all_images:
							if image.url == variant.thumb_image.url:
								continue
							variant_images.append(image)
						variant.images = variant_images
					channel_data = variant['channel'][f'channel_{self.get_channel_id()}']

					self.parent_variants[product['_id']].append(variant['_id'])
					self.parent_variants_listing[product['_id']].append(variant)
					if not variant.name:
						variant.name = product.name
					if not variant.description:
						variant.description = product.description
					if self.is_amazon_gtin_exemption():
						attribute_data = [to_str(attribute['attribute_value_name']).replace(' ', '') for attribute in variant.attributes]
						variant.name = f'{product.name} ({",".join(attribute_data)})'
						# if variant.sku in product_skus:
						# 	variant.sku = f'{parent_sku}-{"-".join(attribute_data)}'
						# if channel_data and channel_data.get('product_id'):
						# 	variant.sku = channel_data.get('product_id')
						self.product_relations_ship[parent_sku].append(variant.sku)

						self._product_skus[variant.sku] = variant['_id']

					if not variant.manufacturer.name:
						variant.manufacturer.name = product.manufacturer.name
					# if channel_data and channel_data.get('product_id'):
					# 	continue
					self.add_product_to_cache(variant)

		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		self._update_product = True
		if not self.is_setting_sync_price():
			self._update_price = False
		if not self.is_setting_sync_qty():
			self._update_qty = False
		if not product.variants:
			return self.channel_sync_inventory_simple_product(product_id, product)
		for variant in product.variants:
			variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
			if not variant_id:
				continue
			variant_sync = self.channel_sync_inventory_simple_product(variant_id, variant)
			if variant_sync.result != Response.SUCCESS:
				variant.sync_error = True
		return Response().success(product)


	def channel_sync_inventory_simple_product(self, product_id, product: Product):
		channel_data = product['channel'][f'channel_{self.get_channel_id()}']
		setting_price = self.is_setting_sync_price()
		setting_qty = self.is_setting_sync_qty()
		if not setting_price and not setting_qty:
			return Response().success()
		try:
			amazon_product_request = self.get_listing_item(product_id, included_data = 'attributes,summaries')
			if not amazon_product_request.payload:
				self.cache_products.append(product)
				self.log(product['_id'], 'amazon_product')
				return Response().success()
			amazon_product = amazon_product_request.payload
			product_type = amazon_product['summaries'][0]['productType']
			if product_type in self._product_type_not_support:
				self.cache_products.append(product)
				return Response().success()
			body = {
				"productType": product_type,
				"patches": []
			}
			if setting_qty:
				fulfillment_availabilities = amazon_product['attributes']['fulfillment_availability']
				for fulfillment_availability in fulfillment_availabilities:
					if fulfillment_availability['marketplace_id'] != self.get_marketplace_id_api():
						continue
					fulfillment_availability['quantity'] = product.qty
				body['patches'].append({
					"op": "replace",
					"path": "/attributes/fulfillment_availability",
					"value": fulfillment_availabilities
				})
			if setting_price:
				purchasable_offers = amazon_product['attributes']['purchasable_offer']
				for purchasable_offer in purchasable_offers:
					if purchasable_offer['marketplace_id'] != self.get_marketplace_id_api():
						continue

					our_price = {
						"schedule": [
							{
								"value_with_tax": to_decimal(product.price, 2)
							}
						]
					}
					purchasable_offer['our_price'] = [
						our_price
					]
					if self.is_special_price(product):
						special_price = product.special_price
						start_date = to_str(special_price.start_date or special_price.sale_start_date).replace(' ', 'T')
						end_date = to_str(special_price.end_date or special_price.sale_end_date).replace(' ', 'T')
						if to_len(start_date) == 10:
							start_date = convert_format_time(special_price.start_date or special_price.sale_start_date, new_format = '%Y-%m-%dT%H:%M:%S', old_format = "%Y-%m-%d")
						if to_len(end_date) == 10:
							end_date = convert_format_time(special_price.end_date or special_price.sale_end_date, new_format = '%Y-%m-%dT%H:%M:%S', old_format = "%Y-%m-%d")
						purchasable_offer['discounted_price'] = [{'schedule': [{'end_at': end_date, 'value_with_tax': product.special_price.price, 'start_at': start_date}]}]
					elif purchasable_offer.get('discounted_price'):
						del purchasable_offer['discounted_price']
				body['patches'].append({
					"op": "replace",
					"path": "/attributes/purchasable_offer",
					"value": purchasable_offers
				})
			response = self.get_listing_items_object().patch_listings_item(self.get_seller_id(), product_id, body = body)
			if response.payload:
				if response.payload.get('status') == 'ACCEPTED':
					if setting_qty and product.qty > 0 and channel_data.get('amazon_status') == 'Inactive':
						self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.amazon_status', 'Active')
					return Response().success()
				if response.payload.get('issues'):
					issues = response.payload['issues']
					if isinstance(issues, list):
						issues = issues[0]
					if to_int(issues.get('code')) == 4000003:
						self._product_type_not_support.append(product_type)
				self.cache_products.append(product)

				self.log_request_error('patch_listings_item', body = body, payload = response.payload)
		except Exception:
			self.log_traceback()
			self.cache_products.append(product)
		return Response().success()


	def get_product_operation_type(self):
		return 'Update' if not self._update_product else 'PartialUpdate'


	def get_condition_id(self, name):
		for condition_id, condition_name in self.MWS_CONDITIONS.items():
			if name == condition_name:
				return condition_id
		return False


	def is_amazon_gtin_exemption(self):
		return self._state.channel.config.api.gtin_exemption


	def specific_to_value(self, specific):
		if specific.type == 'dimension':
			return {
				'@unitOfMeasure': specific.unit,
				'#text': to_str(specific.value),
			}
		if specific.type == 'price':
			return {
				'@currency': specific.unit,
				'#text': to_str(specific.value),
			}
		if specific.type == 'multytext':
			value = specific.value
			if isinstance(value, str):
				value = value.split(',')
				value = list(map(lambda x: x.strip(), value))
			return value
		if specific.type == 'unit_count':
			return {
				'@unitOfMeasure': specific.unit,
				'#text': to_str(specific.value),
			}
		if specific.type == 'age_recommendation':
			age_recommendation = json_decode(specific.value)
			if not age_recommendation:
				return None
			age_recommendation_value = {}
			fields = ['MinimumManufacturerAgeRecommended', 'MaximumManufacturerAgeRecommended', 'MinimumMerchantAgeRecommended', 'MaximumMerchantAgeRecommended']
			for field in fields:
				if age_recommendation.get(field, {}).get('value'):
					age_recommendation_value[field] = {
						'@unitOfMeasure': age_recommendation.get(field, {}).get('unit'),
						'#text': to_str(age_recommendation.get(field, {}).get('value')),
					}
			return age_recommendation_value
		else:
			value = specific.value
			if specific.type == 'boolean':
				value = 'true' if value == 'yes' else 'false'
			return value
		return None


	def get_variant_attribute_value(self, attribute: ProductVariantAttribute):
		if not attribute.variant_unit:
			return attribute.attribute_value_name
		return {
			'@unitOfMeasure': attribute.variant_unit,
			'#text': attribute.attribute_value_name,
		}


	def import_cache_products(self):
		# Update operation type will override all data and PartialUpdate just override only specific fields
		operation_type = self.get_product_operation_type()
		currency = self.get_currency()
		# Re-create new cache errors and warnings for each import round.
		# Import product
		feed_content = self.get_default_feed_content('Product')
		for index, product in enumerate(self.cache_products, 1):
			description_data = {}
			# Prepare before import - get necessary template data
			channel_data = product.channel[f'channel_{self.get_channel_id()}']
			if channel_data:
				channel_data = Prodict.from_dict(channel_data)
			offer_template = OfferTemplate.from_dict(channel_data.template_data.offer) if product.template_data.offer else OfferTemplate()
			price_template = PriceTemplate.from_dict(channel_data.template_data.price) if product.template_data.price else PriceTemplate()
			amz_product_type_template = channel_data.template_data.amz_product_type if channel_data.template_data else None
			if amz_product_type_template is not None:
				amz_product_type_template = Prodict.from_dict(amz_product_type_template)
			amz_details_template = product.template_data.amz_details
			amz_seo_template = product.template_data.amz_seo or Prodict()

			# Get asin code
			asin = product.asin
			gtin = product.gtin or product.upc or product.ean or product.isbn or product.barcode
			if self.is_amazon_gtin_exemption() and not amz_product_type_template:
				self.cache_errors[product["_id"]].append(f'AMZ_MISSING_PRODUCT_TYPE')
				continue
			if not asin and not gtin and not self.is_amazon_gtin_exemption():
				self.cache_errors[product["_id"]].append(f'Please provide at least one of the two fields: ASIN or GTIN')
				continue
			sku = product.sku
			if not sku:
				self.cache_errors[product["_id"]].append(f'Import product_id {product["_id"]} errors: SKU is required')
				continue

			# Assign product post data
			product_data = dict()
			product_data['SKU'] = sku
			if asin:
				product_data['StandardProductID'] = {
					'Type': 'ASIN',
					'Value': asin,
				}
			elif gtin and not self.is_amazon_gtin_exemption():
				fields = ['gtin', 'upc', 'ean', 'isbn', 'gcid']
				for field in fields:
					if product.get(field):
						product_data['StandardProductID'] = {
							'Type': field.upper(),
							'Value': product.get(field),
						}
						break
			if self.is_amazon_gtin_exemption() and not self._state.channel.config.api.skip_gtin_exemption:
				product_data['GtinExemptionReason'] = 'part'
			title = product.name
			description = product.description
			manufacturer = product.manufacturer.name
			# Get and convert condition - get extra field from template
			tax_code = offer_template.tax_code
			launch_date = offer_template.launch_date
			condition_note = offer_template.get('condition_notes')
			gift_wrap = 'true' if offer_template.gift_wrap == 'enable' else 'false'
			gift_message = 'true' if offer_template.gift_message == 'enable' else 'false'
			max_order_qty = offer_template.max_order_qty
			msrp = price_template.msrp

			offer_fields = {
				'tax_code': 'ProductTaxCode',
				'launch_date': 'LaunchDate',
				'release_date': 'ReleaseDate',
			}
			if tax_code:
				product_data['ProductTaxCode'] = tax_code
			if launch_date:
				product_data['LaunchDate'] = launch_date
			condition = offer_template.condition.value

			if condition and self.is_valid_condition(condition):
				product_data['Condition'] = {'ConditionType': condition}
			if condition_note:
				product_data['Condition']['ConditionNote'] = condition_note

			# Update product

			# Imported product cannot update condition
			if self._update_product and not self.is_amazon_gtin_exemption():

				# del product_data['Condition']['ConditionType']
				if 'Condition' in product_data:
					del product_data['Condition']
			if title:
				description_data['Title'] = self.title_cutting(self.strip_html_from_description(title), 500)
			if self.is_amazon_gtin_exemption():
				if self._state.channel.config.api.gtin_exemption_brand or (amz_product_type_template and amz_product_type_template.brand):
					description_data['Brand'] = self._state.channel.config.api.gtin_exemption_brand or amz_product_type_template.brand
			if description and (not asin or self.is_amazon_gtin_exemption()):
				description_data['Description'] = self.replace_description(description)[0:2000]
			if (amz_product_type_template and amz_product_type_template.bullet_point) or (amz_seo_template and amz_seo_template.bullet_point):
				bullet_point = amz_product_type_template.bullet_point if amz_product_type_template and amz_product_type_template.bullet_point else amz_seo_template.bullet_point
				if isinstance(bullet_point, str):
					bullet_point = to_str(bullet_point).split(',')
				description_data['BulletPoint'] = list(map(lambda x: to_str(x).strip(), bullet_point))
			if amz_product_type_template and amz_product_type_template.shipping_details:
				shipping_details = amz_product_type_template.shipping_details
				shipping_details_dimensions = {
					'ItemDimensions': {},
					'PackageDimensions': {},
				}
				item_dimensions_fields = ['length', 'width', 'height', 'weight']
				for dimension_type in ['item', 'package']:
					for dimension in item_dimensions_fields:
						if shipping_details.get(f'{dimension_type}_{dimension}_dimension') and shipping_details.get(f'{dimension_type}_{dimension}_dimension').get('value') and shipping_details.get(f'{dimension_type}_{dimension}_dimension').get('unit'):
							shipping_details_dimensions[f'{dimension_type.capitalize()}Dimensions'][dimension.capitalize()] = {
										'@unitOfMeasure': shipping_details.get(f'{dimension_type}_{dimension}_dimension').get('unit'),
										'#text': to_str(to_decimal(shipping_details.get(f'{dimension_type}_{dimension}_dimension').get('value'), 2)),
									}
				if shipping_details_dimensions['ItemDimensions']:
					description_data['ItemDimensions'] = shipping_details_dimensions['ItemDimensions']
				if shipping_details_dimensions['PackageDimensions']:
					description_data['PackageDimensions'] = shipping_details_dimensions['PackageDimensions']
				if shipping_details.get('shipping_weight') and shipping_details.get(f'shipping_weight').get('value') and shipping_details.get(f'shipping_weight').get('unit'):
					description_data['ShippingWeight'] = {
						'@unitOfMeasure': shipping_details.get(f'shipping_weight').get('unit'),
						'#text': to_str(to_decimal(shipping_details.get(f'shipping_weight').get('value'), 2)),
					}
			if msrp and msrp.price and msrp.status == 'enable':
				description_data['MSRP'] = {
					'@currency': currency,
					'#text': to_str(to_decimal(msrp.price)),
				}
			if max_order_qty is not None and to_int(max_order_qty) > 0:
				description_data['MaxOrderQuantity'] = max_order_qty

			if self.is_amazon_gtin_exemption():
				# description_data['Manufacturer'] = self._state.channel.config.api.gtin_exemption_brand
				if product.mpn:
					description_data['MfrPartNumber'] = product.mpn
				# if amz_product_type_template.category and amz_product_type_template.category.name:
				# 	category_name = to_str(amz_product_type_template.category.name).split('>')[-1].strip()
				# 	if amz_product_type_template.intended_use:
				# 		intended_uses = to_str(amz_product_type_template.intended_use).split(',')
				# 		product_data['DescriptionData']['UsedFor'] = intended_uses
				# 	product_data['DescriptionData']['ItemType'] = category_name
				seo_fields = {
					'search_terms': 'SearchTerms',
					'platinum_keywords': 'PlatinumKeywords',
					'intended_use': 'UsedFor',
					'item_type': 'ItemType',
					'other_attributes': 'OtherItemAttributes',
					'target_audience': 'TargetAudience',
					'subject_matter': 'SubjectContent'
				}
				for seo_field, amz_field in seo_fields.items():
					if (amz_product_type_template and amz_product_type_template.get(seo_field)) or (amz_seo_template and amz_seo_template.get(seo_field)):
						if amz_product_type_template and amz_product_type_template.get(seo_field):
							value = to_str(amz_product_type_template.get(seo_field))
						else:
							value = amz_seo_template.get(seo_field)
						if seo_field in ['platinum_keywords', 'intended_use', 'other_attributes', 'target_audience', 'subject_matter']:
							if isinstance(value, str):
								value = value.split(',')
						if seo_field in ['search_terms']:
							if isinstance(value, str):
								value = value.replace('\n', ',')
						description_data[amz_field] = value
			if not self._update_product or offer_template.gift_wrap is not None:
				description_data['IsGiftWrapAvailable'] = gift_wrap
			if not self._update_product or offer_template.gift_message is not None:
				description_data['IsGiftMessageAvailable'] = gift_message
			if offer_template.external_product_information:
				description_data['ExternalProductInformation'] = offer_template.external_product_information
			if self.is_amazon_gtin_exemption() and amz_product_type_template and amz_product_type_template.category and amz_product_type_template.category.category_id:
				description_data['RecommendedBrowseNode'] = amz_product_type_template.category.category_id
			# if not self._update_product:
			description_data['Battery'] = {
				'AreBatteriesIncluded': True if amz_product_type_template and amz_product_type_template.get('are_batteries_included') else False,
				'AreBatteriesRequired': True if amz_product_type_template and amz_product_type_template.get('are_batteries_required') else False,
			}
			if amz_product_type_template and amz_product_type_template.get('are_batteries_included'):
				description_data['Battery']['BatterySubgroup'] = amz_product_type_template.get('battery_subgroup')
			description_data['SupplierDeclaredDGHZRegulation'] = (amz_product_type_template.get('supplier_declared_dghz_regulation') or 'not_applicable' )if amz_product_type_template else 'not_applicable'
			description_data['CountryOfOrigin'] = self.get_language()
			if amz_product_type_template and amz_product_type_template.get('description_specifics'):
				for specific in amz_product_type_template.get('description_specifics'):
					if not specific.value:
						continue
					value = self.specific_to_value(specific)
					description_data[specific.name] = value
			if not self.is_amazon_gtin_exemption() and amz_details_template:
				for specific in amz_details_template.get('description_specifics'):
					if not specific.value:
						continue
					value = self.specific_to_value(specific)
					description_data[specific.name] = value
			sort_description_data = {}
			for field in AMAZON_DESCRIPTIONS:
				if description_data.get(field['name']):
					value = description_data[field['name']]
					if field.get('max_occurs') and isinstance(value, list):
						value = value[:field.get('max_occurs')]
					sort_description_data[field['name']] = value
			before_description_fields = list(filter(lambda x: x['position'] == 1, AMAZON_DESCRIPTION_EXTEND))
			for field in before_description_fields:
				if description_data.get(field['name']):
					value = description_data[field['name']]
					if field.get('max_occurs') and isinstance(value, list):
						value = value[:field.get('max_occurs')]
					product_data[field['name']] = value
			product_data['DescriptionData'] = sort_description_data
			after_description_fields = list(filter(lambda x: x['position'] == 2, AMAZON_DESCRIPTION_EXTEND))
			for field in after_description_fields:
				if description_data.get(field['name']):
					value = description_data[field['name']]
					if field.get('max_occurs') and isinstance(value, list):
						value = value[:field.get('max_occurs')]
					product_data[field['name']] = value
			if self.is_amazon_gtin_exemption() and amz_product_type_template and amz_product_type_template.product_type:
				is_clothing = amz_product_type_template and amz_product_type_template.product_type.type_id and to_int(amz_product_type_template.product_type.type_id) == 335
				is_shoes = amz_product_type_template and amz_product_type_template.product_type.type_id and to_int(amz_product_type_template.product_type.type_id) == 789
				is_home = amz_product_type_template and amz_product_type_template.product_type.name and to_str(amz_product_type_template.product_type.name).split('>')[0].strip() == 'Home'
				clothing_type = ''
				if is_clothing:

					for specific in amz_product_type_template.specifics:
						if specific.name == 'ClothingType':
							clothing_type = specific.value
							break
					if not clothing_type:
						self.cache_errors[product["_id"]].append(f'ClothingType is required')
						continue
				if amz_product_type_template and amz_product_type_template.product_type.type_id:
					is_set_parentage = False
					parent_tage = ''
					product_type_id = amz_product_type_template.product_type.type_id
					construct_specifics = self.get_item_specifics(product_type_id)
					construct_variant_attributes = construct_specifics.get('variant_attributes') or []
					product_type_data = {}
					product_type_parent_data = {}
					structures = to_str(construct_specifics['structure']).split('>') if construct_specifics['structure'] else []
					if not structures:
						structures = []
					if structures:
						structures = list(map(lambda x: to_str(x).strip(), structures))
					variant_data = {}
					variant_no_sort = {}
					specifics_data = {}
					specifics = amz_product_type_template.specifics
					home_variant_data = {}
					shoe_size_value = False
					real_shoe_size_value = False
					if (product.is_variant or product.variants) and not self._state.channel.config.api.skip_gtin_exemption:
						parent_tage = 'parent' if not product.is_variant else 'child'
						variant_no_sort['VariationTheme'] = amz_product_type_template.variant_data.variant_theme

						if product.is_variant or is_clothing:
							if not product.is_variant and is_clothing:
								product.attributes = self.parent_variants_listing[product['_id']][0]['attributes']
							for attribute in product.attributes:
								if (attribute.is_variant_attribute or attribute.use_variant) and to_int(amz_product_type_template.product_type.type_id) != 335:
									variant_no_sort[attribute.attribute_name.lower()] = self.get_variant_attribute_value(attribute)
								# else:
								if is_home:
									home_variant_data[attribute.attribute_name.lower()] = self.get_variant_attribute_value(attribute)

								product_type_parent_data[attribute.attribute_name.lower()] = self.get_variant_attribute_value(attribute)
								if is_clothing:
									clothing_size = AMAZON_CLOTHING_TYPE_SIZE.get(clothing_type.upper(), 'ApparelSize')
									have_clothing_size = False
									for specific in specifics:
										if specific.name == clothing_size and specific.value:
											have_clothing_size = True
											break
									if amz_product_type_template.parent_specifics:
										for specific in amz_product_type_template.parent_specifics:
											if specific.name == clothing_size and specific.value:
												have_clothing_size = True
												break
									if not have_clothing_size:
										if clothing_size and attribute.attribute_name.lower().find('size') != -1:
											product_type_parent_data[clothing_size.lower()] = self.mapping_size_value(attribute.attribute_value_name, clothing_size)
											specifics_data[clothing_size.lower()] = self.mapping_size_value(attribute.attribute_value_name, clothing_size)
								if is_shoes:
									shoe_size = 'ShoeSize'
									have_shoe_size = False
									for specific in specifics:
										if specific.name == shoe_size and specific.value:
											have_shoe_size = True
											break
									if amz_product_type_template.parent_specifics:
										for specific in amz_product_type_template.parent_specifics:
											if specific.name == shoe_size and specific.value:
												have_shoe_size = True
												break
									if not have_shoe_size:
										if shoe_size and attribute.attribute_name.lower().find('size') != -1:
											shoe_size_value = self.mapping_size_value(attribute.attribute_value_name, shoe_size)
											real_shoe_size_value = attribute.attribute_value_name
											specifics_data[shoe_size.lower()] = self.mapping_size_value(attribute.attribute_value_name, shoe_size)
						if 'Parentage' in construct_variant_attributes:
							is_set_parentage = True
							variant_no_sort['Parentage'] = 'parent' if not product.is_variant else 'child'

					for specific in specifics:
						if not specific.value or (construct_variant_attributes and specific.name not in construct_variant_attributes):
							continue
						value = self.specific_to_value(specific)
						variant_no_sort[specific.name] = value
					for row in construct_variant_attributes:
						if row in variant_no_sort or row.lower() in variant_no_sort:
							variant_data[row] = variant_no_sort.get(row) or variant_no_sort.get(row.lower())
					for field, value in variant_data.items():
						if product_type_parent_data.get(field) or product_type_parent_data.get(field.lower()):
							if field in product_type_parent_data:
								del product_type_parent_data[field]
							else:
								del product_type_parent_data[field.lower()]
					if amz_product_type_template.parent_specifics:
						specifics.extend(amz_product_type_template.parent_specifics)
					if specifics:
						specifics.sort(key = lambda x: to_int(x.get('position')))
					for specific in specifics:
						if not specific.value or specific.name.lower() in specifics_data or specific.name in variant_no_sort or specific.name.lower() in variant_no_sort:
							continue
						if specific.type == 'variant_data' and variant_data:
							specifics_data[specific.name.lower()] = variant_data
							set_variant_data = True
						else:
							value = self.specific_to_value(specific)
							specifics_data[specific.name.lower()] = value
					set_variant_data = False
					for specific in construct_specifics['item_specifics']:
						if specific.get('is_variant_data'):
							continue
						value = False
						specific_name_lower = specific['name'].lower()
						if specific['type'] == 'variant_data' and variant_data:
							set_variant_data = True
							value = variant_data
						elif specifics_data.get(specific_name_lower):
							value = specifics_data.get(specific_name_lower)
							del specifics_data[specific_name_lower]
						elif product_type_parent_data.get(specific_name_lower):
							value = product_type_parent_data.get(specific_name_lower)
							del product_type_parent_data[specific_name_lower]
						elif specific['type'] == 'boolean':
							value = 'false'
						elif specific['name'] == 'Parentage' and not is_set_parentage and (product.is_variant or product.variants):
							value = 'parent' if not product.is_variant else 'child'
						if value is not False:
							product_type_data[specific['name']] = value
					if product_type_data:

						if construct_specifics.get('item_specifics_key'):
							product_type_data = {
								construct_specifics['item_specifics_key']: product_type_data
							}
						product_data['ProductData'] = dict()

						product_type = amz_product_type_template.product_type.name.split('>')[-1]
						structures.append(product_type)
						base_product_type = structures[0]

						structures.reverse()
						temp = product_type_data
						for index_structure, row in enumerate(structures):
							special = False
							temp1 = {}
							if construct_specifics.get('item_specifics_key') and not index_structure and construct_specifics.get('parent_specifics'):
								temp1 = {}
								for parent_specific in construct_specifics.get('parent_specifics'):

									specific_name_lower = parent_specific['name'].lower()
									if parent_specific['type'] == 'variant_data':
										if variant_data and not set_variant_data:
											set_variant_data = True
											temp1[parent_specific['name']] = variant_data
										elif not is_set_parentage and parent_tage:
											temp1[parent_specific['name']] = {
												'Parentage': parent_tage
											}
									elif parent_specific['type'] == 'item_specifics_key':
										temp1[parent_specific['name']] = temp[construct_specifics['item_specifics_key']]
									elif specifics_data.get(specific_name_lower):
										if specifics_data.get(specific_name_lower) != 'false':
											temp1[parent_specific['name']] = specifics_data.get(specific_name_lower)
											del specifics_data[specific_name_lower]
									elif product_type_parent_data.get(specific_name_lower):
										temp1[parent_specific['name']] = product_type_parent_data.get(specific_name_lower)
										del product_type_parent_data[specific_name_lower]
								temp = copy.deepcopy(temp1)
								d = 4
							elif index_structure == 1 and construct_specifics.get('parent_specifics'):
								special = True

								temp1 = {}
								for parent_specific in construct_specifics.get('parent_specifics'):

									specific_name_lower = parent_specific['name'].lower()
									if parent_specific['type'] == 'variant_data':
										if variant_data and not set_variant_data:
											set_variant_data = True
											temp1[parent_specific['name']] = variant_data
										elif not is_set_parentage and parent_tage:
											temp1[parent_specific['name']] = {
												'Parentage': parent_tage
											}
										if is_home:
											home_data = {}
											home_specifics = ['Size', 'Color']
											for home_specific in home_specifics:
												if home_variant_data.get(home_specific.lower()):
													home_data[home_specific] = home_variant_data.get(home_specific.lower())
											if home_data:
												if not is_set_parentage and parent_tage:
													if parent_specific['name'] in temp1:
														del temp1[parent_specific['name']]
													temp1['Parentage'] = parent_tage
												temp1[parent_specific['name']] = home_data
									elif parent_specific['type'] == 'product_type':
										temp1[to_str(row).strip()] = temp
									elif specifics_data.get(specific_name_lower):
										if specifics_data.get(specific_name_lower) != 'false':
											temp1[parent_specific['name']] = specifics_data.get(specific_name_lower)
											del specifics_data[specific_name_lower]
									elif product_type_parent_data.get(specific_name_lower):
										temp1[parent_specific['name']] = product_type_parent_data.get(specific_name_lower)
										del product_type_parent_data[specific_name_lower]

							if not special:
								temp1 = {
									to_str(row).strip(): copy.deepcopy(temp)
								}
							# if index_structure == 1:
							# 	temp1.update(product_type_parent_data)
							temp = copy.deepcopy(temp1)

						product_data['ProductData'] = temp
					if is_shoes:
						product_type_data = {}
						for specific in specifics:
							specifics_data[specific['name'].lower()] = self.specific_to_value(specific)
						if not specifics_data.get('shoesize') and shoe_size_value:
							shoe_size_value_data = self.solve_shoes_size(real_shoe_size_value)
							if shoe_size_value_data:
								specifics_data.update(shoe_size_value_data)
							else:
								specifics_data['shoesize'] = shoe_size_value
						for field, list_field in SHOES_SPECIFICS.items():
							if field == 'VariationData' and variant_data:
								product_type_data[field] = variant_data
							if not list_field and specifics_data.get(field.lower()):
								product_type_data[field] = specifics_data[field.lower()]
							if list_field:
								list_field_data = {}
								for child_field in list_field:
									if specifics_data.get(child_field.lower()):
										list_field_data[child_field] = specifics_data.get(child_field.lower())
								if list_field_data:
									product_type_data[field] = list_field_data
						if product_type_data:
							product_data['ProductData'] = {
								"Shoes": product_type_data
							}

			after_product_type_fields = list(filter(lambda x: x['position'] == 3, AMAZON_DESCRIPTION_EXTEND))
			for field in after_product_type_fields:
				if description_data.get(field['name']):
					value = description_data[field['name']]
					if field.get('max_occurs') and isinstance(value, list):
						value = value[:field.get('max_occurs')]
					product_data[field['name']] = value
			# if amz_product_type_template.variant_data:
						# 	if product.is_variant:
						# 		product_data['ProductData'][base_product_type]['Parentage'] = 'child'
						# 	elif product.variants:
						# 		product_data['ProductData'][base_product_type]['Parentage'] = 'parent'
						# 	else:
						# 		product_data['ProductData'][base_product_type]['Parentage'] = 'base-product'
			message = {
				'MessageID': index,
				'OperationType': operation_type,
				'Product': product_data,
			}
			feed_content['AmazonEnvelope']['Message'].append(message)
		# POST products and check response
		if feed_content['AmazonEnvelope']['Message']:
			xml = self.parse_dict_to_xml(feed_content)
			# md5_hash = self.hash_md5_feed_content(xml)
			if is_local():
				return False
			feed = self.get_feed_object()
			response = feed.submit_feed(feed_type = 'POST_PRODUCT_DATA', file = xml, content_type = 'text/xml')

			response = self.check_submit_feed_response(response)
			if response.result != 'success':
				self.cache_errors = {product["_id"]: [Errors().get_msg_error(response.code)] for product in self.cache_products}
				return False
			submission_id = response.data
			if self.is_log():
				self.log(feed_content, f"feed_product_{submission_id}_request")
				self.log(xml, f"feed_product_{submission_id}_request_xml")
			check_submit = self.check_submit_feed_result(submission_id, 'Product')
			if not check_submit:
				return False
		# Insert map product
		for product in self.cache_products:
			if not self.cache_errors[product["_id"]] and (not self.is_amazon_gtin_exemption() or product.is_variant or not product.variants):
				self.insert_map_product(product, product['_id'], product.sku)
		return True


	def solve_shoes_size(self, shoe_size_value):
		regex = 'M (.*)/(.*) \| W (.*)/(.*)'
		check_regex = re.findall(regex, shoe_size_value)
		if check_regex and len(check_regex[0]) == 4:
			shoe_size_data = {
				'shoesizegenderunisex': 'men',
				'shoesizeunisex': self.mapping_size_value(check_regex[0][0], 'ShoeSize'),
				'shoesizetorangeunisex': self.mapping_size_value(check_regex[0][1],'ShoeSize'),
			}
			return shoe_size_data
		return False


	def feed_update_price(self):
		operation_type = 'Update'

		currency = self.get_currency()
		feed_content = self.get_default_feed_content('Price')
		for index, product in enumerate(self.cache_products, 1):
			if self.cache_errors.get(product["_id"])  or product.is_parent_product:
				continue
			# offer_template = product.template_data.offer or Prodict().from_dict(self.offer_template)
			price_template = product.template_data.price or Prodict()
			sku = product.sku
			price = product.price
			special_price = product.special_price
			if price_template.special_price:
				special_price.update(price_template.special_price)
			map_price = price_template.map
			price_data = {
				'SKU': sku,
				'StandardPrice': {
					'@currency': 'DEFAULT',
					'#text': to_str(price),
				}
			}
			if map_price and map_price.status == 'enable' and map_price.price:
				price_data['MAP'] = {
					'@currency': 'DEFAULT',
					'#text': to_str(map_price.price)
				}
			if self.is_special_price(product) and (special_price.start_date or special_price.sale_start_date) and (special_price.end_date or special_price.sale_end_date):
				if not self.is_setting_use_sale_price():
					start_date = to_str(special_price.start_date or special_price.sale_start_date).replace(' ','T')
					end_date = to_str(special_price.end_date or special_price.sale_end_date).replace(' ', 'T')
					if to_len(start_date) == 10:
						start_date = convert_format_time(special_price.start_date or special_price.sale_start_date, new_format = '%Y-%m-%dT%H:%M:%S',old_format = "%Y-%m-%d")
					if to_len(end_date) == 10:
						end_date = convert_format_time(special_price.end_date or special_price.sale_end_date, new_format = '%Y-%m-%dT%H:%M:%S',old_format = "%Y-%m-%d")
					price_data['Sale'] = {
						'StartDate': start_date,
						'EndDate': end_date,
						'SalePrice': {
							'@currency': currency,
							'#text': to_str(special_price.price),
						},
					}

			message = {
				'MessageID': index,
				'OperationType': operation_type,
				'Price': price_data,
			}
			feed_content['AmazonEnvelope']['Message'].append(message)
		if feed_content['AmazonEnvelope']['Message']:
			xml = self.parse_dict_to_xml(feed_content)
			# md5_hash = self.hash_md5_feed_content(xml)
			feed = self.get_feed_object()
			response = feed.submit_feed(feed_type = 'POST_PRODUCT_PRICING_DATA', file = xml, content_type = 'text/xml')
			response = self.check_submit_feed_response(response)
			if response.result != Response.SUCCESS:
				return False
			price_submission_id = response.data
			self.check_submit_feed_result(price_submission_id, 'Price')
			if self.is_log():
				self.log(feed_content, f"feed_price_{price_submission_id}_request")
				self.log(xml, f"feed_price_{price_submission_id}_xml_request")


	def feed_update_image(self):
		operation_type = self.get_product_operation_type()

		feed_content = self.get_default_feed_content('ProductImage')
		feed_image_index = 1
		for index, product in enumerate(self.cache_products, 1):
			if self.cache_errors.get(product["_id"]):
				continue
			# offer_template = product.template_data.offer or Prodict().from_dict(self.offer_template)
			sku = product.sku

			images = []
			if product.thumb_image.url:
				images.append(product.thumb_image.url)
			for image in product.images:
				images.append(image.url)
			for image_index, image in enumerate(images):
				if not image_index:
					image_type = 'Main'
				elif image_index <= 8:
					image_type = f'PT{image_index}'
				elif image_index == 9:
					image_type = f'PT98'
				elif image_index == 10:
					image_type = f'PT99'
				else:
					break
				self.cache_images[feed_image_index] = {
					'product_id': product['_id'],
					'image': image
				}
				image_data = {
					'SKU': sku,
					'ImageType': image_type,
					'ImageLocation': image
				}

				message = {
					'MessageID': feed_image_index,
					'OperationType': operation_type,
					'ProductImage': image_data,
				}
				feed_image_index += 1
				feed_content['AmazonEnvelope']['Message'].append(message)
		if feed_content['AmazonEnvelope']['Message']:
			xml = self.parse_dict_to_xml(feed_content)
			# md5_hash = self.hash_md5_feed_content(xml)
			feed = self.get_feed_object()
			response = feed.submit_feed(feed_type = 'POST_PRODUCT_IMAGE_DATA', file = xml, content_type = 'text/xml')
			response = self.check_submit_feed_response(response)
			image_submission_id = response.data
			if self.is_log():
				self.log(feed_content, f"feed_image_{image_submission_id}_request")
			if response.result != Response.SUCCESS:
				return False
			self.check_submit_feed_result(image_submission_id, 'Image')

	def feed_update_relationship(self):
		operation_type = self.get_product_operation_type()

		feed_content = self.get_default_feed_content('Relationship')
		feed_image_index = 1
		for parent_sku, skus in self.product_relations_ship.items():
			product_parent_id = self._product_skus[parent_sku]

			if self.cache_errors.get(product_parent_id):
				break

			relations = []
			for sku in skus:
				product_child_id = self._product_skus[sku]

				if self.cache_errors.get(product_child_id):
					continue
				relations.append({
					'SKU': sku,
					'Type': 'Variation'
				})
			relationship = {
				'ParentSKU': parent_sku,
				'Relation': relations
			}

			message = {
				'MessageID': feed_image_index,
				'OperationType': operation_type,
				'Relationship': relationship,
			}
			feed_image_index += 1
			feed_content['AmazonEnvelope']['Message'].append(message)
		if feed_content['AmazonEnvelope']['Message']:
			xml = self.parse_dict_to_xml(feed_content)
			# md5_hash = self.hash_md5_feed_content(xml)
			feed = self.get_feed_object()
			response = feed.submit_feed(feed_type = 'POST_PRODUCT_RELATIONSHIP_DATA', file = xml, content_type = 'text/xml')
			response = self.check_submit_feed_response(response)
			if response.result != Response.SUCCESS:
				return False
			submission_id = response.data
			if self.is_log():
				self.log(feed_content, f"feed_relationship_{submission_id}_request")
			self.check_submit_feed_result(submission_id, 'Relationship')

	def feed_update_inventory(self):
		operation_type = self.get_product_operation_type()
		feed_content = self.get_default_feed_content('Inventory')
		for index, product in enumerate(self.cache_products, 1):
			if self.is_log():
				self.log(product, 'product_inventory')
			if self.cache_errors.get(product["_id"]) or product.is_parent_product:
				continue
			channel_data = copy.deepcopy(product.channel[f'channel_{self.get_channel_id()}'])
			if channel_data:
				channel_data = Prodict.from_dict(channel_data)
			if not channel_data.template_data or not channel_data.template_data.offer:
				self.cache_errors[product['_id']].append("No Offer")
				continue
			offer_template = OfferTemplate.from_dict(channel_data.template_data.offer) if channel_data.template_data and channel_data.template_data.offer else OfferTemplate()
			# price_template = product.template_data.price or Prodict()
			sku = product.sku
			qty = product.qty
			fulfillment = offer_template.fulfillment
			handling_time = offer_template.handling_time
			restock_date = offer_template.restock_date
			marketplace_id = self.get_marketplace_id_api()
			fulfillment_center_id = self.FULFILLMENT_CENTER.get(marketplace_id, 'AMAZON_NA')
			if fulfillment == 'fbm':
				inventory_data = {
					'SKU': sku,
					'FulfillmentCenterID': 'DEFAULT',
					'Quantity': to_int(qty),
					'RestockDate': restock_date,
					'FulfillmentLatency': to_int(handling_time),
					"SwitchFulfillmentTo": "MFN"
				}
			else:
				inventory_data = {
					'SKU': sku,
					'FulfillmentCenterID': fulfillment_center_id,
					'Lookup': 'FulfillmentNetwork',
					'RestockDate': restock_date,
					'FulfillmentLatency': to_int(handling_time),
					'SwitchFulfillmentTo': 'AFN',
				}
			if not restock_date or self.is_inventory_process():
				del inventory_data['RestockDate']
			if not handling_time or self.is_inventory_process() or fulfillment == 'fba':
				del inventory_data['FulfillmentLatency']

			message = {
				'MessageID': index,
				'OperationType': operation_type,
				'Inventory': inventory_data,
			}
			feed_content['AmazonEnvelope']['Message'].append(message)
		if feed_content['AmazonEnvelope']['Message']:
			xml = self.parse_dict_to_xml(feed_content)
			try:
				# md5_hash = self.hash_md5_feed_content(xml)
				feed = self.get_feed_object()
				response = feed.submit_feed(feed_type = 'POST_INVENTORY_AVAILABILITY_DATA', file = xml, content_type = 'text/xml')
				response = self.check_submit_feed_response(response)
				if response.result != Response.SUCCESS:
					return False
				inventory_submission_id = response.data
				self.check_submit_feed_result(inventory_submission_id, 'Inventory')
			except:
				self.log_traceback()


	def addition_product_import(self):
		if not self.cache_products:
			return Response().success()
		self.cache_errors = {product["_id"]: [] for product in self.cache_products}
		self.cache_warnings = {product["_id"]: [] for product in self.cache_products}
		# Update operation type will override all data and PartialUpdate just override only specific fields
		import_cache_product = True
		if not self.is_inventory_process():
			import_cache_product = self.import_cache_products()
		if import_cache_product and self.is_amazon_gtin_exemption():
			for product in self.cache_products:
				try:
					if not self.cache_errors.get(product['_id']):
						sku = product.sku
						listing = self.get_listing_item(sku, included_data = 'summaries,issues')
						if listing and listing.status_code < 300:
							listing_data = listing.payload
							if listing_data.get('summaries'):
								summaries = listing_data['summaries'][0]
								asin = summaries.get('asin')
								if asin:
									product['new_asin'] = asin
							elif listing_data.get('issues'):
								for issue in listing_data['issues']:
									self.cache_errors[product['_id']].append(issue['message'])
				except:
					self.log_traceback()
					continue

		# Import products price
		if import_cache_product and (not self._update_product or self._update_price or (self.is_inventory_process() and self._update_price)):
			self.feed_update_price()

		# Import Feed type: Inventory
		if import_cache_product and (not self._update_product or self._update_qty or (self.is_inventory_process() and self._update_qty)):
			self.feed_update_inventory()
		if import_cache_product:
			if not self.is_inventory_process():
				self.feed_update_image()
			if self.is_amazon_gtin_exemption():
				if not self._state.channel.config.api.skip_update_realation_ship:
					self.feed_update_relationship()
		# Reset cache_products for next import round.
		for product in self.cache_products:
			if product.variants:
				continue
			if not import_cache_product or self.cache_errors.get(product["_id"]):
				error = "\n".join(self.cache_errors[product["_id"]]) if self.cache_errors[product["_id"]] else "Don't submit feed"

				self.after_push_product(product['_id'], Response().error(msg = error), product)
				self.log(f'Error product_id {product["_id"]}: {error}', 'products')

			else:
				self.after_push_product(product['_id'], Response().success(), product)
			if self.cache_warnings.get(product["_id"]):
				for warning in self.cache_warnings[product["_id"]]:
					self.log(f'Warning {product["_id"]}: {warning}', 'products')
		for parent_id, variant_ids in self.parent_variants.items():
			errors = list(filter(lambda x: self.cache_errors.get(x), variant_ids))
			if import_cache_product and not errors:
				self.after_push_product(parent_id, Response().success(), self.parent_products[parent_id])
				if self.is_inventory_process():
					self.update_qty_for_parent(parent_id)
			else:
				if import_cache_product:
					msg_errors = "\n".join(self.cache_errors[errors[0]])
				else:
					msg_errors = 'You have {} variant{} import error'.format(len(errors), "s" if len(errors) > 1 else '')
				self.after_push_product(parent_id, Response().error(msg = msg_errors), self.parent_products[parent_id])

		self._state.push.process.products.error += len([1 for errors in self.cache_errors.values() if errors])
		self.cache_products = []
		return Response().success()


	def after_push_product(self, product_id, import_data, product: Product):
		if self.is_inventory_process():
			if import_data.result == Response.SUCCESS:
				update_field = dict()
				if self.is_setting_sync_qty():
					update_field[f"channel.channel_{self._state.channel.id}.qty"] = product.qty
					if product.qty <= 0 and product['channel'][f'channel_{self.get_channel_id()}'].get('amazon_status') != 'Inactive':
						update_field[f"channel.channel_{self._state.channel.id}.amazon_status"] = 'Inactive'
					if product.qty > 0 and product['channel'][f'channel_{self.get_channel_id()}'].get('amazon_status') != 'Active':
						update_field[f"channel.channel_{self._state.channel.id}.amazon_status"] = 'Active'
				if self.is_setting_sync_price():
					update_field[f"channel.channel_{self._state.channel.id}.price"] = product.price
				if update_field:
					self.get_model_catalog().update(product_id, update_field)
			return Response().success(product)
		update_field = dict()
		product_channel_data = product['channel'][f'channel_{self._state.channel.id}']
		if import_data.result in (Response.ERROR, Response.WARNING):
			publish_status = ProductChannel.ERRORS
			msg = import_data.msg or Errors().get_msg_error(import_data.code)
			if "You are not authorized to list products under this brand" in msg:
				msg += " " + url_to_link("https://sellercentral.amazon.com/help/hub/reference/200942550#", "More details")
			if not product_channel_data.get('product_id'):
				update_field[f"channel.channel_{self._state.channel.id}.status"] = ProductChannel.ERRORS
			update_field[f'channel.channel_{self.get_channel_id()}.server_error'] = self.get_server_name()

		else:
			msg = ''
			publish_status = ProductChannel.COMPLETED
			update_field[f"channel.channel_{self._state.channel.id}.edited"] = False
			update_field[f"channel.channel_{self._state.channel.id}.status"] = 'active'
			update_field[f"channel.channel_{self._state.channel.id}.link_status"] = 'linked'
			update_field[f"channel.channel_{self._state.channel.id}.product_id"] = product.sku
			update_field[f"channel.channel_{self._state.channel.id}.product_sku"] = product.sku
			update_field[f"channel.channel_{self._state.channel.id}.sku"] = product.sku
			if product.new_asin:
				update_field[f"channel.channel_{self._state.channel.id}.asin"] = product.new_asin
				update_field[f"channel.channel_{self._state.channel.id}.asin_data"] = {
					'name': product.name,
					'thumbnail': product.thumb_image.url,
					'asin': product.new_asin,
					'url': f'{self.get_amazon_domain()}/gp/product/{product.new_asin}',
				}

		update_field[f"channel.channel_{self._state.channel.id}.publish_status"] = publish_status
		update_field[f"channel.channel_{self._state.channel.id}.error_message"] = msg

		product.channel[f"channel_{self._state.channel.id}"] = self.get_product_channel_data(product, '')
		product.channel[f"channel_{self._state.channel.id}"]['publish_status'] = publish_status
		if "You are not authorized to list products under this brand" in msg:
			msg += f" {url_to_link('https://sellercentral.amazon.com/help/hub/reference/200942550', 'View details')}"
		product.channel[f"channel_{self._state.channel.id}"]['error_message'] = msg
		self.get_model_catalog().update(product_id, update_field)
		return Response().success(product)


	def check_submit_feed_response(self, response):
		"""
		Check response when submit feed to Amazon AMS.
		If submission complete successfully return submission_id, elif return errors message.
		Args:
			response (Prodict): response when submit feed.
		Return:
			_response object
		"""
		if not response:
			return Response().error(Errors.AMAZON_REQUEST_TIMEOUT)
		try:
			if not response or not isinstance(response, tuple):
				return Response().error(msg = 'error')
			create_feed = response[1]
			if create_feed.errors:
				error = create_feed.errors[0]
				if error.get('code') == 'InvalidInput' and error.get('message') == 'Invalid request parameters' and not error.get('details'):
					return Response().error(Errors.AMAZON_ACCOUNT_INACTIVE)
				return Response().error(msg = error.get('message'))

			submission_id = create_feed.payload.get('feedId')
		except Exception as e:
			self.log('Cannot get FeedSubmissionId when submit Feed.', 'submit_feed_errors')
			return Response().error(Errors.AMAZON_PUSH_PRODUCT_ERROR)
		if not submission_id:
			self.log('Cannot get FeedSubmissionId when submit Feed.', 'submit_feed_errors')
			return Response().error(Errors.AMAZON_PUSH_PRODUCT_ERROR)
		return Response().success(data = submission_id)


	def check_submit_feed_result(self, submission_id, feed_type):
		"""
		Check result of submit feed process and store submission result errors and warning into cache_errors, cache_warnings attributes.
		This function only work inside product_import function.
		Args:
			submission_id (str)
			feed_type (str)
		"""
		# start = time.time()
		time.sleep(1)
		feed = self.get_feed_object()
		response = feed.get_feed(feedId = submission_id)
		count = 0
		total_count = max(len(self.cache_products) * 60, 100)
		while count < total_count:
			if not response or response.errors:
				self.log(response.errors, 'feed_errors')
				errors = obj_to_list(response.errors)
				for error in errors:
					error = Prodict.from_dict(error)
					if error.Error.Code.get('$') == 'FeedProcessingResultNotReady':
						self.log(f"NOT READY: sleep {self.FEED_SLEEP}s time {count} for submission id {submission_id} {feed_type}", 'submission')
						time.sleep(self.FEED_SLEEP)
						response = feed.get_feed(feedId = submission_id)
						count += 1
					else:
						break
			else:
				if response.payload and response.payload.get('processingStatus') != 'DONE':
					self.log(f"PROCESSING: sleep {self.FEED_SLEEP}s time {count} for submission id {submission_id} {feed_type}", 'submission')
					time.sleep(self.FEED_SLEEP)
					response = feed.get_feed(feedId = submission_id)
					count += 1
				else:
					break
		if response.payload and response.payload.get('processingStatus') != 'DONE':
			for product in self.cache_products:
				self.cache_errors[product['_id']].append(f'Time expired when getting {feed_type} submission result.')
				self.get_feed_object().cancel_feed(submission_id)
			return False
		self.log(f"DONE: {submission_id} {feed_type}", 'submission')

		result_document1 = feed.get_feed_result_document(response.payload.get('resultFeedDocumentId'))
		result_document2 = result_document1.replace('<?xml version="1.0" encoding="UTF-8"?>', '')
		result_document = Prodict.from_dict(json.loads(json.dumps(xmltodict.parse(result_document2))))
		if self.is_log():
			self.log(result_document, f"feed_{feed_type}_{submission_id}_response")
		if result_document.AmazonEnvelope.Message.ProcessingReport.Result:
			if isinstance(result_document.AmazonEnvelope.Message.ProcessingReport.Result, dict):
				result_document.AmazonEnvelope.Message.ProcessingReport.Result = [result_document.AmazonEnvelope.Message.ProcessingReport.Result]
			for message_result in result_document.AmazonEnvelope.Message.ProcessingReport.Result:
				message_id = to_int(message_result.MessageID)
				result_code = message_result.ResultCode
				message_code = message_result.ResultMessageCode
				message_description = Errors().get_msg_error(to_int(message_code), message_result.ResultDescription)
				message_description = self.solve_message_description(message_description)
				if message_id:
					if feed_type not in ['Image', 'Relationship']:
						product = self.cache_products[message_id - 1]
						if result_code == 'Error':
							self.log(f"{product['_id']} error: {message_result.ResultDescription}", f'feed_{feed_type}_error')
							self.cache_errors[product["_id"]].append(message_description)
						if result_code == 'Warning':
							self.cache_warnings[product["_id"]].append(message_description)
					else:
						if result_code in ['Error', 'Warning']:
							if feed_type == 'Image':
								product_image = self.cache_images[message_id]
								self.log(f"{product_image['product_id']} image {product_image['image']} error: {message_result.ResultDescription}", f'feed_{feed_type}_error')
							else:
								self.log(f" error: {message_result.ResultDescription}", f'feed_{feed_type}_error')
		return True


	def solve_message_description(self, message):
		try:
			match_message = re.findall('''XML Parsing Error at (.*?)Value '(.*?)' is not facet-valid with respect to enumeration '\[(.*?)\]'. It must be a value from the enumeration. XML Parsing Error at Line(.*?)The value '(.*?)' of element '(.*?)' is not valid''', message)
			if match_message:
				field = match_message[-1]
				if field in list(set(AMAZON_CLOTHING_TYPE_SIZE.values())):
					field = 'Size'
				message = f"The value '{match_message[1]}' of element '{field}' is not valid. Please choose from the list: {match_message[2]}"
		except:
			self.log_traceback()
			return message
		return message


	def field_to_bullet_point(self, product):
		if self._state.channel.config.api.field_to_bullet_point and product.get(self._state.channel.config.api.field_to_bullet_point):
			bullet_point = self.strip_html_from_description(to_str(product.get(self._state.channel.config.api.field_to_bullet_point)))
			while bullet_point.find('\n\n') != -1:
				bullet_point = bullet_point.replace('\n\n', '\n')
			bullet_point = bullet_point.split('\n')
			bullet_point = list(filter(lambda x: 500 > len(x) > 40, bullet_point))
			bullet_point = bullet_point[:5]
			return bullet_point
		return []

	def channel_assign_amz_seo_template(self, product, template_data):
		if template_data.get('tags_to_search_term') == 'enable':
			product['channel'][f'channel_{self.get_channel_id()}']['template_data']['amz_seo']['search_terms'] = product['tags']
		if self._state.channel.config.api.field_to_bullet_point and product.get(self._state.channel.config.api.field_to_bullet_point):
			bullet_point = self.field_to_bullet_point(product)

			product['channel'][f'channel_{self.get_channel_id()}']['template_data']['amz_seo']['bullet_point'] = bullet_point
		elif template_data.get('bullet_point') and isinstance(template_data['bullet_point'], list):
			bullet_points = template_data['bullet_point']
			new_bullet_points = []
			for bullet_point in bullet_points:
				bullet_point = self.assign_attribute_to_field(bullet_point, product)
				if bullet_point:
					new_bullet_points.append(bullet_point)
			if new_bullet_points:
				bullet_points = list(filter(lambda x: len(to_str(x)) > 0, new_bullet_points))
				template_data['bullet_point'] = bullet_points

				product['channel'][f'channel_{self.get_channel_id()}']['template_data']['amz_seo']['bullet_point'] = bullet_points

		return product


	def channel_assign_amz_product_type_template(self, product, template_data):
		shipping_details = template_data.get('shipping_details')

		if shipping_details:
			shipping_details_data = {}
			for shipping_name, shipping_detail in shipping_details.items():
				if not shipping_detail.override and not shipping_detail.mapping:
					continue
				if shipping_detail.override:
					value = shipping_detail.override
				else:
					value = shipping_detail.mapping
				new_value = self.assign_attribute_to_field(value, product)
				if to_decimal(new_value):
					shipping_detail.value = to_str(to_decimal(new_value, 2))
				shipping_details_data[shipping_name] = shipping_detail
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['amz_product_type']['shipping_details'] = shipping_details_data
		specifics_fields = ['specifics', 'parent_specifics', 'description_specifics']

		if template_data.get('variant_data', {}).get('variant_theme'):
			if not product.is_variant and product.variant_count > 0:
				variant_theme = to_str(template_data.get('variant_data', {}).get('variant_theme'))
				if variant_theme.find('-') != -1:
					variant_themes = to_str(template_data.get('variant_data', {}).get('variant_theme')).split('-')
				else:
					if variant_theme.lower().find('color') != -1 and variant_theme.lower().find('size') != -1:
						variant_themes = split_by_title_word(variant_theme)
					else:
						variant_themes = [variant_theme]
				product['channel'][f'channel_{self.get_channel_id()}']['variant_attributes'] = variant_themes
			elif product.is_variant:
				variant_attribute_data = []
				variant_specifics = template_data['variant_data']['specifics']
				for specific in variant_specifics:
					if not specific.get('override') and not specific.get('mapping'):
						continue
					if specific.get('override'):
						value = specific['override']
					else:
						value = specific['mapping']
					specific.value = self.assign_attribute_to_field(value, product)

					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_name = specific.name
					attribute_data.attribute_value_name = specific.value
					attribute_data.is_variant_attribute = specific.is_variant_attribute
					if specific.unit:
						attribute_data.variant_unit = specific.unit

					variant_attribute_data.append(attribute_data)
				product['channel'][f'channel_{self.get_channel_id()}']['template_data']['amz_product_type']['variant_data']['specifics'] = variant_specifics
				product['channel'][f'channel_{self.get_channel_id()}']['attributes'] = variant_attribute_data
			else:
				variant_specifics = template_data['variant_data']['specifics']
				if variant_specifics:
					template_data['specifics'].extend(variant_specifics)
					template_data['parent_specifics'].extend(variant_specifics)
		for specifics_field in specifics_fields:
			item_specifics = template_data.get(specifics_field)
			if not item_specifics:
				continue
			for specific in item_specifics:
				if not specific.override and not specific.mapping:
					specific.value = ''
					continue
				if specific.override:
					value = specific.override
				else:
					value = specific.mapping
				if specific.type == 'boolean':
					specific.value = 'true' if value == 'yes' else 'false'
					continue
				specific.value = self.assign_attribute_to_field(value, product)
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['amz_product_type'][specifics_field] = item_specifics
		return product
	def channel_assign_amz_details_template(self, product, template_data):
		specifics_fields = ['description_specifics']
		for specifics_field in specifics_fields:
			item_specifics = template_data.get(specifics_field)
			if not item_specifics:
				continue
			for specific in item_specifics:
				if not specific.override and not specific.mapping:
					continue
				if specific.override:
					value = specific.override
				else:
					value = specific.mapping
				if specific.type == 'boolean':
					specific.value = 'true' if value == 'yes' else 'false'
					continue
				specific.value = self.assign_attribute_to_field(value, product)
			product.channel[f'channel_{self.get_channel_id()}']['template_data']['amz_details'][specifics_field] = item_specifics

		return product

	def channel_assign_offer_template(self, product, template_data):
		condition = template_data['condition']
		if product.condition and condition.get(product.condition):
			condition['value'] = condition.get(product.condition)
			product['channel'][f'channel_{self.get_channel_id()}']['template_data']['offer']['condition'] = condition

		return product


	def channel_assign_price_template(self, product, template_data):
		price_setting = self._state.channel.config.setting.get('price')
		if price_setting and price_setting.get('use_sale_price') == 'enable' and self.is_special_price(product):
			product['price'] = product.special_price.price
			product['special_price'] = ProductSpecialPrice()

			product.channel[f'channel_{self.get_channel_id()}']['special_price'] = ProductSpecialPrice()
		fields = ['price', 'special_price', 'msrp', 'map']
		real_price = product['price']
		for field in fields:
			field_data = template_data.get(field)
			if not field_data or (field != 'price' and field_data.get('status') != 'enable'):
				continue
			price = self.adjustment_price(field_data, real_price, product)
			if field == 'price':
				product.price = price
				product.channel[f'channel_{self.get_channel_id()}']['price'] = price
			elif field == 'special_price':
				special_price = copy.deepcopy(product.special_price)
				special_price.price = price
				product.special_price = special_price
				product.channel[f'channel_{self.get_channel_id()}']['special_price'] = special_price
			else:
				template_data[field]['price'] = price
		product.channel[f'channel_{self.get_channel_id()}']['template_data']['price'] = template_data
		return product


	# Export Orders

	def get_order_id_import(self, convert: Order, order, orders_ext):
		return to_str(order.get('AmazonOrderId'))


	def set_order_max_last_modifier(self, last_modifier):
		if to_str(last_modifier).isnumeric():
			last_modifier_time = to_int(last_modifier)
		else:
			last_modifier_time = to_timestamp(last_modifier, '%Y-%m-%dT%H:%M:%S')
		if last_modifier_time and (not self._order_max_last_modified or last_modifier_time > to_timestamp(self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
			self._order_max_last_modified = last_modifier


	def get_orders_main_export(self):
		if self._flag_finish_order:
			return Response().finish()
		orders = []
		next_token = self._state.pull.process.orders.next_token
		order_obj = self.get_order_object()
		if next_token:
			response = order_obj.get_orders(NextToken = next_token)
		else:
			last_modifier = self._state.pull.process.orders.max_last_modified
			created_after = self.get_order_start_time('iso')
			if not created_after:
				created_after = '2013-09-01T00:00:00Z'
			extra_data = dict(MarketplaceIds = [self.get_marketplace_id_api()])
			extra_data['CreatedAfter'] = created_after
			extra_data['MaxResultsPerPage'] = 100
			if last_modifier:
				del extra_data['CreatedAfter']
				# last_modifier = convert_format_time(last_modifier, new_format = '%Y-%m-%dT%H:%M:%SZ')
				extra_data['LastUpdatedAfter'] = last_modifier
			response = order_obj.get_orders(**extra_data)
		if response.payload and response.payload.get('Orders'):
			orders = response.payload.get('Orders')
		self.next_token = response.next_token
		if not self.next_token:
			self._flag_finish_order = True
		if not orders:
			return Response().finish()
		return Response().success(data = orders)


	def get_order_by_id(self, order_id):
		model_order = self.get_order_object()
		order = model_order.get_order(order_id)
		if order and order.payload:
			return Response().success(order.payload)
		return Response().success()


	def get_orders_ext_export(self, orders):
		# extends = list()
		# for order in orders:
		# 	order_id = order.get('AmazonOrderId')
		# 	order_ext_data = Prodict()
		# 	order_ext_data['AmazonOrderId'] = order_id
		# 	order_ext_data['items'] = list()
		#
		# 	order_obj = self.get_order_object()
		# 	response = self.api(order_obj, 'get_order_items', order_id = order_id)
		# 	if not response:
		# 		continue
		# 	if response.errors:
		# 		self.log(f'Order Id: {order_id}' + to_str(response.errors), 'get_exts_order_errors')
		# 		continue
		# 	order_ext_data['items'].extend(response.payload.get('OrderItems'))
		# 	next_token = response.next_token
		# 	while next_token:
		# 		response = self.api(order_obj, 'get_order_items', NextToken = next_token)
		# 		# response = order_obj.get_order_items(order_id, NextToken = next_token)
		# 		if not response:
		# 			break
		# 		if response.errors:
		# 			self.log(f'Order Id: {order_id}' + to_str(response.errors), 'get_exts_order_errors')
		# 			continue
		# 		order_ext_data['items'].extend(response.payload.get('OrderItems'))
		# 		next_token = response.next_token
		#
		# 	response_address = self.api(order_obj, 'get_order_address', order_id = order_id)
		# 	if not response_address: continue
		# 	if response_address.errors:
		# 		self.log(f'Order Id: {order_id}' + to_str(response_address.errors), 'get_exts_order_errors')
		# 		continue
		# 	extends.append(order_ext_data)
		# 	order_ext_data['address'] = response_address.payload.get('ShippingAddress')
		#
		# 	response_buyer_info = self.api(order_obj, 'get_order_buyer_info', order_id = order_id)
		# 	if not response_buyer_info: continue
		# 	if response_buyer_info.errors:
		# 		self.log(f'Order id: {order_id}' + to_str(response.errors), 'get_exts_order_errors')
		# 		continue
		# 	order_ext_data['buyer_info'] = response_buyer_info.payload
		return Response().success()


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def get_order_items(self, order_id):
		order_obj = self.get_order_object()
		response = order_obj.get_order_items(order_id)
		if response.status_code != 200:
			return False
		order_items = response.payload.get('OrderItems')
		while response.next_token:
			response = order_obj.get_order_items(order_id, NextToken = response.next_token)
			if response.status_code == 200:
				order_items += response.payload.get('OrderItems')
		return list(map(lambda x: Prodict(**x), order_items))


	def get_order_buyer_info(self, order_id):
		order_obj = self.get_order_object()
		response = order_obj.get_order_buyer_info(order_id)
		if response.status_code != 200:
			return False
		return Prodict(**response.payload)


	def get_order_address(self, order_id):
		order_obj = self.get_order_object()
		response = order_obj.get_order_address(order_id)
		if response.status_code != 200:
			return False
		return Prodict(**response.payload)


	def split_customer_fullname(self, fullname):
		first_name, last_name = super().split_customer_fullname(fullname)
		first_name = re.sub('[0-9]', '', first_name)
		last_name = re.sub('[0-9]', '', first_name)
		if last_name.find('marketplace.amazon.') != -1:
			last_name = first_name
		return first_name, last_name


	def convert_order_export(self, order, orders_ext, channel_id = None):
		# order.PurchaseDate = order.PurchaseDate[0:19]
		order_create = isoformat_to_datetime(order.PurchaseDate)
		start_time = isoformat_to_datetime(self._state.channel.config.start_time)
		status = order.OrderStatus if order.OrderStatus else None

		if order_create.timestamp() < start_time.timestamp() or not status or status in ['PendingAvailability', 'Pending', 'Unfulfillable']:
			return Response().skip()
		self.set_order_max_last_modifier(order.LastUpdateDate)
		order_data = Order()
		# purchase_timestamp = min(to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%SZ'), to_timestamp(order.PurchaseDate.get('$'), '%Y-%m-%dT%H:%M:%S.%fZ'))
		order_id = to_str(order.AmazonOrderId)

		order_data.id = order_id  # + '-' + to_str(purchase_timestamp)
		order_data.order_number = order_id
		status = order.OrderStatus if order.OrderStatus else None
		order_data.status = self.ORDER_STATUS.get(status, Order.OPEN)
		order_items = self.get_order_items(order_id)
		# if status == 'Canceled':
		# 	return Response().success(order_data)
		if not order_items:
			return Response().error(msg = f"Order {order_id} Can't find order item")
		customer_email = ''
		retry_email = 0
		while not customer_email and retry_email < 10:
			buyer_info = self.get_order_buyer_info(order_id) or Prodict()
			# if not buyer_info:
			# 	return Response().error(msg = f"Order {order_id} Can't find buyer info")
			customer_email = buyer_info.BuyerEmail
			if not customer_email:
				if not retry_email:
					if isinstance(buyer_info, dict):
						buyer_info['order_id'] = order_id
					self.log(buyer_info, 'buyer_info')
				retry_email += 1
				self.log(f'order id {order_id} get buyer info sleep {customer_email}', 'buyer_info_sleep')
				time.sleep(retry_email * 1)
		address = self.get_order_address(order_id)
		if not address:
			return Response().error(msg = "Can't find address")
		if not customer_email:
			customer_email = f'{to_str(order_id).replace("-", "")}@marketplace.amazon.com'
		additional_details = {
			'EarliestShipDate': 'Amazon Earliest Ship Date',
			'EarliestDeliveryDate': 'Amazon Earliest Delivery Date',
			'LatestShipDate': 'Amazon Latest Ship Date',
			'LatestDeliveryDate': 'Amazon Latest Delivery Date',
			'SalesChannel': 'Amazon Sales Channel',
		}
		for field, detail_name in additional_details.items():
			if order.get(field):
				order_data.additional_details.append({
					'name': detail_name,
					'value': order[field],
				})
		fulfillment_channel = 'FBM' if order.FulfillmentChannel else 'FBA'
		order_data.additional_details.append({
			'name': 'Amazon Fulfillment Channel',
			'value': fulfillment_channel,
		})
		# Payment & shipped
		if order_data.status != Order.CANCELED:
			order_data.payment.status = True
		order_data.payment.method = order.PaymentMethodDetails[0] if order.PaymentMethodDetails else ''
		if order_data.status in [order.SHIPPING, order.COMPLETED]:
			order_data.shipping.status = True
		order_data.shipping.method = order.ShipmentServiceLevelCategory if order.ShipmentServiceLevelCategory else ''
		order_data.created_at = convert_format_time(order.PurchaseDate, '%Y-%m-%dT%H:%M:%S')
		order_data.updated_at = convert_format_time(order.LastUpdateDate, '%Y-%m-%dT%H:%M:%S')
		order_data.total = to_decimal(order.OrderTotal.Amount) if order.OrderTotal else 0.0
		order_data.customer.email = customer_email

		order_data.channel_data = {
			'order_status': to_str(status),
			'created_at': order_data.created_at,
			'shipped_date': convert_format_time(order.LatestShipDate, '%Y-%m-%dT%H:%M:%S.%fZ')
		}
		# if order.ShippingAddress:
		# 	order_data.shipping_address.last_name = order.ShippingAddress.Name if order.ShippingAddress.Name else ''
		# 	order_data.shipping_address.address_1 = order.ShippingAddress.AddressLine1 if order.ShippingAddress.AddressLine1 else ''
		# 	order_data.shipping_address.city = order.ShippingAddress.City if order.ShippingAddress.City else ''
		# 	order_data.shipping_address.state.state_code = order.ShippingAddress.StateOrRegion if order.ShippingAddress.StateOrRegion else ''
		# 	order_data.shipping_address.state.state_name = order_data.customer_address.state.state_code
		# 	order_data.shipping_address.postcode = order.ShippingAddress.PostalCode if order.ShippingAddress.PostalCode else ''
		# 	order_data.shipping_address.country.country_code = order.ShippingAddress.CountryCode if order.ShippingAddress.CountryCode else ''
		# 	order_data.shipping_address.country.country_name = order_data.customer_address.country.country_code
		# 	order_data.customer_address = order_data.shipping_address

		if order.TaxClassifications:
			order_data.tax.title = order.TaxClassifications.TaxClassification
			order_data.tax.amount = order.TaxClassifications.value
		customer_name = order.BuyerName
		order_data.customer.last_name = order.BuyerName if order.BuyerName else ''
		shipping_address = address.ShippingAddress

		buyer_name = buyer_info.BuyerName or (shipping_address.Name if shipping_address else '') or to_str(customer_email).replace('@', ' ')
		first_name, last_name = self.split_customer_fullname(buyer_name)
		# last_name = ''
		# if buyer_name:
		# 	buyer_name = buyer_name.split(" ", 1)
		# 	if len(buyer_name) >= 2:
		# 		first_name = buyer_name[0]
		# 		last_name = buyer_name[1]
		# 	else:
		# 		customer_name = re.sub(r"([A-Z])", r" \1", order.name).split()
		# 		if len(customer_name) >= 2:
		# 			first_name = customer_name[0]
		# 			del customer_name[0]
		# 			last_name = ''.join(customer_name)
		buyer_info_data = OrderCustomer()
		# buyer_info_data.first_name = first_name
		# buyer_info_data.last_name = last_name
		# buyer_info_data.email = buyer_info.BuyerEmail
		# buyer_info_data.PurchaseOrderNumber = buyer_info.PurchaseOrderNumber
		order_data.customer.first_name = first_name
		order_data.customer.last_name = last_name

		if shipping_address:
			address_data = OrderAddress()
			address_data.first_name = first_name
			address_data.last_name = last_name
			address_data.address_1 = shipping_address.AddressLine1
			address_2 = []
			if shipping_address.AddressLine2:
				address_2.append(shipping_address.AddressLine2)
			if shipping_address.AddressLine3:
				address_2.append(shipping_address.AddressLine3)

			address_data.address_2 = "\n".join(address_2)
			address_data.city = shipping_address.City
			address_data.state.state_code = shipping_address.StateOrRegion
			# address_data.state.state_name = order_data.customer_address.state.state_code
			address_data.postcode = shipping_address.PostalCode
			address_data.country.country_code = shipping_address.CountryCode
			address_data.telephone = shipping_address.Phone
			# address_data.country.country_name = order_data.customer_address.country.country_code
			order_data.shipping_address.update(address_data)
			order_data.customer_address.update(address_data)
			order_data.billing_address.update(address_data)

		shipping_price = 0.0
		subtotal = 0.0
		total = 0.0
		tax_amount = 0.0
		discount = 0.0
		for item in order_items:
			product_data = OrderProducts()
			product_data.asin = item.ASIN
			product_data.product_id = item.SellerSKU
			product_data.product_sku = item.SellerSKU
			product_data.product_name = item.Title
			# product_data.condition = item.ConditionId if item.ConditionId else 'New'
			product_data.qty = to_int(item.QuantityOrdered)
			if item.ItemPrice:
				qty = to_int(item.QuantityOrdered)
				product_data.price = to_decimal(to_decimal(item.ItemPrice.Amount, 2) / qty, 2)
				product_data.subtotal = to_decimal(item.ItemPrice.Amount, 2)
				product_total = to_decimal(item.ItemPrice.Amount, 2)
				product_data.tax_amount = to_decimal(item.ItemTax.Amount, 2) if item.ItemTax else 0
				if item.ShippingTax:
					product_data.tax_amount += to_decimal(item.ShippingTax.Amount, 2)
				discount_fields = ['ShippingDiscount', 'ShippingDiscountTax', 'PromotionDiscount', 'PromotionDiscountTax', 'CODFeeDiscount']
				discount_amount = 0
				for field in discount_fields:
					if item.get(field):
						discount_amount += to_decimal(item[field]['Amount'], 2)
				product_data.discount_amount = discount_amount
				shipping_fields = ['ShippingPrice', 'CODFee']
				shipping_amount = 0
				for field in shipping_fields:
					if item.get(field):
						shipping_amount += to_decimal(item[field]['Amount'], 2)
				product_data.shipping_amount = to_decimal(shipping_amount, 2)
				product_total = to_decimal(product_data.subtotal + product_data.tax_amount + product_data.shipping_amount - product_data.discount_amount, 2)
				product_subtotal = to_decimal(product_total - product_data.tax_amount + product_data.discount_amount, 2)
				# product_total += to_decimal(shipping_amount, 2)
				product_data.total = product_total

				product_data.subtotal = product_subtotal
				subtotal += product_data.subtotal
				total += product_data.total
				tax_amount += product_data.tax_amount
				shipping_price += product_data.shipping_amount
				discount += product_data.discount_amount
			order_data.products.append(product_data)
		order_data.subtotal = to_decimal(subtotal, 2)
		order_data.total = to_decimal(total, 2)
		order_data.currency = order.OrderTotal.get('CurrencyCode', 'USD')
		order_data.shipping.amount = to_decimal(shipping_price, 2)
		order_data.tax.amount = to_decimal(tax_amount, 2)
		order_data.discount.amount = to_decimal(discount, 2)

		return Response().success(data = order_data)


	def set_imported_order(self, imported):
		super().set_imported_order(imported)
		self._state.pull.process.orders.next_token = self.next_token


	def get_listing_items_object(self):
		if self._listing_item_obj:
			return self._listing_item_obj
		self._listing_item_obj = AmazonListingItems(**self.get_amazon_environment())
		return self._listing_item_obj


	def get_listing_item(self, product_id, included_data = 'attributes'):
		return self.get_listing_items_object().get_listings_item(self.get_seller_id(), product_id, includedData = included_data)


	def order_sync_inventory(self, convert: Order, setting_order):
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			variant_id = None
			if row['product_id'] and row['parent_id']:
				variant_id = row['product_id']
				product_id = row['parent_id']
			else:
				product_id = row['product_id']
			row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				amazon_product_id = variant_id or product_id

				new_qty = 0 - to_int(row_qty) if prefix == '-' else to_int(row_qty)
				if not self._cache_inventory.get(amazon_product_id):
					self._cache_inventory[amazon_product_id] = new_qty
				else:
					self._cache_inventory[amazon_product_id] += new_qty

		return Response().success()


	def addition_order_import(self):
		if self._cache_inventory:
			feed_content = self.get_default_feed_content('Inventory')
			index = 1
			for product_id, qty in self._cache_inventory.items():
				amazon_product = self.get_listing_item(product_id, included_data = 'fulfillmentAvailability')
				if amazon_product.payload and amazon_product.payload.get('fulfillmentAvailability'):
					product_qty = to_int(amazon_product.payload['fulfillmentAvailability'][0]['quantity'])
				else:
					continue
				inventory_data = {
					'SKU': product_id,
					'Quantity': product_qty + qty,
				}
				message = {
					'MessageID': index,
					'OperationType': 'PartialUpdate',
					'Inventory': inventory_data,
				}
				feed_content['AmazonEnvelope']['Message'].append(message)
				index += 1
			xml = self.parse_dict_to_xml(feed_content)
			feed = self.get_feed_object()
			response = feed.submit_feed(feed_type = 'POST_INVENTORY_AVAILABILITY_DATA', file = xml, content_type = 'text/xml')
			if response.result != Response.SUCCESS:
				return False
			response_submit = self.check_submit_feed_response(response)
			inventory_submission_id = response_submit.data
			self.check_submit_feed_result(inventory_submission_id, 'Inventory')

		return Response().success()


	def is_import_as_simple_product(self):
		return self._state.channel.config.api.import_as_simple_product


	def is_allow_crawl_description(self):
		return self._state.channel.config.api.allow_crawl_description and self._state.channel.config.api.crawl_description_object


	def pull_limit(self):
		return to_int(self._state.channel.config.api.pull_limit)


	def get_custom_headers_crawl(self):
		return {
			'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
			'sec-ch-ua-platform': 'Linux',
		}


	def crawl_amazon_data(self, soup, crawl_obj):
		if not crawl_obj:
			return ''
		try:
			description_soup = None
			for row in crawl_obj:
				description_soup = soup.find(row['tag'], {row['key']: row['value']})
			return description_soup.decode_contents()
		except Exception:
			self.log_traceback('crawl')
			return ''


	def get_kwargs_crawl(self, asin):
		kwargs = {
			'headers': {
				'user-agent': get_random_useragent(),
				'sec-ch-ua-platform': 'Linux',
				'referer': f'https://google.com/search?q=asin+{asin}',

			},
			"verify": False,
		}
		if self._state.channel.config.api.proxy:
			kwargs['proxies'] = {
				'http': self._state.channel.config.api.proxy,
				'https': self._state.channel.config.api.proxy,
			}
		return kwargs


	def crawl_description(self, asin, retry = 0):
		soup = self.get_soup(asin)
		if not soup:
			return ''
		crawl_objects = self._state.channel.config.api.crawl_description_object
		if crawl_objects and not isinstance(crawl_objects, list):
			crawl_objects = [crawl_objects]
		description = ''
		for obj in crawl_objects:
			row = self.crawl_amazon_data(soup, obj)
			if row:
				if description:
					description += "<br>"
				description += row

		return self.strip_html_from_description(description)


	def get_all_variants(self, parent_asin, retry = 0):
		soup = self.get_soup(parent_asin)
		if not soup:
			return {}
		try:
			variants = list(soup.find("div", {"id": "tmmSwatches"}).find('ul').find_all('li'))
			all_var = dict()
			for variant in variants:
				ahref = variant.find('a')
				link = ahref.attrs.get('href').strip('/')
				name = ahref.find('span').text.strip()
				try:
					asin = link.split('/')[2]
				except:
					asin = parent_asin
				if not all_var.get(asin):
					all_var[asin] = name
		except Exception:
			all_var = dict()
		return all_var


	def get_soup(self, asin, retry = 0):
		if self._soup.get(asin):
			return self._soup[asin]
		try:
			kwargs = self.get_kwargs_crawl(asin)

			text = requests.get(f"{self.get_amazon_domain()}/gp/product/{asin}", **kwargs)
			soup = BeautifulSoup(text.text, 'lxml')
			title = soup.find("span", {"id": "productTitle"}).text

			self._soup[asin] = soup
			return soup
		except Exception:
			self.log_traceback()
			if retry <= 5:
				retry += 1
				time.sleep(retry * 2)
				self._soup[asin] = None
				return self.get_soup(asin, retry)
		return False


	def get_amazon_category_path(self, asin):
		try:
			soup = self.get_soup(asin)
			breadcrumbs = soup.find("div", {"id": "wayfinding-breadcrumbs_feature_div"}).find_all('li')
			category_path = list(filter(lambda x: len(x) > 1, [row.text.strip() for row in breadcrumbs]))
			return ' > '.join(category_path)
		except Exception as e:
			return ''

	def replace_description(self, text):
		if self.get_channel_default().get('type') and self.get_channel_default().get('type') in ['wix']:
			description = self.html_to_text(text)
		else:
			description = self.strip_html_from_description(text)
		description = description.replace('\n', '</br>').replace('’', "'").replace("”", '"').replace('“', '"').replace('–', '-').replace('\u00a0', '')
		return self.title_cutting(description, 2000)

	def html_to_text(self, markup, preserve_new_lines = True, strip_tags = ['style', 'script', 'code']):
		soup = BeautifulSoup(unescape(markup), "html.parser")
		for element in soup(strip_tags): element.extract()
		if preserve_new_lines:
			for element in soup.find_all():
				if element.name not in ['a', 'b', 'button', 'i', 'input', 'label', 'select', 'strong', 'textarea' 'div']:
					element.append('\n\n') if element.name == 'br' else element.append('\n')
		return replace_duplicate_character(soup.get_text(), '\n')
	def get_draft_extend_channel_data(self, product):
		description = product.description or product.short_description or product.name
		description = self.replace_description(description)
		extend = {}
		if product.description != description:
			extend['description'] = description
		asin = product.asin
		if not asin:
			for attribute in product.attributes:
				if attribute.attribute_name.lower() == 'asin':
					asin = attribute.attribute_value_name
					break
		if asin:
			extend['asin'] = asin
			extend['asin_data'] = {
					'name': product.name,
					'thumbnail': product.thumb_image.url,
					'asin': asin,
					'url': f'{self.get_amazon_domain()}/gp/product/{asin}',
				}
		if not product.sku:
			product_sku = random_string(16, True)
			extend['sku'] = product_sku

		if product.sku and self._state.channel.config.api.sku_to_gtin:
			extend['gtin'] = product.sku
		if product.upc and self._state.channel.config.api.upc_to_gtin:
			extend['gtin'] = product.upc
		# gtin = product.gtin or product.upc or product.ean or product.isbn
		# if gtin and gtin != product.gtin and not self._state.channel.config.api.skip_gtin:
		# 	extend['gtin'] = gtin
		return extend


	def mapping_size_value(self, size, size_name):
		if to_decimal(size):
			size_split = to_str(size).split('.')
			if to_len(size_split) == 1:
				return f'numeric_{size}'
			if to_len(size_split) == 2 and to_int(size_split[-1]) == 5:
				return f'numeric_{size_split[0]}_point_5'
		if to_len(to_str(size).split('/')) > 1:
			check_size = to_str(size).split('/')[-1].strip()
			if to_decimal(check_size.split(' ')[-1]):
				new_size = check_size.split(' ')[-1]
				size_split = to_str(new_size).split('.')
				if to_len(size_split) == 1:
					return f'numeric_{new_size}'
				if to_len(size_split) == 2 and to_int(size_split[-1]) == 5:
					return f'numeric_{size_split[0]}_point_5'
		values = MAPPING_SIZE_VALUE['default']
		size_values = MAPPING_SIZE_VALUE.get(size_name)
		if size_values:
			values.update(size_values)
		attribute_value = values.get(to_str(size).lower())
		if attribute_value:
			return attribute_value
		attribute_value = values.get(to_str(size).replace('/','').lower())
		if attribute_value:
			return attribute_value
		new_value = to_str(size).lower().split('(')
		if to_len(new_value) > 1:
			size_value = new_value[0].strip()
			if values.get(size_value):
				return values.get(size_value)
			spefifics = clothing_specifics(self.get_marketplace_id_api())
			for spefific in spefifics:
				if spefific['name'] == size_name and spefific.get('choices'):
					if size_value in spefific['choices']:
						return size_value
		return to_str(size).lower()



	def is_log(self):
		return self._state.channel.config.api.is_log or self.is_amazon_gtin_exemption()
