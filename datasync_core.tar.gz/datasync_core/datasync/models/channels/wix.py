import copy
import io
from itertools import product
from urllib.request import Request, urlopen
import webcolors
import chardet
import requests
from PIL import Image
from PIL import ImageFile
import dateutil.relativedelta
from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderCustomer, OrderAddress
from datasync.models.constructs.product import Product, ProductVariant, \
	ProductVariantAttribute, ProductImage, ProductOption, ProductOptionValue, ProductAttribute, ProductVideo


class ModelChannelsWix(ModelChannel):
	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	CUSTOM_COLLECTION = 'custom'
	SMART_COLLECTION = 'smart'
	ORDER_STATUS = {
		"pending": Order.OPEN,
		"partially_refunded": Order.OPEN,
		"authorized": Order.AWAITING_PAYMENT,
		"partially_paid": Order.SHIPPING,
		"paid": Order.COMPLETED,
		"voided": Order.CANCELED,
		"refunded": Order.REFUNDED,
	}
	FINANCIAL_ORDER_STATUS = {
		Order.OPEN: "pending",
		Order.AWAITING_PAYMENT: "authorized",
		Order.READY_TO_SHIP: "paid",
		Order.SHIPPING: "paid",
		Order.COMPLETED: "paid",
		Order.CANCELED: "refunded",
		Order.REFUNDED: "refunded",
	}
	FULFILLMENT_STATUS = {
		Order.SHIPPING: "partially_paid",
		Order.COMPLETED: "fulfilled",
		Order.CANCELED: "restocked",
	}


	def __init__(self):
		super().__init__()
		self._api_url = "https://www.wixapis.com"
		self._api_url_refresh_token = "https://www.wixapis.com/oauth/access"
		self._total_time_sleep = 0
		self._version_api = 1
		self._last_status = None
		self._collection_type = None
		self._shopify_countries = None
		self._location_id = None
		self._collections = dict()
		self._last_product_response = None
		self.USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36"
		self.COUNTRIES = '{"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon", "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar", "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China", "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen", "DZ": "Algeria", "US": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India", "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}'
		self._product_variants = list()
		self._inventory_item_id = ''
		self._discount_amount = 0
		self._all_categories = dict()
		self._page_number = 0
		self._flag_finish_product = False
		self._first_time_refresh = False
		self._pull_inventory = False
		self._inventory_max_last_modified = False
		self._pull_products_id: list[str] = list()
		self._pull_collections_id: list[str] = list()


	def get_api_info(self):
		return {
			# 'app_id': "App ID",
			# 'app_secret': 'App Secrect Key',
			'access_token': 'Oauth access',
			'refresh_token': 'Refresh Token',
			# 'instance_id': 'Instance Id',
		}


	def set_last_product_response(self, response):
		self._last_product_response = response


	def get_last_product_response(self):
		return self._last_product_response


	# api code

	def refresh_access_token(self):
		data = {
			"grant_type": "refresh_token",
			"client_id": self.get_app_id(),
			"client_secret": self.get_app_secret(),
			"refresh_token": self._state.channel.config.api.get('refresh_token')
		}
		refresh = requests.request('post', self._api_url_refresh_token, json = data)
		if refresh.status_code != 200:
			return False
		token = refresh.json()
		self._state.channel.config.api.access_token = token['access_token']
		self._state.channel.config.api.refresh_token = token['refresh_token']
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return token['access_token']


	def get_app_id(self):
		if self._state.channel.config.api.get('app_id'):
			return self._state.channel.config.api.get('app_id')
		return get_config_ini('wix', 'app_id')


	def get_instance_id(self):
		return self._state.channel.config.api.get('instance_id')


	def get_app_secret(self):
		if self._state.channel.config.api.get('app_secret'):
			return self._state.channel.config.api.get('app_secret')
		return get_config_ini('wix', 'app_secret')


	def stores_api(self, path, data = None, api_type = "get", version_api = None):
		if not version_api:
			version_api = self._version_api
		path = f'stores/v{version_api}/{path.strip("/")}'
		return self.api(path, data, api_type)


	def requests(self, url, data = None, headers = None, method = 'get', retry = 0):
		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if data:
			if method == 'get':
				request_options['params'] = data
			if method in ['post', 'put', 'patch']:
				request_options['json'] = data
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			need_retry = False

			try:
				response = requests.request(method, url, **request_options)
			except:
				self.log_traceback()
				need_retry = True
			self._last_header = response.headers
			self._last_status = response.status_code
			if response.status_code in [401, 403, 428]:
				token = self.refresh_access_token()
				if not token:
					self.set_action_stop(True)
					return response
				headers['Authorization'] = token
				return self.requests(url, data, headers, method)
			if response.status_code in [429] or response.status_code >= 500:
				need_retry = True
			retry = 0
			while need_retry and retry <= 5:
				retry += 1
				time.sleep(retry * 1)
				return self.requests(url, data, headers, method, retry)

			response_data = response.text
			if response.status_code > 204 or self.is_log():
				self.log_request_error(url, method = method, data = data, response = response.text, status = response.status_code)
		except Exception as e:
			self.log_traceback()
		return response_data


	def api(self, path, data = None, api_type = "get"):

		header = {"Content-Type": "application/json"}
		url = self.get_api_url() + '/' + to_str(path).strip('/')
		method = to_str(api_type).lower()
		access_token = self._state.channel.config.api.access_token
		header['Authorization'] = access_token
		res = self.requests(url, data, header, method)
		res_json = json_decode(res)
		if res_json:
			res_json = Prodict.from_dict(res_json)
		return res_json


	def get_api_url(self):
		if not self._api_url:
			self._api_url = self.create_api_url()
		return self._api_url


	def create_api_url(self):
		api_url = "https://www.wixapis.com"
		return api_url


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# order = self.get_product_by_id('5a7b98b2-03d0-b0a7-340d-398a5e5993d6')
		# order_ext = self.get_products_ext_export([order['data']])
		# convert = self._convert_product_export(order['data'], order_ext['data'])
		# url = self._channel_url
		self._state.channel.config.api.shop = self.channel_url_to_identifier()
		data = {
			"query": {
				"paging": {
					"limit": 1
				}
			}
		}
		api_store_category = self.api('site-properties/v4/properties', data, 'get')
		if self._last_status != 200:
			return Response().error(code = Errors.WIX_API_INVALID)
		if 'message' in api_store_category:
			return Response().error(code = Errors.WIX_API_INVALID)
		return response_success()


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		self.set_identifier(self.get_instance_id())
		return Response().success()


	def after_create_channel(self, data):
		return Response().success()

	def before_display_pull(self, data = None):
		if not self.is_order_process() or not self._state.channel.config.api.reset_completed_order:
			return Response().success()
		try:
			status_check = self._state.channel.config.api.reset_completed_order
			where = self.get_model_order().create_where_condition('status', 'completed')
			where.update(self.get_model_order().create_where_condition(f'channel.channel_{self.get_channel_default_id()}.order_status', status_check))
			count_shipping = self.get_model_order().count(where)
			if count_shipping:
				self.get_model_order().update_many(where, {'status': 'shipping'})
				where_shipping = self.get_model_order().create_where_condition('status', 'shipping')
				orders = self.get_model_order().find_all(where_shipping, select_fields = ['created_at'], order_by = '-created_at', limit = 1)
				if orders:
					max_last_modified = orders[0]['created_at']
					max_last_modified_obj = datetime.strptime(max_last_modified, "%Y-%m-%d %H:%M:%S") - dateutil.relativedelta.relativedelta(hours = 7)
					check = True
					if self._state.pull.process.orders.max_last_modified:
						old_obj = isoformat_to_datetime(self._state.pull.process.orders.max_last_modified)
						if old_obj.timestamp() <= max_last_modified_obj.timestamp():
							check = False
					else:
						check = False
					if check:
						self._state.pull.process.orders.max_last_modified = max_last_modified_obj.strftime("%Y-%m-%dT%H:%M:%S.000Z")
		except:
			self.log_traceback()
		return Response().success()


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		if parent.result != Response().SUCCESS:
			return parent

		if self._flag_finish_product:
			return Response().finish()
		# custom_collection_api = self.api('custom_collections/count.json', data = {'since_id': self._state.pull.process.categories.id_src})
		# smart_collection_api = self.api('smart_collections/count.json', data = {'since_id': self._state.pull.process.categories.id_src})
		# orders_api = self.api('orders/count.json', data = {'since_id': self._state.pull.process.orders.id_src})
		# products_api = self.api('products/count.json', data = {'since_id': 0})
		# custom_collection_api = self.api('custom_collections/count.json', data = {'since_id': 0})
		# smart_collection_api = self.api('smart_collections/count.json', data = {'since_id': 0})
		if self.is_product_process():
			if self._request_data.get('collection_id'):
				self._pull_collections_id = list(
					set(
						[
							x.replace('\"', '').replace("'", '').strip()
							for x in to_str(self._request_data['collection_id']).split(',')[:100]
						]
					)
				)

			if self._request_data.get('product_id'):
				self._pull_products_id = list(
					set(
						[
							x.replace('\"', '').replace("'", '').strip()
							for x in to_str(self._request_data['product_id']).split(',')[:100]
						]
					)
				)
				products_api = len(self._pull_products_id)
				self._flag_finish_product = True

			else:
				products_api = self.get_total_count_products()
			self._state.pull.process.products.total_view = products_api
			self._state.pull.process.products.total = products_api
			if self.is_refresh_process():
				self._state.pull.process.products.total = -1 if products_api else 0

			self._state.pull.process.products.error = 0
			self._state.pull.process.products.imported = 0
			self._state.pull.process.products.new_entity = 0
		if self.is_order_process():
			orders_api = self.get_total_count_orders()
			self._state.pull.process.orders.total = orders_api
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
		# category_count = 0
		# if custom_collection_api and custom_collection_api.count:
		# 	category_count = custom_collection_api.count
		# if smart_collection_api and smart_collection_api.count:
		# 	category_count += smart_collection_api.count
		# self._state.pull.process.categories.total = orders_api.count
		return Response().success()


	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		try:
			all_collections = self.api('custom_collections.json?limit=100')
			while all_collections:
				if not all_collections.custom_collections:
					break
				for collect in all_collections.custom_collections:
					id_collect = collect.id
					res = self.api('custom_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('custom_collections.json?limit=100')
				time.sleep(0.1)
			all_collections = self.api('smart_collections.json?limit=100')

			while all_collections:
				if not all_collections:
					return next_clear
				if not all_collections.smart_collections:
					return next_clear
				for collect in all_collections.smart_collections:
					id_collect = collect.id
					res = self.api('smart_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('smart_collections.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			all_products = self.api('products.json?limit=100')
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.products:
					return next_clear
				for product in all_products.products:
					id_product = product.id
					res = self.api('products/{}.json'.format(id_product), None, 'Delete')
				all_products = self.api('products.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_collection_type(self):
		if self._collection_type:
			return self._collection_type
		self._collection_type = self.CUSTOM_COLLECTION
		return self._collection_type


	def set_collection_type(self, collection_type):
		self._collection_type = collection_type


	def get_categories_main_export(self):
		collection_type = self.get_collection_type()
		limit_data = self._state.pull.setting.categories
		categories_data = list()
		if collection_type == self.CUSTOM_COLLECTION:
			id_src = self._state.pull.process.categories.id_src
			collections = self.api('custom_collections.json', data = {'since_id': id_src, 'limit': limit_data})
			if not collections:
				return Response().error()
			# if 'custom_collections' in categories_page and not categories_page['custom_collections']:
			# 	return create_response('pass')
			categories_data = collections.get('custom_collections')
			if not categories_data:
				collection_type = self.CUSTOM_COLLECTION
		if collection_type == self.SMART_COLLECTION:
			id_src = self._state.pull.process.categories.id_src_smart
			if not id_src:
				id_src = 0
			collections = self.api('smart_collections.json', data = {'since_id': id_src, 'limit': limit_data})
			if not collections:
				return Response().error()

			if not collections.get('smart_collections'):
				return Response().skip()
			categories_data = collections['smart_collections']
		return Response().success(categories_data)


	def get_categories_ext_export(self, categories):
		extend = dict()
		for category in categories:
			category_id = to_str(category.id)
			extend[category_id] = dict()
			meta = False
			if 'rules' in category:
				meta = self.api('smart_collections/{}/metafields.json'.format(category_id))
			else:
				meta = self.api('custom_collections/{}/metafields.json'.format(category_id))
			if meta:
				extend[category_id]['meta'] = meta.get('metafields')
		return Response().success(extend)


	def convert_category_export(self, category, categories_ext):
		category_data = CatalogCategory()
		category_id = to_str(category['id'])
		parent = CatalogCategory()
		category_data.parent = parent
		category_data.id = category.id
		category_data.active = True if category.published_at else False
		if category.image and category.image.src:
			real_path = re.sub("/\?.+/", "", category.image.src)
			real_path = real_path[:real_path.find('?')]
			category_data['thumb_image']['url'] = real_path
			category_data['thumb_image']['path'] = ''
		category_data.name = category.title
		category_data.description = category.body_html
		category_data['created_at'] = convert_format_time(category.published_at, self.FORMAT_DATETIME)
		category_data['updated_at'] = convert_format_time(category.updated_at, self.FORMAT_DATETIME)
		category_data.seo_url = "https://{}.myshopify.com/collections/{}".format(self._state.channel.config.api.shop,
		                                                                         category.handle)
		if 'meta' in categories_ext[category_id] and categories_ext[category_id]['meta']:
			for metafields in categories_ext[category_id]['meta']:
				if metafields['key'] == 'description_tag':
					category_data.meta_description = metafields['value']
				elif metafields['key'] == 'title_tag':
					category_data.meta_title = metafields['value']
		return Response().success(category_data)


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['id']


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		if not category.name:
			return response_error('import category ' + to_str(category.id) + ' false.')
		post_data = {
			'smart_collection': {
				'title': category.name,
				'body_html': category.description,
				'published_scope': 'web',
				'disjunctive': 'false',
				'sort_order': 'best-selling',
				'rules': []
			}
		}

		# Add Thumbnail image
		if category.thumb_image.url:
			main_image = self.process_image_before_import(category.thumb_image.url, category.thumb_image.path)
			image_data = self.resize_image(main_image['url'])
			if image_data:
				post_data['smart_collection']['image'] = image_data

		# Status
		if not category.active:
			post_data['smart_collection']['published_at'] = None

		# Add rules: the list of rules that define what products go into the smart collections.
		tag_rule = {
			'column': 'tag',
			'relation': 'equals',
			'condition': category.name
		}
		post_data['smart_collection']['rules'].append(tag_rule)

		# Post data
		response = self.api('smart_collections.json', post_data, 'Post')
		check_response = self.check_response_import(response, category, 'category')
		if check_response.result != Response.SUCCESS:
			if 'Image' in check_response.msg:
				del post_data['smart_collection']['image']
				response = self.api('smart_collections.json', post_data, 'Post')
				check_response = self.check_response_import(response, category, 'category')
				if check_response.result != Response.SUCCESS:
					return check_response
			else:
				return check_response

		category_id = response['smart_collection']['id']
		handle = response['smart_collection'].get('handle')
		return Response().success(category_id)


	def get_product_by_id(self, product_id):
		product = self.stores_api(f'products/{product_id}')
		if self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		if not product or not product.get('product'):
			return Response().error()
		return Response().success(product['product'])


	def get_product_updated_at(self, product):
		return product.lastUpdated


	def updated_at_to_timestamp(self, updated_at, time_format = '%Y-%m-%d %H:%M:%S'):
		return to_timestamp(updated_at[0:19], '%Y-%m-%dT%H:%M:%S')


	def get_max_last_modified_product(self):
		if self._state.pull.process.products.last_modified:
			if to_str(self._state.pull.process.products.last_modified).isnumeric():
				return convert_format_time(self._state.pull.process.products.last_modified, new_format = "%Y-%m-%dT%H:%M:%S.000Z")
			last_modified = to_str(self._state.pull.process.products.last_modified).replace('.Z', '.000Z')
			if last_modified and last_modified.find('.') == -1:
				last_modified = last_modified.replace('Z', '.000Z')
			return last_modified
		return False


	def get_max_last_modified_inventory(self):
		last_modified = to_str(self._state.pull.process.products.last_modified).replace('.Z', '.000Z') or False
		if last_modified and last_modified.find('.') == -1:
			last_modified = last_modified.replace('Z', '.000Z')
		return last_modified


	def get_product_by_inventory(self):
		self._pull_inventory = True
		last_modified = self.get_max_last_modified_inventory()
		inventories = []
		page_number = 0
		limit = 100
		while True:
			offset = page_number * limit
			data = {
				"query": {
					"paging": {
						"limit": limit,
						"offset": offset
					},
					"sort": json_encode([
						{'lastUpdated': 'asc'}
					])
				},
			}
			if last_modified:
				data['query']['filter'] = json_encode({
					'lastUpdated': {
						'$gt': last_modified
					}
				})
			products = self.stores_api('inventoryItems/query', data, 'Post', version_api = 2)
			if not products or not products['inventoryItems']:
				break
			inventories.extend(products['inventoryItems'])
			page_number += 1
		if inventories:
			inventories.sort(key = lambda x: x['lastUpdated'])
			self._inventory_max_last_modified = inventories[-1]['lastUpdated']
		self._flag_finish_product = True
		return Response().success(data = inventories)


	def finish_product_export(self):
		super(ModelChannelsWix, self).finish_product_export()
		if self.is_refresh_process():
			if self._inventory_max_last_modified:
				self._state.pull.process.products.last_modified_inventory = self._inventory_max_last_modified
			elif self._first_time_refresh and self._product_max_last_modified:
				self._state.pull.process.products.last_modified_inventory = self._product_max_last_modified



	def get_product_by_updated_at(self):
		if self._flag_finish_product:
			return Response().finish()
		if self._pull_inventory:
			return self.get_product_by_inventory()

		last_modified = self.get_max_last_modified_product()
		page_number = self._page_number
		limit = 100
		offset = page_number * limit
		data = {
			"query": {
				"paging": {
					"limit": limit,
					"offset": offset
				},
				"sort": json_encode([
					{'lastUpdated': 'asc'}
				])
			},
			"includeVariants": True,
			"includeHiddenProducts": True,
		}
		if last_modified:
			data['query']['filter'] = json_encode({
				'lastUpdated': {
					'$gt': last_modified
				}
			})
		products = self.stores_api('products/query', data, 'Post')
		if not products or not products['products']:
			if self._last_status != 200:
				return Response().error(Errors.WIX_GET_PRODUCT_FAIL)
			if not self._first_time_refresh:
				return self.get_product_by_inventory()
			return Response().finish()
		self._page_number += 1
		return Response().success(data = products['products'])

	def get_products_main_export(self):
		page_number = self._page_number
		limit = 100
		offset = page_number * limit
		data = {
			"query": {
				"paging": {
					"limit": limit,
					"offset": offset
				},
			},
			"includeVariants": True,
			"includeHiddenProducts": True,
		}

		if self._pull_collections_id:
			data['query']['filter'] = json_encode({
				'collections.id': {
					'$hasSome': self._pull_collections_id
				}
			})
		# currently, users can choose to pull by collection or product only
		elif self._pull_products_id:
			data['query']['filter'] = json_encode({
				'id': {
					'$hasSome': self._pull_products_id
				}
			})

		products = self.stores_api('products/query', data, 'Post')
		if not products or not products['products']:
			if self._last_status != 200:
				return Response().error(Errors.WIX_GET_PRODUCT_FAIL)
			return Response().finish()
		self._page_number += 1
		return Response().success(data = products['products'])


	def get_products_ext_export(self, products):
		return Response().success()


	def get_product_id_import(self, convert: Product, product, products_ext):
		if not self._pull_inventory:
			return product.id
		return product.productId


	def convert_inventory_export(self, inventory, inventory_ext):
		inventory_data = Product()
		inventory_data.allow_update = ['qty', 'manage_stock', 'is_in_stock']
		inventory_data.id = inventory.productId
		inventory_data.manage_stock = inventory.trackQuantity
		variant_default = inventory.variants[0]
		if variant_default.variantId == self.variant_default_id():
			inventory_data.qty = variant_default.quantity or 0
			inventory_data.is_in_stock = variant_default.inStock
		else:
			qty = 0
			for variant in inventory.variants:
				variant_data = ProductVariant()
				variant_data.manage_stock = inventory.trackQuantity
				variant_data.id = variant.variantId
				variant_data.qty = variant.quantity or 0
				variant_data.allow_update = inventory_data.allow_update
				qty += variant_data.qty
				variant_data.is_in_stock = variant.inStock
				inventory_data.variants.append(variant_data)
			inventory_data.qty = qty
		inventory_data.is_update_inventory = True
		return Response().success(inventory_data)

	
	def get_weight_units(self, default = 'lb'):
		other_setting = self._state.channel.config.setting.get('other_setting', {})
		if not other_setting:
			other_setting = {}
		return self._state.channel.config.api.weight_units or other_setting.get('weight_units') or default
	
	
	def _convert_product_export(self, product, products_ext: Prodict):
		if self._pull_inventory:
			return self.convert_inventory_export(product, products_ext)

		product_id = to_str(product.id)
		product_data = Product()
		product_data.id = product_id
		if product.productPageUrl:
			product_data.seo_url = f"{product.productPageUrl.base.strip('/')}/{product.productPageUrl.path.strip('/')}"
		else:
			product_data.seo_url = f"{self.get_channel_url()}/product-page/{to_str(product.slug).strip('/')}"
		product_data.name = product.name
		product_data.sku = to_str(product.sku).strip()
		product_data.price = to_decimal(product.priceData.price)
		product_data.special_price.price = to_decimal(product.priceData.discountedPrice) if to_decimal(product.priceData.discountedPrice) < to_decimal(product.priceData.price) else 0
		product_data.type = 'simple'
		product_data.url_key = product.slug
		product_data.description = product.description
		if product.seoData:
			for tag in product.seoData.tags:
				if tag.type == 'meta':
					product_data.meta_description = tag.props.content
				if tag.type == 'title':
					product_data.meta_title = tag.children
		product_data.weight = to_decimal(product.weight)
		product_data.weight_units = self.get_weight_units()
		##
		if product.collectionIds:
			for collection in product.collectionIds:
				category = self.get_category_by_id(collection)
				if category:
					product_data.category_name_list.append(category)
		product_data.status = True if product.visible is True else False
		product_data.invisible = not product_data.status
		if product.stock.trackInventory:
			product_data.manage_stock = True
			product_data.qty = product.stock.quantity
			product_data.is_in_stock = to_int(product.stock.quantity) > 0
		else:
			product_data.manage_stock = False
			product_data.is_in_stock = product.stock.inStock
		product_data.brand = product.brand
		product_data.created_at = convert_format_time(product.lastUpdated, "%Y-%m-%dT%H:%M:%S")
		product_data.updated_at = convert_format_time(product.lastUpdated, "%Y-%m-%dT%H:%M:%S")

		# Image
		image_ids = list()
		if product.media:
			if product.media.mainMedia:
				product_data.thumb_image.url = self.get_image_link(product.media.mainMedia.id)
				image_ids.append(product.media.mainMedia.id)
			if product.media.get('items'):
				for media in product['media']['items']:
					if not media or not media.get('id') or media['id'] in image_ids:
						continue
					image_ids.append(media['id'])
					if not product_data.thumb_image.url:
						product_data.thumb_image.url = self.get_image_link(media['id'])
						continue
					if media['mediaType'] == 'video':
						for idx, video_file in enumerate(media["video"]["files"]):
							try:
								video_data = ProductVideo()
								video_data.url = to_str(video_file["url"]) if video_file.get('url') else ''
								video_data.format = (to_str(video_file["format"]) if video_file.get('format')
													else video_data.url.split('.')[-1])
								video_data.title = (to_str(media["altText"]) if video_file.get('altText')
													else f'{media.get("title", "")}_{idx}')

								product_data.videos.append(video_data)
							except:
								self.log_traceback(msg = "Can't get video")
						continue
					image_data = ProductImage()
					image_data.url = self.get_image_link(media['id'])
					product_data.images.append(image_data)
		has_variant = False
		for variant in product.variants:
			if variant['id'] != self.variant_default_id():
				has_variant = True
				break
		if has_variant:
			inventory_data = self.api('stores/v2/inventoryItems/{}/getVariants'.format(product['inventoryItemId']), {'paging': {}}, 'post')
			product_data['type'] = 'configurable'
			for variant in product.variants:
				product_child = self.copy_data_from_parent_product(product_data)
				product_child.id = variant.id
				variant_price = variant['variant']['priceData']['price'] or product_data.price
				if not variant['variant']['priceData']['price']:
					self.log(inventory_data, 'variant_price_0')
				product_child.price = variant_price
				product_child.special_price.price = to_decimal(variant['variant']['priceData'].get('discountedPrice')) if to_decimal(variant['variant']['priceData'].get('discountedPrice')) < to_decimal(variant_price) else 0
				product_child.sku = to_str(variant['variant']['sku']).strip()
				product_child.weight = variant['variant']['weight']
				product_child.status = variant['variant']['visible']
				product_child.invisible = not variant['variant']['visible']
				inventory = get_row_from_list_by_field(inventory_data['inventoryItem']['variants'], 'variantId', variant['id'])
				product_child.qty = inventory.quantity
				product_child.is_in_stock = inventory.inStock
				for key, value in variant['choices'].items():
					attribute_data = ProductVariantAttribute()
					attribute_data.attribute_code = key.replace(' ', '_').lower()
					attribute_data.attribute_name = key
					attribute_data.attribute_value_name = self.get_color_name(value)
					product_child.attributes.append(attribute_data)
				product_child['type'] = 'simple'
				product_child.seo_url = f"{product_data.seo_url}?variantId={variant.id}"

				product_data.variants.append(product_child)
		product_data.no_manage_variants = False if product.manageVariants else False
		if product.productOptions and not product.manageVariants:
			variant_number = 1
			for modifier in product.productOptions:
				option_data = ProductOption()
				option_data.option_name = modifier.name
				for modifier_value in modifier.choices:
					option_value_data = ProductOptionValue()
					option_value_data.option_value_name = modifier_value['value']
					option_data.option_values.append(option_value_data)
				variant_number *= to_len(option_data.option_values)
				product_data.options.append(option_data)
			if variant_number > 5000:
				return Response().skip()
			variants = self.convert_option_to_child(product_data.options, product_data)
			product_data.variants = variants
			product_data.no_manage_variants = True
		# if not product_data.sku and product_data.variants and product_data.variants[0].sku:
		# 	product_data.sku = product_data.variants[0].sku
		special_fields = ['ean', 'upc', 'gtin']
		if product.additionalInfoSections:
			for addition in product.additionalInfoSections:
				if to_str(addition.title).lower() in special_fields:
					product_data[to_str(addition.title).lower()] = self.strip_html_from_description(addition.description)
				else:
					attribute_data = ProductAttribute()
					attribute_data.attribute_name = addition.title
					attribute_data.attribute_value_name = self.strip_html_from_description(addition.description)
					product_data.attributes.append(attribute_data)
		return Response().success(product_data)


	def convert_option_to_child(self, options, parent):
		variants = list()
		options_src = dict()
		for option in options:
			values = list()
			key_option = option['option_name']
			if option['option_values']:
				for value in option['option_values']:
					values.append(value['option_value_name'])
					opt_val = {
						'option_name': option['option_name'],
						'option_value_name': value['option_value_name'],
					}
					if key_option not in options_src:
						options_src[key_option] = list()
					if opt_val['option_value_name']:
						options_src[key_option].append(opt_val)
		if not options_src:
			return variants
		combinations = self.combination_from_multi_dict(options_src)

		children_base_data = self.copy_data_from_parent_product(parent)

		for item, children in enumerate(combinations):
			children_data = copy.deepcopy(children_base_data)
			min_qty = to_int(parent['qty'])
			status = children_data['status']
			option_data = list()
			for index, attribute in enumerate(children):
				option_data.append({
					'option': attribute['option_name'],
					'selection': attribute['option_value_name'],
				})
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = attribute['option_name']
				attribute_data.attribute_value_name = self.get_color_name(attribute['option_value_name'])
				children_data['attributes'].append(attribute_data)
			children_data['option_data'] = option_data
			children_data['qty'] = min_qty
			children_data['status'] = status
			children_data['id'] = f"{parent.id}-{self.variant_key_generate(children_data)}"
			variants.append(children_data)
		return variants


	def get_color_name(self, color):
		colors = {
			'#B5651D': 'light brown',
			'#37E8F7': 'fluorescent blue'
		}
		if colors.get(to_str(color).upper()):
			return colors.get(to_str(color).upper())
		specs = ['css3','html4','css2', 'css21']
		for spec in specs:
			try:
				color_name = webcolors.hex_to_name(color, spec)
			except:
				color_name = False
			if color_name:
				return color_name
		return color


	def get_draft_extend_channel_data(self, product: Product):
		description = self.convert_description(product.description)
		name = product.name[0:80]
		sku = product.sku[0:40]
		draft_data = {}
		if description != product.description:
			draft_data['description'] = description
		if name != product.name:
			draft_data['name'] = name
		if self._state.channel.config.api.upc_to_sku and product.upc:
			sku = product.upc
		if sku != product.sku:
			draft_data['sku'] = sku
		if product.weight:
			unit = product.weight_units
			if unit == 'oz':
				draft_data['weight'] = to_decimal(product.weight * 0.0625, 4)
				draft_data['weight_units'] = 'lb'
			if unit in ['g', 'gr']:
				draft_data['weight'] = to_decimal(product.weight * 0.001, 4)
				draft_data['weight_units'] = 'kg'
		# if product.is_variant:
		# 	if self.is_special_price(product):
		# 		draft_data['price'] = product.special_price.price

		return draft_data


	def product_import(self, convert: Product, product: Product, products_ext):
		product = self.custom_product(product)
		if not product.name:
			return response_error(Errors.PRODUCT_DATA_INVALID)
		self._discount_amount = 0
		description = self.convert_description(product.description)[0:8000]
		product_name = product.name
		if to_len(product_name) > 80:
			product_name = self.title_cutting(product_name, 80)
			self._extend_product_map['name'] = product_name
		if self._state.channel.config.api.skip_description:
			description = ""
		if description != product.description:
			self._extend_product_map['description'] = description or self.FIELD_EMPTY
		sku = product.sku if product.sku else product.code
		if self._state.channel.config.api.channel_sku:
			channel_sku = product.channel.get(f'channel_{self._state.channel.config.api.channel_sku}', {}).get('product_id')
			if channel_sku:
				sku = channel_sku
		if self._state.channel.config.api.upc_to_sku and product.upc:
			sku = product.upc
		wix_sku = sku[0:40]
		if sku != wix_sku:
			self._extend_product_map['sku'] = wix_sku
		min_price_variant = copy.deepcopy(product)
		if product.variants:
			for variant in product.variants:
				if variant.price <= min_price_variant.price:
					min_price_variant = copy.deepcopy(variant)
		product_post_data = {
			"name": product_name,
			"productType": "physical",
			"priceData": {
				"price": to_decimal(min_price_variant.price)
			},
			"description": description,
			"sku": wix_sku,
			"visible": True if product.status else False,
			"stock": dict()
		}
		if to_str(product.brand):
			product_post_data['brand'] = to_str(product.brand)
		if product.weight and to_decimal(product.weight) != 0:
			product_post_data['weight'] = self.to_wix_weight(product.weight, product.weight_units)
		discount_amount = 0
		if self.is_special_price(min_price_variant):
			discount_amount = to_decimal(min_price_variant.price) - to_decimal(min_price_variant.special_price.price)
			product_post_data['discount'] = {
				"type": "AMOUNT",
				"value": discount_amount
			}
		if product.manage_stock:
			product_post_data['stock']['trackInventory'] = True
			product_post_data['stock']['inStock'] = to_int(product.qty) > 0
			product_post_data['stock']['quantity'] = to_int(product.qty) if to_int(product.qty) < 99999 else 99999
		else:
			product_post_data['stock']['trackInventory'] = False
			if product.get('is_in_stock') or to_int(product.qty) > 0:
				product_post_data['stock']['inStock'] = True
			else:
				product_post_data['stock']['inStock'] = False

		if product.variants:
			children_list = product.variants
			options = self.variants_to_option(children_list)
			product_post_data['productOptions'] = list()
			for attribute_name, attribute_values in options.items():
				product_option = dict()
				product_option['optionType'] = 'drop_down'
				product_option['name'] = attribute_name
				product_option['choices'] = list()
				for option_value in attribute_values:
					choice = dict()
					choice['value'] = option_value
					choice['description'] = option_value
					product_option['choices'].append(choice)
				product_post_data['productOptions'].append(product_option)
			product_post_data["manageVariants"] = True
		else:
			product_post_data["manageVariants"] = False
		product_response = self.stores_api('products', {"product": product_post_data}, 'Post')
		if self._last_status > 300 and product_response.get('message') and 'must not contain XSS tags' in product_response['message']:
			description = self.strip_html_from_description(description)
			description = nl2br(description)
			description = f'<p>{description}</p>'
			self._extend_product_map['description'] = description
			product_post_data['description'] = description
			product_response = self.stores_api('products', {"product": product_post_data}, 'Post')

		if product_response.get('product'):
			self._product_variants = product_response.product.variants
			self._inventory_item_id = product_response.product.inventoryItemId
			self._discount_amount = discount_amount
			self._extend_product_map['inventory_item_id'] = self._inventory_item_id
			return Response().success(product_response.product.id)
		else:
			return Response().error(msg = product_response.get('message'))


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		if self.is_auto_import_category():
			category_name_list = product.category_name_list or []
			if not category_name_list and product.category_path:
				category_name = product.category_path.split('>')[-1].strip()
				if category_name:
					category_name_list = [category_name]
			if category_name_list:
				for category_name in category_name_list:
					category_id = self.get_category_by_name(category_name)
					if category_id:
						self.stores_api(f"collections/{category_id}/productIds", {"productIds": [product_id]}, 'post')
		product_images = dict()
		product_media = list()
		if product.thumb_image.url or product.thumb_image.path:
			image_process = self.process_image_before_import(product.thumb_image.url, product.thumb_image.path)
			media = dict()
			media['url'] = image_process['url']
			product_media.append(media)
		variant_thumb_images = {}
		for variant in product.variants:
			use_variant_attribute = list(filter(lambda x: x['use_variant'], variant.attributes))
			if to_len(use_variant_attribute) == 1 and variant.thumb_image.url and variant.thumb_image.url != product.thumb_image.url:
				variant_attribute = use_variant_attribute[0]
				variant_thumb_images[variant.thumb_image.url] = variant_attribute
		if product.images:
			for image in product.images:
				media = dict()
				media['url'] = image.get('url')
				if variant_thumb_images.get(image.get('url')):
					attribute = variant_thumb_images.get(image.get('url'))
					media['choice'] = {
								'option': attribute['attribute_name'],
								'choice': attribute['attribute_value_name']
							}
					del variant_thumb_images[image.get('url')]
				product_media.append(media)
		for image_url, attribute in variant_thumb_images.items():
			media = dict()
			media['url'] = image_url
			media['choice'] = {
				'option': attribute['attribute_name'],
				'choice': attribute['attribute_value_name']
			}
			product_media.append(media)
		if product_media:
			post_images = self.stores_api(f'products/{product_id}/media', {'media': product_media}, 'post')
		manage_stock = False
		if not product.variants:
			manage_stock = product.manage_stock
		else:
			for variant in product.variants:
				if variant.manage_stock:
					manage_stock = True
		has_variant = False
		if self._product_variants:
			for variant in self._product_variants:
				if variant.id == self.variant_default_id():
					continue
				has_variant = True
				break
		if has_variant:
			wix_variants = dict()
			wix_variants_ids = dict()
			for variant in self._product_variants:
				if variant.id == self.variant_default_id():
					continue
				key_generate = list()
				variant_data = ProductVariant()
				for attribute_name, value in variant.choices.items():
					attribute = ProductVariantAttribute()
					attribute.attribute_name = attribute_name
					attribute.attribute_value_name = value
					variant_data.attributes.append(attribute)
				# 	key_generate.append({"id": attribute_name, 'value': value})
				# key_generate = sorted(key_generate, key = lambda d: d['id'])
				# base64_generate = list()
				# for row in key_generate:
				# 	base64_generate.append(f"{row['id']}:{row['value']}")
				str_generate = self.variant_key_generate(variant_data)
				wix_variants[str_generate] = variant.id
				wix_variants_ids[variant.id] = str_generate
			product_variants = dict()
			for variant in product.variants:
				product_variants[self.variant_key_generate(variant)] = variant
			variants = list()
			inventories = list()
			for variant_key, variant_id in wix_variants.items():
				variant = product_variants.get(variant_key)
				if variant:
					qty = to_int(variant.qty)
					inventories.append({
						'variantId': variant_id,
						'quantity': qty,
						"inStock": qty > 0
					})
					variant_sku = variant.sku
					if self._state.channel.config.api.upc_to_sku and variant.upc:
						variant_sku = variant.upc
					variant_price = variant.price
					if self.is_special_price(variant):
						variant_price = variant.special_price.price
					if self._discount_amount:
						variant_price += self._discount_amount
					variant_data = {
						'price': variant_price,
						'weight': self.to_wix_weight(variant.weight, variant.weight_units or product.weight_units),
						'sku': to_str(variant_sku)[0:40],
						'visible': True,
						'variantIds': [variant_id]
					}
				else:
					variant_data = {
						'visible': False,
						'variantIds': [variant_id]
					}
				variants.append(variant_data)
			variant_import = self.stores_api(f"products/{product_id}/variants", {'variants': variants}, 'patch')
			if self._last_status != 200:
				return Response().error(msg = variant_import.message)
			for variant in variant_import.variants:
				product_variant = product_variants.get(wix_variants_ids[variant.id])
				if product_variant:
					self.insert_map_product(product_variant, product_variant['_id'], variant.id)
			variant_media = []
			# TODO: update second options images
			# https://dev.wix.com/docs/rest/api-reference/wix-stores/catalog/add-product-media
			# try:
			# 	for variant in product.variants:
			# 		variant_media.append(
			# 			{
			# 				'url': variant['thumb_image']['url'],
			# 				'choice': {
			# 					'option': variant['attributes'][0]['attribute_name'],
			# 					'choice': variant['attributes'][0]['attribute_value_name']
			# 				}
			# 			}
			# 		)
			# except:
			# 	self.log_traceback()
			#
			# product_media.extend(variant_media)
			# if product_media:
			# 	post_images = self.stores_api(f'products/{product_id}/media', {'media': product_media}, 'post')

			inventory_data = {
				"inventoryItem": {
					"trackQuantity": manage_stock,
					"variants": inventories
				}
			}
		else:
			inventory_data = {
				"inventoryItem": {
					"trackQuantity": manage_stock,
					"variants": [
						{
							'variantId': self.variant_default_id(),
							'quantity': product.qty,
							"inStock": product.is_in_stock
						}
					]
				}
			}
		inventory_item_id = self._inventory_item_id
		inventory_import = self.stores_api(f"inventoryItems/{inventory_item_id}", inventory_data, 'patch', version_api = 2)
		self._product_variants = list()
		self._inventory_item_id = ''
		return Response().success()


	def get_inventory_item_id(self, product_id):
		inventory = self.stores_api(f'products/{product_id}')
		if self._last_status == 200:
			return inventory.product.inventoryItemId
		return False


	def delete_product_import(self, product_id):
		remove = self.stores_api(f'products/{product_id}', None, 'delete')
		return Response().success()


	def product_channel_update(self, product_id, product: Product, products_ext):
		product_name = product.name
		if to_len(product_name) > 80:
			product_name = self.title_cutting(product_name, 80)
			self._extend_product_map['name'] = product_name
		min_price_variant = copy.deepcopy(product)
		if product.variants:
			for variant in product.variants:
				if variant.price <= min_price_variant.price:
					min_price_variant = copy.deepcopy(variant)
		product_post_data = {
			"name": product_name,
			"priceData": {
				"price": to_decimal(min_price_variant.price)
			},
			"description": self.convert_description(product.description),
			"sku": product.sku if product.sku else product.code,
		}
		if to_str(product.brand):
			product_post_data['brand'] = to_str(product.brand)
		if product.weight and to_decimal(product.weight) != 0:
			product_post_data['weight'] = self.to_wix_weight(product.weight, product.weight_units)
		discount_amount = 0
		if self.is_special_price(min_price_variant):
			discount_amount = to_decimal(min_price_variant.price) - to_decimal(min_price_variant.special_price.price)
			product_post_data['discount'] = {
				"type": "AMOUNT",
				"value": discount_amount
			}
		else:
			product_post_data['discount'] = {
				"type": "AMOUNT",
				"value": 0
			}
		product_response = self.stores_api(f'products/{product_id}', {"product": product_post_data}, 'patch')
		if self._last_status > 300:
			return Response().error(msg = product_response.get('msg'))
		inventories = list()

		if product.variants:
			update_variant = list()
			for variant in product.variants:
				channel_data = variant.channel.get(f"channel_{self.get_channel_id()}")
				if not channel_data or not channel_data.product_id:
					continue
				variant_id = channel_data.product_id
				qty = to_int(variant.qty)
				variant_price = product.price
				if self.is_special_price(variant):
					variant_price = variant.special_price.price
				if discount_amount:
					variant_price += discount_amount
				inventories.append({
					'variantId': variant_id,
					'quantity': qty,
					"inStock": qty > 0
				})
				update_variant.append({
					'price': variant_price,
					'weight': self.to_wix_weight(variant.weight, variant.weight_units or product.weight_units),
					'sku': to_str(variant.sku),
					'visible': True,
					'variantIds': [variant_id]
				})
			variant_import = self.stores_api(f"products/{product_id}/variants", {'variants': update_variant}, 'patch')
			if self._last_status > 300:
				return Response().error(msg = variant_import.get('msg'))
			# return Response().success()
		if not product.variants:
			inventories.append({
				'variantId': self.variant_default_id(),
				'quantity': to_int(product.qty),
				"inStock": to_int(product.qty) > 0
			})
		inventory_item_id = self.get_inventory_item_id(product_id)
		if inventory_item_id:
			inventory_data = {
				"inventoryItem": {
					"trackQuantity": True,
					"variants": inventories
				}
			}
			inventory_import = self.stores_api(f"inventoryItems/{inventory_item_id}", inventory_data, 'patch', version_api = 2)
			if self._last_status > 300:
				return Response().error(msg = inventory_import.get('msg'))
		return Response().success()


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success()
		min_price_variant = copy.deepcopy(product)
		if product.variants:
			for variant in product.variants:
				if variant.price <= min_price_variant.price:
					min_price_variant = copy.deepcopy(variant)
		discount_amount = 0
		if setting_price:
			update_product = {
				"product": {
					"priceData": {
						"price": min_price_variant.price
					}
				}
			}
			if self.is_special_price(min_price_variant):
				discount_amount = to_decimal(min_price_variant.price) - to_decimal(min_price_variant.special_price.price)
				update_product['product']['discount'] = {
						"type": "AMOUNT",
						"value": discount_amount
					}
			else:
				update_product['product']['discount'] = {
					"type": "AMOUNT",
					"value": 0
				}
			variant_import = self.stores_api(f"products/{product_id}", update_product, 'patch')
			if self._last_status > 300:
				msg = variant_import.get('message')
				return Response().error(msg = msg)
		inventories = list()
		update_variants = list()
		if product.variants:
			for variant in product.variants:
				channel_data = variant.channel.get(f"channel_{self.get_channel_id()}")
				if not channel_data or not channel_data.product_id:
					continue
				variant_id = channel_data.product_id
				qty = to_int(variant.qty)
				inventories.append({
					'variantId': variant_id,
					'quantity': qty,
					"inStock": qty > 0
				})
				variant_price = variant.price
				if self.is_special_price(variant):
					variant_price = variant.special_price.price
					variant.price = variant.special_price.price
				if discount_amount:
					variant_price += discount_amount
				update_variant = {
					'price': variant_price,
					'variantIds': [variant_id]
				}

				update_variants.append(update_variant)
			if setting_price:
				variant_import = self.stores_api(f"products/{product_id}/variants", {'variants': update_variants}, 'patch')
				if self._last_status > 300:
					msg = variant_import.get('message')
					return Response().error(msg = msg)
		if not product.variants:
			inventories.append({
				'variantId': self.variant_default_id(),
				'quantity': to_int(product.qty),
				"inStock": to_int(product.qty) > 0
			})
		if setting_qty:
			inventory_item_id = self.get_inventory_item_id(product_id)
			if not inventory_item_id:
				return Response().error(msg = "Not Found Inventory Item Id")

			if inventory_item_id:
				if product.manage_stock:
					inventory_data = {
						"inventoryItem": {
							"trackQuantity": True,
							"variants": inventories
						}
					}
				else:
					inventory_data = {
						"inventoryItem": {
							"trackQuantity": False
						}
					}
				inventory_import = self.stores_api(f"inventoryItems/{inventory_item_id}", inventory_data, 'patch', version_api = 2)
				if self._last_status > 300:
					msg = inventory_import.get('message')
					return Response().error(msg = msg)

		return Response().success(product)


	def get_options_from_variants(self, variants):
		options = {}
		position = 1
		for variant in variants:
			for attribute in variant.attributes:
				if attribute.attribute_name not in options.keys():
					options[attribute.attribute_name] = {
						'values': [attribute.attribute_value_name],
						'position': position
					}
					position += 1
				elif attribute.attribute_value_name not in options[attribute.attribute_name]:
					options[attribute.attribute_name]['values'].append(attribute.attribute_value_name)
		return options


	def get_order_by_id(self, order_id):
		order = self.stores_api(f'orders/{order_id}', version_api = 2)
		if not order or not order.get('order'):
			return Response().error()
		return Response().success(order['order'])


	def get_orders_main_export(self):
		limit_data = self._state.pull.setting.orders
		id_src = self._state.pull.process.orders.id_src
		imported = self._state.pull.process.orders.imported

		data = {
			"query": {
				"paging": {
					"limit": 100,
				}
			}
		}
		if imported:
			data['query']['paging']['offset'] = imported
		data['query']['filter'] = json_encode(self.get_order_filter())

		orders = self.api('stores/v2/orders/query', data, 'post')
		if not orders or 'orders' not in orders:
			return Response().error(Errors.SHOPIFY_GET_PRODUCT_FAIL)
		return Response().success(data = orders['orders'])


	def get_orders_ext_export(self, orders):
		return Response().success()


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		if setting_order:
			# Wix not supported cancel order via api
			# post_data = {
			# 	"effectiveAt": "IMMEDIATELY"
			# }
			# cancel_api = self.api(f'pricing-plans/v2/orders/{order_id}/cancel', post_data, 'Post')
			return Response().success()
		return self._order_sync_inventory(order, '+')


	def order_partially_refunded(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.order_completed(channel_order_id, order_id, order, current_order, setting_order)


	def order_sync_inventory(self, convert: Order, setting_order):
		if setting_order:
			return Response().success()
		return self._order_sync_inventory(convert)


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		if prefix == '-':
			method = 'decrement'
		else:
			method = 'increment'
		data = list()
		for item in convert.products:
			if item.get('sync_inventory') or item['link_status'] != 'linked' or not item.get('product'):
				continue
			if item['product_id'] and item['parent_id']:
				variant_id = item['product_id']
				product_id = item['parent_id']
			else:
				variant_id = False
				product_id = item['product_id']
			row_qty = to_int(item['qty']) if to_int(item.qty) > 0 else 1

			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):
				variant_update_id = variant_id or self.variant_default_id()
				parent = item['parent'] or item['product']
				if item['product'] and not item['product']['manage_stock']:
					item['sync_inventory'] = True
					continue
				if variant_id and parent.no_manage_variants:
					variant_update_id = self.variant_default_id()
				data.append({
					"variantId": variant_update_id,
					f"{method}By": row_qty,
					"productId": product_id
				})
				item['sync_inventory'] = True

		update_qty = self.stores_api(f"inventoryItems/{method}", {f"{method}Data": data}, version_api = 2, api_type = 'post')
		if self._last_status < 300:
			return Response().success(convert)
		return Response().error()


	def to_wix_total(self, total):
		return to_str(to_decimal(total, 2))


	def order_import(self, order: Order, convert: Order, orders_ext):
		customer = convert.customer
		billing_address = convert.billing_address
		map_status = {
			Order.OPEN: "NOT_PAID",
			Order.AWAITING_PAYMENT: "NOT_PAID",
			Order.READY_TO_SHIP: "PAID",
			Order.SHIPPING: "PAID",
			Order.COMPLETED: "PAID",
			Order.CANCELED: "NOT_PAID",
		}

		payment_status = convert.paymentStatus or get_value_by_key_in_dict(map_status, to_str(convert['status']), 'PENDING')
		customer_info = convert.customer
		shipping_phone_number = convert.shipping_address.telephone
		billing_phone_number = convert.billing_address.telephone
		shipping_state = convert.shipping_address.state.state_name
		shipping_state_code = convert.shipping_address.state.state_code
		billing_state = convert.billing_address.state.state_name
		billing_state_code = convert.billing_address.state.state_code
		channel_info = "OTHER_PLATFORM" if convert.channel_type not in ['ebay','amazon','wish'] else convert.channel_type.upper()
		order_data = {
			'totals': {
				"subtotal": self.to_wix_total(convert.subtotal),
				"total": self.to_wix_total(convert.total),
				"shipping": self.to_wix_total(convert.shipping.amount),
				"tax": self.to_wix_total(convert.tax.amount),
				"discount": self.to_wix_total(convert.discount.amount),
			},
			'billingInfo': {
				"address": {
					"fullName": {
						"firstName": convert.billing_address.first_name,
						"lastName": convert.billing_address.last_name,
					},
					"country": convert.billing_address.country.country_code,
					"subdivision": billing_state if billing_state else billing_state_code,
					"city": convert.billing_address.city,
					"zipCode": convert.billing_address.postcode,
					# "phone": convert.billing_address.telephone,
					"company": convert.billing_address.company,
					"email": customer_info.email,
					"addressLine1": convert.billing_address.address_1,
					"addressLine2": convert.billing_address.address_2,
				},
			},
			'shippingInfo': {
				"deliveryOption": convert.shipping.method or convert.shipping.title,
				"shipmentDetails": {
					"priceData": {
						"price": to_str(convert.shipping.amount)
					},
					"address": {
						"fullName": {
							"firstName": convert.shipping_address.first_name,
							"lastName": convert.shipping_address.last_name,
						},
						"country": convert.shipping_address.country.country_code,
						"subdivision": shipping_state if shipping_state else shipping_state_code,
						"city": convert.shipping_address.city,
						"zipCode": convert.shipping_address.postcode,
						# "phone": convert.shipping_address.telephone,
						"company": convert.shipping_address.company,
						"email": customer_info.email,
						"addressLine1": convert.shipping_address.address_1,
						"addressLine2": convert.shipping_address.address_2,
					}
				},

			},
			'lineItems': [],
			"channelInfo": {
				"type": self._state.channel.config.api.order_channel_info or channel_info,
				"externalOrderUrl": get_app_url(f"orders/{convert['_id']}"),
				"externalOrderId": f"{to_str(convert.order_number_prefix)}{to_str(convert.channel_order_number or convert.order_number)}"
			},
			"paymentStatus": payment_status
		}
		if shipping_phone_number:
			order_data["shippingInfo"]["shipmentDetails"]["address"]["phone"] = shipping_phone_number
		if billing_phone_number:
			order_data["billingInfo"]["address"]["phone"] = billing_phone_number

		if payment_status == 'PAID':
			order_data['billingInfo']['paymentMethod'] = convert.payment.method

		for item in convert.products:
			if item['product_id'] and item['parent_id']:
				variant_id = item['product_id']
				product_id = item['parent_id']
			else:
				variant_id = False
				product_id = item['product_id']
			order_item = {
				'quantity': to_int(item.qty),
				'name': item.product_name,
				'productId': product_id,
				"lineItemType": "PHYSICAL" if product_id else "CUSTOM_AMOUNT_ITEM",
				'priceData': {
					"price": to_str(item.price)
				},

			}
			thumb_image = ''
			thumb_image_id = ''
			if product_id:
				order_item['sku'] = item.product_sku
				order_item['discount'] = to_str(item.discount_amount)
				order_item['tax'] = to_str(item.tax_amount)
			try:
				if variant_id and product_id:
					store_variant = self.stores_api(f'variants/{product_id}---{variant_id}')
					if store_variant and store_variant.variant and store_variant.variant.media:
						thumb_image_id = store_variant.variant.media.id
				if not thumb_image_id and product_id:
					wix_product = self.get_product_by_id(product_id)
					if self._last_status < 300 and wix_product.data and wix_product.data and wix_product.data.media and wix_product.data.media.mainMedia:
						thumb_image_id = wix_product.data.media.mainMedia.id
			except:
				self.log_traceback()
			parent = item['parent'] or item['product']
			product = item['product']
			if thumb_image_id:
				order_item['mediaItem'] = {
					'mediaType': 'IMAGE',
					'id': thumb_image_id
				}
			else:
				if product and product['thumb_image'] and product['thumb_image'].get('url'):
					thumb_image = product['thumb_image'].get('url')
				elif parent and parent['thumb_image'] and parent['thumb_image'].get('url'):
					thumb_image = parent['thumb_image'].get('url')
				elif item.thumb_image:
					thumb_image = item.thumb_image
				if thumb_image:
					order_item['mediaItem'] = {
						'mediaType': 'IMAGE',
						'externalImageUrl': thumb_image
					}
			if variant_id:
				if product.option_data:
					option_data = product['option_data']
				else:
					option_data = self.get_option_data(product_id, variant_id)
				if option_data:
					order_item['options'] = option_data
					if not parent.no_manage_variants:
						order_item['variantId'] = variant_id
			order_data['lineItems'].append(order_item)
		if convert.discount.amount and convert.discount.code:
			order_data['discount'] = {
				"appliedCoupon": {
					"name": convert.discount.title,
					"code": convert.discount.code,
				}
			}

		order_response = self.stores_api('orders', {"order": order_data}, 'post', 2)

		if order_response.get('order'):
			order_data = order_response.get('order')
			order_id_import = order_data['id']
			if convert.status == Order.COMPLETED:
				fulfillment = {
					"lineItems": [],
					"trackingInfo": {
						"trackingNumber": convert.shipments.tracking_number,
						"shippingProvider": convert.shipments.tracking_company_code,
						"trackingLink": convert.shipments.tracking_url,
					}
				}
				for item in order_response['order']['lineItems']:
					fulfillment['lineItems'].append({
						"index": item['index'],
						"quantity": item['quantity']
					})
				create_fulfillments = self.stores_api(f'orders/{order_id_import}/fulfillments', {"fulfillment": fulfillment}, 'post', 2)
			order_return = {
				'order_id': order_id_import,
				'order_status': f"{order_data['paymentStatus']}-{order_data['fulfillmentStatus']}",
				'order_number': order_data['number'],
				'created_at': order_data['dateCreated'],
			}
			return Response().success([order_id_import, order_return])
		else:
			msg = order_response.get('message') if order_response else ''
			return Response().error(msg = msg)


	def get_option_data(self, parent_id, product_id):
		variant_data = self.stores_api(f'variants/{parent_id}-{product_id}')
		if variant_data and variant_data.variant:
			option_data = list()
			for name, value in variant_data.variant.choices.items():
				option_data.append({
					'option': name,
					'selection': value,
				})
			return option_data
		else:
			self.log('Can not get child id: ' + to_str(product_id) + ' from product: ' + to_str(product_id))
			return None


	def order_completed(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self.channel_order_completed(channel_order_id, order, current_order)


	def channel_order_completed(self, order_id, order: Order, current_order):
		wix_order_req = self.get_order_by_id(order_id)
		if wix_order_req.result != Response.SUCCESS:
			return Response().success()
		wix_order = wix_order_req.data
		if wix_order.fulfillmentStatus != 'FULFILLED':
			fulfillment_order_line_items = list()
			for item in wix_order['lineItems']:
				fulfillment_order_line_items.append({
					"index": item.index,
					"quantity": item.quantity
				})
			fulfillment_data = {
				"fulfillment": {
					"trackingInfo": {
						"trackingNumber": to_str(order.shipments.tracking_number),
						"shippingProvider": to_str(order.shipments.tracking_company),
					},
					"lineItems": fulfillment_order_line_items
				}
			}
			if order.shipments.tracking_url:
				fulfillment_data['fulfillment']['trackingInfo']['trackingLink'] = order.shipments.tracking_url
			fulffiments = self.stores_api(f'orders/{order_id}/fulfillments', fulfillment_data, api_type = 'post', version_api = 2)
			if self._last_status < 300:
				return Response().success()
			msg = fulffiments.get('message') if fulffiments else ''
			return Response().error(msg = msg)
		return Response().success()


	def convert_order_status(self, status):
		order_status = {
			"pending": Order.OPEN,
			"partially_refunded": Order.OPEN,
			"authorized": Order.AWAITING_PAYMENT,
			"partially_paid": Order.SHIPPING,
			"paid": Order.COMPLETED,
			"voided": Order.CANCELED,
			"refunded": Order.CANCELED,

		}
		return order_status.get(status, 'open') if status else 'open'


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.lastUpdated)
		if to_int(order.number) == 0:
			self.log(order, "order_number_missed")
			return Response().skip()

		order_data = Order()
		order_data.id = order.id
		order_data.order_number = to_str(order.number)
		order_data.created_at = convert_format_time(order.dateCreated, '%Y-%m-%d %H:%M:%S')
		order_customer = OrderCustomer()
		billing_info = order.billingInfo.address

		if order.buyerInfo:
			customer_data = order.buyerInfo

			order_customer.email = customer_data.email
			order_customer.first_name = customer_data.firstName
			order_customer.last_name = customer_data.lastName
			order_customer.telephone = customer_data.phone
		else:

			order_customer.email = billing_info.email
			order_customer.first_name = billing_info.fullName.firstName
			order_customer.last_name = billing_info.fullName.lastName
			order_customer.telephone = billing_info.phone
		order_data.customer.update(order_customer)
		if not order_data.customer.email and not order_data.customer.first_name and not order_data.customer.last_name:
			order_data.customer.first_name = 'Guest'
		if order.totals:
			order_data.tax.title = 'Tax'
			order_data.tax.amount = to_decimal(order.totals.tax)
			order_data.discount.amount = to_decimal(order.totals.discount)
			order_data.shipping.amount = to_decimal(order.totals.shipping)
			order_data.shipping.title = 'Shipping'
			order_data.subtotal = to_decimal(order.totals.subtotal)
			order_data.total = to_decimal(order.totals.total)
		if order.discount and order.discount.appliedCoupon and order.discount.appliedCoupon.code:
			order_data.discount.code = order.discount.appliedCoupon.code
			order_data.discount.title = order.discount.appliedCoupon.name
		order_data.currency = order.currency
		order_data.created_at = order.dateCreated.replace('T', ' ')[:19]
		order_data.updated_at = order.lastUpdated.replace('T', ' ')[:19]

		customer_address = OrderAddress()
		customer_address.country.country_code = billing_info.country
		customer_address.state.state_code = billing_info.subdivision
		customer_address.first_name = billing_info.fullName.firstName
		customer_address.last_name = billing_info.fullName.lastName
		customer_address.city = billing_info.city
		customer_address.postcode = billing_info.zipCode
		customer_address.telephone = billing_info.phone
		customer_address.company = billing_info.company
		customer_address.address_1 = billing_info.addressLine1
		customer_address.address_2 = billing_info.addressLine2
		order_data.customer_address.update(customer_address)
		order_data.billing_address.update(customer_address)
		shipping_info = order.shippingInfo
		if shipping_info:
			if shipping_info.deliveryOption:
				order_data.shipping.method = shipping_info.deliveryOption
			shipping_address = OrderAddress()
			if shipping_info.shipmentDetails:
				shipping_info_address = shipping_info.shipmentDetails.address
				state_code = to_str(shipping_info_address.subdivision).split('-')
				if state_code:
					shipping_address.state.state_code = state_code[-1]
				shipping_address.country.country_code = shipping_info_address.country
				shipping_address.first_name = shipping_info_address.fullName.firstName
				shipping_address.last_name = shipping_info_address.fullName.lastName
				shipping_address.city = shipping_info_address.city
				shipping_address.postcode = shipping_info_address.zipCode
				shipping_address.telephone = shipping_info_address.phone
				shipping_address.company = shipping_info_address.company
				shipping_address.address_1 = shipping_info_address.addressLine1
				shipping_address.address_2 = shipping_info_address.addressLine2
			else:
				shipping_info_address = shipping_info.pickupDetails.pickupAddress
				state_code = to_str(shipping_info_address.subdivision).split('-')
				if state_code:
					shipping_address.state.state_code = state_code[-1]
				shipping_address.country.country_code = shipping_info_address.country
				shipping_address.first_name = billing_info.fullName.firstName
				shipping_address.last_name = billing_info.fullName.lastName
				shipping_address.city = shipping_info_address.city
				shipping_address.postcode = shipping_info_address.zipCode
				shipping_address.telephone = billing_info.phone
				shipping_address.company = billing_info.company
				shipping_address.address_1 = shipping_info_address.addressLine1
			order_data.shipping_address.update(shipping_address)

		order_items = list()
		for order_product in order['lineItems']:
			order_item = OrderProducts()
			order_item.product_id = order_product.variantId if order_product.variantId and order_product.variantId != self.variant_default_id() else order_product.productId
			order_item.listing_id = order_product.productId
			order_item.index = order_product.index
			order_item.product_name = order_product.name
			order_item.product_sku = order_product.sku
			order_item.qty = to_int(order_product.quantity)
			order_item.price = to_decimal(order_product.priceData.price)
			if order_product.priceData.taxIncludedInPrice:
				order_item.price = to_decimal(to_decimal(order_product.priceData.price) - to_decimal(order_product.tax), 2)
			order_item.tax_amount = to_decimal(order_product.tax)
			order_item.discount_amount = to_decimal(order_product.discount)
			order_item.subtotal = to_decimal(order_item.qty * order_item.price)
			order_item.total = to_decimal(order_product.priceData.totalPrice)
			order_items.append(order_item)
		order_data.products = order_items
		order_status = Order.OPEN
		if order.paymentStatus in ('UNSPECIFIED_PAYMENT_STATUS', 'PENDING'):
			order_status = Order.OPEN
		elif order.paymentStatus == "NOT_PAID":
			order_status = Order.AWAITING_PAYMENT
		elif order.paymentStatus in ['PAID', 'PARTIALLY_PAID']:
			if order.fulfillmentStatus == 'CANCELED':
				order_status = Order.CANCELED
			elif order.fulfillmentStatus in ['NOT_FULFILLED', 'PARTIALLY_FULFILLED']:
				order_status = Order.SHIPPING
			else:
				order_status = Order.COMPLETED
		elif order.paymentStatus in ['PARTIALLY_REFUNDED']:
			order_status = Order.PARTIALLY_REFUNDED
		elif order.paymentStatus in ['FULLY_REFUNDED']:
			order_status = Order.REFUNDED
		order_data.status = order_status
		order_data.channel_data = {
			'order_status': f"{order.paymentStatus}-{order.fulfillmentStatus}",
			'created_at': order_data.created_at,
			'order_number': order_data.order_number,
		}

		if order.fulfillments and order.fulfillments[0].trackingInfo:
			order_data.shipments.tracking_number = order.fulfillments[0].trackingInfo.trackingNumber
			order_data.shipments.tracking_company = order.fulfillments[0].trackingInfo.shippingProvider
			order_data.shipments.tracking_company_code = order.fulfillments[0].trackingInfo.shippingProvider
			order_data.shipments.tracking_url = order.fulfillments[0].trackingInfo.trackingLink
			order_data.shipments.shipped_at = convert_format_time(order.fulfillments[0].dateCreated, "%Y-%m-%dT%H:%M:%S")
		return Response().success(order_data)


	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.id


	def get_sizes(self, url):
		req = Request(url, headers = {'User-Agent': get_random_useragent()})
		try:
			file = urlopen(req)
		except:
			self.log('image: ' + to_str(url) + ' 404', 'image_error')
			return False, False
		size = file.headers.get("content-length")
		# date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
		# type = file.headers.get('content-type')
		if size: size = to_int(size)
		p = ImageFile.Parser()
		while 1:
			data = file.read(1024)
			if not data:
				break
			p.feed(data)
			if p.image:
				return size, p.image.size
				break
		file.close()
		return size, False


	def resize_image(self, url):
		url_resize_image = url
		name = os.path.basename(url)
		result = dict()
		result['filename'] = name
		result['attachment'] = ''
		try:
			image_size, wh = self.get_sizes(url)
			w = 4000
			h = 4000
			if wh:
				w = wh[0]
				h = wh[1]
				if to_decimal(to_decimal(w) * to_decimal(h), 2) > to_decimal(4000 * 4000, 2):
					if to_decimal(w) > to_decimal(h):
						h = 4000 * h / w
						w = 4000
					else:
						w = 4000 * w / h
						h = 4000
				else:
					return None
			time.sleep(0.4)
			r = requests.get(url)
			if r.status_code != 200:
				return result
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			new_width = to_int(w)
			new_height = to_int(h)
			img = img.resize((new_width, new_height), Image.ANTIALIAS)
			output = io.BytesIO()
			if img.mode != 'RGB':
				img = img.convert('RGB')
			img.save(output, format = 'JPEG')
			im_data = output.getvalue()
			image_data = base64.b64encode(im_data)
			if not isinstance(image_data, str):
				# Python 3, decode from bytes to string
				image_data = image_data.decode()
				result['attachment'] = image_data
				return result
		except:
			self.log(url, 'url_fail')
			self.log_traceback("url_fail")
		return None


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()


	def validate_channel_url(self):
		parent = super().validate_channel_url()
		if parent.result != Response.SUCCESS:
			return parent
		return self.validate_wix_url(self._channel_url)


	def validate_wix_url(self, cart_url):
		# shopify_code = re.findall("https://(.*).myshopify.com", cart_url)
		# if not shopify_code:
		# 	return Response().error(Errors.SHOPIFY_URL_INVALID)
		return Response().success()


	def get_province_from_country(self, country_code, province_name = None, province_code = None):
		result = {
			'name': '',
			'code': ''
		}
		countries_data = self.get_shopify_countries()
		if countries_data:
			for country in countries_data:
				if country['code'] != country_code:
					continue
				country_provinces = list()
				if 'provinces' in country:
					country_provinces = country['provinces']
				if province_name or province_code:
					for p in country_provinces:
						if (to_str(province_name) and (to_str(province_name).lower() in to_str(p['name']).lower() or to_str(p['name']).lower() in to_str(province_name).lower())) or (to_str(province_code) and to_str(province_code).lower() == to_str(p['code']).lower()):
							result = p
							break
				if not result['code'] and country_provinces:
					result = self.py_reset(country_provinces)
				break
		return result


	def check_country_code(self, country_code):
		result = False
		countries_data = self.get_shopify_countries()
		if countries_data:
			for country in countries_data:
				if country['code'] == country_code:
					return True
		return result


	def py_reset(self, tmp):
		return tmp[0]


	def clear_tags(self, text_src):
		tag_re = re.compile(r'<[^>]+>')
		return tag_re.sub('', to_str(text_src))


	def get_location_id(self):
		if self._location_id:
			return self._location_id
		location = self.api('locations.json')
		try:
			for location_data in location['locations']:
				if location_data['active'] and not location_data.get('legacy'):
					self._location_id = location_data['id']
			if not self._location_id:
				self._location_id = location['locations'][0]['id']
		except Exception:
			self.log_traceback()
			self._location_id = None
		return self._location_id


	def request_by_method(self, method, url, data, custom_headers = None, auth = None, proxies = ''):
		timeout = 300
		if not self._state.running:
			timeout = 30
		if not custom_headers:
			custom_headers = dict()
			custom_headers['User-Agent'] = self.USER_AGENT
			custom_headers['Content-Type'] = 'application/json'
		elif isinstance(custom_headers, dict) and not custom_headers.get('User-Agent'):
			custom_headers['User-Agent'] = self.USER_AGENT
			custom_headers['Content-Type'] = 'application/json'

		res = False
		r = None
		try:
			if method == 'get':
				r = requests.get(url, headers = custom_headers, auth = auth, timeout = timeout)
			elif method == 'delete':
				r = requests.delete(url, headers = custom_headers, auth = auth, timeout = timeout)
			elif method == 'post':
				r = requests.post(url, data, headers = custom_headers, auth = auth, timeout = timeout)
			elif method == 'patch':
				r = requests.patch(url, data, headers = custom_headers, auth = auth, timeout = timeout)
			self.last_header = r.headers
			self._last_status = r.status_code
			res = r.text
			res_data = json_decode(res)
			if r.status_code >= 400:
				if res_data and res_data.get('message'):
					# self._stop_action = True
					msg = 'Url ' + url
					msg += '\n Method: ' + method
					msg += '\n Status: ' + to_str(r.status_code) if r else ''
					msg += '\n Data: ' + to_str(data)
					msg += '\n Header: ' + to_str(r.headers)
					msg += '\n Response: ' + to_str(res)
					# msg += '\n Error: ' + res_data.get('errors')
					self.log(msg, to_str(self.get_type()) + '_status')
					return res
			r.raise_for_status()

		except requests.exceptions.HTTPError as errh:
			# res_data = json_decode(res)
			msg = 'Url ' + url
			# msg += '\n Retry 5 times'
			msg += '\n Method: Post'
			msg += '\n Status: ' + to_str(r.status_code) if r else ''
			msg += '\n Data: ' + to_str(data)
			msg += '\n Header: ' + to_str(r.headers)
			msg += '\n Response: ' + to_str(res)
			self.log(msg, to_str(self.get_type()) + '_status')

		except requests.exceptions.ConnectionError as errc:
			self.log("Error Connecting:" + to_str(errc) + " : " + to_str(res))
		except requests.exceptions.Timeout as errt:
			self.log("Timeout Error:" + to_str(errt) + " : " + to_str(res))
		except requests.exceptions.RequestException as err:
			self.log("OOps: Something Else" + to_str(err) + " : " + to_str(res))
		return res


	def get_type(self):
		return self._state.channel.channel_type


	def sleep_time(self, value, status = 200, warning = False, resume_action = False, msg = ''):
		if self._state and self._state.channel_type:
			if status not in [200, 201, 204]:
				self._clear_entity_warning = False
				self._total_time_sleep += to_decimal(value)
				if self._total_time_sleep > 30 or warning:
					entity_warning = {
						'entity': self._state.resume.type,
						'status': to_str(status),
						'type': self._type
					}
					if msg:
						entity_warning['msg'] = msg
					if resume_action:
						entity_warning['resume'] = True
			if to_int(value):
				time.sleep(to_int(value))

		return


	def get_total_count_products(self):
		data = {
			"query": {
				"paging": {
					"limit": 1
				}
			},
			"includeVariants": True,
			"includeHiddenProducts": True
		}
		if self.is_refresh_process():
			last_modified = self.get_max_last_modified_product()
			if not last_modified:
				self._first_time_refresh = True
			if last_modified:
				data['query']['filter'] = json_encode({
					'lastUpdated': {
						'$gt': last_modified
					}
				})
		if self._pull_collections_id:
			data['query']['filter'] = json_encode({
				'collections.id': {
					'$hasSome': self._pull_collections_id
				}
			})

		product = self.stores_api('products/query', data, 'Post')
		if product and product.get('totalResults'):
			total = to_int(product.get('totalResults'))
		else:
			total = 0
		if not total:
			self._pull_inventory = True
		if self.is_refresh_process():
			data = {
				"query": {
					"paging": {
						"limit": 1
					}
				},
			}
			last_modified = self.get_max_last_modified_inventory()
			if last_modified:
				data['query']['filter'] = json_encode({
					'lastUpdated': {
						'$gt': last_modified
					}
				})

			product = self.stores_api('inventoryItems/query', data, 'Post', version_api = 2)
			if product and product.get('totalResults'):
				total += to_int(product.get('totalResults'))
		return total


	def get_order_filter(self):
		start_time = self.get_order_start_time('iso').replace('Z', '.000Z')
		filter_data = {
			'dateCreated': {
				'$gte': start_time
			},
		}
		last_modifier = self._state.pull.process.orders.max_last_modified
		if last_modifier:
			if last_modifier.find('.') == -1:
				last_modifier = last_modifier.replace('Z', '.000Z')
			filter_data['lastUpdated'] = {
				'$gt': last_modifier
			}
			self.set_order_max_last_modifier(last_modifier)
		return filter_data


	def get_total_count_orders(self):
		data = {
			"query": {
				"paging": {
					"limit": 1
				}
			}
		}
		data['query']['filter'] = json_encode(self.get_order_filter())
		order = self.api('stores/v2/orders/query', data, 'Post')
		if order.get('totalResults'):
			total = to_int(order.get('totalResults'))
		else:
			total = 0
		return total


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_timestamp(last_modifier, "%Y-%m-%dT%H:%M:%S") > to_timestamp(self._order_max_last_modified, '%Y-%m-%dT%H:%M:%S')):
			self._order_max_last_modified = last_modifier


	def get_image_link(self, image_id):
		return f"https://static.wixstatic.com/media/{image_id}"


	def convert_link_image(self, link):
		return link.split('/v1/')[0]


	def copy_data_from_parent_product(self, parent):
		parent = copy.deepcopy(parent)
		children_data = ProductVariant()
		no_copy = [
			'languages',
			'options',
			'group_parent_ids',
			'attributes',
			'variants',
			'group_child_ids',
			'relate',
			'seo', 'images', 'image', 'thumb_image', 'status',
			'description',
			'variant_count',
			'is_variant'

		]
		for code, value in parent.items():
			if code not in no_copy:
				children_data[code] = value
		return children_data


	def convert_attribute_code(self, name):
		if not to_str(name).strip(' / - _'):
			return ''
		str_convert = html.unescape(name)
		if isinstance(str_convert, bool):
			if str_convert:
				str_convert = 'yes'
			else:
				str_convert = 'no'
		result = self.generate_url(str_convert)
		if not result:
			return self.parse_url(str_convert).lower()
		try:
			check_encode = chardet.detect(result.encode())
			if check_encode['encoding'] != 'ascii' or not result:
				return self.parse_url(result).lower()
		except Exception:
			pass
		return result.strip('- ')


	def count_child_from_option(self, options):
		if not options:
			return 0
		child = 1
		for option in options:
			child *= to_len(option['values'])
		return child


	def combination_from_multi_dict(self, data = None):
		if data is None:
			data = dict()
		data = list(data.values())
		result = list(product(*data))
		return result


	def get_country_name_by_code(self, iso_code):
		if not to_str(iso_code):
			return ''
		try:
			# countries = urllib.request.urlopen("http://country.io/names.json").read()
			# countries = countries.decode('utf-8')
			countries = json.loads(self.COUNTRIES)
		except Exception as e:
			return ''
		return countries.get(to_str(iso_code).upper(), '')


	def get_state_name_by_code(self, state_code, country_code = None):
		if not state_code:
			return ''
		where = dict()
		if country_code:
			where['country_id'] = country_code
		if state_code:
			where['code'] = state_code
		if not where:
			return None
		result = self.select_obj('directory_country_region', where)
		try:
			data = result['data'][0]['default_name']
		except Exception as e:
			data = None
		return data


	def get_category_by_name(self, category_name):
		if self._collections.get(category_name):
			return self._collections.get(category_name)
		data = {
			"query": {
				"filter": json.dumps({'name': category_name})
			}
		}
		collections = self.stores_api('collections/query', data, 'post')
		if collections and to_int(collections.get('totalResults')) > 0:
			collection_id = collections['collections'][0]['id']
			self._collections[category_name] = collection_id
			return collection_id

		category_data = {
			"collection": {
				"name": category_name
			}
		}
		category_import = self.stores_api('collections', category_data, 'post')
		if category_import.get('collection'):
			category_id = category_import['collection']['id']
			self._collections[category_name] = category_id

			return category_id
		return False


	def variant_default_id(self):
		return '00000000-0000-0000-0000-000000000000'


	def get_customer_id(self, convert):
		customer = convert.customer
		data = {
			"query": {
				"filter": {
					"primaryInfo.email": customer.email,
				}
			}
		}
		customer_data = self.api('contacts/v4/contacts/query', data, 'post')
		if customer_data and 'contacts' in customer_data and customer_data['contacts']:
			# get customer+id
			return customer_data['contacts'][0]['id']
		else:
			# import
			address_billing = dict()
			address_shipping = dict()
			customer = convert.customer
			customer_address = convert.customer_address
			customer_billing = convert.billing_address
			customer_shipping = convert.shipping_address
			cus_data = {
				'allowDuplicates': True,
				'info': {
					'name': {
						"first": convert.first_name,
						"last": convert.last_name
					},
					"emails": {
						'items': [
							{
								'tag': 'UNTAGGED',
								'email': customer.email,
							}
						]
					},
					'addresses': {
						'items': [
							{
								"tag": "billing-address",
								"address":
									{
										"street": {
											"name": get_value_by_key_in_dict(customer_billing, 'address_1', get_value_by_key_in_dict(customer_billing, 'address_2', '')),
										},
										"city": get_value_by_key_in_dict(customer_billing, 'city'),
										"postalCode": get_value_by_key_in_dict(customer_billing, 'postcode'),
										"country": customer_billing.country.country_code if customer_billing else '',
										"region": customer_billing.state.state_code if customer_billing else ''
									}
							},
							{
								"tag": "shipping-address",
								"address":
									{
										"street": {
											"name": get_value_by_key_in_dict(customer_address, 'address_1', get_value_by_key_in_dict(customer_address, 'address_2', '')),
										},
										"city": get_value_by_key_in_dict(customer_address, 'city'),
										"postalCode": get_value_by_key_in_dict(customer_address, 'postcode'),
										"country": customer_address.country.country_code if customer_address else '',
										"region": customer_address.state.state_code if customer_address else ''
									}
							},
						]
					}
				}
			}
			if customer.get('phone'):
				cus_data["phones"] = {
					                     'items': [
						                     {
							                     'phone': customer.get('phone', '')
						                     }
					                     ]
				                     },
			customer_response = self.api('contacts/v4/contacts', cus_data, 'Post')
			if customer_response.get('contact'):
				customer_data = customer_response.get('contact')
				customer_id_import = customer_data['id']
				return customer_id_import
			else:
				return 0


	def get_category_by_id(self, category_id):
		if self._all_categories.get(category_id):
			return self._all_categories[category_id]
		category = self.stores_api(f'collections/{category_id}')
		if self._last_status != 200:
			return False
		self._all_categories[category_id] = category.collection.name
		return category.collection.name


	def convert_description(self, description):
		if to_len(description) > 8000:
			description = self.strip_html_from_description(description)
		description = description[0:8000]
		while description.find('\n\n') != -1:
			description = description.replace('\n\n', '\n')

		description = nl2br(description)
		return description


	def to_wix_weight(self, weight, unit):
		if unit == 'oz':
			return to_decimal(weight * 0.0625, 4)
		if unit in ['g', 'gr']:
			return to_decimal(weight * 0.001, 4)
		return weight


	def custom_product(self, product: Product):
		if not to_decimal(self._state.channel.config.api.decrease_price):
			return product
		percent = to_decimal(self._state.channel.config.api.decrease_price)
		product.price = self.decrease_price(product.price, percent)
		if product.special_price.price:
			product.special_price.price = self.decrease_price(product.special_price.price, percent)
		for variant in product.variants:
			variant.price = self.decrease_price(variant.price, percent)
			if variant.special_price.price:
				variant.special_price.price = self.decrease_price(variant.special_price.price, percent)
		return product


	def decrease_price(self, price, percent):
		decrease = to_decimal(price) / 100 * to_decimal(percent)
		return to_decimal(to_decimal(price) - decrease, 2)

	def exclude_allow_update(self):
		return ['dimension_units',
		        'weight_units', ]
