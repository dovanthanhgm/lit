import io
from urllib.request import Request, urlopen

import requests
from PIL import Image
from PIL import ImageFile

from datasync.libs.errors import Errors
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.category import *
from datasync.models.constructs.product import Product, ProductVariant


class ModelChannelsCart(ModelChannel):
	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = None
		self._last_status = None


	def get_api_info(self):
		return {
			'cart_type': "Cart Type",
			'cart_url': 'Cart Url',
			'token': 'Token',
			'migration_id': 'Migration_id',
		}


	# api code
	def get_api_url(self):
		if not self._api_url:
			self._api_url = self.create_api_url()
		return self._api_url


	def create_api_url(self):
		url = get_config_ini('cart', 'url')
		url += '/api/v1'
		return url.strip('/')


	def get_custom_headers(self):
		time_request = to_str(to_int(time.time()))
		private_key = get_config_ini('cart', 'private_key')
		hmac_key = hash_hmac('sha256', time_request, private_key)
		custom_headers = dict()
		custom_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64;en; rv:5.0) Gecko/20110619 Firefox/5.0'
		custom_headers['Authorization'] = time_request + ":" + hmac_key
		return custom_headers


	def api(self, path, data = None, method = 'post', timeout = 120):
		url = '{}/{}'.format(self.get_api_url(), to_str(path).strip('/'))
		headers = self.get_custom_headers()
		response = self.requests(url, data, headers, method, timeout)
		return response


	def requests(self, url, data = None, headers = None, method = 'post', timeout = 120):
		method = to_str(method).lower()
		if not headers:
			headers = dict()
			headers['User-Agent'] = get_random_useragent()
		elif isinstance(headers, dict) and not headers.get('User-Agent'):
			headers['User-Agent'] = get_random_useragent()
		response = False
		request_options = {
			'headers': headers,
			'verify': True
		}
		if timeout:
			request_options['timeout'] = timeout
		if method == 'get' and data:
			request_options['params'] = data
		if method in ['post', 'put'] and data:
			request_options['json'] = data
		request_options = self.combine_request_options(request_options)
		response_data = False
		try:
			response = requests.request(method, url, **request_options)
			self._last_header = response.headers
			self._last_status = response.status_code
			response_data = response.json()
			if response_data:
				response_data = Prodict(**response_data)


			def log_request_error():
				error = {
					'method': method,
					'status': response.status_code,
					'data': to_str(data),
					'header': to_str(response.headers),
					'response': response_data.to_json(),
					'error': response_data.errors
				}
				self.log_request_error(url, **error)


			if response.status_code > 201:
				log_request_error()
		except Exception as e:
			self.log_traceback()
		return response_data


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		api_data = {
			'src_cart_type': 'wixapi' if data.get('channel_type') == 'wix' else data.get('channel_type'),
			'src_cart_url': data.get('channel_url'),
			'src_token': data.get('token'),
			'src_api': data.get('api'),
			'target_cart_type': 'datasync',
			'target_api': {
				'user_id': self._user_id
			},
		}
		try:
			ip_host = socket.gethostbyname(socket.gethostname())  # Default to any avialable network interface
		except Exception:
			ip_host = '127.0.0.1'
		api_data['target_cart_url'] = 'http://' + ip_host + ':' + get_config_ini('local', 'port')
		setup = self.api('action/setup-cart', api_data)
		if not setup or setup.result != Response.SUCCESS:
			return Response().error(Errors.CART_INFO_INVALID, msg = setup.msg if setup else "")
		# self._state.channel.clear_process.function = "clear_channel_taxes"

		return Response().success(setup.data)


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		if self._type == 'bigcommerce':
			api_path = self._state.channel.config.api.api_path
			store = re.findall('https://api.bigcommerce.com/stores/(.+)/v[23]+', api_path)
			if not store:
				return Response().error(Errors.BIGCOMMERCE_API_PATH_INVALID)
			self.set_identifier(store[0])
		else:
			self.set_identifier(self.format_url(self._state.channel.url))
		return Response().success()


	def after_create_channel(self, data):
		self._custom_data.target.config.api.channel_id = data.channel_id
		self._custom_data.target.config.api.process_id = data.process_id
		self._custom_data.target.config.api.process_type = 'product'
		self._custom_data.target.config.api.created_at = self._state.channel.created_at
		self._custom_data.support.languages_select = False
		# get support field from cart migration
		self._state.channel.support.categories = self._custom_data.support.categories
		self._state.channel.support.products = self._custom_data.support.products
		self._state.channel.support.orders = self._custom_data.support.orders
		self._state.channel.support.taxes = self._custom_data.support.taxes

		migration = self.api('migration/create', data = self._custom_data)
		if migration.result != Response.SUCCESS or migration.data.result != Response.SUCCESS:
			return Response().error(Errors.CART_NOT_CREATE_MIGRATION)
		migration = migration.data
		if not self._state.channel.config.api:
			self._state.channel.config.api = Prodict()
		self._state.channel.config.api.migration_id = migration.data

		self.api('action/clear_previous_data', data = {'migration_id': migration.data})
		self.api('migration/{}/product/action/prepare-product-import'.format(migration.data), timeout = 1)

		self.get_model_state()
		return Response().success()


	def display_pull_channel(self):
		config_data = {
			'migration_id': self._state.channel.config.api.migration_id,
			'skip_demo': True
		}
		entities = ('categories', 'products', 'orders')
		if get_config_ini('local', 'mode') != 'live':
			limits = dict()
			for entity in entities:
				limits[entity] = get_config_ini('limit', entity, '-1', file = 'local.ini')
				self._state.config[entity] = get_config_ini('config', entity, False)
		else:
			limits = self.get_entity_limit()
			if self.is_order_process():
				self._state.config.orders = self._state.channel.support.orders
				config_data['orders'] = self._state.channel.support.orders
				self._state.config.taxes = False
				self._state.config.categories = False
				self._state.config.products = False
			else:
				self._state.config.orders = False
				self._state.config.taxes = self._state.channel.support.taxes
				self._state.config.categories = self._state.channel.support.categories
				self._state.config.products = self._state.channel.support.products
				config_data['taxes'] = self._state.channel.support.taxes
				config_data['categories'] = self._state.channel.support.categories
				config_data['products'] = self._state.channel.support.products

		config = self.api('action/config', data = config_data)
		return config


	def start_migration(self, data = None):
		migration_id = self._state.channel.config.api.migration_id

		display_recent = self.api('action/display_recent', data = {'migration_id': migration_id})
		if not display_recent or display_recent['result'] != 'success':
			return Response().error(Errors.CM_NOT_CONNECT)
		recent = self.api('action/recent', data = {'migration_id': migration_id})
		if not recent or recent['result'] != 'success':
			return Response().error(Errors.CM_NOT_CONNECT)

		start_data = {
			'migration_id': self._state.channel.config.api.migration_id,
			'auto_build': True,
			'include_inactive': True,
		}
		if isinstance(data, dict):
			if 'auto_build' in data:
				start_data['auto_build'] = to_bool(data.get('auto_build'))
			if 'include_inactive' in data:
				start_data['include_inactive'] = to_bool(data.get('include_inactive'))
		start = self.api('start/{}'.format(start_data['migration_id']), data = start_data)
		return start


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	def clear_channel_categories(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_products',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.categories:
			return next_clear
		try:
			all_collections = self.api('custom_collections.json?limit=100')
			while all_collections:
				if not all_collections.custom_collections:
					break
				for collect in all_collections.custom_collections:
					id_collect = collect.id
					res = self.api('custom_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('custom_collections.json?limit=100')
				time.sleep(0.1)
			all_collections = self.api('smart_collections.json?limit=100')

			while all_collections:
				if not all_collections:
					return next_clear
				if not all_collections.smart_collections:
					return next_clear
				for collect in all_collections.smart_collections:
					id_collect = collect.id
					res = self.api('smart_collections/{}.json'.format(id_collect), None, 'Delete')
				# a = res
				all_collections = self.api('smart_collections.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			all_products = self.api('products.json?limit=100')
			while all_products:
				if not all_products:
					return next_clear
				if not all_products.products:
					return next_clear
				for product in all_products.products:
					id_product = product.id
					res = self.api('products/{}.json'.format(id_product), None, 'Delete')
				all_products = self.api('products.json?limit=100')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		category_import = self.api('migration/{}/category'.format(self._state.channel.config.api.migration_id), category.to_dict())
		if category_import.result != 'success':
			return Response().error(msg = category_import.msg)
		return Response().success(category_import.data)


	def get_products_main_export(self):
		limit_data = self._state.pull.setting.products
		id_src = self._state.pull.process.products.id_src
		products = self.api('products.json', data = {'since_id': id_src, 'limit': limit_data})
		if not products or not products.products:
			if self._last_status != 200:
				return Response().error(Errors.SHOPIFY_GET_PRODUCT_FAIL)
			return Response().finish()
		return Response().success(data = products.products)


	def get_product_by_id(self, product_id):
		migration_id = self._state.channel.config.api.migration_id

		product = self.api(f"migration/{migration_id}/product/action/get-product-by-id", data = {'migration_id': migration_id, 'product_id': product_id})
		if not product or product['result'] != 'success':
			return Response().error()
		if product and product['result'] == 'success':
			return Response().success(data = [product['data']])
		return Response().error()


	def convert_product(self, product):
		product = dict(product)
		product_construct = Product().to_dict() if not product['is_variant'] else ProductVariant().to_dict()
		product_data = Product().to_dict()
		for field, value in product_construct.items():
			if product.get(field):
				value = product.get(field)
			product_data[field] = value
		if not product['is_variant'] and product.get('variants'):
			variants = list()
			for variant in product['variants']:
				variant = self.convert_product(variant)
				variants.append(variant)
				product_data['variants'] = variants
		return Prodict.from_dict(product_data)


	def get_products_ext_export(self, products):
		extend = Prodict()
		for product in products:
			product_id = to_str(product.id)
			meta = self.api("products/{}/metafields.json".format(product.id))
			extend.set_attribute(product_id, Prodict())
			extend[to_str(product_id)].meta = meta.metafields
		return Response().success(extend)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.id


	def _convert_product_export(self, product, products_ext: Prodict):
		product_data = self.convert_product(product)
		return Response().success(product_data)


	def product_import(self, convert: Product, product, products_ext):
		if isinstance(product.tags, (list, tuple)):
			product.tags = ",".join(product.tags)

		product = self.api('migration/{}/product'.format(self._state.channel.config.api.migration_id), product.to_dict())
		if product.result != 'success':
			return Response().error(Errors.PRODUCT_NOT_CREATE, product.msg)
		return Response().success(product.data)


	def product_channel_update(self, product_id, product: Product, products_ext):
		if isinstance(product.tags, (list, tuple)):
			product.tags = ",".join(product.tags)

		product = self.api(f"migration/{self._state.channel.config.api.migration_id}/product/{product_id}", product.to_dict(), method = 'put')
		if product.result != 'success':
			return Response().error(Errors.PRODUCT_NOT_CREATE, product.msg)
		return Response().success(product.data)


	def channel_sync_inventory(self, product_id, product, products_ext):
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False

		update_data = {
			'product': product.to_dict(),
			'settings': {
				'price': setting_price,
				'qty': setting_qty
			}
		}
		product = self.api(f'migration/{self._state.channel.config.api.migration_id}/product/sync/{product_id}', update_data, method = 'put')
		if product.result != Response().SUCCESS:
			return Response().error(Errors.PRODUCT_NOT_CREATE, product.msg)
		return Response().success(product.data)


	def get_sizes(self, url):
		req = Request(url, headers = {'User-Agent': get_random_useragent()})
		try:
			file = urlopen(req)
		except:
			self.log('image: ' + to_str(url) + ' 404', 'image_error')
			return False, False
		size = file.headers.get("content-length")
		# date = datetime.strptime(file.headers.get('date'), '%a, %d %b %Y %H:%M:%S %Z')
		# type = file.headers.get('content-type')
		if size: size = to_int(size)
		p = ImageFile.Parser()
		while 1:
			data = file.read(1024)
			if not data:
				break
			p.feed(data)
			if p.image:
				return size, p.image.size
				break
		file.close()
		return size, False


	def resize_image(self, url):
		url_resize_image = url
		name = os.path.basename(url)
		result = dict()
		result['filename'] = name
		result['attachment'] = ''
		try:
			image_size, wh = self.get_sizes(url)
			w = 4000
			h = 4000
			if wh:
				w = wh[0]
				h = wh[1]
				if to_decimal(to_decimal(w) * to_decimal(h), 2) > to_decimal(4000 * 4000, 2):
					if to_decimal(w) > to_decimal(h):
						h = 4000 * h / w
						w = 4000
					else:
						w = 4000 * w / h
						h = 4000
				else:
					return None
			time.sleep(0.4)
			r = requests.get(url)
			if r.status_code != 200:
				return result
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			new_width = to_int(w)
			new_height = to_int(h)
			img = img.resize((new_width, new_height), Image.ANTIALIAS)
			output = io.BytesIO()
			if img.mode != 'RGB':
				img = img.convert('RGB')
			img.save(output, format = 'JPEG')
			im_data = output.getvalue()
			image_data = base64.b64encode(im_data)
			if not isinstance(image_data, str):
				# Python 3, decode from bytes to string
				image_data = image_data.decode()
				result['attachment'] = image_data
				return result
		except:
			self.log(url, 'url_fail')
			self.log_traceback("url_fail")
		return None


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error()
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors, "{}_errors".format(entity_type))
			return Response().error()

		else:
			return Response().success()


	def after_create_order_process(self, process):
		migration_id = self._state.channel.config.api.migration_id
		migration = self.api('action/create-order-migration', {'migration_id': migration_id, 'process_id': process['process_id']})
		if not migration:
			return Response().error(Errors.CART_NOT_CREATE_MIGRATION)
		self.update_field_state('channel.config.api.migration_id', migration.data)
		self._state.channel.config.api.migration_id = migration['data']
		self.api('action/clear_previous_data', data = {'migration_id': migration.data})
		return Response().success()


	def after_create_inventory_process(self, process):
		migration_id = self._state.channel.config.api.migration_id
		migration = self.api('action/create-inventory-migration', {'migration_id': migration_id, 'process_id': process['process_id']})
		if not migration:
			return Response().error(Errors.CART_NOT_CREATE_MIGRATION)
		self.update_field_state('channel.config.api.migration_id', migration.data)
		self._state.channel.config.api.migration_id = migration['data']
		self.api('action/clear_previous_data', data = {'migration_id': migration.data})
		return Response().success()
