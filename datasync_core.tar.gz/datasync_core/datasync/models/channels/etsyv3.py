import io
import itertools
import ssl
from copy import deepcopy
from html import unescape
from itertools import product as combination
import validators as python_validators
import requests
from PIL import Image
from requests_oauthlib import OAuth1

from datasync.libs.errors import Errors
from datasync.libs.messages import Messages
from datasync.libs.response import Response
from datasync.libs.utils import *
from datasync.models.channel import ModelChannel
from datasync.models.constructs.activity import Activity
from datasync.models.constructs.category import CatalogCategory
from datasync.models.constructs.order import Order, OrderProducts, OrderItemOption, OrderHistory, OrderHistoryStaff
from datasync.models.constructs.product import Product, ProductImage, ProductVariant, ProductVariantAttribute, ProductAttribute


# from datasync.models.collections.template import Template


class ModelChannelsEtsyV3(ModelChannel):
	COUNTRIES = '{"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon", "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar", "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China", "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen", "DZ": "Algeria", "US": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India", "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}'

	FORMAT_DATETIME = '%Y-%m-%d %H:%M:%S'
	INIT_INDEX_FIELDS = ['state']
	TEMPLATE_REQUIRED_ASSIGN = ['price', 'title', 'category', 'shipping']

	ORDER_STATUS = {
		'refunded': Order.REFUNDED,
		'paid': Order.SHIPPING,
		'open': Order.OPEN,
		'payment processing': Order.AWAITING_PAYMENT,
		'canceled': Order.CANCELED,
		'processing': Order.SHIPPING,
		'completed': Order.COMPLETED,
		'unshipped': Order.CANCELED,
		'unpaid': Order.AWAITING_PAYMENT
	}


	def __init__(self):
		super().__init__()
		self._api_url = None
		self._version_api = None
		self._last_status = None
		self.flag_pull_order = False
		self.imported_product_active = 0
		self._pull_active_listing = True
		self._product_pull_type = 'active'
		self._active_imported = 0
		self._draft_imported = 0
		self._api_time = list()
		self._page = 0
		self._order_max_last_modified = 0
		self._last_created_at = 0
		self._all_section = dict()
		self._product_new_qty = None
		self._taxonomy_response = dict()


	def get_api_info(self):

		return {
			'access_token': "access_token",
			'access_token_secret': 'access_token_secret',
			'etsy_user_id': 'etsy_user_id',
			'name': 'name',
		}


	def get_active_imported(self):
		if self._active_imported is not None:
			return self._active_imported
		where = self.get_model_catalog().create_where_condition(f"channel.channel_{self._state.channel.id}.state", 'active')
		where.update(self.get_model_catalog().create_where_condition("is_variant", False))

		self._active_imported = self.get_model_catalog().count(where)
		return self._active_imported


	def get_draft_imported(self):
		if self._draft_imported is not None:
			return self._draft_imported
		where = self.get_model_catalog().create_where_condition(f"channel.channel_{self._state.channel.id}.state", 'draft')
		where.update(self.get_model_catalog().create_where_condition("is_variant", False))

		self._draft_imported = self.get_model_catalog().count(where)
		return self._draft_imported


	# api code
	def get_etsy_user_id(self):
		return self._state.channel.config.api.etsy_user_id


	def get_shop_id(self):
		return self._state.channel.config.api.shop_id


	def get_access_token(self):
		return self._state.channel.config.api.access_token


	def get_access_token_secret(self):
		return self._state.channel.config.api.access_token_secret


	def info(self):
		info = {
			"access_token": self._state.channel.config.api.access_token,
			"access_token_secret": self._state.channel.config.api.access_token_secret,
			"etsy_user_id": self._state.channel.config.api.etsy_user_id,
			"name": self._state.channel.config.api.name,
			"shipping_template_id": self._state.channel.config.api.shipping_template_id
		}
		return info


	def get_api_path(self, path, add_version = True):
		path = to_str(path).replace('admin/', '')
		prefix = 'admin'
		if add_version:
			prefix += '/api/' + self.get_version_api()
		path = prefix + '/' + path
		return path


	def get_version_api(self):
		if self._version_api:
			return self._version_api
		year = get_current_time("%Y")
		month = get_current_time("%m")
		quarter = (to_int(month) - 1) // 3 + 1
		version_api = (to_int(quarter) - 1) * 3 + 1
		if version_api < 10:
			version_api = "0" + to_str(version_api)
		else:
			version_api = to_str(version_api)

		self._version_api = to_str(year) + "-" + version_api
		return self._version_api


	def auth(self):
		client_key = self.get_client_id(self._user_id)
		client_secret = self.get_client_secret(self._user_id)
		resource_owner_key = self.info()['access_token']
		resource_owner_secret = self.info()['access_token_secret']
		auth = OAuth1(client_key, client_secret, resource_owner_key, resource_owner_secret)
		return auth


	def sleep_time(self):
		time.sleep(0.1)
		return
		if len(self._api_time) < 10:
			self._api_time.append(time.time())
		else:
			sub = time.time() - self._api_time[0]
			if sub <= 1:
				time.sleep(1 - sub)
			del self._api_time[0]
			self._api_time.append((time.time()))


	def get_shop_language(self):
		shop_language = []
		if self._state.channel.config.api.shop_language:
			shop_language = self._state.channel.config.api.shop_language
		else:
			shop_info = self.api_v2(path = f"shops/{self.info()['name']}", auth = self.auth(), shop_language = False)
			if shop_info.result == Response.SUCCESS:
				language = shop_info.data.results[0].languages
				self._state.channel.config.api.shop_language = language
				shop_language = language
				self.update_channel(api = json_encode(self._state.channel.config.api))
		if shop_language:
			return shop_language[0]

		return False


	def shop_api_v3(self, path, data = None, params = None, method = 'get', retry = 0, shop_language = True, **kwargs):
		path = f"shops/{self.get_shop_id()}/{path.strip('/')}"
		return self.api_v3(path, data, params, method, retry, shop_language, **kwargs)


	def refresh_access_token(self):
		url = f"https://api.etsy.com/v3/public/oauth/token"
		payload = {
			'grant_type': 'refresh_token',
			'client_id': self.get_client_id(),
			'refresh_token': self.get_access_token_secret()
		}
		res = requests.request(method = 'post', url = url, data = payload)
		if res.status_code != 200:
			self.channel_disconnected()
			return False
		self._state.channel.config.api.access_token = res.json()['access_token']
		self._state.channel.config.api.access_token_secret = res.json()['refresh_token']
		self.update_channel(api = json_encode(self._state.channel.config.api))
		return res.json()['access_token']


	def api_v3(self, path, data = None, params = None, method = 'get', retry = 0, shop_language = True, **kwargs):
		time.sleep(0.1)
		url = "https://openapi.etsy.com/v3/application/" + path.strip('/')
		if shop_language:
			shop_lang = self.get_shop_language()
			if shop_lang:
				if not params:
					params = dict()
				params['language'] = shop_lang
		custom_headers = {
			'x-api-key': self.get_client_id(),
			'Authorization': f"Bearer {self.get_access_token()}"
		}

		if not kwargs:
			kwargs = dict()
		log_file = ''
		if kwargs.get('log_file'):
			log_file = kwargs['log_file']
			del kwargs['log_file']
		current_kwargs = deepcopy(kwargs)
		kwargs['headers'] = custom_headers
		if data:
			if method == 'get':
				params.update(data)
			else:
				if not kwargs.get('files'):
					kwargs['json'] = data
				else:
					kwargs['data'] = data
		kwargs['params'] = params
		try:
			response = requests.request(method, url, **kwargs)
		except Exception as e:
			if retry < 5:
				retry += 1
				time.sleep(5 * retry)

				return self.api_v3(path, data, params, method, retry, shop_language, **current_kwargs)
			self.log_traceback()
			return Response().error(msg = "Unable to connect to Etsy. Please try again later.")
		error = {
			'method': method,
			'url': url,
			'headers': response.headers,
			'data': data,
			'params': params,
			'status_code': response.status_code,
			'content': response.text,
			'retry': retry,

		}
		if log_file:
			del error['url']
			self.log_request_error(url, log_type = log_file, **error)
			error['url'] = url
		if self.is_log():
			self.log_request_error(**error)

		self._last_header = response.headers
		self._last_status = response.status_code
		if response.status_code == 400 and 'OAuth1 support has been deprecated. Please use the OAuth2 protocol' in response.text:
			self.set_action_stop(True)
			self.channel_disconnected()
		if response.status_code == 401:
			token = self.refresh_access_token()
			if not token:
				self.set_action_stop(True)
				return Response().error(msg = "Disconnected")
			# self.get_model_state().update(self._state.get('_id'), {"channel.config.api.access_token": token})
			self._state.channel.config.api.access_token = token
			custom_headers['Authorization'] = f'Bearer {token}'
			kwargs['headers'] = custom_headers

			response = requests.request(method, url, **kwargs)
			self._last_status = response.status_code
			if response.status_code == 401:
				self.set_action_stop(True)
		if response.status_code <= 204:
			if response.text:
				response_data = response.json()
				response_data = Prodict.from_dict(response_data)
			else:
				response_data = True
			return Response().success(response_data)

		self.log_request_error(**error)

		if (response.status_code == 429 or (response.status_code == 409 and 'is being edited by another process' in response.text)) and retry < 5:
			retry += 1
			time.sleep(5 * retry)
			error['retry'] = retry
			self.log_for_channel(url, method, response.status_code)

			return self.api_v3(path, data, params, method, retry, shop_language, **current_kwargs)
		if response.status_code == 400 and "You have exceeded your quota of" in response.text:
			notification_data = {
				'code': 'etsy_rate_limit',
				'activity_type': 'etsy_rate_limit',
				'description': 'Etsy rate limit',
				'date_requested': self._date_requested,
				'result': Activity.FAILURE,
				'content': Messages.ETSY_RATE_LIMIT
			}
			self.log_for_channel(url, method, response.status_code)

			self.create_activity_notification(**notification_data)
			return Response().error(code = Errors.ETSY_RATE_LIMIT, msg = "Error returned from Etsy: Has exceeded the limit of calling request to api. Please wait another 30 minutes")
		elif response.status_code == 429:
			retry += 1
			time.sleep(5 * retry)
			error['retry'] = retry
			self.log_request_error(**error)
			self.log_for_channel(url, method, response.status_code)

			return self.api_v3(path, data, params, method, retry, shop_language)
		response_data = response.text
		msg = ''
		if json_decode(response_data):
			response_data = json_decode(response_data)
			if isinstance(response_data, dict):
				response_data = [response_data]
			if isinstance(response_data, list):
				msg_list = list()
				for row in response_data:
					msg_row = row.get('error') or row.get('message')
					if row.get('path'):
						path = to_str(row.get('path')).replace('\/', '').replace('\/0', '').strip('/ \\')
						msg_row = f'{path} {msg_row}'
					msg_list.append(msg_row)
				msg = '_lic_nl_'.join(msg_list)
			if not msg:
				msg = response.text
		return Response().error(msg = msg)


	def api_v2(self, method = 'get', path = '', headers = None, params = None, data = None, files = [], auth = None, retry = 0, shop_language = True):
		if not auth:
			auth = self.auth()
		self.sleep_time()
		url = f"https://openapi.etsy.com/v2/"
		url += path.strip('/')
		if shop_language:
			shop_lang = self.get_shop_language()
			if shop_lang:
				if not params:
					params = dict()
				params['language'] = shop_lang
		try:
			response = requests.request(method, url, headers = headers, params = params, data = data, files = files, auth = auth)
			self._last_status = response.status_code

			if response.status_code in [200, 201]:
				# time.sleep(0.1)
				return Response().success(data = response.json())
			error = {
				'method': method,
				'url': url,
				'headers': headers,
				'data': data,
				'params': params,
				'status_code': response.status_code,
				'content': response.text
			}
			if response.status_code == 409 and 'The resource is being edited by another process' in response.text and retry < 5:
				retry += 1
				time.sleep(5 * retry)
				error['retry'] = retry
				self.log_request_error(**error)

				return self.api_v2(method, path, headers, params, data, files, auth, retry)
			self.log_request_error(**error)

			if response.status_code == 400 and "You have exceeded your quota of" in response.text:
				# error = {
				# 	'method': method,
				# 	'url': url,
				# 	'headers': headers,
				# 	'data': data,
				# 	'params': params,
				# 	'status_code': response.status_code,
				# 	'content': response.content
				# }
				# self.log_request_error(**error)
				notification_data = {
					'code': 'etsy_rate_limit',
					'activity_type': 'etsy_rate_limit',
					'description': 'Etsy rate limit',
					'date_requested': self._date_requested,
					'result': Activity.FAILURE,
					'content': Messages.ETSY_RATE_LIMIT
				}
				self.create_activity_notification(**notification_data)
				return Response().error(code = Errors.ETSY_RATE_LIMIT, msg = "Error returned from Etsy: Has exceeded the limit of calling request to api. Please wait another 30 minutes")
			else:

				return Response().error(code = Errors.ETSY_FAIL_API, msg = response.text)

		except Exception as e:
			error = {
				'method': method,
				'url': url,
				'headers': headers,
				'files': files,
				'data': data,
				'error': e
			}
			self.log_request_error(**error)
			return Response().error(code = Errors.EXCEPTION, msg = e)


	def display_setup_channel(self, data = None):
		parent = super().display_setup_channel(data)
		if parent.result != Response().SUCCESS:
			return parent
		# shop_lange = self.get_shop_language()
		# order = self.get_product_by_id(1431504493)
		# order_ext = self.get_products_ext_export([order['data']])
		# convert = self.convert_product_export(order['data'], order_ext['data'])
		check = self.shop_api_v3('listings', params = {'limit': 1})
		if self._last_status != 200:
			return Response().error(Errors.ETSY_API_INVALID, msg = "access token invalid")

		self._state.channel.support.taxes = False
		self._state.channel.support.categories = True

		return Response().success(data)


	def set_channel_identifier(self):
		parent = super().set_channel_identifier()
		if parent.result != Response().SUCCESS:
			return parent
		etsy_user_id = self.set_identifier(self.get_etsy_user_id())
		return Response().success(etsy_user_id)


	def validate_get_items_id(self, response_products):
		"""The batch endpoint will retrieve data including other shop.
		 Check shop_id before importing"""
		if response_products.result != Response.SUCCESS:
			return response_products
		product_list = response_products.data.get('results')
		shop_id = to_str(self.get_shop_id())

		product_validate = list(filter(lambda x: to_str(x['shop_id']) == shop_id, product_list))

		response_products.data.count = len(product_validate)
		response_products.data.results = product_validate

		return response_products


	def display_pull_channel(self):
		parent = super().display_pull_channel()
		self._state.pull.process.products.include_expired = to_bool(self._request_data.get('include_expired'))
		if parent.result != Response().SUCCESS:
			return parent
		if self.is_product_process():
			if self._state.pull.process.products.finished:
				self._state.pull.process.products.finished = False
				self._state.pull.process.products.imported = 0
				self._state.pull.process.products.new_entity = 0
				self._state.pull.process.products.imported_inactive = 0
				self._state.pull.process.products.imported_expired = 0
				self._state.pull.process.products.imported_draft = 0
				self._state.pull.process.products.imported_sold_out = 0
				self._state.pull.process.products.error = 0
				self._state.pull.process.products.id_src = 0
			offset = self._state.pull.process.products.imported
			params = {
				'limit': 1

			}
			if offset:
				params['offset'] = offset
			if self._request_data.get("section_ids", {}):
				params['shop_section_ids'] = [int(x) for x in self._request_data.get("section_ids", {})]
				products_api = self.api_v3(path=f"shops/{self.get_shop_id()}/shop-sections/listings", params=params)
			elif self._request_data.get("item_ids", {}):
				list_id = self._request_data.get("item_ids", {}).split(",")
				for index in range(0, len(list_id)):
					field = list_id[index]
					params[f"listing_ids[{index}]"] = to_int(field)
				products_api = self.validate_get_items_id(
					self.api_v3(path=f"listings/batch", params=params))


			else:
				products_api = self.shop_api_v3(path=f"listings", params=params)
			self._state.pull.process.products.total = 0
			if products_api.result == Response.SUCCESS:
				self._state.pull.process.products.total = to_int(products_api['data']['count'])
			if not self.is_refresh_process():
				for row in ['inactive', 'expired', 'sold_out', 'draft']:
					if self.is_import_product_by_status(row):
						params = {
							'limit': '1',
							'state': row
						}
						imported = self._state.pull.process.products.get(f'imported_{row}')
						if to_str(imported):
							params['offset'] = to_str(imported)
						products_api = self.shop_api_v3(path=f"listings", params=params)
						if products_api.result == Response.SUCCESS:
							self._state.pull.process.products.total += to_int(products_api['data']['count'])

		if self.is_order_process():
			start_time = self.get_order_start_time(False)
			last_modifier = self._state.pull.process.orders.max_last_modified
			# if self._state.channel.config.start_time:
			# 	start_time = self._state.channel.config.start_time
			params = {'limit': '1', 'min_created': start_time}
			if last_modifier:
				params['min_last_modified'] = last_modifier
				self.set_order_max_last_modifier(last_modifier)
			orders_api = self.shop_api_v3(path=f"receipts", params=params)
			self._state.pull.process.orders.total = 0
			if orders_api.result == Response.SUCCESS:
				self._state.pull.process.orders.total = to_int(orders_api['data']['count'])
			self._state.pull.process.orders.imported = 0
			self._state.pull.process.orders.new_entity = 0
			self._state.pull.process.orders.error = 0
			self._state.pull.process.orders.id_src = 0

		return Response().success()


	def set_order_max_last_modifier(self, last_modifier):
		if last_modifier and (not self._order_max_last_modified or to_int(last_modifier) > self._order_max_last_modified):
			self._order_max_last_modified = last_modifier


	# TODO: clear
	def clear_channel_taxes(self):
		next_clear = Prodict.from_dict({
			'result': 'process',
			'function': 'clear_channel_categories',
		})
		self._state.channel.clear_process = next_clear
		return next_clear


	# TODO: Categories

	def get_categories_main_export(self):
		shop_id = self.info()['name']
		try:
			categories_data = self.api_v2(path = f"/shops/{shop_id}/sections?api_key={self.get_client_id(self._user_id)}")
			if categories_data['result'] != "success":
				return Response().finish()
		# if isinstance(categories_data, dict):
		# 	return Response().error(Errors.ETSY_API_INVALID, msg = categories_data.get('content'))
		except Exception as e:
			return Response().error(Errors.EXCEPTION, msg = e)
		return Response().success(data = categories_data)


	def get_categories_ext_export(self, categories):
		extend = dict()
		shop_id = self._state.channel.config.api.name
		for category in categories:
			extend[to_str(category['shop_section_id'])] = dict()
			meta = False
			try:
				meta = self.api_v2(path = f"/shops/{shop_id}/sections/{category['shop_section_id']}?api_key={self.get_client_id(self._user_id)}")
				if meta['data']['count'] != 0:
					extend[to_str(category['shop_section_id'])]['meta'] = meta
			except Exception as e:
				self.log(f"failed get section {to_str(category['shop_section_id'])}")
		return Response().success(extend)


	def convert_category_export(self, category, categories_ext):
		shop_id = self._state.channel.config.api.name
		category_data = CatalogCategory()
		category_id = to_str(category['shop_section_id'])
		parent = CatalogCategory()
		category_data.parent = parent
		category_data.id = category.shop_section_id
		api_key = self.get_client_id(self._user_id)
		category_data.seo_url = f"https://www.etsy.com/shop/{shop_id}?section_id={category_id}"
		res = requests.get(f"https://openapi.etsy.com/v2/shops/{shop_id}/sections/{category_id}?api_key={api_key}")
		category_data.active = True if res.status_code == 200 else False
		category_data.name = category.title
		# category_data.description = category.body_html
		category_data['created_at'] = convert_format_time(time_data = datetime.now(), old_format = self.FORMAT_DATETIME)
		category_data['updated_at'] = convert_format_time(time_data = datetime.now(), old_format = self.FORMAT_DATETIME)
		return Response().success(category_data)


	def get_category_id_import(self, convert: CatalogCategory, category, categories_ext):
		return category['shop_section_id']


	def category_import(self, convert: CatalogCategory, category, categories_ext):
		shop_id = self.info()['name']
		if category.name:
			headers = {'title': category.name}
			section = self.api_v2(path = f"/shops/{shop_id}/sections", headers = headers)
			if section['data']['count'] == 0:
				self.log(f"failed create section with shop_id {shop_id}, title {category.name}")

		check_response = self.check_response_import(section['data']['results'], category, 'category')
		if check_response.result != Response.SUCCESS:
			return check_response
		category_id = section['data']['results'][0]['shop_section_id']
		return Response().success(category_id)


	# TODO: Products
	def clear_channel_products(self):
		next_clear = Prodict.from_dict({
			'result': 'success',
			'function': '',
		})
		self._state.channel.clear_process = next_clear
		if not self._state.config.products:
			return next_clear
		try:
			shop_id = self.info()['name']
			headers = {'offset': '0', 'limit': '10000000'}
			all_products = self.api_v2(path = f"/shops/{shop_id}/listings/active", headers = headers)
			while all_products:
				if all_products['data']['count'] == 0:
					return next_clear
				for product in all_products['data']:
					id_product = product.get('listing_id')
					self.api_v2(path = f"/listings/{id_product}", method = 'delete')
				time.sleep(0.1)
		except Exception:
			self.log_traceback()
			return next_clear
		return next_clear


	def get_product_by_updated_at(self):
		return self.get_products_main_export()


	def is_exclude_inventory(self):
		return self._state.channel.config.api.exclude_inventory


	def get_products_main_export(self):
		limit_data = self._state.channel.config.api.product_limit or 100
		try:
			products_data = list()
			if not self._product_pull_type:
				return Response().finish()
			if self._product_pull_type == 'active':
				imported = self._state.pull.process.products.imported
			else:
				if self.is_refresh_process() or not self.is_import_product_by_status(self._product_pull_type):
					self.set_product_pull_type()
					return self.get_products_main_export()
				imported = self._state.pull.process.products.get(f'imported_{self._product_pull_type}')
			params = {
				'limit': str(limit_data),
				"state": self._product_pull_type,
				"includes": "Images,Inventory"
			}
			if self.is_exclude_inventory():
				params['includes'] = 'Images'
			if to_str(imported):
				params['offset'] = to_str(imported)
			if self._request_data.get("section_ids", {}):
				params['shop_section_ids'] = [int(x) for x in self._request_data.get("section_ids", {})]
				products = self.api_v3(path=f"shops/{self.get_shop_id()}/shop-sections/listings", params=params)
				if products.result == Response.SUCCESS:
					for index in range(0, len(products['data']['results'])):
						field = products['data']['results'][index]
						params[f"listing_ids[{index}]"] = field['listing_id']
				# params['listing_ids'] = list_id.rstrip(",")
				products = self.api_v3(path=f"listings/batch", params=params)
			elif self._request_data.get("item_ids", {}):
				list_id = self._request_data.get("item_ids", {}).split(",")
				for index in range(0, len(list_id)):
					field = list_id[index]
					params[f"listing_ids[{index}]"] = to_int(field)
				products = self.validate_get_items_id(
					self.api_v3(path=f"listings/batch", params=params))
			else:
				products = self.shop_api_v3(path=f"listings", params=params)
			if self._last_status != 200:
				return Response().finish(code=Errors.ETSY_API_INVALID, msg=products.get('msg'))
			if products.result == Response.SUCCESS:
				products_data = products['data']['results']
			if not products_data:
				self.set_product_pull_type()
				return self.get_products_main_export()
		except Exception as e:
			self.log_traceback()
			return Response().finish(code=Errors.EXCEPTION, msg=e)
		return Response().success(products_data)


	def set_product_pull_type(self):
		product_status = self._product_pull_type
		product_next_type = {
			'active': 'inactive',
			'inactive': 'expired',
			'expired': 'sold_out',
			'sold_out': 'draft',
			'draft': ''
		}
		self._product_pull_type = product_next_type.get(product_status, '')


	def get_products_ext_export(self, products):
		extend = Prodict()
		for product in products:
			product_id = to_str(product.listing_id)
			extend[to_str(product_id)] = product
		return Response().success(extend)


	def get_product_id_import(self, convert: Product, product, products_ext):
		return product.listing_id


	def _convert_product_export(self, product, products_ext: Prodict):
		# if not product.get_associations:
		# 	product = self.get_product_by_id(product.listing_id)['data']
		product_id = to_str(product.listing_id)
		product_data = Product()
		product_data.tags = ",".join(product.tags)
		weight = to_decimal(product.item_weight)
		if not weight % 16:
			product_data.weight = weight / 16
			product_data.weight_units = 'lb'
		else:
			product_data.weight = product.item_weight  # product['variants'][0]['grams'] if product['variants'][0]['weight_unit'] == 'g' else
			product_data.weight_units = product.item_weight_unit
		product_data.length = to_decimal(product.item_length)
		product_data.width = to_decimal(product.item_width)
		product_data.height = to_decimal(product.item_height)
		# product_data.weight_units = product.item_weight_unit
		product_data.dimension_units = product.item_dimensions_unit
		product_data.product_type = "digital" if product.listing_type == "download" else "physical"

		product_data.status = True if product.state == 'active' else False
		product_data.invisible = True if product.state != 'active' else False
		product_data.created_at = self.convert_format_time(product.original_creation_timestamp)
		product_data.updated_at = self.convert_format_time(product.last_modified_timestamp)
		product_data.name = product.title
		product_data.description = product.description
		product_data.price = to_decimal(to_decimal(product.price.amount) / to_decimal(product.price.divisor), 2)
		url_key = product.url.split('?')[0] if product.url else None
		product_data.seo_url = url_key or f'https://www.etsy.com/listing/{product.listing_id}'
		image_ids = list()
		etsy_images = dict()

		# images = self.api_v3(path = f"/listings/{product_id}/images")
		if product.images:
			for index, image in enumerate(product.images):
				if image['listing_image_id'] in image_ids:
					continue
				etsy_images[image['listing_image_id']] = image['url_fullxfull']

				image_ids.append(image['listing_image_id'])
				if not index:
					product_data.thumb_image.url = image.url_fullxfull
					continue
				product_image_data = ProductImage()
				product_image_data.url = image.url_fullxfull
				product_image_data.image_id = image['listing_image_id']

				product_data.images.append(product_image_data)
		if not self.is_exclude_inventory():
			inventory = product.inventory
			variant_sku = ''
			if inventory.get('products'):
				variant_default = inventory['products'][0]
				variant_sku = variant_default.sku
			if variant_sku:
				product_data.sku = variant_sku
		else:
			if product.listing_type == 'physical':
				inventory = self.api_v3(path = f"/listings/{product_id}/inventory")['data']
			else:
				inventory = Prodict()
		channel_data = {}
		channel_data['listing_type'] = product['listing_type']
		if not product_data.sku:
			if not product.skus:
				channel_data['empty_sku'] = True
				product_data.sku = product_id
			else:
				product_data.sku = product.skus[0]
		if self._state.channel.config.product_id_to_sku:
			product_data.sku = product_id

		state = product.state
		if state == 'edit':
			state = 'inactive'
		if state == 'draft':
			state = 'etsy_draft'

		product_data.qty = product.quantity
		if not product.syncing:
			category_path_api = self.get_category_path(channel_type = 'etsy', type_search = f'{self.get_channel_id()}/category/search', params = {"category_id": product.taxonomy_id})
			if category_path_api and category_path_api.get('data'):
				category_path = category_path_api['data'][0]['path']
			else:
				category_path = product.taxonomy_id
			channel_data['state'] = state
			channel_data['category_path'] = category_path
			# if self._state.channel.config.section_to_category and product.shop_section_id:
			section_name = self.get_section_name(product.shop_section_id)
			if section_name:
				channel_data['category_path'] = section_name
			properties = self.shop_api_v3(path = f"/listings/{product_id}/properties")
			etsy_attributes = []
			if properties.result == Response.SUCCESS:
				for att in properties.data.results:
					if att['property_name'] in ['Weight', 'Height', 'Length', 'Width']:
						if not to_decimal(att['values'][0]):
							continue
						if att['property_name'] == 'Weight' and not product_data.weight:
							product_data.weight = to_decimal(att['values'][0])
							product_data.weight_units = 'kg' if att.scale_name.lower() in ['kg', 'kilogram', 'kilograms'] else 'oz'
						else:
							attribute_name = att['property_name'].lower()
							if not product_data.get(attribute_name):
								product_data[attribute_name] = to_decimal(att['values'][0])
							product_data.dimension_units = 'in' if att.scale_name.lower() in ['in', 'inch', 'inches'] else 'cm'
						continue
					attribute_values = att['value_ids'] or att['values']
					etsy_attributes.append({
						'attribute_id': att['property_id'],
						'scale_id': att['scale_id'],
						'attribute_value': ','.join(list(map(lambda x: to_str(x), attribute_values)))

					})

					attribute_data = ProductAttribute()
					attribute_data.attribute_name = att['property_name']
					attribute_data.attribute_code = att['property_id']
					attribute_data.attribute_value_name = ', '.join(att['values'])
					product_data.attributes.append(attribute_data)
			template_data = {
				'category': {
					'about': {
						'who_made': product.who_made,
						'when_made': product.when_made,
						'is_supply': 1 if product.is_supply else 0,
						'production_partner_ids': [row['production_partner_id'] for row in product.production_partners] if product.production_partners else []
					},
					'category': {
						'id': product.taxonomy_id,
						'name': category_path
					},
					'advance': {
						'section': product.shop_section_id,
						'tags': ', '.join(product.tags) if isinstance(product.tags, list) else product.tags,
						'materials': ', '.join(product.materials) if isinstance(product.materials, list) else product.materials,
						'attributes': etsy_attributes,
					}
				},
				'shipping': {
					'shipping_id': product.shipping_profile_id,
					'policy_id': product.return_policy_id,
				},
				'personalization': {
					'status': 'enable' if product.is_personalizable else 'disable',
					'is_required': product.personalization_is_required,
					'char_count_max': product.personalization_char_count_max,
					'instructions': product.personalization_instructions,
				}
			}
			if product.listing_type == "download":
				template_data["digital"] = {
					"digital_status": True
				}

			product_data.template_data = template_data
			product_data.channel_data = channel_data
		if not product.has_variations:
			return Response().success(product_data)
		# if product.get('state') == 'active':
		# 	variants = self.api(path = f"/listings/{product.listing_id}/inventory", params = params)
		# else:
		# 	variants = self.api(path = f"/listings/{product.listing_id}/inventory", auth = self.auth())
		if product.has_variations and inventory and inventory.get('products'):
			variant_etsy_images = dict()
			variant_etsy_image_ids = dict()
			all_attributes = {}
			all_attributes_by_name = {}
			all_attributes_by_name1 = []
			if not product.syncing:
				variant_images = self.shop_api_v3(path = f'/listings/{product_id}/variation-images')
				if variant_images and variant_images.data and variant_images.data.results:
					for image in variant_images.data.results:
						if image['image_id'] not in etsy_images:
							continue
						key_gen = f"p{image['property_id']}-v{image['value_id']}"
						variant_etsy_image_ids[key_gen] = image['image_id']
			# if product.Inventory and product.Inventory[0].get('products') and to_len(product.Inventory[0].get('products')) > 1:
			variant_exist = list()
			for index, variant in enumerate(inventory.get('products')):
				# product_variant = self.api(path = f"/listings/{product_id}/products/{variant['product_id']}", auth = self.auth())
				variant_data = ProductVariant()
				if not inventory.quantity_on_property:
					variant_data.tracking_inventory = 'product'
					product_data.tracking_inventory = 'product'
				variant_data.id = variant['product_id']
				variant_data.seo_url = product_data.seo_url
				variant_data.qty = variant['offerings'][0]['quantity']
				variant_data.status = variant['offerings'][0]['is_enabled']
				variant_data.invisible = not variant['offerings'][0]['is_enabled']
				variant_data.is_in_stock = to_int(variant_data.qty) > 0

				# price variant
				divisor_price = variant['offerings'][0]['price'].get('divisor')
				divisor_before_conversion = variant['offerings'][0]['price'].get('before_conversion', {}).get('divisor')
				variant_data.price = variant['offerings'][0]['price'].get('before_conversion', {}).get('amount') / divisor_before_conversion if \
					variant['offerings'][0]['price'].get('before_conversion') \
					else variant['offerings'][0]['price']['amount'] / divisor_price
				# sku variant
				if variant.sku:
					variant_data.sku = variant.sku
				elif to_len(product.skus) > index:
					variant_data.sku = product.skus[index]
				else:
					variant_data.channel_data.empty_sku = True
					variant_data.sku = variant['product_id']
				if not variant['offerings'][0]['is_enabled']:
					variant_data.is_in_stock = False
					variant_data.channel_data.is_enable = False
				if self._state.channel.config.product_id_to_sku:
					variant_data.sku = variant['product_id']
				# property
				for attribute in variant['property_values']:
					if attribute['property_name'] == 'Title' and attribute['values'][0] == 'Default Title':
						return Response().success(product_data)

					if not index:
						all_attributes[attribute['property_id']] = attribute['property_name']
						all_attributes_by_name[attribute['property_name']] = attribute['property_id']
						all_attributes_by_name1.append({
							'name': attribute['property_name'],
							'property_id': attribute['property_id'],
						})
					variant_attribute = ProductVariantAttribute()
					variant_attribute.id = attribute['property_id']
					variant_attribute.etsy_attribute_id = attribute['property_id']
					variant_attribute.attribute_name = attribute['property_name']
					variant_attribute.attribute_value_name = ', '.join(attribute['values'])
					if attribute['scale_id']:
						variant_attribute.etsy_scale_id = attribute['scale_id']

					variant_data.attributes.append(variant_attribute)
					key_gen = f"p{attribute['property_id']}-v{attribute['value_ids'][0]}"
					if key_gen in variant_etsy_image_ids:
						image_id = variant_etsy_image_ids[key_gen]
						variant_data.thumb_image.url = etsy_images[image_id]
						variant_data.thumb_image.image_id = image_id
				variant_key = self.variant_key_generate(variant_data)
				if not variant_data.attributes or variant_key in variant_exist:
					continue
				variant_exist.append(variant_key)
				product_data.variants.append(variant_data)
			len_attribute = to_len(all_attributes.keys())
			product_data.channel_data.quantity_on_property = inventory.quantity_on_property
			product_data.channel_data.price_on_property = inventory.price_on_property
			product_data.channel_data.sku_on_property = inventory.sku_on_property
			product_data.channel_data.all_attributes1 = all_attributes_by_name1
			if to_len(inventory.quantity_on_property) != len_attribute:
				attribute_manage_quantity = {}
				for attribute_id in inventory.quantity_on_property:
					attribute_manage_quantity[to_str(attribute_id)] = all_attributes[attribute_id]
				product_data.attribute_manage_quantity = attribute_manage_quantity

		return Response().success(product_data)


	def get_product_by_id(self, product_id):
		params = {'includes': "Images,Inventory"}
		if self.is_exclude_inventory():
			params['includes'] = 'Images'
		product = self.api_v3(path = f"/listings/{product_id}", params = params)
		if self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		if product['result'] != "success":
			return Response().error(code = Errors.ETSY_GET_PRODUCT_FAIL)
		product = product['data']
		if product.state == 'removed' or self._last_status == 404:
			return Response().create_response(result = Response.DELETED)
		return Response().success(data = product)


	def to_etsy_weight(self, weight):
		if self._state.channel.config.api.rounding_weight:
			return round(to_decimal(weight))
		return to_decimal(weight, 4)


	def product_to_etsy_data(self, product, insert = False, product_id = None):
		link = []
		if not product.name:
			return Response().error(msg = "Product missing name")

		if product.url:
			link_product = self.process_image_before_import(product.url, product.path)
			link.append({'src': link_product['url']})

		price = product.price or product.min_price or product.max_price
		price = to_decimal(price)
		qty = to_int(product.qty)
		if qty > 999 or not product.manage_stock:
			qty = 999
		if product.variants:
			qty = 0
			for variant in product.variants:
				qty += to_int(variant.qty)
			if qty > 999:
				qty = 999
		template_category = product.get('template_data', {}).get('category', Prodict())
		template_category_id = product.get('templates', {}).get('category', Prodict())
		template_shipping = product.get('template_data', {}).get('shipping', Prodict())
		template_digital = product.get('template_data', Prodict()).get('digital', Prodict())
		product_sku = self.convert_sku(product.sku)
		if template_digital and template_digital.get('digital_status') and product_id:
			payload = {"products": self.to_json_array([
				{
					"property_values": [],
					'sku': "" if product.empty_sku else product_sku,
					"offerings": [{"price": to_decimal(product.price), "quantity": qty, "is_enabled": True}]
				}
			])
			}
			res = self.api_v3(f"/listings/{product_id}/inventory", method = 'put', data = payload)
			if res['result'] != 'success':
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))

		if not template_category or not template_category.get('category', {}).get('id'):
			return Response().error(msg = 'ETSY_CATEGORY_TEMPLATE_NOT_FOUND')
		if not template_digital or not template_digital.get('digital_status'):
			if not template_shipping or not to_int(template_shipping.get('shipping_id')):
				return Response().error(msg = "ETSY_SHIPPING_TEMPLATE_NOT_FOUND")

		data_category_template = template_category.get('about')
		if 'production_partner_ids' in data_category_template and not data_category_template['production_partner_ids']:
			del data_category_template['production_partner_ids']
		when_made = data_category_template.when_made
		if when_made.startswith('2020_20'):
			when_made = f'2020_{get_current_time("%Y")}'
		if when_made.startswith('before_200'):
			when_made = 'before_2004'
		if when_made.startswith('2000_200'):
			when_made = '2000_2003'
		if re.findall("200[0-9]_2009", when_made):
			when_made = '2004_2009'
		data_category_template.when_made = when_made
		data_category_template['is_supply'] = True if to_int(data_category_template['is_supply']) == 1 else False

		taxonomy_id = template_category.get('category').get('id')
		advance_data = template_category.get('advance')
		use_main_tag = False
		if not template_category_id or advance_data.get('use_tags_default'):
			use_main_tag = True

		if use_main_tag:
			main_tags = product.tags
			if template_category_id and advance_data.get('use_tags_default') and product.main_tags:
				main_tags = product.main_tags
			tags = main_tags.split(',') if isinstance(main_tags, str) else main_tags
		else:
			tags = advance_data['tags'].split(',')

		list_tag = []
		for tag in tags:
			tag = re.sub("[^a-zA-Z0-9- '™©®]", '', tag)
			list_tag.append(tag.strip()[:20])
		if advance_data:
			advance = {
				"materials": to_str(advance_data.get('materials', '')).split(',') if advance_data.get('materials') else None,
				"shop_section_id": int(advance_data['section']) if advance_data['section'] else None,
			}
			data_category_template.update(advance)
		data_category_template.update({'taxonomy_id': to_int(taxonomy_id)})
		if not template_digital or not template_digital.get('digital_status'):
			data_category_template.update({'shipping_profile_id': to_int(template_shipping.get('shipping_id'))})
		if to_int(template_shipping.get('policy_id')):
			data_category_template.update({'return_policy_id': to_int(template_shipping.get('policy_id'))})

		title = self.convert_title(product.name)
		if title != product.name:
			self._extend_product_map['name'] = title
		description = product.description or product.short_description or title
		# if to_len(list_tag) > 13:
		# 	return Response().error(msg = "tags_too_many")
		post_data = {
			'title': title[0:140],
			'description': self.replace_description(description),
			'price': price,
			'tags': ','.join(list_tag[0:13]),
			'should_auto_renew': True,
		}
		if template_digital:
			if template_digital.get('digital_status'):
				post_data['type'] = "download"
		else:
			post_data['type'] = "physical"
		if insert:
			post_data['quantity'] = qty
			post_data['state'] = 'active' if not product.invisible else 'draft'
			if self.is_import_draft():
				post_data['state'] = 'draft'
		else:
			if qty:
				post_data['quantity'] = qty
		post_data.update(data_category_template)
		if post_data.get('production_partner_ids'):
			post_data['production_partner_ids'] = list(filter(lambda x: to_int(x) > 0, post_data['production_partner_ids']))
		dimensions = ('length', 'width', 'height')
		dimension_units = product.dimension_units or 'in'
		if dimension_units in ['foot', 'feet']:
			dimension_units = 'ft'
		if dimension_units.lower() in ['inch', 'inches']:
			dimension_units = 'in'
		if dimension_units.lower() in ['yard', 'yards']:
			dimension_units = 'yd'
		need_convert_dimension = False
		if self._state.channel.config.api.dimension_units and self._state.channel.config.api.dimension_units != dimension_units:
			dimension_units = self._state.channel.config.api.dimension_units
			need_convert_dimension = True
		post_data['item_dimensions_unit'] = dimension_units
		dimensions_value = [product.length, product.width, product.height]
		dimensions_value = list(map(lambda x: to_decimal(x, 4), dimensions_value))
		dimensions_value.sort(reverse = True)
		for index, dimension in enumerate(dimensions):
			value = to_decimal(dimensions_value[index])
			if value:
				value = to_decimal(value, 4)
				if need_convert_dimension:
					value = self.convert_dimension_unit(value, product.dimension_units, dimension_units)
				post_data[f'item_{dimension}'] = value

		# update listing
		if product.weight:
			weight_unit = product.weight_units or 'oz'
			if weight_unit == 'lbs':
				weight_unit = 'lb'
			weight = self.to_etsy_weight(product.weight)
			if self._state.channel.config.api.weight_units and self._state.channel.config.api.weight_units != weight_unit:
				weight_unit = self._state.channel.config.api.weight_units
				weight = self.convert_weight_unit(product.weight, product.weight_units, weight_unit)
				weight = self.to_etsy_weight(weight)

			post_data['item_weight_unit'] = weight_unit
			post_data[f'item_weight'] = weight

		# post_data['is_supply'] = True if to_str(post_data['is_supply']) == '1' else False
		template_personalize = product.get('template_data', {}).get('personalization', {})
		if template_personalize and template_personalize.status == "enable":
			post_data['is_personalizable'] = True
			post_data['personalization_is_required'] = template_personalize.is_required
			post_data['personalization_char_count_max'] = template_personalize.char_count_max
			post_data['personalization_instructions'] = template_personalize.instructions
		return Response().success(post_data)


	def product_import(self, convert: Product, product, products_ext):
		post_convert = self.product_to_etsy_data(product, insert = True)
		if post_convert.result != Response.SUCCESS:
			return post_convert
		responses = self.shop_api_v3(path = "listings", method = 'post', data = post_convert.data)
		if responses.result == Response.SUCCESS:
			return Response().success(responses.data.listing_id)

		return responses


	def is_import_draft(self):
		return (self._request_data.get('publish_draft') and self._request_data.get('publish_draft') != 'live') or self._state.channel.config.import_draft or to_int(self.info()['etsy_user_id']) in [452073815, 814118823]


	def extend_data_insert_map_product(self):
		extend = super().extend_data_insert_map_product()
		if isinstance(self._product_new_qty, int):
			extend['qty'] = self._product_new_qty
			self._product_new_qty = None
		if self.is_import_draft():
			extend['state'] = 'etsy_draft'
		return extend


	def attribute_name_to_code(self, attribute_name):
		return to_str(attribute_name).lower().strip(' ')


	def convert_sku(self, sku):
		sku = to_str(sku)
		if not sku:
			return ""
		while not sku[0].isalnum():
			sku = sku[1:]
		if not sku:
			return ''
		sku = sku[0:32]
		while not sku[-1].isalnum():
			sku = sku[:-1]
		return sku


	def convert_title(self, title):
		title = title.lstrip('#@$%^&*()!"').lstrip("'")
		special_chars = ['$', '^', '`']
		title = self.strip_html_from_description(title)
		if title.isupper():
			title = title.title()
		remove_chars = ['%', ':', '&']
		contain_remove_chars = []
		new_title = ''
		for char in title:
			if char in special_chars:
				continue
			if char in remove_chars:
				if char in contain_remove_chars:
					continue
				contain_remove_chars.append(char)
				new_title += char
				continue
			new_title += char
		title = new_title
		titles = title.split(' ')
		index = 0
		response = list()
		for char in titles:
			if char.isupper():
				index += 1
				if index > 3:
					char = char.capitalize()
			response.append(char)

		title = ' '.join(response)
		title = self.title_cutting(title, 140)
		return title


	def get_image_import_limit(self):
		return to_int(self._state.channel.config.api.limit_image) or 10


	def get_custom_image(self, images):
		if not self._state.channel.config.api.custom_image:
			return images
		custom_image = self._state.channel.config.api.custom_image
		if not isinstance(custom_image, list):
			custom_image = [custom_image]
		if to_len(images) >= 10:
			len_image = to_len(images) - to_len(custom_image)
			images = images[0:len_image]
		images.extend(custom_image)
		return images


	def after_product_import(self, product_id, convert: Product, product, products_ext):
		# Update attribute
		taxonomy_support_variants, taxonomy_support_variants_2nd = self.product_update_attributes(product_id, product, insert = True)
		# upload image
		images = list()
		if product.thumb_image.url:
			img = product.thumb_image.url
			if img:
				images.append(img)
		for img_src in product.images:
			if 'status' in img_src and not img_src['status']:
				continue
			img = img_src.url
			if img:
				images.append(img)
		etsy_images = dict()
		main_image_id = None
		limit_image = self.get_image_import_limit()
		images = images[0:limit_image]
		images = self.get_custom_image(images)
		for index, image in enumerate(images):
			image_id = self.upload_image(product_id, image, index)
			if image_id:
				etsy_images[image] = image_id
				if not index:
					main_image_id = image_id
		qty = product.qty
		# TODO: push variants
		template_digital = product.get('template_data', Prodict()).get('digital', Prodict())
		update_variant = self.product_channel_update_variant(product_id, product, taxonomy_support_variants, main_image_id, etsy_images, taxonomy_support_variants_2nd)
		if update_variant.result != Response.SUCCESS:
			return update_variant
		if template_digital and template_digital.get('digital_product'):
			payload = {"products": self.to_json_array([
				{
					"property_values": [],
					'sku': "" if product.empty_sku else product.sku[:32],
					"offerings": [{"price": to_decimal(product.price), "quantity": qty, "is_enabled": True}]
				}
			])
			}
			res = self.api_v3(f"/listings/{product_id}/inventory", method = 'put', data = payload)
			if res['result'] != 'success':
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			for index, value in enumerate(template_digital['digital_product'].values()):
				f = requests.get(value.file_url).content
				files = [
					('file', ('file', f, f'{value.content_type}'))  # Replace with actual file path
				]
				body = {
					"name": value.file_name
				}
				file_res = self.api_v3(f"/shops/{self.get_shop_id()}/listings/{product_id}/files", data = body,
				                       method = 'post', files = files)
				if file_res['result'] != 'success':
					return Response().error(code = Errors.ETSY_FAIL_API, msg = file_res.get('msg'))

		if not self.is_import_draft() and not product.invisible:
			update_product = self.shop_api_v3(f'listings/{product_id}', {'state': 'active'}, method = 'patch')
		else:
			self._extend_product_map['state'] = 'etsy_draft'
		return Response().success(product_id)


	def to_json_array(self, variants):
		return variants


	def exceed_variant(self, options, skip_options = None):
		combinations = list()
		for option_key, values in options.items():
			if skip_options and option_key in skip_options:
				continue
			combinations.append([{option_key: row} for row in values])
		combinations_variants = list(combination(*combinations))
		exceed_variant = False
		combinations_variants_default = combinations_variants[0]
		combinations_variants_default_attributes = list()
		for attribute in combinations_variants_default:
			attribute_data = ProductVariantAttribute()
			attribute_data.attribute_name = list(attribute.keys())[0]
			attribute_data.attribute_value_name = list(attribute.values())[0]
			combinations_variants_default_attributes.append(attribute_data)
		len_attributes = to_len(combinations_variants_default_attributes)
		if len_attributes == 1:
			if to_len(combinations_variants) > 70:
				exceed_variant = True
		if len_attributes == 2:
			for option_key, values in options.items():
				if skip_options and option_key in skip_options:
					continue
				if to_len(values) > 70:
					exceed_variant = True
					break
		is_option_group = False
		option_group1 = []
		option_group2 = []
		if len_attributes == 3:
			option_length = []
			for option_key, values in options.items():
				if skip_options and option_key in skip_options:
					continue
				option_length.append({'name': option_key, 'len': to_len(values)})
			option_length.sort(key = lambda x: x['len'])
			if option_length[1]['len'] * option_length[0]['len'] > 70:
				exceed_variant = True
			else:
				is_option_group = True
				option_group1 = [option_length[0]['name'], option_length[1]['name']]
				option_group2 = [option_length[2]['name']]
		if len_attributes == 4:
			option_length = []
			for option_key, values in options.items():
				if skip_options and option_key in skip_options:
					continue
				option_length.append({'name': option_key, 'len': to_len(values)})
			option_length.sort(key = lambda x: x['len'])
			if (option_length[3]['len'] * option_length[0]['len'] > 70) or (option_length[1]['len'] * option_length[2]['len'] > 70):
				exceed_variant = True
			else:
				is_option_group = True
				option_group1 = [option_length[0]['name'], option_length[3]['name']]
				option_group2 = [option_length[2]['name'], option_length[1]['name']]
		if len_attributes > 4:
			if to_len(combinations_variants) > 70:
				exceed_variant = True
			else:
				is_option_group = True
				option_group1 = list(options.keys())
		return exceed_variant, combinations_variants, is_option_group, option_group1, option_group2


	def get_skip_options(self, options):
		len_options = to_len(list(options.keys()))
		if len_options <= 2:
			return []
		skip_options = []
		for option_name, option_values in options.items():
			if to_len(option_values) == 1:
				skip_options.append(option_name)
		if self._state.channel.config.api.skip_options:
			skip_options.extend(self._state.channel.config.api.skip_options)
		return skip_options


	def etsy_variant_key_generate(self, variant, skip_options = None):

		return self.etsy_variant_key_generate_by_attributes(variant.attributes, skip_options)


	def etsy_variant_key_generate_by_attributes(self, attributes, skip_options = None):
		key_generate = list()
		for attribute in attributes:
			if not attribute.use_variant or (skip_options and attribute.attribute_name in skip_options):
				continue

			key_generate.append({"id": to_str(attribute.attribute_name).lower().strip(), 'value': to_str(attribute.attribute_value_name).lower().strip()})
		key_generate = sorted(key_generate, key = lambda d: d['id'])
		base64_generate = list()
		for row in key_generate:
			base64_generate.append(f"{row['id']}:{row['value']}")
		str_generate = string_to_base64('|'.join(base64_generate))
		return str_generate


	def product_channel_update_variant(self, product_id, product: Product, taxonomy_support_variants, main_image_id, etsy_images, taxonomy_support_variants_2nd, image_in_etsy = False):
		if not product.variants or self._state.channel.config.api.ignore_variant:
			product_sku = self.convert_sku(product.sku)
			qty = product.qty
			if qty > 999:
				qty = 999
			payload = {"products": self.to_json_array([
				{
					# "property_values": [],
					'sku': "" if product.empty_sku else product_sku,
					"offerings": [{"price": to_decimal(product.price), "quantity": qty, "is_enabled": True}]
				}
			])
			}
			res = self.api_v3(f"/listings/{product_id}/inventory", method = 'put', data = payload)
			if res['result'] != 'success':
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			return Response().success(product_id)

		variants = []
		pro_on_property = []
		len_attributes = 0
		options = self.variants_to_option(product.variants)
		skip_options = self.get_skip_options(options)
		all_variants = {self.etsy_variant_key_generate(variant, skip_options): variant for variant in product.variants}

		exceed_variant, combinations_variants, is_option_group, option_group1, option_group2 = self.exceed_variant(options, skip_options)
		all_variant_keys = list()
		variant_max_qty = list()
		variant_update_qty = list()
		new_qty = 0
		all_attributes = product.all_attributes
		all_attributes1 = product.all_attributes1
		if all_attributes1:
			all_attributes = {}
			for row in all_attributes1:
				all_attributes[row['name']] = row['property_id']
		if exceed_variant:
			return Response().error(code = Errors.ETSY_VARIANT_LIMIT)
		etsy_variant_attributes = {}
		for row in combinations_variants:
			attributes = list()
			for attribute in row:
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = list(attribute.keys())[0]
				attribute_data.attribute_value_name = list(attribute.values())[0]
				attributes.append(attribute_data)
			variant_key = self.variant_key_generate_by_attributes(attributes)
			all_variant_keys.append(variant_key)
			variant = all_variants.get(variant_key)
			sku = variant.sku if variant and variant.sku else variant_key
			if 'sku_on_property' in product and not product.sku_on_property:
				sku = self.convert_sku(product.sku)
				if product.get('empty_sku'):
					sku = ''
			if variant and variant.get('empty_sku'):
				sku = ''
			var_qty = variant.qty if variant else 0
			if var_qty > 999:
				variant_max_qty.append(variant_key)
				var_qty = 999
			new_qty += var_qty
			var_price = variant.price if variant else product.variants[0]['price']
			property_id_custom = None
			is_enabled = True
			if variant:
				if 'visible' in variant:
					is_enabled = to_bool(variant.visible)
				if variant.invisible and not product.invisible:
					is_enabled = False
			else:
				is_enabled = False
			if to_decimal(var_price) == 0:
				is_enabled = False
				var_price = 0.2
			if not len_attributes:
				len_attributes = to_len(attributes)
			if is_option_group:
				if not variant and not option_group2:
					continue
				option_1_name = []
				option_1_value = []
				option_2_name = []
				option_2_value = []
				for attribute in attributes:
					if skip_options and attribute.attribute_name in skip_options:
						continue
					if attribute.attribute_name.replace(';', '') in option_group1:
						option_1_value.append(attribute.attribute_value_name.replace(';', ''))
						option_1_name.append(attribute.attribute_name.replace(';', ''))
					else:
						option_2_value.append(attribute.attribute_value_name.replace(';', ''))
						option_2_name.append(attribute.attribute_name.replace(';', ''))

				pro_on_property = [513] if not option_group2 else [513, 514]
				if not option_group2:
					property_values = [{"property_id": 513, "property_name": ",".join(option_1_name), "values": [','.join(option_1_value)]}]
				else:
					property_values = [
						{
							"property_id": 513,
							"property_name": ",".join(option_1_name),
							"values": [','.join(option_1_value)]
						},
						{
							"property_id": 514,
							"property_name": ",".join(option_2_name),
							"values": [','.join(option_2_value)]
						}
					]
				variant_sku = self.convert_sku(sku)
				variants.append({"property_values": property_values, "sku": variant_sku,
				                 "offerings": [{"price": to_decimal(var_price), "quantity": var_qty, "is_enabled": is_enabled}]})
			else:

				property_values_dict = {}
				for attribute in attributes:
					if skip_options and attribute.attribute_name in skip_options:
						continue
					attribute_code = self.attribute_name_to_code(attribute.attribute_name)
					values = attribute.attribute_value_name
					if attribute.etsy_attribute_id:
						property_id = attribute.etsy_attribute_id

					if all_attributes and all_attributes.get(attribute.attribute_name):
						property_id = all_attributes.get(attribute.attribute_name)
					elif taxonomy_support_variants.get(attribute_code) or taxonomy_support_variants_2nd.get(attribute_code):
						property_id = taxonomy_support_variants.get(attribute_code) or taxonomy_support_variants_2nd.get(attribute_code)
					else:
						property_id = 514 if property_id_custom else 513
						property_id_custom = property_id
					if str(property_id) not in pro_on_property:
						pro_on_property.append(str(property_id))
					etsy_variant_attributes[attribute.attribute_name] = property_id
					property_values_dict[property_id] = {"property_id": property_id, "property_name": attribute.attribute_name, "values": [values.replace(';', '')]}
					if attribute.etsy_scale_id:
						property_values_dict[property_id]['scale_id'] = attribute.etsy_scale_id
				sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
				property_values = [sorted_dict[key] for key in sorted_dict]
				variant_sku = self.convert_sku(sku)

				variants.append({"property_values": property_values, "sku": variant_sku,
				                 "offerings": [{"price": to_decimal(var_price), "quantity": var_qty, "is_enabled": is_enabled}]})
		if len(variants) > 0:
			pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), pro_on_property))))
			if product.attribute_manage_quantity:
				pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), list(product.attribute_manage_quantity.keys())))))
			quantity_on_property = pro_on_properties if 'quantity_on_property' not in product else ','.join(list(map(lambda x: to_str(x), product.quantity_on_property)))
			price_on_property = pro_on_properties if 'price_on_property' not in product else ','.join(list(map(lambda x: to_str(x), product.price_on_property)))
			sku_on_property = pro_on_properties if 'sku_on_property' not in product else ','.join(list(map(lambda x: to_str(x), product.sku_on_property)))
			if 'quantity_on_property' not in product and product.tracking_inventory == 'product':
				quantity_on_property = ''
			source_sort = quantity_on_property or price_on_property or sku_on_property
			source_sort_array = list(map(lambda x: to_int(x), source_sort.split(',')))
			for variant in variants:
				property_values = variant['property_values']
				try:
					property_values.sort(key = lambda x: source_sort_array.index(to_int(x['property_id'])))
					variant['property_values'] = property_values
				except Exception:
					self.log_traceback()
			payload = {
				"products": self.to_json_array(variants),
				"quantity_on_property": quantity_on_property,
				"price_on_property": price_on_property,
				"sku_on_property": sku_on_property
			}
			res = self.api_v3(f"/listings/{product_id}/inventory", method = 'put', data = payload)
			if res['result'] != 'success':
				if res.get('msg') and "cannot be more than 70 items" in res.get('msg'):
					return Response().error(code = Errors.ETSY_VARIANT_LIMIT)

				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			variant_images = list()
			variant_options = {}
			channel_data = product['channel'][f'channel_{self.get_channel_id()}']

			for index, variant_res in enumerate(res['data'].get('products')):
				variant_key = self.get_variant_key_gen(variant_res, all_variants)
				if not variant_key:
					variant_key = all_variant_keys[index]
				if not all_variants.get(variant_key):
					continue
				child = all_variants.get(variant_key)
				if variant_key in variant_max_qty:
					variant_update_qty.append(child['_id'])
				if not child['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
					self.insert_map_product(child, child['_id'], variant_res.get('product_id'))
				else:
					self.update_map_product(child, child['_id'], variant_res.get('product_id'))
				if not image_in_etsy:
					if len_attributes and len_attributes != 2:
						child_image = child.thumb_image.url
						if child_image and etsy_images.get(child.thumb_image.url):
							child_image_id = etsy_images.get(child.thumb_image.url)
						else:
							child_image_id = main_image_id
						if not child_image_id:
							continue
						property = variant_res.property_values[0]
						variant_images.append({
							'property_id': property.property_id,
							'value_id': property.value_ids[0],
							'image_id': child_image_id,
						})
					elif channel_data.get('etsy_variant_images'):
						for property in variant_res.property_values:
							if not variant_options.get(property.property_name):
								variant_options[property.property_name] = {}
							value = string_to_base64(property['values'][0])
							if variant_options[property.property_name].get(value):
								continue
							variant_options[property.property_name][value] = property.value_ids[0]
			if not image_in_etsy and not variant_images and channel_data.get('etsy_variant_images') and variant_options:
				attribute = channel_data['etsy_variant_images']['attribute']
				option_images = channel_data['etsy_variant_images']['options']
				variant_option_image = variant_options.get(attribute)
				attribute_id = etsy_variant_attributes.get(attribute)
				if variant_option_image and attribute_id:
					for option in option_images:
						value_id = variant_option_image.get(string_to_base64(option['name']))
						if not value_id:
							continue
						child_image = option.image
						if child_image and etsy_images.get(child_image):
							child_image_id = etsy_images.get(child_image)
							variant_images.append({
								'property_id': attribute_id,
								'value_id': value_id,
								'image_id': child_image_id,
							})
			if variant_images:
				listing_variant_images = {
					'listing_id': to_int(product_id),
					'variation_images': variant_images
				}
				upload = self.shop_api_v3(f'listings/{product_id}/variation-images', data = listing_variant_images, method = 'post')
			if variant_update_qty:
				self.get_model_catalog().update_many(self.get_model_catalog().create_where_condition('_id', variant_update_qty, 'in'), {f'channel.channel_{self.get_channel_id()}.qty': 999})
				self._product_new_qty = to_int(new_qty)
		return Response().success()


	def get_variant_key_gen(self, variant_res, all_variants):
		variant_key = ''
		try:
			if to_len(variant_res['property_values'][0]) == 1:
				variant_key_gen = ''
				attribute_default = variant_res['property_values'][0]
				if to_len(attribute_default['property_name'].split(',')) > 1 and to_len(attribute_default['property_name'].split(',')) == to_len(attribute_default['values'][0].split(',')):
					attribute_names = attribute_default['property_name'].split(',')
					attribute_values = attribute_default['values'][0].split(',')
					variant_attributes = []
					for index, name in enumerate(attribute_names):
						variant_attribute = ProductVariantAttribute()
						variant_attribute.attribute_name = to_str(name).strip()
						variant_attribute.attribute_value_name = to_str(attribute_values[index]).strip()

						variant_attributes.append(variant_attribute)
					variant_key_gen = self.variant_key_generate_by_attributes(variant_attributes)
					if all_variants.get(variant_key_gen):
						variant_key = variant_key_gen
			if not variant_key:
				variant_attributes = []
				variant_attributes2 = []
				for attribute in variant_res['property_values']:
					variant_attribute = ProductVariantAttribute()
					variant_attribute.id = attribute['property_id']
					variant_attribute.etsy_attribute_id = attribute['property_id']
					variant_attribute.attribute_name = attribute['property_name']
					variant_attribute.attribute_value_name = ', '.join(attribute['values'])

					variant_attributes2.append(variant_attribute)
					if to_len(attribute['property_name'].split(',')) > 1 and to_len(attribute['property_name'].split(',')) == to_len(attribute['values'][0].split(',')):
						attribute_names = attribute['property_name'].split(',')
						attribute_values = attribute['values'][0].split(',')
						for index, name in enumerate(attribute_names):
							variant_attribute = ProductVariantAttribute()
							variant_attribute.attribute_name = to_str(name).strip()
							variant_attribute.attribute_value_name = to_str(attribute_values[index]).strip()

							variant_attributes.append(variant_attribute)
					else:
						variant_attribute = ProductVariantAttribute()
						variant_attribute.id = attribute['property_id']
						variant_attribute.etsy_attribute_id = attribute['property_id']
						variant_attribute.attribute_name = attribute['property_name']
						variant_attribute.attribute_value_name = ', '.join(attribute['values'])

						variant_attributes.append(variant_attribute)
				variant_key_gen = self.variant_key_generate_by_attributes(variant_attributes)
				variant_key_gen2 = self.variant_key_generate_by_attributes(variant_attributes2)
				if all_variants.get(variant_key_gen):
					variant_key = variant_key_gen
				if all_variants.get(variant_key_gen2):
					variant_key = variant_key_gen2
		except:
			self.log_traceback()
		return variant_key


	def get_taxonomy_response(self, taxonomy_id):
		taxonomy_id = to_str(taxonomy_id)
		if self._taxonomy_response.get(taxonomy_id):
			return self._taxonomy_response[taxonomy_id]
		taxonomy_response = self.api_v3(path = f"seller-taxonomy/nodes/{taxonomy_id}/properties")
		if taxonomy_response.data:
			self._taxonomy_response[taxonomy_id] = taxonomy_response['data']['results']
		return self._taxonomy_response.get(taxonomy_id)


	def product_update_attributes(self, product_id, product: Product, insert = False):
		template_category = product.get('template_data', {}).get('category', {})
		taxonomy_id = template_category.get('category').get('id')
		taxonomy_response = self.get_taxonomy_response(taxonomy_id)
		taxonomy_attributes = dict()
		taxonomy_support_variants = dict()
		taxonomy_support_variants_2nd = dict()
		possible_values = dict()
		possible_values_ids = dict()
		etsy_attributes = dict()
		for attribute in taxonomy_response:
			taxonomy_attributes[attribute['name'].lower()] = attribute['property_id']
			possible_values[attribute['name'].lower()] = attribute.get('possible_values')
			if attribute.get('possible_values'):
				possible_values_ids[to_int(attribute['property_id'])] = {to_int(row['value_id']): to_str(row['name']) for row in attribute.get('possible_values')}
			if attribute['supports_variations'] and to_int(attribute['property_id']) <= 514:
				taxonomy_support_variants[attribute['name'].lower()] = attribute['property_id']
				taxonomy_support_variants_2nd[attribute['display_name'].lower()] = attribute['property_id']
		if not insert:
			properties = self.shop_api_v3(path = f"/listings/{product_id}/properties")
			if properties.result == Response.SUCCESS:
				for att in properties.data.results:
					etsy_attributes[to_str(att['property_id'])] = att['value_ids'][0] if possible_values_ids.get(to_int(att['property_id'])) else att['values'][0]

		advance_data = template_category.get('advance')
		attributes = advance_data.get('attributes', [])
		product_attribute_ids = list()

		for attribute in attributes:
			if not attribute['attribute_id']:
				continue
			if etsy_attributes.get(to_str(attribute['attribute_id'])):
				if not attribute['attribute_value'] or (is_decimal(attribute['attribute_value']) and not to_decimal(attribute['attribute_value'])):
					self.shop_api_v3(path = f"listings/{product_id}/properties/{attribute['attribute_id']}", method = 'delete')
					continue
				if to_str(etsy_attributes.get(to_str(attribute['attribute_id']))) == to_str(attribute.attribute_value):
					continue
			if not attribute['attribute_value'] or (is_decimal(attribute['attribute_value']) and not to_decimal(attribute['attribute_value'])):
				continue
			if possible_values_ids.get(to_int(attribute['attribute_id']), {}):
				attribute_data = {
					'value_ids': to_str(attribute.attribute_value).split(','),
					'values': ""
				}
			else:
				attribute_data = {
					'value_ids': "",
					'values': attribute.attribute_value
				}
			if attribute.scale_id:
				attribute_data['scale_id'] = attribute.scale_id
			attribute_update = self.shop_api_v3(path = f"listings/{product_id}/properties/{attribute['attribute_id']}", data = attribute_data, method = 'put')
			product_attribute_ids.append(attribute['attribute_id'])
		if product.attributes:
			for attribute in product.attributes:
				attribute_code = self.attribute_name_to_code(attribute.attribute_name)
				if not taxonomy_attributes.get(attribute_code) or not possible_values.get(attribute_code):
					continue
				attribute_id = taxonomy_attributes[attribute_code]
				attribute_possible_values = {to_str(row['name']).lower(): row['value_id'] for row in possible_values[attribute_code]}
				values = to_str(attribute.attribute_value_name).split(',')
				value_ids = list()
				values_update = list()
				for value in values:
					if attribute_possible_values.get(to_str(value).lower()):
						value_ids.append(to_str(attribute_possible_values.get(to_str(value).lower())))
						values_update.append(value)
				if not value_ids:
					continue
				attribute_data = {'value_ids': ','.join(value_ids), "values": ','.join(values_update)}

				attribute_update = self.shop_api_v3(path = f"listings/{product_id}/properties/{attribute_id}", data = attribute_data, method = 'put')
		return taxonomy_support_variants, taxonomy_support_variants_2nd


	def upload_image(self, product_id, image, rank):
		payload = {
			'listing_id': product_id,
			'overwite': 'true',
			'rank': rank + 1
		}
		try:
			# upload_image = False
			image_resize = self.get_image(image)
			image_resize = self.convert_image_background(image_resize)
			if image_resize:
				files = [
					('image', image_resize)
				]

				upload_image = self.shop_api_v3(f"/listings/{product_id}/images", method = 'post', data = payload, files = files)
				if upload_image.result == Response.SUCCESS and upload_image.data:
					return upload_image.data.listing_image_id
		except Exception:
			self.log_traceback('images')
		return False


	def product_channel_update(self, product_id, product: Product, products_ext):
		post_convert = self.product_to_etsy_data(product, False, product_id)
		if post_convert.result != Response.SUCCESS:
			return post_convert
		data_update = post_convert.data
		res = self.shop_api_v3(f"/listings/{product_id}", method = 'patch', data = data_update)
		# updateInventory to update quantity, price
		taxonomy_support_variants, taxonomy_support_variants_2nd = self.product_update_attributes(product_id, product)
		# TODO: push variants

		images = list()
		if product.thumb_image.url:
			img = product.thumb_image.url
			if img:
				images.append(img)
		all_images = product.all_images or product.images
		for img_src in all_images:
			if 'status' in img_src and not img_src['status']:
				continue
			img = img_src.url
			if img and img not in images:
				images.append(img)
		main_image_id = None
		etsy_images = dict()
		limit_image = self.get_image_import_limit()
		images = images[0:limit_image]
		image_in_etsy = False
		images = self.get_custom_image(images)
		for image in images:
			if to_str(image).find('i.etsystatic.com') != -1:
				image_in_etsy = True
		if not image_in_etsy:
			image_need_delete = False

			product_images_request = self.api_v3(f'/listings/{product_id}/images')
			product_images = list()
			if product_images_request.result == Response.SUCCESS:
				product_images = product_images_request.data.results
				for index, row in enumerate(product_images):
					if not index:
						image_need_delete = row['listing_image_id']
					else:
						delete = self.shop_api_v3(path = f"/listings/{product_id}/images/{row['listing_image_id']}", method = 'delete')
			for index, image in enumerate(images):
				# if product_images and to_len(product_images) > index:
				# 	delete = self.shop_api_v3(path = f"/listings/{product_id}/images/{product_images[index]['listing_image_id']}", method = 'delete')
				image_id = self.upload_image(product_id, image, index)
				if image_id:
					etsy_images[image] = image_id
					if not index:
						main_image_id = image_id
			if image_need_delete:
				delete = self.shop_api_v3(path = f"/listings/{product_id}/images/{image_need_delete}", method = 'delete')

		# if product_images and to_len(product_images) > to_len(images):
		# 	for image in product_images[to_len(images):]:
		# 		delete = self.shop_api_v3(method = 'delete', path = f"/listings/{product_id}/images/{image['listing_image_id']}")
		template_digital = product.get('template_data', Prodict()).get('digital', Prodict())
		if not template_digital or not template_digital.get('digital_status'):
			update_variant = self.product_channel_update_variant(product_id, product, taxonomy_support_variants, main_image_id, etsy_images, taxonomy_support_variants_2nd, image_in_etsy = image_in_etsy)
			if update_variant.result != Response.SUCCESS:
				return update_variant
		else:
			if template_digital and template_digital.digital_product:
				for index, value in enumerate(template_digital.digital_product.values()):
					num_index = index
					f = requests.get(value.file_url).content
					files = [
						('file', ('file', f, f'{value.content_type}'))  # Replace with actual file path
					]
					body = {
						"name": value.file_name
					}
					file_res = self.api_v3(f"/shops/{self.get_shop_id()}/listings/{product_id}/files", data = body,
					                       method = 'post', files = files)
					if 'is already attached to this listing' in file_res.get('msg'):
						file_id = re.findall("File (.*) is already attached to this listing.", file_res.get('msg'))
						file_id = to_int(file_id[0])
						for index, key in enumerate(template_digital.digital_product.keys()):
							if index == num_index:
								self.get_model_catalog().update_field(product['_id'],
								                                      f'channel.channel_{self.get_channel_id()}.template_data.digital.digital_product.{key}.file_uploaded_id',
								                                      file_id)
					elif file_res['result'] == 'success':
						for index, key in enumerate(template_digital.digital_product.keys()):
							if index == num_index:
								self.get_model_catalog().update_field(product['_id'],
								                                      f'channel.channel_{self.get_channel_id()}.template_data.digital.digital_product.{key}.file_uploaded_id',
								                                      file_res.data.listing_file_id)
					else:
						return Response().error(code = Errors.ETSY_FAIL_API, msg = file_res.get('msg'))
		if res['result'] != "success":
			return Response().error(msg = res.get('msg'))
		return Response().success(product.id)


	def delete_product_import(self, product_id):
		self.api_v3(f"/listings/{product_id}", method = 'delete')
		return Response().success()


	def convert_variants(self, products):
		properties = {}
		for property in products[0]['property_values']:
			properties[property['property_name']] = set()
		list_key_properties = []
		for product in products:
			set_values = set()
			for property in properties.keys():
				values = self.choice_values(property, product['property_values'])
				properties[property].add(values[0])
				set_values.add(values[0])
			list_key_properties.append(set_values)
		t = 1
		for property in properties:
			t *= len(properties[property])
		if len(products) == t:
			return products
		key_properties = list(properties.keys())
		# Products can have a maximum of two property values
		if len(properties) == 1:
			list_properties = properties[key_properties[0]]
		else:  # len(properties) == 2:
			list_properties = list(itertools.product(properties[key_properties[0]], properties[key_properties[1]]))
		results = products
		for key_properties in list_properties:
			if set(key_properties) not in list_key_properties:
				tmp = deepcopy(products[0])
				for i in range(len(tmp['property_values'])):
					tmp['property_values'][i]['values'] = [key_properties[i]]
				tmp['sku'] = 'sku_etsy'
				results.append(tmp)
		return results


	def choice_values(self, property_name, property_values):
		for property_value in property_values:
			if property_name in property_value['property_name']:
				return property_value['values']


	# # TODO: Order

	def get_orders_main_export(self):
		shop_id = self._state.channel.config.api.name
		try:
			imported = self._state.pull.process.orders.imported
			limit_data = self._state.pull.setting.orders
			created_channel = self.get_order_start_time(False)
			last_modifier = self._state.pull.process.orders.max_last_modified
			params = {'limit': limit_data, 'min_created': created_channel, 'offset': imported, 'includes': 'Listings,Transactions,Buyer,GuestBuyer'}
			if last_modifier:
				params['min_last_modified'] = last_modifier
			orders_data = self.shop_api_v3(path = f"receipts", params = params)
		except Exception as e:
			self.log_traceback()
			return Response().finish(Errors.EXCEPTION, msg = e)
		return Response().success(data = orders_data['data']['results'])


	def get_order_by_id(self, order_id):
		order = self.shop_api_v3(path = f"receipts/{order_id}")
		if self._last_status == 200:
			return Response().success(order['data'])
		return Response().success()


	def get_orders_ext_export(self, orders):
		# user_ids = list()
		# countries = list()
		# for order in orders:
		# 	user_ids.append(order.buyer_user_id)
		# 	countries.append(order.country_id)
		# users = dict()
		# countries_data = dict()
		# for user_id in user_ids:
		# 	user_info = self.api_v3(path = f'users/{user_id}', params = {'includes': 'Profile'})
		# 	if user_info.result == 'success':
		# 		users[to_str(user_id)] = user_info.data
		# for country in countries:
		# 	country_info = self.api_v2(path = f'countries/{country}', auth = self.auth())
		# 	if country_info.result == 'success':
		# 		countries_data[to_str(country)] = country_info.data.results[0]
		return Response().success()


	def finish_order_export(self):
		if self._order_max_last_modified:
			self._state.pull.process.orders.max_last_modified = self._order_max_last_modified


	def convert_order_export(self, order, orders_ext, channel_id = None):
		self.set_order_max_last_modifier(order.updated_timestamp)
		# buyer_info = orders_ext['users'].get(to_str(order.buyer_user_id))
		# country_info = orders_ext['countries'][to_str(order.country_id)]
		order_data = Order()
		order_id = order['receipt_id']
		order_data.id = order_id
		order_data.order_number = order_id

		if not order.is_paid:
			order_status = 'unpaid'
			return Response().skip()
		order_status = order.status
		if not order_status:
			if not order.is_shipped:
				order_status = 'processing'
			else:
				order_status = 'completed'
		order_data.status = self.ORDER_STATUS.get(to_str(order_status).lower(), 'open')
		order_data.currency = order.total_price.currency_code
		order_data.created_at = self.convert_format_time(order.created_timestamp)
		order_data.updated_at = self.convert_format_time(order.updated_timestamp)
		order_data.channel_data = {
			'order_status': order_status,
			'created_at': order_data.created_at,
			'shipped_date': convert_format_time(order.shipments[0].shipment_notification_timestamp) if order.shipments and order.shipments[0].shipment_notification_timestamp else ''
		}
		if order.shipments:
			shipments = order.shipments[0]
			order_data.shipments.tracking_company = shipments.carrier_name
			order_data.shipments.tracking_company_code = shipments.carrier_name
			order_data.shipments.tracking_number = shipments.tracking_code
		first_name = ''
		last_name = ''
		if order.name:
			first_name, last_name = self.split_customer_fullname(order.name)

		customer_first_name = first_name
		customer_last_name = last_name
		# if buyer_info:
		# 	if buyer_info.first_name:
		# 		customer_first_name = buyer_info.first_name
		# 	if not customer_first_name and buyer_info.login_name:
		# 		customer_first_name = buyer_info.login_name
		# 	if buyer_info.last_name:
		# 		customer_last_name = buyer_info.last_name
		# 	if not customer_last_name and buyer_info.login_name:
		# 		customer_last_name = buyer_info.login_name
		# order_data.customer.id = order.buyer_user_id
		# if buyer_info:
		# 	order_data.customer.username = buyer_info.login_name
		order_city = order.city
		city = order.city
		postcode = ''
		city_exp = to_str(order_city).split('zip code')
		if to_len(city_exp) == 2:
			city = to_str(city_exp[0]).strip()
			postcode = to_str(city_exp[1]).strip()
		order_data.customer.first_name = customer_first_name
		order_data.customer.last_name = customer_last_name
		order_data.customer.email = order.buyer_email
		# order_data.customer_address = dict()
		order_data.customer_address.first_name = customer_first_name
		order_data.customer_address.last_name = customer_last_name
		order_data.customer_address.country.country_code = order.country_iso
		order_data.customer_address.country.country_name = self.get_country_name_by_code(order.country_iso)
		order_data.customer_address.state.state_code = order.state
		order_data.customer_address.address_1 = order.first_line
		order_data.customer_address.address_2 = order.second_line
		order_data.customer_address.city = city
		order_data.customer_address.postcode = order.zip or postcode
		# order_data.billing_address = dict()
		order_data.billing_address.first_name = customer_first_name
		order_data.billing_address.last_name = customer_last_name
		order_data.billing_address.country.country_code = order.country_iso
		order_data.billing_address.country.country_name = self.get_country_name_by_code(order.country_iso)
		order_data.billing_address.state.state_code = order.state
		order_data.billing_address.address_1 = order.first_line
		order_data.billing_address.address_2 = order.second_line
		order_data.billing_address.city = city
		order_data.billing_address.postcode = order.zip or postcode
		# order_data.shipping_address = dict()
		order_data.shipping_address.first_name = first_name or customer_first_name
		order_data.shipping_address.last_name = last_name or customer_last_name
		order_data.shipping_address.country.country_code = order.country_iso
		order_data.shipping_address.country.country_name = self.get_country_name_by_code(order.country_iso)
		order_data.shipping_address.state.state_code = order.state

		order_data.shipping_address.address_1 = order.first_line
		order_data.shipping_address.address_2 = order.second_line
		order_data.shipping_address.city = city
		order_data.shipping_address.postcode = order.zip or postcode
		# order_data.payment = dict()
		order_data.payment.method = self.get_order_payment_method(order.payment_method)
		# order_data.payment = self.etsy_oauth().findShopPaymentByReceipt(shop_id = shop_id, receipt_id = order_id)
		# order_data.items = list()
		customer_notes = ['message_from_buyer', 'gift_message', 'message_from_payment', 'message_from_seller']
		for row in customer_notes:
			if order.get(row):
				if row == 'message_from_seller':
					history = OrderHistoryStaff()
				else:
					history = OrderHistory()
				history.comment = order[row]
				order_data.history.append(history)

		# listings = {listing["listing_id"]: listing for listing in order.Listings}
		for item in order.transactions:
			if not order_data.shipping.method:
				order_data.shipping.method = item.shipping_method or item.shipping_upgrade
			# listing = listings[item['listing_id']]
			# product = self.get_product_by_id(item.listing_id)

			order_item = OrderProducts()
			options = dict()
			has_variant = False
			# option_data = OrderItemOption()
			# option_data.option_id = option.property_id
			# option_data.option_name = option.property_name
			# option_data.option_value_name = option['values'][0]
			# order_item.options.append(option_data)
			if item.product_data:
				for option in item.product_data:
					if not options.get(option.property_id) and option.property_name != 'Custom Property':

						options[option.property_id] = {
							"name": html_unescape(option.property_name),
							"value": html_unescape(to_str(option['values'][0])).strip(' ')
						}
			if item.variations:
				for option in item.variations:
					if not to_str(option.formatted_name).lower().startswith('personali'):
						has_variant = True
					if not options.get(option.property_id):

						options[option.property_id] = {
							"name": html_unescape(option.formatted_name),
							"value": html_unescape(option.formatted_value)
						}
			if has_variant:
				product_id = item.product_id
				order_item.is_variant = True
			else:
				product_id = item.listing_id
			order_item.product_id = product_id
			order_item.listing_id = item.listing_id
			order_item.price = self.to_price(item.price)
			order_item.total = to_decimal(to_decimal(item.price) * to_decimal(item.quantity), 2)
			order_item.qty = item.quantity
			order_item.product_sku = item.sku
			order_item.product_name = item.title


			for option_id, option in options.items():
				option_data = OrderItemOption()
				option_data.option_id = option_id
				option_data.option_name = option['name']
				option_data.option_value_name = option['value']
				order_item.options.append(option_data)
			order_data.products.append(order_item)
		order_data.subtotal = self.to_price(order.total_price)
		order_data.total = self.to_price(order.grandtotal)
		if order.gift_wrap_price and order.gift_wrap_price.amount:
			order_data.gift_wrap_price = self.to_price(order.gift_wrap_price)
		order_data.discount.amount = self.to_price(order.discount_amt)
		order_data.shipping.amount = self.to_price(order.total_shipping_cost)
		order_data.tax.amount = self.to_price(order.total_tax_cost) + self.to_price(order.total_vat_cost)
		if not order_data.shipping.method:
			order_data.shipping.method = self._state.channel.config.api.shipping_method_default or ''
		if not order_data.tax.amount and to_decimal(self._state.channel.config.api.order_tax_percent):
			order_data.tax.amount = to_decimal(order_data.total * (1 - 1 / (1 + to_decimal(self._state.channel.config.api.order_tax_percent)/100)), 2)
			order_data.tax.included = True
			order_data.tax.title = f'VAT'
		# order_data.currency = order.currency_code
		# if order_data.tax.amount and self.is_import_order_without_tax():
		# 	order_data.total = to_decimal(to_decimal(order_data.total) - to_decimal(order_data.tax.amount), 2)
		# 	order_data.tax.amount = 0
		# if order.refunds:
		# 	refund = order.refunds
		# 	if isinstance(order.refunds, list):
		# 		refund = order.refunds[0]
		# 	if refund.amount:
		# 		if refund.reason == 'Cancellation requested':
		# 			order_data.status = Order.CANCELED
		# 			order_data.channel_data.order_status = Order.CANCELED
		# 		else:
		# 			amount_refund = self.to_price(refund.amount)
		# 			if amount_refund >= order_data.total:
		# 				order_data.status = 'refunded'
		# 				order_data.channel_data.order_status = 'refunded'
		return Response().success(order_data)


	def get_order_payment_method(self, payment_raw):
		payment_mapping = {
			'cc': 'credit card',
			'mo': 'money order',
			'bt': 'bank transfer',
			'k_pay_in_4': 'klarna',
			'k_pay_in_3': 'klarna',
			'k_financing': 'klarna'
		}
		payment_str = to_str(payment_raw)

		return payment_mapping.get(payment_str, payment_str)

	def get_order_id_import(self, convert: Order, order, orders_ext):
		return order.receipt_id


	def channel_order_completed(self, order_id, order: Order, current_order):
		try:
			channel_default = self.get_channel_default()
			submit_tracking = {
				'tracking_code': order.shipments.tracking_number or '',
				'carrier_name': order.shipments.tracking_company_code,
				'send_bcc': False
			}
			self.shop_api_v3(f'receipts/{order_id}/tracking', data = submit_tracking, method = 'post', log_file = 'tracking')
			order_id = order_id if order_id else order.order_number
			res = self.shop_api_v3(path = f"/receipts/{order_id}", data = {"was_shipped": True}, method = 'put')
			if res['result'] != 'success':
				if res.get('code') in [1303, 1305]:
					return Response().error(Errors.ETSY_FAIL_API, msg = res.get('msg'))
				elif res.get('code') == 2201:
					return Response().error(Errors.EXCEPTION, msg = res.get('msg'))
			return_order = {"status": 'Completed'}
		except:
			log_traceback()
			return Response().error(Errors.EXCEPTION)

		return Response().success(return_order)


	def resize_image(self, url):
		try:
			r = requests.get(url)
			if r.status_code != 200:
				return
			img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
			new_width = 570
			new_height = 450
			img = img.resize((new_width, new_height), Image.ANTIALIAS)
			if img.mode != 'RGB':
				img = img.convert('RGB')
			imgByteArr = io.BytesIO()
			img.save(imgByteArr, format = 'PNG')
			imgByteArr = imgByteArr.getvalue()
			return imgByteArr
		except Exception as e:
			self.log(e, 'resize_image')



	def convert_image_background(self, image_raw):
		"""convert images background, just PNG type
		"""
		try:
			image = Image.open(io.BytesIO(image_raw))
			if image.mode != 'RGBA' and image.format != 'PNG' and image.format != 'WEBP':
				return image_raw
			if image.mode != 'RGBA':
				image = image.convert('RGBA')
			color_background = 'WHITE'

			convert_image = Image.new("RGBA", image.size, color_background)
			convert_image.paste(image, (0, 0), image)

			convert_image_raw = io.BytesIO()

			convert_image.save(convert_image_raw, format = 'PNG')
			convert_image_raw = convert_image_raw.getvalue()

		except Exception as e:
			self.log_traceback('convert_image_background', to_str(e))
			convert_image_raw = image_raw

		return convert_image_raw

	def get_image(self, url):
		# new_url = to_str(url).replace("i0.wp.com/", "")
		# if python_validators.url(new_url):
		# 	url = new_url
		try:
			r = False
			retry = 0
			while r is False and retry < 5:
				try:
					r = requests.get(url, headers = {"User-Agent": get_random_useragent()}, timeout = 60, verify = False)
					image = Image.open(io.BytesIO(r.content))
				except Exception as e:
					time.sleep(2)
					retry += 1
					r = False
					if retry == 1:
						self.log_traceback('image_resize')
			if not r or r.status_code != 200:
				self.log(r.status_code, 'image_resize')
				return False
			content_type = self.image_content_type_to_mime_type(r.headers.get('content-type'))
			if content_type == 'webp':
				img = Image.open(io.BytesIO(r.content))  # image extension *.png,*.jpg
				imgByteArr = io.BytesIO()
				format_save = 'PNG' if img.mode == 'RGBA' else 'JPEG'
				img.save(imgByteArr, format = format_save)
				imgByteArr = imgByteArr.getvalue()
				return imgByteArr
			return r.content


		except Exception as e:
			self.log_traceback('images', f"image error: {url}")

			return False


	def check_response_import(self, response, convert, entity_type = ''):
		id = convert.id if convert.id else convert.code
		if not response:
			return Response().error(msg = 'no respone check_response_import')
		elif response and hasattr(response, 'errors') and response.errors:
			console = list()
			if isinstance(response.errors, list):
				for error in response.errors:
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(error_messages)
			if isinstance(response.errors, dict) or isinstance(response.errors, Prodict):
				for key, error in response['errors'].items():
					if isinstance(error, list):
						error_messages = ' '.join(error)
					else:
						error_messages = error
					console.append(key + ': ' + error_messages)
			else:
				console.append(response['errors'])
			msg_errors = '::'.join(console)
			self.log(entity_type + ' id ' + to_str(id) + ' import failed. Error: ' + msg_errors,
			         "{}_errors".format(entity_type))
			return Response().error(msg = msg_errors)

		else:
			return Response().success(response)


	def convert_child_to_option(self, childrens):
		max_attribute = 0
		option_src = list()
		for children in childrens:
			if max_attribute <= to_len(children['attributes']):
				max_attribute = to_len(children['attributes'])
				option_src = children['attributes']
		all_option_name = list()
		for option in option_src:
			if option['attribute_name'] in all_option_name:
				continue
			all_option_name.append(option['attribute_name'])
		options = dict()
		languages = dict()
		for children in childrens:
			for attribute in children['attributes']:
				if attribute['attribute_name'] not in all_option_name:
					continue
				if attribute['attribute_name'] not in options:
					options[attribute['attribute_name']] = dict()
				if not attribute['attribute_value_name'] or attribute['attribute_value_name'] in options[
					attribute['attribute_name']]:
					continue
				option_data = ProductVariant()
				option_data['attribute_code'] = attribute['attribute_code']
				option_data['attribute_value_name'] = attribute['attribute_value_name']
				option_data['attribute_value_code'] = attribute['attribute_value_code']
				option_data['attribute_value_languages'] = attribute['attribute_value_languages']
				option_data['attribute_value_price'] = attribute['price'] if attribute['price'] and to_int(
					attribute['price']) > 0 else (
					children['price'] if to_len(children['attributes']) < 2 and to_int(children['price']) > 0 else 0)
				option_data['price_prefix'] = attribute['price_prefix']
				languages[attribute['option_name']] = attribute['option_languages']
				options[attribute['option_name']][attribute['option_value_name']] = option_data
		all_options = list()
		for option_name, option in options.items():
			option_data = ProductVariant()
			option_data['id'] = None
			# option_data['code'] = self.convert_attribute_code(option_name)
			option_data['attribute_type'] = 'select'
			option_data['attribute_name'] = option_name
			option_data['attribute_languages'] = languages[option_name] if option_name in languages else ''
			for option_value_name, option_value in option.items():
				if option_value['attribute_code'] and option_value['attribute_code'] != '':
					option_data['code'] = option_value['attribute_code']
					option_data['attribute_code'] = option_value['attribute_code']
				option_data['values'].append(option_value)
			all_options.append(option_data)
		return all_options


	def random_sku(self, length = 16):
		chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
		return "".join(random.choice(chars) for _ in six.moves.xrange(length))


	def get_client_id(self, user_id = None):
		client_id = self._state.channel.config.api.consumer_key
		if not client_id:
			return get_config_ini('etsy', 'oauth_consumer_key')
		return client_id


	def get_client_secret(self, user_id = None):
		client_id = self._state.channel.config.api.consumer_secret
		if not client_id:
			return get_config_ini('etsy', 'oauth_consumer_secret')
		return client_id


	def replace_description(self, text):
		return self.html_to_text(text)

		if self.get_channel_default().get('type') and self.get_channel_default().get('type') in ['wix']:
			return self.html_to_text(text)

		return self.strip_html_from_description(text)


	def html_to_text(self, markup, preserve_new_lines = True, strip_tags = ['style', 'script', 'code']):
		if bool(BeautifulSoup(unescape(markup), "html.parser").find()):
			markup = markup.replace('\n', '')
		soup = BeautifulSoup(unescape(markup), "html.parser")
		for element in soup(strip_tags): element.extract()
		if preserve_new_lines:
			for element in soup.find_all():
				if element.name not in ['a', 'b', 'button', 'i', 'input', 'label', 'select', 'strong', 'textarea' 'div']:
					element.append('\n') if element.name == 'br' else element.append('\n')
		text = soup.get_text().replace(' ', ' ').strip()
		while text.find('\n \n') != -1:
			text = text.replace('\n \n', '\n')
		while text.find('\n\n\n') != -1:
			text = text.replace('\n\n\n', '\n\n')
		return text.replace('\n ', '\n\t')

	def channel_sync_inventory(self, product_id, product, products_ext):
		if product.channel[f'channel_{self.get_channel_id()}'].get('is_variant'):
			return Response().error()
		setting_price = True if self._state.channel.config.setting.get('price', {}).get('status') != 'disable' else False
		setting_qty = True if self._state.channel.config.setting.get('qty', {}).get('status') != 'disable' else False
		if not setting_price and not setting_qty:
			return Response().success(product)
		if self.is_sync_product_invisible(product):
			update_data = {
				'state': 'inactive'
			}
			res = self.shop_api_v3(f"/listings/{product_id}", method = 'patch', data = update_data)
			if res['result'] == 'success':
				update_product = {
					f"channel.channel_{self.get_channel_id()}.state": 'inactive',
					# f"channel.channel_{self.get_channel_id()}.inactive_during_sync": True,
				}
				self.get_model_catalog().update(product['_id'], update_product)
				return Response().success(product)
			if res['msg'].find('quantity : cannot be empty'):
				update_product = {
					f"channel.channel_{self.get_channel_id()}.state": 'sold_out',
					# f"channel.channel_{self.get_channel_id()}.inactive_during_sync": True,
				}
				self.get_model_catalog().update(product['_id'], update_product)
				return Response().success(product)
			return res
		etsy_product = self.get_product_by_id(product_id)
		if etsy_product.result != Response.SUCCESS:
			return Response().success(product)
		etsy_product_data = etsy_product['data']
		etsy_product_data['syncing'] = True
		etsy_product_ext = self.get_products_ext_export([etsy_product_data])
		etsy_convert = self.convert_product_export(etsy_product_data, etsy_product_ext['data'])
		convert = etsy_convert.data
		product_state = etsy_product_data.state
		if product_state == 'edit':
			product_state = 'inactive'
		status = product_state
		channel_data = convert.channel_data

		if not product.variants:
			qty = product.qty if to_int(product.qty) < 999 else 999
			product.qty = qty
			if setting_qty:
				if not qty:
					state_update = product_state
					if product_state == 'active':
						update_data = {
							'state': 'inactive'
						}
						res = self.shop_api_v3(f"/listings/{product_id}", method = 'patch', data = update_data)
						if res['result'] == 'success':
							state_update = 'inactive'
					update_product = {
						f"channel.channel_{self.get_channel_id()}.state": state_update,
						# f"channel.channel_{self.get_channel_id()}.inactive_during_sync": True,
					}
					self.get_model_catalog().update(product['_id'], update_product)
					return Response().success(product)
				else:
					if etsy_product_data.get('state') != 'active' and product_state != 'draft':
						update_data = {
							'state': 'active',
							'renew': True
						}
						res = self.shop_api_v3(path = f"/listings/{product_id}", method = 'patch', data = update_data)
						if res['result'] == 'success':
							status = 'active'
			update_data = {
				"price": to_decimal(product.price),
				"quantity": qty,
				"is_enabled": True
			}
			if not setting_qty:
				update_data['quantity'] = convert.qty
			if not setting_price:
				update_data['price'] = convert.price
			payload = {
				"products": self.to_json_array([{"property_values": [], "offerings": [update_data], 'sku': '' if (channel_data and channel_data.get('empty_sku') or self.is_sync_delete_sku()) else self.convert_sku(product.sku)}])}
			res = self.api_v3(path = f"/listings/{product_id}/inventory", method = 'put', data = payload)
			if res['result'] != 'success':
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			update_product = {
				f"channel.channel_{self.get_channel_id()}.state": status,
				# f"channel.channel_{self.get_channel_id()}.inactive_during_sync": False,
			}
			self.get_model_catalog().update(product['_id'], update_product)
			return Response().success(product)

		# TODO: push variants

		variants = []
		pro_on_property = []
		etsy_variants = dict()
		etsy_variants_by_keys = dict()
		for variant in convert.variants:
			etsy_variants[to_str(variant['id'])] = variant
			variant_key = self.variant_key_generate(variant)
			etsy_variants_by_keys[variant_key] = variant
		all_attributes = convert.channel_data.all_attributes
		all_attributes1 = convert.channel_data.all_attributes1
		if all_attributes1:
			all_attributes = {}
			for row in all_attributes1:
				all_attributes[row['name']] = row['property_id']
		number_sold_out = 0
		template_shipping = product.channel.get(f"channel_{self.get_channel_id()}").get('template_data', {}).get('shipping', {})

		template_category = product.channel.get(f"channel_{self.get_channel_id()}").get('template_data', {}).get('category', {})
		if not template_category or not template_shipping:
			return Response().error(Errors.TEMPLATE_NOT_FOUND, msg = 'Missing required template. Please add a template for the etsy channel')
		taxonomy_id = template_category.get('category').get('id')
		taxonomy_response = self.get_taxonomy_response(taxonomy_id)
		taxonomy_support_variants = dict()
		taxonomy_support_variants_2nd = dict()
		possible_values = dict()
		for attribute in taxonomy_response:
			if attribute['supports_variations'] and to_int(attribute['property_id']) <= 514:
				taxonomy_support_variants[attribute['name'].lower()] = attribute['property_id']
				taxonomy_support_variants_2nd[attribute['display_name'].lower()] = attribute['property_id']
		variants = []
		pro_on_property = []
		options = self.variants_to_option(product.variants)
		skip_options = self.get_skip_options(options)
		all_variants = {self.etsy_variant_key_generate(variant, skip_options): variant for variant in product.variants}
		scale_id_value = {}
		variant_default = product.variants[0]
		for attribute in variant_default['attributes']:
			if attribute.etsy_scale_id:
				scale_id_value[attribute.etsy_attribute_id] = attribute.etsy_scale_id
		exceed_variant, combinations_variants, is_option_group, option_group1, option_group2 = self.exceed_variant(options, skip_options)
		if exceed_variant:
			return Response().error(code = Errors.ETSY_VARIANT_LIMIT)
		all_variant_keys = list()
		for row in combinations_variants:
			attributes = list()
			for attribute in row:
				attribute_data = ProductVariantAttribute()
				attribute_data.attribute_name = list(attribute.keys())[0]
				attribute_data.attribute_value_name = list(attribute.values())[0]
				attributes.append(attribute_data)
			variant_key = self.variant_key_generate_by_attributes(attributes)
			all_variant_keys.append(variant_key)
			variant = all_variants.get(variant_key)
			etsy_variant = False
			if variant:
				sku = variant.sku or variant_key
				var_qty = variant.qty if to_int(variant.qty) < 999 else 999
				var_price = variant.price
				variant_id = variant.channel[f'channel_{self.get_channel_id()}'].get('product_id')
				if variant_id:
					etsy_variant = etsy_variants.get(variant_id)
				if not etsy_variant:
					etsy_variant = etsy_variants_by_keys.get(variant_key)
			else:
				sku = variant_key
				var_qty = 0
				var_price = product.variants[0]['price']
			is_enabled = True
			if variant:
				if 'visible' in variant:
					is_enabled = to_bool(variant.visible)
				if self.is_sync_product_invisible(variant):
					is_enabled = False
			else:
				is_enabled = False
			if to_decimal(var_price) == 0:
				is_enabled = False
				var_price = 0.2
			offerings = {
				"price": etsy_variant.price if etsy_variant else var_price,
				"quantity": etsy_variant.qty if etsy_variant else var_qty,
				"is_enabled": is_enabled
			}
			if 'sku_on_property' in product and not product.sku_on_property:
				sku = product.sku
				if channel_data.get('empty_sku') or self.is_sync_delete_sku():
					sku = ''
			if etsy_variant:
				variant_channel_data = etsy_variant.channel_data
				if variant_channel_data and variant_channel_data.get('empty_sku'):
					sku = ''

			if setting_qty:
				offerings['quantity'] = var_qty
				if not var_qty > 0:
					number_sold_out += 1
			if setting_price:
				offerings['price'] = var_price
			property_id_custom = None
			if is_option_group:
				if not variant and not option_group2:
					continue
				option_1_name = []
				option_1_value = []
				option_2_name = []
				option_2_value = []
				for attribute in attributes:
					if skip_options and attribute.attribute_name in skip_options:
						continue
					if attribute.attribute_name.replace(';', '') in option_group1:
						option_1_value.append(attribute.attribute_value_name.replace(';', ''))
						option_1_name.append(attribute.attribute_name.replace(';', ''))
					else:
						option_2_value.append(attribute.attribute_value_name.replace(';', ''))
						option_2_name.append(attribute.attribute_name.replace(';', ''))

				pro_on_property = [513] if not option_group2 else [513, 514]
				if not option_group2:
					property_values = [{"property_id": 513, "property_name": ",".join(option_1_name), "values": [','.join(option_1_value)]}]
				else:
					property_values = [
						{
							"property_id": 513,
							"property_name": ",".join(option_1_name),
							"values": [','.join(option_1_value)]
						},
						{
							"property_id": 514,
							"property_name": ",".join(option_2_name),
							"values": [','.join(option_2_value)]
						}
					]

				variants.append({"property_values": property_values, "sku": self.convert_sku(sku),
				                 "offerings": [offerings]})
			else:

				property_values_dict = {}
				for attribute in attributes:
					if skip_options and attribute.attribute_name in skip_options:
						continue
					attribute_code = self.attribute_name_to_code(attribute.attribute_name)
					values = attribute.attribute_value_name
					property_id_check = taxonomy_support_variants.get(attribute_code) or taxonomy_support_variants_2nd.get(attribute_code)
					if attribute.etsy_attribute_id:
						property_id = attribute.etsy_attribute_id
					elif all_attributes and all_attributes.get(attribute.attribute_name):
						property_id = all_attributes.get(attribute.attribute_name)
					elif property_id_check:
						property_id = property_id_check
					else:
						property_id = 514 if property_id_custom else 513
						property_id_custom = property_id
					if str(property_id) not in pro_on_property:
						pro_on_property.append(str(property_id))
					property_values_dict[property_id] = {"property_id": property_id, "property_name": attribute.attribute_name, "values": [values.replace(';', '')]}
					if scale_id_value.get(property_id):
						property_values_dict[property_id]['scale_id'] = scale_id_value.get(property_id)
				sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
				property_values = [sorted_dict[key] for key in sorted_dict]
				variants.append({"property_values": property_values, "sku": self.convert_sku(sku),
				                 "offerings": [offerings]})

		if len(variants) > 0:
			if number_sold_out == len(variants):
				state_update = product_state
				if product_state == 'active':
					update_data = {
						'state': 'inactive'
					}
					res = self.shop_api_v3(f"/listings/{product_id}", method = 'patch', data = update_data)
					if res['result'] == 'success':
						state_update = 'inactive'
				self.get_model_catalog().update_field(product['_id'], f"channel.channel_{self.get_channel_id()}.state", state_update)

				return Response().success(product)
			status = product_state
			if etsy_product_data.get('state') != 'active' and product_state != 'draft':
				update_data = {
					'state': 'active',
					'renew': True
				}
				res = self.shop_api_v3(path = f"/listings/{product_id}", method = 'patch', data = update_data)
				if res['result'] == 'success':
					status = 'active'
			update_product = {
				f"channel.channel_{self.get_channel_id()}.state": status,
			}
			self.get_model_catalog().update(product['_id'], update_product)
			pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), pro_on_property))))
			# if product.attribute_manage_quantity:
			# 	pro_on_properties = ','.join(sorted(list(map(lambda x: to_str(x), list(product.attribute_manage_quantity.keys())))))
			quantity_on_property = pro_on_properties if 'quantity_on_property' not in product else ','.join(list(map(lambda x: to_str(x), product.quantity_on_property)))
			price_on_property = pro_on_properties if 'price_on_property' not in product else ','.join(list(map(lambda x: to_str(x), product.price_on_property)))
			sku_on_property = pro_on_properties if 'sku_on_property' not in product else ','.join(list(map(lambda x: to_str(x), product.sku_on_property)))
			if 'quantity_on_property' not in product and product.tracking_inventory == 'product':
				quantity_on_property = ''
			source_sort = quantity_on_property or price_on_property or sku_on_property
			source_sort_array = list(map(lambda x: to_int(x), source_sort.split(',')))
			for variant in variants:
				property_values = variant['property_values']
				try:
					property_values.sort(key = lambda x: source_sort_array.index(to_int(x['property_id'])))
					variant['property_values'] = property_values
				except Exception:
					self.log_traceback()
			payload = {
				"products": self.to_json_array(variants),
				"quantity_on_property": quantity_on_property,
				"price_on_property": price_on_property,
				"sku_on_property": sku_on_property,
			}
			# payload = {
			# 	"products": self.to_json_array(variants),
			# 	"quantity_on_property": pro_on_properties,
			# 	"price_on_property": pro_on_properties,
			# 	"sku_on_property": pro_on_properties
			# }
			res = self.api_v3(path = f"/listings/{product_id}/inventory", method = 'put', data = payload)
			if res['result'] != 'success':
				if res.get('msg') and "cannot be more than 70 items" in res.get('msg'):
					return Response().error(code = Errors.ETSY_VARIANT_LIMIT)
				if self.is_refresh_inventory(res.get('msg')):
					self.add_product_to_need_refresh(product['_id'])
				return Response().error(code = Errors.ETSY_FAIL_API, msg = res.get('msg'))
			for index, variant_res in enumerate(res['data'].get('products')):
				variant_key = self.get_variant_key_gen(variant_res, all_variants)
				if not variant_key:
					variant_key = all_variant_keys[index]

				if not all_variants.get(variant_key):
					continue
				child = all_variants.get(variant_key)
				if not child['channel'].get(f'channel_{self.get_channel_id()}', {}).get('product_id'):
					self.insert_map_product(child, child['_id'], variant_res.get('product_id'))
				else:
					self.update_map_product(child, child['_id'], variant_res.get('product_id'))

		return Response().success(product)


	def is_refresh_inventory(self, msg):
		msg = to_str(msg)
		text_need_refresh = [
			'property IDs must be in the same order as in products',
			'with scales has invalid ott_value_qualifier 0',
			'property IDs must exist in products'
		]
		for row in text_need_refresh:
			if msg.find(row) != -1:
				return True
		return False


	def match_property(self, property_1, property_2):
		return False
		properties_1 = property_1.split(',')
		properties_2 = property_2.split(',')
		return sorted(properties_1) == sorted(properties_2)


	def valid_property(self, properties, taxonomy_support_variants):
		allow_attributes = list(map(lambda x: to_int(x), list(taxonomy_support_variants.values())))
		for property in properties:
			if to_int(property) not in allow_attributes:
				return False
		return True


	def set_imported_product(self, imported):
		if self._product_pull_type == 'active':
			self._state.pull.process.products.imported += imported
		else:
			if not self._state.pull.process.products.get(f'imported_{self._product_pull_type}'):
				self._state.pull.process.products[f'imported_{self._product_pull_type}'] = 0
			self._state.pull.process.products[f'imported_{self._product_pull_type}'] += imported


	def mass_action(self, product_id, data, product, product_ext):
		mass_action = data['mass_action']
		if mass_action == 'delete':
			self.delete_product_import(product_id)
			self.product_deleted(product['_id'], product)
			return Response().success(product_id)

		if mass_action == 'renew':
			data_post = {
				'state': 'active',
				'renew': True
			}
		elif mass_action == 'active':
			data_post = {
				'state': 'active'
			}
		else:
			return Response().success(product_id)
		res = self.shop_api_v3(method = 'patch', path = f"/listings/{product_id}", data = data_post)
		if res['result'] != "success":
			return Response().error(Errors.ETSY_FAIL_API, msg = res.get('msg'))
		if mass_action in ['renew', 'active']:
			self.get_model_catalog().update_field(product['_id'], f'channel.channel_{self.get_channel_id()}.state', 'active')
		return Response().success(product_id)


	def get_draft_extend_channel_data(self, product):
		title = self.convert_title(product.name)
		description = product.description or product.short_description or title
		description = self.replace_description(description)
		extend = {}
		if product.description != description:
			extend['description'] = description
		short_description = self.replace_description(product.short_description)
		if product.short_description != short_description:
			extend['short_description'] = short_description
		if product.name != title:
			extend['name'] = title
		for attribute in product.attributes:
			if self.product_lower_name(attribute.attribute_name) == 'materials':
				extend['materials'] = attribute.attribute_value_name
				break
		qty_setting = self._state.channel.config.setting.get('qty')

		qty = product.qty
		if not product.is_in_stock:
			qty = 0
		elif not product.manage_stock:
			qty = 999
			if qty_setting and to_int(qty_setting.get('no_manage_stock_qty')):
				qty = to_int(qty_setting.get('no_manage_stock_qty'))
		if to_int(qty) != to_int(product.qty):
			extend['qty'] = qty
		# price_setting = self._state.channel.config.setting.get('price')
		# if price_setting.get('use_sale_price') and self.is_special_price(product):
		# 	extend['price'] = product.special_price.price
		return extend


	def order_canceled(self, channel_order_id, order_id, order: Order, current_order: Order, setting_order = True):
		return self._order_sync_inventory(order, '+')


	def order_sync_inventory(self, convert: Order, setting_order):
		return self._order_sync_inventory(convert)


	def is_deduct_qty(self, property, property_values_dict_check, quantity_on_property):
		if not quantity_on_property:
			return True
		if to_len(quantity_on_property) == 2:
			return False
		value_check = property_values_dict_check[to_int(quantity_on_property[0])]
		for row in property:
			if to_int(row['property_id']) == to_int(quantity_on_property[0]) and row['property_name'] == value_check:
				return True
		return False


	def _order_sync_inventory(self, convert: Order, prefix = '-'):
		for row in convert.products:
			if (prefix == '-' and convert.status != Order.CANCELED) or (prefix == '+' and convert.status == Order.CANCELED):

				product_id = None
				variant_id = None
				if row['product_id'] and row['parent_id']:
					variant_id = row['product_id']
					product_id = row['parent_id']
				else:
					product_id = row['product_id']
				etsy_product = self.get_product_by_id(product_id)
				if etsy_product.result != Response.SUCCESS:
					continue
				etsy_product_ext = self.get_products_ext_export([etsy_product['data']])
				etsy_convert = self.convert_product_export(etsy_product['data'], etsy_product_ext['data'])
				convert = etsy_convert.data
				row_qty = to_int(row['qty']) if to_int(row.qty) > 0 else 1

				if not convert.variants:
					qty = to_int(convert.qty)
					new_qty = qty - row_qty if prefix == '-' else qty + row_qty

					if new_qty <= 0:
						update_data = {
							'state': 'inactive'
						}
						res = self.shop_api_v3(path = f"/listings/{product_id}", method = 'put', data = update_data)
					else:
						update_data = {
							"price": convert.price,
							"quantity": new_qty,
							"is_enabled": True
						}
						payload = {
							"products": self.to_json_array([{"property_values": [], "offerings": [update_data]}])}
						res = self.api_v3(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
						                  auth = self.auth())
					continue
				variants = list()
				is_inactive = True
				deduct_property = {}
				property_values_dict_check = {}

				for product in etsy_product['data']['inventory']['products']:
					property_values_dict = {}
					for property in product.property_values:
						property_values_dict[property.property_id] = {
							"property_id": property.property_id,
							"property_name": property.property_name,
							"values": [property['values'][0]]
						}
						if property.get('scale_id'):
							property_values_dict[property.property_id]['scale_id'] = property.get('scale_id')
						property_values_dict_check[to_int(property.property_id)] = property['values'][0]
					sorted_dict = {k: property_values_dict[k] for k in sorted(property_values_dict)}
					property_values = [sorted_dict[key] for key in sorted_dict]
					divisor_price = product['offerings'][0]['price'].get('divisor')
					divisor_before_conversion = product['offerings'][0]['price'].get('before_conversion', {}).get('divisor')
					price = product['offerings'][0]['price'].get('before_conversion', {}).get('amount') / divisor_before_conversion if product['offerings'][0]['price'].get('before_conversion') else product['offerings'][0]['price']['amount'] / divisor_price
					qty = product.offerings[0].quantity

					if to_str(variant_id) == to_str(product.product_id):
						deduct_property = property_values_dict_check

					offerings = {
						"variant_id": product.product_id,
						"price": price,
						"quantity": qty,
						'is_enable': product['offerings'][0]['is_enable']
					}
					variants.append({
						"offering": offerings,
						"property_values": property_values,
						'sku': product.sku
					})
				variant_update = list()
				for variant in variants:
					offering = variant['offering']
					qty = to_int(offering['quantity'])
					if to_str(variant_id) == to_str(variant['variant_id']) or self.is_deduct_qty(variant['property_values'], property_values_dict_check, etsy_product['data']['Inventory'].quantity_on_property):
						qty = qty - row_qty if prefix == '-' else qty + row_qty
					offering['quantity'] = qty
					if qty > 0:
						is_inactive = False
					del offering['variant_id']
					variant_update.append({
						"offerings": [offering],
						"property_values": variant['property_values'],
						'sku': variant['sku']
					})
				if is_inactive:
					update = {
						'state': 'inactive',

					}
					res = self.shop_api_v3(path = f"/listings/{product_id}", method = 'put', data = update)
					if res['result'] == Response.SUCCESS:
						self.get_model_catalog().update_field(row['product']['_id'], f"channel.channel_{self.get_channel_id()}.state", 'sold_out')
					continue
				payload = {
					"products": self.to_json_array(variant_update),
					"quantity_on_property": etsy_product['data']['Inventory'].quantity_on_property,
					"price_on_property": etsy_product['data']['Inventory'].price_on_property,
					"sku_on_property": etsy_product['data']['Inventory'].sku_on_property,
				}
				res = self.api_v3(path = f"/listings/{product_id}/inventory", method = 'put', data = payload,
				                  auth = self.auth())
		return Response().success()


	def get_all_section(self):
		if self._all_section:
			return self._all_section
		result = self.shop_api_v3(path = f"sections")
		if result.result == Response.SUCCESS:
			all_section = result.data.results
		else:
			all_section = []
		for section in all_section:
			self._all_section[to_int(section['shop_section_id'])] = section['title']
		return self._all_section


	def get_section_name(self, section_id):
		all_section = self.get_all_section()
		if all_section.get(to_int(section_id)):
			return all_section[to_int(section_id)]
		return ''


	def get_country_name_by_code(self, iso_code):
		if not to_str(iso_code):
			return ''
		try:
			# countries = urllib.request.urlopen("http://country.io/names.json").read()
			# countries = countries.decode('utf-8')
			countries = json.loads(self.COUNTRIES)
		except Exception as e:
			return ''
		return countries.get(to_str(iso_code).upper(), '')


	def to_price(self, price):
		return to_decimal(price.amount / price.divisor, 2)


	def is_sync_delete_sku(self):
		return True if self._state.channel.config.api.sync_empty_sku else False


	def convert_format_time(self, epoch_seconds):
		return convert_format_time(time_data = to_int(epoch_seconds) - 25200, old_format = 'timestamp')


	def channel_assign_category_template(self, product, template_data):
		item_specifics = template_data['advance']['attributes']
		for specific in item_specifics:
			specific.attribute_value = self.assign_attribute_to_field(specific.attribute_value, product)

		product.channel[f'channel_{self.get_channel_id()}']['template_data']['category']['advance']['attributes'] = item_specifics
		return product


	def channel_assign_shipping_template(self, product, template_data):
		dimensions = template_data.get('dimensions')
		if not dimensions:
			return product
		for dimension in dimensions:
			if dimension['name'] not in ['length', 'weight', 'width', 'height'] or not dimension.get('override') and not dimension.get('mapping'):
				continue
			if dimension.get('override'):
				value = dimension['override']
			else:
				value = dimension['mapping']
			value = self.assign_attribute_to_field(value, product)
			if to_decimal(value):
				dimension['value'] = value
				product.channel[f'channel_{self.get_channel_id()}'][dimension['name']] = value
		if 'dimension_units' in product.channel[f'channel_{self.get_channel_id()}']:
			del product.channel[f'channel_{self.get_channel_id()}']['dimension_units']
		if 'weight_units' in product.channel[f'channel_{self.get_channel_id()}']:
			del product.channel[f'channel_{self.get_channel_id()}']['weight_units']

		product.channel[f'channel_{self.get_channel_id()}']['template_data']['shipping']['dimensions'] = dimensions
		return product


	def channel_sync_title(self, product_id, product, products_ext):
		title = self.convert_title(product.name)
		if title != product.name:
			self._extend_product_map['name'] = title
		description = product.description or product.short_description or title
		post_data = {
		}
		if self.is_setting_sync_title():
			post_data['title'] = title[0:140]
			product['name'] = title[0:140]
		if self.is_setting_sync_description():
			post_data['description'] = self.replace_description(description)
			product['description'] = post_data['description']
		if post_data:
			res = self.shop_api_v3(f"/listings/{product_id}", method = 'patch', data = post_data)
			if res['result'] != "success":
				return Response().error(msg = res.get('msg'))
		return Response().success(product)