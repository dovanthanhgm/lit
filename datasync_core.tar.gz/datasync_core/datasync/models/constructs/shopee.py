from typing import List

from datasync.models.constructs.base import ConstructBase


class ShopeeCategorySimple(ConstructBase):
    def __init__(self, **kwargs):
        self.category_id = 0
        self.category_name = ""
        super().__init__(**kwargs)


class ShopeeBrandCategory(ConstructBase):
    def __init__(self, **kwargs):
        self.brand_id = 0
        self.brand_name = ''
        super().__init__(**kwargs)


class ShopeePreOrder(ConstructBase):
    def __init__(self, **kwargs):
        self.is_pre_order = False
        self.days_to_ship = 0
        super().__init__(**kwargs)


class ShopeeCategorySpecifics(ConstructBase):
    def __init__(self, **kwargs):
        self.name = ''
        self.override = ''
        self.value = ''
        self.mapping = ''
        super().__init__(**kwargs)


class ShopeeCategoryTemplate(ConstructBase):
    specifics: List[ShopeeCategorySpecifics]

    def __init__(self, **kwargs):
        self.primary_category = ShopeeCategorySimple()
        self.brand = ShopeeBrandCategory()
        self.pre_order = ShopeePreOrder()
        self.specifics = list()
        self.size_chart_id = ""
        super().__init__(**kwargs)


class ShopeeComplaintPolicyTemplate(ConstructBase):
    def __init__(self, **kwargs):
        self.additional_information = "",
        self.warranty_time = "",
        self.exclude_entrepreneur_warranty = False,
        self.complaint_address_id = 0,
        super().__init__(**kwargs)


class DomensticShipping(ConstructBase):

    def __init__(self, **kwargs):
        self.logistic_id = 0,
        self.enabled = False
        self.shipping_fee = 0,
        self.size_id = 0
        self.is_free = False
        super().__init__(**kwargs)


class ShopeeShippingTemplate(ConstructBase):
    domestic_shipping: List[DomensticShipping]

    def __init__(self, **kwargs):
        self.domestic_shipping = list()
        super().__init__(**kwargs)


class ShopeeExtendedDescription(ConstructBase):

    def __init__(self, **kwargs):
        self.extended_description = ''
        self.status_extended = False
        super().__init__(**kwargs)
