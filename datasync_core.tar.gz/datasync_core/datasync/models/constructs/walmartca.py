from typing import List

from datasync.models.constructs.base import ConstructBase


class WalmartcaCategorySpecifics(ConstructBase):
	name: str
	mapping: any
	override: any
	value: any

	def __init__(self, **kwargs):
		self.name = ''
		self.mapping = ''
		self.override = ''
		self.value = ''
		super().__init__(**kwargs)


class WalmartcaStatus(ConstructBase):
	ACTIVE = 'active'
	RETIRED = 'retired'
	ARCHIVED = 'archived'

	def __init__(self, **kwargs):
		super().__init__(**kwargs)

class WalmartcaCategory(ConstructBase):

	def __init__(self, **kwargs):
		self.english = WalmartcaCategorySpecifics()
		self.french = WalmartcaCategorySpecifics()
		super().__init__(**kwargs)


class WalmartcaProductInsertMap(ConstructBase):

	def __init__(self, **kwargs):
		self.sku: str = ''
		self.upc: str = ''
		self.gtin: str = ''
		self.isbn: str = ''
		self.ean: str = ''
		self.wpid: str = ''
		self.wm_itemid: str = ''
		self.mart_id: str = ''
		super().__init__(**kwargs)
