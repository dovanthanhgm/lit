from typing import List

from datasync.models.constructs.base import ConstructBase

class BonanzaCategorySimple(ConstructBase):
    def __init__(self, **kwargs):
        self.category_id = ''
        self.category_name = ''
        super().__init__(**kwargs)

class BonanzaCategorySpecifics(ConstructBase):
    def __init__(self, **kwargs):
        self.name = ''
        self.mapping = ''
        self.override = ''
        self.value = ''
        super().__init__(**kwargs)
class BonanzaCategoryTemplate(ConstructBase):
    specifics: List[BonanzaCategorySpecifics]

    def __init__(self, **kwargs):
        self.primary_category = BonanzaCategorySimple()
        self.custom_category = BonanzaCategorySimple()
        self.specifics = list()

        super().__init__(**kwargs)


class BonanzaReturnPolicy(ConstructBase):

    def __init__(self, **kwargs):
        self.description = ""
        self.returns_accepted = ""
        self.within = 0
        self.paid_by = ""
        super().__init__(**kwargs)

class BonanzaTitleTemplate(ConstructBase):

    def __init__(self, **kwargs):
        self.title = ""
        self.description = ""
        super().__init__(**kwargs)

class DomesticFlatShipment(ConstructBase):

    def __init__(self, **kwargs):
        self.free_shipping = 0
        self.shipping_service_cost = 0
        super().__init__(**kwargs)

class DomesticCalculatedShipment(ConstructBase):

    def __init__(self, **kwargs):
        self.buyer_pays_for_label = 0
        self.shipping_carrier = ""
        super().__init__(**kwargs)

class DomesticShipping(ConstructBase):
    calculated_options_attributes: List[DomesticCalculatedShipment]
    flat_options_attributes: List[DomesticFlatShipment]

    def __init__(self, **kwargs):
        self.shipment_type = ""
        self.shipping_package = ""
        self.major = ""
        self.minor = ""
        self.height = ""
        self.width = ""
        self.depth = ""
        self.calculated_options_attributes = list()
        self.flat_options_attributes = list()
        super().__init__(**kwargs)

class InternationalFlatShipment(ConstructBase):
    def __init__(self, **kwargs):
        self.shipment_type = ""
        self.ship_to_location = ""
        self.shipping_service_cost = 0
        super().__init__(**kwargs)

class InternationalFreeShipment(ConstructBase):
    def __init__(self, **kwargs):
        self.shipment_type = ""
        self.ship_to_location = ""
        super().__init__(**kwargs)
class InternationalDescriptiomShipment(ConstructBase):
    def __init__(self, **kwargs):
        self.shipment_type = ""
        self.ship_to_location = ""
        super().__init__(**kwargs)

class InternationalCalculatedShipment(ConstructBase):
    def __init__(self, **kwargs):
        self.shipment_type = ""
        self.ship_to_location = ""
        self.shipping_carrier = 0
        super().__init__(**kwargs)


class InternationalShipping(ConstructBase):
    calculated_options_attributes: List[InternationalCalculatedShipment]
    flat_options_attributes: List[InternationalFlatShipment]
    free_options_attributes: List[InternationalFreeShipment]
    description_options_attributes: List[InternationalDescriptiomShipment]
    def __init__(self, **kwargs):
        self.calculated_options_attributes = list()
        self.flat_options_attributes = list()
        self.free_options_attributes = list()
        self.description_options_attributes = list()
        super().__init__(**kwargs)

class BonanzaShippingTemplate(ConstructBase):

    def __init__(self, **kwargs):
        self.domestic_shipping = DomesticShipping()
        self.international_shipping = InternationalShipping()
        self.insurance_cost = 0
        self.insurance_type = ""
        self.global_shipping = False
        super().__init__(**kwargs)
