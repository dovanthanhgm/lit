from datasync.libs.utils import json_decode, to_decimal, to_str
from datasync.models.constructs.product import Product


class TemplateCondition:
	def __init__(self, condition, product: Product):
		self.condition = condition
		self.product = product


	def product_type_valid_condition(self):
		if self.condition.condition == 'equal':
			values = list(map(lambda x: to_str(x).strip().lower(), self.condition.value.split(',')))
			return self.product.product_type.lower() in values
		if self.condition.condition == 'not_equal':
			values = list(map(lambda x: to_str(x).strip().lower(), self.condition.value.split(',')))
			return self.product.product_type.lower() not in values

		if self.condition.condition == 'contain' and self.product.product_type.find(self.condition.value) != -1:
			return True
		if self.condition.condition == 'not_contain' and self.product.product_type.find(self.condition.value) == -1:
			return True
		return False


	def brand_valid_condition(self):
		if self.condition.condition == 'equal':
			values = list(map(lambda x: to_str(x).strip().lower(), self.condition.value.split(',')))
			return self.product.brand.lower() in values
		if self.condition.condition == 'not_equal':
			values = list(map(lambda x: to_str(x).strip().lower(), self.condition.value.split(',')))
			return self.product.brand.lower() not in values
		return False


	def tags_valid_condition(self):
		all_tags = list(map(lambda x: x.strip(), self.product.tags.split(',')))
		filter_tags = list(map(lambda x: x.strip(), self.condition.value.split(',')))
		if self.condition.condition == 'contain':
			if self.condition.apply_to == 'all':
				return all(row in all_tags for row in filter_tags)
			else:
				return any(row in all_tags for row in filter_tags)

		if self.condition.condition == 'not_contain':
			if self.condition.apply_to == 'all':
				return all(row not in all_tags for row in filter_tags)
			else:
				return any(row not in all_tags for row in filter_tags)
		return False


	def weight_to_kg(self, weight, unit):
		if unit in ['lb', 'lbs']:
			return weight * 0.45359237
		if unit in ['oz']:
			return weight * 0.0283495231
		if unit in ['g', 'gr', 'gram', 'grams']:
			return weight * 0.001
		if unit in ['tonnes', 't']:
			return weight * 1000
		return weight


	def weight_kg_to_unit(self, weight, unit):
		unit = unit.lower()
		if unit in ['lb', 'lbs']:
			return weight * 2.20462262
		if unit in ['oz']:
			return weight * 35.2739619
		if unit in ['g', 'gr', 'gram', 'grams']:
			return weight * 1000
		if unit in ['tonnes', 't']:
			return weight * 0.001
		return weight


	def convert_weight_unit(self, weight, unit, new_unit = 'lb'):
		weight = to_decimal(weight, 4)
		if not weight:
			return 0
		weight_kg = self.weight_to_kg(weight, unit)
		weight_to_unit = self.weight_kg_to_unit(weight_kg, new_unit)
		return to_decimal(weight_to_unit, 4)


	def weight_valid_condition(self):
		weight_condition = json_decode(self.condition.value)
		if not weight_condition:
			return False
		fields = ['minimum', 'maximum', 'unit']
		for field in fields:
			if field not in weight_condition:
				return False
		weight_product = self.convert_weight_unit(self.product.weight, self.product.weight_units, weight_condition['unit'])

		if to_decimal(weight_condition['minimum']) <= weight_product <= to_decimal(weight_condition['maximum']):
			return True
		return False


	def category_valid_condition(self):
		all_tags = list(map(lambda x: x.strip(), self.product.category_name_list))
		filter_tags = list(map(lambda x: x.split('_lit_sp_char_')[0].strip(), self.condition.display_value.split(',')))
		if self.condition.condition in ['contain', 'equal']:
			if self.condition.apply_to == 'all':
				return all(row in all_tags for row in filter_tags)
			else:
				return any(row in all_tags for row in filter_tags)
		if self.condition.condition == ['not_contain', 'not_equal']:
			if self.condition.apply_to == 'all':
				return all(row not in all_tags for row in filter_tags)
			else:
				return any(row not in all_tags for row in filter_tags)
		return False


	def product_format_valid_condition(self):
		if self.condition.value == 'simple' and self.product.variant_count == 0:
			return True
		if self.condition.value == 'variable' and self.product.variant_count > 0:
			return True
		return False


	def title_valid_condition(self):
		if self.condition.condition == 'contain' and self.product.name.lower().find(self.condition.value.lower()) != -1:
			return True
		if self.condition.condition == 'not_contain' and self.product.name.lower().find(self.condition.value.lower()) == -1:
			return True
		if self.condition.condition == 'start_with' and self.product.name.lower().startswith(self.condition.value.lower()):
			return True
		if self.condition.condition == 'end_with' and self.product.name.lower().endswith(self.condition.value.lower()):
			return True
		return False


	def valid(self):
		if hasattr(self, f'{self.condition.field}_valid_condition'):
			return getattr(self, f'{self.condition.field}_valid_condition')()
		return False
